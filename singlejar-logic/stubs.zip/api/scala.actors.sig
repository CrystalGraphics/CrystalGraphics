cg-stub-db 1
in 0
class scala/actors/migration/ActWithStash 50 public,interface,abstract,deprecated java/lang/Object scala/actors/InternalActor -
 inner scala/actors/migration/ActWithStash$ActorContext scala/actors/migration/ActWithStash ActorContext public
 method public,abstract scala$actors$migration$ActWithStash$_setter_$ref_$eq (Lscala/actors/migration/InternalActorRef;)V - -
 method public,abstract scala$actors$migration$ActWithStash$_setter_$self_$eq (Lscala/actors/ActorRef;)V - -
 method public,abstract scala$actors$migration$ActWithStash$_setter_$context_$eq (Lscala/actors/migration/ActWithStash$ActorContext;)V - -
 method public,abstract scala$actors$migration$ActWithStash$_setter_$scala$actors$migration$ActWithStash$$stash_$eq (Lscala/actors/MQueue;)V - -
 method public,abstract ref ()Lscala/actors/migration/InternalActorRef; - -
 method public,abstract self ()Lscala/actors/ActorRef; - -
 method public,abstract context ()Lscala/actors/migration/ActWithStash$ActorContext; - -
 method public,abstract scala$actors$migration$ActWithStash$$myTimeout ()Lscala/Option; ()Lscala/Option<Ljava/lang/Object;>; -
 method public,abstract scala$actors$migration$ActWithStash$$myTimeout_$eq (Lscala/Option;)V (Lscala/Option<Ljava/lang/Object;>;)V -
 method public,abstract scala$actors$migration$ActWithStash$$stash ()Lscala/actors/MQueue; ()Lscala/actors/MQueue<Ljava/lang/Object;>; -
 method public,abstract receive ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public,abstract preStart ()V - -
 method public,abstract postStop ()V - -
 method public,abstract preRestart (Ljava/lang/Throwable;Lscala/Option;)V (Ljava/lang/Throwable;Lscala/Option<Ljava/lang/Object;>;)V -
 method public,abstract unhandled (Ljava/lang/Object;)V - -
 method public,abstract sender ()Lscala/actors/ActorRef; - -
 method public,abstract act ()V - -
 method public,abstract start ()Lscala/actors/migration/ActWithStash; - -
 method public,abstract receive (Lscala/PartialFunction;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Lscala/PartialFunction<Ljava/lang/Object;TR;>;)TR; -
 method public,abstract behaviorStack ()Lscala/collection/immutable/Stack; ()Lscala/collection/immutable/Stack<Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>;>; -
 method public,abstract behaviorStack_$eq (Lscala/collection/immutable/Stack;)V (Lscala/collection/immutable/Stack<Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>;>;)V -
 method public,abstract preAct ()V - -
 method public,abstract stash (Ljava/lang/Object;)V - -
 method public,abstract unstashAll ()V - -
 method public,abstract wrapWithSystemMessageHandling (Lscala/PartialFunction;)Lscala/PartialFunction; (Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>;)Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public,abstract internalAct ()V - -
 method public,abstract internalPostStop ()V - -
 method public,abstract ReceiveTimeout ()Lscala/actors/TIMEOUT$; - -
in 0
class scala/actors/migration/ActWithStash$ 50 public,final,super,deprecated java/lang/Object scala/actors/Combinators,scala/Serializable -
 inner scala/actors/InternalActor$Body scala/actors/InternalActor Body public,static,interface,abstract
 inner scala/actors/migration/ActWithStash$ActorContext scala/actors/migration/ActWithStash ActorContext public
 field public,static,final MODULE$ Lscala/actors/migration/ActWithStash$; -
 method public,static <clinit> ()V - -
 method public loop (Lscala/Function0;)V (Lscala/Function0<Lscala/runtime/BoxedUnit;>;)V -
 method public loopWhile (Lscala/Function0;Lscala/Function0;)V (Lscala/Function0<Ljava/lang/Object;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;)V -
 method public continue ()V - -
 method public deadLettersActor ()Lscala/actors/ActorRef; - -
 method public mkBody (Lscala/Function0;)Lscala/actors/InternalActor$Body; <A:Ljava/lang/Object;>(Lscala/Function0<TA;>;)Ljava/lang/Object; -
in 0
class scala/actors/migration/ActWithStash$ActorContext 50 public,super java/lang/Object - -
 inner scala/actors/migration/ActWithStash$ActorContext scala/actors/migration/ActWithStash ActorContext public
 method public actr ()Lscala/actors/migration/ActWithStash; - -
 method public become (Lscala/PartialFunction;Z)V (Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>;Z)V -
 method public become$default$2 ()Z - -
 method public unbecome ()V - -
 method public stop (Lscala/actors/ActorRef;)Lscala/runtime/Nothing$; - -
 method public watch (Lscala/actors/ActorRef;)Lscala/actors/ActorRef; - -
 method public unwatch (Lscala/actors/ActorRef;)Lscala/actors/ActorRef; - -
 method public,final setReceiveTimeout (Lscala/concurrent/duration/Duration;)V - -
 method public,final receiveTimeout ()Lscala/Option; ()Lscala/Option<Lscala/concurrent/duration/Duration;>; -
 method public <init> (Lscala/actors/migration/ActWithStash;Lscala/actors/migration/ActWithStash;)V - -
in 0
class scala/actors/migration/ActWithStash$class 50 public,super,abstract java/lang/Object - -
 inner scala/actors/migration/ActWithStash$ActorContext scala/actors/migration/ActWithStash ActorContext public
 method public,static preStart (Lscala/actors/migration/ActWithStash;)V - -
 method public,static postStop (Lscala/actors/migration/ActWithStash;)V - -
 method public,static preRestart (Lscala/actors/migration/ActWithStash;Ljava/lang/Throwable;Lscala/Option;)V - -
 method public,static scala$actors$migration$ActWithStash$$become (Lscala/actors/migration/ActWithStash;Lscala/PartialFunction;Z)V - -
 method public,static scala$actors$migration$ActWithStash$$unbecome (Lscala/actors/migration/ActWithStash;)V - -
 method public,static unhandled (Lscala/actors/migration/ActWithStash;Ljava/lang/Object;)V - -
 method public,static sender (Lscala/actors/migration/ActWithStash;)Lscala/actors/ActorRef; - -
 method public,static act (Lscala/actors/migration/ActWithStash;)V - -
 method public,static start (Lscala/actors/migration/ActWithStash;)Lscala/actors/migration/ActWithStash; - -
 method public,static scala$actors$migration$ActWithStash$$creationCheck (Lscala/actors/migration/ActWithStash;)V - -
 method public,static preAct (Lscala/actors/migration/ActWithStash;)V - -
 method public,static,final stash (Lscala/actors/migration/ActWithStash;Ljava/lang/Object;)V - -
 method public,static,final unstashAll (Lscala/actors/migration/ActWithStash;)V - -
 method public,static wrapWithSystemMessageHandling (Lscala/actors/migration/ActWithStash;Lscala/PartialFunction;)Lscala/PartialFunction; - -
 method public,static internalAct (Lscala/actors/migration/ActWithStash;)V - -
 method public,static internalPostStop (Lscala/actors/migration/ActWithStash;)V - -
 method public,static ReceiveTimeout (Lscala/actors/migration/ActWithStash;)Lscala/actors/TIMEOUT$; - -
 method public,static $init$ (Lscala/actors/migration/ActWithStash;)V - -
in 0
class scala/actors/migration/ActorDSL 50 public,final,super java/lang/Object - -
 method public,static actor (Lscala/Function0;Lscala/reflect/ClassTag;)Lscala/actors/ActorRef; <T::Lscala/actors/InternalActor;>(Lscala/Function0<TT;>;Lscala/reflect/ClassTag<TT;>;)Lscala/actors/ActorRef; -
in 0
class scala/actors/migration/ActorDSL$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/actors/migration/ActorDSL$; -
 method public,static <clinit> ()V - -
 method public contextStack ()Ljava/lang/ThreadLocal; ()Ljava/lang/ThreadLocal<Lscala/collection/immutable/Stack<Ljava/lang/Object;>;>; -
 method public actor (Lscala/Function0;Lscala/reflect/ClassTag;)Lscala/actors/ActorRef; <T::Lscala/actors/InternalActor;>(Lscala/Function0<TT;>;Lscala/reflect/ClassTag<TT;>;)Lscala/actors/ActorRef; -
in 0
class scala/actors/migration/AskableActorRef 50 public,super java/lang/Object scala/actors/ActorRef -
 method public ar ()Lscala/actors/ActorRef; - -
 method public $bang (Ljava/lang/Object;Lscala/actors/ActorRef;)V - -
 method public $bang$default$2 (Ljava/lang/Object;)Lscala/actors/ActorRef; - -
 method public $qmark (Ljava/lang/Object;Lscala/actors/migration/Timeout;)Lscala/concurrent/Future; (Ljava/lang/Object;Lscala/actors/migration/Timeout;)Lscala/concurrent/Future<Ljava/lang/Object;>; -
 method public $qmark (Ljava/lang/Object;Lscala/concurrent/duration/Duration;)Lscala/concurrent/Future; (Ljava/lang/Object;Lscala/concurrent/duration/Duration;)Lscala/concurrent/Future<Ljava/lang/Object;>; -
 method public forward (Ljava/lang/Object;)V - -
 method public localActor ()Lscala/actors/AbstractActor; - -
 method public <init> (Lscala/actors/ActorRef;)V - -
in 0
class scala/actors/migration/DeathPactException 50 public,super java/lang/Exception - -
 method public,static $lessinit$greater$default$1 ()Lscala/actors/ActorRef; - -
 method public fillInStackTrace ()Lscala/actors/migration/DeathPactException; - -
 method public <init> (Lscala/actors/ActorRef;)V - -
in 0
class scala/actors/migration/DeathPactException$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/actors/migration/DeathPactException$; -
 method public,static <clinit> ()V - -
 method public $lessinit$greater$default$1 ()Lscala/actors/ActorRef; - -
in 0
class scala/actors/migration/InternalActorRef 50 public,final,super scala/actors/migration/ReactorRef - -
 inner scala/concurrent/ExecutionContext$Implicits$ scala/concurrent/ExecutionContext Implicits$ public,static
 method public,static <clinit> ()V - -
 method public actor ()Lscala/actors/InternalActor; - -
 method public $qmark (Ljava/lang/Object;Lscala/concurrent/duration/Duration;)Lscala/concurrent/Future; (Ljava/lang/Object;Lscala/concurrent/duration/Duration;)Lscala/concurrent/Future<Ljava/lang/Object;>; -
 method public $bang (Ljava/lang/Object;Lscala/actors/ActorRef;)V - -
 method public $bang$default$2 (Ljava/lang/Object;)Lscala/actors/ActorRef; - -
 method public localActor ()Lscala/actors/InternalActor; - -
 method public <init> (Lscala/actors/InternalActor;)V - -
in 0
class scala/actors/migration/OutputChannelRef 50 public,super java/lang/Object scala/actors/ActorRef -
 method public actor ()Lscala/actors/OutputChannel; ()Lscala/actors/OutputChannel<Ljava/lang/Object;>; -
 method public $qmark (Ljava/lang/Object;Lscala/concurrent/duration/Duration;)Lscala/concurrent/Future; (Ljava/lang/Object;Lscala/concurrent/duration/Duration;)Lscala/concurrent/Future<Ljava/lang/Object;>; -
 method public $bang (Ljava/lang/Object;Lscala/actors/ActorRef;)V - -
 method public $bang$default$2 (Ljava/lang/Object;)Lscala/actors/ActorRef; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public localActor ()Lscala/actors/AbstractActor; - -
 method public forward (Ljava/lang/Object;)V - -
 method public <init> (Lscala/actors/OutputChannel;)V (Lscala/actors/OutputChannel<Ljava/lang/Object;>;)V -
in 0
class scala/actors/migration/ReactorRef 50 public,super scala/actors/migration/OutputChannelRef - -
 method public actor ()Lscala/actors/Reactor; ()Lscala/actors/Reactor<Ljava/lang/Object;>; -
 method public forward (Ljava/lang/Object;)V - -
 method public <init> (Lscala/actors/Reactor;)V (Lscala/actors/Reactor<Ljava/lang/Object;>;)V -
in 0
class scala/actors/migration/Terminated 50 public,super java/lang/Object scala/Product,scala/Serializable -
 method public,static unapply (Lscala/actors/migration/Terminated;)Lscala/Option; (Lscala/actors/migration/Terminated;)Lscala/Option<Lscala/actors/ActorRef;>; -
 method public,static apply (Lscala/actors/ActorRef;Ljava/lang/Object;)Lscala/actors/migration/Terminated; - -
 method public actor ()Lscala/actors/ActorRef; - -
 method public reason ()Ljava/lang/Object; - -
 method public copy (Lscala/actors/ActorRef;Ljava/lang/Object;)Lscala/actors/migration/Terminated; - -
 method public copy$default$1 ()Lscala/actors/ActorRef; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/actors/ActorRef;Ljava/lang/Object;)V - -
in 0
class scala/actors/migration/Terminated$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/actors/migration/Terminated$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/actors/ActorRef;Ljava/lang/Object;)Lscala/actors/migration/Terminated; - -
 method public unapply (Lscala/actors/migration/Terminated;)Lscala/Option; (Lscala/actors/migration/Terminated;)Lscala/Option<Lscala/actors/ActorRef;>; -
in 0
class scala/actors/migration/Timeout 50 public,super java/lang/Object scala/Product,scala/Serializable -
 method public,static unapply (Lscala/actors/migration/Timeout;)Lscala/Option; (Lscala/actors/migration/Timeout;)Lscala/Option<Lscala/concurrent/duration/Duration;>; -
 method public,static apply (Lscala/concurrent/duration/Duration;)Lscala/actors/migration/Timeout; - -
 method public,static longToTimeout (J)Lscala/actors/migration/Timeout; - -
 method public,static intToTimeout (I)Lscala/actors/migration/Timeout; - -
 method public,static durationToTimeout (Lscala/concurrent/duration/Duration;)Lscala/actors/migration/Timeout; - -
 method public,static apply (JLjava/util/concurrent/TimeUnit;)Lscala/actors/migration/Timeout; - -
 method public,static apply (J)Lscala/actors/migration/Timeout; - -
 method public,static never ()Lscala/actors/migration/Timeout; - -
 method public,static zero ()Lscala/actors/migration/Timeout; - -
 method public duration ()Lscala/concurrent/duration/Duration; - -
 method public copy (Lscala/concurrent/duration/Duration;)Lscala/actors/migration/Timeout; - -
 method public copy$default$1 ()Lscala/concurrent/duration/Duration; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/concurrent/duration/Duration;)V - -
 method public <init> (J)V - -
 method public <init> (JLjava/util/concurrent/TimeUnit;)V - -
in 0
class scala/actors/migration/Timeout$ 50 public,final,super java/lang/Object scala/Serializable -
 inner scala/concurrent/duration/Duration$Infinite scala/concurrent/duration/Duration Infinite public,static,abstract
 field public,static,final MODULE$ Lscala/actors/migration/Timeout$; -
 method public,static <clinit> ()V - -
 method public zero ()Lscala/actors/migration/Timeout; - -
 method public never ()Lscala/actors/migration/Timeout; - -
 method public apply (J)Lscala/actors/migration/Timeout; - -
 method public apply (JLjava/util/concurrent/TimeUnit;)Lscala/actors/migration/Timeout; - -
 method public durationToTimeout (Lscala/concurrent/duration/Duration;)Lscala/actors/migration/Timeout; - -
 method public intToTimeout (I)Lscala/actors/migration/Timeout; - -
 method public longToTimeout (J)Lscala/actors/migration/Timeout; - -
 method public apply (Lscala/concurrent/duration/Duration;)Lscala/actors/migration/Timeout; - -
 method public unapply (Lscala/actors/migration/Timeout;)Lscala/Option; (Lscala/actors/migration/Timeout;)Lscala/Option<Lscala/concurrent/duration/Duration;>; -
in 0
class scala/actors/migration/package 50 public,final,super java/lang/Object - -
 method public,static actorSender ()Lscala/actors/ActorRef; - -
 method public,static registerActorRef (Lscala/Symbol;Lscala/actors/ActorRef;)V - -
 method public,static selectActorRef (Lscala/actors/remote/Node;Lscala/Symbol;)Lscala/actors/ActorRef; - -
in 0
class scala/actors/migration/package$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/actors/migration/package$; -
 method public,static <clinit> ()V - -
 method public selectActorRef (Lscala/actors/remote/Node;Lscala/Symbol;)Lscala/actors/ActorRef; - -
 method public registerActorRef (Lscala/Symbol;Lscala/actors/ActorRef;)V - -
 method public actorSender ()Lscala/actors/ActorRef; - -
in 0
class scala/actors/migration/pattern 50 public,final,super java/lang/Object - -
 method public,static ask (Lscala/actors/ActorRef;)Lscala/actors/migration/AskableActorRef; - -
in 0
class scala/actors/migration/pattern$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/actors/migration/pattern$; -
 method public,static <clinit> ()V - -
 method public ask (Lscala/actors/ActorRef;)Lscala/actors/migration/AskableActorRef; - -
