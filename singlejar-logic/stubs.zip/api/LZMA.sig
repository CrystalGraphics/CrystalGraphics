cg-stub-db 1
in 0
class LZMA/CRangeDecoder 48 super java/lang/Object - -
in 0
class LZMA/LzmaException 48 public,super java/io/IOException - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class LZMA/LzmaInputStream 48 public,super java/io/FilterInputStream - -
 method public <init> (Ljava/io/InputStream;)V - java/io/IOException
 method public read ([BII)I - java/io/IOException
 method public close ()V - java/io/IOException
