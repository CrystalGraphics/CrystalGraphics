cg-stub-db 1
in 104
class cpw/mods/bootstraplauncher/BootstrapLauncher 60 public,super java/lang/Object - -
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PkgTracker cpw/mods/bootstraplauncher/BootstrapLauncher PkgTracker private,static,final
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static main ([Ljava/lang/String;)V - -
in 105
class cpw/mods/bootstraplauncher/BootstrapLauncher 60 public,super java/lang/Object - -
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker cpw/mods/bootstraplauncher/BootstrapLauncher PackageTracker private,static,final
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static main ([Ljava/lang/String;)V - -
in 372
class cpw/mods/bootstraplauncher/BootstrapLauncher 60 public,super java/lang/Object - -
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker cpw/mods/bootstraplauncher/BootstrapLauncher PackageTracker private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static,varargs main ([Ljava/lang/String;)V - -
in 373
class cpw/mods/bootstraplauncher/BootstrapLauncher 65 public,super java/lang/Object - -
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker cpw/mods/bootstraplauncher/BootstrapLauncher PackageTracker private,static,final
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static,varargs unitTestingMain ([Ljava/lang/String;)V - -
 method public,static,varargs main ([Ljava/lang/String;)V - -
in 194
class cpw/mods/bootstraplauncher/BootstrapLauncher 65 public,super java/lang/Object - -
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker cpw/mods/bootstraplauncher/BootstrapLauncher PackageTracker private,static,final
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static,varargs unitTestingMain ([Ljava/lang/String;)V - java/lang/Exception
 method public,static,varargs main ([Ljava/lang/String;)V - java/lang/Exception
in 374
class cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker 60 final,super java/lang/Record java/util/function/BiPredicate Ljava/lang/Record;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker cpw/mods/bootstraplauncher/BootstrapLauncher PackageTracker private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public test (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public packages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public paths ()[Ljava/nio/file/Path; - -
in 348
class cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker 65 final,super java/lang/Record cpw/mods/niofs/union/UnionPathFilter -
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PackageTracker cpw/mods/bootstraplauncher/BootstrapLauncher PackageTracker private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public test (Ljava/lang/String;Ljava/nio/file/Path;)Z - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public packages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public paths ()[Ljava/nio/file/Path; - -
in 104
class cpw/mods/bootstraplauncher/BootstrapLauncher$PkgTracker 60 final,super java/lang/Record java/util/function/BiPredicate Ljava/lang/Record;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;
 inner cpw/mods/bootstraplauncher/BootstrapLauncher$PkgTracker cpw/mods/bootstraplauncher/BootstrapLauncher PkgTracker private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public test (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public packages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public paths ()[Ljava/nio/file/Path; - -
in 0
class cpw/mods/cl/JarModuleFinder 60 public,super java/lang/Object java/lang/module/ModuleFinder -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public find (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/module/ModuleReference;>; -
 method public findAll ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/module/ModuleReference;>; -
 method public,static,varargs of ([Lcpw/mods/jarhandling/SecureJar;)Lcpw/mods/cl/JarModuleFinder; - -
in 182
class cpw/mods/cl/JarModuleFinder 60 public,super java/lang/Object java/lang/module/ModuleFinder -
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public find (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/module/ModuleReference;>; -
 method public findAll ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/module/ModuleReference;>; -
 method public,static,varargs of ([Lcpw/mods/jarhandling/SecureJar;)Lcpw/mods/cl/JarModuleFinder; - -
in 191
class cpw/mods/cl/JarModuleFinder 60 public,super java/lang/Object java/lang/module/ModuleFinder -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public find (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/module/ModuleReference;>; -
 method public findAll ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/module/ModuleReference;>; -
 method public,static,varargs of ([Lcpw/mods/jarhandling/SecureJar;)Lcpw/mods/cl/JarModuleFinder; - -
in 348
class cpw/mods/cl/JarModuleFinder 65 public,super java/lang/Object java/lang/module/ModuleFinder -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public find (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/module/ModuleReference;>; -
 method public findAll ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/module/ModuleReference;>; -
 method public,static,varargs of ([Lcpw/mods/jarhandling/SecureJar;)Lcpw/mods/cl/JarModuleFinder; - -
in 0
class cpw/mods/cl/JarModuleFinder$JarModuleReader 60 super java/lang/Object java/lang/module/ModuleReader -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/jarhandling/impl/Jar;)V - -
 method public find (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; java/io/IOException
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; java/io/IOException
 method public list ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; java/io/IOException
 method public close ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 372
class cpw/mods/cl/JarModuleFinder$JarModuleReader 60 super java/lang/Object java/lang/module/ModuleReader -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider;)V - -
 method public find (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; java/io/IOException
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; java/io/IOException
 method public list ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; java/io/IOException
 method public close ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 348
class cpw/mods/cl/JarModuleFinder$JarModuleReader 65 super java/lang/Object java/lang/module/ModuleReader -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider;)V - -
 method public find (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; java/io/IOException
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; java/io/IOException
 method public list ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; java/io/IOException
 method public close ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 0
class cpw/mods/cl/JarModuleFinder$JarModuleReference 60 super java/lang/module/ModuleReference - -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 method public open ()Ljava/lang/module/ModuleReader; - java/io/IOException
 method public jar ()Lcpw/mods/jarhandling/impl/Jar; - -
in 372
class cpw/mods/cl/JarModuleFinder$JarModuleReference 60 super java/lang/module/ModuleReference - -
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 method public open ()Ljava/lang/module/ModuleReader; - java/io/IOException
 method public jar ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
in 348
class cpw/mods/cl/JarModuleFinder$JarModuleReference 65 super java/lang/module/ModuleReference - -
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/cl/JarModuleFinder$JarModuleReader cpw/mods/cl/JarModuleFinder JarModuleReader static
 method public open ()Ljava/lang/module/ModuleReader; - java/io/IOException
 method public jar ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
in 375
class cpw/mods/cl/ModularURLHandler 60 public,super java/lang/Object java/net/URLStreamHandlerFactory -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 inner cpw/mods/cl/ModularURLHandler$FunctionURLStreamHandler cpw/mods/cl/ModularURLHandler FunctionURLStreamHandler private,static
 inner cpw/mods/cl/ModularURLHandler$FunctionURLConnection cpw/mods/cl/ModularURLHandler FunctionURLConnection private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 field public,static,final INSTANCE Lcpw/mods/cl/ModularURLHandler; -
 method public <init> ()V - -
 method public,static initFrom (Ljava/lang/ModuleLayer;)V - -
 method public createURLStreamHandler (Ljava/lang/String;)Ljava/net/URLStreamHandler; - -
in 348
class cpw/mods/cl/ModularURLHandler 65 public,super java/lang/Object java/net/URLStreamHandlerFactory -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 inner cpw/mods/cl/ModularURLHandler$FunctionURLStreamHandler cpw/mods/cl/ModularURLHandler FunctionURLStreamHandler private,static
 inner cpw/mods/cl/ModularURLHandler$FunctionURLConnection cpw/mods/cl/ModularURLHandler FunctionURLConnection private,static
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lcpw/mods/cl/ModularURLHandler; -
 method public <init> ()V - -
 method public,static initFrom (Ljava/lang/ModuleLayer;)V - -
 method public createURLStreamHandler (Ljava/lang/String;)Ljava/net/URLStreamHandler; - -
in 53
class cpw/mods/cl/ModularURLHandler$FunctionURLConnection 60 super java/net/URLConnection - -
 inner cpw/mods/cl/ModularURLHandler$FunctionURLConnection cpw/mods/cl/ModularURLHandler FunctionURLConnection private,static
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 method protected <init> (Ljava/net/URL;Lcpw/mods/cl/ModularURLHandler$IURLProvider;)V - -
 method public connect ()V - java/io/IOException
 method public getInputStream ()Ljava/io/InputStream; - java/io/IOException
in 191
class cpw/mods/cl/ModularURLHandler$FunctionURLConnection 60 super java/net/URLConnection - -
 inner cpw/mods/cl/ModularURLHandler$FunctionURLConnection cpw/mods/cl/ModularURLHandler FunctionURLConnection private,static
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 method protected <init> (Ljava/net/URL;Lcpw/mods/cl/ModularURLHandler$IURLProvider;)V - -
 method public connect ()V - java/io/IOException
 method public getInputStream ()Ljava/io/InputStream; - java/io/IOException
 method public getContentLength ()I - -
 method public getContentLengthLong ()J - -
 method public getLastModified ()J - -
in 348
class cpw/mods/cl/ModularURLHandler$FunctionURLConnection 65 super java/net/URLConnection - -
 inner cpw/mods/cl/ModularURLHandler$FunctionURLConnection cpw/mods/cl/ModularURLHandler FunctionURLConnection private,static
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 method protected <init> (Ljava/net/URL;Lcpw/mods/cl/ModularURLHandler$IURLProvider;)V - -
 method public connect ()V - java/io/IOException
 method public getInputStream ()Ljava/io/InputStream; - java/io/IOException
 method public getContentLength ()I - -
 method public getContentLengthLong ()J - -
 method public getLastModified ()J - -
in 375
class cpw/mods/cl/ModularURLHandler$FunctionURLStreamHandler 60 super java/net/URLStreamHandler - -
 inner cpw/mods/cl/ModularURLHandler$FunctionURLStreamHandler cpw/mods/cl/ModularURLHandler FunctionURLStreamHandler private,static
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 inner cpw/mods/cl/ModularURLHandler$FunctionURLConnection cpw/mods/cl/ModularURLHandler FunctionURLConnection private,static
 method public <init> (Lcpw/mods/cl/ModularURLHandler$IURLProvider;)V - -
 method protected openConnection (Ljava/net/URL;)Ljava/net/URLConnection; - java/io/IOException
in 348
class cpw/mods/cl/ModularURLHandler$FunctionURLStreamHandler 65 super java/net/URLStreamHandler - -
 inner cpw/mods/cl/ModularURLHandler$FunctionURLStreamHandler cpw/mods/cl/ModularURLHandler FunctionURLStreamHandler private,static
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 inner cpw/mods/cl/ModularURLHandler$FunctionURLConnection cpw/mods/cl/ModularURLHandler FunctionURLConnection private,static
 method public <init> (Lcpw/mods/cl/ModularURLHandler$IURLProvider;)V - -
 method protected openConnection (Ljava/net/URL;)Ljava/net/URLConnection; - java/io/IOException
in 53
class cpw/mods/cl/ModularURLHandler$IURLProvider 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 method public,abstract protocol ()Ljava/lang/String; - -
 method public,abstract inputStreamFunction ()Ljava/util/function/Function; ()Ljava/util/function/Function<Ljava/net/URL;Ljava/io/InputStream;>; -
in 191
class cpw/mods/cl/ModularURLHandler$IURLProvider 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 method public,abstract protocol ()Ljava/lang/String; - -
 method public,abstract inputStreamFunction ()Ljava/util/function/Function; ()Ljava/util/function/Function<Ljava/net/URL;Ljava/io/InputStream;>; -
 method public getLastModified (Ljava/net/URL;)J - -
 method public getContentLength (Ljava/net/URL;)J - -
in 348
class cpw/mods/cl/ModularURLHandler$IURLProvider 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 method public,abstract protocol ()Ljava/lang/String; - -
 method public,abstract inputStreamFunction ()Ljava/util/function/Function; ()Ljava/util/function/Function<Ljava/net/URL;Ljava/io/InputStream;>; -
 method public getLastModified (Ljava/net/URL;)J - -
 method public getContentLength (Ljava/net/URL;)J - -
in 104
class cpw/mods/cl/ModuleClassLoader 60 public,super java/lang/ClassLoader - -
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Exports java/lang/module/ModuleDescriptor Exports public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;)V -
 method protected getClassBytes (Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;Ljava/lang/String;)[B - -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected classNameToModuleName (Ljava/lang/String;)Ljava/lang/String; - -
 method public getResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected findResource (Ljava/lang/String;Ljava/lang/String;)Ljava/net/URL; - java/io/IOException
 method public getResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class<*>; -
 method protected loadFromModule (Ljava/lang/String;Ljava/util/function/BiFunction;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/BiFunction<Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;TT;>;)TT; java/io/IOException
 method protected getMaybeTransformedClassBytes (Ljava/lang/String;Ljava/lang/String;)[B - -
 method public setFallbackClassLoader (Ljava/lang/ClassLoader;)V - -
in 105
class cpw/mods/cl/ModuleClassLoader 60 public,super java/lang/ClassLoader - -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Exports java/lang/module/ModuleDescriptor Exports public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;)V -
 method protected getClassBytes (Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;Ljava/lang/String;)[B - -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected classNameToModuleName (Ljava/lang/String;)Ljava/lang/String; - -
 method public getResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected findResource (Ljava/lang/String;Ljava/lang/String;)Ljava/net/URL; - java/io/IOException
 method public getResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class<*>; -
 method protected loadFromModule (Ljava/lang/String;Ljava/util/function/BiFunction;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/BiFunction<Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;TT;>;)TT; java/io/IOException
 method protected getMaybeTransformedClassBytes (Ljava/lang/String;Ljava/lang/String;)[B - java/lang/ClassNotFoundException
 method public setFallbackClassLoader (Ljava/lang/ClassLoader;)V - -
in 182
class cpw/mods/cl/ModuleClassLoader 60 public,super java/lang/ClassLoader - -
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Exports java/lang/module/ModuleDescriptor Exports public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;)V -
 method protected getClassBytes (Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;Ljava/lang/String;)[B - -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected classNameToModuleName (Ljava/lang/String;)Ljava/lang/String; - -
 method public getResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected findResource (Ljava/lang/String;Ljava/lang/String;)Ljava/net/URL; - java/io/IOException
 method public getResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class<*>; -
 method protected loadFromModule (Ljava/lang/String;Ljava/util/function/BiFunction;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/BiFunction<Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;TT;>;)TT; java/io/IOException
 method protected getMaybeTransformedClassBytes (Ljava/lang/String;Ljava/lang/String;)[B - java/lang/ClassNotFoundException
 method public setFallbackClassLoader (Ljava/lang/ClassLoader;)V - -
in 191
class cpw/mods/cl/ModuleClassLoader 60 public,super java/lang/ClassLoader - -
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Exports java/lang/module/ModuleDescriptor Exports public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;)V -
 method protected getClassBytes (Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;Ljava/lang/String;)[B - -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected classNameToModuleName (Ljava/lang/String;)Ljava/lang/String; - -
 method public getResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected findResource (Ljava/lang/String;Ljava/lang/String;)Ljava/net/URL; - java/io/IOException
 method public getResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class<*>; -
 method protected loadFromModule (Ljava/lang/String;Ljava/util/function/BiFunction;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/BiFunction<Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;TT;>;)TT; java/io/IOException
 method protected getMaybeTransformedClassBytes (Ljava/lang/String;Ljava/lang/String;)[B - java/lang/ClassNotFoundException
 method public setFallbackClassLoader (Ljava/lang/ClassLoader;)V - -
in 348
class cpw/mods/cl/ModuleClassLoader 65 public,super java/lang/ClassLoader - -
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/cl/JarModuleFinder$JarModuleReference cpw/mods/cl/JarModuleFinder JarModuleReference static
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Exports java/lang/module/ModuleDescriptor Exports public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List;Ljava/lang/ClassLoader;)V (Ljava/lang/String;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;Ljava/lang/ClassLoader;)V -
 method protected getClassBytes (Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;Ljava/lang/String;)[B - -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected classNameToModuleName (Ljava/lang/String;)Ljava/lang/String; - -
 method public getResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected findResource (Ljava/lang/String;Ljava/lang/String;)Ljava/net/URL; - java/io/IOException
 method public getResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; java/io/IOException
 method protected findClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Class<*>; -
 method protected loadFromModule (Ljava/lang/String;Ljava/util/function/BiFunction;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/BiFunction<Ljava/lang/module/ModuleReader;Ljava/lang/module/ModuleReference;TT;>;)TT; java/io/IOException
 method protected getMaybeTransformedClassBytes (Ljava/lang/String;Ljava/lang/String;)[B - java/lang/ClassNotFoundException
 method public setFallbackClassLoader (Ljava/lang/ClassLoader;)V - -
in 375
class cpw/mods/cl/ProtectionDomainHelper 60 public,super java/lang/Object - -
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static createCodeSource (Ljava/net/URL;[Ljava/security/CodeSigner;)Ljava/security/CodeSource; - -
 method public,static createProtectionDomain (Ljava/security/CodeSource;Ljava/lang/ClassLoader;)Ljava/security/ProtectionDomain; - -
in 348
class cpw/mods/cl/ProtectionDomainHelper 65 public,super java/lang/Object - -
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static createCodeSource (Ljava/net/URL;[Ljava/security/CodeSigner;)Ljava/security/CodeSource; - -
 method public,static createProtectionDomain (Ljava/security/CodeSource;Ljava/lang/ClassLoader;)Ljava/security/ProtectionDomain; - -
in 53
class cpw/mods/cl/UnionURLStreamHandler 60 public,super java/lang/Object cpw/mods/cl/ModularURLHandler$IURLProvider -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public protocol ()Ljava/lang/String; - -
 method public inputStreamFunction ()Ljava/util/function/Function; ()Ljava/util/function/Function<Ljava/net/URL;Ljava/io/InputStream;>; -
in 191
class cpw/mods/cl/UnionURLStreamHandler 60 public,super java/lang/Object cpw/mods/cl/ModularURLHandler$IURLProvider -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public protocol ()Ljava/lang/String; - -
 method public inputStreamFunction ()Ljava/util/function/Function; ()Ljava/util/function/Function<Ljava/net/URL;Ljava/io/InputStream;>; -
 method public getLastModified (Ljava/net/URL;)J - -
 method public getContentLength (Ljava/net/URL;)J - -
in 348
class cpw/mods/cl/UnionURLStreamHandler 65 public,super java/lang/Object cpw/mods/cl/ModularURLHandler$IURLProvider -
 inner cpw/mods/cl/ModularURLHandler$IURLProvider cpw/mods/cl/ModularURLHandler IURLProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public protocol ()Ljava/lang/String; - -
 method public inputStreamFunction ()Ljava/util/function/Function; ()Ljava/util/function/Function<Ljava/net/URL;Ljava/io/InputStream;>; -
 method public getLastModified (Ljava/net/URL;)J - -
 method public getContentLength (Ljava/net/URL;)J - -
in 182
class cpw/mods/fml/relauncher/Side 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/fml/relauncher/Side;>;
 field public,static,final,enum CLIENT Lcpw/mods/fml/relauncher/Side; -
 field public,static,final,enum SERVER Lcpw/mods/fml/relauncher/Side; -
 field public,static,final,enum BUKKIT Lcpw/mods/fml/relauncher/Side; -
 method public,static values ()[Lcpw/mods/fml/relauncher/Side; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/fml/relauncher/Side; - -
 method public isServer ()Z - -
 method public isClient ()Z - -
in 182
class cpw/mods/fml/relauncher/SideOnly 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()Lcpw/mods/fml/relauncher/Side; - -
in 376
class cpw/mods/gross/Java9ClassLoaderUtil 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getSystemClassPathURLs ()[Ljava/net/URL; - -
in 191
class cpw/mods/jarhandling/JarContents 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner org/jetbrains/annotations/ApiStatus$NonExtendable org/jetbrains/annotations/ApiStatus NonExtendable public,static,interface,abstract,annotation
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,abstract getManifest ()Ljava/util/jar/Manifest; - -
 method public,abstract getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,varargs,abstract getPackagesExcluding ([Ljava/lang/String;)Ljava/util/Set; ([Ljava/lang/String;)Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract getMetaInfServices ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
in 377
class cpw/mods/jarhandling/JarContents 65 public,interface,abstract java/lang/Object java/io/Closeable -
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner org/jetbrains/annotations/ApiStatus$NonExtendable org/jetbrains/annotations/ApiStatus NonExtendable public,static,interface,abstract,annotation
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,abstract getManifest ()Ljava/util/jar/Manifest; - -
 method public,abstract getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,varargs,abstract getPackagesExcluding ([Ljava/lang/String;)Ljava/util/Set; ([Ljava/lang/String;)Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract getMetaInfServices ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,static of (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/JarContents; - -
 method public,static of (Ljava/util/Collection;)Lcpw/mods/jarhandling/JarContents; (Ljava/util/Collection<Ljava/nio/file/Path;>;)Lcpw/mods/jarhandling/JarContents; -
in 122
class cpw/mods/jarhandling/JarContents 65 public,interface,abstract java/lang/Object java/io/Closeable -
 inner org/jetbrains/annotations/ApiStatus$NonExtendable org/jetbrains/annotations/ApiStatus NonExtendable public,static,interface,abstract,annotation
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,abstract openFile (Ljava/lang/String;)Ljava/io/InputStream; - java/io/IOException
 method public containsFile (Ljava/lang/String;)Z - java/io/IOException
 method public,abstract getManifest ()Ljava/util/jar/Manifest; - -
 method public,static of (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/JarContents; - -
 method public,static of (Ljava/util/Collection;)Lcpw/mods/jarhandling/JarContents; (Ljava/util/Collection<Ljava/nio/file/Path;>;)Lcpw/mods/jarhandling/JarContents; -
in 191
class cpw/mods/jarhandling/JarContentsBuilder 60 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,varargs paths ([Ljava/nio/file/Path;)Lcpw/mods/jarhandling/JarContentsBuilder; - -
 method public defaultManifest (Ljava/util/function/Supplier;)Lcpw/mods/jarhandling/JarContentsBuilder; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;)Lcpw/mods/jarhandling/JarContentsBuilder; -
 method public pathFilter (Lcpw/mods/niofs/union/UnionPathFilter;)Lcpw/mods/jarhandling/JarContentsBuilder; - -
 method public build ()Lcpw/mods/jarhandling/JarContents; - -
in 348
class cpw/mods/jarhandling/JarContentsBuilder 65 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,varargs paths ([Ljava/nio/file/Path;)Lcpw/mods/jarhandling/JarContentsBuilder; - -
 method public defaultManifest (Ljava/util/function/Supplier;)Lcpw/mods/jarhandling/JarContentsBuilder; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;)Lcpw/mods/jarhandling/JarContentsBuilder; -
 method public pathFilter (Lcpw/mods/niofs/union/UnionPathFilter;)Lcpw/mods/jarhandling/JarContentsBuilder; - -
 method public build ()Lcpw/mods/jarhandling/JarContents; - -
in 0
class cpw/mods/jarhandling/JarMetadata 60 public,interface,abstract java/lang/Object - -
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DASH_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NON_ALPHANUM Ljava/util/regex/Pattern; -
 field public,static,final REPEATING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final LEADING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final TRAILING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final MODULE_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NUMBERLIKE_PARTS Ljava/util/regex/Pattern; -
 field public,static,final ILLEGAL_KEYWORDS Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public,static,final KEYWORD_PARTS Ljava/util/regex/Pattern; -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract version ()Ljava/lang/String; - -
 method public,abstract descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public,static,varargs from (Lcpw/mods/jarhandling/SecureJar;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/JarMetadata; - -
 method public,static fromFileName (Ljava/nio/file/Path;Ljava/util/Set;Ljava/util/List;)Lcpw/mods/jarhandling/impl/SimpleJarMetadata; (Ljava/nio/file/Path;Ljava/util/Set<Ljava/lang/String;>;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>;)Lcpw/mods/jarhandling/impl/SimpleJarMetadata; -
in 182
class cpw/mods/jarhandling/JarMetadata 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DASH_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NON_ALPHANUM Ljava/util/regex/Pattern; -
 field public,static,final REPEATING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final LEADING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final TRAILING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final MODULE_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NUMBERLIKE_PARTS Ljava/util/regex/Pattern; -
 field public,static,final ILLEGAL_KEYWORDS Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public,static,final KEYWORD_PARTS Ljava/util/regex/Pattern; -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract version ()Ljava/lang/String; - -
 method public,abstract descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public,static,varargs from (Lcpw/mods/jarhandling/SecureJar;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/JarMetadata; - -
 method public,static fromFileName (Ljava/nio/file/Path;Ljava/util/Set;Ljava/util/List;)Lcpw/mods/jarhandling/impl/SimpleJarMetadata; (Ljava/nio/file/Path;Ljava/util/Set<Ljava/lang/String;>;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>;)Lcpw/mods/jarhandling/impl/SimpleJarMetadata; -
in 191
class cpw/mods/jarhandling/JarMetadata 60 public,interface,abstract java/lang/Object - -
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/module/ModuleDescriptor$Provides java/lang/module/ModuleDescriptor Provides public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DASH_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NON_ALPHANUM Ljava/util/regex/Pattern; -
 field public,static,final REPEATING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final LEADING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final TRAILING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final MODULE_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NUMBERLIKE_PARTS Ljava/util/regex/Pattern; -
 field public,static,final ILLEGAL_KEYWORDS Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public,static,final KEYWORD_PARTS Ljava/util/regex/Pattern; -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract version ()Ljava/lang/String; - -
 method public,abstract descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public providers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,static from (Lcpw/mods/jarhandling/JarContents;)Lcpw/mods/jarhandling/JarMetadata; - -
 method public,static,deprecated fromFileName (Ljava/nio/file/Path;Ljava/util/Set;Ljava/util/List;)Lcpw/mods/jarhandling/impl/SimpleJarMetadata; (Ljava/nio/file/Path;Ljava/util/Set<Ljava/lang/String;>;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>;)Lcpw/mods/jarhandling/impl/SimpleJarMetadata; -
 method public,static,varargs,deprecated from (Lcpw/mods/jarhandling/SecureJar;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/JarMetadata; - -
in 377
class cpw/mods/jarhandling/JarMetadata 65 public,interface,abstract java/lang/Object - -
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/module/ModuleDescriptor$Provides java/lang/module/ModuleDescriptor Provides public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DASH_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NON_ALPHANUM Ljava/util/regex/Pattern; -
 field public,static,final REPEATING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final LEADING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final TRAILING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final MODULE_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NUMBERLIKE_PARTS Ljava/util/regex/Pattern; -
 field public,static,final ILLEGAL_KEYWORDS Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public,static,final KEYWORD_PARTS Ljava/util/regex/Pattern; -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract version ()Ljava/lang/String; - -
 method public,abstract descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public providers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,static from (Lcpw/mods/jarhandling/JarContents;)Lcpw/mods/jarhandling/JarMetadata; - -
in 122
class cpw/mods/jarhandling/JarMetadata 65 public,interface,abstract java/lang/Object - -
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DASH_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NON_ALPHANUM Ljava/util/regex/Pattern; -
 field public,static,final REPEATING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final LEADING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final TRAILING_DOTS Ljava/util/regex/Pattern; -
 field public,static,final MODULE_VERSION Ljava/util/regex/Pattern; -
 field public,static,final NUMBERLIKE_PARTS Ljava/util/regex/Pattern; -
 field public,static,final ILLEGAL_KEYWORDS Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public,static,final KEYWORD_PARTS Ljava/util/regex/Pattern; -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract version ()Ljava/lang/String; - -
 method public,abstract descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public,static from (Lcpw/mods/jarhandling/JarContents;)Lcpw/mods/jarhandling/JarMetadata; - -
in 191
class cpw/mods/jarhandling/LazyJarMetadata 60 public,super,abstract java/lang/Object cpw/mods/jarhandling/JarMetadata -
 method public <init> ()V - -
 method public,final descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method protected,abstract computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
in 348
class cpw/mods/jarhandling/LazyJarMetadata 65 public,super,abstract java/lang/Object cpw/mods/jarhandling/JarMetadata -
 method public <init> ()V - -
 method public,final descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method protected,abstract computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
in 191
class cpw/mods/jarhandling/NameAndVersion 60 final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
in 348
class cpw/mods/jarhandling/NameAndVersion 65 final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
in 0
class cpw/mods/jarhandling/SecureJar 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,abstract getManifest ()Ljava/util/jar/Manifest; - -
 method public,abstract getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public,abstract verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public,abstract hasSecurityData ()Z - -
 method public,static,varargs from ([Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static,varargs from (Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Function;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Supplier;Ljava/util/function/Function;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Supplier;Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,abstract getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract getProviders ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,abstract name ()Ljava/lang/String; - -
 method public,varargs,abstract getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,abstract getRootPath ()Ljava/nio/file/Path; - -
in 182
class cpw/mods/jarhandling/SecureJar 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public,abstract verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public,abstract hasSecurityData ()Z - -
 method public,static,varargs from ([Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static,varargs from (Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Function;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Supplier;Ljava/util/function/Function;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs from (Ljava/util/function/Supplier;Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,abstract getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract getProviders ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,abstract name ()Ljava/lang/String; - -
 method public,varargs,abstract getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,abstract getRootPath ()Ljava/nio/file/Path; - -
in 191
class cpw/mods/jarhandling/SecureJar 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/module/ModuleDescriptor$Provides java/lang/module/ModuleDescriptor Provides public,static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static,varargs from ([Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static from (Lcpw/mods/jarhandling/JarContents;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static from (Lcpw/mods/jarhandling/JarContents;Lcpw/mods/jarhandling/JarMetadata;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,abstract moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public,abstract verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public,abstract hasSecurityData ()Z - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,varargs,abstract getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,abstract getRootPath ()Ljava/nio/file/Path; - -
 method public,deprecated getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,deprecated getProviders ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,static,varargs,deprecated from (Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs,deprecated from (Ljava/util/function/Function;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs,deprecated from (Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs,deprecated from (Ljava/util/function/Supplier;Ljava/util/function/Function;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
 method public,static,varargs,deprecated from (Ljava/util/function/Supplier;Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; -
in 377
class cpw/mods/jarhandling/SecureJar 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 method public,static,varargs from ([Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static from (Lcpw/mods/jarhandling/JarContents;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static from (Lcpw/mods/jarhandling/JarContents;Lcpw/mods/jarhandling/JarMetadata;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,abstract moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public,abstract verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public,abstract hasSecurityData ()Z - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,varargs,abstract getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,abstract getRootPath ()Ljava/nio/file/Path; - -
 method public,abstract close ()V - java/io/IOException
in 122
class cpw/mods/jarhandling/SecureJar 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 method public,static,varargs from ([Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static from (Lcpw/mods/jarhandling/JarContents;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,static from (Lcpw/mods/jarhandling/JarContents;Lcpw/mods/jarhandling/JarMetadata;)Lcpw/mods/jarhandling/SecureJar; - -
 method public,abstract moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public,abstract getPrimaryPath ()Ljava/nio/file/Path; - -
 method public,abstract getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public,abstract verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,abstract getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public,abstract hasSecurityData ()Z - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,varargs,abstract getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,abstract getRootPath ()Ljava/nio/file/Path; - -
 method public,abstract close ()V - java/io/IOException
in 372
class cpw/mods/jarhandling/SecureJar$ModuleDataProvider 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public,abstract uri ()Ljava/net/URI; - -
 method public,abstract findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,abstract open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; -
 method public,abstract getManifest ()Ljava/util/jar/Manifest; - -
 method public,abstract verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
in 348
class cpw/mods/jarhandling/SecureJar$ModuleDataProvider 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public,abstract uri ()Ljava/net/URI; - -
 method public,abstract findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,abstract open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; -
 method public,abstract getManifest ()Ljava/util/jar/Manifest; - -
 method public,abstract verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
in 375
class cpw/mods/jarhandling/SecureJar$Provider 60 public,final,super java/lang/Record - -
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;)V -
 method public,static fromPath (Ljava/nio/file/Path;Ljava/util/function/BiPredicate;)Lcpw/mods/jarhandling/SecureJar$Provider; (Ljava/nio/file/Path;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;)Lcpw/mods/jarhandling/SecureJar$Provider; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public serviceName ()Ljava/lang/String; - -
 method public providers ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
in 377
class cpw/mods/jarhandling/SecureJar$Provider 65 public,final,super java/lang/Record - -
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;)V -
 method public,static fromPath (Ljava/nio/file/Path;Lcpw/mods/niofs/union/UnionPathFilter;)Lcpw/mods/jarhandling/SecureJar$Provider; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public serviceName ()Ljava/lang/String; - -
 method public providers ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
in 375
class cpw/mods/jarhandling/SecureJar$Status 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/jarhandling/SecureJar$Status;>;
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 field public,static,final,enum NONE Lcpw/mods/jarhandling/SecureJar$Status; -
 field public,static,final,enum INVALID Lcpw/mods/jarhandling/SecureJar$Status; -
 field public,static,final,enum UNVERIFIED Lcpw/mods/jarhandling/SecureJar$Status; -
 field public,static,final,enum VERIFIED Lcpw/mods/jarhandling/SecureJar$Status; -
 method public,static values ()[Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
in 348
class cpw/mods/jarhandling/SecureJar$Status 65 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/jarhandling/SecureJar$Status;>;
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 field public,static,final,enum NONE Lcpw/mods/jarhandling/SecureJar$Status; -
 field public,static,final,enum INVALID Lcpw/mods/jarhandling/SecureJar$Status; -
 field public,static,final,enum UNVERIFIED Lcpw/mods/jarhandling/SecureJar$Status; -
 field public,static,final,enum VERIFIED Lcpw/mods/jarhandling/SecureJar$Status; -
 method public,static values ()[Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
in 191
class cpw/mods/jarhandling/VirtualJar 60 public,final,super java/lang/Object cpw/mods/jarhandling/SecureJar -
 inner cpw/mods/jarhandling/VirtualJar$VirtualJarModuleDataProvider cpw/mods/jarhandling/VirtualJar VirtualJarModuleDataProvider private
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Ljava/lang/String;Ljava/nio/file/Path;[Ljava/lang/String;)V - -
 method public moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public hasSecurityData ()Z - -
 method public name ()Ljava/lang/String; - -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getRootPath ()Ljava/nio/file/Path; - -
in 348
class cpw/mods/jarhandling/VirtualJar 65 public,final,super java/lang/Object cpw/mods/jarhandling/SecureJar -
 inner cpw/mods/jarhandling/VirtualJar$VirtualJarModuleDataProvider cpw/mods/jarhandling/VirtualJar VirtualJarModuleDataProvider private
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Ljava/lang/String;Ljava/nio/file/Path;[Ljava/lang/String;)V - -
 method public moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public hasSecurityData ()Z - -
 method public name ()Ljava/lang/String; - -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getRootPath ()Ljava/nio/file/Path; - -
 method public close ()V - java/io/IOException
in 191
class cpw/mods/jarhandling/VirtualJar$VirtualJarModuleDataProvider 60 super java/lang/Object cpw/mods/jarhandling/SecureJar$ModuleDataProvider -
 inner cpw/mods/jarhandling/VirtualJar$VirtualJarModuleDataProvider cpw/mods/jarhandling/VirtualJar VirtualJarModuleDataProvider private
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 method public name ()Ljava/lang/String; - -
 method public descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public uri ()Ljava/net/URI; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
in 348
class cpw/mods/jarhandling/VirtualJar$VirtualJarModuleDataProvider 65 super java/lang/Object cpw/mods/jarhandling/SecureJar$ModuleDataProvider -
 inner cpw/mods/jarhandling/VirtualJar$VirtualJarModuleDataProvider cpw/mods/jarhandling/VirtualJar VirtualJarModuleDataProvider private
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 method public name ()Ljava/lang/String; - -
 method public descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public uri ()Ljava/net/URI; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
in 0
class cpw/mods/jarhandling/impl/Jar 60 public,super java/lang/Object cpw/mods/jarhandling/SecureJar -
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/impl/Jar$StatusData cpw/mods/jarhandling/impl/Jar StatusData private,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/Runtime$Version java/lang/Runtime Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getURI ()Ljava/net/URI; - -
 method public computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,varargs <init> (Ljava/util/function/Supplier;Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)V (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)V -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public,synchronized verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
 method public verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public hasSecurityData ()Z - -
 method public name ()Ljava/lang/String; - -
 method public getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getProviders ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getRootPath ()Ljava/nio/file/Path; - -
 method public toString ()Ljava/lang/String; - -
in 182
class cpw/mods/jarhandling/impl/Jar 60 public,super java/lang/Object cpw/mods/jarhandling/SecureJar -
 inner cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider cpw/mods/jarhandling/impl/Jar JarModuleDataProvider private,static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/impl/Jar$StatusData cpw/mods/jarhandling/impl/Jar StatusData private,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/Runtime$Version java/lang/Runtime Version public,static,final
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getURI ()Ljava/net/URI; - -
 method public computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public,varargs <init> (Ljava/util/function/Supplier;Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)V (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)V -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public,synchronized verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
 method public verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public hasSecurityData ()Z - -
 method public name ()Ljava/lang/String; - -
 method public getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getProviders ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getRootPath ()Ljava/nio/file/Path; - -
 method public toString ()Ljava/lang/String; - -
in 191
class cpw/mods/jarhandling/impl/Jar 60 public,super java/lang/Object cpw/mods/jarhandling/SecureJar -
 inner cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider cpw/mods/jarhandling/impl/Jar JarModuleDataProvider private,static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs,deprecated <init> (Ljava/util/function/Supplier;Ljava/util/function/Function;Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)V (Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/Function<Lcpw/mods/jarhandling/SecureJar;Lcpw/mods/jarhandling/JarMetadata;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)V -
 method public <init> (Lcpw/mods/jarhandling/impl/JarContentsImpl;Lcpw/mods/jarhandling/JarMetadata;)V - -
 method public getURI ()Ljava/net/URI; - -
 method public computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public hasSecurityData ()Z - -
 method public name ()Ljava/lang/String; - -
 method public getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getProviders ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getRootPath ()Ljava/nio/file/Path; - -
 method public toString ()Ljava/lang/String; - -
in 348
class cpw/mods/jarhandling/impl/Jar 65 public,super java/lang/Object cpw/mods/jarhandling/SecureJar -
 inner cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider cpw/mods/jarhandling/impl/Jar JarModuleDataProvider private,static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/jarhandling/impl/JarContentsImpl;Lcpw/mods/jarhandling/JarMetadata;)V - -
 method public getURI ()Ljava/net/URI; - -
 method public computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public moduleDataProvider ()Lcpw/mods/jarhandling/SecureJar$ModuleDataProvider; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public getManifestSigners ()[Ljava/security/CodeSigner; - -
 method public verifyPath (Ljava/nio/file/Path;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getFileStatus (Ljava/lang/String;)Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public getTrustedManifestEntries (Ljava/lang/String;)Ljava/util/jar/Attributes; - -
 method public hasSecurityData ()Z - -
 method public name ()Ljava/lang/String; - -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getRootPath ()Ljava/nio/file/Path; - -
 method public close ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 372
class cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider 60 final,super java/lang/Record cpw/mods/jarhandling/SecureJar$ModuleDataProvider -
 inner cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider cpw/mods/jarhandling/impl/Jar JarModuleDataProvider private,static,final
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public name ()Ljava/lang/String; - -
 method public descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public uri ()Ljava/net/URI; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public jar ()Lcpw/mods/jarhandling/impl/Jar; - -
in 377
class cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider 65 final,super java/lang/Record cpw/mods/jarhandling/SecureJar$ModuleDataProvider -
 inner cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider cpw/mods/jarhandling/impl/Jar JarModuleDataProvider private,static,final
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public name ()Ljava/lang/String; - -
 method public descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public uri ()Ljava/net/URI; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public jar ()Lcpw/mods/jarhandling/impl/Jar; - -
in 122
class cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider 65 final,super java/lang/Record cpw/mods/jarhandling/SecureJar$ModuleDataProvider -
 inner cpw/mods/jarhandling/impl/Jar$JarModuleDataProvider cpw/mods/jarhandling/impl/Jar JarModuleDataProvider private,static,final
 inner cpw/mods/jarhandling/SecureJar$ModuleDataProvider cpw/mods/jarhandling/SecureJar ModuleDataProvider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public name ()Ljava/lang/String; - -
 method public descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public uri ()Ljava/net/URI; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public open (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/io/InputStream;>; -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public verifyAndGetSigners (Ljava/lang/String;[B)[Ljava/security/CodeSigner; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public jar ()Lcpw/mods/jarhandling/impl/Jar; - -
in 53
class cpw/mods/jarhandling/impl/Jar$StatusData 60 final,super java/lang/Record - -
 inner cpw/mods/jarhandling/impl/Jar$StatusData cpw/mods/jarhandling/impl/Jar StatusData private,static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public status ()Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public signers ()[Ljava/security/CodeSigner; - -
in 191
class cpw/mods/jarhandling/impl/JarContentsImpl 60 public,super java/lang/Object cpw/mods/jarhandling/JarContents -
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/Runtime$Version java/lang/Runtime Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ([Ljava/nio/file/Path;Ljava/util/function/Supplier;Ljava/util/function/BiPredicate;)V ([Ljava/nio/file/Path;Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public,varargs getPackagesExcluding ([Ljava/lang/String;)Ljava/util/Set; ([Ljava/lang/String;)Ljava/util/Set<Ljava/lang/String;>; -
 method public getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getMetaInfServices ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
in 377
class cpw/mods/jarhandling/impl/JarContentsImpl 65 public,super java/lang/Object cpw/mods/jarhandling/JarContents -
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/Runtime$Version java/lang/Runtime Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ([Ljava/nio/file/Path;Ljava/util/function/Supplier;Lcpw/mods/niofs/union/UnionPathFilter;)V ([Ljava/nio/file/Path;Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Lcpw/mods/niofs/union/UnionPathFilter;)V -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public,varargs getPackagesExcluding ([Ljava/lang/String;)Ljava/util/Set; ([Ljava/lang/String;)Ljava/util/Set<Ljava/lang/String;>; -
 method public getPackages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getMetaInfServices ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
 method public close ()V - java/io/IOException
in 122
class cpw/mods/jarhandling/impl/JarContentsImpl 65 public,super java/lang/Object cpw/mods/jarhandling/JarContents -
 inner java/lang/Runtime$Version java/lang/Runtime Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ([Ljava/nio/file/Path;Ljava/util/function/Supplier;Lcpw/mods/niofs/union/UnionPathFilter;)V ([Ljava/nio/file/Path;Ljava/util/function/Supplier<Ljava/util/jar/Manifest;>;Lcpw/mods/niofs/union/UnionPathFilter;)V -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public findFile (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URI;>; -
 method public openFile (Ljava/lang/String;)Ljava/io/InputStream; - java/io/IOException
 method public getManifest ()Ljava/util/jar/Manifest; - -
 method public close ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 191
class cpw/mods/jarhandling/impl/JarSigningData 60 public,super java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/impl/JarSigningData$StatusData cpw/mods/jarhandling/impl/JarSigningData StatusData static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
in 348
class cpw/mods/jarhandling/impl/JarSigningData 65 public,super java/lang/Object - -
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner cpw/mods/jarhandling/impl/JarSigningData$StatusData cpw/mods/jarhandling/impl/JarSigningData StatusData static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
in 191
class cpw/mods/jarhandling/impl/JarSigningData$StatusData 60 final,super java/lang/Record - -
 inner cpw/mods/jarhandling/impl/JarSigningData$StatusData cpw/mods/jarhandling/impl/JarSigningData StatusData static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public status ()Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public signers ()[Ljava/security/CodeSigner; - -
in 348
class cpw/mods/jarhandling/impl/JarSigningData$StatusData 65 final,super java/lang/Record - -
 inner cpw/mods/jarhandling/impl/JarSigningData$StatusData cpw/mods/jarhandling/impl/JarSigningData StatusData static,final
 inner cpw/mods/jarhandling/SecureJar$Status cpw/mods/jarhandling/SecureJar Status public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public status ()Lcpw/mods/jarhandling/SecureJar$Status; - -
 method public signers ()[Ljava/security/CodeSigner; - -
in 122
class cpw/mods/jarhandling/impl/JlsConstants 65 final,super java/lang/Object - -
 method public,static isJavaIdentifier (Ljava/lang/String;)Z - -
 method public,static getPackageName (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static isTypeName (Ljava/lang/String;)Z - -
in 375
class cpw/mods/jarhandling/impl/ManifestVerifier 60 super java/lang/Object - -
 inner java/util/Base64$Decoder java/util/Base64 Decoder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 348
class cpw/mods/jarhandling/impl/ManifestVerifier 65 super java/lang/Object - -
 inner java/util/Base64$Decoder java/util/Base64 Decoder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 122
class cpw/mods/jarhandling/impl/ModuleDescriptorFactory 65 public,final,super java/lang/Object - -
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner org/jetbrains/annotations/ApiStatus$Internal org/jetbrains/annotations/ApiStatus Internal public,static,interface,abstract,annotation
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static,varargs scanAutomaticModule (Lcpw/mods/jarhandling/JarContents;Ljava/lang/module/ModuleDescriptor$Builder;[Ljava/lang/String;)V - -
 method public,static scanModulePackages (Lcpw/mods/jarhandling/JarContents;)Ljava/util/Set; (Lcpw/mods/jarhandling/JarContents;)Ljava/util/Set<Ljava/lang/String;>; -
in 53
class cpw/mods/jarhandling/impl/ModuleJarMetadata 60 public,super java/lang/Object cpw/mods/jarhandling/JarMetadata -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModuleClassVisitor private
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 method public <init> (Ljava/net/URI;Ljava/util/Set;)V (Ljava/net/URI;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
 method public descriptor ()Ljava/lang/module/ModuleDescriptor; - -
in 191
class cpw/mods/jarhandling/impl/ModuleJarMetadata 60 public,super cpw/mods/jarhandling/LazyJarMetadata - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModuleClassVisitor private,static
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private,static
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 method public <init> (Ljava/net/URI;Ljava/util/function/Supplier;)V (Ljava/net/URI;Ljava/util/function/Supplier<Ljava/util/Set<Ljava/lang/String;>;>;)V -
 method protected computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
in 377
class cpw/mods/jarhandling/impl/ModuleJarMetadata 65 public,super cpw/mods/jarhandling/LazyJarMetadata - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModuleClassVisitor private,static
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private,static
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 method public <init> (Ljava/net/URI;Ljava/util/function/Supplier;)V (Ljava/net/URI;Ljava/util/function/Supplier<Ljava/util/Set<Ljava/lang/String;>;>;)V -
 method protected computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
in 122
class cpw/mods/jarhandling/impl/ModuleJarMetadata 65 public,super cpw/mods/jarhandling/LazyJarMetadata - -
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner java/lang/module/ModuleDescriptor$Exports java/lang/module/ModuleDescriptor Exports public,static,final
 inner java/lang/module/ModuleDescriptor$Provides java/lang/module/ModuleDescriptor Provides public,static,final
 inner java/lang/module/ModuleDescriptor$Requires java/lang/module/ModuleDescriptor Requires public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/net/URI;Lcpw/mods/jarhandling/JarContents;)V - -
 method protected computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
in 53
class cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor 60 super org/objectweb/asm/ModuleVisitor - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner java/lang/module/ModuleDescriptor$Requires java/lang/module/ModuleDescriptor Requires public,static,final
 inner java/lang/module/ModuleDescriptor$Requires$Modifier java/lang/module/ModuleDescriptor$Requires Modifier public,static,final,enum
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/jarhandling/impl/ModuleJarMetadata;Ljava/lang/String;ILjava/lang/String;)V - -
 method public,varargs visitExport (Ljava/lang/String;I[Ljava/lang/String;)V - -
 method public visitMainClass (Ljava/lang/String;)V - -
 method public,varargs visitOpen (Ljava/lang/String;I[Ljava/lang/String;)V - -
 method public visitPackage (Ljava/lang/String;)V - -
 method public,varargs visitProvide (Ljava/lang/String;[Ljava/lang/String;)V - -
 method public visitRequire (Ljava/lang/String;ILjava/lang/String;)V - -
 method public visitUse (Ljava/lang/String;)V - -
 method public packages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
in 191
class cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor 60 super org/objectweb/asm/ModuleVisitor - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private,static
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner java/lang/module/ModuleDescriptor$Requires java/lang/module/ModuleDescriptor Requires public,static,final
 inner java/lang/module/ModuleDescriptor$Requires$Modifier java/lang/module/ModuleDescriptor$Requires Modifier public,static,final,enum
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;ILjava/lang/String;)V - -
 method public,varargs visitExport (Ljava/lang/String;I[Ljava/lang/String;)V - -
 method public visitMainClass (Ljava/lang/String;)V - -
 method public,varargs visitOpen (Ljava/lang/String;I[Ljava/lang/String;)V - -
 method public visitPackage (Ljava/lang/String;)V - -
 method public,varargs visitProvide (Ljava/lang/String;[Ljava/lang/String;)V - -
 method public visitRequire (Ljava/lang/String;ILjava/lang/String;)V - -
 method public visitUse (Ljava/lang/String;)V - -
 method public packages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
in 377
class cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor 65 super org/objectweb/asm/ModuleVisitor - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private,static
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner java/lang/module/ModuleDescriptor$Requires java/lang/module/ModuleDescriptor Requires public,static,final
 inner java/lang/module/ModuleDescriptor$Requires$Modifier java/lang/module/ModuleDescriptor$Requires Modifier public,static,final,enum
 inner java/lang/module/ModuleDescriptor$Version java/lang/module/ModuleDescriptor Version public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;ILjava/lang/String;)V - -
 method public,varargs visitExport (Ljava/lang/String;I[Ljava/lang/String;)V - -
 method public visitMainClass (Ljava/lang/String;)V - -
 method public,varargs visitOpen (Ljava/lang/String;I[Ljava/lang/String;)V - -
 method public visitPackage (Ljava/lang/String;)V - -
 method public,varargs visitProvide (Ljava/lang/String;[Ljava/lang/String;)V - -
 method public visitRequire (Ljava/lang/String;ILjava/lang/String;)V - -
 method public visitUse (Ljava/lang/String;)V - -
 method public packages ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
in 53
class cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor 60 super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModuleClassVisitor private
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private
 method public visitModule (Ljava/lang/String;ILjava/lang/String;)Lorg/objectweb/asm/ModuleVisitor; - -
 method public mfv ()Lcpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor; - -
in 191
class cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor 60 super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private,static
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModuleClassVisitor private,static
 method public visitModule (Ljava/lang/String;ILjava/lang/String;)Lorg/objectweb/asm/ModuleVisitor; - -
 method public mfv ()Lcpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor; - -
in 377
class cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor 65 super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModFileVisitor private,static
 inner cpw/mods/jarhandling/impl/ModuleJarMetadata$ModuleClassVisitor cpw/mods/jarhandling/impl/ModuleJarMetadata ModuleClassVisitor private,static
 method public visitModule (Ljava/lang/String;ILjava/lang/String;)Lorg/objectweb/asm/ModuleVisitor; - -
 method public mfv ()Lcpw/mods/jarhandling/impl/ModuleJarMetadata$ModFileVisitor; - -
in 375
class cpw/mods/jarhandling/impl/SecureJarVerifier 60 public,super java/lang/Object - -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$UnsafeAccessor cpw/mods/jarhandling/impl/SecureJarVerifier UnsafeAccessor private,static
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$Reflection cpw/mods/jarhandling/impl/SecureJarVerifier Reflection private,static
 method public <init> ()V - -
 method public,static toHexString ([B)Ljava/lang/String; - -
 method public,static isSigningRelated (Ljava/lang/String;)Z - -
 method public,static getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static isParsingMeta (Ljava/lang/Object;)Z - -
 method public,static hasSignatures (Ljava/lang/Object;)Z - -
 method public,static getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public,static getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 348
class cpw/mods/jarhandling/impl/SecureJarVerifier 65 public,super java/lang/Object - -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$UnsafeAccessor cpw/mods/jarhandling/impl/SecureJarVerifier UnsafeAccessor private,static
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$Reflection cpw/mods/jarhandling/impl/SecureJarVerifier Reflection private,static
 method public <init> ()V - -
 method public,static toHexString ([B)Ljava/lang/String; - -
 method public,static isSigningRelated (Ljava/lang/String;)Z - -
 method public,static getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static isParsingMeta (Ljava/lang/Object;)Z - -
 method public,static hasSignatures (Ljava/lang/Object;)Z - -
 method public,static getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public,static getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 375
class cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor 60 interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 method public,abstract getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,abstract isParsingMeta (Ljava/lang/Object;)Z - -
 method public,abstract hasSignatures (Ljava/lang/Object;)Z - -
 method public,abstract getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public,abstract getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 348
class cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor 65 interface,abstract java/lang/Object - -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 method public,abstract getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,abstract isParsingMeta (Ljava/lang/Object;)Z - -
 method public,abstract hasSignatures (Ljava/lang/Object;)Z - -
 method public,abstract getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public,abstract getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 375
class cpw/mods/jarhandling/impl/SecureJarVerifier$Reflection 60 super java/lang/Object cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$Reflection cpw/mods/jarhandling/impl/SecureJarVerifier Reflection private,static
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public isParsingMeta (Ljava/lang/Object;)Z - -
 method public hasSignatures (Ljava/lang/Object;)Z - -
 method public getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 348
class cpw/mods/jarhandling/impl/SecureJarVerifier$Reflection 65 super java/lang/Object cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$Reflection cpw/mods/jarhandling/impl/SecureJarVerifier Reflection private,static
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public isParsingMeta (Ljava/lang/Object;)Z - -
 method public hasSignatures (Ljava/lang/Object;)Z - -
 method public getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 375
class cpw/mods/jarhandling/impl/SecureJarVerifier$UnsafeAccessor 60 super java/lang/Object cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$UnsafeAccessor cpw/mods/jarhandling/impl/SecureJarVerifier UnsafeAccessor private,static
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public isParsingMeta (Ljava/lang/Object;)Z - -
 method public hasSignatures (Ljava/lang/Object;)Z - -
 method public getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 348
class cpw/mods/jarhandling/impl/SecureJarVerifier$UnsafeAccessor 65 super java/lang/Object cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor -
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$UnsafeAccessor cpw/mods/jarhandling/impl/SecureJarVerifier UnsafeAccessor private,static
 inner cpw/mods/jarhandling/impl/SecureJarVerifier$IAccessor cpw/mods/jarhandling/impl/SecureJarVerifier IAccessor private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getJarVerifier (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public isParsingMeta (Ljava/lang/Object;)Z - -
 method public hasSignatures (Ljava/lang/Object;)Z - -
 method public getVerifiedSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
 method public getPendingSigners (Ljava/lang/Object;)Ljava/util/Map; (Ljava/lang/Object;)Ljava/util/Map<Ljava/lang/String;[Ljava/security/CodeSigner;>; -
in 53
class cpw/mods/jarhandling/impl/SimpleJarMetadata 60 public,final,super java/lang/Record cpw/mods/jarhandling/JarMetadata -
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>;)V -
 method public descriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
 method public pkgs ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public providers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
in 191
class cpw/mods/jarhandling/impl/SimpleJarMetadata 60 public,super cpw/mods/jarhandling/LazyJarMetadata cpw/mods/jarhandling/JarMetadata -
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Supplier<Ljava/util/Set<Ljava/lang/String;>;>;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>;)V -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
 method public computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public providers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
in 377
class cpw/mods/jarhandling/impl/SimpleJarMetadata 65 public,super cpw/mods/jarhandling/LazyJarMetadata cpw/mods/jarhandling/JarMetadata -
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 inner cpw/mods/jarhandling/SecureJar$Provider cpw/mods/jarhandling/SecureJar Provider public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/util/function/Supplier<Ljava/util/Set<Ljava/lang/String;>;>;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>;)V -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
 method public computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
 method public providers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar$Provider;>; -
in 122
class cpw/mods/jarhandling/impl/SimpleJarMetadata 65 public,super cpw/mods/jarhandling/LazyJarMetadata cpw/mods/jarhandling/JarMetadata -
 inner java/lang/module/ModuleDescriptor$Builder java/lang/module/ModuleDescriptor Builder public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lcpw/mods/jarhandling/JarContents;)V - -
 method public name ()Ljava/lang/String; - -
 method public version ()Ljava/lang/String; - -
 method public computeDescriptor ()Ljava/lang/module/ModuleDescriptor; - -
in 378
class cpw/mods/modlauncher/ArgumentHandler 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public buildArgumentList ()[Ljava/lang/String; - -
in 376
class cpw/mods/modlauncher/ArgumentHandler 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public buildArgumentList ()[Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/ArgumentHandler 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public buildArgumentList ()[Ljava/lang/String; - -
in 0
class cpw/mods/modlauncher/ArgumentHandler$DiscoveryData 60 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public gameDir ()Ljava/nio/file/Path; - -
 method public launchTarget ()Ljava/lang/String; - -
in 379
class cpw/mods/modlauncher/ArgumentHandler$DiscoveryData 60 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public gameDir ()Ljava/nio/file/Path; - -
 method public launchTarget ()Ljava/lang/String; - -
 method public arguments ()[Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/ArgumentHandler$DiscoveryData 65 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public gameDir ()Ljava/nio/file/Path; - -
 method public launchTarget ()Ljava/lang/String; - -
 method public arguments ()[Ljava/lang/String; - -
in 380
class cpw/mods/modlauncher/BootstrapEntry 60 public,super java/lang/Object net/minecraftforge/bootstrap/api/BootstrapEntryPoint -
 method public <init> ()V - -
 method public,varargs main ([Ljava/lang/String;)V - -
in 381
class cpw/mods/modlauncher/BootstrapLaunchConsumer 60 public,super java/lang/Object java/util/function/Consumer Ljava/lang/Object;Ljava/util/function/Consumer<[Ljava/lang/String;>;
 method public <init> ()V - -
 method public accept ([Ljava/lang/String;)V - -
in 380
class cpw/mods/modlauncher/BootstrapLaunchConsumer 60 public,super,deprecated java/lang/Object java/util/function/Consumer Ljava/lang/Object;Ljava/util/function/Consumer<[Ljava/lang/String;>;
 method public <init> ()V - -
 method public accept ([Ljava/lang/String;)V - -
in 373
class cpw/mods/modlauncher/BootstrapLaunchConsumer 65 public,super java/lang/Object java/util/function/Consumer Ljava/lang/Object;Ljava/util/function/Consumer<[Ljava/lang/String;>;
 method public <init> ()V - -
 method public accept ([Ljava/lang/String;)V - -
in 378
class cpw/mods/modlauncher/ClassTransformer 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 382
class cpw/mods/modlauncher/ClassTransformer 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 190
class cpw/mods/modlauncher/ClassTransformer 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 348
class cpw/mods/modlauncher/ClassTransformer 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 0
class cpw/mods/modlauncher/DefaultLaunchHandlerService 60 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LAUNCH_PROPERTY Ljava/lang/String; - "minecraft.client.jar"
 field public,static,final LAUNCH_PATH_STRING Ljava/lang/String; -
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 383
class cpw/mods/modlauncher/DefaultLaunchHandlerService 60 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LAUNCH_PROPERTY Ljava/lang/String; - "minecraft.client.jar"
 field public,static,final LAUNCH_PATH_STRING Ljava/lang/String; -
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 384
class cpw/mods/modlauncher/DefaultLaunchHandlerService 52 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LAUNCH_PROPERTY Ljava/lang/String; - "minecraft.client.jar"
 field public,static,final LAUNCH_PATH_STRING Ljava/lang/String; -
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
in 385
class cpw/mods/modlauncher/DefaultLaunchHandlerService 52 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LAUNCH_PROPERTY Ljava/lang/String; - "minecraft.client.jar"
 field public,static,final LAUNCH_PATH_STRING Ljava/lang/String; -
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
 method public getPaths ()[Ljava/nio/file/Path; - -
in 380
class cpw/mods/modlauncher/DefaultLaunchHandlerService 60 public,super,deprecated java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LAUNCH_PROPERTY Ljava/lang/String; - "minecraft.client.jar"
 field public,static,final LAUNCH_PATH_STRING Ljava/lang/String; -
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 348
class cpw/mods/modlauncher/DefaultLaunchHandlerService 65 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LAUNCH_PROPERTY Ljava/lang/String; - "minecraft.client.jar"
 field public,static,final LAUNCH_PATH_STRING Ljava/lang/String; -
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 378
class cpw/mods/modlauncher/EnumerationHelper 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static merge (Ljava/util/Enumeration;Ljava/util/Enumeration;)Ljava/util/Enumeration; <T:Ljava/lang/Object;>(Ljava/util/Enumeration<TT;>;Ljava/util/Enumeration<TT;>;)Ljava/util/Enumeration<TT;>; -
 method public,static mergeFunctors (Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>;Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>;)Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>; -
 method public,static firstElementOrNull (Ljava/util/Enumeration;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Enumeration<TT;>;)TT; -
 method public,static fromOptional (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<TT;>;>;)Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>; -
in 190
class cpw/mods/modlauncher/EnumerationHelper 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static merge (Ljava/util/Enumeration;Ljava/util/Enumeration;)Ljava/util/Enumeration; <T:Ljava/lang/Object;>(Ljava/util/Enumeration<TT;>;Ljava/util/Enumeration<TT;>;)Ljava/util/Enumeration<TT;>; -
 method public,static mergeFunctors (Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>;Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>;)Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>; -
 method public,static firstElementOrNull (Ljava/util/Enumeration;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Enumeration<TT;>;)TT; -
 method public,static fromOptional (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<TT;>;>;)Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>; -
in 348
class cpw/mods/modlauncher/EnumerationHelper 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static merge (Ljava/util/Enumeration;Ljava/util/Enumeration;)Ljava/util/Enumeration; <T:Ljava/lang/Object;>(Ljava/util/Enumeration<TT;>;Ljava/util/Enumeration<TT;>;)Ljava/util/Enumeration<TT;>; -
 method public,static mergeFunctors (Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>;Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>;)Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>; -
 method public,static firstElementOrNull (Ljava/util/Enumeration;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Enumeration<TT;>;)TT; -
 method public,static fromOptional (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<TT;>;>;)Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<TT;>;>; -
in 386
class cpw/mods/modlauncher/Environment 60 public,final,super java/lang/Object cpw/mods/modlauncher/api/IEnvironment -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 method public,final getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public findModuleLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
 method public findNameMapping (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
in 376
class cpw/mods/modlauncher/Environment 52 public,final,super java/lang/Object cpw/mods/modlauncher/api/IEnvironment -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 method public,final getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public findNameMapping (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
in 387
class cpw/mods/modlauncher/Environment 60 public,final,super java/lang/Object cpw/mods/modlauncher/api/IEnvironment -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 method public,final getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public findModuleLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
 method public findNameMapping (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
 method public putPropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;TT;)TT; -
in 348
class cpw/mods/modlauncher/Environment 65 public,final,super java/lang/Object cpw/mods/modlauncher/api/IEnvironment -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 method public,final getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public findModuleLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
 method public computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
in 378
class cpw/mods/modlauncher/InvalidLauncherSetupException 60 public,super java/lang/IllegalStateException - -
in 376
class cpw/mods/modlauncher/InvalidLauncherSetupException 52 public,super java/lang/IllegalStateException - -
in 348
class cpw/mods/modlauncher/InvalidLauncherSetupException 65 public,super java/lang/IllegalStateException - -
in 381
class cpw/mods/modlauncher/LaunchPluginHandler 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public computeLaunchPluginTransformerSet (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap; (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Ljava/util/List<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;>; -
in 384
class cpw/mods/modlauncher/LaunchPluginHandler 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public computeLaunchPluginTransformerSet (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumMap; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumMap<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Ljava/util/List<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;>; -
in 188
class cpw/mods/modlauncher/LaunchPluginHandler 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public computeLaunchPluginTransformerSet (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumMap; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumMap<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Ljava/util/List<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;>; -
in 215
class cpw/mods/modlauncher/LaunchPluginHandler 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public computeLaunchPluginTransformerSet (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap; (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Ljava/util/List<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;>; -
in 380
class cpw/mods/modlauncher/LaunchPluginHandler 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public computeLaunchPluginTransformerSet (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap; (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Ljava/util/List<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;>; -
in 192
class cpw/mods/modlauncher/LaunchPluginHandler 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public computeLaunchPluginTransformerSet (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap; (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Ljava/util/List<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;>; -
in 388
class cpw/mods/modlauncher/LaunchPluginHandler 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public <init> (Ljava/util/stream/Stream;)V (Ljava/util/stream/Stream<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;)V -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public computeLaunchPluginTransformerSet (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap; (Lorg/objectweb/asm/Type;ZLjava/lang/String;Lcpw/mods/modlauncher/TransformerAuditTrail;)Ljava/util/EnumMap<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Ljava/util/List<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>;>; -
in 386
class cpw/mods/modlauncher/LaunchServiceHandler 60 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public launch (Lcpw/mods/modlauncher/ArgumentHandler;Ljava/lang/ModuleLayer;Lcpw/mods/modlauncher/TransformingClassLoader;Lcpw/mods/modlauncher/LaunchPluginHandler;)V - -
in 384
class cpw/mods/modlauncher/LaunchServiceHandler 52 super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public launch (Lcpw/mods/modlauncher/ArgumentHandler;Lcpw/mods/modlauncher/TransformingClassLoader;)V - -
in 385
class cpw/mods/modlauncher/LaunchServiceHandler 52 super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public launch (Lcpw/mods/modlauncher/ArgumentHandler;Lcpw/mods/modlauncher/TransformingClassLoader;Lcpw/mods/modlauncher/LaunchPluginHandler;)V - -
in 389
class cpw/mods/modlauncher/LaunchServiceHandler 60 final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public launch (Lcpw/mods/modlauncher/ArgumentHandler;Ljava/lang/ModuleLayer;Lcpw/mods/modlauncher/TransformingClassLoader;Lcpw/mods/modlauncher/LaunchPluginHandler;)V - -
in 390
class cpw/mods/modlauncher/LaunchServiceHandler 60 final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;Z)V - -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public launch (Lcpw/mods/modlauncher/ArgumentHandler;Ljava/lang/ModuleLayer;Lcpw/mods/modlauncher/TransformingClassLoader;Lcpw/mods/modlauncher/LaunchPluginHandler;)V - -
in 348
class cpw/mods/modlauncher/LaunchServiceHandler 65 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public launch (Lcpw/mods/modlauncher/ArgumentHandler;Ljava/lang/ModuleLayer;Lcpw/mods/modlauncher/TransformingClassLoader;Lcpw/mods/modlauncher/LaunchPluginHandler;)V - -
in 0
class cpw/mods/modlauncher/LaunchServiceHandlerDecorator 60 super java/lang/Object - -
 method public <init> (Lcpw/mods/modlauncher/api/ILaunchHandlerService;)V - -
 method public launch ([Ljava/lang/String;Ljava/lang/ModuleLayer;)V - -
 method public configureTransformationClassLoaderBuilder (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
in 383
class cpw/mods/modlauncher/LaunchServiceHandlerDecorator 60 final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public launch ([Ljava/lang/String;Ljava/lang/ModuleLayer;)V - -
 method public configureTransformationClassLoaderBuilder (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public service ()Lcpw/mods/modlauncher/api/ILaunchHandlerService; - -
in 376
class cpw/mods/modlauncher/LaunchServiceHandlerDecorator 52 super java/lang/Object - -
 method public <init> (Lcpw/mods/modlauncher/api/ILaunchHandlerService;)V - -
 method public launch ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)V - -
 method public configureTransformationClassLoaderBuilder (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
in 348
class cpw/mods/modlauncher/LaunchServiceHandlerDecorator 65 final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public launch ([Ljava/lang/String;Ljava/lang/ModuleLayer;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public service ()Lcpw/mods/modlauncher/api/ILaunchHandlerService; - -
in 381
class cpw/mods/modlauncher/Launcher 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static INSTANCE Lcpw/mods/modlauncher/Launcher; -
 method public,static,varargs main ([Ljava/lang/String;)V - -
 method public,final blackboard ()Lcpw/mods/modlauncher/api/TypesafeMap; - -
 method public environment ()Lcpw/mods/modlauncher/Environment; - -
 method public findLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
in 135
class cpw/mods/modlauncher/Launcher 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static INSTANCE Lcpw/mods/modlauncher/Launcher; -
 method public,static,varargs main ([Ljava/lang/String;)V - -
 method public,final blackboard ()Lcpw/mods/modlauncher/api/TypesafeMap; - -
 method public environment ()Lcpw/mods/modlauncher/Environment; - -
in 391
class cpw/mods/modlauncher/Launcher 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static INSTANCE Lcpw/mods/modlauncher/Launcher; -
 method public,static,varargs main ([Ljava/lang/String;)V - -
 method public,final blackboard ()Lcpw/mods/modlauncher/api/TypesafeMap; - -
 method public environment ()Lcpw/mods/modlauncher/Environment; - -
in 385
class cpw/mods/modlauncher/Launcher 52 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static INSTANCE Lcpw/mods/modlauncher/Launcher; -
 method public,static,varargs main ([Ljava/lang/String;)V - -
 method public,final blackboard ()Lcpw/mods/modlauncher/api/TypesafeMap; - -
 method public environment ()Lcpw/mods/modlauncher/Environment; - -
in 392
class cpw/mods/modlauncher/Launcher 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static INSTANCE Lcpw/mods/modlauncher/Launcher; -
 method public,static,varargs main ([Ljava/lang/String;)V - -
 method public,final blackboard ()Lcpw/mods/modlauncher/api/TypesafeMap; - -
 method public environment ()Lcpw/mods/modlauncher/Environment; - -
 method public findLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
in 390
class cpw/mods/modlauncher/Launcher 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/Launcher$VersionInfo cpw/mods/modlauncher/Launcher VersionInfo private,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static INSTANCE Lcpw/mods/modlauncher/Launcher; -
 method public,static,varargs main ([Ljava/lang/String;)V - -
 method public,final blackboard ()Lcpw/mods/modlauncher/api/TypesafeMap; - -
 method public environment ()Lcpw/mods/modlauncher/Environment; - -
 method public findLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
in 348
class cpw/mods/modlauncher/Launcher 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static INSTANCE Lcpw/mods/modlauncher/Launcher; -
 method public,static,varargs main ([Ljava/lang/String;)V - -
 method public,final blackboard ()Lcpw/mods/modlauncher/api/TypesafeMap; - -
 method public environment ()Lcpw/mods/modlauncher/Environment; - -
 method public findLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
in 390
class cpw/mods/modlauncher/Launcher$VersionInfo 60 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/Launcher$VersionInfo cpw/mods/modlauncher/Launcher VersionInfo private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public implementation ()Ljava/lang/String; - -
 method public specification ()Ljava/lang/String; - -
in 386
class cpw/mods/modlauncher/LogMarkers 60 super java/lang/Object - -
in 376
class cpw/mods/modlauncher/LogMarkers 52 super java/lang/Object - -
in 387
class cpw/mods/modlauncher/LogMarkers 60 final,super java/lang/Object - -
in 348
class cpw/mods/modlauncher/LogMarkers 65 super java/lang/Object - -
in 381
class cpw/mods/modlauncher/ModuleLayerHandler 60 public,final,super java/lang/Object cpw/mods/modlauncher/api/IModuleLayerManager -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/ModuleLayerHandler$PathOrJar cpw/mods/modlauncher/ModuleLayerHandler PathOrJar private,static,final
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public buildLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/BiFunction;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/BiFunction<Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;Lcpw/mods/cl/ModuleClassLoader;>;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; -
 method public buildLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; - -
 method public getLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional<Ljava/lang/ModuleLayer;>; -
 method public updateLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/Consumer;)V (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/Consumer<Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo;>;)V -
in 380
class cpw/mods/modlauncher/ModuleLayerHandler 60 public,final,super java/lang/Object cpw/mods/modlauncher/api/IModuleLayerManager -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/ModuleLayerHandler$ClassLoaderFactory cpw/mods/modlauncher/ModuleLayerHandler ClassLoaderFactory static,interface,abstract
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional<Ljava/lang/ModuleLayer;>; -
 method public,deprecated buildLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/BiFunction;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/BiFunction<Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;Ljava/lang/ClassLoader;>;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; -
 method public,deprecated buildLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; - -
 method public,deprecated updateLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/Consumer;)V (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/Consumer<Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo;>;)V -
in 348
class cpw/mods/modlauncher/ModuleLayerHandler 65 public,final,super java/lang/Object cpw/mods/modlauncher/api/IModuleLayerManager -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/ModuleLayerHandler$PathOrJar cpw/mods/modlauncher/ModuleLayerHandler PathOrJar private,static,final
 inner java/lang/ModuleLayer$Controller java/lang/ModuleLayer Controller public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public buildLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/BiFunction;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/BiFunction<Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;Lcpw/mods/cl/ModuleClassLoader;>;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; -
 method public buildLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo; - -
 method public getLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional<Ljava/lang/ModuleLayer;>; -
 method public updateLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/Consumer;)V (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/function/Consumer<Lcpw/mods/modlauncher/ModuleLayerHandler$LayerInfo;>;)V -
in 380
class cpw/mods/modlauncher/ModuleLayerHandler$ClassLoaderFactory 60 interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/ModuleLayerHandler$ClassLoaderFactory cpw/mods/modlauncher/ModuleLayerHandler ClassLoaderFactory static,interface,abstract
 method public,abstract create (Ljava/lang/module/Configuration;Ljava/util/List;Ljava/util/List;)Ljava/lang/ClassLoader; (Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;Ljava/util/List<Ljava/lang/ClassLoader;>;)Ljava/lang/ClassLoader; -
in 381
class cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo 60 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public layer ()Ljava/lang/ModuleLayer; - -
 method public cl ()Lcpw/mods/cl/ModuleClassLoader; - -
in 380
class cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo 60 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public layer ()Ljava/lang/ModuleLayer; - -
 method public cl ()Ljava/lang/ClassLoader; - -
in 348
class cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo 65 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public layer ()Ljava/lang/ModuleLayer; - -
 method public cl ()Lcpw/mods/cl/ModuleClassLoader; - -
in 381
class cpw/mods/modlauncher/ModuleLayerHandler$PathOrJar 60 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ModuleLayerHandler$PathOrJar cpw/mods/modlauncher/ModuleLayerHandler PathOrJar private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public path ()Lcpw/mods/modlauncher/api/NamedPath; - -
 method public jar ()Lcpw/mods/jarhandling/SecureJar; - -
in 348
class cpw/mods/modlauncher/ModuleLayerHandler$PathOrJar 65 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/ModuleLayerHandler$PathOrJar cpw/mods/modlauncher/ModuleLayerHandler PathOrJar private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public path ()Lcpw/mods/modlauncher/api/NamedPath; - -
 method public jar ()Lcpw/mods/jarhandling/SecureJar; - -
in 381
class cpw/mods/modlauncher/NameMappingServiceDecorator 60 super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/api/INameMappingService;)V - -
 method public validTarget (Ljava/lang/String;)Z - -
 method public understands ()Ljava/lang/String; - -
 method public function ()Ljava/util/function/BiFunction; ()Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>; -
 method public toString ()Ljava/lang/String; - -
in 376
class cpw/mods/modlauncher/NameMappingServiceDecorator 52 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Lcpw/mods/modlauncher/api/INameMappingService;)V - -
 method public validTarget (Ljava/lang/String;)Z - -
 method public understands ()Ljava/lang/String; - -
 method public function ()Ljava/util/function/BiFunction; ()Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>; -
 method public toString ()Ljava/lang/String; - -
in 381
class cpw/mods/modlauncher/NameMappingServiceHandler 60 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public findNameTranslator (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public bindNamingServices (Ljava/lang/String;)V - -
in 376
class cpw/mods/modlauncher/NameMappingServiceHandler 52 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public findNameTranslator (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public bindNamingServices (Ljava/lang/String;)V - -
in 393
class cpw/mods/modlauncher/NameMappingServiceHandler 60 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public findNameTranslator (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public bindNamingServices (Ljava/lang/String;)V - -
in 387
class cpw/mods/modlauncher/NameMappingServiceHandler 60 final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method public findNameTranslator (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public bindNamingServices (Ljava/lang/String;)V - -
in 386
class cpw/mods/modlauncher/PredicateVisitor 60 public,super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 method public visitField (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lorg/objectweb/asm/FieldVisitor; - -
 method public visitMethod (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lorg/objectweb/asm/MethodVisitor; - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 394
class cpw/mods/modlauncher/PredicateVisitor 52 public,super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 method public visitField (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lorg/objectweb/asm/FieldVisitor; - -
 method public visitMethod (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lorg/objectweb/asm/MethodVisitor; - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 387
class cpw/mods/modlauncher/PredicateVisitor 60 public,super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 method public visitField (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lorg/objectweb/asm/FieldVisitor; - -
 method public visitMethod (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lorg/objectweb/asm/MethodVisitor; - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 348
class cpw/mods/modlauncher/PredicateVisitor 65 public,super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 method public visitField (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lorg/objectweb/asm/FieldVisitor; - -
 method public visitMethod (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lorg/objectweb/asm/MethodVisitor; - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 378
class cpw/mods/modlauncher/ProtectionDomainHelper 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static createCodeSource (Ljava/net/URL;[Ljava/security/CodeSigner;)Ljava/security/CodeSource; - -
 method public,static createProtectionDomain (Ljava/security/CodeSource;Ljava/lang/ClassLoader;)Ljava/security/ProtectionDomain; - -
 method public,static canHandleSecuredJars ()Z - -
in 190
class cpw/mods/modlauncher/SecureJarHandler 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static createCodeSource (Ljava/lang/String;Ljava/net/URL;[BLjava/util/jar/Manifest;)Ljava/security/CodeSource; - -
 method public,static createProtectionDomain (Ljava/security/CodeSource;Ljava/lang/ClassLoader;)Ljava/security/ProtectionDomain; - -
 method public,static canHandleSecuredJars ()Z - -
in 376
class cpw/mods/modlauncher/ServiceLoaderStreamUtils 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static parallelForEach (Ljava/util/ServiceLoader;Ljava/util/function/Consumer;)V <T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Consumer<TT;>;)V -
 method public,static forEach (Ljava/util/ServiceLoader;Ljava/util/function/Consumer;)V <T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Consumer<TT;>;)V -
 method public,static map (Ljava/util/ServiceLoader;Ljava/util/function/Function;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Function<TT;TU;>;)Ljava/util/stream/Stream<TU;>; -
 method public,static toList (Ljava/util/ServiceLoader;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;)Ljava/util/List<TT;>; -
 method public,static toMap (Ljava/util/ServiceLoader;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Function<TT;TK;>;)Ljava/util/Map<TK;TT;>; -
 method public,static toMap (Ljava/util/ServiceLoader;Ljava/util/function/Function;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Function<TT;TK;>;Ljava/util/function/Function<TT;TV;>;)Ljava/util/Map<TK;TV;>; -
 method public,static errorHandlingServiceLoader (Ljava/lang/Class;Ljava/util/function/Consumer;)Ljava/util/ServiceLoader; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/ServiceLoader<TT;>; -
 method public,static errorHandlingServiceLoader (Ljava/lang/Class;Ljava/lang/ClassLoader;Ljava/util/function/Consumer;)Ljava/util/ServiceLoader; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;Ljava/lang/ClassLoader;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/ServiceLoader<TT;>; -
in 0
class cpw/mods/modlauncher/TestingLaunchHandlerService 60 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
in 383
class cpw/mods/modlauncher/TestingLaunchHandlerService 60 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
in 376
class cpw/mods/modlauncher/TestingLaunchHandlerService 52 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public launchService ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
in 392
class cpw/mods/modlauncher/TestingLaunchHandlerService 60 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
in 390
class cpw/mods/modlauncher/TestingLaunchHandlerService 60 public,super,deprecated java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
in 348
class cpw/mods/modlauncher/TestingLaunchHandlerService 65 public,super java/lang/Object cpw/mods/modlauncher/api/ILaunchHandlerService -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
in 378
class cpw/mods/modlauncher/TransformList 60 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 376
class cpw/mods/modlauncher/TransformList 52 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 348
class cpw/mods/modlauncher/TransformList 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 378
class cpw/mods/modlauncher/TransformStore 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
in 376
class cpw/mods/modlauncher/TransformStore 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
in 348
class cpw/mods/modlauncher/TransformStore 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
in 386
class cpw/mods/modlauncher/TransformTargetLabel 60 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;)V - -
 method public,final getElementName ()Ljava/lang/String; - -
 method public,final getElementDescriptor ()Lorg/objectweb/asm/Type; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 382
class cpw/mods/modlauncher/TransformTargetLabel 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,final getElementName ()Ljava/lang/String; - -
 method public,final getElementDescriptor ()Lorg/objectweb/asm/Type; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 190
class cpw/mods/modlauncher/TransformTargetLabel 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;)V - -
 method public,final getElementName ()Ljava/lang/String; - -
 method public,final getElementDescriptor ()Lorg/objectweb/asm/Type; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 387
class cpw/mods/modlauncher/TransformTargetLabel 60 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;)V - -
 method public getElementName ()Ljava/lang/String; - -
 method public getElementDescriptor ()Lorg/objectweb/asm/Type; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/TransformTargetLabel 65 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lcpw/mods/modlauncher/api/TargetType;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/TargetType<Lorg/objectweb/asm/tree/ClassNode;>;)V -
 method public,final getElementName ()Ljava/lang/String; - -
 method public,final getElementDescriptor ()Lorg/objectweb/asm/Type; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 381
class cpw/mods/modlauncher/TransformTargetLabel$LabelType 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>;
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum PRE_CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 method public,static values ()[Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static getTypeFor (Ljava/lang/reflect/Type;)Ljava/util/List; (Ljava/lang/reflect/Type;)Ljava/util/List<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>; -
 method public getNodeType ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
 method public getFromMap (Ljava/util/EnumMap;)Lcpw/mods/modlauncher/TransformList; <V:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Lcpw/mods/modlauncher/TransformList<TV;>; -
 method public mapSupplier (Ljava/util/EnumMap;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/TransformList<TT;>;>; -
in 382
class cpw/mods/modlauncher/TransformTargetLabel$LabelType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>;
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 method public,static values ()[Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static getTypeFor (Ljava/lang/reflect/Type;)Ljava/util/Optional; (Ljava/lang/reflect/Type;)Ljava/util/Optional<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>; -
 method public getNodeType ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
 method public getFromMap (Ljava/util/EnumMap;)Lcpw/mods/modlauncher/TransformList; <V:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Lcpw/mods/modlauncher/TransformList<TV;>; -
 method public mapSupplier (Ljava/util/EnumMap;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/TransformList<TT;>;>; -
in 190
class cpw/mods/modlauncher/TransformTargetLabel$LabelType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>;
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum PRE_CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 method public,static values ()[Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static getTypeFor (Ljava/lang/reflect/Type;)Ljava/util/List; (Ljava/lang/reflect/Type;)Ljava/util/List<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>; -
 method public getNodeType ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
 method public getFromMap (Ljava/util/EnumMap;)Lcpw/mods/modlauncher/TransformList; <V:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Lcpw/mods/modlauncher/TransformList<TV;>; -
 method public mapSupplier (Ljava/util/EnumMap;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/TransformList<TT;>;>; -
in 393
class cpw/mods/modlauncher/TransformTargetLabel$LabelType 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>;
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum PRE_CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 method public,static values ()[Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public getNodeType ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
 method public getFromMap (Ljava/util/EnumMap;)Lcpw/mods/modlauncher/TransformList; <V:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Lcpw/mods/modlauncher/TransformList<TV;>; -
 method public mapSupplier (Ljava/util/EnumMap;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/TransformList<TT;>;>; -
in 387
class cpw/mods/modlauncher/TransformTargetLabel$LabelType 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>;
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 field public,static,final,enum PRE_CLASS Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; -
 method public,static values ()[Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/TransformTargetLabel$LabelType; - -
 method public getNodeType ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
 method public getFromMap (Ljava/util/EnumMap;)Lcpw/mods/modlauncher/TransformList; <V:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Lcpw/mods/modlauncher/TransformList<TV;>; -
 method public mapSupplier (Ljava/util/EnumMap;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/EnumMap<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;Lcpw/mods/modlauncher/TransformList<*>;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/TransformList<TT;>;>; -
 method public,static,deprecated getTypeFor (Ljava/lang/reflect/Type;)Ljava/util/List; (Ljava/lang/reflect/Type;)Ljava/util/List<Lcpw/mods/modlauncher/TransformTargetLabel$LabelType;>; -
in 381
class cpw/mods/modlauncher/TransformationServiceDecorator 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public gatherTransformers (Lcpw/mods/modlauncher/TransformStore;)V - -
 method public onCompleteScan (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 135
class cpw/mods/modlauncher/TransformationServiceDecorator 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public gatherTransformers (Lcpw/mods/modlauncher/TransformStore;)V - -
in 395
class cpw/mods/modlauncher/TransformationServiceDecorator 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public gatherTransformers (Lcpw/mods/modlauncher/TransformStore;)V - -
in 190
class cpw/mods/modlauncher/TransformationServiceDecorator 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public gatherTransformers (Lcpw/mods/modlauncher/TransformStore;)V - -
in 380
class cpw/mods/modlauncher/TransformationServiceDecorator 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/TransformTargetLabel$LabelType cpw/mods/modlauncher/TransformTargetLabel LabelType public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public gatherTransformers (Lcpw/mods/modlauncher/TransformStore;)V - -
 method public onCompleteScan (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 192
class cpw/mods/modlauncher/TransformationServiceDecorator 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public gatherTransformers (Lcpw/mods/modlauncher/TransformStore;)V - -
 method public onCompleteScan (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 388
class cpw/mods/modlauncher/TransformationServiceDecorator 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/api/ITransformationService;)V - -
 method public gatherTransformers (Lcpw/mods/modlauncher/TransformStore;)V - -
 method public onCompleteScan (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 381
class cpw/mods/modlauncher/TransformationServicesHandler 60 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public triggerScanCompletion (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 384
class cpw/mods/modlauncher/TransformationServicesHandler 52 super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformationServicesHandler$TransformerClassLoader cpw/mods/modlauncher/TransformationServicesHandler TransformerClassLoader private,static
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 385
class cpw/mods/modlauncher/TransformationServicesHandler 52 super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformationServicesHandler$TransformerClassLoader cpw/mods/modlauncher/TransformationServicesHandler TransformerClassLoader private,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 393
class cpw/mods/modlauncher/TransformationServicesHandler 60 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$ClassLoaderFactory cpw/mods/modlauncher/ModuleLayerHandler ClassLoaderFactory static,interface,abstract
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public triggerScanCompletion (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 387
class cpw/mods/modlauncher/TransformationServicesHandler 60 final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$ClassLoaderFactory cpw/mods/modlauncher/ModuleLayerHandler ClassLoaderFactory static,interface,abstract
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public triggerScanCompletion (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 348
class cpw/mods/modlauncher/TransformationServicesHandler 65 super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/ModuleLayerHandler$LayerInfo cpw/mods/modlauncher/ModuleLayerHandler LayerInfo static,final
 inner cpw/mods/modlauncher/ArgumentHandler$DiscoveryData cpw/mods/modlauncher/ArgumentHandler DiscoveryData static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public triggerScanCompletion (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
in 376
class cpw/mods/modlauncher/TransformationServicesHandler$TransformerClassLoader 52 super java/net/URLClassLoader - -
 inner cpw/mods/modlauncher/TransformationServicesHandler$TransformerClassLoader cpw/mods/modlauncher/TransformationServicesHandler TransformerClassLoader private,static
 method protected addURL (Ljava/net/URL;)V - -
in 386
class cpw/mods/modlauncher/TransformerAuditTrail 60 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerAuditTrail -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public addReason (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,varargs addPluginCustomAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;[Ljava/lang/String;)V - -
 method public addPluginAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;)V - -
 method public addTransformerAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer<*>;)V -
 method public getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 135
class cpw/mods/modlauncher/TransformerAuditTrail 52 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerAuditTrail -
 inner cpw/mods/modlauncher/TransformerAuditTrail$Type cpw/mods/modlauncher/TransformerAuditTrail Type static,final,enum
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public addPluginAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;)V - -
 method public addTransformerAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer<*>;)V -
 method public getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 391
class cpw/mods/modlauncher/TransformerAuditTrail 52 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerAuditTrail -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public addPluginAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;)V - -
 method public addTransformerAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer<*>;)V -
 method public getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 188
class cpw/mods/modlauncher/TransformerAuditTrail 52 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerAuditTrail -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public addReason (Ljava/lang/String;Ljava/lang/String;)V - -
 method public addPluginAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;)V - -
 method public addTransformerAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer<*>;)V -
 method public getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 215
class cpw/mods/modlauncher/TransformerAuditTrail 52 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerAuditTrail -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public addReason (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,varargs addPluginCustomAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;[Ljava/lang/String;)V - -
 method public addPluginAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;)V - -
 method public addTransformerAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer<*>;)V -
 method public getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 387
class cpw/mods/modlauncher/TransformerAuditTrail 60 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerAuditTrail -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static,final
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public addReason (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,varargs addPluginCustomAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;[Ljava/lang/String;)V - -
 method public addPluginAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;)V - -
 method public addTransformerAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer<*>;)V -
 method public getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/TransformerAuditTrail 65 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerAuditTrail -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public addReason (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,varargs addPluginCustomAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;[Ljava/lang/String;)V - -
 method public addPluginAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;)V - -
 method public addTransformerAuditTrail (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer;)V (Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformationService;Lcpw/mods/modlauncher/api/ITransformer<*>;)V -
 method public getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 386
class cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity 60 super java/lang/Object cpw/mods/modlauncher/api/ITransformerActivity -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getContext ()[Ljava/lang/String; - -
 method public getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getActivityString ()Ljava/lang/String; - -
in 135
class cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity 52 super java/lang/Object - -
 inner cpw/mods/modlauncher/TransformerAuditTrail$Type cpw/mods/modlauncher/TransformerAuditTrail Type static,final,enum
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
in 394
class cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity 52 super java/lang/Object cpw/mods/modlauncher/api/ITransformerActivity -
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 method public getContext ()[Ljava/lang/String; - -
 method public getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getActivityString ()Ljava/lang/String; - -
in 387
class cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity 60 final,super java/lang/Record cpw/mods/modlauncher/api/ITransformerActivity -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static,final
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Lcpw/mods/modlauncher/api/ITransformerActivity$Type;[Ljava/lang/String;)V - -
 method public getContext ()[Ljava/lang/String; - -
 method public getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getActivityString ()Ljava/lang/String; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public context ()[Ljava/lang/String; - -
 method public type ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
in 348
class cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity 65 super java/lang/Object cpw/mods/modlauncher/api/ITransformerActivity -
 inner cpw/mods/modlauncher/TransformerAuditTrail$TransformerActivity cpw/mods/modlauncher/TransformerAuditTrail TransformerActivity private,static
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getContext ()[Ljava/lang/String; - -
 method public getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getActivityString ()Ljava/lang/String; - -
in 135
class cpw/mods/modlauncher/TransformerAuditTrail$Type 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/TransformerAuditTrail$Type;>;
 inner cpw/mods/modlauncher/TransformerAuditTrail$Type cpw/mods/modlauncher/TransformerAuditTrail Type static,final,enum
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/TransformerAuditTrail$Type; -
 field public,static,final,enum TRANSFORMER Lcpw/mods/modlauncher/TransformerAuditTrail$Type; -
 method public,static values ()[Lcpw/mods/modlauncher/TransformerAuditTrail$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/TransformerAuditTrail$Type; - -
 method public getLabel ()Ljava/lang/String; - -
in 386
class cpw/mods/modlauncher/TransformerClassWriter 60 super org/objectweb/asm/ClassWriter - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static createClassWriter (ILcpw/mods/modlauncher/ClassTransformer;Lorg/objectweb/asm/tree/ClassNode;)Lorg/objectweb/asm/ClassWriter; - -
 method protected getCommonSuperClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 382
class cpw/mods/modlauncher/TransformerClassWriter 52 super org/objectweb/asm/ClassWriter - -
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 method public <init> (Lcpw/mods/modlauncher/ClassTransformer;Lorg/objectweb/asm/tree/ClassNode;)V - -
 method protected getCommonSuperClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 190
class cpw/mods/modlauncher/TransformerClassWriter 52 super org/objectweb/asm/ClassWriter - -
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static createClassWriter (ILcpw/mods/modlauncher/ClassTransformer;Lorg/objectweb/asm/tree/ClassNode;)Lorg/objectweb/asm/ClassWriter; - -
 method protected getCommonSuperClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 387
class cpw/mods/modlauncher/TransformerClassWriter 60 final,super org/objectweb/asm/ClassWriter - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static createClassWriter (ILcpw/mods/modlauncher/ClassTransformer;Lorg/objectweb/asm/tree/ClassNode;)Lorg/objectweb/asm/ClassWriter; - -
 method protected getCommonSuperClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/TransformerClassWriter 65 super org/objectweb/asm/ClassWriter - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static createClassWriter (ILcpw/mods/modlauncher/ClassTransformer;Lorg/objectweb/asm/tree/ClassNode;)Lorg/objectweb/asm/ClassWriter; - -
 method protected getCommonSuperClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 386
class cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor 60 super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/TransformerClassWriter;)V - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 382
class cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor 52 super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/TransformerClassWriter;Lcpw/mods/modlauncher/ClassTransformer;)V - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 190
class cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor 52 super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/TransformerClassWriter;)V - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 387
class cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor 60 final,super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private,final
 method public <init> (Lcpw/mods/modlauncher/TransformerClassWriter;)V - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 348
class cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor 65 super org/objectweb/asm/ClassVisitor - -
 inner cpw/mods/modlauncher/TransformerClassWriter$SuperCollectingVisitor cpw/mods/modlauncher/TransformerClassWriter SuperCollectingVisitor private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/TransformerClassWriter;)V - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
in 378
class cpw/mods/modlauncher/TransformerHolder 60 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformer <T:Ljava/lang/Object;>Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformer<TT;>;
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 method public <init> (Lcpw/mods/modlauncher/api/ITransformer;Lcpw/mods/modlauncher/api/ITransformationService;)V (Lcpw/mods/modlauncher/api/ITransformer<TT;>;Lcpw/mods/modlauncher/api/ITransformationService;)V -
 method public transform (Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Ljava/lang/Object; (TT;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)TT; -
 method public castVote (Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public targets ()Ljava/util/Set; ()Ljava/util/Set<Lcpw/mods/modlauncher/api/ITransformer$Target;>; -
 method public labels ()[Ljava/lang/String; - -
 method public owner ()Lcpw/mods/modlauncher/api/ITransformationService; - -
in 376
class cpw/mods/modlauncher/TransformerHolder 52 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformer <T:Ljava/lang/Object;>Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformer<TT;>;
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 method public <init> (Lcpw/mods/modlauncher/api/ITransformer;Lcpw/mods/modlauncher/api/ITransformationService;)V (Lcpw/mods/modlauncher/api/ITransformer<TT;>;Lcpw/mods/modlauncher/api/ITransformationService;)V -
 method public transform (Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Ljava/lang/Object; (TT;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)TT; -
 method public castVote (Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public targets ()Ljava/util/Set; ()Ljava/util/Set<Lcpw/mods/modlauncher/api/ITransformer$Target;>; -
 method public labels ()[Ljava/lang/String; - -
 method public owner ()Lcpw/mods/modlauncher/api/ITransformationService; - -
in 348
class cpw/mods/modlauncher/TransformerHolder 65 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformer <T:Ljava/lang/Object;>Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformer<TT;>;
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 method public <init> (Lcpw/mods/modlauncher/api/ITransformer;Lcpw/mods/modlauncher/api/ITransformationService;)V (Lcpw/mods/modlauncher/api/ITransformer<TT;>;Lcpw/mods/modlauncher/api/ITransformationService;)V -
 method public transform (Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Ljava/lang/Object; (TT;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)TT; -
 method public castVote (Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public targets ()Ljava/util/Set; ()Ljava/util/Set<Lcpw/mods/modlauncher/api/ITransformer$Target<TT;>;>; -
 method public getTargetType ()Lcpw/mods/modlauncher/api/TargetType; ()Lcpw/mods/modlauncher/api/TargetType<TT;>; -
 method public labels ()[Ljava/lang/String; - -
 method public owner ()Lcpw/mods/modlauncher/api/ITransformationService; - -
in 386
class cpw/mods/modlauncher/TransformerVote 60 super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
in 376
class cpw/mods/modlauncher/TransformerVote 52 super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
in 387
class cpw/mods/modlauncher/TransformerVote 60 final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public result ()Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public transformer ()Lcpw/mods/modlauncher/api/ITransformer; ()Lcpw/mods/modlauncher/api/ITransformer<TT;>; -
in 348
class cpw/mods/modlauncher/TransformerVote 65 super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
in 378
class cpw/mods/modlauncher/TransformingClassLoader 60 public,super cpw/mods/cl/ModuleClassLoader - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method public getLoadedClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
in 135
class cpw/mods/modlauncher/TransformingClassLoader 52 public,super java/lang/ClassLoader cpw/mods/modlauncher/api/ITransformingClassLoader -
 inner cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader cpw/mods/modlauncher/TransformingClassLoader DelegatedClassLoader private,static
 inner cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection cpw/mods/modlauncher/TransformingClassLoader AutoURLConnection static
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;[Ljava/nio/file/Path;)V - -
 method public <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/TransformingClassLoaderBuilder;Lcpw/mods/modlauncher/Environment;)V - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public getLoadedClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
 method public addTargetPackageFilter (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
 method public getClass (Ljava/lang/String;[B)Ljava/lang/Class; <T:Ljava/lang/Object;>(Ljava/lang/String;[B)Ljava/lang/Class<TT;>; -
 method public loadClass (Ljava/lang/String;Ljava/util/function/Function;)Ljava/lang/Class; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/net/URL;>;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected locateResource (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URL;>; -
in 395
class cpw/mods/modlauncher/TransformingClassLoader 52 public,super java/lang/ClassLoader cpw/mods/modlauncher/api/ITransformingClassLoader -
 inner cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader cpw/mods/modlauncher/TransformingClassLoader DelegatedClassLoader private,static
 inner cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection cpw/mods/modlauncher/TransformingClassLoader AutoURLConnection static
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;[Ljava/nio/file/Path;)V - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public getLoadedClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
 method public addTargetPackageFilter (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
 method public getClass (Ljava/lang/String;[B)Ljava/lang/Class; <T:Ljava/lang/Object;>(Ljava/lang/String;[B)Ljava/lang/Class<TT;>; -
 method public loadClass (Ljava/lang/String;Ljava/util/function/Function;)Ljava/lang/Class; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/net/URL;>;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected locateResource (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/net/URL;>; -
in 190
class cpw/mods/modlauncher/TransformingClassLoader 52 public,super java/lang/ClassLoader cpw/mods/modlauncher/api/ITransformingClassLoader -
 inner cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader cpw/mods/modlauncher/TransformingClassLoader DelegatedClassLoader private,static
 inner cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection cpw/mods/modlauncher/TransformingClassLoader AutoURLConnection static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;[Ljava/nio/file/Path;)V - -
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public getLoadedClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
 method public addTargetPackageFilter (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
 method public getClass (Ljava/lang/String;[B)Ljava/lang/Class; <T:Ljava/lang/Object;>(Ljava/lang/String;[B)Ljava/lang/Class<TT;>; -
 method public loadClass (Ljava/lang/String;Ljava/util/function/Function;)Ljava/lang/Class; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findResource (Ljava/lang/String;)Ljava/net/URL; - -
 method protected findResources (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; -
 method protected locateResource (Ljava/lang/String;)Ljava/util/Enumeration; (Ljava/lang/String;)Ljava/util/Enumeration<Ljava/net/URL;>; -
in 192
class cpw/mods/modlauncher/TransformingClassLoader 65 public,super cpw/mods/cl/ModuleClassLoader - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/ModuleLayerHandler;)V - -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method public getLoadedClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
in 388
class cpw/mods/modlauncher/TransformingClassLoader 65 public,super cpw/mods/cl/ModuleClassLoader - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/api/IModuleLayerManager;)V - -
 method public <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/Environment;Ljava/lang/module/Configuration;Ljava/util/List;)V (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/Environment;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;)V -
 method public <init> (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/Environment;Ljava/lang/module/Configuration;Ljava/util/List;Ljava/lang/ClassLoader;)V (Lcpw/mods/modlauncher/TransformStore;Lcpw/mods/modlauncher/LaunchPluginHandler;Lcpw/mods/modlauncher/Environment;Ljava/lang/module/Configuration;Ljava/util/List<Ljava/lang/ModuleLayer;>;Ljava/lang/ClassLoader;)V -
 method protected maybeTransformClassBytes ([BLjava/lang/String;Ljava/lang/String;)[B - -
 method public getLoadedClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
in 376
class cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection 52 super java/lang/Object java/lang/AutoCloseable -
 inner cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection cpw/mods/modlauncher/TransformingClassLoader AutoURLConnection static
 method public close ()V - java/io/IOException
in 384
class cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader 52 super java/net/URLClassLoader - -
 inner cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader cpw/mods/modlauncher/TransformingClassLoader DelegatedClassLoader private,static
 inner cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection cpw/mods/modlauncher/TransformingClassLoader AutoURLConnection static
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public findResource (Ljava/lang/String;Ljava/util/function/Function;)Ljava/net/URL; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/net/URL;>;)Ljava/net/URL; -
 method protected findClass (Ljava/lang/String;Ljava/util/function/Function;)[B (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/net/URL;>;)[B java/lang/ClassNotFoundException
in 396
class cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader 52 super java/net/URLClassLoader - -
 inner cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader cpw/mods/modlauncher/TransformingClassLoader DelegatedClassLoader private,static
 inner cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection cpw/mods/modlauncher/TransformingClassLoader AutoURLConnection static
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public findResource (Ljava/lang/String;Ljava/util/function/Function;)Ljava/net/URL; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/net/URL;>;)Ljava/net/URL; -
 method protected findClass (Ljava/lang/String;Ljava/util/function/Function;Ljava/lang/String;)[B (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/net/URL;>;Ljava/lang/String;)[B java/lang/ClassNotFoundException
in 190
class cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader 52 super java/net/URLClassLoader - -
 inner cpw/mods/modlauncher/TransformingClassLoader$DelegatedClassLoader cpw/mods/modlauncher/TransformingClassLoader DelegatedClassLoader private,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner cpw/mods/modlauncher/TransformingClassLoader$AutoURLConnection cpw/mods/modlauncher/TransformingClassLoader AutoURLConnection static
 inner java/util/AbstractMap$SimpleImmutableEntry java/util/AbstractMap SimpleImmutableEntry public,static
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 method protected loadClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public findResource (Ljava/lang/String;Ljava/util/function/Function;)Ljava/net/URL; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)Ljava/net/URL; -
 method public findResources (Ljava/lang/String;Ljava/util/function/Function;)Ljava/util/Enumeration; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)Ljava/util/Enumeration<Ljava/net/URL;>; -
 method protected findClass (Ljava/lang/String;Ljava/util/function/Function;Ljava/lang/String;)Ljava/util/Map$Entry; (Ljava/lang/String;Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;Ljava/lang/String;)Ljava/util/Map$Entry<[BLjava/security/CodeSource;>; java/lang/ClassNotFoundException
in 386
class cpw/mods/modlauncher/TransformingClassLoaderBuilder 60 super java/lang/Object cpw/mods/modlauncher/api/ITransformingClassLoaderBuilder -
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public addTransformationPath (Ljava/nio/file/Path;)V - -
 method public setClassBytesLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;)V -
 method public setResourceEnumeratorLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)V -
in 382
class cpw/mods/modlauncher/TransformingClassLoaderBuilder 52 super java/lang/Object cpw/mods/modlauncher/api/ITransformingClassLoaderBuilder -
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public addTransformationPath (Ljava/nio/file/Path;)V - -
 method public setClassBytesLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;)V -
 method public setManifestLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/net/URLConnection;Ljava/util/Optional<Ljava/util/jar/Manifest;>;>;)V -
in 190
class cpw/mods/modlauncher/TransformingClassLoaderBuilder 52 super java/lang/Object cpw/mods/modlauncher/api/ITransformingClassLoaderBuilder -
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public addTransformationPath (Ljava/nio/file/Path;)V - -
 method public setClassBytesLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;)V -
 method public setResourceEnumeratorLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)V -
 method public setManifestLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/net/URLConnection;Ljava/util/Optional<Ljava/util/jar/Manifest;>;>;)V -
in 387
class cpw/mods/modlauncher/TransformingClassLoaderBuilder 60 final,super java/lang/Object cpw/mods/modlauncher/api/ITransformingClassLoaderBuilder -
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public addTransformationPath (Ljava/nio/file/Path;)V - -
 method public setClassBytesLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;)V -
 method public setResourceEnumeratorLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)V -
in 376
class cpw/mods/modlauncher/ValidateLibraries 52 super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/util/AbstractMap$SimpleEntry java/util/AbstractMap SimpleEntry public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 378
class cpw/mods/modlauncher/VoteDeadlockException 60 public,super java/lang/RuntimeException - -
in 376
class cpw/mods/modlauncher/VoteDeadlockException 52 public,super java/lang/RuntimeException - -
in 348
class cpw/mods/modlauncher/VoteDeadlockException 65 public,super java/lang/RuntimeException - -
in 378
class cpw/mods/modlauncher/VoteRejectedException 60 public,super java/lang/RuntimeException - -
in 376
class cpw/mods/modlauncher/VoteRejectedException 52 public,super java/lang/RuntimeException - -
in 348
class cpw/mods/modlauncher/VoteRejectedException 65 public,super java/lang/RuntimeException - -
in 386
class cpw/mods/modlauncher/VotingContext 60 super java/lang/Object cpw/mods/modlauncher/api/ITransformerVotingContext -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 method public getClassName ()Ljava/lang/String; - -
 method public doesClassExist ()Z - -
 method public getInitialClassSha256 ()[B - -
 method public getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public getReason ()Ljava/lang/String; - -
 method public applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 135
class cpw/mods/modlauncher/VotingContext 52 public,super java/lang/Object cpw/mods/modlauncher/api/ITransformerVotingContext -
 method public <init> (Ljava/lang/String;ZLjava/util/function/Supplier;)V (Ljava/lang/String;ZLjava/util/function/Supplier<[B>;)V -
 method public getClassName ()Ljava/lang/String; - -
in 391
class cpw/mods/modlauncher/VotingContext 52 super java/lang/Object cpw/mods/modlauncher/api/ITransformerVotingContext -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 method public getClassName ()Ljava/lang/String; - -
 method public doesClassExist ()Z - -
 method public getInitialClassSha256 ()[B - -
 method public getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 385
class cpw/mods/modlauncher/VotingContext 52 super java/lang/Object cpw/mods/modlauncher/api/ITransformerVotingContext -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 method public getClassName ()Ljava/lang/String; - -
 method public doesClassExist ()Z - -
 method public getInitialClassSha256 ()[B - -
 method public getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public getReason ()Ljava/lang/String; - -
 method public applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 387
class cpw/mods/modlauncher/VotingContext 60 final,super java/lang/Record cpw/mods/modlauncher/api/ITransformerVotingContext -
 inner cpw/mods/modlauncher/VotingContext$NodeHolder cpw/mods/modlauncher/VotingContext NodeHolder private,static,final
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getInitialClassSha256 ()[B - -
 method public getReason ()Ljava/lang/String; - -
 method public applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public getClassName ()Ljava/lang/String; - -
 method public doesClassExist ()Z - -
 method public sha256 ()Ljava/util/function/Supplier; ()Ljava/util/function/Supplier<[B>; -
 method public getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public reason ()Ljava/lang/String; - -
 method public node ()Lcpw/mods/modlauncher/VotingContext$NodeHolder; - -
in 348
class cpw/mods/modlauncher/VotingContext 65 super java/lang/Object cpw/mods/modlauncher/api/ITransformerVotingContext -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 method public getClassName ()Ljava/lang/String; - -
 method public doesClassExist ()Z - -
 method public getInitialClassSha256 ()[B - -
 method public getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public getReason ()Ljava/lang/String; - -
 method public applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 387
class cpw/mods/modlauncher/VotingContext$NodeHolder 60 final,super java/lang/Object - -
 inner cpw/mods/modlauncher/VotingContext$NodeHolder cpw/mods/modlauncher/VotingContext NodeHolder private,static,final
in 386
class cpw/mods/modlauncher/api/IEnvironment 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 method public,abstract getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public,abstract computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
 method public,abstract findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public,abstract findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public,abstract findModuleLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
 method public,abstract findNameMapping (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static buildKey (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Class<-TT;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>; -
in 135
class cpw/mods/modlauncher/api/IEnvironment 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 method public,abstract getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public,abstract computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
 method public,abstract findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public,abstract findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public,abstract findNameMapping (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static buildKey (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Class<TT;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>; -
in 394
class cpw/mods/modlauncher/api/IEnvironment 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 method public,abstract getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public,abstract computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
 method public,abstract findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public,abstract findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public,abstract findNameMapping (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static buildKey (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Class<-TT;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>; -
in 387
class cpw/mods/modlauncher/api/IEnvironment 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public,abstract computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
 method public computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Supplier<+TT;>;)TT; -
 method public putPropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;TT;)TT; -
 method public,abstract findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public,abstract findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public,abstract findModuleLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
 method public,abstract findNameMapping (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static buildKey (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Class<-TT;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>; -
in 348
class cpw/mods/modlauncher/api/IEnvironment 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 method public,abstract getProperty (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;)Ljava/util/Optional<TT;>; -
 method public,abstract computePropertyIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;+TT;>;)TT; -
 method public,abstract findLaunchPlugin (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService;>; -
 method public,abstract findLaunchHandler (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcpw/mods/modlauncher/api/ILaunchHandlerService;>; -
 method public,abstract findModuleLayerManager ()Ljava/util/Optional; ()Ljava/util/Optional<Lcpw/mods/modlauncher/api/IModuleLayerManager;>; -
 method public,static buildKey (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Class<-TT;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>; -
in 378
class cpw/mods/modlauncher/api/IEnvironment$Keys 60 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 field public,static,final VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final GAMEDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final ASSETSDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final UUID Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final LAUNCHTARGET Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final NAMING Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final AUDITTRAIL Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Lcpw/mods/modlauncher/api/ITransformerAuditTrail;>;>;
 field public,static,final MODLIST Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;>;>;
 field public,static,final MLSPEC_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final MLIMPL_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final SECURED_JARS_ENABLED Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/Boolean;>;>;
 method public <init> ()V - -
in 135
class cpw/mods/modlauncher/api/IEnvironment$Keys 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 field public,static,final VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final GAMEDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final ASSETSDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final LAUNCHTARGET Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final NAMING Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final AUDITTRAIL Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Lcpw/mods/modlauncher/api/ITransformerAuditTrail;>;>;
 method public <init> ()V - -
in 391
class cpw/mods/modlauncher/api/IEnvironment$Keys 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 field public,static,final VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final GAMEDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final ASSETSDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final LAUNCHTARGET Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final NAMING Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final AUDITTRAIL Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Lcpw/mods/modlauncher/api/ITransformerAuditTrail;>;>;
 field public,static,final MODLIST Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;>;>;
 field public,static,final MLSPEC_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final MLIMPL_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 method public <init> ()V - -
in 396
class cpw/mods/modlauncher/api/IEnvironment$Keys 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 field public,static,final VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final GAMEDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final ASSETSDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final UUID Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final LAUNCHTARGET Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final NAMING Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final AUDITTRAIL Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Lcpw/mods/modlauncher/api/ITransformerAuditTrail;>;>;
 field public,static,final MODLIST Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;>;>;
 field public,static,final MLSPEC_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final MLIMPL_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 method public <init> ()V - -
in 190
class cpw/mods/modlauncher/api/IEnvironment$Keys 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 field public,static,final VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final GAMEDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final ASSETSDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final UUID Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final LAUNCHTARGET Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final NAMING Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final AUDITTRAIL Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Lcpw/mods/modlauncher/api/ITransformerAuditTrail;>;>;
 field public,static,final MODLIST Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;>;>;
 field public,static,final MLSPEC_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final MLIMPL_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final SECURED_JARS_ENABLED Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/Boolean;>;>;
 method public <init> ()V - -
in 348
class cpw/mods/modlauncher/api/IEnvironment$Keys 65 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 field public,static,final VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final GAMEDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final ASSETSDIR Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/nio/file/Path;>;>;
 field public,static,final UUID Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final LAUNCHTARGET Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final AUDITTRAIL Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Lcpw/mods/modlauncher/api/ITransformerAuditTrail;>;>;
 field public,static,final MODLIST Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;>;>;
 field public,static,final MLSPEC_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 field public,static,final MLIMPL_VERSION Ljava/util/function/Supplier; Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<Ljava/lang/String;>;>;
 method public <init> ()V - -
in 0
class cpw/mods/modlauncher/api/ILaunchHandlerService 60 public,interface,abstract java/lang/Object - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public,abstract launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 383
class cpw/mods/modlauncher/api/ILaunchHandlerService 60 public,interface,abstract java/lang/Object - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract,deprecated configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public,abstract launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 384
class cpw/mods/modlauncher/api/ILaunchHandlerService 52 public,interface,abstract java/lang/Object - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public,abstract launchService ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
in 385
class cpw/mods/modlauncher/api/ILaunchHandlerService 52 public,interface,abstract java/lang/Object - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public,abstract launchService ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable; ([Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformingClassLoader;)Ljava/util/concurrent/Callable<Ljava/lang/Void;>; -
 method public getPaths ()[Ljava/nio/file/Path; - -
in 380
class cpw/mods/modlauncher/api/ILaunchHandlerService 60 public,interface,abstract java/lang/Object - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,deprecated configureTransformationClassLoader (Lcpw/mods/modlauncher/api/ITransformingClassLoaderBuilder;)V - -
 method public,abstract launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 348
class cpw/mods/modlauncher/api/ILaunchHandlerService 65 public,interface,abstract java/lang/Object - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract launchService ([Ljava/lang/String;Ljava/lang/ModuleLayer;)Lcpw/mods/modlauncher/api/ServiceRunner; - -
 method public getPaths ()[Lcpw/mods/modlauncher/api/NamedPath; - -
in 378
class cpw/mods/modlauncher/api/IModuleLayerManager 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 method public,abstract getLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional<Ljava/lang/ModuleLayer;>; -
in 348
class cpw/mods/modlauncher/api/IModuleLayerManager 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 method public,abstract getLayer (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional; (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;)Ljava/util/Optional<Ljava/lang/ModuleLayer;>; -
in 381
class cpw/mods/modlauncher/api/IModuleLayerManager$Layer 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;>;
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 field public,static,final,enum BOOT Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum SERVICE Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum GAME Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 method public,static values ()[Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public getParent ()[Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
in 380
class cpw/mods/modlauncher/api/IModuleLayerManager$Layer 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;>;
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BOOT Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum SERVICE Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum GAME Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 method public,static values ()[Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public,deprecated getParent ()[Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public getParents ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;>; -
in 348
class cpw/mods/modlauncher/api/IModuleLayerManager$Layer 65 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;>;
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 field public,static,final,enum BOOT Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum SERVICE Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 field public,static,final,enum GAME Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; -
 method public,static values ()[Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public getParent ()[Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
in 378
class cpw/mods/modlauncher/api/INameMappingService 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract mappingName ()Ljava/lang/String; - -
 method public,abstract mappingVersion ()Ljava/lang/String; - -
 method public,abstract understanding ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract namingFunction ()Ljava/util/function/BiFunction; ()Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>; -
in 376
class cpw/mods/modlauncher/api/INameMappingService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract mappingName ()Ljava/lang/String; - -
 method public,abstract mappingVersion ()Ljava/lang/String; - -
 method public,abstract understanding ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract namingFunction ()Ljava/util/function/BiFunction; ()Ljava/util/function/BiFunction<Lcpw/mods/modlauncher/api/INameMappingService$Domain;Ljava/lang/String;Ljava/lang/String;>; -
in 378
class cpw/mods/modlauncher/api/INameMappingService$Domain 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/INameMappingService$Domain;>;
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/api/INameMappingService$Domain; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/api/INameMappingService$Domain; -
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/api/INameMappingService$Domain; -
 method public,static values ()[Lcpw/mods/modlauncher/api/INameMappingService$Domain; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/INameMappingService$Domain; - -
in 376
class cpw/mods/modlauncher/api/INameMappingService$Domain 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/INameMappingService$Domain;>;
 inner cpw/mods/modlauncher/api/INameMappingService$Domain cpw/mods/modlauncher/api/INameMappingService Domain public,static,final,enum
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/api/INameMappingService$Domain; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/api/INameMappingService$Domain; -
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/api/INameMappingService$Domain; -
 method public,static values ()[Lcpw/mods/modlauncher/api/INameMappingService$Domain; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/INameMappingService$Domain; - -
in 381
class cpw/mods/modlauncher/api/ITransformationService 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public arguments (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<Ljava/lang/String;Ljava/lang/String;Ljoptsimple/OptionSpecBuilder;>;)V -
 method public argumentValues (Lcpw/mods/modlauncher/api/ITransformationService$OptionResult;)V - -
 method public,abstract initialize (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public beginScanning (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
 method public completeScan (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
 method public,abstract onLoad (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set;)V (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set<Ljava/lang/String;>;)V cpw/mods/modlauncher/api/IncompatibleEnvironmentException
 method public,abstract transformers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformer;>; -
 method public additionalClassesLocator ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;>;>; -
 method public additionalResourcesLocator ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;>;>; -
in 135
class cpw/mods/modlauncher/api/ITransformationService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public arguments (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<Ljava/lang/String;Ljava/lang/String;Ljoptsimple/OptionSpecBuilder;>;)V -
 method public argumentValues (Lcpw/mods/modlauncher/api/ITransformationService$OptionResult;)V - -
 method public,abstract initialize (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public,abstract beginScanning (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public,abstract onLoad (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set;)V (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set<Ljava/lang/String;>;)V cpw/mods/modlauncher/api/IncompatibleEnvironmentException
 method public,abstract transformers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformer;>; -
in 391
class cpw/mods/modlauncher/api/ITransformationService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public arguments (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<Ljava/lang/String;Ljava/lang/String;Ljoptsimple/OptionSpecBuilder;>;)V -
 method public argumentValues (Lcpw/mods/modlauncher/api/ITransformationService$OptionResult;)V - -
 method public,abstract initialize (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public,abstract beginScanning (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public,abstract onLoad (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set;)V (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set<Ljava/lang/String;>;)V cpw/mods/modlauncher/api/IncompatibleEnvironmentException
 method public,abstract transformers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformer;>; -
 method public additionalClassesLocator ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;>;>; -
in 385
class cpw/mods/modlauncher/api/ITransformationService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public arguments (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<Ljava/lang/String;Ljava/lang/String;Ljoptsimple/OptionSpecBuilder;>;)V -
 method public argumentValues (Lcpw/mods/modlauncher/api/ITransformationService$OptionResult;)V - -
 method public,abstract initialize (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public,abstract beginScanning (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public runScan (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/String;Ljava/nio/file/Path;>;>; -
 method public,abstract onLoad (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set;)V (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set<Ljava/lang/String;>;)V cpw/mods/modlauncher/api/IncompatibleEnvironmentException
 method public,abstract transformers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformer;>; -
 method public additionalClassesLocator ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;>;>; -
 method public additionalResourcesLocator ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;>;>; -
in 380
class cpw/mods/modlauncher/api/ITransformationService 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public arguments (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<Ljava/lang/String;Ljava/lang/String;Ljoptsimple/OptionSpecBuilder;>;)V -
 method public argumentValues (Lcpw/mods/modlauncher/api/ITransformationService$OptionResult;)V - -
 method public,abstract initialize (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public beginScanning (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
 method public completeScan (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
 method public,abstract onLoad (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set;)V (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set<Ljava/lang/String;>;)V cpw/mods/modlauncher/api/IncompatibleEnvironmentException
 method public,abstract transformers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformer;>; -
 method public,deprecated additionalClassesLocator ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;>;>; -
 method public,deprecated additionalResourcesLocator ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;>;>; -
in 348
class cpw/mods/modlauncher/api/ITransformationService 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 method public,abstract name ()Ljava/lang/String; - -
 method public arguments (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<Ljava/lang/String;Ljava/lang/String;Ljoptsimple/OptionSpecBuilder;>;)V -
 method public argumentValues (Lcpw/mods/modlauncher/api/ITransformationService$OptionResult;)V - -
 method public,abstract initialize (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public beginScanning (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
 method public completeScan (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IModuleLayerManager;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformationService$Resource;>; -
 method public,abstract onLoad (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set;)V (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set<Ljava/lang/String;>;)V cpw/mods/modlauncher/api/IncompatibleEnvironmentException
 method public,abstract transformers ()Ljava/util/List; ()Ljava/util/List<+Lcpw/mods/modlauncher/api/ITransformer<*>;>; -
in 378
class cpw/mods/modlauncher/api/ITransformationService$OptionResult 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 method public,abstract value (Ljoptsimple/OptionSpec;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)TV; -
 method public,abstract values (Ljoptsimple/OptionSpec;)Ljava/util/List; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)Ljava/util/List<TV;>; -
in 376
class cpw/mods/modlauncher/api/ITransformationService$OptionResult 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 method public,abstract value (Ljoptsimple/OptionSpec;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)TV; -
 method public,abstract values (Ljoptsimple/OptionSpec;)Ljava/util/List; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)Ljava/util/List<TV;>; -
in 348
class cpw/mods/modlauncher/api/ITransformationService$OptionResult 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 method public,abstract value (Ljoptsimple/OptionSpec;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)TV; -
 method public,abstract values (Ljoptsimple/OptionSpec;)Ljava/util/List; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)Ljava/util/List<TV;>; -
in 378
class cpw/mods/modlauncher/api/ITransformationService$Resource 60 public,final,super java/lang/Record - -
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/List;)V (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public target ()Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public resources ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar;>; -
in 348
class cpw/mods/modlauncher/api/ITransformationService$Resource 65 public,final,super java/lang/Record - -
 inner cpw/mods/modlauncher/api/ITransformationService$Resource cpw/mods/modlauncher/api/ITransformationService Resource public,static,final
 inner cpw/mods/modlauncher/api/IModuleLayerManager$Layer cpw/mods/modlauncher/api/IModuleLayerManager Layer public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/List;)V (Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer;Ljava/util/List<Lcpw/mods/jarhandling/SecureJar;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public target ()Lcpw/mods/modlauncher/api/IModuleLayerManager$Layer; - -
 method public resources ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/jarhandling/SecureJar;>; -
in 378
class cpw/mods/modlauncher/api/ITransformer 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 field public,static,final DEFAULT_LABEL [Ljava/lang/String; -
 method public,abstract transform (Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Ljava/lang/Object; (TT;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)TT; -
 method public,abstract castVote (Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public,abstract targets ()Ljava/util/Set; ()Ljava/util/Set<Lcpw/mods/modlauncher/api/ITransformer$Target;>; -
 method public labels ()[Ljava/lang/String; - -
in 376
class cpw/mods/modlauncher/api/ITransformer 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 field public,static,final DEFAULT_LABEL [Ljava/lang/String; -
 method public,abstract transform (Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Ljava/lang/Object; (TT;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)TT; -
 method public,abstract castVote (Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public,abstract targets ()Ljava/util/Set; ()Ljava/util/Set<Lcpw/mods/modlauncher/api/ITransformer$Target;>; -
 method public labels ()[Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/api/ITransformer 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 field public,static,final DEFAULT_LABEL [Ljava/lang/String; -
 method public,abstract transform (Ljava/lang/Object;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Ljava/lang/Object; (TT;Lcpw/mods/modlauncher/api/ITransformerVotingContext;)TT; -
 method public,abstract castVote (Lcpw/mods/modlauncher/api/ITransformerVotingContext;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public,abstract targets ()Ljava/util/Set; ()Ljava/util/Set<Lcpw/mods/modlauncher/api/ITransformer$Target<TT;>;>; -
 method public,abstract getTargetType ()Lcpw/mods/modlauncher/api/TargetType; ()Lcpw/mods/modlauncher/api/TargetType<TT;>; -
 method public labels ()[Ljava/lang/String; - -
in 386
class cpw/mods/modlauncher/api/ITransformer$Target 60 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 method public,static targetClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetPreClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetMethod (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetField (Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getElementName ()Ljava/lang/String; - -
 method public getElementDescriptor ()Ljava/lang/String; - -
 method public getTargetType ()Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
in 382
class cpw/mods/modlauncher/api/ITransformer$Target 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 method public,static targetClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetMethod (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetField (Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getElementName ()Ljava/lang/String; - -
 method public getElementDescriptor ()Ljava/lang/String; - -
 method public getTargetType ()Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
in 190
class cpw/mods/modlauncher/api/ITransformer$Target 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 method public,static targetClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetPreClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetMethod (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetField (Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getElementName ()Ljava/lang/String; - -
 method public getElementDescriptor ()Ljava/lang/String; - -
 method public getTargetType ()Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
in 387
class cpw/mods/modlauncher/api/ITransformer$Target 60 public,final,super java/lang/Record - -
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcpw/mods/modlauncher/api/ITransformer$TargetType;)V - -
 method public,static targetClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetPreClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetMethod (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public,static targetField (Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getElementName ()Ljava/lang/String; - -
 method public getElementDescriptor ()Ljava/lang/String; - -
 method public getTargetType ()Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public className ()Ljava/lang/String; - -
 method public elementName ()Ljava/lang/String; - -
 method public elementDescriptor ()Ljava/lang/String; - -
 method public targetType ()Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
in 348
class cpw/mods/modlauncher/api/ITransformer$Target 65 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner cpw/mods/modlauncher/api/ITransformer$Target cpw/mods/modlauncher/api/ITransformer Target public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcpw/mods/modlauncher/api/TargetType;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcpw/mods/modlauncher/api/TargetType<TT;>;)V -
 method public,static targetClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target<Lorg/objectweb/asm/tree/ClassNode;>; -
 method public,static targetPreClass (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target<Lorg/objectweb/asm/tree/ClassNode;>; -
 method public,static targetMethod (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target<Lorg/objectweb/asm/tree/MethodNode;>; -
 method public,static targetField (Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target; (Ljava/lang/String;Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$Target<Lorg/objectweb/asm/tree/FieldNode;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public className ()Ljava/lang/String; - -
 method public elementName ()Ljava/lang/String; - -
 method public elementDescriptor ()Ljava/lang/String; - -
 method public targetType ()Lcpw/mods/modlauncher/api/TargetType; ()Lcpw/mods/modlauncher/api/TargetType<TT;>; -
in 378
class cpw/mods/modlauncher/api/ITransformer$TargetType 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/ITransformer$TargetType;>;
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum PRE_CLASS Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 method public,static values ()[Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
in 382
class cpw/mods/modlauncher/api/ITransformer$TargetType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/ITransformer$TargetType;>;
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 method public,static values ()[Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
in 190
class cpw/mods/modlauncher/api/ITransformer$TargetType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/ITransformer$TargetType;>;
 inner cpw/mods/modlauncher/api/ITransformer$TargetType cpw/mods/modlauncher/api/ITransformer TargetType public,static,final,enum
 field public,static,final,enum CLASS Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum METHOD Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum FIELD Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 field public,static,final,enum PRE_CLASS Lcpw/mods/modlauncher/api/ITransformer$TargetType; -
 method public,static values ()[Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformer$TargetType; - -
in 378
class cpw/mods/modlauncher/api/ITransformerActivity 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 field public,static,final COMPUTING_FRAMES_REASON Ljava/lang/String; - "computing_frames"
 field public,static,final CLASSLOADING_REASON Ljava/lang/String; - "classloading"
 method public,abstract getContext ()[Ljava/lang/String; - -
 method public,abstract getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,abstract getActivityString ()Ljava/lang/String; - -
in 395
class cpw/mods/modlauncher/api/ITransformerActivity 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 method public,abstract getContext ()[Ljava/lang/String; - -
 method public,abstract getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,abstract getActivityString ()Ljava/lang/String; - -
in 190
class cpw/mods/modlauncher/api/ITransformerActivity 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 field public,static,final COMPUTING_FRAMES_REASON Ljava/lang/String; - "computing_frames"
 field public,static,final CLASSLOADING_REASON Ljava/lang/String; - "classloading"
 method public,abstract getContext ()[Ljava/lang/String; - -
 method public,abstract getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,abstract getActivityString ()Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/api/ITransformerActivity 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 field public,static,final COMPUTING_FRAMES_REASON Ljava/lang/String; - "computing_frames"
 field public,static,final CLASSLOADING_REASON Ljava/lang/String; - "classloading"
 method public,abstract getContext ()[Ljava/lang/String; - -
 method public,abstract getType ()Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,abstract getActivityString ()Ljava/lang/String; - -
in 378
class cpw/mods/modlauncher/api/ITransformerActivity$Type 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/ITransformerActivity$Type;>;
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 field public,static,final,enum TRANSFORMER Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 field public,static,final,enum REASON Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 method public,static values ()[Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getLabel ()Ljava/lang/String; - -
in 391
class cpw/mods/modlauncher/api/ITransformerActivity$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/ITransformerActivity$Type;>;
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 field public,static,final,enum TRANSFORMER Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 method public,static values ()[Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getLabel ()Ljava/lang/String; - -
in 385
class cpw/mods/modlauncher/api/ITransformerActivity$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/ITransformerActivity$Type;>;
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 field public,static,final,enum TRANSFORMER Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 field public,static,final,enum REASON Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 method public,static values ()[Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getLabel ()Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/api/ITransformerActivity$Type 65 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/ITransformerActivity$Type;>;
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 field public,static,final,enum PLUGIN Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 field public,static,final,enum TRANSFORMER Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 field public,static,final,enum REASON Lcpw/mods/modlauncher/api/ITransformerActivity$Type; -
 method public,static values ()[Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/ITransformerActivity$Type; - -
 method public getLabel ()Ljava/lang/String; - -
in 378
class cpw/mods/modlauncher/api/ITransformerAuditTrail 60 public,interface,abstract java/lang/Object - -
 method public,abstract getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public,abstract getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 135
class cpw/mods/modlauncher/api/ITransformerAuditTrail 52 public,interface,abstract java/lang/Object - -
 method public,abstract getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 394
class cpw/mods/modlauncher/api/ITransformerAuditTrail 52 public,interface,abstract java/lang/Object - -
 method public,abstract getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public,abstract getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/api/ITransformerAuditTrail 65 public,interface,abstract java/lang/Object - -
 method public,abstract getActivityFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public,abstract getAuditString (Ljava/lang/String;)Ljava/lang/String; - -
in 378
class cpw/mods/modlauncher/api/ITransformerVotingContext 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 method public,abstract getClassName ()Ljava/lang/String; - -
 method public,abstract doesClassExist ()Z - -
 method public,abstract getInitialClassSha256 ()[B - -
 method public,abstract getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public,abstract getReason ()Ljava/lang/String; - -
 method public,abstract applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public,abstract applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public,abstract applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public,abstract applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 135
class cpw/mods/modlauncher/api/ITransformerVotingContext 52 public,interface,abstract java/lang/Object - -
in 391
class cpw/mods/modlauncher/api/ITransformerVotingContext 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 method public,abstract getClassName ()Ljava/lang/String; - -
 method public,abstract doesClassExist ()Z - -
 method public,abstract getInitialClassSha256 ()[B - -
 method public,abstract getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public,abstract applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public,abstract applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public,abstract applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public,abstract applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 385
class cpw/mods/modlauncher/api/ITransformerVotingContext 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 method public,abstract getClassName ()Ljava/lang/String; - -
 method public,abstract doesClassExist ()Z - -
 method public,abstract getInitialClassSha256 ()[B - -
 method public,abstract getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public,abstract getReason ()Ljava/lang/String; - -
 method public,abstract applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public,abstract applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public,abstract applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public,abstract applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 348
class cpw/mods/modlauncher/api/ITransformerVotingContext 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 method public,abstract getClassName ()Ljava/lang/String; - -
 method public,abstract doesClassExist ()Z - -
 method public,abstract getInitialClassSha256 ()[B - -
 method public,abstract getAuditActivities ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformerActivity;>; -
 method public,abstract getReason ()Ljava/lang/String; - -
 method public,abstract applyFieldPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate;)Z - -
 method public,abstract applyMethodPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate;)Z - -
 method public,abstract applyClassPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate;)Z - -
 method public,abstract applyInstructionPredicate (Lcpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate;)Z - -
in 378
class cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 method public,abstract test (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z - -
in 394
class cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 method public,abstract test (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z - -
in 348
class cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$ClassPredicate cpw/mods/modlauncher/api/ITransformerVotingContext ClassPredicate public,static,interface,abstract
 method public,abstract test (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z - -
in 378
class cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 method public,abstract test (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Z - -
in 394
class cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 method public,abstract test (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Z - -
in 348
class cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$FieldPredicate cpw/mods/modlauncher/api/ITransformerVotingContext FieldPredicate public,static,interface,abstract
 method public,abstract test (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Z - -
in 378
class cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 method public,varargs,abstract test (II[Ljava/lang/Object;)Z - -
in 394
class cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 method public,varargs,abstract test (II[Ljava/lang/Object;)Z - -
in 348
class cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$InsnPredicate cpw/mods/modlauncher/api/ITransformerVotingContext InsnPredicate public,static,interface,abstract
 method public,varargs,abstract test (II[Ljava/lang/Object;)Z - -
in 378
class cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 method public,abstract test (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z - -
in 394
class cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 method public,abstract test (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z - -
in 348
class cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/api/ITransformerVotingContext$MethodPredicate cpw/mods/modlauncher/api/ITransformerVotingContext MethodPredicate public,static,interface,abstract
 method public,abstract test (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Z - -
in 376
class cpw/mods/modlauncher/api/ITransformingClassLoader 52 public,interface,abstract java/lang/Object - -
 method public getInstance ()Ljava/lang/ClassLoader; - -
 method public,abstract addTargetPackageFilter (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
in 378
class cpw/mods/modlauncher/api/ITransformingClassLoaderBuilder 60 public,interface,abstract java/lang/Object - -
 method public,abstract addTransformationPath (Ljava/nio/file/Path;)V - -
 method public,abstract setClassBytesLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;)V -
 method public,abstract setResourceEnumeratorLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)V -
in 382
class cpw/mods/modlauncher/api/ITransformingClassLoaderBuilder 52 public,interface,abstract java/lang/Object - -
 method public,abstract addTransformationPath (Ljava/nio/file/Path;)V - -
 method public,abstract setClassBytesLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;)V -
 method public,abstract setManifestLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/net/URLConnection;Ljava/util/Optional<Ljava/util/jar/Manifest;>;>;)V -
in 190
class cpw/mods/modlauncher/api/ITransformingClassLoaderBuilder 52 public,interface,abstract java/lang/Object - -
 method public,abstract addTransformationPath (Ljava/nio/file/Path;)V - -
 method public,abstract setClassBytesLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Optional<Ljava/net/URL;>;>;)V -
 method public,abstract setResourceEnumeratorLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/lang/String;Ljava/util/Enumeration<Ljava/net/URL;>;>;)V -
 method public,abstract setManifestLocator (Ljava/util/function/Function;)V (Ljava/util/function/Function<Ljava/net/URLConnection;Ljava/util/Optional<Ljava/util/jar/Manifest;>;>;)V -
in 378
class cpw/mods/modlauncher/api/IncompatibleEnvironmentException 60 public,super java/lang/Exception - -
 method public <init> (Ljava/lang/String;)V - -
in 376
class cpw/mods/modlauncher/api/IncompatibleEnvironmentException 52 public,super java/lang/Exception - -
 method public <init> (Ljava/lang/String;)V - -
in 348
class cpw/mods/modlauncher/api/IncompatibleEnvironmentException 65 public,super java/lang/Exception - -
 method public <init> (Ljava/lang/String;)V - -
in 348
class cpw/mods/modlauncher/api/LambdaExceptionUtils 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$BiConsumer_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Runnable_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static rethrowConsumer (Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Consumer_WithExceptions<TT;TE;>;)Ljava/util/function/Consumer<TT;>; -
 method public,static rethrowBiConsumer (Lcpw/mods/modlauncher/api/LambdaExceptionUtils$BiConsumer_WithExceptions;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LambdaExceptionUtils$BiConsumer_WithExceptions<TT;TU;TE;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,static rethrowFunction (Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Function_WithExceptions;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static rethrowSupplier (Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Supplier_WithExceptions<TT;TE;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Runnable_WithExceptions;)V - -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/lang/Object; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)TR; -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Function_WithExceptions;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;TT;)TR; -
in 348
class cpw/mods/modlauncher/api/LambdaExceptionUtils$BiConsumer_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$BiConsumer_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V^TE; java/lang/Exception
in 348
class cpw/mods/modlauncher/api/LambdaExceptionUtils$Consumer_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;)V (TT;)V^TE; java/lang/Exception
in 348
class cpw/mods/modlauncher/api/LambdaExceptionUtils$Function_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR;^TE; java/lang/Exception
in 348
class cpw/mods/modlauncher/api/LambdaExceptionUtils$Runnable_WithExceptions 65 public,interface,abstract java/lang/Object - <E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Runnable_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 method public,abstract run ()V ()V^TE; java/lang/Exception
in 348
class cpw/mods/modlauncher/api/LambdaExceptionUtils$Supplier_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LambdaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LambdaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 method public,abstract get ()Ljava/lang/Object; ()TT;^TE; java/lang/Exception
in 378
class cpw/mods/modlauncher/api/LamdbaExceptionUtils 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static rethrowConsumer (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions<TT;TE;>;)Ljava/util/function/Consumer<TT;>; -
 method public,static rethrowBiConsumer (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions<TT;TU;TE;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,static rethrowFunction (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static rethrowSupplier (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions<TT;TE;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions;)V - -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions;)Ljava/lang/Object; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)TR; -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;TT;)TR; -
in 376
class cpw/mods/modlauncher/api/LamdbaExceptionUtils 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static rethrowConsumer (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions<TT;TE;>;)Ljava/util/function/Consumer<TT;>; -
 method public,static rethrowBiConsumer (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions<TT;TU;TE;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,static rethrowFunction (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static rethrowSupplier (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions<TT;TE;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions;)V - -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions;)Ljava/lang/Object; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)TR; -
 method public,static uncheck (Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;TT;)TR; -
in 378
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V^TE; java/lang/Exception
in 376
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$BiConsumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V^TE; java/lang/Exception
in 378
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;)V (TT;)V^TE; java/lang/Exception
in 376
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Consumer_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;)V (TT;)V^TE; java/lang/Exception
in 378
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR;^TE; java/lang/Exception
in 376
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Function_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Function_WithExceptions public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR;^TE; java/lang/Exception
in 378
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions 60 public,interface,abstract java/lang/Object - <E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 method public,abstract run ()V ()V^TE; java/lang/Exception
in 376
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions 52 public,interface,abstract java/lang/Object - <E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Runnable_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 method public,abstract run ()V ()V^TE; java/lang/Exception
in 378
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 method public,abstract get ()Ljava/lang/Object; ()TT;^TE; java/lang/Exception
in 376
class cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/modlauncher/api/LamdbaExceptionUtils$Supplier_WithExceptions cpw/mods/modlauncher/api/LamdbaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 method public,abstract get ()Ljava/lang/Object; ()TT;^TE; java/lang/Exception
in 378
class cpw/mods/modlauncher/api/NamedPath 60 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Ljava/lang/String;[Ljava/nio/file/Path;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public paths ()[Ljava/nio/file/Path; - -
in 348
class cpw/mods/modlauncher/api/NamedPath 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Ljava/lang/String;[Ljava/nio/file/Path;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public paths ()[Ljava/nio/file/Path; - -
in 379
class cpw/mods/modlauncher/api/ServiceRunner 60 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NOOP Lcpw/mods/modlauncher/api/ServiceRunner; -
 method public,abstract run ()V - java/lang/Throwable
in 348
class cpw/mods/modlauncher/api/ServiceRunner 65 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NOOP Lcpw/mods/modlauncher/api/ServiceRunner; -
 method public,abstract run ()V - java/lang/Throwable
in 348
class cpw/mods/modlauncher/api/TargetType 65 public,final,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final PRE_CLASS Lcpw/mods/modlauncher/api/TargetType; Lcpw/mods/modlauncher/api/TargetType<Lorg/objectweb/asm/tree/ClassNode;>;
 field public,static,final CLASS Lcpw/mods/modlauncher/api/TargetType; Lcpw/mods/modlauncher/api/TargetType<Lorg/objectweb/asm/tree/ClassNode;>;
 field public,static,final METHOD Lcpw/mods/modlauncher/api/TargetType; Lcpw/mods/modlauncher/api/TargetType<Lorg/objectweb/asm/tree/MethodNode;>;
 field public,static,final FIELD Lcpw/mods/modlauncher/api/TargetType; Lcpw/mods/modlauncher/api/TargetType<Lorg/objectweb/asm/tree/FieldNode;>;
 field public,static,final VALUES [Lcpw/mods/modlauncher/api/TargetType; [Lcpw/mods/modlauncher/api/TargetType<*>;
 method public getNodeType ()Ljava/lang/Class; ()Ljava/lang/Class<TT;>; -
 method public,static byName (Ljava/lang/String;)Lcpw/mods/modlauncher/api/TargetType; (Ljava/lang/String;)Lcpw/mods/modlauncher/api/TargetType<*>; -
 method public get (Ljava/util/Map;)Lcpw/mods/modlauncher/TransformList; (Ljava/util/Map<Lcpw/mods/modlauncher/api/TargetType<*>;Lcpw/mods/modlauncher/TransformList<*>;>;)Lcpw/mods/modlauncher/TransformList<TT;>; -
 method public mapSupplier (Ljava/util/Map;)Ljava/util/function/Supplier; (Ljava/util/Map<Lcpw/mods/modlauncher/api/TargetType<*>;Lcpw/mods/modlauncher/TransformList<*>;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/TransformList<TT;>;>; -
in 378
class cpw/mods/modlauncher/api/TransformerVoteResult 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/TransformerVoteResult;>;
 field public,static,final,enum YES Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum DEFER Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum NO Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum REJECT Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 method public,static values ()[Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
in 376
class cpw/mods/modlauncher/api/TransformerVoteResult 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/TransformerVoteResult;>;
 field public,static,final,enum YES Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum DEFER Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum NO Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum REJECT Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 method public,static values ()[Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
in 348
class cpw/mods/modlauncher/api/TransformerVoteResult 65 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/api/TransformerVoteResult;>;
 field public,static,final,enum YES Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum DEFER Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum NO Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 field public,static,final,enum REJECT Lcpw/mods/modlauncher/api/TransformerVoteResult; -
 method public,static values ()[Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/api/TransformerVoteResult; - -
in 386
class cpw/mods/modlauncher/api/TypesafeMap 60 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public get (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;)Ljava/util/Optional<TV;>; -
 method public computeIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;+TV;>;)TV; -
in 376
class cpw/mods/modlauncher/api/TypesafeMap 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public get (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;)Ljava/util/Optional<TV;>; -
 method public computeIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;+TV;>;)TV; -
in 387
class cpw/mods/modlauncher/api/TypesafeMap 60 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public get (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;)Ljava/util/Optional<TV;>; -
 method public computeIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;+TV;>;)TV; -
 method public putIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/lang/Object;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;TV;)TV; -
in 348
class cpw/mods/modlauncher/api/TypesafeMap 65 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public get (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)Ljava/util/Optional; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;)Ljava/util/Optional<TV;>; -
 method public computeIfAbsent (Lcpw/mods/modlauncher/api/TypesafeMap$Key;Ljava/util/function/Function;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;Ljava/util/function/Function<-Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;+TV;>;)TV; -
in 378
class cpw/mods/modlauncher/api/TypesafeMap$Key 60 public,final,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getOrCreate (Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class;)Lcpw/mods/modlauncher/api/TypesafeMap$Key; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class<-TV;>;)Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>; -
 method public,static getOrCreate (Ljava/util/function/Supplier;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap;>;Ljava/lang/String;Ljava/lang/Class<TV;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;>; -
 method public,final name ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)I - -
in 135
class cpw/mods/modlauncher/api/TypesafeMap$Key 52 public,final,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getOrCreate (Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class;)Lcpw/mods/modlauncher/api/TypesafeMap$Key; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class<TV;>;)Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>; -
 method public,static getOrCreate (Ljava/util/function/Supplier;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap;>;Ljava/lang/String;Ljava/lang/Class<TV;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;>; -
 method public,final name ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)I - -
in 394
class cpw/mods/modlauncher/api/TypesafeMap$Key 52 public,final,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getOrCreate (Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class;)Lcpw/mods/modlauncher/api/TypesafeMap$Key; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class<-TV;>;)Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>; -
 method public,static getOrCreate (Ljava/util/function/Supplier;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap;>;Ljava/lang/String;Ljava/lang/Class<TV;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;>; -
 method public,final name ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)I - -
in 348
class cpw/mods/modlauncher/api/TypesafeMap$Key 65 public,final,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getOrCreate (Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class;)Lcpw/mods/modlauncher/api/TypesafeMap$Key; <V:Ljava/lang/Object;>(Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class<-TV;>;)Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>; -
 method public,static getOrCreate (Ljava/util/function/Supplier;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap;>;Ljava/lang/String;Ljava/lang/Class<TV;>;)Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TV;>;>; -
 method public,final name ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lcpw/mods/modlauncher/api/TypesafeMap$Key;)I - -
in 378
class cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder 60 public,final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/Class<-TT;>;Ljava/lang/Class<*>;)V -
 method public get ()Lcpw/mods/modlauncher/api/TypesafeMap$Key; ()Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>; -
in 135
class cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder 52 public,final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/Class<TT;>;Ljava/lang/Class<*>;)V -
 method public get ()Lcpw/mods/modlauncher/api/TypesafeMap$Key; ()Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>; -
in 394
class cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder 52 public,final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/Class<-TT;>;Ljava/lang/Class<*>;)V -
 method public get ()Lcpw/mods/modlauncher/api/TypesafeMap$Key; ()Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>; -
in 348
class cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder 65 public,final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>;>;
 inner cpw/mods/modlauncher/api/TypesafeMap$KeyBuilder cpw/mods/modlauncher/api/TypesafeMap KeyBuilder public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/Class<-TT;>;Ljava/lang/Class<*>;)V -
 method public get ()Lcpw/mods/modlauncher/api/TypesafeMap$Key; ()Lcpw/mods/modlauncher/api/TypesafeMap$Key<TT;>; -
in 386
class cpw/mods/modlauncher/log/ExtraDataTextRenderer 60 public,super java/lang/Object org/apache/logging/log4j/core/pattern/TextRenderer -
 inner cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext cpw/mods/modlauncher/log/ExtraDataTextRenderer TransformerContext private,static
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public render (Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/String;)V - -
 method public render (Ljava/lang/StringBuilder;Ljava/lang/StringBuilder;)V - -
in 376
class cpw/mods/modlauncher/log/ExtraDataTextRenderer 52 public,super java/lang/Object org/apache/logging/log4j/core/pattern/TextRenderer -
 inner cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext cpw/mods/modlauncher/log/ExtraDataTextRenderer TransformerContext private,static
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public render (Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/String;)V - -
 method public render (Ljava/lang/StringBuilder;Ljava/lang/StringBuilder;)V - -
in 387
class cpw/mods/modlauncher/log/ExtraDataTextRenderer 60 public,super,deprecated java/lang/Object org/apache/logging/log4j/core/pattern/TextRenderer -
 inner cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext cpw/mods/modlauncher/log/ExtraDataTextRenderer TransformerContext private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public render (Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/String;)V - -
 method public render (Ljava/lang/StringBuilder;Ljava/lang/StringBuilder;)V - -
in 348
class cpw/mods/modlauncher/log/ExtraDataTextRenderer 65 public,super java/lang/Object org/apache/logging/log4j/core/pattern/TextRenderer -
 inner cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext cpw/mods/modlauncher/log/ExtraDataTextRenderer TransformerContext private,static
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public render (Ljava/lang/String;Ljava/lang/StringBuilder;Ljava/lang/String;)V - -
 method public render (Ljava/lang/StringBuilder;Ljava/lang/StringBuilder;)V - -
in 378
class cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext 60 super java/lang/Object - -
 inner cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext cpw/mods/modlauncher/log/ExtraDataTextRenderer TransformerContext private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public setClassName (Ljava/lang/String;)V - -
 method public getClassName ()Ljava/lang/String; - -
 method public setMethodName (Ljava/lang/String;)V - -
 method public getMethodName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 376
class cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext 52 super java/lang/Object - -
 inner cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext cpw/mods/modlauncher/log/ExtraDataTextRenderer TransformerContext private,static
 method public setClassName (Ljava/lang/String;)V - -
 method public getClassName ()Ljava/lang/String; - -
 method public setMethodName (Ljava/lang/String;)V - -
 method public getMethodName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext 65 super java/lang/Object - -
 inner cpw/mods/modlauncher/log/ExtraDataTextRenderer$TransformerContext cpw/mods/modlauncher/log/ExtraDataTextRenderer TransformerContext private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public setClassName (Ljava/lang/String;)V - -
 method public getClassName ()Ljava/lang/String; - -
 method public setMethodName (Ljava/lang/String;)V - -
 method public getMethodName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 397
class cpw/mods/modlauncher/log/MLClassLoaderContextSelector 60 public,super org/apache/logging/log4j/core/selector/ClassLoaderContextSelector - -
 method public <init> ()V - -
 method protected toContextMapKey (Ljava/lang/ClassLoader;)Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/log/MLClassLoaderContextSelector 65 public,super org/apache/logging/log4j/core/selector/ClassLoaderContextSelector - -
 method public <init> ()V - -
 method protected toContextMapKey (Ljava/lang/ClassLoader;)Ljava/lang/String; - -
in 386
class cpw/mods/modlauncher/log/TransformingThrowablePatternConverter 60 public,super org/apache/logging/log4j/core/pattern/ThrowablePatternConverter - -
 method protected <init> (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)V - -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lcpw/mods/modlauncher/log/TransformingThrowablePatternConverter; - -
 method public,static generateEnhancedStackTrace (Ljava/lang/Throwable;)Ljava/lang/String; - -
in 376
class cpw/mods/modlauncher/log/TransformingThrowablePatternConverter 52 public,super org/apache/logging/log4j/core/pattern/ThrowablePatternConverter - -
 method protected <init> (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)V - -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lcpw/mods/modlauncher/log/TransformingThrowablePatternConverter; - -
 method public,static generateEnhancedStackTrace (Ljava/lang/Throwable;)Ljava/lang/String; - -
in 387
class cpw/mods/modlauncher/log/TransformingThrowablePatternConverter 60 public,super org/apache/logging/log4j/core/pattern/ThrowablePatternConverter - -
 inner cpw/mods/modlauncher/api/ITransformerActivity$Type cpw/mods/modlauncher/api/ITransformerActivity Type public,static,final,enum
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)V - -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lcpw/mods/modlauncher/log/TransformingThrowablePatternConverter; - -
 method public,static,deprecated generateEnhancedStackTrace (Ljava/lang/Throwable;)Ljava/lang/String; - -
in 348
class cpw/mods/modlauncher/log/TransformingThrowablePatternConverter 65 public,super org/apache/logging/log4j/core/pattern/ThrowablePatternConverter - -
 method protected <init> (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)V - -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lcpw/mods/modlauncher/log/TransformingThrowablePatternConverter; - -
 method public,static generateEnhancedStackTrace (Ljava/lang/Throwable;)Ljava/lang/String; - -
in 381
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public processClassWithFlags (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)I - -
 method public offerResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public addResources (Ljava/util/List;)V (Ljava/util/List<Lcpw/mods/jarhandling/SecureJar;>;)V -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Lcpw/mods/modlauncher/api/NamedPath;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public customAuditConsumer (Ljava/lang/String;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/function/Consumer<[Ljava/lang/String;>;)V -
in 384
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public,abstract processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public addResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
in 188
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public,abstract processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public,deprecated addResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public addResources (Ljava/util/List;)V (Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/String;Ljava/nio/file/Path;>;>;)V -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Ljava/nio/file/Path;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
in 189
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public,abstract processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public,deprecated addResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public addResources (Ljava/util/List;)V (Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/String;Ljava/nio/file/Path;>;>;)V -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Ljava/nio/file/Path;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public customAuditConsumer (Ljava/lang/String;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/function/Consumer<[Ljava/lang/String;>;)V -
in 190
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public processClassWithFlags (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)I - -
 method public offerResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public addResources (Ljava/util/List;)V (Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/String;Ljava/nio/file/Path;>;>;)V -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Ljava/nio/file/Path;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public customAuditConsumer (Ljava/lang/String;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/function/Consumer<[Ljava/lang/String;>;)V -
in 380
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public processClassWithFlags (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)I - -
 method public offerResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public addResources (Ljava/util/List;)V (Ljava/util/List<Lcpw/mods/jarhandling/SecureJar;>;)V -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;)V - -
 method public,deprecated initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Lcpw/mods/modlauncher/api/NamedPath;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public customAuditConsumer (Ljava/lang/String;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/function/Consumer<[Ljava/lang/String;>;)V -
in 348
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public processClassWithFlags (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)I - -
 method public offerResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public addResources (Ljava/util/List;)V (Ljava/util/List<Lcpw/mods/jarhandling/SecureJar;>;)V -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Lcpw/mods/modlauncher/api/NamedPath;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public customAuditConsumer (Ljava/lang/String;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/function/Consumer<[Ljava/lang/String;>;)V -
in 378
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 field public,static,final NO_REWRITE I - I0
 field public,static,final SIMPLE_REWRITE I - I256
 field public,static,final COMPUTE_MAXS I - I1
 field public,static,final COMPUTE_FRAMES I - I2
 method public <init> ()V - -
in 190
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags 52 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 field public,static,final NO_REWRITE I - I0
 field public,static,final SIMPLE_REWRITE I - I256
 field public,static,final COMPUTE_MAXS I - I1
 field public,static,final COMPUTE_FRAMES I - I2
 method public <init> ()V - -
in 348
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags 65 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ComputeFlags cpw/mods/modlauncher/serviceapi/ILaunchPluginService ComputeFlags public,static
 field public,static,final NO_REWRITE I - I0
 field public,static,final SIMPLE_REWRITE I - I256
 field public,static,final COMPUTE_MAXS I - I1
 field public,static,final COMPUTE_FRAMES I - I2
 method public <init> ()V - -
in 378
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader 60 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 method public,abstract buildTransformedClassNodeFor (Ljava/lang/String;)[B - java/lang/ClassNotFoundException
in 385
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 method public,abstract buildTransformedClassNodeFor (Ljava/lang/String;)[B - java/lang/ClassNotFoundException
in 348
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader 65 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 method public,abstract buildTransformedClassNodeFor (Ljava/lang/String;)[B - java/lang/ClassNotFoundException
in 378
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>;
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 field public,static,final,enum BEFORE Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; -
 field public,static,final,enum AFTER Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; -
 method public,static values ()[Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; - -
in 376
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>;
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 field public,static,final,enum BEFORE Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; -
 field public,static,final,enum AFTER Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; -
 method public,static values ()[Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; - -
in 348
class cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase 65 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>;
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 field public,static,final,enum BEFORE Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; -
 field public,static,final,enum AFTER Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; -
 method public,static values ()[Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; - -
 method public,static valueOf (Ljava/lang/String;)Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase; - -
in 0
class cpw/mods/modlauncher/serviceapi/ITransformerDiscoveryService 60 public,interface,abstract java/lang/Object - -
 method public,abstract candidates (Ljava/nio/file/Path;)Ljava/util/List; (Ljava/nio/file/Path;)Ljava/util/List<Lcpw/mods/modlauncher/api/NamedPath;>; -
 method public candidates (Ljava/nio/file/Path;Ljava/lang/String;)Ljava/util/List; (Ljava/nio/file/Path;Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/NamedPath;>; -
in 379
class cpw/mods/modlauncher/serviceapi/ITransformerDiscoveryService 60 public,interface,abstract java/lang/Object - -
 method public,abstract candidates (Ljava/nio/file/Path;)Ljava/util/List; (Ljava/nio/file/Path;)Ljava/util/List<Lcpw/mods/modlauncher/api/NamedPath;>; -
 method public candidates (Ljava/nio/file/Path;Ljava/lang/String;)Ljava/util/List; (Ljava/nio/file/Path;Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/NamedPath;>; -
 method public earlyInitialization (Ljava/lang/String;[Ljava/lang/String;)V - -
in 376
class cpw/mods/modlauncher/serviceapi/ITransformerDiscoveryService 52 public,interface,abstract java/lang/Object - -
 method public,abstract candidates (Ljava/nio/file/Path;)Ljava/util/List; (Ljava/nio/file/Path;)Ljava/util/List<Ljava/nio/file/Path;>; -
in 348
class cpw/mods/modlauncher/serviceapi/ITransformerDiscoveryService 65 public,interface,abstract java/lang/Object - -
 method public,abstract candidates (Ljava/nio/file/Path;)Ljava/util/List; (Ljava/nio/file/Path;)Ljava/util/List<Lcpw/mods/modlauncher/api/NamedPath;>; -
 method public candidates (Ljava/nio/file/Path;Ljava/lang/String;)Ljava/util/List; (Ljava/nio/file/Path;Ljava/lang/String;)Ljava/util/List<Lcpw/mods/modlauncher/api/NamedPath;>; -
 method public earlyInitialization (Ljava/lang/String;[Ljava/lang/String;)V - -
in 390
class cpw/mods/modlauncher/util/ModuleExceptionEnhancer 60 public,super java/lang/Object - -
 inner cpw/mods/modlauncher/util/ModuleExceptionEnhancer$Message cpw/mods/modlauncher/util/ModuleExceptionEnhancer Message private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static enhance (Ljava/lang/RuntimeException;[Lcpw/mods/jarhandling/SecureJar;)Ljava/lang/RuntimeException; - -
in 390
class cpw/mods/modlauncher/util/ModuleExceptionEnhancer$Message 60 final,super java/lang/Record - -
 inner cpw/mods/modlauncher/util/ModuleExceptionEnhancer$Message cpw/mods/modlauncher/util/ModuleExceptionEnhancer Message private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public count ()I - -
 method public pattern ()Ljava/util/regex/Pattern; - -
in 381
class cpw/mods/modlauncher/util/ServiceLoaderUtils 60 public,final,super java/lang/Object - -
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static streamServiceLoader (Ljava/util/function/Supplier;Ljava/util/function/Consumer;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<Ljava/util/ServiceLoader<TT;>;>;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static streamWithErrorHandling (Ljava/util/ServiceLoader;Ljava/util/function/Consumer;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static fileNameFor (Ljava/lang/Class;)Ljava/lang/String; (Ljava/lang/Class<*>;)Ljava/lang/String; -
in 380
class cpw/mods/modlauncher/util/ServiceLoaderUtils 60 public,final,super,deprecated java/lang/Object - -
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static streamServiceLoader (Ljava/util/function/Supplier;Ljava/util/function/Consumer;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<Ljava/util/ServiceLoader<TT;>;>;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static streamWithErrorHandling (Ljava/util/ServiceLoader;Ljava/util/function/Consumer;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static fileNameFor (Ljava/lang/Class;)Ljava/lang/String; (Ljava/lang/Class<*>;)Ljava/lang/String; -
in 348
class cpw/mods/modlauncher/util/ServiceLoaderUtils 65 public,final,super java/lang/Object - -
 inner java/util/ServiceLoader$Provider java/util/ServiceLoader Provider public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static streamServiceLoader (Ljava/util/function/Supplier;Ljava/util/function/Consumer;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<Ljava/util/ServiceLoader<TT;>;>;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static streamWithErrorHandling (Ljava/util/ServiceLoader;Ljava/util/function/Consumer;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/ServiceLoader<TT;>;Ljava/util/function/Consumer<Ljava/util/ServiceConfigurationError;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static fileNameFor (Ljava/lang/Class;)Ljava/lang/String; (Ljava/lang/Class<*>;)Ljava/lang/String; -
in 104
class cpw/mods/niofs/union/UnionFileSystem 60 public,super java/nio/file/FileSystem - -
 inner cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata cpw/mods/niofs/union/UnionFileSystem EmbeddedFileSystemMetadata private,static,final
 inner java/nio/file/DirectoryStream$Filter java/nio/file/DirectoryStream Filter public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public getFilesystemFilter ()Ljava/util/function/BiPredicate; ()Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>; -
 method public,varargs <init> (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/util/function/BiPredicate;Ljava/lang/String;[Ljava/nio/file/Path;)V (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;Ljava/lang/String;[Ljava/nio/file/Path;)V -
 method public provider ()Lcpw/mods/niofs/union/UnionFileSystemProvider; - -
 method public close ()V - -
 method public isOpen ()Z - -
 method public isReadOnly ()Z - -
 method public getSeparator ()Ljava/lang/String; - -
 method public getRootDirectories ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/Path;>; -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileStores ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/FileStore;>; -
 method public supportedFileAttributeViews ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getPathMatcher (Ljava/lang/String;)Ljava/nio/file/PathMatcher; - -
 method public getUserPrincipalLookupService ()Ljava/nio/file/attribute/UserPrincipalLookupService; - -
 method public newWatchService ()Ljava/nio/file/WatchService; - -
 method public,varargs readAttributes (Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs checkAccess (Lcpw/mods/niofs/union/UnionPath;[Ljava/nio/file/AccessMode;)V - java/io/IOException
 method public newReadByteChannel (Lcpw/mods/niofs/union/UnionPath;)Ljava/nio/channels/SeekableByteChannel; - java/io/IOException
 method public newDirStream (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter;)Ljava/nio/file/DirectoryStream; (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter<-Ljava/nio/file/Path;>;)Ljava/nio/file/DirectoryStream<Ljava/nio/file/Path;>; java/io/IOException
in 350
class cpw/mods/niofs/union/UnionFileSystem 60 public,super java/nio/file/FileSystem - -
 inner cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata cpw/mods/niofs/union/UnionFileSystem EmbeddedFileSystemMetadata private,static,final
 inner cpw/mods/niofs/union/UnionFileSystem$UncheckedIOException cpw/mods/niofs/union/UnionFileSystem UncheckedIOException private,static
 inner cpw/mods/niofs/union/UnionFileSystem$NoSuchFileException cpw/mods/niofs/union/UnionFileSystem NoSuchFileException private,static
 inner java/nio/file/DirectoryStream$Filter java/nio/file/DirectoryStream Filter public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public getFilesystemFilter ()Ljava/util/function/BiPredicate; ()Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>; -
 method public,varargs <init> (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/util/function/BiPredicate;Ljava/lang/String;[Ljava/nio/file/Path;)V (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;Ljava/lang/String;[Ljava/nio/file/Path;)V -
 method public provider ()Lcpw/mods/niofs/union/UnionFileSystemProvider; - -
 method public close ()V - -
 method public isOpen ()Z - -
 method public isReadOnly ()Z - -
 method public getSeparator ()Ljava/lang/String; - -
 method public getRootDirectories ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/Path;>; -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileStores ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/FileStore;>; -
 method public supportedFileAttributeViews ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getPathMatcher (Ljava/lang/String;)Ljava/nio/file/PathMatcher; - -
 method public getUserPrincipalLookupService ()Ljava/nio/file/attribute/UserPrincipalLookupService; - -
 method public newWatchService ()Ljava/nio/file/WatchService; - -
 method public,varargs readAttributes (Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs checkAccess (Lcpw/mods/niofs/union/UnionPath;[Ljava/nio/file/AccessMode;)V - java/io/IOException
 method public newReadByteChannel (Lcpw/mods/niofs/union/UnionPath;)Ljava/nio/channels/SeekableByteChannel; - java/io/IOException
 method public newDirStream (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter;)Ljava/nio/file/DirectoryStream; (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter<-Ljava/nio/file/Path;>;)Ljava/nio/file/DirectoryStream<Ljava/nio/file/Path;>; java/io/IOException
in 273
class cpw/mods/niofs/union/UnionFileSystem 60 public,super java/nio/file/FileSystem - -
 inner cpw/mods/niofs/union/UnionFileSystem$UncheckedIOException cpw/mods/niofs/union/UnionFileSystem UncheckedIOException private,static
 inner cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata cpw/mods/niofs/union/UnionFileSystem EmbeddedFileSystemMetadata private,static,final
 inner cpw/mods/niofs/union/UnionFileSystem$NoSuchFileException cpw/mods/niofs/union/UnionFileSystem NoSuchFileException private,static
 inner java/nio/file/DirectoryStream$Filter java/nio/file/DirectoryStream Filter public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public buildInputStream (Lcpw/mods/niofs/union/UnionPath;)Ljava/io/InputStream; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public getFilesystemFilter ()Ljava/util/function/BiPredicate; ()Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>; -
 method public,varargs <init> (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/util/function/BiPredicate;Ljava/lang/String;[Ljava/nio/file/Path;)V (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;Ljava/lang/String;[Ljava/nio/file/Path;)V -
 method public provider ()Lcpw/mods/niofs/union/UnionFileSystemProvider; - -
 method public close ()V - -
 method public isOpen ()Z - -
 method public isReadOnly ()Z - -
 method public getSeparator ()Ljava/lang/String; - -
 method public getRootDirectories ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/Path;>; -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileStores ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/FileStore;>; -
 method public supportedFileAttributeViews ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getPathMatcher (Ljava/lang/String;)Ljava/nio/file/PathMatcher; - -
 method public getUserPrincipalLookupService ()Ljava/nio/file/attribute/UserPrincipalLookupService; - -
 method public newWatchService ()Ljava/nio/file/WatchService; - -
 method public,varargs readAttributes (Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs checkAccess (Lcpw/mods/niofs/union/UnionPath;[Ljava/nio/file/AccessMode;)V - java/io/IOException
 method public newReadByteChannel (Lcpw/mods/niofs/union/UnionPath;)Ljava/nio/channels/SeekableByteChannel; - java/io/IOException
 method public newDirStream (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter;)Ljava/nio/file/DirectoryStream; (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter<-Ljava/nio/file/Path;>;)Ljava/nio/file/DirectoryStream<Ljava/nio/file/Path;>; java/io/IOException
in 348
class cpw/mods/niofs/union/UnionFileSystem 65 public,super java/nio/file/FileSystem - -
 inner cpw/mods/niofs/union/UnionFileSystem$UncheckedIOException cpw/mods/niofs/union/UnionFileSystem UncheckedIOException private,static
 inner cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata cpw/mods/niofs/union/UnionFileSystem EmbeddedFileSystemMetadata private,static,final
 inner cpw/mods/niofs/union/UnionFileSystem$NoSuchFileException cpw/mods/niofs/union/UnionFileSystem NoSuchFileException private,static
 inner java/nio/file/DirectoryStream$Filter java/nio/file/DirectoryStream Filter public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public buildInputStream (Lcpw/mods/niofs/union/UnionPath;)Ljava/io/InputStream; - -
 method public getPrimaryPath ()Ljava/nio/file/Path; - -
 method public getFilesystemFilter ()Lcpw/mods/niofs/union/UnionPathFilter; - -
 method public,varargs <init> (Lcpw/mods/niofs/union/UnionFileSystemProvider;Lcpw/mods/niofs/union/UnionPathFilter;Ljava/lang/String;[Ljava/nio/file/Path;)V - -
 method public provider ()Lcpw/mods/niofs/union/UnionFileSystemProvider; - -
 method public close ()V - java/io/IOException
 method public isOpen ()Z - -
 method public isReadOnly ()Z - -
 method public getSeparator ()Ljava/lang/String; - -
 method public getRootDirectories ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/Path;>; -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileStores ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/nio/file/FileStore;>; -
 method public supportedFileAttributeViews ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,varargs getPath (Ljava/lang/String;[Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getPathMatcher (Ljava/lang/String;)Ljava/nio/file/PathMatcher; - -
 method public getUserPrincipalLookupService ()Ljava/nio/file/attribute/UserPrincipalLookupService; - -
 method public newWatchService ()Ljava/nio/file/WatchService; - -
 method public,varargs readAttributes (Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs readAttributesIfExists (Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Lcpw/mods/niofs/union/UnionPath;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs checkAccess (Lcpw/mods/niofs/union/UnionPath;[Ljava/nio/file/AccessMode;)V - java/io/IOException
 method public exists (Lcpw/mods/niofs/union/UnionPath;)Z - -
 method public newReadByteChannel (Lcpw/mods/niofs/union/UnionPath;)Ljava/nio/channels/SeekableByteChannel; - java/io/IOException
 method public newDirStream (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter;)Ljava/nio/file/DirectoryStream; (Lcpw/mods/niofs/union/UnionPath;Ljava/nio/file/DirectoryStream$Filter<-Ljava/nio/file/Path;>;)Ljava/nio/file/DirectoryStream<Ljava/nio/file/Path;>; java/io/IOException
in 398
class cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata 60 final,super java/lang/Record - -
 inner cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata cpw/mods/niofs/union/UnionFileSystem EmbeddedFileSystemMetadata private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public path ()Ljava/nio/file/Path; - -
 method public fs ()Ljava/nio/file/FileSystem; - -
in 273
class cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata 60 final,super java/lang/Record - -
 inner cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata cpw/mods/niofs/union/UnionFileSystem EmbeddedFileSystemMetadata private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public path ()Ljava/nio/file/Path; - -
 method public fs ()Ljava/nio/file/FileSystem; - -
 method public fsCh ()Ljava/nio/channels/SeekableByteChannel; - -
in 348
class cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata 65 final,super java/lang/Record - -
 inner cpw/mods/niofs/union/UnionFileSystem$EmbeddedFileSystemMetadata cpw/mods/niofs/union/UnionFileSystem EmbeddedFileSystemMetadata private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public path ()Ljava/nio/file/Path; - -
 method public fs ()Ljava/nio/file/FileSystem; - -
 method public fsCh ()Ljava/nio/channels/SeekableByteChannel; - -
in 374
class cpw/mods/niofs/union/UnionFileSystem$NoSuchFileException 60 super java/nio/file/NoSuchFileException - -
 inner cpw/mods/niofs/union/UnionFileSystem$NoSuchFileException cpw/mods/niofs/union/UnionFileSystem NoSuchFileException private,static
 method public <init> (Ljava/lang/String;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 348
class cpw/mods/niofs/union/UnionFileSystem$NoSuchFileException 65 super java/nio/file/NoSuchFileException - -
 inner cpw/mods/niofs/union/UnionFileSystem$NoSuchFileException cpw/mods/niofs/union/UnionFileSystem NoSuchFileException private,static
 method public <init> (Ljava/lang/String;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 374
class cpw/mods/niofs/union/UnionFileSystem$UncheckedIOException 60 super java/io/UncheckedIOException - -
 inner cpw/mods/niofs/union/UnionFileSystem$UncheckedIOException cpw/mods/niofs/union/UnionFileSystem UncheckedIOException private,static
 method public <init> (Ljava/io/IOException;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 348
class cpw/mods/niofs/union/UnionFileSystem$UncheckedIOException 65 super java/io/UncheckedIOException - -
 inner cpw/mods/niofs/union/UnionFileSystem$UncheckedIOException cpw/mods/niofs/union/UnionFileSystem UncheckedIOException private,static
 method public <init> (Ljava/io/IOException;)V - -
 method public <init> (Ljava/lang/String;Ljava/io/IOException;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 104
class cpw/mods/niofs/union/UnionFileSystemProvider 60 public,super java/nio/file/spi/FileSystemProvider - -
 inner java/nio/file/DirectoryStream$Filter java/nio/file/DirectoryStream Filter public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getScheme ()Ljava/lang/String; - -
 method protected uriToPath (Ljava/net/URI;)Ljava/nio/file/Path; - -
 method public newFileSystem (Ljava/net/URI;Ljava/util/Map;)Ljava/nio/file/FileSystem; (Ljava/net/URI;Ljava/util/Map<Ljava/lang/String;*>;)Ljava/nio/file/FileSystem; java/io/IOException
 method public newFileSystem (Ljava/nio/file/Path;Ljava/util/Map;)Ljava/nio/file/FileSystem; (Ljava/nio/file/Path;Ljava/util/Map<Ljava/lang/String;*>;)Ljava/nio/file/FileSystem; java/io/IOException
 method public,varargs newFileSystem (Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/niofs/union/UnionFileSystem; (Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/niofs/union/UnionFileSystem; -
 method public getPath (Ljava/net/URI;)Ljava/nio/file/Path; - -
 method public getFileSystem (Ljava/net/URI;)Ljava/nio/file/FileSystem; - -
 method public,varargs newByteChannel (Ljava/nio/file/Path;Ljava/util/Set;[Ljava/nio/file/attribute/FileAttribute;)Ljava/nio/channels/SeekableByteChannel; (Ljava/nio/file/Path;Ljava/util/Set<+Ljava/nio/file/OpenOption;>;[Ljava/nio/file/attribute/FileAttribute<*>;)Ljava/nio/channels/SeekableByteChannel; java/io/IOException
 method public newDirectoryStream (Ljava/nio/file/Path;Ljava/nio/file/DirectoryStream$Filter;)Ljava/nio/file/DirectoryStream; (Ljava/nio/file/Path;Ljava/nio/file/DirectoryStream$Filter<-Ljava/nio/file/Path;>;)Ljava/nio/file/DirectoryStream<Ljava/nio/file/Path;>; java/io/IOException
 method public,varargs createDirectory (Ljava/nio/file/Path;[Ljava/nio/file/attribute/FileAttribute;)V (Ljava/nio/file/Path;[Ljava/nio/file/attribute/FileAttribute<*>;)V java/io/IOException
 method public delete (Ljava/nio/file/Path;)V - java/io/IOException
 method public,varargs copy (Ljava/nio/file/Path;Ljava/nio/file/Path;[Ljava/nio/file/CopyOption;)V - java/io/IOException
 method public,varargs move (Ljava/nio/file/Path;Ljava/nio/file/Path;[Ljava/nio/file/CopyOption;)V - java/io/IOException
 method public isSameFile (Ljava/nio/file/Path;Ljava/nio/file/Path;)Z - java/io/IOException
 method public isHidden (Ljava/nio/file/Path;)Z - java/io/IOException
 method public getFileStore (Ljava/nio/file/Path;)Ljava/nio/file/FileStore; - java/io/IOException
 method public,varargs checkAccess (Ljava/nio/file/Path;[Ljava/nio/file/AccessMode;)V - java/io/IOException
 method public,varargs getFileAttributeView (Ljava/nio/file/Path;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/FileAttributeView; <V::Ljava/nio/file/attribute/FileAttributeView;>(Ljava/nio/file/Path;Ljava/lang/Class<TV;>;[Ljava/nio/file/LinkOption;)TV; -
 method public,varargs readAttributes (Ljava/nio/file/Path;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Ljava/nio/file/Path;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs readAttributes (Ljava/nio/file/Path;Ljava/lang/String;[Ljava/nio/file/LinkOption;)Ljava/util/Map; (Ljava/nio/file/Path;Ljava/lang/String;[Ljava/nio/file/LinkOption;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; java/io/IOException
 method public,varargs setAttribute (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/Object;[Ljava/nio/file/LinkOption;)V - java/io/IOException
in 374
class cpw/mods/niofs/union/UnionFileSystemProvider 60 public,super java/nio/file/spi/FileSystemProvider - -
 inner java/nio/file/DirectoryStream$Filter java/nio/file/DirectoryStream Filter public,static,interface,abstract
 inner cpw/mods/niofs/union/UnionFileSystemProvider$UnionBasicFileAttributeView cpw/mods/niofs/union/UnionFileSystemProvider UnionBasicFileAttributeView private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getScheme ()Ljava/lang/String; - -
 method protected uriToPath (Ljava/net/URI;)Ljava/nio/file/Path; - -
 method public newFileSystem (Ljava/net/URI;Ljava/util/Map;)Ljava/nio/file/FileSystem; (Ljava/net/URI;Ljava/util/Map<Ljava/lang/String;*>;)Ljava/nio/file/FileSystem; java/io/IOException
 method public newFileSystem (Ljava/nio/file/Path;Ljava/util/Map;)Ljava/nio/file/FileSystem; (Ljava/nio/file/Path;Ljava/util/Map<Ljava/lang/String;*>;)Ljava/nio/file/FileSystem; java/io/IOException
 method public,varargs newFileSystem (Ljava/util/function/BiPredicate;[Ljava/nio/file/Path;)Lcpw/mods/niofs/union/UnionFileSystem; (Ljava/util/function/BiPredicate<Ljava/lang/String;Ljava/lang/String;>;[Ljava/nio/file/Path;)Lcpw/mods/niofs/union/UnionFileSystem; -
 method public getPath (Ljava/net/URI;)Ljava/nio/file/Path; - -
 method public getFileSystem (Ljava/net/URI;)Ljava/nio/file/FileSystem; - -
 method public,varargs newByteChannel (Ljava/nio/file/Path;Ljava/util/Set;[Ljava/nio/file/attribute/FileAttribute;)Ljava/nio/channels/SeekableByteChannel; (Ljava/nio/file/Path;Ljava/util/Set<+Ljava/nio/file/OpenOption;>;[Ljava/nio/file/attribute/FileAttribute<*>;)Ljava/nio/channels/SeekableByteChannel; java/io/IOException
 method public newDirectoryStream (Ljava/nio/file/Path;Ljava/nio/file/DirectoryStream$Filter;)Ljava/nio/file/DirectoryStream; (Ljava/nio/file/Path;Ljava/nio/file/DirectoryStream$Filter<-Ljava/nio/file/Path;>;)Ljava/nio/file/DirectoryStream<Ljava/nio/file/Path;>; java/io/IOException
 method public,varargs createDirectory (Ljava/nio/file/Path;[Ljava/nio/file/attribute/FileAttribute;)V (Ljava/nio/file/Path;[Ljava/nio/file/attribute/FileAttribute<*>;)V java/io/IOException
 method public delete (Ljava/nio/file/Path;)V - java/io/IOException
 method public,varargs copy (Ljava/nio/file/Path;Ljava/nio/file/Path;[Ljava/nio/file/CopyOption;)V - java/io/IOException
 method public,varargs move (Ljava/nio/file/Path;Ljava/nio/file/Path;[Ljava/nio/file/CopyOption;)V - java/io/IOException
 method public isSameFile (Ljava/nio/file/Path;Ljava/nio/file/Path;)Z - java/io/IOException
 method public isHidden (Ljava/nio/file/Path;)Z - java/io/IOException
 method public getFileStore (Ljava/nio/file/Path;)Ljava/nio/file/FileStore; - java/io/IOException
 method public,varargs checkAccess (Ljava/nio/file/Path;[Ljava/nio/file/AccessMode;)V - java/io/IOException
 method public,varargs getFileAttributeView (Ljava/nio/file/Path;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/FileAttributeView; <V::Ljava/nio/file/attribute/FileAttributeView;>(Ljava/nio/file/Path;Ljava/lang/Class<TV;>;[Ljava/nio/file/LinkOption;)TV; -
 method public,varargs readAttributes (Ljava/nio/file/Path;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Ljava/nio/file/Path;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs readAttributes (Ljava/nio/file/Path;Ljava/lang/String;[Ljava/nio/file/LinkOption;)Ljava/util/Map; (Ljava/nio/file/Path;Ljava/lang/String;[Ljava/nio/file/LinkOption;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; java/io/IOException
 method public,varargs setAttribute (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/Object;[Ljava/nio/file/LinkOption;)V - java/io/IOException
in 348
class cpw/mods/niofs/union/UnionFileSystemProvider 65 public,super java/nio/file/spi/FileSystemProvider - -
 inner java/nio/file/DirectoryStream$Filter java/nio/file/DirectoryStream Filter public,static,interface,abstract
 inner cpw/mods/niofs/union/UnionFileSystemProvider$UnionBasicFileAttributeView cpw/mods/niofs/union/UnionFileSystemProvider UnionBasicFileAttributeView private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getScheme ()Ljava/lang/String; - -
 method protected uriToPath (Ljava/net/URI;)Ljava/nio/file/Path; - -
 method public newFileSystem (Ljava/net/URI;Ljava/util/Map;)Ljava/nio/file/FileSystem; (Ljava/net/URI;Ljava/util/Map<Ljava/lang/String;*>;)Ljava/nio/file/FileSystem; java/io/IOException
 method public newFileSystem (Ljava/nio/file/Path;Ljava/util/Map;)Ljava/nio/file/FileSystem; (Ljava/nio/file/Path;Ljava/util/Map<Ljava/lang/String;*>;)Ljava/nio/file/FileSystem; java/io/IOException
 method public,varargs newFileSystem (Lcpw/mods/niofs/union/UnionPathFilter;[Ljava/nio/file/Path;)Lcpw/mods/niofs/union/UnionFileSystem; - -
 method public getPath (Ljava/net/URI;)Ljava/nio/file/Path; - -
 method public getFileSystem (Ljava/net/URI;)Ljava/nio/file/FileSystem; - -
 method public,varargs newByteChannel (Ljava/nio/file/Path;Ljava/util/Set;[Ljava/nio/file/attribute/FileAttribute;)Ljava/nio/channels/SeekableByteChannel; (Ljava/nio/file/Path;Ljava/util/Set<+Ljava/nio/file/OpenOption;>;[Ljava/nio/file/attribute/FileAttribute<*>;)Ljava/nio/channels/SeekableByteChannel; java/io/IOException
 method public newDirectoryStream (Ljava/nio/file/Path;Ljava/nio/file/DirectoryStream$Filter;)Ljava/nio/file/DirectoryStream; (Ljava/nio/file/Path;Ljava/nio/file/DirectoryStream$Filter<-Ljava/nio/file/Path;>;)Ljava/nio/file/DirectoryStream<Ljava/nio/file/Path;>; java/io/IOException
 method public,varargs createDirectory (Ljava/nio/file/Path;[Ljava/nio/file/attribute/FileAttribute;)V (Ljava/nio/file/Path;[Ljava/nio/file/attribute/FileAttribute<*>;)V java/io/IOException
 method public delete (Ljava/nio/file/Path;)V - java/io/IOException
 method public,varargs copy (Ljava/nio/file/Path;Ljava/nio/file/Path;[Ljava/nio/file/CopyOption;)V - java/io/IOException
 method public,varargs move (Ljava/nio/file/Path;Ljava/nio/file/Path;[Ljava/nio/file/CopyOption;)V - java/io/IOException
 method public isSameFile (Ljava/nio/file/Path;Ljava/nio/file/Path;)Z - java/io/IOException
 method public isHidden (Ljava/nio/file/Path;)Z - java/io/IOException
 method public getFileStore (Ljava/nio/file/Path;)Ljava/nio/file/FileStore; - java/io/IOException
 method public,varargs checkAccess (Ljava/nio/file/Path;[Ljava/nio/file/AccessMode;)V - java/io/IOException
 method public,varargs getFileAttributeView (Ljava/nio/file/Path;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/FileAttributeView; <V::Ljava/nio/file/attribute/FileAttributeView;>(Ljava/nio/file/Path;Ljava/lang/Class<TV;>;[Ljava/nio/file/LinkOption;)TV; -
 method public,varargs readAttributes (Ljava/nio/file/Path;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Ljava/nio/file/Path;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs readAttributes (Ljava/nio/file/Path;Ljava/lang/String;[Ljava/nio/file/LinkOption;)Ljava/util/Map; (Ljava/nio/file/Path;Ljava/lang/String;[Ljava/nio/file/LinkOption;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; java/io/IOException
 method public,varargs setAttribute (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/Object;[Ljava/nio/file/LinkOption;)V - java/io/IOException
 method public,varargs readAttributesIfExists (Ljava/nio/file/Path;Ljava/lang/Class;[Ljava/nio/file/LinkOption;)Ljava/nio/file/attribute/BasicFileAttributes; <A::Ljava/nio/file/attribute/BasicFileAttributes;>(Ljava/nio/file/Path;Ljava/lang/Class<TA;>;[Ljava/nio/file/LinkOption;)TA; java/io/IOException
 method public,varargs exists (Ljava/nio/file/Path;[Ljava/nio/file/LinkOption;)Z - -
in 374
class cpw/mods/niofs/union/UnionFileSystemProvider$UnionBasicFileAttributeView 60 super java/lang/Object java/nio/file/attribute/BasicFileAttributeView -
 inner cpw/mods/niofs/union/UnionFileSystemProvider$UnionBasicFileAttributeView cpw/mods/niofs/union/UnionFileSystemProvider UnionBasicFileAttributeView private
 method public <init> (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/nio/file/Path;[Ljava/nio/file/LinkOption;)V - -
 method public name ()Ljava/lang/String; - -
 method public readAttributes ()Ljava/nio/file/attribute/BasicFileAttributes; - java/io/IOException
 method public setTimes (Ljava/nio/file/attribute/FileTime;Ljava/nio/file/attribute/FileTime;Ljava/nio/file/attribute/FileTime;)V - -
in 348
class cpw/mods/niofs/union/UnionFileSystemProvider$UnionBasicFileAttributeView 65 super java/lang/Object java/nio/file/attribute/BasicFileAttributeView -
 inner cpw/mods/niofs/union/UnionFileSystemProvider$UnionBasicFileAttributeView cpw/mods/niofs/union/UnionFileSystemProvider UnionBasicFileAttributeView private
 method public <init> (Lcpw/mods/niofs/union/UnionFileSystemProvider;Ljava/nio/file/Path;[Ljava/nio/file/LinkOption;)V - -
 method public name ()Ljava/lang/String; - -
 method public readAttributes ()Ljava/nio/file/attribute/BasicFileAttributes; - java/io/IOException
 method public setTimes (Ljava/nio/file/attribute/FileTime;Ljava/nio/file/attribute/FileTime;Ljava/nio/file/attribute/FileTime;)V - -
in 104
class cpw/mods/niofs/union/UnionPath 60 public,super java/lang/Object java/nio/file/Path -
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner java/nio/file/WatchEvent$Modifier java/nio/file/WatchEvent Modifier public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFileSystem ()Lcpw/mods/niofs/union/UnionFileSystem; - -
 method public isAbsolute ()Z - -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileName ()Ljava/nio/file/Path; - -
 method public getParent ()Ljava/nio/file/Path; - -
 method public getNameCount ()I - -
 method public getName (I)Ljava/nio/file/Path; - -
 method public subpath (II)Ljava/nio/file/Path; - -
 method public startsWith (Ljava/nio/file/Path;)Z - -
 method public endsWith (Ljava/nio/file/Path;)Z - -
 method public normalize ()Ljava/nio/file/Path; - -
 method public resolve (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public relativize (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public toUri ()Ljava/net/URI; - -
 method public toAbsolutePath ()Ljava/nio/file/Path; - -
 method public,varargs toRealPath ([Ljava/nio/file/LinkOption;)Ljava/nio/file/Path; - java/io/IOException
 method public,varargs register (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind<*>;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; java/io/IOException
 method public compareTo (Ljava/nio/file/Path;)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 350
class cpw/mods/niofs/union/UnionPath 60 public,super java/lang/Object java/nio/file/Path -
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner java/nio/file/WatchEvent$Modifier java/nio/file/WatchEvent Modifier public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFileSystem ()Lcpw/mods/niofs/union/UnionFileSystem; - -
 method public isAbsolute ()Z - -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileName ()Ljava/nio/file/Path; - -
 method public getParent ()Ljava/nio/file/Path; - -
 method public getNameCount ()I - -
 method public getName (I)Ljava/nio/file/Path; - -
 method public subpath (II)Lcpw/mods/niofs/union/UnionPath; - -
 method public startsWith (Ljava/nio/file/Path;)Z - -
 method public endsWith (Ljava/nio/file/Path;)Z - -
 method public normalize ()Ljava/nio/file/Path; - -
 method public resolve (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public relativize (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public toUri ()Ljava/net/URI; - -
 method public toAbsolutePath ()Ljava/nio/file/Path; - -
 method public,varargs toRealPath ([Ljava/nio/file/LinkOption;)Ljava/nio/file/Path; - java/io/IOException
 method public,varargs register (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind<*>;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; java/io/IOException
 method public compareTo (Ljava/nio/file/Path;)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 273
class cpw/mods/niofs/union/UnionPath 60 public,super java/lang/Object java/nio/file/Path -
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner java/nio/file/WatchEvent$Modifier java/nio/file/WatchEvent Modifier public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFileSystem ()Lcpw/mods/niofs/union/UnionFileSystem; - -
 method public isAbsolute ()Z - -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileName ()Ljava/nio/file/Path; - -
 method public getParent ()Ljava/nio/file/Path; - -
 method public getNameCount ()I - -
 method public getName (I)Ljava/nio/file/Path; - -
 method public subpath (II)Lcpw/mods/niofs/union/UnionPath; - -
 method public startsWith (Ljava/nio/file/Path;)Z - -
 method public endsWith (Ljava/nio/file/Path;)Z - -
 method public normalize ()Ljava/nio/file/Path; - -
 method public resolve (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public relativize (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public toUri ()Ljava/net/URI; - -
 method public toAbsolutePath ()Ljava/nio/file/Path; - -
 method public,varargs toRealPath ([Ljava/nio/file/LinkOption;)Ljava/nio/file/Path; - java/io/IOException
 method public,varargs register (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind<*>;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; java/io/IOException
 method public compareTo (Ljava/nio/file/Path;)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public buildInputStream ()Ljava/io/InputStream; - -
in 348
class cpw/mods/niofs/union/UnionPath 65 public,super java/lang/Object java/nio/file/Path -
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner java/nio/file/WatchEvent$Modifier java/nio/file/WatchEvent Modifier public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFileSystem ()Lcpw/mods/niofs/union/UnionFileSystem; - -
 method public isAbsolute ()Z - -
 method public getRoot ()Ljava/nio/file/Path; - -
 method public getFileName ()Ljava/nio/file/Path; - -
 method public getParent ()Ljava/nio/file/Path; - -
 method public getNameCount ()I - -
 method public getName (I)Ljava/nio/file/Path; - -
 method public subpath (II)Lcpw/mods/niofs/union/UnionPath; - -
 method public startsWith (Ljava/nio/file/Path;)Z - -
 method public endsWith (Ljava/nio/file/Path;)Z - -
 method public normalize ()Ljava/nio/file/Path; - -
 method public resolve (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public relativize (Ljava/nio/file/Path;)Ljava/nio/file/Path; - -
 method public toUri ()Ljava/net/URI; - -
 method public toAbsolutePath ()Ljava/nio/file/Path; - -
 method public,varargs toRealPath ([Ljava/nio/file/LinkOption;)Ljava/nio/file/Path; - java/io/IOException
 method public,varargs register (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; (Ljava/nio/file/WatchService;[Ljava/nio/file/WatchEvent$Kind<*>;[Ljava/nio/file/WatchEvent$Modifier;)Ljava/nio/file/WatchKey; java/io/IOException
 method public compareTo (Ljava/nio/file/Path;)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public buildInputStream ()Ljava/io/InputStream; - -
in 191
class cpw/mods/niofs/union/UnionPathFilter 60 public,interface,abstract java/lang/Object - -
 method public,abstract test (Ljava/lang/String;Ljava/lang/String;)Z - -
in 348
class cpw/mods/niofs/union/UnionPathFilter 65 public,interface,abstract java/lang/Object - -
 method public,abstract test (Ljava/lang/String;Ljava/nio/file/Path;)Z - -
in 104
class cpw/mods/niofs/zip/ZipFileSystem 60 public,super java/lang/Object - -
 method public <init> ()V - -
in 104
class cpw/mods/util/LambdaExceptionUtils 60 public,super java/lang/Object - -
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions cpw/mods/util/LambdaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions cpw/mods/util/LambdaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions cpw/mods/util/LambdaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static rethrowConsumer (Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions<TT;TE;>;)Ljava/util/function/Consumer<TT;>; -
 method public,static rethrowBiConsumer (Lcpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions<TT;TU;TE;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,static rethrowFunction (Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static rethrowSupplier (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TT;TE;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions;)V - -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/lang/Object; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)TR; -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;TT;)TR; -
in 374
class cpw/mods/util/LambdaExceptionUtils 60 public,super java/lang/Object - -
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions cpw/mods/util/LambdaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions cpw/mods/util/LambdaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions cpw/mods/util/LambdaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static rethrowConsumer (Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions<TT;TE;>;)Ljava/util/function/Consumer<TT;>; -
 method public,static rethrowBiConsumer (Lcpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions<TT;TU;TE;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,static rethrowFunction (Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static rethrowSupplier (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TT;TE;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions;)V - -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/lang/Object; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)TR; -
 method public,static uncheckSupply (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)Ljava/util/function/Supplier<TR;>; -
 method public,static uncheckConsume (Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions<TR;TE;>;)Ljava/util/function/Consumer<TR;>; -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;TT;)TR; -
in 348
class cpw/mods/util/LambdaExceptionUtils 65 public,super java/lang/Object - -
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions cpw/mods/util/LambdaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions cpw/mods/util/LambdaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 inner cpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions cpw/mods/util/LambdaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static rethrowConsumer (Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions<TT;TE;>;)Ljava/util/function/Consumer<TT;>; -
 method public,static rethrowBiConsumer (Lcpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions<TT;TU;TE;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,static rethrowFunction (Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static rethrowSupplier (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TT;TE;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions;)V - -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/lang/Object; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)TR; -
 method public,static uncheckSupply (Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions;)Ljava/util/function/Supplier; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions<TR;TE;>;)Ljava/util/function/Supplier<TR;>; -
 method public,static uncheckConsume (Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions;)Ljava/util/function/Consumer; <R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions<TR;TE;>;)Ljava/util/function/Consumer<TR;>; -
 method public,static uncheck (Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcpw/mods/util/LambdaExceptionUtils$Function_WithExceptions<TT;TR;TE;>;TT;)TR; -
in 375
class cpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions cpw/mods/util/LambdaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V^TE; java/lang/Exception
in 348
class cpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$BiConsumer_WithExceptions cpw/mods/util/LambdaExceptionUtils BiConsumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V^TE; java/lang/Exception
in 375
class cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;)V (TT;)V^TE; java/lang/Exception
in 348
class cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Consumer_WithExceptions cpw/mods/util/LambdaExceptionUtils Consumer_WithExceptions public,static,interface,abstract
 method public,abstract accept (Ljava/lang/Object;)V (TT;)V^TE; java/lang/Exception
in 375
class cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR;^TE; java/lang/Exception
in 348
class cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Function_WithExceptions cpw/mods/util/LambdaExceptionUtils Function_WithExceptions public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR;^TE; java/lang/Exception
in 375
class cpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions 60 public,interface,abstract java/lang/Object - <E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions cpw/mods/util/LambdaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 method public,abstract run ()V ()V^TE; java/lang/Exception
in 348
class cpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions 65 public,interface,abstract java/lang/Object - <E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Runnable_WithExceptions cpw/mods/util/LambdaExceptionUtils Runnable_WithExceptions public,static,interface,abstract
 method public,abstract run ()V ()V^TE; java/lang/Exception
in 375
class cpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions cpw/mods/util/LambdaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 method public,abstract get ()Ljava/lang/Object; ()TT;^TE; java/lang/Exception
in 348
class cpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;E:Ljava/lang/Exception;>Ljava/lang/Object;
 inner cpw/mods/util/LambdaExceptionUtils$Supplier_WithExceptions cpw/mods/util/LambdaExceptionUtils Supplier_WithExceptions public,static,interface,abstract
 method public,abstract get ()Ljava/lang/Object; ()TT;^TE; java/lang/Exception
in 374
class cpw/mods/util/Lazy 60 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static of ()Lcpw/mods/util/Lazy; <T:Ljava/lang/Object;>()Lcpw/mods/util/Lazy<TT;>; -
 method public,static of (Ljava/lang/Object;)Lcpw/mods/util/Lazy; <T:Ljava/lang/Object;>(TT;)Lcpw/mods/util/Lazy<TT;>; -
 method public,static of (Ljava/util/function/Supplier;)Lcpw/mods/util/Lazy; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)Lcpw/mods/util/Lazy<TT;>; -
 method public get ()Ljava/lang/Object; ()TT; -
 method public ifPresent (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<TT;>;)V -
 method public map (Ljava/util/function/Function;)Lcpw/mods/util/Lazy; <R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Lcpw/mods/util/Lazy<TR;>; -
 method public orElse (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
in 348
class cpw/mods/util/Lazy 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static of ()Lcpw/mods/util/Lazy; <T:Ljava/lang/Object;>()Lcpw/mods/util/Lazy<TT;>; -
 method public,static of (Ljava/lang/Object;)Lcpw/mods/util/Lazy; <T:Ljava/lang/Object;>(TT;)Lcpw/mods/util/Lazy<TT;>; -
 method public,static of (Ljava/util/function/Supplier;)Lcpw/mods/util/Lazy; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)Lcpw/mods/util/Lazy<TT;>; -
 method public get ()Ljava/lang/Object; ()TT; -
 method public ifPresent (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<TT;>;)V -
 method public map (Ljava/util/function/Function;)Lcpw/mods/util/Lazy; <R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Lcpw/mods/util/Lazy<TR;>; -
 method public orElse (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
