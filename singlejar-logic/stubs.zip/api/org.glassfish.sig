cg-stub-db 1
in 53
class org/glassfish/json/BufferPoolImpl 50 super java/lang/Object org/glassfish/json/api/BufferPool -
 method public,final take ()[C - -
 method public,final recycle ([C)V - -
in 53
class org/glassfish/json/JsonArrayBuilderImpl 50 super java/lang/Object javax/json/JsonArrayBuilder -
 inner org/glassfish/json/JsonArrayBuilderImpl$JsonArrayImpl org/glassfish/json/JsonArrayBuilderImpl JsonArrayImpl private,static,final
 method public add (Ljavax/json/JsonValue;)Ljavax/json/JsonArrayBuilder; - -
 method public add (Ljava/lang/String;)Ljavax/json/JsonArrayBuilder; - -
 method public add (Ljava/math/BigDecimal;)Ljavax/json/JsonArrayBuilder; - -
 method public add (Ljava/math/BigInteger;)Ljavax/json/JsonArrayBuilder; - -
 method public add (I)Ljavax/json/JsonArrayBuilder; - -
 method public add (J)Ljavax/json/JsonArrayBuilder; - -
 method public add (D)Ljavax/json/JsonArrayBuilder; - -
 method public add (Z)Ljavax/json/JsonArrayBuilder; - -
 method public addNull ()Ljavax/json/JsonArrayBuilder; - -
 method public add (Ljavax/json/JsonObjectBuilder;)Ljavax/json/JsonArrayBuilder; - -
 method public add (Ljavax/json/JsonArrayBuilder;)Ljavax/json/JsonArrayBuilder; - -
 method public build ()Ljavax/json/JsonArray; - -
in 53
class org/glassfish/json/JsonArrayBuilderImpl$JsonArrayImpl 50 final,super java/util/AbstractList javax/json/JsonArray Ljava/util/AbstractList<Ljavax/json/JsonValue;>;Ljavax/json/JsonArray;
 inner org/glassfish/json/JsonArrayBuilderImpl$JsonArrayImpl org/glassfish/json/JsonArrayBuilderImpl JsonArrayImpl private,static,final
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 method public size ()I - -
 method public getJsonObject (I)Ljavax/json/JsonObject; - -
 method public getJsonArray (I)Ljavax/json/JsonArray; - -
 method public getJsonNumber (I)Ljavax/json/JsonNumber; - -
 method public getJsonString (I)Ljavax/json/JsonString; - -
 method public getValuesAs (Ljava/lang/Class;)Ljava/util/List; <T::Ljavax/json/JsonValue;>(Ljava/lang/Class<TT;>;)Ljava/util/List<TT;>; -
 method public getString (I)Ljava/lang/String; - -
 method public getString (ILjava/lang/String;)Ljava/lang/String; - -
 method public getInt (I)I - -
 method public getInt (II)I - -
 method public getBoolean (I)Z - -
 method public getBoolean (IZ)Z - -
 method public isNull (I)Z - -
 method public getValueType ()Ljavax/json/JsonValue$ValueType; - -
 method public get (I)Ljavax/json/JsonValue; - -
 method public toString ()Ljava/lang/String; - -
in 53
class org/glassfish/json/JsonBuilderFactoryImpl 50 super java/lang/Object javax/json/JsonBuilderFactory -
 method public createObjectBuilder ()Ljavax/json/JsonObjectBuilder; - -
 method public createArrayBuilder ()Ljavax/json/JsonArrayBuilder; - -
 method public getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class org/glassfish/json/JsonGeneratorFactoryImpl 50 super java/lang/Object javax/json/stream/JsonGeneratorFactory -
 method public createGenerator (Ljava/io/Writer;)Ljavax/json/stream/JsonGenerator; - -
 method public createGenerator (Ljava/io/OutputStream;)Ljavax/json/stream/JsonGenerator; - -
 method public createGenerator (Ljava/io/OutputStream;Ljava/nio/charset/Charset;)Ljavax/json/stream/JsonGenerator; - -
 method public getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class org/glassfish/json/JsonGeneratorImpl 50 super java/lang/Object javax/json/stream/JsonGenerator -
 inner org/glassfish/json/JsonGeneratorImpl$Context org/glassfish/json/JsonGeneratorImpl Context private,static
 inner org/glassfish/json/JsonGeneratorImpl$Scope org/glassfish/json/JsonGeneratorImpl Scope private,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 method public flush ()V - -
 method public writeStartObject ()Ljavax/json/stream/JsonGenerator; - -
 method public writeStartObject (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;I)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;J)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;D)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;Ljava/math/BigInteger;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;Ljava/math/BigDecimal;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;Z)Ljavax/json/stream/JsonGenerator; - -
 method public writeNull (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljavax/json/JsonValue;)Ljavax/json/stream/JsonGenerator; - -
 method public writeStartArray ()Ljavax/json/stream/JsonGenerator; - -
 method public writeStartArray (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;Ljavax/json/JsonValue;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public write (I)Ljavax/json/stream/JsonGenerator; - -
 method public write (J)Ljavax/json/stream/JsonGenerator; - -
 method public write (D)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/math/BigInteger;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Ljava/math/BigDecimal;)Ljavax/json/stream/JsonGenerator; - -
 method public write (Z)Ljavax/json/stream/JsonGenerator; - -
 method public writeNull ()Ljavax/json/stream/JsonGenerator; - -
 method public writeEnd ()Ljavax/json/stream/JsonGenerator; - -
 method protected writeComma ()V - -
 method public close ()V - -
in 53
class org/glassfish/json/JsonGeneratorImpl$Context 50 super java/lang/Object - -
 inner org/glassfish/json/JsonGeneratorImpl$Scope org/glassfish/json/JsonGeneratorImpl Scope private,static,final,enum
 inner org/glassfish/json/JsonGeneratorImpl$Context org/glassfish/json/JsonGeneratorImpl Context private,static
in 53
class org/glassfish/json/JsonGeneratorImpl$Scope 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/glassfish/json/JsonGeneratorImpl$Scope;>;
 inner org/glassfish/json/JsonGeneratorImpl$Scope org/glassfish/json/JsonGeneratorImpl Scope private,static,final,enum
 field public,static,final,enum IN_NONE Lorg/glassfish/json/JsonGeneratorImpl$Scope; -
 field public,static,final,enum IN_OBJECT Lorg/glassfish/json/JsonGeneratorImpl$Scope; -
 field public,static,final,enum IN_ARRAY Lorg/glassfish/json/JsonGeneratorImpl$Scope; -
 method public,static values ()[Lorg/glassfish/json/JsonGeneratorImpl$Scope; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/glassfish/json/JsonGeneratorImpl$Scope; - -
in 53
class org/glassfish/json/JsonLocationImpl 50 super java/lang/Object javax/json/stream/JsonLocation -
 method public getLineNumber ()J - -
 method public getColumnNumber ()J - -
 method public getStreamOffset ()J - -
 method public toString ()Ljava/lang/String; - -
in 53
class org/glassfish/json/JsonMessages 50 final,super java/lang/Object - -
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
in 53
class org/glassfish/json/JsonNumberImpl 50 super,abstract java/lang/Object javax/json/JsonNumber -
 inner org/glassfish/json/JsonNumberImpl$JsonBigDecimalNumber org/glassfish/json/JsonNumberImpl JsonBigDecimalNumber private,static,final
 inner org/glassfish/json/JsonNumberImpl$JsonLongNumber org/glassfish/json/JsonNumberImpl JsonLongNumber private,static,final
 inner org/glassfish/json/JsonNumberImpl$JsonIntNumber org/glassfish/json/JsonNumberImpl JsonIntNumber private,static,final
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 method public isIntegral ()Z - -
 method public intValue ()I - -
 method public intValueExact ()I - -
 method public longValue ()J - -
 method public longValueExact ()J - -
 method public doubleValue ()D - -
 method public bigIntegerValue ()Ljava/math/BigInteger; - -
 method public bigIntegerValueExact ()Ljava/math/BigInteger; - -
 method public getValueType ()Ljavax/json/JsonValue$ValueType; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 53
class org/glassfish/json/JsonNumberImpl$JsonBigDecimalNumber 50 final,super org/glassfish/json/JsonNumberImpl - -
 inner org/glassfish/json/JsonNumberImpl$JsonBigDecimalNumber org/glassfish/json/JsonNumberImpl JsonBigDecimalNumber private,static,final
 method public bigDecimalValue ()Ljava/math/BigDecimal; - -
in 53
class org/glassfish/json/JsonNumberImpl$JsonIntNumber 50 final,super org/glassfish/json/JsonNumberImpl - -
 inner org/glassfish/json/JsonNumberImpl$JsonIntNumber org/glassfish/json/JsonNumberImpl JsonIntNumber private,static,final
 method public isIntegral ()Z - -
 method public intValue ()I - -
 method public intValueExact ()I - -
 method public longValue ()J - -
 method public longValueExact ()J - -
 method public doubleValue ()D - -
 method public bigDecimalValue ()Ljava/math/BigDecimal; - -
 method public toString ()Ljava/lang/String; - -
in 53
class org/glassfish/json/JsonNumberImpl$JsonLongNumber 50 final,super org/glassfish/json/JsonNumberImpl - -
 inner org/glassfish/json/JsonNumberImpl$JsonLongNumber org/glassfish/json/JsonNumberImpl JsonLongNumber private,static,final
 method public isIntegral ()Z - -
 method public longValue ()J - -
 method public longValueExact ()J - -
 method public doubleValue ()D - -
 method public bigDecimalValue ()Ljava/math/BigDecimal; - -
 method public toString ()Ljava/lang/String; - -
in 53
class org/glassfish/json/JsonObjectBuilderImpl 50 super java/lang/Object javax/json/JsonObjectBuilder -
 inner org/glassfish/json/JsonObjectBuilderImpl$JsonObjectImpl org/glassfish/json/JsonObjectBuilderImpl JsonObjectImpl private,static,final
 method public add (Ljava/lang/String;Ljavax/json/JsonValue;)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;Ljava/lang/String;)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;Ljava/math/BigInteger;)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;Ljava/math/BigDecimal;)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;I)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;J)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;D)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;Z)Ljavax/json/JsonObjectBuilder; - -
 method public addNull (Ljava/lang/String;)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;Ljavax/json/JsonObjectBuilder;)Ljavax/json/JsonObjectBuilder; - -
 method public add (Ljava/lang/String;Ljavax/json/JsonArrayBuilder;)Ljavax/json/JsonObjectBuilder; - -
 method public build ()Ljavax/json/JsonObject; - -
in 53
class org/glassfish/json/JsonObjectBuilderImpl$JsonObjectImpl 50 final,super java/util/AbstractMap javax/json/JsonObject Ljava/util/AbstractMap<Ljava/lang/String;Ljavax/json/JsonValue;>;Ljavax/json/JsonObject;
 inner org/glassfish/json/JsonObjectBuilderImpl$JsonObjectImpl org/glassfish/json/JsonObjectBuilderImpl JsonObjectImpl private,static,final
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public getJsonArray (Ljava/lang/String;)Ljavax/json/JsonArray; - -
 method public getJsonObject (Ljava/lang/String;)Ljavax/json/JsonObject; - -
 method public getJsonNumber (Ljava/lang/String;)Ljavax/json/JsonNumber; - -
 method public getJsonString (Ljava/lang/String;)Ljavax/json/JsonString; - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public getInt (Ljava/lang/String;)I - -
 method public getInt (Ljava/lang/String;I)I - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public getBoolean (Ljava/lang/String;Z)Z - -
 method public isNull (Ljava/lang/String;)Z - -
 method public getValueType ()Ljavax/json/JsonValue$ValueType; - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Ljavax/json/JsonValue;>;>; -
 method public toString ()Ljava/lang/String; - -
in 53
class org/glassfish/json/JsonParserFactoryImpl 50 super java/lang/Object javax/json/stream/JsonParserFactory -
 method public createParser (Ljava/io/Reader;)Ljavax/json/stream/JsonParser; - -
 method public createParser (Ljava/io/InputStream;)Ljavax/json/stream/JsonParser; - -
 method public createParser (Ljava/io/InputStream;Ljava/nio/charset/Charset;)Ljavax/json/stream/JsonParser; - -
 method public createParser (Ljavax/json/JsonArray;)Ljavax/json/stream/JsonParser; - -
 method public getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
 method public createParser (Ljavax/json/JsonObject;)Ljavax/json/stream/JsonParser; - -
in 53
class org/glassfish/json/JsonParserImpl 50 public,super java/lang/Object javax/json/stream/JsonParser -
 inner org/glassfish/json/JsonParserImpl$ArrayContext org/glassfish/json/JsonParserImpl ArrayContext private,final
 inner org/glassfish/json/JsonParserImpl$ObjectContext org/glassfish/json/JsonParserImpl ObjectContext private,final
 inner org/glassfish/json/JsonParserImpl$NoneContext org/glassfish/json/JsonParserImpl NoneContext private,final
 inner org/glassfish/json/JsonParserImpl$Context org/glassfish/json/JsonParserImpl Context private,abstract
 inner org/glassfish/json/JsonParserImpl$Stack org/glassfish/json/JsonParserImpl Stack private,static,final
 inner org/glassfish/json/JsonParserImpl$StateIterator org/glassfish/json/JsonParserImpl StateIterator private
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
 method public <init> (Ljava/io/Reader;Lorg/glassfish/json/api/BufferPool;)V - -
 method public <init> (Ljava/io/InputStream;Lorg/glassfish/json/api/BufferPool;)V - -
 method public <init> (Ljava/io/InputStream;Ljava/nio/charset/Charset;Lorg/glassfish/json/api/BufferPool;)V - -
 method public getString ()Ljava/lang/String; - -
 method public isIntegralNumber ()Z - -
 method public getInt ()I - -
 method public getLong ()J - -
 method public getBigDecimal ()Ljava/math/BigDecimal; - -
 method public getLocation ()Ljavax/json/stream/JsonLocation; - -
 method public getLastCharLocation ()Ljavax/json/stream/JsonLocation; - -
 method public hasNext ()Z - -
 method public next ()Ljavax/json/stream/JsonParser$Event; - -
 method public close ()V - -
in 53
class org/glassfish/json/JsonParserImpl$ArrayContext 50 final,super org/glassfish/json/JsonParserImpl$Context - -
 inner org/glassfish/json/JsonParserImpl$ArrayContext org/glassfish/json/JsonParserImpl ArrayContext private,final
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
 inner org/glassfish/json/JsonParserImpl$ObjectContext org/glassfish/json/JsonParserImpl ObjectContext private,final
 inner org/glassfish/json/JsonParserImpl$Context org/glassfish/json/JsonParserImpl Context private,abstract
 inner org/glassfish/json/JsonParserImpl$Stack org/glassfish/json/JsonParserImpl Stack private,static,final
 method public getNextEvent ()Ljavax/json/stream/JsonParser$Event; - -
in 53
class org/glassfish/json/JsonParserImpl$Context 50 super,abstract java/lang/Object - -
 inner org/glassfish/json/JsonParserImpl$Context org/glassfish/json/JsonParserImpl Context private,abstract
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
in 53
class org/glassfish/json/JsonParserImpl$NoneContext 50 final,super org/glassfish/json/JsonParserImpl$Context - -
 inner org/glassfish/json/JsonParserImpl$NoneContext org/glassfish/json/JsonParserImpl NoneContext private,final
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
 inner org/glassfish/json/JsonParserImpl$ObjectContext org/glassfish/json/JsonParserImpl ObjectContext private,final
 inner org/glassfish/json/JsonParserImpl$ArrayContext org/glassfish/json/JsonParserImpl ArrayContext private,final
 inner org/glassfish/json/JsonParserImpl$Context org/glassfish/json/JsonParserImpl Context private,abstract
 inner org/glassfish/json/JsonParserImpl$Stack org/glassfish/json/JsonParserImpl Stack private,static,final
 method public getNextEvent ()Ljavax/json/stream/JsonParser$Event; - -
in 53
class org/glassfish/json/JsonParserImpl$ObjectContext 50 final,super org/glassfish/json/JsonParserImpl$Context - -
 inner org/glassfish/json/JsonParserImpl$ObjectContext org/glassfish/json/JsonParserImpl ObjectContext private,final
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
 inner org/glassfish/json/JsonParserImpl$ArrayContext org/glassfish/json/JsonParserImpl ArrayContext private,final
 inner org/glassfish/json/JsonParserImpl$Context org/glassfish/json/JsonParserImpl Context private,abstract
 inner org/glassfish/json/JsonParserImpl$Stack org/glassfish/json/JsonParserImpl Stack private,static,final
 method public getNextEvent ()Ljavax/json/stream/JsonParser$Event; - -
in 53
class org/glassfish/json/JsonParserImpl$Stack 50 final,super java/lang/Object - -
 inner org/glassfish/json/JsonParserImpl$Context org/glassfish/json/JsonParserImpl Context private,abstract
 inner org/glassfish/json/JsonParserImpl$Stack org/glassfish/json/JsonParserImpl Stack private,static,final
in 53
class org/glassfish/json/JsonParserImpl$StateIterator 50 super java/lang/Object java/util/Iterator Ljava/lang/Object;Ljava/util/Iterator<Ljavax/json/stream/JsonParser$Event;>;
 inner org/glassfish/json/JsonParserImpl$StateIterator org/glassfish/json/JsonParserImpl StateIterator private
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 inner org/glassfish/json/JsonParserImpl$Stack org/glassfish/json/JsonParserImpl Stack private,static,final
 inner org/glassfish/json/JsonParserImpl$Context org/glassfish/json/JsonParserImpl Context private,abstract
 method public hasNext ()Z - -
 method public next ()Ljavax/json/stream/JsonParser$Event; - -
 method public remove ()V - -
in 53
class org/glassfish/json/JsonPrettyGeneratorImpl 50 public,super org/glassfish/json/JsonGeneratorImpl - -
 method public <init> (Ljava/io/Writer;Lorg/glassfish/json/api/BufferPool;)V - -
 method public <init> (Ljava/io/OutputStream;Lorg/glassfish/json/api/BufferPool;)V - -
 method public <init> (Ljava/io/OutputStream;Ljava/nio/charset/Charset;Lorg/glassfish/json/api/BufferPool;)V - -
 method public writeStartObject ()Ljavax/json/stream/JsonGenerator; - -
 method public writeStartObject (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public writeStartArray ()Ljavax/json/stream/JsonGenerator; - -
 method public writeStartArray (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public writeEnd ()Ljavax/json/stream/JsonGenerator; - -
 method protected writeComma ()V - -
in 53
class org/glassfish/json/JsonProviderImpl 50 public,super javax/json/spi/JsonProvider - -
 method public <init> ()V - -
 method public createGenerator (Ljava/io/Writer;)Ljavax/json/stream/JsonGenerator; - -
 method public createGenerator (Ljava/io/OutputStream;)Ljavax/json/stream/JsonGenerator; - -
 method public createParser (Ljava/io/Reader;)Ljavax/json/stream/JsonParser; - -
 method public createParser (Ljava/io/InputStream;)Ljavax/json/stream/JsonParser; - -
 method public createParserFactory (Ljava/util/Map;)Ljavax/json/stream/JsonParserFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/stream/JsonParserFactory; -
 method public createGeneratorFactory (Ljava/util/Map;)Ljavax/json/stream/JsonGeneratorFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/stream/JsonGeneratorFactory; -
 method public createReader (Ljava/io/Reader;)Ljavax/json/JsonReader; - -
 method public createReader (Ljava/io/InputStream;)Ljavax/json/JsonReader; - -
 method public createWriter (Ljava/io/Writer;)Ljavax/json/JsonWriter; - -
 method public createWriter (Ljava/io/OutputStream;)Ljavax/json/JsonWriter; - -
 method public createWriterFactory (Ljava/util/Map;)Ljavax/json/JsonWriterFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonWriterFactory; -
 method public createReaderFactory (Ljava/util/Map;)Ljavax/json/JsonReaderFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonReaderFactory; -
 method public createObjectBuilder ()Ljavax/json/JsonObjectBuilder; - -
 method public createArrayBuilder ()Ljavax/json/JsonArrayBuilder; - -
 method public createBuilderFactory (Ljava/util/Map;)Ljavax/json/JsonBuilderFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonBuilderFactory; -
in 53
class org/glassfish/json/JsonReaderFactoryImpl 50 super java/lang/Object javax/json/JsonReaderFactory -
 method public createReader (Ljava/io/Reader;)Ljavax/json/JsonReader; - -
 method public createReader (Ljava/io/InputStream;)Ljavax/json/JsonReader; - -
 method public createReader (Ljava/io/InputStream;Ljava/nio/charset/Charset;)Ljavax/json/JsonReader; - -
 method public getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class org/glassfish/json/JsonReaderImpl 50 super java/lang/Object javax/json/JsonReader -
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 method public read ()Ljavax/json/JsonStructure; - -
 method public readObject ()Ljavax/json/JsonObject; - -
 method public readArray ()Ljavax/json/JsonArray; - -
 method public close ()V - -
in 53
class org/glassfish/json/JsonStringImpl 50 final,super java/lang/Object javax/json/JsonString -
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 method public getString ()Ljava/lang/String; - -
 method public getChars ()Ljava/lang/CharSequence; - -
 method public getValueType ()Ljavax/json/JsonValue$ValueType; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 53
class org/glassfish/json/JsonStructureParser 50 super java/lang/Object javax/json/stream/JsonParser -
 inner org/glassfish/json/JsonStructureParser$ObjectScope org/glassfish/json/JsonStructureParser ObjectScope private,static
 inner org/glassfish/json/JsonStructureParser$ArrayScope org/glassfish/json/JsonStructureParser ArrayScope private,static
 inner org/glassfish/json/JsonStructureParser$Scope org/glassfish/json/JsonStructureParser Scope private,static,abstract
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 method public getString ()Ljava/lang/String; - -
 method public isIntegralNumber ()Z - -
 method public getInt ()I - -
 method public getLong ()J - -
 method public getBigDecimal ()Ljava/math/BigDecimal; - -
 method public getLocation ()Ljavax/json/stream/JsonLocation; - -
 method public hasNext ()Z - -
 method public next ()Ljavax/json/stream/JsonParser$Event; - -
 method public close ()V - -
in 53
class org/glassfish/json/JsonStructureParser$ArrayScope 50 super org/glassfish/json/JsonStructureParser$Scope - -
 inner org/glassfish/json/JsonStructureParser$ArrayScope org/glassfish/json/JsonStructureParser ArrayScope private,static
 inner org/glassfish/json/JsonStructureParser$Scope org/glassfish/json/JsonStructureParser Scope private,static,abstract
 method public hasNext ()Z - -
 method public next ()Ljavax/json/JsonValue; - -
 method public remove ()V - -
in 53
class org/glassfish/json/JsonStructureParser$ObjectScope 50 super org/glassfish/json/JsonStructureParser$Scope - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/glassfish/json/JsonStructureParser$ObjectScope org/glassfish/json/JsonStructureParser ObjectScope private,static
 inner org/glassfish/json/JsonStructureParser$Scope org/glassfish/json/JsonStructureParser Scope private,static,abstract
 method public hasNext ()Z - -
 method public next ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<Ljava/lang/String;Ljavax/json/JsonValue;>; -
 method public remove ()V - -
in 53
class org/glassfish/json/JsonStructureParser$Scope 50 super,abstract java/lang/Object java/util/Iterator -
 inner org/glassfish/json/JsonStructureParser$Scope org/glassfish/json/JsonStructureParser Scope private,static,abstract
 inner org/glassfish/json/JsonStructureParser$ArrayScope org/glassfish/json/JsonStructureParser ArrayScope private,static
 inner org/glassfish/json/JsonStructureParser$ObjectScope org/glassfish/json/JsonStructureParser ObjectScope private,static
in 53
class org/glassfish/json/JsonTokenizer 50 final,super java/lang/Object java/io/Closeable -
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
 method public close ()V - java/io/IOException
in 53
class org/glassfish/json/JsonTokenizer$JsonToken 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/glassfish/json/JsonTokenizer$JsonToken;>;
 inner org/glassfish/json/JsonTokenizer$JsonToken org/glassfish/json/JsonTokenizer JsonToken static,final,enum
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 field public,static,final,enum CURLYOPEN Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum SQUAREOPEN Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum COLON Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum COMMA Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum STRING Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum NUMBER Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum TRUE Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum FALSE Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum NULL Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum CURLYCLOSE Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum SQUARECLOSE Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 field public,static,final,enum EOF Lorg/glassfish/json/JsonTokenizer$JsonToken; -
 method public,static values ()[Lorg/glassfish/json/JsonTokenizer$JsonToken; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/glassfish/json/JsonTokenizer$JsonToken; - -
in 53
class org/glassfish/json/JsonWriterFactoryImpl 50 super java/lang/Object javax/json/JsonWriterFactory -
 method public createWriter (Ljava/io/Writer;)Ljavax/json/JsonWriter; - -
 method public createWriter (Ljava/io/OutputStream;)Ljavax/json/JsonWriter; - -
 method public createWriter (Ljava/io/OutputStream;Ljava/nio/charset/Charset;)Ljavax/json/JsonWriter; - -
 method public getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class org/glassfish/json/JsonWriterImpl 50 super java/lang/Object javax/json/JsonWriter -
 inner org/glassfish/json/JsonWriterImpl$NoFlushOutputStream org/glassfish/json/JsonWriterImpl NoFlushOutputStream private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public writeArray (Ljavax/json/JsonArray;)V - -
 method public writeObject (Ljavax/json/JsonObject;)V - -
 method public write (Ljavax/json/JsonStructure;)V - -
 method public close ()V - -
in 53
class org/glassfish/json/JsonWriterImpl$NoFlushOutputStream 50 final,super java/io/FilterOutputStream - -
 inner org/glassfish/json/JsonWriterImpl$NoFlushOutputStream org/glassfish/json/JsonWriterImpl NoFlushOutputStream private,static,final
 method public <init> (Ljava/io/OutputStream;)V - -
 method public write ([BII)V - java/io/IOException
 method public flush ()V - -
in 53
class org/glassfish/json/UnicodeDetectingInputStream 50 super java/io/FilterInputStream - -
 method public read ()I - java/io/IOException
 method public read ([BII)I - java/io/IOException
in 53
class org/glassfish/json/api/BufferPool 50 public,interface,abstract java/lang/Object - -
 method public,abstract take ()[C - -
 method public,abstract recycle ([C)V - -
