cg-stub-db 1
in 53
class javax/json/Json 50 public,super java/lang/Object - -
 method public,static createParser (Ljava/io/Reader;)Ljavax/json/stream/JsonParser; - -
 method public,static createParser (Ljava/io/InputStream;)Ljavax/json/stream/JsonParser; - -
 method public,static createGenerator (Ljava/io/Writer;)Ljavax/json/stream/JsonGenerator; - -
 method public,static createGenerator (Ljava/io/OutputStream;)Ljavax/json/stream/JsonGenerator; - -
 method public,static createParserFactory (Ljava/util/Map;)Ljavax/json/stream/JsonParserFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/stream/JsonParserFactory; -
 method public,static createGeneratorFactory (Ljava/util/Map;)Ljavax/json/stream/JsonGeneratorFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/stream/JsonGeneratorFactory; -
 method public,static createWriter (Ljava/io/Writer;)Ljavax/json/JsonWriter; - -
 method public,static createWriter (Ljava/io/OutputStream;)Ljavax/json/JsonWriter; - -
 method public,static createReader (Ljava/io/Reader;)Ljavax/json/JsonReader; - -
 method public,static createReader (Ljava/io/InputStream;)Ljavax/json/JsonReader; - -
 method public,static createReaderFactory (Ljava/util/Map;)Ljavax/json/JsonReaderFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonReaderFactory; -
 method public,static createWriterFactory (Ljava/util/Map;)Ljavax/json/JsonWriterFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonWriterFactory; -
 method public,static createArrayBuilder ()Ljavax/json/JsonArrayBuilder; - -
 method public,static createObjectBuilder ()Ljavax/json/JsonObjectBuilder; - -
 method public,static createBuilderFactory (Ljava/util/Map;)Ljavax/json/JsonBuilderFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonBuilderFactory; -
in 53
class javax/json/JsonArray 50 public,interface,abstract java/lang/Object javax/json/JsonStructure,java/util/List Ljava/lang/Object;Ljavax/json/JsonStructure;Ljava/util/List<Ljavax/json/JsonValue;>;
 method public,abstract getJsonObject (I)Ljavax/json/JsonObject; - -
 method public,abstract getJsonArray (I)Ljavax/json/JsonArray; - -
 method public,abstract getJsonNumber (I)Ljavax/json/JsonNumber; - -
 method public,abstract getJsonString (I)Ljavax/json/JsonString; - -
 method public,abstract getValuesAs (Ljava/lang/Class;)Ljava/util/List; <T::Ljavax/json/JsonValue;>(Ljava/lang/Class<TT;>;)Ljava/util/List<TT;>; -
 method public,abstract getString (I)Ljava/lang/String; - -
 method public,abstract getString (ILjava/lang/String;)Ljava/lang/String; - -
 method public,abstract getInt (I)I - -
 method public,abstract getInt (II)I - -
 method public,abstract getBoolean (I)Z - -
 method public,abstract getBoolean (IZ)Z - -
 method public,abstract isNull (I)Z - -
in 53
class javax/json/JsonArrayBuilder 50 public,interface,abstract java/lang/Object - -
 method public,abstract add (Ljavax/json/JsonValue;)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (Ljava/lang/String;)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (Ljava/math/BigDecimal;)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (Ljava/math/BigInteger;)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (I)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (J)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (D)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (Z)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract addNull ()Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (Ljavax/json/JsonObjectBuilder;)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract add (Ljavax/json/JsonArrayBuilder;)Ljavax/json/JsonArrayBuilder; - -
 method public,abstract build ()Ljavax/json/JsonArray; - -
in 53
class javax/json/JsonBuilderFactory 50 public,interface,abstract java/lang/Object - -
 method public,abstract createObjectBuilder ()Ljavax/json/JsonObjectBuilder; - -
 method public,abstract createArrayBuilder ()Ljavax/json/JsonArrayBuilder; - -
 method public,abstract getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class javax/json/JsonException 50 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 53
class javax/json/JsonNumber 50 public,interface,abstract java/lang/Object javax/json/JsonValue -
 method public,abstract isIntegral ()Z - -
 method public,abstract intValue ()I - -
 method public,abstract intValueExact ()I - -
 method public,abstract longValue ()J - -
 method public,abstract longValueExact ()J - -
 method public,abstract bigIntegerValue ()Ljava/math/BigInteger; - -
 method public,abstract bigIntegerValueExact ()Ljava/math/BigInteger; - -
 method public,abstract doubleValue ()D - -
 method public,abstract bigDecimalValue ()Ljava/math/BigDecimal; - -
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract equals (Ljava/lang/Object;)Z - -
 method public,abstract hashCode ()I - -
in 53
class javax/json/JsonObject 50 public,interface,abstract java/lang/Object javax/json/JsonStructure,java/util/Map Ljava/lang/Object;Ljavax/json/JsonStructure;Ljava/util/Map<Ljava/lang/String;Ljavax/json/JsonValue;>;
 method public,abstract getJsonArray (Ljava/lang/String;)Ljavax/json/JsonArray; - -
 method public,abstract getJsonObject (Ljava/lang/String;)Ljavax/json/JsonObject; - -
 method public,abstract getJsonNumber (Ljava/lang/String;)Ljavax/json/JsonNumber; - -
 method public,abstract getJsonString (Ljava/lang/String;)Ljavax/json/JsonString; - -
 method public,abstract getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getInt (Ljava/lang/String;)I - -
 method public,abstract getInt (Ljava/lang/String;I)I - -
 method public,abstract getBoolean (Ljava/lang/String;)Z - -
 method public,abstract getBoolean (Ljava/lang/String;Z)Z - -
 method public,abstract isNull (Ljava/lang/String;)Z - -
in 53
class javax/json/JsonObjectBuilder 50 public,interface,abstract java/lang/Object - -
 method public,abstract add (Ljava/lang/String;Ljavax/json/JsonValue;)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;Ljava/lang/String;)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;Ljava/math/BigInteger;)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;Ljava/math/BigDecimal;)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;I)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;J)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;D)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;Z)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract addNull (Ljava/lang/String;)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;Ljavax/json/JsonObjectBuilder;)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract add (Ljava/lang/String;Ljavax/json/JsonArrayBuilder;)Ljavax/json/JsonObjectBuilder; - -
 method public,abstract build ()Ljavax/json/JsonObject; - -
in 53
class javax/json/JsonReader 50 public,interface,abstract java/lang/Object java/io/Closeable -
 method public,abstract read ()Ljavax/json/JsonStructure; - -
 method public,abstract readObject ()Ljavax/json/JsonObject; - -
 method public,abstract readArray ()Ljavax/json/JsonArray; - -
 method public,abstract close ()V - -
in 53
class javax/json/JsonReaderFactory 50 public,interface,abstract java/lang/Object - -
 method public,abstract createReader (Ljava/io/Reader;)Ljavax/json/JsonReader; - -
 method public,abstract createReader (Ljava/io/InputStream;)Ljavax/json/JsonReader; - -
 method public,abstract createReader (Ljava/io/InputStream;Ljava/nio/charset/Charset;)Ljavax/json/JsonReader; - -
 method public,abstract getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class javax/json/JsonString 50 public,interface,abstract java/lang/Object javax/json/JsonValue -
 method public,abstract getString ()Ljava/lang/String; - -
 method public,abstract getChars ()Ljava/lang/CharSequence; - -
 method public,abstract equals (Ljava/lang/Object;)Z - -
 method public,abstract hashCode ()I - -
in 53
class javax/json/JsonStructure 50 public,interface,abstract java/lang/Object javax/json/JsonValue -
in 53
class javax/json/JsonValue 50 public,interface,abstract java/lang/Object - -
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 field public,static,final NULL Ljavax/json/JsonValue; -
 field public,static,final TRUE Ljavax/json/JsonValue; -
 field public,static,final FALSE Ljavax/json/JsonValue; -
 method public,abstract getValueType ()Ljavax/json/JsonValue$ValueType; - -
 method public,abstract toString ()Ljava/lang/String; - -
in 53
class javax/json/JsonValue$ValueType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljavax/json/JsonValue$ValueType;>;
 inner javax/json/JsonValue$ValueType javax/json/JsonValue ValueType public,static,final,enum
 field public,static,final,enum ARRAY Ljavax/json/JsonValue$ValueType; -
 field public,static,final,enum OBJECT Ljavax/json/JsonValue$ValueType; -
 field public,static,final,enum STRING Ljavax/json/JsonValue$ValueType; -
 field public,static,final,enum NUMBER Ljavax/json/JsonValue$ValueType; -
 field public,static,final,enum TRUE Ljavax/json/JsonValue$ValueType; -
 field public,static,final,enum FALSE Ljavax/json/JsonValue$ValueType; -
 field public,static,final,enum NULL Ljavax/json/JsonValue$ValueType; -
 method public,static values ()[Ljavax/json/JsonValue$ValueType; - -
 method public,static valueOf (Ljava/lang/String;)Ljavax/json/JsonValue$ValueType; - -
in 53
class javax/json/JsonWriter 50 public,interface,abstract java/lang/Object java/io/Closeable -
 method public,abstract writeArray (Ljavax/json/JsonArray;)V - -
 method public,abstract writeObject (Ljavax/json/JsonObject;)V - -
 method public,abstract write (Ljavax/json/JsonStructure;)V - -
 method public,abstract close ()V - -
in 53
class javax/json/JsonWriterFactory 50 public,interface,abstract java/lang/Object - -
 method public,abstract createWriter (Ljava/io/Writer;)Ljavax/json/JsonWriter; - -
 method public,abstract createWriter (Ljava/io/OutputStream;)Ljavax/json/JsonWriter; - -
 method public,abstract createWriter (Ljava/io/OutputStream;Ljava/nio/charset/Charset;)Ljavax/json/JsonWriter; - -
 method public,abstract getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class javax/json/spi/JsonProvider 50 public,super,abstract java/lang/Object - -
 method protected <init> ()V - -
 method public,static provider ()Ljavax/json/spi/JsonProvider; - -
 method public,abstract createParser (Ljava/io/Reader;)Ljavax/json/stream/JsonParser; - -
 method public,abstract createParser (Ljava/io/InputStream;)Ljavax/json/stream/JsonParser; - -
 method public,abstract createParserFactory (Ljava/util/Map;)Ljavax/json/stream/JsonParserFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/stream/JsonParserFactory; -
 method public,abstract createGenerator (Ljava/io/Writer;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract createGenerator (Ljava/io/OutputStream;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract createGeneratorFactory (Ljava/util/Map;)Ljavax/json/stream/JsonGeneratorFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/stream/JsonGeneratorFactory; -
 method public,abstract createReader (Ljava/io/Reader;)Ljavax/json/JsonReader; - -
 method public,abstract createReader (Ljava/io/InputStream;)Ljavax/json/JsonReader; - -
 method public,abstract createWriter (Ljava/io/Writer;)Ljavax/json/JsonWriter; - -
 method public,abstract createWriter (Ljava/io/OutputStream;)Ljavax/json/JsonWriter; - -
 method public,abstract createWriterFactory (Ljava/util/Map;)Ljavax/json/JsonWriterFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonWriterFactory; -
 method public,abstract createReaderFactory (Ljava/util/Map;)Ljavax/json/JsonReaderFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonReaderFactory; -
 method public,abstract createObjectBuilder ()Ljavax/json/JsonObjectBuilder; - -
 method public,abstract createArrayBuilder ()Ljavax/json/JsonArrayBuilder; - -
 method public,abstract createBuilderFactory (Ljava/util/Map;)Ljavax/json/JsonBuilderFactory; (Ljava/util/Map<Ljava/lang/String;*>;)Ljavax/json/JsonBuilderFactory; -
in 53
class javax/json/stream/JsonGenerationException 50 public,super javax/json/JsonException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 53
class javax/json/stream/JsonGenerator 50 public,interface,abstract java/lang/Object java/io/Flushable,java/io/Closeable -
 field public,static,final PRETTY_PRINTING Ljava/lang/String; - "javax.json.stream.JsonGenerator.prettyPrinting"
 method public,abstract writeStartObject ()Ljavax/json/stream/JsonGenerator; - -
 method public,abstract writeStartObject (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract writeStartArray ()Ljavax/json/stream/JsonGenerator; - -
 method public,abstract writeStartArray (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;Ljavax/json/JsonValue;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;Ljava/math/BigInteger;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;Ljava/math/BigDecimal;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;I)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;J)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;D)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;Z)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract writeNull (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract writeEnd ()Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljavax/json/JsonValue;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/lang/String;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/math/BigDecimal;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Ljava/math/BigInteger;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (I)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (J)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (D)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract write (Z)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract writeNull ()Ljavax/json/stream/JsonGenerator; - -
 method public,abstract close ()V - -
 method public,abstract flush ()V - -
in 53
class javax/json/stream/JsonGeneratorFactory 50 public,interface,abstract java/lang/Object - -
 method public,abstract createGenerator (Ljava/io/Writer;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract createGenerator (Ljava/io/OutputStream;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract createGenerator (Ljava/io/OutputStream;Ljava/nio/charset/Charset;)Ljavax/json/stream/JsonGenerator; - -
 method public,abstract getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class javax/json/stream/JsonLocation 50 public,interface,abstract java/lang/Object - -
 method public,abstract getLineNumber ()J - -
 method public,abstract getColumnNumber ()J - -
 method public,abstract getStreamOffset ()J - -
in 53
class javax/json/stream/JsonParser 50 public,interface,abstract java/lang/Object java/io/Closeable -
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 method public,abstract hasNext ()Z - -
 method public,abstract next ()Ljavax/json/stream/JsonParser$Event; - -
 method public,abstract getString ()Ljava/lang/String; - -
 method public,abstract isIntegralNumber ()Z - -
 method public,abstract getInt ()I - -
 method public,abstract getLong ()J - -
 method public,abstract getBigDecimal ()Ljava/math/BigDecimal; - -
 method public,abstract getLocation ()Ljavax/json/stream/JsonLocation; - -
 method public,abstract close ()V - -
in 53
class javax/json/stream/JsonParser$Event 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljavax/json/stream/JsonParser$Event;>;
 inner javax/json/stream/JsonParser$Event javax/json/stream/JsonParser Event public,static,final,enum
 field public,static,final,enum START_ARRAY Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum START_OBJECT Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum KEY_NAME Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum VALUE_STRING Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum VALUE_NUMBER Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum VALUE_TRUE Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum VALUE_FALSE Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum VALUE_NULL Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum END_OBJECT Ljavax/json/stream/JsonParser$Event; -
 field public,static,final,enum END_ARRAY Ljavax/json/stream/JsonParser$Event; -
 method public,static values ()[Ljavax/json/stream/JsonParser$Event; - -
 method public,static valueOf (Ljava/lang/String;)Ljavax/json/stream/JsonParser$Event; - -
in 53
class javax/json/stream/JsonParserFactory 50 public,interface,abstract java/lang/Object - -
 method public,abstract createParser (Ljava/io/Reader;)Ljavax/json/stream/JsonParser; - -
 method public,abstract createParser (Ljava/io/InputStream;)Ljavax/json/stream/JsonParser; - -
 method public,abstract createParser (Ljava/io/InputStream;Ljava/nio/charset/Charset;)Ljavax/json/stream/JsonParser; - -
 method public,abstract createParser (Ljavax/json/JsonObject;)Ljavax/json/stream/JsonParser; - -
 method public,abstract createParser (Ljavax/json/JsonArray;)Ljavax/json/stream/JsonParser; - -
 method public,abstract getConfigInUse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
in 53
class javax/json/stream/JsonParsingException 50 public,super javax/json/JsonException - -
 method public <init> (Ljava/lang/String;Ljavax/json/stream/JsonLocation;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;Ljavax/json/stream/JsonLocation;)V - -
 method public getLocation ()Ljavax/json/stream/JsonLocation; - -
