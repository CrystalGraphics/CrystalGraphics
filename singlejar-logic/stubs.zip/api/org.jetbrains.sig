cg-stub-db 1
in 1111
class org/jetbrains/annotations/ApiStatus 52 public,final,super java/lang/Object - -
 inner org/jetbrains/annotations/ApiStatus$OverrideOnly org/jetbrains/annotations/ApiStatus OverrideOnly public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$NonExtendable org/jetbrains/annotations/ApiStatus NonExtendable public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$AvailableSince org/jetbrains/annotations/ApiStatus AvailableSince public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$ScheduledForRemoval org/jetbrains/annotations/ApiStatus ScheduledForRemoval public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$Obsolete org/jetbrains/annotations/ApiStatus Obsolete public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$Internal org/jetbrains/annotations/ApiStatus Internal public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$Experimental org/jetbrains/annotations/ApiStatus Experimental public,static,interface,abstract,annotation
in 350
class org/jetbrains/annotations/ApiStatus 52 public,final,super java/lang/Object - -
 inner org/jetbrains/annotations/ApiStatus$OverrideOnly org/jetbrains/annotations/ApiStatus OverrideOnly public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$NonExtendable org/jetbrains/annotations/ApiStatus NonExtendable public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$AvailableSince org/jetbrains/annotations/ApiStatus AvailableSince public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$ScheduledForRemoval org/jetbrains/annotations/ApiStatus ScheduledForRemoval public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$Internal org/jetbrains/annotations/ApiStatus Internal public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/ApiStatus$Experimental org/jetbrains/annotations/ApiStatus Experimental public,static,interface,abstract,annotation
in 1110
class org/jetbrains/annotations/ApiStatus$AvailableSince 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$AvailableSince org/jetbrains/annotations/ApiStatus AvailableSince public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PACKAGE])
 method public,abstract value ()Ljava/lang/String; - -
in 1110
class org/jetbrains/annotations/ApiStatus$Experimental 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$Experimental org/jetbrains/annotations/ApiStatus Experimental public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1110
class org/jetbrains/annotations/ApiStatus$Internal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$Internal org/jetbrains/annotations/ApiStatus Internal public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1110
class org/jetbrains/annotations/ApiStatus$NonExtendable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$NonExtendable org/jetbrains/annotations/ApiStatus NonExtendable public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD])
in 1111
class org/jetbrains/annotations/ApiStatus$Obsolete 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$Obsolete org/jetbrains/annotations/ApiStatus Obsolete public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PACKAGE])
 method public,abstract since ()Ljava/lang/String; - - ""
in 1110
class org/jetbrains/annotations/ApiStatus$OverrideOnly 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$OverrideOnly org/jetbrains/annotations/ApiStatus OverrideOnly public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD])
in 1110
class org/jetbrains/annotations/ApiStatus$ScheduledForRemoval 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$ScheduledForRemoval org/jetbrains/annotations/ApiStatus ScheduledForRemoval public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PACKAGE])
 method public,abstract inVersion ()Ljava/lang/String; - - ""
in 1110
class org/jetbrains/annotations/Async 52 public,final,super java/lang/Object - -
 inner org/jetbrains/annotations/Async$Execute org/jetbrains/annotations/Async Execute public,static,interface,abstract,annotation
 inner org/jetbrains/annotations/Async$Schedule org/jetbrains/annotations/Async Schedule public,static,interface,abstract,annotation
in 1110
class org/jetbrains/annotations/Async$Execute 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/Async$Execute org/jetbrains/annotations/Async Execute public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#PARAMETER])
in 1110
class org/jetbrains/annotations/Async$Schedule 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/Async$Schedule org/jetbrains/annotations/Async Schedule public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#PARAMETER])
in 1110
class org/jetbrains/annotations/Blocking 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#TYPE])
in 1110
class org/jetbrains/annotations/BlockingExecutor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1112
class org/jetbrains/annotations/CheckReturnValue 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$Experimental org/jetbrains/annotations/ApiStatus Experimental public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1113
class org/jetbrains/annotations/CheckReturnValue 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1114
class org/jetbrains/annotations/Contract 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$Experimental org/jetbrains/annotations/ApiStatus Experimental public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()Ljava/lang/String; - - ""
 method public,abstract pure ()Z - - Z0
 method public,abstract mutates ()Ljava/lang/String; - - ""
in 1115
class org/jetbrains/annotations/Contract 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()Ljava/lang/String; - - ""
 method public,abstract pure ()Z - - Z0
 method public,abstract mutates ()Ljava/lang/String; - - ""
in 1110
class org/jetbrains/annotations/Debug 52 public,final,super java/lang/Object - -
 inner org/jetbrains/annotations/Debug$Renderer org/jetbrains/annotations/Debug Renderer public,static,interface,abstract,annotation
in 1110
class org/jetbrains/annotations/Debug$Renderer 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/Debug$Renderer org/jetbrains/annotations/Debug Renderer public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract text ()Ljava/lang/String; - - ""
 method public,abstract childrenArray ()Ljava/lang/String; - - ""
 method public,abstract hasChildren ()Ljava/lang/String; - - ""
in 1110
class org/jetbrains/annotations/MustBeInvokedByOverriders 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 1110
class org/jetbrains/annotations/Nls 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/Nls$Capitalization org/jetbrains/annotations/Nls Capitalization public,static,final,enum
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
 method public,abstract capitalization ()Lorg/jetbrains/annotations/Nls$Capitalization; - - ELorg/jetbrains/annotations/Nls$Capitalization;#NotSpecified
in 1110
class org/jetbrains/annotations/Nls$Capitalization 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/jetbrains/annotations/Nls$Capitalization;>;
 inner org/jetbrains/annotations/Nls$Capitalization org/jetbrains/annotations/Nls Capitalization public,static,final,enum
 field public,static,final,enum NotSpecified Lorg/jetbrains/annotations/Nls$Capitalization; -
 field public,static,final,enum Title Lorg/jetbrains/annotations/Nls$Capitalization; -
 field public,static,final,enum Sentence Lorg/jetbrains/annotations/Nls$Capitalization; -
 method public,static values ()[Lorg/jetbrains/annotations/Nls$Capitalization; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/jetbrains/annotations/Nls$Capitalization; - -
in 1110
class org/jetbrains/annotations/NonBlocking 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#TYPE])
in 1110
class org/jetbrains/annotations/NonBlockingExecutor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1110
class org/jetbrains/annotations/NonNls 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1110
class org/jetbrains/annotations/NotNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()Ljava/lang/String; - - ""
 method public,abstract exception ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/Exception;>; - TLjava/lang/Exception;
in 1116
class org/jetbrains/annotations/NotNullByDefault 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/jetbrains/annotations/ApiStatus$Experimental org/jetbrains/annotations/ApiStatus Experimental public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1110
class org/jetbrains/annotations/Nullable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()Ljava/lang/String; - - ""
in 1110
class org/jetbrains/annotations/PropertyKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract resourceBundle ()Ljava/lang/String; - -
in 1110
class org/jetbrains/annotations/Range 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract from ()J - -
 method public,abstract to ()J - -
in 1110
class org/jetbrains/annotations/TestOnly 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
in 1110
class org/jetbrains/annotations/UnknownNullability 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()Ljava/lang/String; - - ""
in 1110
class org/jetbrains/annotations/Unmodifiable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1110
class org/jetbrains/annotations/UnmodifiableView 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1110
class org/jetbrains/annotations/VisibleForTesting 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
