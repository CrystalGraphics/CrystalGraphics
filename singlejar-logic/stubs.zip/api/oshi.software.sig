cg-stub-db 1
in 1183
class oshi/software/common/AbstractFileSystem 52 public,super,abstract java/lang/Object oshi/software/os/FileSystem -
 field public,static,final OSHI_NETWORK_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.network.filesystem.types"
 field public,static,final OSHI_PSEUDO_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.pseudo.filesystem.types"
 field protected,static,final NETWORK_FS_TYPES Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field protected,static,final PSEUDO_FS_TYPES Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 method public <init> ()V - -
 method public getFileStores ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSFileStore;>; -
in 39
class oshi/software/common/AbstractFileSystem 52 public,super,abstract java/lang/Object oshi/software/os/FileSystem -
 field protected,static,final NETWORK_FS_TYPES Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field protected,static,final PSEUDO_FS_TYPES Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 method public <init> ()V - -
 method public getFileStores ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSFileStore;>; -
in 290
class oshi/software/common/AbstractInternetProtocolStats 52 public,super,abstract java/lang/Object oshi/software/os/InternetProtocolStats -
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 method public <init> ()V - -
 method public getTCPv6Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getConnections ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
in 290
class oshi/software/common/AbstractNetworkParams 52 public,super,abstract java/lang/Object oshi/software/os/NetworkParams -
 method public <init> ()V - -
 method public getDomainName ()Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getDnsServers ()[Ljava/lang/String; - -
 method protected,static searchGateway (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/common/AbstractOSFileStore 52 public,super,abstract java/lang/Object oshi/software/os/OSFileStore -
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method protected <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getVolume ()Ljava/lang/String; - -
 method public getLabel ()Ljava/lang/String; - -
 method public getMount ()Ljava/lang/String; - -
 method public getOptions ()Ljava/lang/String; - -
 method public getUUID ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/common/AbstractOSProcess 52 public,super,abstract java/lang/Object oshi/software/os/OSProcess -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (I)V - -
 method public getProcessID ()I - -
 method public getProcessCpuLoadCumulative ()D - -
 method public getProcessCpuLoadBetweenTicks (Loshi/software/os/OSProcess;)D - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/common/AbstractOSThread 52 public,super,abstract java/lang/Object oshi/software/os/OSThread -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (I)V - -
 method public getOwningProcessId ()I - -
 method public getThreadCpuLoadCumulative ()D - -
 method public getThreadCpuLoadBetweenTicks (Loshi/software/os/OSThread;)D - -
 method public toString ()Ljava/lang/String; - -
in 1183
class oshi/software/common/AbstractOperatingSystem 52 public,super,abstract java/lang/Object oshi/software/os/OperatingSystem -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_OS_UNIX_WHOCOMMAND Ljava/lang/String; - "oshi.os.unix.whoCommand"
 field protected,static,final USE_WHO_COMMAND Z -
 method public <init> ()V - -
 method public getManufacturer ()Ljava/lang/String; - -
 method protected,abstract queryManufacturer ()Ljava/lang/String; - -
 method public getFamily ()Ljava/lang/String; - -
 method public getVersionInfo ()Loshi/software/os/OperatingSystem$OSVersionInfo; - -
 method protected,abstract queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method public getBitness ()I - -
 method protected,abstract queryBitness (I)I - -
 method public getProcesses (Ljava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,abstract queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getChildProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,abstract queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getDescendantProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,abstract queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,static getChildrenOrDescendants (Ljava/util/Collection;IZ)Ljava/util/Set; (Ljava/util/Collection<Loshi/software/os/OSProcess;>;IZ)Ljava/util/Set<Ljava/lang/Integer;>; -
 method protected,static getChildrenOrDescendants (Ljava/util/Map;IZ)Ljava/util/Set; (Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>;IZ)Ljava/util/Set<Ljava/lang/Integer;>; -
 method public toString ()Ljava/lang/String; - -
in 39
class oshi/software/common/AbstractOperatingSystem 52 public,super,abstract java/lang/Object oshi/software/os/OperatingSystem -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final USE_WHO_COMMAND Z -
 method public <init> ()V - -
 method public getManufacturer ()Ljava/lang/String; - -
 method protected,abstract queryManufacturer ()Ljava/lang/String; - -
 method public getFamily ()Ljava/lang/String; - -
 method public getVersionInfo ()Loshi/software/os/OperatingSystem$OSVersionInfo; - -
 method protected,abstract queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method public getBitness ()I - -
 method protected,abstract queryBitness (I)I - -
 method public getProcesses (Ljava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,abstract queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getChildProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,abstract queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getDescendantProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,abstract queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method protected,static getChildrenOrDescendants (Ljava/util/Collection;IZ)Ljava/util/Set; (Ljava/util/Collection<Loshi/software/os/OSProcess;>;IZ)Ljava/util/Set<Ljava/lang/Integer;>; -
 method protected,static getChildrenOrDescendants (Ljava/util/Map;IZ)Ljava/util/Set; (Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>;IZ)Ljava/util/Set<Ljava/lang/Integer;>; -
 method public toString ()Ljava/lang/String; - -
in 2
class oshi/software/os/ApplicationInfo 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/util/Map;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getVendor ()Ljava/lang/String; - -
 method public getTimestamp ()J - -
 method public getAdditionalInfo ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 371
class oshi/software/os/FileSystem 52 public,interface,abstract java/lang/Object - -
 method public,abstract getFileStores ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public,abstract getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public,abstract getOpenFileDescriptors ()J - -
 method public,abstract getMaxFileDescriptors ()J - -
in 23
class oshi/software/os/FileSystem 52 public,interface,abstract java/lang/Object - -
 method public,abstract getFileStores ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public,abstract getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public,abstract getOpenFileDescriptors ()J - -
 method public,abstract getMaxFileDescriptors ()J - -
 method public,abstract getMaxFileDescriptorsPerProcess ()J - -
in 290
class oshi/software/os/InternetProtocolStats 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 method public,abstract getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public,abstract getTCPv6Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public,abstract getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public,abstract getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public,abstract getConnections ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
in 290
class oshi/software/os/InternetProtocolStats$IPConnection 52 public,final,super java/lang/Object - -
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 method public <init> (Ljava/lang/String;[BI[BILoshi/software/os/InternetProtocolStats$TcpState;III)V - -
 method public getType ()Ljava/lang/String; - -
 method public getLocalAddress ()[B - -
 method public getLocalPort ()I - -
 method public getForeignAddress ()[B - -
 method public getForeignPort ()I - -
 method public getState ()Loshi/software/os/InternetProtocolStats$TcpState; - -
 method public getTransmitQueue ()I - -
 method public getReceiveQueue ()I - -
 method public getowningProcessId ()I - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/os/InternetProtocolStats$TcpState 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/InternetProtocolStats$TcpState;>;
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 field public,static,final,enum UNKNOWN Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum CLOSED Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum LISTEN Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum SYN_SENT Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum SYN_RECV Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum ESTABLISHED Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum FIN_WAIT_1 Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum FIN_WAIT_2 Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum CLOSE_WAIT Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum CLOSING Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum LAST_ACK Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum TIME_WAIT Loshi/software/os/InternetProtocolStats$TcpState; -
 field public,static,final,enum NONE Loshi/software/os/InternetProtocolStats$TcpState; -
 method public,static values ()[Loshi/software/os/InternetProtocolStats$TcpState; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/InternetProtocolStats$TcpState; - -
in 290
class oshi/software/os/InternetProtocolStats$TcpStats 52 public,final,super java/lang/Object - -
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 method public <init> (JJJJJJJJJJ)V - -
 method public getConnectionsEstablished ()J - -
 method public getConnectionsActive ()J - -
 method public getConnectionsPassive ()J - -
 method public getConnectionFailures ()J - -
 method public getConnectionsReset ()J - -
 method public getSegmentsSent ()J - -
 method public getSegmentsReceived ()J - -
 method public getSegmentsRetransmitted ()J - -
 method public getInErrors ()J - -
 method public getOutResets ()J - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/os/InternetProtocolStats$UdpStats 52 public,final,super java/lang/Object - -
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 method public <init> (JJJJ)V - -
 method public getDatagramsSent ()J - -
 method public getDatagramsReceived ()J - -
 method public getDatagramsNoPort ()J - -
 method public getDatagramsReceivedErrors ()J - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/os/NetworkParams 52 public,interface,abstract java/lang/Object - -
 method public,abstract getHostName ()Ljava/lang/String; - -
 method public,abstract getDomainName ()Ljava/lang/String; - -
 method public,abstract getDnsServers ()[Ljava/lang/String; - -
 method public,abstract getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public,abstract getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/OSDesktopWindow 52 public,super java/lang/Object - -
 method public <init> (JLjava/lang/String;Ljava/lang/String;Ljava/awt/Rectangle;JIZ)V - -
 method public getWindowId ()J - -
 method public getTitle ()Ljava/lang/String; - -
 method public getCommand ()Ljava/lang/String; - -
 method public getLocAndSize ()Ljava/awt/Rectangle; - -
 method public getOwningProcessId ()J - -
 method public getOrder ()I - -
 method public isVisible ()Z - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/os/OSFileStore 52 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getVolume ()Ljava/lang/String; - -
 method public,abstract getLabel ()Ljava/lang/String; - -
 method public,abstract getLogicalVolume ()Ljava/lang/String; - -
 method public,abstract getMount ()Ljava/lang/String; - -
 method public,abstract getDescription ()Ljava/lang/String; - -
 method public,abstract getType ()Ljava/lang/String; - -
 method public,abstract getOptions ()Ljava/lang/String; - -
 method public,abstract getUUID ()Ljava/lang/String; - -
 method public,abstract getFreeSpace ()J - -
 method public,abstract getUsableSpace ()J - -
 method public,abstract getTotalSpace ()J - -
 method public,abstract getFreeInodes ()J - -
 method public,abstract getTotalInodes ()J - -
 method public,abstract updateAttributes ()Z - -
in 82
class oshi/software/os/OSProcess 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPath ()Ljava/lang/String; - -
 method public,abstract getCommandLine ()Ljava/lang/String; - -
 method public,abstract getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public,abstract getUser ()Ljava/lang/String; - -
 method public,abstract getUserID ()Ljava/lang/String; - -
 method public,abstract getGroup ()Ljava/lang/String; - -
 method public,abstract getGroupID ()Ljava/lang/String; - -
 method public,abstract getState ()Loshi/software/os/OSProcess$State; - -
 method public,abstract getProcessID ()I - -
 method public,abstract getParentProcessID ()I - -
 method public,abstract getThreadCount ()I - -
 method public,abstract getPriority ()I - -
 method public,abstract getVirtualSize ()J - -
 method public,abstract getResidentSetSize ()J - -
 method public,abstract getKernelTime ()J - -
 method public,abstract getUserTime ()J - -
 method public,abstract getUpTime ()J - -
 method public,abstract getStartTime ()J - -
 method public,abstract getBytesRead ()J - -
 method public,abstract getBytesWritten ()J - -
 method public,abstract getOpenFiles ()J - -
 method public,abstract getProcessCpuLoadCumulative ()D - -
 method public,abstract getProcessCpuLoadBetweenTicks (Loshi/software/os/OSProcess;)D - -
 method public,abstract getBitness ()I - -
 method public,abstract getAffinityMask ()J - -
 method public,abstract updateAttributes ()Z - -
 method public,abstract getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
in 36
class oshi/software/os/OSProcess 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPath ()Ljava/lang/String; - -
 method public,abstract getCommandLine ()Ljava/lang/String; - -
 method public,abstract getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public,abstract getUser ()Ljava/lang/String; - -
 method public,abstract getUserID ()Ljava/lang/String; - -
 method public,abstract getGroup ()Ljava/lang/String; - -
 method public,abstract getGroupID ()Ljava/lang/String; - -
 method public,abstract getState ()Loshi/software/os/OSProcess$State; - -
 method public,abstract getProcessID ()I - -
 method public,abstract getParentProcessID ()I - -
 method public,abstract getThreadCount ()I - -
 method public,abstract getPriority ()I - -
 method public,abstract getVirtualSize ()J - -
 method public,abstract getResidentSetSize ()J - -
 method public,abstract getKernelTime ()J - -
 method public,abstract getUserTime ()J - -
 method public,abstract getUpTime ()J - -
 method public,abstract getStartTime ()J - -
 method public,abstract getBytesRead ()J - -
 method public,abstract getBytesWritten ()J - -
 method public,abstract getOpenFiles ()J - -
 method public,abstract getProcessCpuLoadCumulative ()D - -
 method public,abstract getProcessCpuLoadBetweenTicks (Loshi/software/os/OSProcess;)D - -
 method public,abstract getBitness ()I - -
 method public,abstract getAffinityMask ()J - -
 method public,abstract updateAttributes ()Z - -
 method public,abstract getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
in 23
class oshi/software/os/OSProcess 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPath ()Ljava/lang/String; - -
 method public,abstract getCommandLine ()Ljava/lang/String; - -
 method public,abstract getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public,abstract getUser ()Ljava/lang/String; - -
 method public,abstract getUserID ()Ljava/lang/String; - -
 method public,abstract getGroup ()Ljava/lang/String; - -
 method public,abstract getGroupID ()Ljava/lang/String; - -
 method public,abstract getState ()Loshi/software/os/OSProcess$State; - -
 method public,abstract getProcessID ()I - -
 method public,abstract getParentProcessID ()I - -
 method public,abstract getThreadCount ()I - -
 method public,abstract getPriority ()I - -
 method public,abstract getVirtualSize ()J - -
 method public,abstract getResidentSetSize ()J - -
 method public,abstract getKernelTime ()J - -
 method public,abstract getUserTime ()J - -
 method public,abstract getUpTime ()J - -
 method public,abstract getStartTime ()J - -
 method public,abstract getBytesRead ()J - -
 method public,abstract getBytesWritten ()J - -
 method public,abstract getOpenFiles ()J - -
 method public,abstract getSoftOpenFileLimit ()J - -
 method public,abstract getHardOpenFileLimit ()J - -
 method public,abstract getProcessCpuLoadCumulative ()D - -
 method public,abstract getProcessCpuLoadBetweenTicks (Loshi/software/os/OSProcess;)D - -
 method public,abstract getBitness ()I - -
 method public,abstract getAffinityMask ()J - -
 method public,abstract updateAttributes ()Z - -
 method public,abstract getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
in 290
class oshi/software/os/OSProcess$State 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/OSProcess$State;>;
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 field public,static,final,enum NEW Loshi/software/os/OSProcess$State; -
 field public,static,final,enum RUNNING Loshi/software/os/OSProcess$State; -
 field public,static,final,enum SLEEPING Loshi/software/os/OSProcess$State; -
 field public,static,final,enum WAITING Loshi/software/os/OSProcess$State; -
 field public,static,final,enum ZOMBIE Loshi/software/os/OSProcess$State; -
 field public,static,final,enum STOPPED Loshi/software/os/OSProcess$State; -
 field public,static,final,enum OTHER Loshi/software/os/OSProcess$State; -
 field public,static,final,enum INVALID Loshi/software/os/OSProcess$State; -
 field public,static,final,enum SUSPENDED Loshi/software/os/OSProcess$State; -
 method public,static values ()[Loshi/software/os/OSProcess$State; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/OSProcess$State; - -
in 290
class oshi/software/os/OSService 52 public,super java/lang/Object - -
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 method public <init> (Ljava/lang/String;ILoshi/software/os/OSService$State;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getProcessID ()I - -
 method public getState ()Loshi/software/os/OSService$State; - -
in 290
class oshi/software/os/OSService$State 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/OSService$State;>;
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 field public,static,final,enum RUNNING Loshi/software/os/OSService$State; -
 field public,static,final,enum STOPPED Loshi/software/os/OSService$State; -
 field public,static,final,enum OTHER Loshi/software/os/OSService$State; -
 method public,static values ()[Loshi/software/os/OSService$State; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/OSService$State; - -
in 290
class oshi/software/os/OSSession 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V - -
 method public getUserName ()Ljava/lang/String; - -
 method public getTerminalDevice ()Ljava/lang/String; - -
 method public getLoginTime ()J - -
 method public getHost ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 371
class oshi/software/os/OSThread 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public,abstract getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public,abstract getState ()Loshi/software/os/OSProcess$State; - -
 method public,abstract getThreadCpuLoadCumulative ()D - -
 method public,abstract getThreadCpuLoadBetweenTicks (Loshi/software/os/OSThread;)D - -
 method public,abstract getOwningProcessId ()I - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public,abstract getKernelTime ()J - -
 method public,abstract getUserTime ()J - -
 method public,abstract getUpTime ()J - -
 method public,abstract getStartTime ()J - -
 method public,abstract getPriority ()I - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/OSThread 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OSThread$ThreadFiltering oshi/software/os/OSThread ThreadFiltering public,static,final
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public,abstract getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public,abstract getState ()Loshi/software/os/OSProcess$State; - -
 method public,abstract getThreadCpuLoadCumulative ()D - -
 method public,abstract getThreadCpuLoadBetweenTicks (Loshi/software/os/OSThread;)D - -
 method public,abstract getOwningProcessId ()I - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public,abstract getKernelTime ()J - -
 method public,abstract getUserTime ()J - -
 method public,abstract getUpTime ()J - -
 method public,abstract getStartTime ()J - -
 method public,abstract getPriority ()I - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/OSThread$ThreadFiltering 52 public,final,super java/lang/Object - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/OSThread$ThreadFiltering oshi/software/os/OSThread ThreadFiltering public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final VALID_THREAD Ljava/util/function/Predicate; Ljava/util/function/Predicate<Loshi/software/os/OSThread;>;
in 126
class oshi/software/os/OperatingSystem 49 public,interface,abstract java/lang/Object - -
 method public,abstract getFamily ()Ljava/lang/String; - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getVersion ()Loshi/software/os/OperatingSystemVersion; - -
in 1183
class oshi/software/os/OperatingSystem 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSort oshi/software/os/OperatingSystem ProcessSort public,static,final,enum
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getFamily ()Ljava/lang/String; - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getVersionInfo ()Loshi/software/os/OperatingSystem$OSVersionInfo; - -
 method public,abstract getFileSystem ()Loshi/software/os/FileSystem; - -
 method public,abstract getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcesses (Ljava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,deprecated getProcesses (ILoshi/software/os/OperatingSystem$ProcessSort;)Ljava/util/List; (ILoshi/software/os/OperatingSystem$ProcessSort;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcess (I)Loshi/software/os/OSProcess; - -
 method public,deprecated getChildProcesses (IILoshi/software/os/OperatingSystem$ProcessSort;)Ljava/util/List; (IILoshi/software/os/OperatingSystem$ProcessSort;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getChildProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getDescendantProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcessId ()I - -
 method public,abstract getProcessCount ()I - -
 method public,abstract getThreadCount ()I - -
 method public,abstract getBitness ()I - -
 method public,abstract getSystemUptime ()J - -
 method public,abstract getSystemBootTime ()J - -
 method public isElevated ()Z - -
 method public,abstract getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 42
class oshi/software/os/OperatingSystem 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getFamily ()Ljava/lang/String; - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getVersionInfo ()Loshi/software/os/OperatingSystem$OSVersionInfo; - -
 method public,abstract getFileSystem ()Loshi/software/os/FileSystem; - -
 method public,abstract getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcesses (Ljava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcess (I)Loshi/software/os/OSProcess; - -
 method public,abstract getChildProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getDescendantProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcessId ()I - -
 method public,abstract getProcessCount ()I - -
 method public,abstract getThreadCount ()I - -
 method public,abstract getBitness ()I - -
 method public,abstract getSystemUptime ()J - -
 method public,abstract getSystemBootTime ()J - -
 method public isElevated ()Z - -
 method public,abstract getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 33
class oshi/software/os/OperatingSystem 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getFamily ()Ljava/lang/String; - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getVersionInfo ()Loshi/software/os/OperatingSystem$OSVersionInfo; - -
 method public,abstract getFileSystem ()Loshi/software/os/FileSystem; - -
 method public,abstract getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcesses (Ljava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcess (I)Loshi/software/os/OSProcess; - -
 method public,abstract getChildProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getDescendantProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcessId ()I - -
 method public getCurrentProcess ()Loshi/software/os/OSProcess; - -
 method public,abstract getProcessCount ()I - -
 method public,abstract getThreadId ()I - -
 method public,abstract getCurrentThread ()Loshi/software/os/OSThread; - -
 method public,abstract getThreadCount ()I - -
 method public,abstract getBitness ()I - -
 method public,abstract getSystemUptime ()J - -
 method public,abstract getSystemBootTime ()J - -
 method public isElevated ()Z - -
 method public,abstract getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 2
class oshi/software/os/OperatingSystem 52 public,interface,abstract java/lang/Object - -
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getFamily ()Ljava/lang/String; - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getVersionInfo ()Loshi/software/os/OperatingSystem$OSVersionInfo; - -
 method public,abstract getFileSystem ()Loshi/software/os/FileSystem; - -
 method public,abstract getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcesses (Ljava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcess (I)Loshi/software/os/OSProcess; - -
 method public,abstract getChildProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getDescendantProcesses (ILjava/util/function/Predicate;Ljava/util/Comparator;I)Ljava/util/List; (ILjava/util/function/Predicate<Loshi/software/os/OSProcess;>;Ljava/util/Comparator<Loshi/software/os/OSProcess;>;I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public,abstract getProcessId ()I - -
 method public getCurrentProcess ()Loshi/software/os/OSProcess; - -
 method public,abstract getProcessCount ()I - -
 method public,abstract getThreadId ()I - -
 method public,abstract getCurrentThread ()Loshi/software/os/OSThread; - -
 method public,abstract getThreadCount ()I - -
 method public,abstract getBitness ()I - -
 method public,abstract getSystemUptime ()J - -
 method public,abstract getSystemBootTime ()J - -
 method public isElevated ()Z - -
 method public,abstract getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
 method public getInstalledApplications ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 290
class oshi/software/os/OperatingSystem$OSVersionInfo 52 public,super java/lang/Object - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getVersion ()Ljava/lang/String; - -
 method public getCodeName ()Ljava/lang/String; - -
 method public getBuildNumber ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/software/os/OperatingSystem$ProcessFiltering 52 public,final,super java/lang/Object - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ALL_PROCESSES Ljava/util/function/Predicate; Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;
 field public,static,final VALID_PROCESS Ljava/util/function/Predicate; Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;
 field public,static,final NO_PARENT Ljava/util/function/Predicate; Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;
 field public,static,final BITNESS_64 Ljava/util/function/Predicate; Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;
 field public,static,final BITNESS_32 Ljava/util/function/Predicate; Ljava/util/function/Predicate<Loshi/software/os/OSProcess;>;
in 1183
class oshi/software/os/OperatingSystem$ProcessSort 52 public,final,super,enum,deprecated java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/OperatingSystem$ProcessSort;>;
 inner oshi/software/os/OperatingSystem$ProcessSort oshi/software/os/OperatingSystem ProcessSort public,static,final,enum
 field public,static,final,enum CPU Loshi/software/os/OperatingSystem$ProcessSort; -
 field public,static,final,enum MEMORY Loshi/software/os/OperatingSystem$ProcessSort; -
 field public,static,final,enum OLDEST Loshi/software/os/OperatingSystem$ProcessSort; -
 field public,static,final,enum NEWEST Loshi/software/os/OperatingSystem$ProcessSort; -
 field public,static,final,enum PID Loshi/software/os/OperatingSystem$ProcessSort; -
 field public,static,final,enum PARENTPID Loshi/software/os/OperatingSystem$ProcessSort; -
 field public,static,final,enum NAME Loshi/software/os/OperatingSystem$ProcessSort; -
 method public,static values ()[Loshi/software/os/OperatingSystem$ProcessSort; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/OperatingSystem$ProcessSort; - -
in 1183
class oshi/software/os/OperatingSystem$ProcessSorting 52 public,final,super java/lang/Object - -
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSort oshi/software/os/OperatingSystem ProcessSort public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NO_SORTING Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final CPU_DESC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final RSS_DESC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final UPTIME_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final UPTIME_DESC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final PID_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final PARENTPID_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final NAME_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
in 39
class oshi/software/os/OperatingSystem$ProcessSorting 52 public,final,super java/lang/Object - -
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NO_SORTING Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final CPU_DESC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final RSS_DESC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final UPTIME_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final UPTIME_DESC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final PID_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final PARENTPID_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
 field public,static,final NAME_ASC Ljava/util/Comparator; Ljava/util/Comparator<Loshi/software/os/OSProcess;>;
in 126
class oshi/software/os/OperatingSystemVersion 49 public,interface,abstract java/lang/Object - -
in 126
class oshi/software/os/Process 49 public,interface,abstract java/lang/Object - -
in 371
class oshi/software/os/linux/LinuxFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/linux/LibC$Statvfs com/sun/jna/platform/linux/LibC Statvfs public,static
 field public,static,final OSHI_LINUX_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.path.excludes"
 field public,static,final OSHI_LINUX_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.path.includes"
 field public,static,final OSHI_LINUX_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.volume.excludes"
 field public,static,final OSHI_LINUX_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 23
class oshi/software/os/linux/LinuxFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/linux/LibC$Statvfs com/sun/jna/platform/linux/LibC Statvfs public,static
 field public,static,final OSHI_LINUX_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.path.excludes"
 field public,static,final OSHI_LINUX_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.path.includes"
 field public,static,final OSHI_LINUX_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.volume.excludes"
 field public,static,final OSHI_LINUX_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.linux.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 126
class oshi/software/os/linux/LinuxHardwareAbstractionLayer 49 public,super java/lang/Object oshi/hardware/HardwareAbstractionLayer -
 method public <init> ()V - -
 method public getMemory ()Loshi/hardware/Memory; - -
 method public getProcessors ()[Loshi/hardware/Processor; - -
in 2
class oshi/software/os/linux/LinuxInstalledApps 52 public,final,super java/lang/Object - -
 method public,static queryInstalledApps ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 1186
class oshi/software/os/linux/LinuxInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getConnections ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
in 2
class oshi/software/os/linux/LinuxInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner oshi/software/os/linux/LinuxInternetProtocolStats$TcpStat oshi/software/os/linux/LinuxInternetProtocolStats TcpStat private,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/software/os/linux/LinuxInternetProtocolStats$UdpStat oshi/software/os/linux/LinuxInternetProtocolStats UdpStat private,static,final,enum
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getConnections ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
in 2
class oshi/software/os/linux/LinuxInternetProtocolStats$TcpStat 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat;>;
 inner oshi/software/os/linux/LinuxInternetProtocolStats$TcpStat oshi/software/os/linux/LinuxInternetProtocolStats TcpStat private,static,final,enum
 field public,static,final,enum RtoAlgorithm Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum RtoMin Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum RtoMax Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum MaxConn Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum ActiveOpens Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum PassiveOpens Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum AttemptFails Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum EstabResets Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum CurrEstab Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum InSegs Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum OutSegs Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum RetransSegs Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum InErrs Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum OutRsts Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 field public,static,final,enum InCsumErrors Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; -
 method public,static values ()[Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/linux/LinuxInternetProtocolStats$TcpStat; - -
in 2
class oshi/software/os/linux/LinuxInternetProtocolStats$UdpStat 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat;>;
 inner oshi/software/os/linux/LinuxInternetProtocolStats$UdpStat oshi/software/os/linux/LinuxInternetProtocolStats UdpStat private,static,final,enum
 field public,static,final,enum OutDatagrams Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum InDatagrams Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum NoPorts Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum InErrors Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum RcvbufErrors Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum SndbufErrors Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum InCsumErrors Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum IgnoredMulti Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 field public,static,final,enum MemErrors Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; -
 method public,static values ()[Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/linux/LinuxInternetProtocolStats$UdpStat; - -
in 1183
class oshi/software/os/linux/LinuxNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 39
class oshi/software/os/linux/LinuxNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/linux/LinuxOSFileStore 52 public,super oshi/software/common/AbstractOSFileStore - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJJJJ)V - -
 method public getLogicalVolume ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getFreeSpace ()J - -
 method public getUsableSpace ()J - -
 method public getTotalSpace ()J - -
 method public getFreeInodes ()J - -
 method public getTotalInodes ()J - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/linux/LinuxOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/linux/LinuxOSProcess$ProcPidStat oshi/software/os/linux/LinuxOSProcess ProcPidStat private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public updateAttributes ()Z - -
in 36
class oshi/software/os/linux/LinuxOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/linux/LinuxOSProcess$ProcPidStat oshi/software/os/linux/LinuxOSProcess ProcPidStat private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/linux/LinuxOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/OSThread$ThreadFiltering oshi/software/os/OSThread ThreadFiltering public,static,final
 inner com/sun/jna/platform/unix/Resource$Rlimit com/sun/jna/platform/unix/Resource Rlimit public,static
 inner oshi/software/os/linux/LinuxOSProcess$ProcPidStat oshi/software/os/linux/LinuxOSProcess ProcPidStat private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILoshi/software/os/linux/LinuxOperatingSystem;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public getOpenFiles ()J - -
 method public getSoftOpenFileLimit ()J - -
 method public getHardOpenFileLimit ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public updateAttributes ()Z - -
in 290
class oshi/software/os/linux/LinuxOSProcess$ProcPidStat 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/linux/LinuxOSProcess$ProcPidStat;>;
 inner oshi/software/os/linux/LinuxOSProcess$ProcPidStat oshi/software/os/linux/LinuxOSProcess ProcPidStat private,static,final,enum
 field public,static,final,enum PPID Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum MINOR_FAULTS Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum MAJOR_FAULTS Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum USER_TIME Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum KERNEL_TIME Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum PRIORITY Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum THREAD_COUNT Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum START_TIME Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum VSZ Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 field public,static,final,enum RSS Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; -
 method public,static values ()[Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/linux/LinuxOSProcess$ProcPidStat; - -
 method public getOrder ()I - -
in 290
class oshi/software/os/linux/LinuxOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/linux/LinuxOSThread$ThreadPidStat oshi/software/os/linux/LinuxOSThread ThreadPidStat private,static,final,enum
 method public <init> (II)V - -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartTime ()J - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 290
class oshi/software/os/linux/LinuxOSThread$ThreadPidStat 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/linux/LinuxOSThread$ThreadPidStat;>;
 inner oshi/software/os/linux/LinuxOSThread$ThreadPidStat oshi/software/os/linux/LinuxOSThread ThreadPidStat private,static,final,enum
 field public,static,final,enum PPID Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum MINOR_FAULTS Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum MAJOR_FAULT Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum USER_TIME Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum KERNEL_TIME Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum PRIORITY Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum THREAD_COUNT Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum START_TIME Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum VSZ Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum RSS Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 field public,static,final,enum START_CODE Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; -
 method public,static values ()[Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/linux/LinuxOSThread$ThreadPidStat; - -
 method public getOrder ()I - -
in 126
class oshi/software/os/linux/LinuxOperatingSystem 49 public,super java/lang/Object oshi/software/os/OperatingSystem -
 method public <init> ()V - -
 method public getFamily ()Ljava/lang/String; - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getVersion ()Loshi/software/os/OperatingSystemVersion; - -
 method public toString ()Ljava/lang/String; - -
in 1183
class oshi/software/os/linux/LinuxOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/linux/LibC$Sysinfo com/sun/jna/platform/linux/LibC Sysinfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method protected,static getReleaseFilename ()Ljava/lang/String; - -
 method public getServices ()[Loshi/software/os/OSService; - -
 method public,static getHz ()J - -
in 42
class oshi/software/os/linux/LinuxOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/Struct$CloseableSysinfo oshi/jna/Struct CloseableSysinfo public,static
 inner com/sun/jna/platform/linux/LibC$Sysinfo com/sun/jna/platform/linux/LibC Sysinfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final HAS_UDEV Z -
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method protected,static getReleaseFilename ()Ljava/lang/String; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public,static getHz ()J - -
 method public,static getPageSize ()J - -
in 33
class oshi/software/os/linux/LinuxOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/Struct$CloseableSysinfo oshi/jna/Struct CloseableSysinfo public,static
 inner com/sun/jna/platform/linux/LibC$Sysinfo com/sun/jna/platform/linux/LibC Sysinfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final HAS_UDEV Z -
 field public,static,final HAS_GETTID Z -
 field public,static,final HAS_SYSCALL_GETTID Z -
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method protected,static getReleaseFilename ()Ljava/lang/String; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public,static getHz ()J - -
 method public,static getPageSize ()J - -
in 2
class oshi/software/os/linux/LinuxOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/Struct$CloseableSysinfo oshi/jna/Struct CloseableSysinfo public,static
 inner com/sun/jna/platform/linux/LibC$Sysinfo com/sun/jna/platform/linux/LibC Sysinfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final HAS_UDEV Z -
 field public,static,final HAS_GETTID Z -
 field public,static,final HAS_SYSCALL_GETTID Z -
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getInstalledApplications ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
 method protected,static getReleaseFilename ()Ljava/lang/String; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public,static getHz ()J - -
 method public,static getPageSize ()J - -
in 126
class oshi/software/os/linux/proc/CentralProcessor 49 public,super java/lang/Object oshi/hardware/Processor -
 method public <init> ()V - -
 method public getVendor ()Ljava/lang/String; - -
 method public setVendor (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public getIdentifier ()Ljava/lang/String; - -
 method public setIdentifier (Ljava/lang/String;)V - -
 method public isCpu64bit ()Z - -
 method public setCpu64 (Z)V - -
 method public getStepping ()Ljava/lang/String; - -
 method public setStepping (Ljava/lang/String;)V - -
 method public getModel ()Ljava/lang/String; - -
 method public setModel (Ljava/lang/String;)V - -
 method public getFamily ()Ljava/lang/String; - -
 method public setFamily (Ljava/lang/String;)V - -
 method public getLoad ()F - -
 method public toString ()Ljava/lang/String; - -
in 126
class oshi/software/os/linux/proc/GlobalMemory 49 public,super java/lang/Object oshi/hardware/Memory -
 method public <init> ()V - -
 method public getAvailable ()J - -
 method public getTotal ()J - -
in 126
class oshi/software/os/linux/proc/OSVersionInfoEx 49 public,super java/lang/Object oshi/software/os/OperatingSystemVersion -
 method public <init> ()V - -
 method public getCodeName ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public setCodeName (Ljava/lang/String;)V - -
 method public setVersion (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
in 371
class oshi/software/os/mac/MacFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/mac/SystemB$Statfs com/sun/jna/platform/mac/SystemB Statfs public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef com/sun/jna/platform/mac/CoreFoundation CFAllocatorRef public,static
 inner com/sun/jna/platform/mac/DiskArbitration$DASessionRef com/sun/jna/platform/mac/DiskArbitration DASessionRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner com/sun/jna/platform/mac/DiskArbitration$DADiskRef com/sun/jna/platform/mac/DiskArbitration DADiskRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFMutableDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFMutableDictionaryRef public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_MAC_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.path.excludes"
 field public,static,final OSHI_MAC_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.path.includes"
 field public,static,final OSHI_MAC_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.volume.excludes"
 field public,static,final OSHI_MAC_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 33
class oshi/software/os/mac/MacFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/mac/SystemB$Statfs com/sun/jna/platform/mac/SystemB Statfs public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef com/sun/jna/platform/mac/CoreFoundation CFAllocatorRef public,static
 inner com/sun/jna/platform/mac/DiskArbitration$DASessionRef com/sun/jna/platform/mac/DiskArbitration DASessionRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner com/sun/jna/platform/mac/DiskArbitration$DADiskRef com/sun/jna/platform/mac/DiskArbitration DADiskRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFMutableDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFMutableDictionaryRef public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_MAC_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.path.excludes"
 field public,static,final OSHI_MAC_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.path.includes"
 field public,static,final OSHI_MAC_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.volume.excludes"
 field public,static,final OSHI_MAC_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 2
class oshi/software/os/mac/MacFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/mac/SystemB$Statfs com/sun/jna/platform/mac/SystemB Statfs public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef com/sun/jna/platform/mac/CoreFoundation CFAllocatorRef public,static
 inner com/sun/jna/platform/mac/DiskArbitration$DASessionRef com/sun/jna/platform/mac/DiskArbitration DASessionRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner com/sun/jna/platform/mac/DiskArbitration$DADiskRef com/sun/jna/platform/mac/DiskArbitration DADiskRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFMutableDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFMutableDictionaryRef public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_MAC_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.path.excludes"
 field public,static,final OSHI_MAC_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.path.includes"
 field public,static,final OSHI_MAC_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.volume.excludes"
 field public,static,final OSHI_MAC_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.mac.filesystem.volume.includes"
 field protected,static,final FS_PATH_EXCLUDES Ljava/util/List; Ljava/util/List<Ljava/nio/file/PathMatcher;>;
 field protected,static,final FS_PATH_INCLUDES Ljava/util/List; Ljava/util/List<Ljava/nio/file/PathMatcher;>;
 field protected,static,final FS_VOLUME_EXCLUDES Ljava/util/List; Ljava/util/List<Ljava/nio/file/PathMatcher;>;
 field protected,static,final FS_VOLUME_INCLUDES Ljava/util/List; Ljava/util/List<Ljava/nio/file/PathMatcher;>;
 field protected,static,final LOCAL_DISK Ljava/util/regex/Pattern; -
 field protected,static,final MNT_RDONLY I - I1
 field protected,static,final MNT_SYNCHRONOUS I - I2
 field protected,static,final MNT_NOEXEC I - I4
 field protected,static,final MNT_NOSUID I - I8
 field protected,static,final MNT_NODEV I - I16
 field protected,static,final MNT_UNION I - I32
 field protected,static,final MNT_ASYNC I - I64
 field protected,static,final MNT_CPROTECT I - I128
 field protected,static,final MNT_EXPORTED I - I256
 field protected,static,final MNT_QUARANTINE I - I1024
 field protected,static,final MNT_LOCAL I - I4096
 field protected,static,final MNT_QUOTA I - I8192
 field protected,static,final MNT_ROOTFS I - I16384
 field protected,static,final MNT_DOVOLFS I - I32768
 field protected,static,final MNT_DONTBROWSE I - I1048576
 field protected,static,final MNT_IGNORE_OWNERSHIP I - I2097152
 field protected,static,final MNT_AUTOMOUNTED I - I4194304
 field protected,static,final MNT_JOURNALED I - I8388608
 field protected,static,final MNT_NOUSERXATTR I - I16777216
 field protected,static,final MNT_DEFWRITE I - I33554432
 field protected,static,final MNT_MULTILABEL I - I67108864
 field protected,static,final MNT_NOATIME I - I268435456
 field protected,static,final OPTIONS_MAP Ljava/util/Map; Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 126
class oshi/software/os/mac/MacHardwareAbstractionLayer 49 public,super java/lang/Object oshi/hardware/HardwareAbstractionLayer -
 method public <init> ()V - -
 method public getProcessors ()[Loshi/hardware/Processor; - -
 method public getMemory ()Loshi/hardware/Memory; - -
in 2
class oshi/software/os/mac/MacInstalledApps 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle oshi/jna/platform/mac/CoreFoundation CFDateFormatterStyle public,static,final,enum
 inner com/sun/jna/platform/mac/CoreFoundation$CFIndex com/sun/jna/platform/mac/CoreFoundation CFIndex public,static
 inner oshi/jna/platform/mac/CoreFoundation$CFLocale oshi/jna/platform/mac/CoreFoundation CFLocale public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef com/sun/jna/platform/mac/CoreFoundation CFAllocatorRef public,static
 inner oshi/jna/platform/mac/CoreFoundation$CFDateFormatter oshi/jna/platform/mac/CoreFoundation CFDateFormatter public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 method public,static queryInstalledApps ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 290
class oshi/software/os/mac/MacInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner oshi/jna/platform/unix/CLibrary$BsdTcpstat oshi/jna/platform/unix/CLibrary BsdTcpstat public,static
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/jna/platform/unix/CLibrary$BsdIpstat oshi/jna/platform/unix/CLibrary BsdIpstat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdUdpstat oshi/jna/platform/unix/CLibrary BsdUdpstat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdIp6stat oshi/jna/platform/unix/CLibrary BsdIp6stat public,static
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 inner oshi/jna/platform/mac/SystemB$ProcFdInfo oshi/jna/platform/mac/SystemB ProcFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$SocketFdInfo oshi/jna/platform/mac/SystemB SocketFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$SocketInfo oshi/jna/platform/mac/SystemB SocketInfo public,static
 inner oshi/jna/platform/mac/SystemB$Pri oshi/jna/platform/mac/SystemB Pri public,static
 inner oshi/jna/platform/mac/SystemB$TcpSockInfo oshi/jna/platform/mac/SystemB TcpSockInfo public,static
 inner oshi/jna/platform/mac/SystemB$InSockInfo oshi/jna/platform/mac/SystemB InSockInfo public,static
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Z)V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getTCPv6Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getConnections ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
 method public,static queryUdpstat ()Loshi/jna/platform/unix/CLibrary$BsdUdpstat; - -
in 1183
class oshi/software/os/mac/MacNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 39
class oshi/software/os/mac/MacNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/mac/MacOSFileStore 52 public,super oshi/software/common/AbstractOSFileStore - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJJJJ)V - -
 method public getLogicalVolume ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getFreeSpace ()J - -
 method public getUsableSpace ()J - -
 method public getTotalSpace ()J - -
 method public getFreeInodes ()J - -
 method public getTotalInodes ()J - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/mac/MacOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner oshi/driver/mac/ThreadInfo$ThreadStats oshi/driver/mac/ThreadInfo ThreadStats public,static
 inner com/sun/jna/platform/mac/SystemB$ProcTaskAllInfo com/sun/jna/platform/mac/SystemB ProcTaskAllInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcTaskInfo com/sun/jna/platform/mac/SystemB ProcTaskInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcBsdInfo com/sun/jna/platform/mac/SystemB ProcBsdInfo public,static
 inner com/sun/jna/platform/mac/SystemB$Passwd com/sun/jna/platform/mac/SystemB Passwd public,static
 inner com/sun/jna/platform/mac/SystemB$Group com/sun/jna/platform/mac/SystemB Group public,static
 inner com/sun/jna/platform/mac/SystemB$RUsageInfoV2 com/sun/jna/platform/mac/SystemB RUsageInfoV2 public,static
 inner com/sun/jna/platform/mac/SystemB$VnodePathInfo com/sun/jna/platform/mac/SystemB VnodePathInfo public,static
 inner com/sun/jna/platform/mac/SystemB$VnodeInfoPath com/sun/jna/platform/mac/SystemB VnodeInfoPath public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (II)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/mac/MacOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/driver/mac/ThreadInfo$ThreadStats oshi/driver/mac/ThreadInfo ThreadStats public,static
 inner com/sun/jna/platform/mac/SystemB$ProcTaskAllInfo com/sun/jna/platform/mac/SystemB ProcTaskAllInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcTaskInfo com/sun/jna/platform/mac/SystemB ProcTaskInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcBsdInfo com/sun/jna/platform/mac/SystemB ProcBsdInfo public,static
 inner com/sun/jna/platform/mac/SystemB$Passwd com/sun/jna/platform/mac/SystemB Passwd public,static
 inner com/sun/jna/platform/mac/SystemB$Group com/sun/jna/platform/mac/SystemB Group public,static
 inner com/sun/jna/platform/mac/SystemB$RUsageInfoV2 com/sun/jna/platform/mac/SystemB RUsageInfoV2 public,static
 inner com/sun/jna/platform/mac/SystemB$VnodePathInfo com/sun/jna/platform/mac/SystemB VnodePathInfo public,static
 inner com/sun/jna/platform/mac/SystemB$VnodeInfoPath com/sun/jna/platform/mac/SystemB VnodeInfoPath public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (II)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 42
class oshi/software/os/mac/MacOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/driver/mac/ThreadInfo$ThreadStats oshi/driver/mac/ThreadInfo ThreadStats public,static
 inner oshi/jna/Struct$CloseableProcTaskAllInfo oshi/jna/Struct CloseableProcTaskAllInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcTaskInfo com/sun/jna/platform/mac/SystemB ProcTaskInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcBsdInfo com/sun/jna/platform/mac/SystemB ProcBsdInfo public,static
 inner com/sun/jna/platform/mac/SystemB$Passwd com/sun/jna/platform/mac/SystemB Passwd public,static
 inner com/sun/jna/platform/mac/SystemB$Group com/sun/jna/platform/mac/SystemB Group public,static
 inner oshi/jna/Struct$CloseableRUsageInfoV2 oshi/jna/Struct CloseableRUsageInfoV2 public,static
 inner com/sun/jna/platform/mac/SystemB$RUsageInfoV2 com/sun/jna/platform/mac/SystemB RUsageInfoV2 public,static
 inner oshi/jna/Struct$CloseableVnodePathInfo oshi/jna/Struct CloseableVnodePathInfo public,static
 inner com/sun/jna/platform/mac/SystemB$VnodeInfoPath com/sun/jna/platform/mac/SystemB VnodeInfoPath public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (III)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/mac/MacOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner com/sun/jna/platform/unix/Resource$Rlimit com/sun/jna/platform/unix/Resource Rlimit public,static
 inner oshi/jna/Struct$CloseableProcTaskAllInfo oshi/jna/Struct CloseableProcTaskAllInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcTaskInfo com/sun/jna/platform/mac/SystemB ProcTaskInfo public,static
 inner com/sun/jna/platform/mac/SystemB$ProcBsdInfo com/sun/jna/platform/mac/SystemB ProcBsdInfo public,static
 inner com/sun/jna/platform/mac/SystemB$Passwd com/sun/jna/platform/mac/SystemB Passwd public,static
 inner com/sun/jna/platform/mac/SystemB$Group com/sun/jna/platform/mac/SystemB Group public,static
 inner oshi/jna/Struct$CloseableRUsageInfoV2 oshi/jna/Struct CloseableRUsageInfoV2 public,static
 inner com/sun/jna/platform/mac/SystemB$RUsageInfoV2 com/sun/jna/platform/mac/SystemB RUsageInfoV2 public,static
 inner oshi/jna/Struct$CloseableVnodePathInfo oshi/jna/Struct CloseableVnodePathInfo public,static
 inner com/sun/jna/platform/mac/SystemB$VnodeInfoPath com/sun/jna/platform/mac/SystemB VnodeInfoPath public,static
 inner oshi/driver/mac/ThreadInfo$ThreadStats oshi/driver/mac/ThreadInfo ThreadStats public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (IIILoshi/software/os/mac/MacOperatingSystem;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getSoftOpenFileLimit ()J - -
 method public getHardOpenFileLimit ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 371
class oshi/software/os/mac/MacOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public <init> (IILoshi/software/os/OSProcess$State;JJJJI)V - -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getStartTime ()J - -
 method public getUpTime ()J - -
 method public getPriority ()I - -
in 23
class oshi/software/os/mac/MacOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public <init> (IILoshi/software/os/OSProcess$State;JJJJI)V - -
 method public <init> (I)V - -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getStartTime ()J - -
 method public getUpTime ()J - -
 method public getPriority ()I - -
in 126
class oshi/software/os/mac/MacOperatingSystem 49 public,super java/lang/Object oshi/software/os/OperatingSystem -
 method public <init> ()V - -
 method public getVersion ()Loshi/software/os/OperatingSystemVersion; - -
 method public getFamily ()Ljava/lang/String; - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 1183
class oshi/software/os/mac/MacOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/mac/SystemB$ProcTaskInfo com/sun/jna/platform/mac/SystemB ProcTaskInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner com/sun/jna/platform/mac/SystemB$Timeval com/sun/jna/platform/mac/SystemB Timeval public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final MACOS_VERSIONS_PROPERTIES Ljava/lang/String; - "oshi.macos.versions.properties"
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 42
class oshi/software/os/mac/MacOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/Struct$CloseableProcTaskInfo oshi/jna/Struct CloseableProcTaskInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/jna/Struct$CloseableTimeval oshi/jna/Struct CloseableTimeval public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final MACOS_VERSIONS_PROPERTIES Ljava/lang/String; - "oshi.macos.versions.properties"
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 33
class oshi/software/os/mac/MacOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/Struct$CloseableProcTaskInfo oshi/jna/Struct CloseableProcTaskInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/jna/Struct$CloseableTimeval oshi/jna/Struct CloseableTimeval public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final MACOS_VERSIONS_PROPERTIES Ljava/lang/String; - "oshi.macos.versions.properties"
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 2
class oshi/software/os/mac/MacOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/Struct$CloseableProcTaskInfo oshi/jna/Struct CloseableProcTaskInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/jna/Struct$CloseableTimeval oshi/jna/Struct CloseableTimeval public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final MACOS_VERSIONS_PROPERTIES Ljava/lang/String; - "oshi.macos.versions.properties"
 field protected,final maxProc I -
 field protected,final osXVersion Ljava/lang/String; -
 field protected,final major I -
 field protected,final minor I -
 method public <init> ()V - -
 method protected <init> (I)V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected parseCodeName ()Ljava/lang/String; - -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
 method public getInstalledApplications ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 126
class oshi/software/os/mac/local/CentralProcessor 49 public,super java/lang/Object oshi/hardware/Processor -
 method public <init> ()V - -
 method public getVendor ()Ljava/lang/String; - -
 method public setVendor (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public getIdentifier ()Ljava/lang/String; - -
 method public setIdentifier (Ljava/lang/String;)V - -
 method public isCpu64bit ()Z - -
 method public setCpu64 (Z)V - -
 method public getStepping ()Ljava/lang/String; - -
 method public setStepping (Ljava/lang/String;)V - -
 method public getModel ()Ljava/lang/String; - -
 method public setModel (Ljava/lang/String;)V - -
 method public getFamily ()Ljava/lang/String; - -
 method public setFamily (Ljava/lang/String;)V - -
 method public getLoad ()F - -
 method public toString ()Ljava/lang/String; - -
in 126
class oshi/software/os/mac/local/GlobalMemory 49 public,super java/lang/Object oshi/hardware/Memory -
 method public <init> ()V - -
 method public getAvailable ()J - -
 method public getTotal ()J - -
in 126
class oshi/software/os/mac/local/OSVersionInfoEx 49 public,super java/lang/Object oshi/software/os/OperatingSystemVersion -
 method public <init> ()V - -
 method public getVersion ()Ljava/lang/String; - -
 method public setVersion (Ljava/lang/String;)V - -
 method public getCodeName ()Ljava/lang/String; - -
 method public setCodeName (Ljava/lang/String;)V - -
 method public getBuildNumber ()Ljava/lang/String; - -
 method public setBuildNumber (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
in 371
class oshi/software/os/unix/aix/AixFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 field public,static,final OSHI_AIX_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.path.excludes"
 field public,static,final OSHI_AIX_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.path.includes"
 field public,static,final OSHI_AIX_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.volume.excludes"
 field public,static,final OSHI_AIX_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 23
class oshi/software/os/unix/aix/AixFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 field public,static,final OSHI_AIX_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.path.excludes"
 field public,static,final OSHI_AIX_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.path.includes"
 field public,static,final OSHI_AIX_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.volume.excludes"
 field public,static,final OSHI_AIX_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.aix.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 2
class oshi/software/os/unix/aix/AixInstalledApps 52 public,final,super java/lang/Object - -
 method public,static queryInstalledApps ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 290
class oshi/software/os/unix/aix/AixInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t com/sun/jna/platform/unix/aix/Perfstat perfstat_protocol_t public,static
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t$AnonymousUnionPayload com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t AnonymousUnionPayload public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t$AnonymousStructTCP com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t AnonymousStructTCP public,static
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t$AnonymousStructUDP com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t AnonymousStructUDP public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
in 290
class oshi/software/os/unix/aix/AixNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/unix/aix/AixOSFileStore 52 public,super oshi/software/common/AbstractOSFileStore - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJJJJ)V - -
 method public getLogicalVolume ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getFreeSpace ()J - -
 method public getUsableSpace ()J - -
 method public getTotalSpace ()J - -
 method public getFreeInodes ()J - -
 method public getTotalInodes ()J - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/aix/AixOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I[Ljava/lang/String;Ljava/util/Map;Ljava/util/function/Supplier;)V (I[Ljava/lang/String;Ljava/util/Map<Ljava/lang/Integer;Loshi/util/tuples/Pair<Ljava/lang/Long;Ljava/lang/Long;>;>;Ljava/util/function/Supplier<[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMajorFaults ()J - -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/aix/AixOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/aix/AixOSProcess$PsThreadColumns oshi/software/os/unix/aix/AixOSProcess PsThreadColumns static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner oshi/software/os/unix/aix/AixOperatingSystem$PsKeywords oshi/software/os/unix/aix/AixOperatingSystem PsKeywords static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;Ljava/util/Map;Ljava/util/function/Supplier;)V (ILjava/util/Map<Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords;Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/util/tuples/Pair<Ljava/lang/Long;Ljava/lang/Long;>;>;Ljava/util/function/Supplier<[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMajorFaults ()J - -
 method public updateAttributes ()Z - -
in 42
class oshi/software/os/unix/aix/AixOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/platform/unix/AixLibc$AixPsInfo oshi/jna/platform/unix/AixLibc AixPsInfo public,static
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner oshi/jna/platform/unix/AixLibc$Timestruc oshi/jna/platform/unix/AixLibc Timestruc public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILoshi/util/tuples/Pair;Ljava/util/function/Supplier;)V (ILoshi/util/tuples/Pair<Ljava/lang/Long;Ljava/lang/Long;>;Ljava/util/function/Supplier<[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/unix/aix/AixOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/platform/unix/AixLibc$AixPsInfo oshi/jna/platform/unix/AixLibc AixPsInfo public,static
 inner com/sun/jna/platform/unix/Resource$Rlimit com/sun/jna/platform/unix/Resource Rlimit public,static
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 inner oshi/software/os/OSThread$ThreadFiltering oshi/software/os/OSThread ThreadFiltering public,static,final
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner oshi/jna/platform/unix/AixLibc$Timestruc oshi/jna/platform/unix/AixLibc Timestruc public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILoshi/util/tuples/Pair;Ljava/util/function/Supplier;Loshi/software/os/unix/aix/AixOperatingSystem;)V (ILoshi/util/tuples/Pair<Ljava/lang/Long;Ljava/lang/Long;>;Ljava/util/function/Supplier<[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t;>;Loshi/software/os/unix/aix/AixOperatingSystem;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getSoftOpenFileLimit ()J - -
 method public getHardOpenFileLimit ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/aix/AixOSProcess$PsThreadColumns 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns;>;
 inner oshi/software/os/unix/aix/AixOSProcess$PsThreadColumns oshi/software/os/unix/aix/AixOSProcess PsThreadColumns static,final,enum
 field public,static,final,enum USER Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum PID Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum PPID Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum TID Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum ST Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum CP Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum PRI Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum SC Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum WCHAN Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum F Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum TT Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum BND Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 field public,static,final,enum COMMAND Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; -
 method public,static values ()[Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns; - -
in 82
class oshi/software/os/unix/aix/AixOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public <init> (I[Ljava/lang/String;)V - -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getContextSwitches ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/aix/AixOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/aix/AixOSProcess$PsThreadColumns oshi/software/os/unix/aix/AixOSProcess PsThreadColumns static,final,enum
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/aix/AixOSProcess$PsThreadColumns;Ljava/lang/String;>;)V -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getContextSwitches ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 39
class oshi/software/os/unix/aix/AixOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 method public <init> (II)V - -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/aix/AixOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 34
class oshi/software/os/unix/aix/AixOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner oshi/software/os/unix/aix/AixOperatingSystem$PsKeywords oshi/software/os/unix/aix/AixOperatingSystem PsKeywords static,final,enum
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 42
class oshi/software/os/unix/aix/AixOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 33
class oshi/software/os/unix/aix/AixOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 2
class oshi/software/os/unix/aix/AixOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getInstalledApplications ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 34
class oshi/software/os/unix/aix/AixOperatingSystem$PsKeywords 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords;>;
 inner oshi/software/os/unix/aix/AixOperatingSystem$PsKeywords oshi/software/os/unix/aix/AixOperatingSystem PsKeywords static,final,enum
 field public,static,final,enum ST Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum PID Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum PPID Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum USER Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum UID Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum GROUP Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum GID Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum THCOUNT Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum PRI Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum VSIZE Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum RSSIZE Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum ETIME Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum TIME Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum COMM Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum PAGEIN Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 field public,static,final,enum ARGS Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; -
 method public,static values ()[Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/aix/AixOperatingSystem$PsKeywords; - -
in 371
class oshi/software/os/unix/freebsd/FreeBsdFileSystem 52 public,final,super oshi/software/common/AbstractFileSystem - -
 field public,static,final OSHI_FREEBSD_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.path.excludes"
 field public,static,final OSHI_FREEBSD_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.path.includes"
 field public,static,final OSHI_FREEBSD_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.volume.excludes"
 field public,static,final OSHI_FREEBSD_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 23
class oshi/software/os/unix/freebsd/FreeBsdFileSystem 52 public,final,super oshi/software/common/AbstractFileSystem - -
 field public,static,final OSHI_FREEBSD_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.path.excludes"
 field public,static,final OSHI_FREEBSD_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.path.includes"
 field public,static,final OSHI_FREEBSD_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.volume.excludes"
 field public,static,final OSHI_FREEBSD_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.freebsd.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 290
class oshi/software/os/unix/freebsd/FreeBsdInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner oshi/jna/platform/unix/CLibrary$BsdTcpstat oshi/jna/platform/unix/CLibrary BsdTcpstat public,static
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/jna/platform/unix/CLibrary$BsdUdpstat oshi/jna/platform/unix/CLibrary BsdUdpstat public,static
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
in 1183
class oshi/software/os/unix/freebsd/FreeBsdNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 39
class oshi/software/os/unix/freebsd/FreeBsdNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/unix/freebsd/FreeBsdOSFileStore 52 public,super oshi/software/common/AbstractOSFileStore - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJJJJ)V - -
 method public getLogicalVolume ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getFreeSpace ()J - -
 method public getUsableSpace ()J - -
 method public getTotalSpace ()J - -
 method public getFreeInodes ()J - -
 method public getTotalInodes ()J - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/freebsd/FreeBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I[Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/freebsd/FreeBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns oshi/software/os/unix/freebsd/FreeBsdOSProcess PsThreadColumns static,final,enum
 inner oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords oshi/software/os/unix/freebsd/FreeBsdOperatingSystem PsKeywords static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords;Ljava/lang/String;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 42
class oshi/software/os/unix/freebsd/FreeBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns oshi/software/os/unix/freebsd/FreeBsdOSProcess PsThreadColumns static,final,enum
 inner oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords oshi/software/os/unix/freebsd/FreeBsdOperatingSystem PsKeywords static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords;Ljava/lang/String;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/unix/freebsd/FreeBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner com/sun/jna/platform/unix/Resource$Rlimit com/sun/jna/platform/unix/Resource Rlimit public,static
 inner oshi/software/os/OSThread$ThreadFiltering oshi/software/os/OSThread ThreadFiltering public,static,final
 inner oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords oshi/software/os/unix/freebsd/FreeBsdOperatingSystem PsKeywords static,final,enum
 inner oshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns oshi/software/os/unix/freebsd/FreeBsdOSProcess PsThreadColumns static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem;)V (ILjava/util/Map<Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords;Ljava/lang/String;>;Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getSoftOpenFileLimit ()J - -
 method public getHardOpenFileLimit ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 30
class oshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns;>;
 inner oshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns oshi/software/os/unix/freebsd/FreeBsdOSProcess PsThreadColumns static,final,enum
 field public,static,final,enum TDNAME Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum LWP Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum STATE Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum ETIMES Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum SYSTIME Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum TIME Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum TDADDR Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum NIVCSW Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum NVCSW Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum MAJFLT Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum MINFLT Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum PRI Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; -
 method public,static values ()[Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns; - -
in 82
class oshi/software/os/unix/freebsd/FreeBsdOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public <init> (I[Ljava/lang/String;)V - -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 36
class oshi/software/os/unix/freebsd/FreeBsdOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns oshi/software/os/unix/freebsd/FreeBsdOSProcess PsThreadColumns static,final,enum
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns;Ljava/lang/String;>;)V -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/unix/freebsd/FreeBsdOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns oshi/software/os/unix/freebsd/FreeBsdOSProcess PsThreadColumns static,final,enum
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/freebsd/FreeBsdOSProcess$PsThreadColumns;Ljava/lang/String;>;)V -
 method public <init> (II)V - -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/freebsd/FreeBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval oshi/jna/platform/unix/freebsd/FreeBsdLibc Timeval public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 34
class oshi/software/os/unix/freebsd/FreeBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords oshi/software/os/unix/freebsd/FreeBsdOperatingSystem PsKeywords static,final,enum
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval oshi/jna/platform/unix/freebsd/FreeBsdLibc Timeval public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 42
class oshi/software/os/unix/freebsd/FreeBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords oshi/software/os/unix/freebsd/FreeBsdOperatingSystem PsKeywords static,final,enum
 inner oshi/jna/platform/unix/FreeBsdLibc$Timeval oshi/jna/platform/unix/FreeBsdLibc Timeval public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 23
class oshi/software/os/unix/freebsd/FreeBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/jna/platform/unix/FreeBsdLibc$Timeval oshi/jna/platform/unix/FreeBsdLibc Timeval public,static
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords oshi/software/os/unix/freebsd/FreeBsdOperatingSystem PsKeywords static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 30
class oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords;>;
 inner oshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords oshi/software/os/unix/freebsd/FreeBsdOperatingSystem PsKeywords static,final,enum
 field public,static,final,enum STATE Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum PID Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum PPID Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum USER Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum UID Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum GROUP Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum GID Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum NLWP Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum PRI Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum VSZ Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum RSS Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum ETIMES Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum SYSTIME Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum TIME Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum COMM Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum MAJFLT Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum MINFLT Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum NVCSW Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum NIVCSW Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum ARGS Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; -
 method public,static values ()[Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/freebsd/FreeBsdOperatingSystem$PsKeywords; - -
in 371
class oshi/software/os/unix/openbsd/OpenBsdFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 field public,static,final OSHI_OPENBSD_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.path.excludes"
 field public,static,final OSHI_OPENBSD_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.path.includes"
 field public,static,final OSHI_OPENBSD_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.volume.excludes"
 field public,static,final OSHI_OPENBSD_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 23
class oshi/software/os/unix/openbsd/OpenBsdFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 field public,static,final OSHI_OPENBSD_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.path.excludes"
 field public,static,final OSHI_OPENBSD_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.path.includes"
 field public,static,final OSHI_OPENBSD_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.volume.excludes"
 field public,static,final OSHI_OPENBSD_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.openbsd.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 290
class oshi/software/os/unix/openbsd/OpenBsdInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
in 290
class oshi/software/os/unix/openbsd/OpenBsdNetworkParams 52 public,super oshi/software/common/AbstractNetworkParams - -
 method public <init> ()V - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/unix/openbsd/OpenBsdOSFileStore 52 public,super oshi/software/common/AbstractOSFileStore - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJJJJ)V - -
 method public getLogicalVolume ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getFreeSpace ()J - -
 method public getUsableSpace ()J - -
 method public getTotalSpace ()J - -
 method public getFreeInodes ()J - -
 method public getTotalInodes ()J - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/openbsd/OpenBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I[Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/openbsd/OpenBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns oshi/software/os/unix/openbsd/OpenBsdOSProcess PsThreadColumns static,final,enum
 inner oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords oshi/software/os/unix/openbsd/OpenBsdOperatingSystem PsKeywords static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords;Ljava/lang/String;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 42
class oshi/software/os/unix/openbsd/OpenBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns oshi/software/os/unix/openbsd/OpenBsdOSProcess PsThreadColumns static,final,enum
 inner oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords oshi/software/os/unix/openbsd/OpenBsdOperatingSystem PsKeywords static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords;Ljava/lang/String;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/unix/openbsd/OpenBsdOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner com/sun/jna/platform/unix/Resource$Rlimit com/sun/jna/platform/unix/Resource Rlimit public,static
 inner oshi/software/os/OSThread$ThreadFiltering oshi/software/os/OSThread ThreadFiltering public,static,final
 inner oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords oshi/software/os/unix/openbsd/OpenBsdOperatingSystem PsKeywords static,final,enum
 inner oshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns oshi/software/os/unix/openbsd/OpenBsdOSProcess PsThreadColumns static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem;)V (ILjava/util/Map<Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords;Ljava/lang/String;>;Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getSoftOpenFileLimit ()J - -
 method public getHardOpenFileLimit ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public updateAttributes ()Z - -
in 30
class oshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns;>;
 inner oshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns oshi/software/os/unix/openbsd/OpenBsdOSProcess PsThreadColumns static,final,enum
 field public,static,final,enum TID Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum STATE Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum ETIME Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum CPUTIME Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum NIVCSW Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum NVCSW Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum MAJFLT Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum MINFLT Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum PRI Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 field public,static,final,enum ARGS Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; -
 method public,static values ()[Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns; - -
in 82
class oshi/software/os/unix/openbsd/OpenBsdOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public <init> (I[Ljava/lang/String;)V - -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 36
class oshi/software/os/unix/openbsd/OpenBsdOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns oshi/software/os/unix/openbsd/OpenBsdOSProcess PsThreadColumns static,final,enum
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns;Ljava/lang/String;>;)V -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/unix/openbsd/OpenBsdOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns oshi/software/os/unix/openbsd/OpenBsdOSProcess PsThreadColumns static,final,enum
 method public <init> (ILjava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/openbsd/OpenBsdOSProcess$PsThreadColumns;Ljava/lang/String;>;)V -
 method public <init> (II)V - -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/openbsd/OpenBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 34
class oshi/software/os/unix/openbsd/OpenBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords oshi/software/os/unix/openbsd/OpenBsdOperatingSystem PsKeywords static,final,enum
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 42
class oshi/software/os/unix/openbsd/OpenBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords oshi/software/os/unix/openbsd/OpenBsdOperatingSystem PsKeywords static,final,enum
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 23
class oshi/software/os/unix/openbsd/OpenBsdOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords oshi/software/os/unix/openbsd/OpenBsdOperatingSystem PsKeywords static,final,enum
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/software/os/OperatingSystem$ProcessSorting oshi/software/os/OperatingSystem ProcessSorting public,static,final
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 30
class oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords;>;
 inner oshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords oshi/software/os/unix/openbsd/OpenBsdOperatingSystem PsKeywords static,final,enum
 field public,static,final,enum STATE Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum PID Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum PPID Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum USER Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum UID Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum GROUP Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum GID Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum PRI Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum VSZ Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum RSS Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum ETIME Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum CPUTIME Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum COMM Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum MAJFLT Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum MINFLT Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum NVCSW Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum NIVCSW Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 field public,static,final,enum ARGS Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; -
 method public,static values ()[Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/openbsd/OpenBsdOperatingSystem$PsKeywords; - -
in 1183
class oshi/software/os/unix/solaris/SolarisFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 field public,static,final OSHI_SOLARIS_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.path.excludes"
 field public,static,final OSHI_SOLARIS_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.path.includes"
 field public,static,final OSHI_SOLARIS_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.volume.excludes"
 field public,static,final OSHI_SOLARIS_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 42
class oshi/software/os/unix/solaris/SolarisFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_SOLARIS_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.path.excludes"
 field public,static,final OSHI_SOLARIS_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.path.includes"
 field public,static,final OSHI_SOLARIS_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.volume.excludes"
 field public,static,final OSHI_SOLARIS_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 23
class oshi/software/os/unix/solaris/SolarisFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_SOLARIS_FS_PATH_EXCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.path.excludes"
 field public,static,final OSHI_SOLARIS_FS_PATH_INCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.path.includes"
 field public,static,final OSHI_SOLARIS_FS_VOLUME_EXCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.volume.excludes"
 field public,static,final OSHI_SOLARIS_FS_VOLUME_INCLUDES Ljava/lang/String; - "oshi.os.solaris.filesystem.volume.includes"
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 290
class oshi/software/os/unix/solaris/SolarisInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
in 290
class oshi/software/os/unix/solaris/SolarisNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/unix/solaris/SolarisOSFileStore 52 public,super oshi/software/common/AbstractOSFileStore - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJJJJ)V - -
 method public getLogicalVolume ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getFreeSpace ()J - -
 method public getUsableSpace ()J - -
 method public getTotalSpace ()J - -
 method public getFreeInodes ()J - -
 method public getTotalInodes ()J - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/solaris/SolarisOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I[Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getContextSwitches ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/solaris/SolarisOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns oshi/software/os/unix/solaris/SolarisOSProcess PsThreadColumns static,final,enum
 inner oshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords oshi/software/os/unix/solaris/SolarisOperatingSystem PrstatKeywords static,final,enum
 inner oshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords oshi/software/os/unix/solaris/SolarisOperatingSystem PsKeywords static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;Ljava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords;Ljava/lang/String;>;Ljava/util/Map<Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords;Ljava/lang/String;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getContextSwitches ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 42
class oshi/software/os/unix/solaris/SolarisOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPsInfo oshi/jna/platform/unix/SolarisLibc SolarisPsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage oshi/jna/platform/unix/SolarisLibc SolarisPrUsage public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/unix/solaris/SolarisOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPsInfo oshi/jna/platform/unix/SolarisLibc SolarisPsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage oshi/jna/platform/unix/SolarisLibc SolarisPrUsage public,static
 inner com/sun/jna/platform/unix/Resource$Rlimit com/sun/jna/platform/unix/Resource Rlimit public,static
 inner oshi/software/os/OSThread$ThreadFiltering oshi/software/os/OSThread ThreadFiltering public,static,final
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILoshi/software/os/unix/solaris/SolarisOperatingSystem;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getMinorFaults ()J - -
 method public getMajorFaults ()J - -
 method public getContextSwitches ()J - -
 method public getOpenFiles ()J - -
 method public getSoftOpenFileLimit ()J - -
 method public getHardOpenFileLimit ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns;>;
 inner oshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns oshi/software/os/unix/solaris/SolarisOSProcess PsThreadColumns static,final,enum
 field public,static,final,enum LWP Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; -
 field public,static,final,enum S Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; -
 field public,static,final,enum ETIME Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; -
 field public,static,final,enum TIME Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; -
 field public,static,final,enum ADDR Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; -
 field public,static,final,enum PRI Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; -
 method public,static values ()[Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns; - -
in 82
class oshi/software/os/unix/solaris/SolarisOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (I[Ljava/lang/String;)V - -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/unix/solaris/SolarisOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns oshi/software/os/unix/solaris/SolarisOSProcess PsThreadColumns static,final,enum
 inner oshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords oshi/software/os/unix/solaris/SolarisOperatingSystem PrstatKeywords static,final,enum
 method public <init> (ILjava/util/Map;Ljava/util/Map;)V (ILjava/util/Map<Loshi/software/os/unix/solaris/SolarisOSProcess$PsThreadColumns;Ljava/lang/String;>;Ljava/util/Map<Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords;Ljava/lang/String;>;)V -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 39
class oshi/software/os/unix/solaris/SolarisOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage oshi/jna/platform/unix/SolarisLibc SolarisPrUsage public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (II)V - -
 method public getName ()Ljava/lang/String; - -
 method public getThreadId ()I - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/unix/solaris/SolarisOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 34
class oshi/software/os/unix/solaris/SolarisOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords oshi/software/os/unix/solaris/SolarisOperatingSystem PsKeywords static,final,enum
 inner oshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords oshi/software/os/unix/solaris/SolarisOperatingSystem PrstatKeywords static,final,enum
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
in 42
class oshi/software/os/unix/solaris/SolarisOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final HAS_KSTAT2 Z -
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 23
class oshi/software/os/unix/solaris/SolarisOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final HAS_KSTAT2 Z -
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
in 34
class oshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords;>;
 inner oshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords oshi/software/os/unix/solaris/SolarisOperatingSystem PrstatKeywords static,final,enum
 field public,static,final,enum PID Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum USERNAME Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum USR Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum SYS Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum TRP Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum TFL Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum DFL Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum LCK Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum SLP Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum LAT Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum VCX Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum ICX Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum SCL Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum SIG Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 field public,static,final,enum PROCESS_NLWP Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; -
 method public,static values ()[Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/solaris/SolarisOperatingSystem$PrstatKeywords; - -
in 34
class oshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords;>;
 inner oshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords oshi/software/os/unix/solaris/SolarisOperatingSystem PsKeywords static,final,enum
 field public,static,final,enum S Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum PID Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum PPID Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum USER Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum UID Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum GROUP Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum GID Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum NLWP Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum PRI Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum VSZ Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum RSS Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum ETIME Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum TIME Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum COMM Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 field public,static,final,enum ARGS Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; -
 method public,static values ()[Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/software/os/unix/solaris/SolarisOperatingSystem$PsKeywords; - -
in 1183
class oshi/software/os/windows/WindowsFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty oshi/driver/windows/wmi/Win32LogicalDisk LogicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty oshi/driver/windows/perfmon/ProcessInformation HandleCountProperty public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 42
class oshi/software/os/windows/WindowsFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty oshi/driver/windows/wmi/Win32LogicalDisk LogicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty oshi/driver/windows/perfmon/ProcessInformation HandleCountProperty public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
in 23
class oshi/software/os/windows/WindowsFileSystem 52 public,super oshi/software/common/AbstractFileSystem - -
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty oshi/driver/windows/wmi/Win32LogicalDisk LogicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty oshi/driver/windows/perfmon/ProcessInformation HandleCountProperty public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getFileStores (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSFileStore;>; -
 method public getOpenFileDescriptors ()J - -
 method public getMaxFileDescriptors ()J - -
 method public getMaxFileDescriptorsPerProcess ()J - -
in 126
class oshi/software/os/windows/WindowsHardwareAbstractionLayer 49 public,super java/lang/Object oshi/hardware/HardwareAbstractionLayer -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 method public <init> ()V - -
 method public getMemory ()Loshi/hardware/Memory; - -
 method public getProcessors ()[Loshi/hardware/Processor; - -
in 2
class oshi/software/os/windows/WindowsInstalledApps 52 public,final,super java/lang/Object - -
 method public,static queryInstalledApps ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 1183
class oshi/software/os/windows/WindowsInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner com/sun/jna/platform/win32/IPHlpAPI$UDP_TABLE_CLASS com/sun/jna/platform/win32/IPHlpAPI UDP_TABLE_CLASS public,static,interface,abstract
 inner com/sun/jna/platform/win32/IPHlpAPI$TCP_TABLE_CLASS com/sun/jna/platform/win32/IPHlpAPI TCP_TABLE_CLASS public,static,interface,abstract
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPSTATS com/sun/jna/platform/win32/IPHlpAPI MIB_TCPSTATS public,static
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPSTATS com/sun/jna/platform/win32/IPHlpAPI MIB_UDPSTATS public,static
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPTABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCPTABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCPROW_OWNER_PID public,static
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCP6TABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCP6TABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCP6ROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCP6ROW_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPTABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDPTABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDPROW_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDP6TABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDP6TABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDP6ROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDP6ROW_OWNER_PID public,static
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getTCPv6Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getConnections ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
in 39
class oshi/software/os/windows/WindowsInternetProtocolStats 52 public,super oshi/software/common/AbstractInternetProtocolStats - -
 inner com/sun/jna/platform/win32/IPHlpAPI$UDP_TABLE_CLASS com/sun/jna/platform/win32/IPHlpAPI UDP_TABLE_CLASS public,static,interface,abstract
 inner com/sun/jna/platform/win32/IPHlpAPI$TCP_TABLE_CLASS com/sun/jna/platform/win32/IPHlpAPI TCP_TABLE_CLASS public,static,interface,abstract
 inner oshi/jna/Struct$CloseableMibTcpStats oshi/jna/Struct CloseableMibTcpStats public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPSTATS com/sun/jna/platform/win32/IPHlpAPI MIB_TCPSTATS public,static
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/jna/Struct$CloseableMibUdpStats oshi/jna/Struct CloseableMibUdpStats public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPSTATS com/sun/jna/platform/win32/IPHlpAPI MIB_UDPSTATS public,static
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPTABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCPTABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCPROW_OWNER_PID public,static
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCP6TABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCP6TABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCP6ROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_TCP6ROW_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPTABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDPTABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDPROW_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDP6TABLE_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDP6TABLE_OWNER_PID public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDP6ROW_OWNER_PID com/sun/jna/platform/win32/IPHlpAPI MIB_UDP6ROW_OWNER_PID public,static
 method public <init> ()V - -
 method public getTCPv4Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getTCPv6Stats ()Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public getUDPv4Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getUDPv6Stats ()Loshi/software/os/InternetProtocolStats$UdpStats; - -
 method public getConnections ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
in 1183
class oshi/software/os/windows/WindowsNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner com/sun/jna/platform/win32/IPHlpAPI$FIXED_INFO com/sun/jna/platform/win32/IPHlpAPI FIXED_INFO public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$IP_ADDR_STRING com/sun/jna/platform/win32/IPHlpAPI IP_ADDR_STRING public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$IP_ADDRESS_STRING com/sun/jna/platform/win32/IPHlpAPI IP_ADDRESS_STRING public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$IP_ADDR_STRING$ByReference com/sun/jna/platform/win32/IPHlpAPI$IP_ADDR_STRING ByReference public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getDnsServers ()[Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 39
class oshi/software/os/windows/WindowsNetworkParams 52 final,super oshi/software/common/AbstractNetworkParams - -
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$FIXED_INFO com/sun/jna/platform/win32/IPHlpAPI FIXED_INFO public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$IP_ADDR_STRING com/sun/jna/platform/win32/IPHlpAPI IP_ADDR_STRING public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$IP_ADDRESS_STRING com/sun/jna/platform/win32/IPHlpAPI IP_ADDRESS_STRING public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$IP_ADDR_STRING$ByReference com/sun/jna/platform/win32/IPHlpAPI$IP_ADDR_STRING ByReference public,static
 method public getDomainName ()Ljava/lang/String; - -
 method public getDnsServers ()[Ljava/lang/String; - -
 method public getHostName ()Ljava/lang/String; - -
 method public getIpv4DefaultGateway ()Ljava/lang/String; - -
 method public getIpv6DefaultGateway ()Ljava/lang/String; - -
in 290
class oshi/software/os/windows/WindowsOSFileStore 52 public,super oshi/software/common/AbstractOSFileStore - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJJJJ)V - -
 method public getLogicalVolume ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getFreeSpace ()J - -
 method public getUsableSpace ()J - -
 method public getTotalSpace ()J - -
 method public getFreeInodes ()J - -
 method public getTotalInodes ()J - -
 method public updateAttributes ()Z - -
in 82
class oshi/software/os/windows/WindowsOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTRByReference com/sun/jna/platform/win32/BaseTSD ULONG_PTRByReference public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 inner com/sun/jna/platform/win32/Advapi32Util$Account com/sun/jna/platform/win32/Advapi32Util Account public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_OS_WINDOWS_COMMANDLINE_BATCH Ljava/lang/String; - "oshi.os.windows.commandline.batch"
 method public <init> (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessWtsData$WtsInfo;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 34
class oshi/software/os/windows/WindowsOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTRByReference com/sun/jna/platform/win32/BaseTSD ULONG_PTRByReference public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 inner com/sun/jna/platform/win32/Advapi32Util$Account com/sun/jna/platform/win32/Advapi32Util Account public,static
 inner oshi/jna/platform/windows/NtDll$PROCESS_BASIC_INFORMATION oshi/jna/platform/windows/NtDll PROCESS_BASIC_INFORMATION public,static
 inner oshi/jna/platform/windows/NtDll$PEB oshi/jna/platform/windows/NtDll PEB public,static
 inner oshi/jna/platform/windows/NtDll$RTL_USER_PROCESS_PARAMETERS oshi/jna/platform/windows/NtDll RTL_USER_PROCESS_PARAMETERS public,static
 inner oshi/jna/platform/windows/NtDll$CURDIR oshi/jna/platform/windows/NtDll CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$UNICODE_STRING oshi/jna/platform/windows/NtDll UNICODE_STRING public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_OS_WINDOWS_COMMANDLINE_BATCH Ljava/lang/String; - "oshi.os.windows.commandline.batch"
 method public <init> (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessWtsData$WtsInfo;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 42
class oshi/software/os/windows/WindowsOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/ByRef$CloseableULONGptrByReference oshi/jna/ByRef CloseableULONGptrByReference public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTRByReference com/sun/jna/platform/win32/BaseTSD ULONG_PTRByReference public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/Advapi32Util$Account com/sun/jna/platform/win32/Advapi32Util Account public,static
 inner oshi/jna/platform/windows/NtDll$PROCESS_BASIC_INFORMATION oshi/jna/platform/windows/NtDll PROCESS_BASIC_INFORMATION public,static
 inner oshi/jna/platform/windows/NtDll$PEB oshi/jna/platform/windows/NtDll PEB public,static
 inner oshi/jna/platform/windows/NtDll$RTL_USER_PROCESS_PARAMETERS oshi/jna/platform/windows/NtDll RTL_USER_PROCESS_PARAMETERS public,static
 inner oshi/jna/platform/windows/NtDll$CURDIR oshi/jna/platform/windows/NtDll CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$UNICODE_STRING oshi/jna/platform/windows/NtDll UNICODE_STRING public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessWtsData$WtsInfo;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 23
class oshi/software/os/windows/WindowsOSProcess 52 public,super oshi/software/common/AbstractOSProcess - -
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/ByRef$CloseableULONGptrByReference oshi/jna/ByRef CloseableULONGptrByReference public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTRByReference com/sun/jna/platform/win32/BaseTSD ULONG_PTRByReference public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/Advapi32Util$Account com/sun/jna/platform/win32/Advapi32Util Account public,static
 inner oshi/jna/platform/windows/NtDll$PROCESS_BASIC_INFORMATION oshi/jna/platform/windows/NtDll PROCESS_BASIC_INFORMATION public,static
 inner oshi/jna/platform/windows/NtDll$PEB oshi/jna/platform/windows/NtDll PEB public,static
 inner oshi/jna/platform/windows/NtDll$RTL_USER_PROCESS_PARAMETERS oshi/jna/platform/windows/NtDll RTL_USER_PROCESS_PARAMETERS public,static
 inner oshi/jna/platform/windows/NtDll$CURDIR oshi/jna/platform/windows/NtDll CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$UNICODE_STRING oshi/jna/platform/windows/NtDll UNICODE_STRING public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map;Ljava/util/Map;Ljava/util/Map;)V (ILoshi/software/os/windows/WindowsOperatingSystem;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessWtsData$WtsInfo;>;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getCommandLine ()Ljava/lang/String; - -
 method public getArguments ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getEnvironmentVariables ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getCurrentWorkingDirectory ()Ljava/lang/String; - -
 method public getUser ()Ljava/lang/String; - -
 method public getUserID ()Ljava/lang/String; - -
 method public getGroup ()Ljava/lang/String; - -
 method public getGroupID ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getParentProcessID ()I - -
 method public getThreadCount ()I - -
 method public getPriority ()I - -
 method public getVirtualSize ()J - -
 method public getResidentSetSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getUpTime ()J - -
 method public getStartTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getOpenFiles ()J - -
 method public getSoftOpenFileLimit ()J - -
 method public getHardOpenFileLimit ()J - -
 method public getBitness ()I - -
 method public getAffinityMask ()J - -
 method public getMinorFaults ()J - -
 method public getThreadDetails ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSThread;>; -
 method public updateAttributes ()Z - -
in 1183
class oshi/software/os/windows/WindowsOSSystemInfo 52 public,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/platform/win32/WinBase$SYSTEM_INFO;)V - -
 method public getNumberOfProcessors ()I - -
in 290
class oshi/software/os/windows/WindowsOSThread 52 public,super oshi/software/common/AbstractOSThread - -
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public <init> (IILjava/lang/String;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;)V - -
 method public getThreadId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getStartMemoryAddress ()J - -
 method public getContextSwitches ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getStartTime ()J - -
 method public getUpTime ()J - -
 method public getPriority ()I - -
 method public updateAttributes ()Z - -
in 126
class oshi/software/os/windows/WindowsOperatingSystem 49 public,super java/lang/Object oshi/software/os/OperatingSystem -
 method public <init> ()V - -
 method public getVersion ()Loshi/software/os/OperatingSystemVersion; - -
 method public getFamily ()Ljava/lang/String; - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 82
class oshi/software/os/windows/WindowsOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty oshi/driver/windows/wmi/Win32OperatingSystem OSVersionProperty public,static,final,enum
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/driver/windows/wmi/Win32Processor$BitnessProperty oshi/driver/windows/wmi/Win32Processor BitnessProperty public,static,final,enum
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION oshi/jna/platform/windows/WinNT TOKEN_ELEVATION public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 com/sun/jna/platform/win32/Tlhelp32 PROCESSENTRY32 public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32$ByReference com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 ByReference public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogIterator com/sun/jna/platform/win32/Advapi32Util EventLogIterator public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogRecord com/sun/jna/platform/win32/Advapi32Util EventLogRecord public,static
 inner com/sun/jna/platform/win32/WinNT$EVENTLOGRECORD com/sun/jna/platform/win32/WinNT EVENTLOGRECORD public,static
 inner com/sun/jna/platform/win32/WinNT$LUID com/sun/jna/platform/win32/WinNT LUID public,static
 inner com/sun/jna/platform/win32/WinNT$TOKEN_PRIVILEGES com/sun/jna/platform/win32/WinNT TOKEN_PRIVILEGES public,static
 inner com/sun/jna/platform/win32/WinNT$LUID_AND_ATTRIBUTES com/sun/jna/platform/win32/WinNT LUID_AND_ATTRIBUTES public,static
 inner com/sun/jna/platform/win32/Winsvc$ENUM_SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc ENUM_SERVICE_STATUS_PROCESS public,static
 inner com/sun/jna/platform/win32/Winsvc$SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc SERVICE_STATUS_PROCESS public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_OS_WINDOWS_PROCSTATE_SUSPENDED Ljava/lang/String; - "oshi.os.windows.procstate.suspended"
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public isElevated ()Z - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 34
class oshi/software/os/windows/WindowsOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty oshi/driver/windows/wmi/Win32OperatingSystem OSVersionProperty public,static,final,enum
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/driver/windows/wmi/Win32Processor$BitnessProperty oshi/driver/windows/wmi/Win32Processor BitnessProperty public,static,final,enum
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION oshi/jna/platform/windows/WinNT TOKEN_ELEVATION public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 com/sun/jna/platform/win32/Tlhelp32 PROCESSENTRY32 public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32$ByReference com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 ByReference public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogIterator com/sun/jna/platform/win32/Advapi32Util EventLogIterator public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogRecord com/sun/jna/platform/win32/Advapi32Util EventLogRecord public,static
 inner com/sun/jna/platform/win32/WinNT$EVENTLOGRECORD com/sun/jna/platform/win32/WinNT EVENTLOGRECORD public,static
 inner com/sun/jna/platform/win32/WinNT$LUID com/sun/jna/platform/win32/WinNT LUID public,static
 inner com/sun/jna/platform/win32/WinNT$TOKEN_PRIVILEGES com/sun/jna/platform/win32/WinNT TOKEN_PRIVILEGES public,static
 inner com/sun/jna/platform/win32/WinNT$LUID_AND_ATTRIBUTES com/sun/jna/platform/win32/WinNT LUID_AND_ATTRIBUTES public,static
 inner com/sun/jna/platform/win32/Winsvc$ENUM_SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc ENUM_SERVICE_STATUS_PROCESS public,static
 inner com/sun/jna/platform/win32/Winsvc$SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc SERVICE_STATUS_PROCESS public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_OS_WINDOWS_PROCSTATE_SUSPENDED Ljava/lang/String; - "oshi.os.windows.procstate.suspended"
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public isElevated ()Z - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()[Loshi/software/os/OSService; - -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 42
class oshi/software/os/windows/WindowsOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty oshi/driver/windows/wmi/Win32OperatingSystem OSVersionProperty public,static,final,enum
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/driver/windows/wmi/Win32Processor$BitnessProperty oshi/driver/windows/wmi/Win32Processor BitnessProperty public,static,final,enum
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION oshi/jna/platform/windows/WinNT TOKEN_ELEVATION public,static
 inner oshi/jna/ByRef$CloseablePROCESSENTRY32ByReference oshi/jna/ByRef CloseablePROCESSENTRY32ByReference public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 com/sun/jna/platform/win32/Tlhelp32 PROCESSENTRY32 public,static
 inner oshi/jna/Struct$CloseablePerformanceInformation oshi/jna/Struct CloseablePerformanceInformation public,static
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogIterator com/sun/jna/platform/win32/Advapi32Util EventLogIterator public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogRecord com/sun/jna/platform/win32/Advapi32Util EventLogRecord public,static
 inner com/sun/jna/platform/win32/WinNT$EVENTLOGRECORD com/sun/jna/platform/win32/WinNT EVENTLOGRECORD public,static
 inner com/sun/jna/platform/win32/WinNT$LUID com/sun/jna/platform/win32/WinNT LUID public,static
 inner com/sun/jna/platform/win32/WinNT$TOKEN_PRIVILEGES com/sun/jna/platform/win32/WinNT TOKEN_PRIVILEGES public,static
 inner com/sun/jna/platform/win32/WinNT$LUID_AND_ATTRIBUTES com/sun/jna/platform/win32/WinNT LUID_AND_ATTRIBUTES public,static
 inner com/sun/jna/platform/win32/Winsvc$ENUM_SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc ENUM_SERVICE_STATUS_PROCESS public,static
 inner com/sun/jna/platform/win32/Winsvc$SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc SERVICE_STATUS_PROCESS public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public isElevated ()Z - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 33
class oshi/software/os/windows/WindowsOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty oshi/driver/windows/wmi/Win32OperatingSystem OSVersionProperty public,static,final,enum
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/driver/windows/wmi/Win32Processor$BitnessProperty oshi/driver/windows/wmi/Win32Processor BitnessProperty public,static,final,enum
 inner oshi/jna/ByRef$CloseablePROCESSENTRY32ByReference oshi/jna/ByRef CloseablePROCESSENTRY32ByReference public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 com/sun/jna/platform/win32/Tlhelp32 PROCESSENTRY32 public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/jna/Struct$CloseablePerformanceInformation oshi/jna/Struct CloseablePerformanceInformation public,static
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogIterator com/sun/jna/platform/win32/Advapi32Util EventLogIterator public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogRecord com/sun/jna/platform/win32/Advapi32Util EventLogRecord public,static
 inner com/sun/jna/platform/win32/WinNT$EVENTLOGRECORD com/sun/jna/platform/win32/WinNT EVENTLOGRECORD public,static
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$LUID com/sun/jna/platform/win32/WinNT LUID public,static
 inner com/sun/jna/platform/win32/WinNT$TOKEN_PRIVILEGES com/sun/jna/platform/win32/WinNT TOKEN_PRIVILEGES public,static
 inner com/sun/jna/platform/win32/WinNT$LUID_AND_ATTRIBUTES com/sun/jna/platform/win32/WinNT LUID_AND_ATTRIBUTES public,static
 inner com/sun/jna/platform/win32/Winsvc$ENUM_SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc ENUM_SERVICE_STATUS_PROCESS public,static
 inner com/sun/jna/platform/win32/Winsvc$SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc SERVICE_STATUS_PROCESS public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public isElevated ()Z - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 2
class oshi/software/os/windows/WindowsOperatingSystem 52 public,super oshi/software/common/AbstractOperatingSystem - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty oshi/driver/windows/wmi/Win32OperatingSystem OSVersionProperty public,static,final,enum
 inner oshi/software/os/OperatingSystem$OSVersionInfo oshi/software/os/OperatingSystem OSVersionInfo public,static
 inner oshi/driver/windows/wmi/Win32Processor$BitnessProperty oshi/driver/windows/wmi/Win32Processor BitnessProperty public,static,final,enum
 inner oshi/jna/ByRef$CloseablePROCESSENTRY32ByReference oshi/jna/ByRef CloseablePROCESSENTRY32ByReference public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 com/sun/jna/platform/win32/Tlhelp32 PROCESSENTRY32 public,static
 inner oshi/software/os/OperatingSystem$ProcessFiltering oshi/software/os/OperatingSystem ProcessFiltering public,static,final
 inner oshi/jna/Struct$CloseablePerformanceInformation oshi/jna/Struct CloseablePerformanceInformation public,static
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogIterator com/sun/jna/platform/win32/Advapi32Util EventLogIterator public,static
 inner com/sun/jna/platform/win32/Advapi32Util$EventLogRecord com/sun/jna/platform/win32/Advapi32Util EventLogRecord public,static
 inner com/sun/jna/platform/win32/WinNT$EVENTLOGRECORD com/sun/jna/platform/win32/WinNT EVENTLOGRECORD public,static
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$LUID com/sun/jna/platform/win32/WinNT LUID public,static
 inner com/sun/jna/platform/win32/WinNT$TOKEN_PRIVILEGES com/sun/jna/platform/win32/WinNT TOKEN_PRIVILEGES public,static
 inner com/sun/jna/platform/win32/WinNT$LUID_AND_ATTRIBUTES com/sun/jna/platform/win32/WinNT LUID_AND_ATTRIBUTES public,static
 inner com/sun/jna/platform/win32/Winsvc$ENUM_SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc ENUM_SERVICE_STATUS_PROCESS public,static
 inner com/sun/jna/platform/win32/Winsvc$SERVICE_STATUS_PROCESS com/sun/jna/platform/win32/Winsvc SERVICE_STATUS_PROCESS public,static
 inner oshi/software/os/OSService$State oshi/software/os/OSService State public,static,final,enum
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public queryManufacturer ()Ljava/lang/String; - -
 method public queryFamilyVersionInfo ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Loshi/software/os/OperatingSystem$OSVersionInfo;>; -
 method protected queryBitness (I)I - -
 method public isElevated ()Z - -
 method public getFileSystem ()Loshi/software/os/FileSystem; - -
 method public getInternetProtocolStats ()Loshi/software/os/InternetProtocolStats; - -
 method public getSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
 method public getProcesses (Ljava/util/Collection;)Ljava/util/List; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryAllProcesses ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryChildProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public queryDescendantProcesses (I)Ljava/util/List; (I)Ljava/util/List<Loshi/software/os/OSProcess;>; -
 method public getProcess (I)Loshi/software/os/OSProcess; - -
 method public getProcessId ()I - -
 method public getProcessCount ()I - -
 method public getThreadId ()I - -
 method public getCurrentThread ()Loshi/software/os/OSThread; - -
 method public getThreadCount ()I - -
 method public getSystemUptime ()J - -
 method public getSystemBootTime ()J - -
 method public getNetworkParams ()Loshi/software/os/NetworkParams; - -
 method public getServices ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSService;>; -
 method public getDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
 method public getInstalledApplications ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 126
class oshi/software/os/windows/nt/CentralProcessor 49 public,super java/lang/Object oshi/hardware/Processor -
 method public <init> ()V - -
 method public getVendor ()Ljava/lang/String; - -
 method public setVendor (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public getIdentifier ()Ljava/lang/String; - -
 method public setIdentifier (Ljava/lang/String;)V - -
 method public isCpu64bit ()Z - -
 method public setCpu64 (Z)V - -
 method public getStepping ()Ljava/lang/String; - -
 method public setStepping (Ljava/lang/String;)V - -
 method public getModel ()Ljava/lang/String; - -
 method public setModel (Ljava/lang/String;)V - -
 method public getFamily ()Ljava/lang/String; - -
 method public setFamily (Ljava/lang/String;)V - -
 method public getLoad ()F - -
 method public toString ()Ljava/lang/String; - -
in 126
class oshi/software/os/windows/nt/GlobalMemory 49 public,super java/lang/Object oshi/hardware/Memory -
 inner com/sun/jna/platform/win32/WinBase$MEMORYSTATUSEX com/sun/jna/platform/win32/WinBase MEMORYSTATUSEX public,static
 inner com/sun/jna/platform/win32/WinDef$DWORDLONG com/sun/jna/platform/win32/WinDef DWORDLONG public,static
 method public <init> ()V - -
 method public getAvailable ()J - -
 method public getTotal ()J - -
in 126
class oshi/software/os/windows/nt/OSNativeSystemInfo 49 public,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/platform/win32/WinBase$SYSTEM_INFO;)V - -
 method public getNumberOfProcessors ()I - -
in 126
class oshi/software/os/windows/nt/OSVersionInfoEx 49 public,super java/lang/Object oshi/software/os/OperatingSystemVersion -
 inner com/sun/jna/platform/win32/WinNT$OSVERSIONINFOEX com/sun/jna/platform/win32/WinNT OSVERSIONINFOEX public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 method public <init> ()V - -
 method public getMajor ()I - -
 method public getMinor ()I - -
 method public getBuildNumber ()I - -
 method public getPlatformId ()I - -
 method public getServicePack ()Ljava/lang/String; - -
 method public getSuiteMask ()I - -
 method public getProductType ()B - -
 method public toString ()Ljava/lang/String; - -
 method public <init> (Lcom/sun/jna/platform/win32/WinNT$OSVERSIONINFOEX;)V - -
