cg-stub-db 1
in 90
class net/minecraft/scoreboard/GoalColor 50 public,super java/lang/Object net/minecraft/scoreboard/IScoreObjectiveCriteria -
 inner net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType net/minecraft/scoreboard/IScoreObjectiveCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/EnumChatFormatting;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setScore (Ljava/util/List;)I (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)I -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
in 91
class net/minecraft/scoreboard/IScoreCriteria 50 public,interface,abstract java/lang/Object - -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 field public,static,final INSTANCES Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreCriteria;>;
 field public,static,final DUMMY Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final TRIGGER Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final DEATH_COUNT Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final PLAYER_KILL_COUNT Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final TOTAL_KILL_COUNT Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final HEALTH Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final FOOD Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final AIR Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final ARMOR Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final XP Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final LEVEL Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final TEAM_KILL [Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final KILLED_BY_TEAM [Lnet/minecraft/scoreboard/IScoreCriteria; -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract isReadOnly ()Z - -
 method public,abstract getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 326
class net/minecraft/scoreboard/IScoreCriteria 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 field public,static,final INSTANCES Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreCriteria;>;
 field public,static,final DUMMY Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final TRIGGER Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final DEATH_COUNT Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final PLAYER_KILL_COUNT Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final TOTAL_KILL_COUNT Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final HEALTH Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final FOOD Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final AIR Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final ARMOR Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final XP Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final LEVEL Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final TEAM_KILL [Lnet/minecraft/scoreboard/IScoreCriteria; -
 field public,static,final KILLED_BY_TEAM [Lnet/minecraft/scoreboard/IScoreCriteria; -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract isReadOnly ()Z - -
 method public,abstract getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 91
class net/minecraft/scoreboard/IScoreCriteria$EnumRenderType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType;>;
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 field public,static,final,enum INTEGER Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; -
 field public,static,final,enum HEARTS Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; -
 method public,static values ()[Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
 method public getRenderType ()Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 326
class net/minecraft/scoreboard/IScoreCriteria$EnumRenderType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType;>;
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 field public,static,final,enum INTEGER Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; -
 field public,static,final,enum HEARTS Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; -
 method public,static values ()[Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
 method public getRenderType ()Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 90
class net/minecraft/scoreboard/IScoreObjectiveCriteria 50 public,interface,abstract java/lang/Object - -
 inner net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType net/minecraft/scoreboard/IScoreObjectiveCriteria EnumRenderType public,static,final,enum
 field public,static,final INSTANCES Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreObjectiveCriteria;>;
 field public,static,final DUMMY Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 field public,static,final TRIGGER Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 field public,static,final deathCount Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 field public,static,final playerKillCount Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 field public,static,final totalKillCount Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 field public,static,final health Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 field public,static,final field_178792_h [Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 field public,static,final field_178793_i [Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract setScore (Ljava/util/List;)I (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)I -
 method public,abstract isReadOnly ()Z - -
 method public,abstract getRenderType ()Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
in 90
class net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType;>;
 inner net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType net/minecraft/scoreboard/IScoreObjectiveCriteria EnumRenderType public,static,final,enum
 field public,static,final,enum INTEGER Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; -
 field public,static,final,enum HEARTS Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; -
 method public,static values ()[Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
 method public func_178796_a ()Ljava/lang/String; - -
 method public,static func_178795_a (Ljava/lang/String;)Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
in 90
class net/minecraft/scoreboard/Score 50 public,super java/lang/Object - -
 field public,static,final scoreComparator Ljava/util/Comparator; Ljava/util/Comparator<Lnet/minecraft/scoreboard/Score;>;
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Lnet/minecraft/scoreboard/ScoreObjective;Ljava/lang/String;)V - -
 method public increseScore (I)V - -
 method public decreaseScore (I)V - -
 method public func_96648_a ()V - -
 method public getScorePoints ()I - -
 method public setScorePoints (I)V - -
 method public getObjective ()Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getPlayerName ()Ljava/lang/String; - -
 method public getScoreScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public isLocked ()Z - -
 method public setLocked (Z)V - -
 method public func_96651_a (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)V -
in 91
class net/minecraft/scoreboard/Score 50 public,super java/lang/Object - -
 field public,static,final SCORE_COMPARATOR Ljava/util/Comparator; Ljava/util/Comparator<Lnet/minecraft/scoreboard/Score;>;
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Lnet/minecraft/scoreboard/ScoreObjective;Ljava/lang/String;)V - -
 method public increaseScore (I)V - -
 method public decreaseScore (I)V - -
 method public incrementScore ()V - -
 method public getScorePoints ()I - -
 method public setScorePoints (I)V - -
 method public getObjective ()Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getPlayerName ()Ljava/lang/String; - -
 method public getScoreScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public isLocked ()Z - -
 method public setLocked (Z)V - -
in 326
class net/minecraft/scoreboard/Score 52 public,super java/lang/Object - -
 field public,static,final SCORE_COMPARATOR Ljava/util/Comparator; Ljava/util/Comparator<Lnet/minecraft/scoreboard/Score;>;
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Lnet/minecraft/scoreboard/ScoreObjective;Ljava/lang/String;)V - -
 method public increaseScore (I)V - -
 method public decreaseScore (I)V - -
 method public incrementScore ()V - -
 method public getScorePoints ()I - -
 method public setScorePoints (I)V - -
 method public getObjective ()Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getPlayerName ()Ljava/lang/String; - -
 method public getScoreScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public isLocked ()Z - -
 method public setLocked (Z)V - -
in 91
class net/minecraft/scoreboard/ScoreCriteria 50 public,super java/lang/Object net/minecraft/scoreboard/IScoreCriteria -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 326
class net/minecraft/scoreboard/ScoreCriteria 52 public,super java/lang/Object net/minecraft/scoreboard/IScoreCriteria -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 91
class net/minecraft/scoreboard/ScoreCriteriaColored 50 public,super java/lang/Object net/minecraft/scoreboard/IScoreCriteria -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/TextFormatting;)V - -
 method public getName ()Ljava/lang/String; - -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 326
class net/minecraft/scoreboard/ScoreCriteriaColored 52 public,super java/lang/Object net/minecraft/scoreboard/IScoreCriteria -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/TextFormatting;)V - -
 method public getName ()Ljava/lang/String; - -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 91
class net/minecraft/scoreboard/ScoreCriteriaHealth 50 public,super net/minecraft/scoreboard/ScoreCriteria - -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;)V - -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 326
class net/minecraft/scoreboard/ScoreCriteriaHealth 52 public,super net/minecraft/scoreboard/ScoreCriteria - -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;)V - -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
in 91
class net/minecraft/scoreboard/ScoreCriteriaReadOnly 50 public,super net/minecraft/scoreboard/ScoreCriteria - -
 method public <init> (Ljava/lang/String;)V - -
 method public isReadOnly ()Z - -
in 326
class net/minecraft/scoreboard/ScoreCriteriaReadOnly 52 public,super net/minecraft/scoreboard/ScoreCriteria - -
 method public <init> (Ljava/lang/String;)V - -
 method public isReadOnly ()Z - -
in 91
class net/minecraft/scoreboard/ScoreCriteriaStat 50 public,super net/minecraft/scoreboard/ScoreCriteria - -
 method public <init> (Lnet/minecraft/stats/StatBase;)V - -
in 326
class net/minecraft/scoreboard/ScoreCriteriaStat 52 public,super net/minecraft/scoreboard/ScoreCriteria - -
 method public <init> (Lnet/minecraft/stats/StatBase;)V - -
in 90
class net/minecraft/scoreboard/ScoreDummyCriteria 50 public,super java/lang/Object net/minecraft/scoreboard/IScoreObjectiveCriteria -
 inner net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType net/minecraft/scoreboard/IScoreObjectiveCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setScore (Ljava/util/List;)I (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)I -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
in 90
class net/minecraft/scoreboard/ScoreHealthCriteria 50 public,super net/minecraft/scoreboard/ScoreDummyCriteria - -
 inner net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType net/minecraft/scoreboard/IScoreObjectiveCriteria EnumRenderType public,static,final,enum
 method public <init> (Ljava/lang/String;)V - -
 method public setScore (Ljava/util/List;)I (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)I -
 method public isReadOnly ()Z - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
in 90
class net/minecraft/scoreboard/ScoreObjective 50 public,super java/lang/Object - -
 inner net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType net/minecraft/scoreboard/IScoreObjectiveCriteria EnumRenderType public,static,final,enum
 method public getScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreObjectiveCriteria;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getCriteria ()Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public setDisplayName (Ljava/lang/String;)V - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType; - -
 method public setRenderType (Lnet/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType;)V - -
in 91
class net/minecraft/scoreboard/ScoreObjective 50 public,super java/lang/Object - -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public getScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreCriteria;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getCriteria ()Lnet/minecraft/scoreboard/IScoreCriteria; - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public setDisplayName (Ljava/lang/String;)V - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
 method public setRenderType (Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType;)V - -
in 326
class net/minecraft/scoreboard/ScoreObjective 52 public,super java/lang/Object - -
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreCriteria;)V - -
 method public getScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public getName ()Ljava/lang/String; - -
 method public getCriteria ()Lnet/minecraft/scoreboard/IScoreCriteria; - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public setDisplayName (Ljava/lang/String;)V - -
 method public getRenderType ()Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType; - -
 method public setRenderType (Lnet/minecraft/scoreboard/IScoreCriteria$EnumRenderType;)V - -
in 90
class net/minecraft/scoreboard/ScorePlayerTeam 50 public,super net/minecraft/scoreboard/Team - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 method public func_98298_a (I)V - -
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Ljava/lang/String;)V - -
 method public getRegisteredName ()Ljava/lang/String; - -
 method public getTeamName ()Ljava/lang/String; - -
 method public setTeamName (Ljava/lang/String;)V - -
 method public getMembershipCollection ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getColorPrefix ()Ljava/lang/String; - -
 method public setNamePrefix (Ljava/lang/String;)V - -
 method public getColorSuffix ()Ljava/lang/String; - -
 method public setNameSuffix (Ljava/lang/String;)V - -
 method public formatString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static formatPlayerName (Lnet/minecraft/scoreboard/Team;Ljava/lang/String;)Ljava/lang/String; - -
 method public getAllowFriendlyFire ()Z - -
 method public setAllowFriendlyFire (Z)V - -
 method public getSeeFriendlyInvisiblesEnabled ()Z - -
 method public setSeeFriendlyInvisiblesEnabled (Z)V - -
 method public getNameTagVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public getDeathMessageVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public setNameTagVisibility (Lnet/minecraft/scoreboard/Team$EnumVisible;)V - -
 method public setDeathMessageVisibility (Lnet/minecraft/scoreboard/Team$EnumVisible;)V - -
 method public func_98299_i ()I - -
 method public setChatFormat (Lnet/minecraft/util/EnumChatFormatting;)V - -
 method public getChatFormat ()Lnet/minecraft/util/EnumChatFormatting; - -
in 91
class net/minecraft/scoreboard/ScorePlayerTeam 50 public,super net/minecraft/scoreboard/Team - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 method public setFriendlyFlags (I)V - -
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Ljava/lang/String;)V - -
 method public getRegisteredName ()Ljava/lang/String; - -
 method public getTeamName ()Ljava/lang/String; - -
 method public setTeamName (Ljava/lang/String;)V - -
 method public getMembershipCollection ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getColorPrefix ()Ljava/lang/String; - -
 method public setNamePrefix (Ljava/lang/String;)V - -
 method public getColorSuffix ()Ljava/lang/String; - -
 method public setNameSuffix (Ljava/lang/String;)V - -
 method public formatString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static formatPlayerName (Lnet/minecraft/scoreboard/Team;Ljava/lang/String;)Ljava/lang/String; - -
 method public getAllowFriendlyFire ()Z - -
 method public setAllowFriendlyFire (Z)V - -
 method public getSeeFriendlyInvisiblesEnabled ()Z - -
 method public setSeeFriendlyInvisiblesEnabled (Z)V - -
 method public getNameTagVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public getDeathMessageVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public setNameTagVisibility (Lnet/minecraft/scoreboard/Team$EnumVisible;)V - -
 method public setDeathMessageVisibility (Lnet/minecraft/scoreboard/Team$EnumVisible;)V - -
 method public getCollisionRule ()Lnet/minecraft/scoreboard/Team$CollisionRule; - -
 method public setCollisionRule (Lnet/minecraft/scoreboard/Team$CollisionRule;)V - -
 method public getFriendlyFlags ()I - -
 method public setChatFormat (Lnet/minecraft/util/text/TextFormatting;)V - -
 method public getChatFormat ()Lnet/minecraft/util/text/TextFormatting; - -
in 326
class net/minecraft/scoreboard/ScorePlayerTeam 52 public,super net/minecraft/scoreboard/Team - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 method public <init> (Lnet/minecraft/scoreboard/Scoreboard;Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public setDisplayName (Ljava/lang/String;)V - -
 method public getMembershipCollection ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getPrefix ()Ljava/lang/String; - -
 method public setPrefix (Ljava/lang/String;)V - -
 method public getSuffix ()Ljava/lang/String; - -
 method public setSuffix (Ljava/lang/String;)V - -
 method public formatString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static formatPlayerName (Lnet/minecraft/scoreboard/Team;Ljava/lang/String;)Ljava/lang/String; - -
 method public getAllowFriendlyFire ()Z - -
 method public setAllowFriendlyFire (Z)V - -
 method public getSeeFriendlyInvisiblesEnabled ()Z - -
 method public setSeeFriendlyInvisiblesEnabled (Z)V - -
 method public getNameTagVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public getDeathMessageVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public setNameTagVisibility (Lnet/minecraft/scoreboard/Team$EnumVisible;)V - -
 method public setDeathMessageVisibility (Lnet/minecraft/scoreboard/Team$EnumVisible;)V - -
 method public getCollisionRule ()Lnet/minecraft/scoreboard/Team$CollisionRule; - -
 method public setCollisionRule (Lnet/minecraft/scoreboard/Team$CollisionRule;)V - -
 method public getFriendlyFlags ()I - -
 method public setFriendlyFlags (I)V - -
 method public setColor (Lnet/minecraft/util/text/TextFormatting;)V - -
 method public getColor ()Lnet/minecraft/util/text/TextFormatting; - -
in 90
class net/minecraft/scoreboard/Scoreboard 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public getObjective (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public addScoreObjective (Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreObjectiveCriteria;)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getObjectivesFromCriteria (Lnet/minecraft/scoreboard/IScoreObjectiveCriteria;)Ljava/util/Collection; (Lnet/minecraft/scoreboard/IScoreObjectiveCriteria;)Ljava/util/Collection<Lnet/minecraft/scoreboard/ScoreObjective;>; -
 method public entityHasObjective (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)Z - -
 method public getValueFromObjective (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)Lnet/minecraft/scoreboard/Score; - -
 method public getSortedScores (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/Collection; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/Collection<Lnet/minecraft/scoreboard/Score;>; -
 method public getScoreObjectives ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/ScoreObjective;>; -
 method public getObjectiveNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public removeObjectiveFromEntity (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getScores ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/Score;>; -
 method public getObjectivesForEntity (Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/scoreboard/ScoreObjective;Lnet/minecraft/scoreboard/Score;>; -
 method public removeObjective (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public setObjectiveInDisplaySlot (ILnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getObjectiveInDisplaySlot (I)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public createTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public removeTeam (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public addPlayerToTeam (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public removePlayerFromTeams (Ljava/lang/String;)Z - -
 method public removePlayerFromTeam (Ljava/lang/String;Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public getTeamNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getTeams ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/ScorePlayerTeam;>; -
 method public getPlayersTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public onScoreObjectiveAdded (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onObjectiveDisplayNameChanged (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreObjectiveRemoved (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public func_96536_a (Lnet/minecraft/scoreboard/Score;)V - -
 method public func_96516_a (Ljava/lang/String;)V - -
 method public func_178820_a (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public broadcastTeamCreated (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public sendTeamUpdate (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public func_96513_c (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public,static getObjectiveDisplaySlot (I)Ljava/lang/String; - -
 method public,static getObjectiveDisplaySlotNumber (Ljava/lang/String;)I - -
 method public,static getDisplaySlotStrings ()[Ljava/lang/String; - -
 method public func_181140_a (Lnet/minecraft/entity/Entity;)V - -
in 91
class net/minecraft/scoreboard/Scoreboard 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public getObjective (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public addScoreObjective (Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreCriteria;)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getObjectivesFromCriteria (Lnet/minecraft/scoreboard/IScoreCriteria;)Ljava/util/Collection; (Lnet/minecraft/scoreboard/IScoreCriteria;)Ljava/util/Collection<Lnet/minecraft/scoreboard/ScoreObjective;>; -
 method public entityHasObjective (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)Z - -
 method public getOrCreateScore (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)Lnet/minecraft/scoreboard/Score; - -
 method public getSortedScores (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/Collection; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/Collection<Lnet/minecraft/scoreboard/Score;>; -
 method public getScoreObjectives ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/ScoreObjective;>; -
 method public getObjectiveNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public removeObjectiveFromEntity (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getScores ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/Score;>; -
 method public getObjectivesForEntity (Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/scoreboard/ScoreObjective;Lnet/minecraft/scoreboard/Score;>; -
 method public removeObjective (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public setObjectiveInDisplaySlot (ILnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getObjectiveInDisplaySlot (I)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public createTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public removeTeam (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public addPlayerToTeam (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public removePlayerFromTeams (Ljava/lang/String;)Z - -
 method public removePlayerFromTeam (Ljava/lang/String;Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public getTeamNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getTeams ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/ScorePlayerTeam;>; -
 method public getPlayersTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public onScoreObjectiveAdded (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onObjectiveDisplayNameChanged (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreObjectiveRemoved (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreUpdated (Lnet/minecraft/scoreboard/Score;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public broadcastTeamCreated (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamInfoUpdate (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamRemove (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public,static getObjectiveDisplaySlot (I)Ljava/lang/String; - -
 method public,static getObjectiveDisplaySlotNumber (Ljava/lang/String;)I - -
 method public,static getDisplaySlotStrings ()[Ljava/lang/String; - -
 method public removeEntity (Lnet/minecraft/entity/Entity;)V - -
in 326
class net/minecraft/scoreboard/Scoreboard 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public getObjective (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public addScoreObjective (Ljava/lang/String;Lnet/minecraft/scoreboard/IScoreCriteria;)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getObjectivesFromCriteria (Lnet/minecraft/scoreboard/IScoreCriteria;)Ljava/util/Collection; (Lnet/minecraft/scoreboard/IScoreCriteria;)Ljava/util/Collection<Lnet/minecraft/scoreboard/ScoreObjective;>; -
 method public entityHasObjective (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)Z - -
 method public getOrCreateScore (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)Lnet/minecraft/scoreboard/Score; - -
 method public getSortedScores (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/Collection; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/Collection<Lnet/minecraft/scoreboard/Score;>; -
 method public getScoreObjectives ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/ScoreObjective;>; -
 method public getObjectiveNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public removeObjectiveFromEntity (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getScores ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/Score;>; -
 method public getObjectivesForEntity (Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/scoreboard/ScoreObjective;Lnet/minecraft/scoreboard/Score;>; -
 method public removeObjective (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public setObjectiveInDisplaySlot (ILnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getObjectiveInDisplaySlot (I)Lnet/minecraft/scoreboard/ScoreObjective; - -
 method public getTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public createTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public removeTeam (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public addPlayerToTeam (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public removePlayerFromTeams (Ljava/lang/String;)Z - -
 method public removePlayerFromTeam (Ljava/lang/String;Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public getTeamNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getTeams ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/scoreboard/ScorePlayerTeam;>; -
 method public getPlayersTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - -
 method public onScoreObjectiveAdded (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onObjectiveDisplayNameChanged (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreObjectiveRemoved (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreUpdated (Lnet/minecraft/scoreboard/Score;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public broadcastTeamCreated (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamInfoUpdate (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamRemove (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public,static getObjectiveDisplaySlot (I)Ljava/lang/String; - -
 method public,static getObjectiveDisplaySlotNumber (Ljava/lang/String;)I - -
 method public,static getDisplaySlotStrings ()[Ljava/lang/String; - -
 method public removeEntity (Lnet/minecraft/entity/Entity;)V - -
in 90
class net/minecraft/scoreboard/ScoreboardSaveData 50 public,super net/minecraft/world/WorldSavedData - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/scoreboard/IScoreObjectiveCriteria$EnumRenderType net/minecraft/scoreboard/IScoreObjectiveCriteria EnumRenderType public,static,final,enum
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public setScoreboard (Lnet/minecraft/scoreboard/Scoreboard;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readTeams (Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected func_96502_a (Lnet/minecraft/scoreboard/ScorePlayerTeam;Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected readDisplayConfig (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readObjectives (Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected readScores (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected func_96496_a ()Lnet/minecraft/nbt/NBTTagList; - -
 method protected func_96497_d (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected objectivesToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
 method protected scoresToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
in 91
class net/minecraft/scoreboard/ScoreboardSaveData 50 public,super net/minecraft/world/WorldSavedData - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public setScoreboard (Lnet/minecraft/scoreboard/Scoreboard;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readTeams (Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected loadTeamPlayers (Lnet/minecraft/scoreboard/ScorePlayerTeam;Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected readDisplayConfig (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readObjectives (Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected readScores (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method protected teamsToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
 method protected fillInDisplaySlots (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected objectivesToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
 method protected scoresToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
in 326
class net/minecraft/scoreboard/ScoreboardSaveData 52 public,super net/minecraft/world/storage/WorldSavedData - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 inner net/minecraft/scoreboard/IScoreCriteria$EnumRenderType net/minecraft/scoreboard/IScoreCriteria EnumRenderType public,static,final,enum
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public setScoreboard (Lnet/minecraft/scoreboard/Scoreboard;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readTeams (Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected loadTeamPlayers (Lnet/minecraft/scoreboard/ScorePlayerTeam;Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected readDisplayConfig (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readObjectives (Lnet/minecraft/nbt/NBTTagList;)V - -
 method protected readScores (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method protected teamsToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
 method protected fillInDisplaySlots (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected objectivesToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
 method protected scoresToNbt ()Lnet/minecraft/nbt/NBTTagList; - -
in 90
class net/minecraft/scoreboard/ServerScoreboard 50 public,super net/minecraft/scoreboard/Scoreboard - -
 method public <init> (Lnet/minecraft/server/MinecraftServer;)V - -
 method public func_96536_a (Lnet/minecraft/scoreboard/Score;)V - -
 method public func_96516_a (Ljava/lang/String;)V - -
 method public func_178820_a (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public setObjectiveInDisplaySlot (ILnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public addPlayerToTeam (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public removePlayerFromTeam (Ljava/lang/String;Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public onScoreObjectiveAdded (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onObjectiveDisplayNameChanged (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreObjectiveRemoved (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public broadcastTeamCreated (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public sendTeamUpdate (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public func_96513_c (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public func_96547_a (Lnet/minecraft/scoreboard/ScoreboardSaveData;)V - -
 method protected markSaveDataDirty ()V - -
 method public func_96550_d (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List<Lnet/minecraft/network/Packet;>; -
 method public func_96549_e (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public func_96548_f (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List<Lnet/minecraft/network/Packet;>; -
 method public sendDisplaySlotRemovalPackets (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public func_96552_h (Lnet/minecraft/scoreboard/ScoreObjective;)I - -
in 91
class net/minecraft/scoreboard/ServerScoreboard 50 public,super net/minecraft/scoreboard/Scoreboard - -
 method public <init> (Lnet/minecraft/server/MinecraftServer;)V - -
 method public onScoreUpdated (Lnet/minecraft/scoreboard/Score;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public setObjectiveInDisplaySlot (ILnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public addPlayerToTeam (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public removePlayerFromTeam (Ljava/lang/String;Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public onScoreObjectiveAdded (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onObjectiveDisplayNameChanged (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreObjectiveRemoved (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public broadcastTeamCreated (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamInfoUpdate (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamRemove (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public addDirtyRunnable (Ljava/lang/Runnable;)V - -
 method protected markSaveDataDirty ()V - -
 method public getCreatePackets (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List<Lnet/minecraft/network/Packet<*>;>; -
 method public addObjective (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getDestroyPackets (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List<Lnet/minecraft/network/Packet<*>;>; -
 method public sendDisplaySlotRemovalPackets (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getObjectiveDisplaySlotCount (Lnet/minecraft/scoreboard/ScoreObjective;)I - -
in 326
class net/minecraft/scoreboard/ServerScoreboard 52 public,super net/minecraft/scoreboard/Scoreboard - -
 method public <init> (Lnet/minecraft/server/MinecraftServer;)V - -
 method public onScoreUpdated (Lnet/minecraft/scoreboard/Score;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;)V - -
 method public broadcastScoreUpdate (Ljava/lang/String;Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public setObjectiveInDisplaySlot (ILnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public addPlayerToTeam (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public removePlayerFromTeam (Ljava/lang/String;Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public onScoreObjectiveAdded (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onObjectiveDisplayNameChanged (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public onScoreObjectiveRemoved (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public broadcastTeamCreated (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamInfoUpdate (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public broadcastTeamRemove (Lnet/minecraft/scoreboard/ScorePlayerTeam;)V - -
 method public addDirtyRunnable (Ljava/lang/Runnable;)V - -
 method protected markSaveDataDirty ()V - -
 method public getCreatePackets (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List<Lnet/minecraft/network/Packet<*>;>; -
 method public addObjective (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getDestroyPackets (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List; (Lnet/minecraft/scoreboard/ScoreObjective;)Ljava/util/List<Lnet/minecraft/network/Packet<*>;>; -
 method public sendDisplaySlotRemovalPackets (Lnet/minecraft/scoreboard/ScoreObjective;)V - -
 method public getObjectiveDisplaySlotCount (Lnet/minecraft/scoreboard/ScoreObjective;)I - -
in 90
class net/minecraft/scoreboard/Team 50 public,super,abstract java/lang/Object - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 method public,abstract getSeeFriendlyInvisiblesEnabled ()Z - -
 method public,abstract getNameTagVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public <init> ()V - -
 method public isSameTeam (Lnet/minecraft/scoreboard/Team;)Z - -
 method public,abstract getRegisteredName ()Ljava/lang/String; - -
 method public,abstract formatString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getAllowFriendlyFire ()Z - -
 method public,abstract getMembershipCollection ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,abstract getDeathMessageVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
in 91
class net/minecraft/scoreboard/Team 50 public,super,abstract java/lang/Object - -
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 method public,abstract getSeeFriendlyInvisiblesEnabled ()Z - -
 method public,abstract getNameTagVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public <init> ()V - -
 method public isSameTeam (Lnet/minecraft/scoreboard/Team;)Z - -
 method public,abstract getRegisteredName ()Ljava/lang/String; - -
 method public,abstract formatString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getAllowFriendlyFire ()Z - -
 method public,abstract getChatFormat ()Lnet/minecraft/util/text/TextFormatting; - -
 method public,abstract getMembershipCollection ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,abstract getDeathMessageVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,abstract getCollisionRule ()Lnet/minecraft/scoreboard/Team$CollisionRule; - -
in 326
class net/minecraft/scoreboard/Team 52 public,super,abstract java/lang/Object - -
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 method public <init> ()V - -
 method public isSameTeam (Lnet/minecraft/scoreboard/Team;)Z - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract formatString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getSeeFriendlyInvisiblesEnabled ()Z - -
 method public,abstract getAllowFriendlyFire ()Z - -
 method public,abstract getNameTagVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,abstract getColor ()Lnet/minecraft/util/text/TextFormatting; - -
 method public,abstract getMembershipCollection ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,abstract getDeathMessageVisibility ()Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,abstract getCollisionRule ()Lnet/minecraft/scoreboard/Team$CollisionRule; - -
in 91
class net/minecraft/scoreboard/Team$CollisionRule 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/Team$CollisionRule;>;
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 field public,static,final,enum ALWAYS Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,static,final,enum NEVER Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,static,final,enum HIDE_FOR_OTHER_TEAMS Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,static,final,enum HIDE_FOR_OWN_TEAM Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,final name Ljava/lang/String; -
 field public,final id I -
 method public,static values ()[Lnet/minecraft/scoreboard/Team$CollisionRule; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$CollisionRule; - -
 method public,static getNames ()[Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$CollisionRule; - -
in 326
class net/minecraft/scoreboard/Team$CollisionRule 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/Team$CollisionRule;>;
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 field public,static,final,enum ALWAYS Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,static,final,enum NEVER Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,static,final,enum HIDE_FOR_OTHER_TEAMS Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,static,final,enum HIDE_FOR_OWN_TEAM Lnet/minecraft/scoreboard/Team$CollisionRule; -
 field public,final name Ljava/lang/String; -
 field public,final id I -
 method public,static values ()[Lnet/minecraft/scoreboard/Team$CollisionRule; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$CollisionRule; - -
 method public,static getNames ()[Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$CollisionRule; - -
in 90
class net/minecraft/scoreboard/Team$EnumVisible 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/Team$EnumVisible;>;
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 field public,static,final,enum ALWAYS Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum NEVER Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum HIDE_FOR_OTHER_TEAMS Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum HIDE_FOR_OWN_TEAM Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,final internalName Ljava/lang/String; -
 field public,final id I -
 method public,static values ()[Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,static func_178825_a ()[Ljava/lang/String; - -
 method public,static func_178824_a (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$EnumVisible; - -
in 91
class net/minecraft/scoreboard/Team$EnumVisible 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/Team$EnumVisible;>;
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 field public,static,final,enum ALWAYS Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum NEVER Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum HIDE_FOR_OTHER_TEAMS Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum HIDE_FOR_OWN_TEAM Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,final internalName Ljava/lang/String; -
 field public,final id I -
 method public,static values ()[Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,static getNames ()[Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$EnumVisible; - -
in 326
class net/minecraft/scoreboard/Team$EnumVisible 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/scoreboard/Team$EnumVisible;>;
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 field public,static,final,enum ALWAYS Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum NEVER Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum HIDE_FOR_OTHER_TEAMS Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,static,final,enum HIDE_FOR_OWN_TEAM Lnet/minecraft/scoreboard/Team$EnumVisible; -
 field public,final internalName Ljava/lang/String; -
 field public,final id I -
 method public,static values ()[Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$EnumVisible; - -
 method public,static getNames ()[Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/scoreboard/Team$EnumVisible; - -
