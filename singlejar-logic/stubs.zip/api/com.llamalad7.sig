cg-stub-db 1
in 22
class com/llamalad7/mixinextras/MixinExtrasBootstrap 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static,deprecated getVersion ()Ljava/lang/String; - -
 method public,static init ()V - -
in 22
class com/llamalad7/mixinextras/ap/MixinExtrasAP 52 public,super javax/annotation/processing/AbstractProcessor - -
 method public <init> ()V - -
 method public process (Ljava/util/Set;Ljavax/annotation/processing/RoundEnvironment;)Z (Ljava/util/Set<+Ljavax/lang/model/element/TypeElement;>;Ljavax/annotation/processing/RoundEnvironment;)Z -
 method public getSupportedSourceVersion ()Ljavax/lang/model/SourceVersion; - -
in 22
class com/llamalad7/mixinextras/ap/StdoutMessager 52 public,super java/lang/Object javax/annotation/processing/Messager -
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 method public <init> ()V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
in 61
class com/llamalad7/mixinextras/ap/expressions/DefinitionInfo 52 public,super,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$SyntheticAt com/llamalad7/mixinextras/ap/expressions/DefinitionInfo SyntheticAt private
 inner com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$Field com/llamalad7/mixinextras/ap/expressions/DefinitionInfo Field public,static
 inner com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$Method com/llamalad7/mixinextras/ap/expressions/DefinitionInfo Method public,static
 method public <init> (Ljava/lang/String;Ljavax/annotation/processing/ProcessingEnvironment;Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Ljava/lang/String;Ljava/lang/Boolean;)V - -
 method public remap ()V - -
in 61
class com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$Field 52 public,super com/llamalad7/mixinextras/ap/expressions/DefinitionInfo - -
 inner com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$Field com/llamalad7/mixinextras/ap/expressions/DefinitionInfo Field public,static
 method public <init> (Ljavax/annotation/processing/ProcessingEnvironment;Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Ljava/lang/String;Ljava/lang/Boolean;)V - -
in 61
class com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$Method 52 public,super com/llamalad7/mixinextras/ap/expressions/DefinitionInfo - -
 inner com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$Method com/llamalad7/mixinextras/ap/expressions/DefinitionInfo Method public,static
 method public <init> (Ljavax/annotation/processing/ProcessingEnvironment;Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Ljava/lang/String;Ljava/lang/Boolean;)V - -
in 61
class com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$SyntheticAt 52 super java/lang/Object javax/lang/model/element/AnnotationMirror -
 inner com/llamalad7/mixinextras/ap/expressions/DefinitionInfo$SyntheticAt com/llamalad7/mixinextras/ap/expressions/DefinitionInfo SyntheticAt private
 method public <init> (Lcom/llamalad7/mixinextras/ap/expressions/DefinitionInfo;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;)V - -
 method public getAnnotationType ()Ljavax/lang/model/type/DeclaredType; - -
 method public getElementValues ()Ljava/util/Map; ()Ljava/util/Map<+Ljavax/lang/model/element/ExecutableElement;+Ljavax/lang/model/element/AnnotationValue;>; -
in 62
class com/llamalad7/mixinextras/config/MixinExtrasConfig 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final,transient minVersion Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;Ljava/lang/String;)V - -
in 63
class com/llamalad7/mixinextras/config/MixinExtrasConfig 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final,transient parent Lcom/llamalad7/mixinextras/config/MixinExtrasConfig; -
 field public,final,transient minVersion Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 method public <init> (Ljava/lang/String;Lcom/llamalad7/mixinextras/config/MixinExtrasConfig;Ljava/lang/String;)V - -
in 61
class com/llamalad7/mixinextras/expression/Definition 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLcom/llamalad7/mixinextras/expression/Definitions;)
 method public,abstract id ()Ljava/lang/String; - -
 method public,abstract method ()[Ljava/lang/String; - - []
 method public,abstract field ()[Ljava/lang/String; - - []
 method public,abstract type ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; - []
 method public,abstract local ()[Lcom/llamalad7/mixinextras/sugar/Local; - - []
 method public,abstract remap ()Z - - Z1
in 61
class com/llamalad7/mixinextras/expression/Definitions 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()[Lcom/llamalad7/mixinextras/expression/Definition; - -
in 61
class com/llamalad7/mixinextras/expression/Expression 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLcom/llamalad7/mixinextras/expression/Expressions;)
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract id ()Ljava/lang/String; - - ""
in 61
class com/llamalad7/mixinextras/expression/Expressions 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()[Lcom/llamalad7/mixinextras/expression/Expression; - -
in 61
class com/llamalad7/mixinextras/expression/impl/ExpressionParserFacade 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser RootContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayStoreStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayStoreStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ReturnStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ReturnStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThrowStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThrowStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CapturingExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CapturingExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ParenthesizedExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ParenthesizedExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$SuperCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser SuperCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StaticMethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StaticMethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoundMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoundMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$FreeMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser FreeMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ConstructorReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ConstructorReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ClassConstantExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ClassConstantExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NewArrayExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NewArrayExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$UnaryExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser UnaryExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CastExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CastExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstantiationExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstantiationExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MultiplicativeExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MultiplicativeExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$AdditiveExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser AdditiveExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ShiftExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ShiftExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ComparisonExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ComparisonExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstanceofExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstanceofExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$EqualityExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser EqualityExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseAndExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseAndExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseXorExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseXorExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseOrExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseOrExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$DecimalLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser DecimalLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IntLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IntLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StringLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StringLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoolLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoolLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NullExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NullExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThisExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThisExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NonEmptyArgumentsContext public,static
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression Operator public,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression Operator public,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression Operator public,static,final,enum
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierNameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardNameContext public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static parse (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; - -
in 61
class com/llamalad7/mixinextras/expression/impl/ExpressionService 52 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public <init> ()V - -
 method public,static getInstance ()Lcom/llamalad7/mixinextras/expression/impl/ExpressionService; - -
 method public,static offerInstance (Lcom/llamalad7/mixinextras/expression/impl/ExpressionService;)V - -
 method public makeInvalidInjectionException (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)Ljava/lang/RuntimeException; - -
 method public decorateInjectorSpecific (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,abstract getCommonSuperClass (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/ExpressionSource 52 public,super java/lang/Object - -
 field public,final expression Ljava/lang/String; -
 field public,final startIndex I -
 field public,final endIndex I -
 method public <init> (Ljava/lang/String;II)V - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ArrayAccessExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final arr Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final index Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ArrayLiteralExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final elementType Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 field public,final values Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;Ljava/util/List;)V (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;)V -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ArrayStoreExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 field public,final arr Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final index Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final value Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression Operator public,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type com/llamalad7/mixinextras/expression/impl/point/ExpressionContext Type public,static,final,enum
 field public,final left Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final operator Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,final right Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator;>;
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression Operator public,static,final,enum
 field public,static,final,enum MULT Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum DIV Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum MOD Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum PLUS Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum MINUS Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum SHL Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum SHR Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum USHR Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum BITWISE_AND Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum BITWISE_XOR Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 field public,static,final,enum BITWISE_OR Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator; - -
 method public matches (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/BooleanLiteralExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final value Z -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Z)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/BoundMethodReferenceExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo Type public,static,final,enum
 field public,final receiver Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final name Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/CapturingExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final expression Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/CastExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final type Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 field public,final expression Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ClassConstantExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final type Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression Operator public,static,final,enum
 field public,final left Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final operator Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; -
 field public,final right Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator 52 public,final,super,enum java/lang/Enum org/objectweb/asm/Opcodes Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator;>;Lorg/objectweb/asm/Opcodes;
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression Operator public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum EQ Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; -
 field public,static,final,enum NE Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; -
 field public,static,final,enum LT Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; -
 field public,static,final,enum LE Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; -
 field public,static,final,enum GT Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; -
 field public,static,final,enum GE Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/ComparisonExpression$Operator; - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ConstructorReferenceExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo Type public,static,final,enum
 field public,final type Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/DecimalLiteralExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final value D -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;D)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression 52 public,super,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression$OutputSink com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression OutputSink public,static,interface,abstract
 field protected,final src Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;)V - -
 method public getSrc ()Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource; - -
 method public,final matches (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method protected capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
 method protected,varargs inputsMatch (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;[Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)Z - -
 method protected,varargs inputsMatch (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;Z[Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)Z - -
 method protected,varargs inputsMatch (ILcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;[Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)Z - -
 method protected,varargs inputsMatch (ILcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;Z[Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression$OutputSink 52 public,interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression$OutputSink com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression OutputSink public,static,interface,abstract
 method public,abstract capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
 method public,abstract decorate (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,abstract decorateInjectorSpecific (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public reportMatchStatus (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Z)V - -
 method public reportPartialMatch (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/FreeMethodReferenceExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo Type public,static,final,enum
 field public,final name Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/IdentifierAssignmentExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 field public,final identifier Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 field public,final value Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/IdentifierExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final identifier Ljava/lang/String; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Ljava/lang/String;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/InstanceofExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final expression Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final type Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/InstantiationExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 inner com/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type com/llamalad7/mixinextras/expression/impl/point/ExpressionContext Type public,static,final,enum
 field public,final type Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 field public,final arguments Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;Ljava/util/List;)V (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;)V -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method protected capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/IntLiteralExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final value J -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;J)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/MemberAccessExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final receiver Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final name Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/MemberAssignmentExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 field public,final receiver Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final name Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 field public,final value Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/MethodCallExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final receiver Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 field public,final name Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 field public,final arguments Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Ljava/util/List;)V (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;)V -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/NewArrayExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final innerType Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 field public,final dims Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;
 field public,final blankDims I -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;Ljava/util/List;I)V (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;I)V -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/NullLiteralExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ReturnExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 field public,final value Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression 52 public,super,abstract com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;)V - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/StaticMethodCallExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final name Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 field public,final arguments Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Ljava/util/List;)V (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;)V -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/StringLiteralExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final value Ljava/lang/String; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Ljava/lang/String;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/SuperCallExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 field public,final name Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier; -
 field public,final arguments Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Ljava/util/List;)V (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier;Ljava/util/List<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;>;)V -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ThisExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/ThrowExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression - -
 field public,final value Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression Operator public,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/BinaryExpression Operator public,static,final,enum
 field public,final operator Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator; -
 field public,final expression Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator;>;
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator com/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression Operator public,static,final,enum
 field public,static,final,enum MINUS Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator; -
 field public,static,final,enum BITWISE_NOT Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/UnaryExpression$Operator; - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/expressions/WildcardExpression 52 public,super com/llamalad7/mixinextras/expression/impl/ast/expressions/SimpleExpression - -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/ExpressionSource;)V - -
 method protected matchesImpl (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/identifiers/ArrayTypeIdentifier 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier -
 field public,final dims I -
 field public,final elementType Lcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier; -
 method public <init> (ILcom/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier;)V - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lorg/objectweb/asm/Type;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/identifiers/DefinedMemberIdentifier 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier -
 field public,final name Ljava/lang/String; -
 method public <init> (Ljava/lang/String;)V - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/identifiers/DefinedTypeIdentifier 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier -
 field public,final name Ljava/lang/String; -
 method public <init> (Ljava/lang/String;)V - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lorg/objectweb/asm/Type;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier 52 public,interface,abstract java/lang/Object - -
 method public,abstract matches (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier 52 public,interface,abstract java/lang/Object - -
 method public,abstract matches (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lorg/objectweb/asm/Type;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/ast/identifiers/WildcardIdentifier 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/ast/identifiers/MemberIdentifier,com/llamalad7/mixinextras/expression/impl/ast/identifiers/TypeIdentifier -
 method public <init> ()V - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lorg/objectweb/asm/Type;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/Boxing 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getUnboxedType (Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/ComplexDataException 52 public,super java/lang/RuntimeException - -
 field public,static,final INSTANCE Ljava/lang/RuntimeException; -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/ComplexFlowValue 52 public,super com/llamalad7/mixinextras/expression/impl/flow/FlowValue - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Set;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)V (ILjava/util/Set<Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;>;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)V -
 method public addChild (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;I)V - -
 method public finish ()V - -
 method public getInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getInput (I)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public inputCount ()I - -
 method public mergeInputs ([Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)V - -
 method public getSize ()I - -
 method public mergeWith (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public getType ()Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/ComputedFlowValue 52 public,super com/llamalad7/mixinextras/expression/impl/flow/FlowValue - -
 method public,varargs <init> (ILjava/util/function/Function;Lorg/objectweb/asm/tree/AbstractInsnNode;[Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V (ILjava/util/function/Function<[Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lorg/objectweb/asm/Type;>;Lorg/objectweb/asm/tree/AbstractInsnNode;[Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V -
 method public getSize ()I - -
 method public getType ()Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/DummyFlowValue 52 public,super com/llamalad7/mixinextras/expression/impl/flow/FlowValue - -
 field public,static,final UNINITIALIZED Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; -
 method public <init> (Lorg/objectweb/asm/Type;)V - -
 method public addChild (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;I)V - -
 method public finish ()V - -
 method public getInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getInput (I)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public inputCount ()I - -
 method public mergeInputs ([Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/FlowContext 52 public,interface,abstract java/lang/Object - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/FlowInterpreter 52 public,super org/objectweb/asm/tree/analysis/Interpreter - Lorg/objectweb/asm/tree/analysis/Interpreter<Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;>;
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)V - -
 method public,static analyze (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)Ljava/util/Collection; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)Ljava/util/Collection<Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;>; -
 method public finish ()Ljava/util/Collection; ()Ljava/util/Collection<Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;>; -
 method public newValue (Lorg/objectweb/asm/Type;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public newOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public copyOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public unaryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public binaryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public ternaryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public naryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/List;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/List<+Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;>;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; -
 method public returnOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
 method public merge (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/FlowValue 52 public,super java/lang/Object org/objectweb/asm/tree/analysis/Value -
 field protected parents [Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; -
 method public,varargs <init> (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/AbstractInsnNode;[Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
 method public addChild (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;I)V - -
 method public finish ()V - -
 method public onFinished ()V - -
 method public getSize ()I - -
 method public getType ()Lorg/objectweb/asm/Type; - -
 method public getInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getNext ()Ljava/util/Collection; ()Ljava/util/Collection<Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair<Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Ljava/lang/Integer;>;>; -
 method public getInput (I)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public inputCount ()I - -
 method public setInsn (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,varargs setParents ([Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
 method public setParent (ILcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
 method public removeParent (I)V - -
 method public mergeWith (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; - -
 method public mergeInputs ([Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)V - -
 method public isComplex ()Z - -
 method public decorate (Ljava/lang/String;Ljava/lang/Object;)V <V:Ljava/lang/Object;>(Ljava/lang/String;TV;)V -
 method public hasDecoration (Ljava/lang/String;)Z - -
 method public getDecoration (Ljava/lang/String;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;)TV; -
 method public getDecorations ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public typeMatches (Lorg/objectweb/asm/Type;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/LocalsCalculator 52 super org/objectweb/asm/tree/analysis/Interpreter - Lorg/objectweb/asm/tree/analysis/Interpreter<Lorg/objectweb/asm/tree/analysis/BasicValue;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getLocalTypes (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)Ljava/util/Map; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;)Ljava/util/Map<Lorg/objectweb/asm/tree/VarInsnNode;Lorg/objectweb/asm/Type;>; -
 method public newValue (Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/tree/analysis/BasicValue; - -
 method public newOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/tree/analysis/BasicValue; - -
 method public copyOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/analysis/BasicValue;)Lorg/objectweb/asm/tree/analysis/BasicValue; - -
 method public unaryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/analysis/BasicValue;)Lorg/objectweb/asm/tree/analysis/BasicValue; - -
 method public binaryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/analysis/BasicValue;Lorg/objectweb/asm/tree/analysis/BasicValue;)Lorg/objectweb/asm/tree/analysis/BasicValue; - -
 method public ternaryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/analysis/BasicValue;Lorg/objectweb/asm/tree/analysis/BasicValue;Lorg/objectweb/asm/tree/analysis/BasicValue;)Lorg/objectweb/asm/tree/analysis/BasicValue; - -
 method public naryOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/List;)Lorg/objectweb/asm/tree/analysis/BasicValue; (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/List<+Lorg/objectweb/asm/tree/analysis/BasicValue;>;)Lorg/objectweb/asm/tree/analysis/BasicValue; -
 method public returnOperation (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/analysis/BasicValue;Lorg/objectweb/asm/tree/analysis/BasicValue;)V - -
 method public merge (Lorg/objectweb/asm/tree/analysis/BasicValue;Lorg/objectweb/asm/tree/analysis/BasicValue;)Lorg/objectweb/asm/tree/analysis/BasicValue; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander 52 public,super com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander - -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component com/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander Component private,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander Expansion public
 method public <init> ()V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
 method public expand (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component 52 final,super,enum java/lang/Enum com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component;>;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent;
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component com/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander Component private,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 field public,static,final,enum LOAD Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component; -
 field public,static,final,enum CST Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component; -
 field public,static,final,enum ADD Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component; -
 field public,static,final,enum STORE Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/IincExpander$Component; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander 52 public,super,abstract java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander Expansion public
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type com/llamalad7/mixinextras/expression/impl/point/ExpressionContext Type public,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,abstract process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
 method public,abstract expand (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion;)V - -
 method protected,final registerComponent (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method protected,final,varargs expandInsn (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;[Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method protected,static dummyInsn ()Lorg/objectweb/asm/tree/InsnNode; - -
 method public,static prepareExpansion (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext;)Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion; - -
 method public,static doExpansion (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
 method public,static getRepresentative (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,static hasExpansion (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
 method public,static addExpansionStep (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Ljava/util/function/Consumer;)V (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Ljava/util/function/Consumer<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;)V -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander Expansion public
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final compound Lorg/objectweb/asm/tree/AbstractInsnNode; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public registerInterest (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent;)V - -
 method public decorate (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public decorateInjectorSpecific (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public registeredInterests ()Ljava/util/Set; ()Ljava/util/Set<Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent;>; -
 method protected registerInsn (Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent 52 public,interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander 52 public,super com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander - -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander ConcatPart private,static,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$Argument com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart Argument public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$PooledConstant com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart PooledConstant public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$TemplateString com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart TemplateString public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$Component com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander Component private,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$PartialResult com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander PartialResult private,static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander Expansion public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
 method public expand (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$Component 52 final,super,enum java/lang/Enum com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$Component;>;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent;
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$Component com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander Component private,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 field public,static,final,enum TO_STRING Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$Component; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$Component; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$Component; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart 52 super,abstract java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander ConcatPart private,static,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$TemplateString com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart TemplateString public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$PooledConstant com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart PooledConstant public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$Argument com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart Argument public,static
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$Argument 52 public,super com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart - -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander ConcatPart private,static,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$Argument com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart Argument public,static
 method public <init> (I)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$PooledConstant 52 public,super com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart - -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander ConcatPart private,static,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$PooledConstant com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart PooledConstant public,static
 field public,final value Ljava/lang/Object; -
 method public <init> (ILjava/lang/Object;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$TemplateString 52 public,super com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart - -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander ConcatPart private,static,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart$TemplateString com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$ConcatPart TemplateString public,static
 field public,final value Ljava/lang/String; -
 method public <init> (ILjava/lang/String;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$PartialResult 52 super java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent -
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander$PartialResult com/llamalad7/mixinextras/expression/impl/flow/expansion/StringConcatFactoryExpander PartialResult private,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 field public,final finishedParts I -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander 52 public,super com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander - -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component com/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander Component private,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander Expansion public
 method public <init> ()V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
 method public expand (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$Expansion;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component 52 final,super,enum java/lang/Enum com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component;>;Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent;
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component com/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander Component private,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander$InsnComponent com/llamalad7/mixinextras/expression/impl/flow/expansion/InsnExpander InsnComponent public,static,interface,abstract
 field public,static,final,enum CST Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component; -
 field public,static,final,enum JUMP Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/flow/expansion/UnaryComparisonExpander$Component; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/ArrayCreationInfo 52 public,super java/lang/Object - -
 field public,final initialized Lcom/llamalad7/mixinextras/expression/impl/flow/utils/InsnReference; -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/CallTaggingPostProcessor 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 method public <init> (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor 52 public,interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 method public,abstract process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink 52 public,interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 method public,abstract markAsSynthetic (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
 method public,varargs,abstract registerFlow ([Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/InstantiationInfo 52 public,super java/lang/Object - -
 field public,final type Lorg/objectweb/asm/Type; -
 field public,final initCall Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; -
 method public <init> (Lorg/objectweb/asm/Type;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/InstantiationPostProcessor 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo Type public,static,final,enum
 field public,final impl Lorg/objectweb/asm/Handle; -
 field public,final type Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type; -
 method public <init> (Lorg/objectweb/asm/Handle;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type;>;
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo Type public,static,final,enum
 field public,static,final,enum FREE_METHOD Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type; -
 field public,static,final,enum BOUND_METHOD Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type; -
 field public,static,final,enum INSTANTIATION Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFPostProcessor 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo$Type com/llamalad7/mixinextras/expression/impl/flow/postprocessing/LMFInfo Type public,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 method public <init> (Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/MethodCallType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/MethodCallType;>;
 field public,static,final,enum NORMAL Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/MethodCallType; -
 field public,static,final,enum SUPER Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/MethodCallType; -
 field public,static,final,enum STATIC Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/MethodCallType; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/MethodCallType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/MethodCallType; - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/NewArrayPostProcessor 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/SplitNodeRemovalPostProcessor 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 method public <init> ()V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/StringConcatInfo 52 public,super java/lang/Object - -
 field public,final isFirstConcat Z -
 field public,final isBuilder Z -
 field public,final initialComponent Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; -
 field public,final toStringCall Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue; -
 method public <init> (ZZLcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/postprocessing/StringConcatPostProcessor 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor -
 inner com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink com/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor OutputSink public,static,interface,abstract
 method public <init> ()V - -
 method public process (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/flow/postprocessing/FlowPostProcessor$OutputSink;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/flow/utils/InsnReference 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)V - -
 method public getNode (Lorg/spongepowered/asm/mixin/injection/struct/Target;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
in 61
class com/llamalad7/mixinextras/expression/impl/point/ExpressionContext 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression$OutputSink com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression OutputSink public,static,interface,abstract
 inner com/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type com/llamalad7/mixinextras/expression/impl/point/ExpressionContext Type public,static,final,enum
 field public,final pool Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool; -
 field public,final classNode Lorg/objectweb/asm/tree/ClassNode; -
 field public,final method Lorg/objectweb/asm/tree/MethodNode; -
 field public,final type Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,final isStatic Z -
 field public,final allowIncompleteListInputs Z -
 method public <init> (Lcom/llamalad7/mixinextras/expression/impl/pool/IdentifierPool;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression$OutputSink;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type;Z)V - -
 method public capture (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
 method public decorate (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public decorateInjectorSpecific (Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public reportMatchStatus (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;Z)V - -
 method public reportPartialMatch (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type;>;
 inner com/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type com/llamalad7/mixinextras/expression/impl/point/ExpressionContext Type public,static,final,enum
 field public,static,final,enum CUSTOM Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum INJECT Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum MODIFY_ARG Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum MODIFY_ARGS Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum MODIFY_CONSTANT Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum MODIFY_EXPRESSION_VALUE Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum MODIFY_RECEIVER Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum MODIFY_RETURN_VALUE Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum MODIFY_VARIABLE Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum REDIRECT Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum SLICE Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum WRAP_OPERATION Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 field public,static,final,enum WRAP_WITH_CONDITION Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; -
 method public,static values ()[Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/point/ExpressionInjectionPoint 52 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner com/llamalad7/mixinextras/expression/impl/point/ExpressionContext$Type com/llamalad7/mixinextras/expression/impl/point/ExpressionContext Type public,static,final,enum
 inner com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression$OutputSink com/llamalad7/mixinextras/expression/impl/ast/expressions/Expression OutputSink public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method public,static withContext (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/Runnable;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/point/ExpressionSliceMarkerTransformer 52 public,super java/lang/Object com/llamalad7/mixinextras/transformer/MixinTransformer -
 method public <init> ()V - -
 method public transform (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/objectweb/asm/tree/ClassNode;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/point/RuntimeExpressionService 52 super com/llamalad7/mixinextras/expression/impl/ExpressionService - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public makeInvalidInjectionException (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)Ljava/lang/RuntimeException; - -
 method public decorateInjectorSpecific (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getCommonSuperClass (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/ArrayLengthDef 52 super java/lang/Object com/llamalad7/mixinextras/expression/impl/pool/SimpleMemberDefinition -
 method public matches (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/BytecodeIdentifierPool 52 public,super com/llamalad7/mixinextras/expression/impl/pool/IdentifierPool - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/ExactTypeDef 52 super java/lang/Object com/llamalad7/mixinextras/expression/impl/pool/TypeDefinition -
 method public matches (Lorg/objectweb/asm/Type;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/FieldDef 52 super java/lang/Object com/llamalad7/mixinextras/expression/impl/pool/SimpleMemberDefinition -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method public matches (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/IdentifierPool 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public matchesMember (Ljava/lang/String;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
 method public matchesType (Ljava/lang/String;Lorg/objectweb/asm/Type;)Z - -
 method public addMember (Ljava/lang/String;Lcom/llamalad7/mixinextras/expression/impl/pool/MemberDefinition;)V - -
 method public addType (Ljava/lang/String;Lcom/llamalad7/mixinextras/expression/impl/pool/TypeDefinition;)V - -
 method public memberExists (Ljava/lang/String;)Z - -
 method public typeExists (Ljava/lang/String;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/LocalDef 52 public,super java/lang/Object com/llamalad7/mixinextras/expression/impl/pool/MemberDefinition -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/MemberDefinition 52 public,interface,abstract java/lang/Object - -
 method public,abstract matches (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/MethodDef 52 super java/lang/Object com/llamalad7/mixinextras/expression/impl/pool/SimpleMemberDefinition -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method public matches (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public matches (Lorg/objectweb/asm/Handle;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/SimpleMemberDefinition 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/expression/impl/pool/MemberDefinition -
 method public,abstract matches (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public matches (Lorg/objectweb/asm/Handle;)Z - -
 method public matches (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/pool/TypeDefinition 52 public,interface,abstract java/lang/Object - -
 method public,abstract matches (Lorg/objectweb/asm/Type;)Z - -
in 61
class com/llamalad7/mixinextras/expression/impl/utils/ComparisonInfo 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 field protected,final comparison I -
 field protected,final node Lcom/llamalad7/mixinextras/expression/impl/flow/utils/InsnReference; -
 field public,final input Lorg/objectweb/asm/Type; -
 field public,final jumpOnTrue Z -
 method public <init> (ILcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lorg/objectweb/asm/Type;Z)V - -
 method public attach (Ljava/util/function/BiConsumer;Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/Object;>;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public copyJump (Lorg/objectweb/asm/tree/InsnList;)I - -
 method public getJumpTarget (Lorg/spongepowered/asm/mixin/injection/struct/Target;)Lorg/objectweb/asm/tree/LabelNode; - -
 method public getJumpInsn (Lorg/spongepowered/asm/mixin/injection/struct/Target;)Lorg/objectweb/asm/tree/JumpInsnNode; - -
 method public cleanup (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/utils/ComplexComparisonInfo 52 public,super com/llamalad7/mixinextras/expression/impl/utils/ComparisonInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public <init> (ILcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Lorg/objectweb/asm/Type;Lcom/llamalad7/mixinextras/expression/impl/flow/FlowValue;Z)V - -
 method public copyJump (Lorg/objectweb/asm/tree/InsnList;)I - -
 method public getJumpInsn (Lorg/spongepowered/asm/mixin/injection/struct/Target;)Lorg/objectweb/asm/tree/JumpInsnNode; - -
 method public cleanup (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/utils/ExpressionASMUtils 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OBJECT_TYPE Lorg/objectweb/asm/Type; -
 field public,static,final BOTTOM_TYPE Lorg/objectweb/asm/Type; -
 field public,static,final INTLIKE_TYPE Lorg/objectweb/asm/Type; -
 field public,static,final LMF_HANDLE Lorg/objectweb/asm/Handle; -
 field public,static,final ALT_LMF_HANDLE Lorg/objectweb/asm/Handle; -
 method public <init> ()V - -
 method public,static getNewType (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/Type; - -
 method public,static getUnaryType (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/Type; - -
 method public,static getBinaryType (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method public,static getNaryType (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/Type; - -
 method public,static getCommonSupertype (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method public,static getCommonIntType (Lcom/llamalad7/mixinextras/expression/impl/flow/FlowContext;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method public,static isIntLike (Lorg/objectweb/asm/Type;)Z - -
 method public,static getInnerType (Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method public,static getNewArrayType (Lorg/objectweb/asm/tree/IntInsnNode;)Lorg/objectweb/asm/Type; - -
 method public,static getConstant (Lorg/objectweb/asm/tree/AbstractInsnNode;)Ljava/lang/Object; - -
 method public,static pushInt (I)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,static getCastType (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/expression/impl/utils/ExpressionDecorations 52 public,super java/lang/Object - -
 field public,static,final SIMPLE_EXPRESSION_TYPE Ljava/lang/String; - "mixinextras_simpleExpressionType"
 field public,static,final COMPARISON_INFO Ljava/lang/String; - "mixinextras_comparisonInfo"
 field public,static,final SIMPLE_OPERATION_ARGS Ljava/lang/String; - "mixinextras_simpleOperationArgs"
 field public,static,final SIMPLE_OPERATION_PARAM_NAMES Ljava/lang/String; - "mixinextras_simpleOperationParamNames"
 field public,static,final SIMPLE_OPERATION_RETURN_TYPE Ljava/lang/String; - "mixinextras_simpleOperationReturnType"
 field public,static,final EXPANSION_INFO Ljava/lang/String; - "mixinextras_expansionInfo"
 field public,static,final IS_STRING_CONCAT_EXPRESSION Ljava/lang/String; - "mixinextras_isStringConcatExpression"
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/expression/impl/utils/ExpressionUtil 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static skipCapturesDown (Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression;)Lcom/llamalad7/mixinextras/expression/impl/ast/expressions/Expression; - -
in 61
class com/llamalad7/mixinextras/expression/impl/utils/FlowDecorations 52 public,super java/lang/Object - -
 field public,static,final PERSISTENT Ljava/lang/String; - "mixinextras_persistent_"
 field public,static,final ARRAY_CREATION_INFO Ljava/lang/String; - "mixinextras_persistent_arrayCreationInfo"
 field public,static,final STRING_CONCAT_INFO Ljava/lang/String; - "stringConcatInfo"
 field public,static,final INSTANTIATION_INFO Ljava/lang/String; - "instantiationInfo"
 field public,static,final COMPLEX_COMPARISON_JUMP Ljava/lang/String; - "complexComparisonJump"
 field public,static,final METHOD_CALL_TYPE Ljava/lang/String; - "methodCallType"
 field public,static,final LMF_INFO Ljava/lang/String; - "lmfInfo"
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/expression/impl/wrapper/ExpressionInjectorWrapper 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
in 61
class com/llamalad7/mixinextras/expression/impl/wrapper/ExpressionInjectorWrapperImpl 52 public,super com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected getDelegate ()Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo; - -
 method protected getHandler ()Lorg/objectweb/asm/tree/MethodNode; - -
 method protected prepare ()V - -
in 61
class com/llamalad7/mixinextras/expression/impl/wrapper/ExpressionInjectorWrapperInjectionInfo 52 public,super com/llamalad7/mixinextras/wrapper/WrapperInjectionInfo - -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl Factory public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
in 61
class com/llamalad7/mixinextras/expression/impl/wrapper/ExpressionInjectorWrapperTransformer 52 public,super java/lang/Object com/llamalad7/mixinextras/transformer/MixinTransformer -
 method public <init> ()V - -
 method public transform (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/objectweb/asm/tree/ClassNode;)V - -
in 61
class com/llamalad7/mixinextras/injector/IntLikeBehaviour 52 public,super,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/injector/IntLikeBehaviour$MatchArgType com/llamalad7/mixinextras/injector/IntLikeBehaviour MatchArgType public,static
 inner com/llamalad7/mixinextras/injector/IntLikeBehaviour$MatchReturnType com/llamalad7/mixinextras/injector/IntLikeBehaviour MatchReturnType public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public transform (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method protected,abstract transformImpl (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method protected replaceIntLike (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/injector/IntLikeBehaviour$MatchArgType 52 public,super com/llamalad7/mixinextras/injector/IntLikeBehaviour - -
 inner com/llamalad7/mixinextras/injector/IntLikeBehaviour$MatchArgType com/llamalad7/mixinextras/injector/IntLikeBehaviour MatchArgType public,static
 method public <init> (I)V - -
 method public transformImpl (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
in 61
class com/llamalad7/mixinextras/injector/IntLikeBehaviour$MatchReturnType 52 public,super com/llamalad7/mixinextras/injector/IntLikeBehaviour - -
 inner com/llamalad7/mixinextras/injector/IntLikeBehaviour$MatchReturnType com/llamalad7/mixinextras/injector/IntLikeBehaviour MatchReturnType public,static
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/injector/IntLikeBehaviour$MatchReturnType; -
 method public <init> ()V - -
 method public transformImpl (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
in 22
class com/llamalad7/mixinextras/injector/LateApplyingInjectorInfo 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract lateInject ()V - -
 method public,abstract latePostInject ()V - -
 method public,abstract wrap (Lcom/llamalad7/mixinextras/injector/LateApplyingInjectorInfo;)V - -
 method public,abstract getLateInjectionType ()Ljava/lang/String; - -
 method public,deprecated lateApply ()V - -
 method public,static wrap (Ljava/lang/Object;Lcom/llamalad7/mixinextras/injector/LateApplyingInjectorInfo;)Z - -
in 22
class com/llamalad7/mixinextras/injector/LateInjectionApplicatorExtension 52 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 61
class com/llamalad7/mixinextras/injector/MixinExtrasHooks 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static replaceContents (Ljava/lang/StringBuilder;Ljava/lang/String;)Ljava/lang/StringBuilder; - -
in 22
class com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo 52 public,super,abstract org/spongepowered/asm/mixin/injection/struct/InjectionInfo - -
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)V - -
 method public getSliceId (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/injector/MixinExtrasLateInjectionInfo 52 public,super,abstract com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo com/llamalad7/mixinextras/injector/LateApplyingInjectorInfo -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)V - -
 method public inject ()V - -
 method public postInject ()V - -
 method public addCallbackInvocation (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public lateInject ()V - -
 method public latePostInject ()V - -
 method public wrap (Lcom/llamalad7/mixinextras/injector/LateApplyingInjectorInfo;)V - -
in 22
class com/llamalad7/mixinextras/injector/ModifyExpressionValue 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract at ()[Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
in 22
class com/llamalad7/mixinextras/injector/ModifyExpressionValueInjectionInfo 52 public,super com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public prepare ()V - -
in 22
class com/llamalad7/mixinextras/injector/ModifyExpressionValueInjector 52 public,super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 61
class com/llamalad7/mixinextras/injector/ModifyExpressionValueInjector$TargetInfo 52 super java/lang/Object - -
 inner com/llamalad7/mixinextras/injector/ModifyExpressionValueInjector$TargetInfo com/llamalad7/mixinextras/injector/ModifyExpressionValueInjector TargetInfo private
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/llamalad7/mixinextras/injector/ModifyExpressionValueInjector;Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method public getInsertionPoint (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public invokeHandler (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;Lcom/llamalad7/mixinextras/injector/StackExtension;)V - -
in 22
class com/llamalad7/mixinextras/injector/ModifyReceiver 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract at ()[Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
in 22
class com/llamalad7/mixinextras/injector/ModifyReceiverInjectionInfo 52 public,super com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
in 22
class com/llamalad7/mixinextras/injector/ModifyReceiverInjector 52 public,super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 22
class com/llamalad7/mixinextras/injector/ModifyReturnValue 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract at ()[Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
in 22
class com/llamalad7/mixinextras/injector/ModifyReturnValueInjectionInfo 52 public,super com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
in 22
class com/llamalad7/mixinextras/injector/ModifyReturnValueInjector 52 public,super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 22
class com/llamalad7/mixinextras/injector/StackExtension 52 public,super java/lang/Object - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method public receiver (Z)V - -
 method public capturedArgs ([Lorg/objectweb/asm/Type;I)V - -
 method public extra (I)V - -
 method public ensureAtLeast (I)V - -
in 22
class com/llamalad7/mixinextras/injector/WrapWithCondition 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract at ()[Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
in 22
class com/llamalad7/mixinextras/injector/WrapWithConditionInjector 52 public,super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 22
class com/llamalad7/mixinextras/injector/WrapWithConditionV1InjectionInfo 52 public,super com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public prepare ()V - -
in 22
class com/llamalad7/mixinextras/injector/v2/WrapWithCondition 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract at ()[Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
in 22
class com/llamalad7/mixinextras/injector/v2/WrapWithConditionInjectionInfo 52 public,super com/llamalad7/mixinextras/injector/MixinExtrasLateInjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public prepare ()V - -
 method public getLateInjectionType ()Ljava/lang/String; - -
in 64
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
in 63
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
 method public,abstract order ()I - - I1000
in 65
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodApplicatorExtension 52 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Wrapper com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage Wrapper public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 inner com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Vanilla com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage Vanilla public,static
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 65
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodInjectionInfo 52 public,super com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method protected parseInjectionPoints (Ljava/util/List;)V (Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;)V -
in 65
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodInjectionPoint 52 super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 method public checkPriority (II)Z - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 65
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodInjector 52 public,super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 65
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage 52 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 inner com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Wrapper com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage Wrapper public,static
 inner com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Vanilla com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage Vanilla public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method protected,abstract getVanillaMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public,abstract apply (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/LinkedHashSet;)Lorg/objectweb/asm/tree/MethodNode; (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/LinkedHashSet<Lcom/llamalad7/mixinextras/sugar/impl/ShareInfo;>;)Lorg/objectweb/asm/tree/MethodNode; -
 method protected,static move (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Lorg/objectweb/asm/tree/MethodNode; - -
in 65
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Vanilla 52 public,super com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage - -
 inner com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Vanilla com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage Vanilla public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected getVanillaMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public apply (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/LinkedHashSet;)Lorg/objectweb/asm/tree/MethodNode; (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/LinkedHashSet<Lcom/llamalad7/mixinextras/sugar/impl/ShareInfo;>;)Lorg/objectweb/asm/tree/MethodNode; -
in 65
class com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Wrapper 52 public,super com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage - -
 inner com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage$Wrapper com/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage Wrapper public,static
 inner com/llamalad7/mixinextras/utils/OperationUtils$OperationContents com/llamalad7/mixinextras/utils/OperationUtils OperationContents public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/Type;Ljava/util/List;)V (Lcom/llamalad7/mixinextras/injector/wrapmethod/WrapMethodStage;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/Type;Ljava/util/List<Lcom/llamalad7/mixinextras/sugar/impl/ShareInfo;>;)V -
 method protected getVanillaMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public apply (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/LinkedHashSet;)Lorg/objectweb/asm/tree/MethodNode; (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/LinkedHashSet<Lcom/llamalad7/mixinextras/sugar/impl/ShareInfo;>;)Lorg/objectweb/asm/tree/MethodNode; -
in 22
class com/llamalad7/mixinextras/injector/wrapoperation/IncorrectArgumentCountException 52 super java/lang/RuntimeException - -
in 22
class com/llamalad7/mixinextras/injector/wrapoperation/Operation 52 public,interface,abstract java/lang/Object - <R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,varargs,abstract call ([Ljava/lang/Object;)Ljava/lang/Object; ([Ljava/lang/Object;)TR; -
in 22
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - -
 method public,abstract at ()[Lorg/spongepowered/asm/mixin/injection/At; - - []
 method public,abstract constant ()[Lorg/spongepowered/asm/mixin/injection/Constant; - - []
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
in 22
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjectionInfo 52 public,super com/llamalad7/mixinextras/injector/MixinExtrasLateInjectionInfo - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public prepare ()V - -
 method protected parseInjectionPoints (Ljava/util/List;)V (Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;)V -
 method public getLateInjectionType ()Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector 52 super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$ComparisonOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$ComparisonOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector ComparisonOperation private
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector MethodCallOperation private
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$DupedFactoryRedirectOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$DupedFactoryRedirectOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector DupedFactoryRedirectOperation private
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector MethodCallOperation private
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$DynamicInstanceofRedirectOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$DynamicInstanceofRedirectOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector DynamicInstanceofRedirectOperation private
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector MethodCallOperation private
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$FieldAccessOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationType private,static,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$FieldAccessOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector FieldAccessOperation private,static
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$InstanceofOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationType private,static,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$InstanceofOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector InstanceofOperation private,static
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$InstantiationOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationType private,static,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$InstantiationOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector InstantiationOperation private,static
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$MethodCallOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector MethodCallOperation private
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationType private,static,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationConstructor 52 interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationConstructor com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationConstructor private,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationType private,static,abstract
 method public,abstract make (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lcom/llamalad7/mixinextras/injector/StackExtension;)Lcom/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType; - -
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType 52 super,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationType private,static,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 field protected,final target Lorg/spongepowered/asm/mixin/injection/struct/Target; -
 field protected,final node Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; -
 field protected,final originalTarget Lorg/objectweb/asm/tree/AbstractInsnNode; -
 field protected,final currentTarget Lorg/objectweb/asm/tree/AbstractInsnNode; -
 field protected,final stack Lcom/llamalad7/mixinextras/injector/StackExtension; -
in 61
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$SimpleOperation 52 super com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType - -
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$OperationType com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector OperationType private,static,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector$SimpleOperation com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationInjector SimpleOperation private,static
in 22
class com/llamalad7/mixinextras/injector/wrapoperation/WrapOperationRuntime 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static checkArgumentCount ([Ljava/lang/Object;ILjava/lang/String;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorListener 52 public,interface,abstract java/lang/Object - -
 method public,abstract syntaxError (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V -
 method public,abstract reportAmbiguity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IIZLjava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public,abstract reportAttemptingFullContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IILjava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public,abstract reportContextSensitivity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IIILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorStrategy 52 public,interface,abstract java/lang/Object - -
 method public,abstract reset (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public,abstract recoverInline (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,abstract recover (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,abstract sync (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,abstract inErrorRecoveryMode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Z - -
 method public,abstract reportMatch (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public,abstract reportError (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/BaseErrorListener 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorListener -
 method public <init> ()V - -
 method public syntaxError (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V -
 method public reportAmbiguity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IIZLjava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public reportAttemptingFullContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IILjava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public reportContextSensitivity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IIILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/BufferedTokenStream 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/TokenStream -
 field protected tokenSource Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource; -
 field protected tokens Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;>;
 field protected p I -
 field protected fetchedEOF Z -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;)V - -
 method public getTokenSource ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource; - -
 method public index ()I - -
 method public mark ()I - -
 method public release (I)V - -
 method public seek (I)V - -
 method public size ()I - -
 method public consume ()V - -
 method protected sync (I)Z - -
 method protected fetch (I)I - -
 method public get (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public LA (I)I - -
 method protected LB (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public LT (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method protected adjustSeekIndex (I)I - -
 method protected,final lazyInit ()V - -
 method protected setup ()V - -
 method protected nextTokenOnChannel (II)I - -
 method protected previousTokenOnChannel (II)I - -
 method public getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Ljava/lang/String; - -
 method public getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CharStream 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/IntStream -
 method public,abstract getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CharStreams 52 public,final,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Builder com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer Builder public,static
 method public,static fromString (Ljava/lang/String;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream; - -
 method public,static fromString (Ljava/lang/String;Ljava/lang/String;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Builder com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer Builder public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer Type public,static,final,enum
 method public position ()I - -
 method public remaining ()I - -
 method public,static builder (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Builder; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Builder 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer Type public,static,final,enum
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Builder com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer Builder public,static
 method public build ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer; - -
 method public ensureRemaining (I)V - -
 method public append (Ljava/nio/CharBuffer;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer Type public,static,final,enum
 field public,static,final,enum BYTE Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type; -
 field public,static,final,enum CHAR Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type; -
 field public,static,final,enum INT Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type; -
 method public,static values ()[Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream 52 public,super,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/CharStream -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint32BitCharStream com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream CodePoint32BitCharStream private,static,final
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint16BitCharStream com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream CodePoint16BitCharStream private,static,final
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint8BitCharStream com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream CodePoint8BitCharStream private,static,final
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer$Type com/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer Type public,static,final,enum
 field protected,final size I -
 field protected,final name Ljava/lang/String; -
 field protected position I -
 method public,static fromBuffer (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointBuffer;Ljava/lang/String;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream; - -
 method public,final consume ()V - -
 method public,final index ()I - -
 method public,final size ()I - -
 method public,final mark ()I - -
 method public,final release (I)V - -
 method public,final seek (I)V - -
 method public,final toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint16BitCharStream 52 final,super com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint16BitCharStream com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream CodePoint16BitCharStream private,static,final
 method public getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Ljava/lang/String; - -
 method public LA (I)I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint32BitCharStream 52 final,super com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint32BitCharStream com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream CodePoint32BitCharStream private,static,final
 method public getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Ljava/lang/String; - -
 method public LA (I)I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint8BitCharStream 52 final,super com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream$CodePoint8BitCharStream com/llamalad7/mixinextras/lib/antlr/runtime/CodePointCharStream CodePoint8BitCharStream private,static,final
 method public getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Ljava/lang/String; - -
 method public LA (I)I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CommonToken 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/WritableToken,java/io/Serializable -
 field protected,static,final EMPTY_SOURCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair; Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair<Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;>;
 field protected type I -
 field protected line I -
 field protected charPositionInLine I -
 field protected channel I -
 field protected source Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair; Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair<Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;>;
 field protected text Ljava/lang/String; -
 field protected index I -
 field protected start I -
 field protected stop I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair;IIII)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair<Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;>;IIII)V -
 method public getType ()I - -
 method public setLine (I)V - -
 method public getText ()Ljava/lang/String; - -
 method public setText (Ljava/lang/String;)V - -
 method public getLine ()I - -
 method public getCharPositionInLine ()I - -
 method public setCharPositionInLine (I)V - -
 method public getChannel ()I - -
 method public getStartIndex ()I - -
 method public getStopIndex ()I - -
 method public getTokenIndex ()I - -
 method public setTokenIndex (I)V - -
 method public getTokenSource ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource; - -
 method public getInputStream ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream; - -
 method public toString ()Ljava/lang/String; - -
 method public toString (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;)Ljava/lang/String; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;)Ljava/lang/String; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CommonTokenFactory 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory Ljava/lang/Object;Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory<Lcom/llamalad7/mixinextras/lib/antlr/runtime/CommonToken;>;
 field public,static,final DEFAULT Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory; Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory<Lcom/llamalad7/mixinextras/lib/antlr/runtime/CommonToken;>;
 field protected,final copyText Z -
 method public <init> (Z)V - -
 method public <init> ()V - -
 method public create (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair;ILjava/lang/String;IIIII)Lcom/llamalad7/mixinextras/lib/antlr/runtime/CommonToken; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair<Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;>;ILjava/lang/String;IIIII)Lcom/llamalad7/mixinextras/lib/antlr/runtime/CommonToken; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/CommonTokenStream 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/BufferedTokenStream - -
 field protected channel I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;)V - -
 method protected adjustSeekIndex (I)I - -
 method protected LB (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public LT (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/ConsoleErrorListener 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/BaseErrorListener - -
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/ConsoleErrorListener; -
 method public <init> ()V - -
 method public syntaxError (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/DefaultErrorStrategy 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorStrategy -
 field protected errorRecoveryMode Z -
 field protected lastErrorIndex I -
 field protected lastErrorStates Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; -
 field protected nextTokensContext Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext; -
 field protected nextTokensState I -
 method public <init> ()V - -
 method public reset (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method protected beginErrorCondition (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public inErrorRecoveryMode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Z - -
 method protected endErrorCondition (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public reportMatch (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public reportError (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V - -
 method public recover (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V - -
 method public sync (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method protected reportNoViableAlternative (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/NoViableAltException;)V - -
 method protected reportInputMismatch (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/InputMismatchException;)V - -
 method protected reportFailedPredicate (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/FailedPredicateException;)V - -
 method protected reportUnwantedToken (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method protected reportMissingToken (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public recoverInline (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method protected singleTokenInsertion (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Z - -
 method protected singleTokenDeletion (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method protected getMissingSymbol (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method protected getExpectedTokens (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method protected getTokenErrorDisplay (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)Ljava/lang/String; - -
 method protected getSymbolText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)Ljava/lang/String; - -
 method protected getSymbolType (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)I - -
 method protected escapeWSAndQuote (Ljava/lang/String;)Ljava/lang/String; - -
 method protected getErrorRecoverySet (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method protected consumeUntil (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/FailedPredicateException 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Ljava/lang/String;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Ljava/lang/String;Ljava/lang/String;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/InputMismatchException 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;ILcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/IntStream 52 public,interface,abstract java/lang/Object - -
 method public,abstract consume ()V - -
 method public,abstract LA (I)I - -
 method public,abstract mark ()I - -
 method public,abstract release (I)V - -
 method public,abstract index ()I - -
 method public,abstract seek (I)V - -
 method public,abstract size ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/Lexer 52 public,super,abstract com/llamalad7/mixinextras/lib/antlr/runtime/Recognizer com/llamalad7/mixinextras/lib/antlr/runtime/TokenSource Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<Ljava/lang/Integer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator;>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;
 field public _input Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream; -
 field protected _tokenFactorySourcePair Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair; Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair<Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;>;
 field protected _factory Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory; Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory<*>;
 field public _token Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public _tokenStartCharIndex I -
 field public _tokenStartLine I -
 field public _tokenStartCharPositionInLine I -
 field public _hitEOF Z -
 field public _channel I -
 field public _type I -
 field public,final _modeStack Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntegerStack; -
 field public _mode I -
 field public _text Ljava/lang/String; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;)V - -
 method public nextToken ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public skip ()V - -
 method public more ()V - -
 method public mode (I)V - -
 method public pushMode (I)V - -
 method public popMode ()I - -
 method public getTokenFactory ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory; ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory<+Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;>; -
 method public getInputStream ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream; - -
 method public emit (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)V - -
 method public emit ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public emitEOF ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public getLine ()I - -
 method public getCharPositionInLine ()I - -
 method public getCharIndex ()I - -
 method public getText ()Ljava/lang/String; - -
 method public setText (Ljava/lang/String;)V - -
 method public setType (I)V - -
 method public setChannel (I)V - -
 method public,deprecated getTokenNames ()[Ljava/lang/String; - -
 method public recover (Lcom/llamalad7/mixinextras/lib/antlr/runtime/LexerNoViableAltException;)V - -
 method public notifyListeners (Lcom/llamalad7/mixinextras/lib/antlr/runtime/LexerNoViableAltException;)V - -
 method public getErrorDisplay (Ljava/lang/String;)Ljava/lang/String; - -
 method public getErrorDisplay (I)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/LexerNoViableAltException 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public getInputStream ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream; - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/NoViableAltException 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
 method public getStartToken ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/Parser 52 public,super,abstract com/llamalad7/mixinextras/lib/antlr/runtime/Recognizer - Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ParserATNSimulator;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/Parser$TraceListener com/llamalad7/mixinextras/lib/antlr/runtime/Parser TraceListener public
 field protected _errHandler Lcom/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorStrategy; -
 field protected _input Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream; -
 field protected,final _precedenceStack Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntegerStack; -
 field protected _ctx Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext; -
 field protected _buildParseTrees Z -
 field protected _parseListeners Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;>;
 field protected _syntaxErrors I -
 field protected matchedEOF Z -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;)V - -
 method public reset ()V - -
 method public match (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public addParseListener (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public removeParseListener (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method protected triggerEnterRuleEvent ()V - -
 method protected triggerExitRuleEvent ()V - -
 method public getTokenFactory ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory; ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory<*>; -
 method public getInputStream ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream; - -
 method public,final setInputStream (Lcom/llamalad7/mixinextras/lib/antlr/runtime/IntStream;)V - -
 method public getTokenStream ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream; - -
 method public setTokenStream (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;)V - -
 method public getCurrentToken ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public notifyErrorListeners (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;Ljava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V - -
 method public consume ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public createTerminalNode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode; - -
 method public createErrorNode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNode; - -
 method protected addContextToParseTree ()V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;II)V - -
 method public exitRule ()V - -
 method public enterOuterAlt (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public,final getPrecedence ()I - -
 method public enterRecursionRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;III)V - -
 method public pushNewRecursionContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;II)V - -
 method public unrollRecursionContexts (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
 method public getContext ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext; - -
 method public precpred (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;I)Z - -
 method public getExpectedTokens ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public getRuleInvocationStack ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getRuleInvocationStack (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Ljava/util/List; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Ljava/util/List<Ljava/lang/String;>; -
 method public setTrace (Z)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/Parser$TraceListener 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/Parser$TraceListener com/llamalad7/mixinextras/lib/antlr/runtime/Parser TraceListener public
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;)V - -
 method public enterEveryRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
 method public visitTerminal (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode;)V - -
 method public visitErrorNode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNode;)V - -
 method public exitEveryRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/RuleContext - -
 field public,static,final EMPTY Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext; -
 field public children Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree;>;
 field public start Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public stop Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public exception Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException; -
 method public <init> ()V - -
 method public copyFrom (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public addAnyChild (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree; <T::Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree;>(TT;)TT; -
 method public addChild (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext; - -
 method public addChild (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode; - -
 method public addErrorNode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNode;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNode; - -
 method public removeLastChild ()V - -
 method public getChild (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree; - -
 method public getChild (Ljava/lang/Class;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree; <T::Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree;>(Ljava/lang/Class<+TT;>;I)TT; -
 method public getRuleContext (Ljava/lang/Class;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext; <T:Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;>(Ljava/lang/Class<+TT;>;I)TT; -
 method public getRuleContexts (Ljava/lang/Class;)Ljava/util/List; <T:Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;>(Ljava/lang/Class<+TT;>;)Ljava/util/List<TT;>; -
 method public getChildCount ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/ProxyErrorListener 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorListener -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<+Lcom/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorListener;>;)V -
 method public syntaxError (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Ljava/lang/Object;IILjava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException;)V -
 method public reportAmbiguity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IIZLjava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public reportAttemptingFullContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IILjava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public reportContextSensitivity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;IIILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException 52 public,super java/lang/RuntimeException - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/IntStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/IntStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V -
 method public <init> (Ljava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/IntStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V (Ljava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/IntStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V -
 method protected,final setOffendingState (I)V - -
 method public getExpectedTokens ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public getInputStream ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/IntStream; - -
 method public getOffendingToken ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method protected,final setOffendingToken (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/Recognizer 52 public,super,abstract java/lang/Object - <Symbol:Ljava/lang/Object;ATNInterpreter:Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNSimulator;>Ljava/lang/Object;
 field protected _interp Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNSimulator; TATNInterpreter;
 method public <init> ()V - -
 method public,abstract,deprecated getTokenNames ()[Ljava/lang/String; - -
 method public,abstract getRuleNames ()[Ljava/lang/String; - -
 method public getVocabulary ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary; - -
 method public,abstract getATN ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; - -
 method public getInterpreter ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNSimulator; ()TATNInterpreter; -
 method public addErrorListener (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorListener;)V - -
 method public removeErrorListeners ()V - -
 method public getErrorListeners ()Ljava/util/List; ()Ljava/util/List<+Lcom/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorListener;>; -
 method public getErrorListenerDispatch ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/ANTLRErrorListener; - -
 method public sempred (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;II)Z - -
 method public precpred (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;I)Z - -
 method public action (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;II)V - -
 method public,final getState ()I - -
 method public,final setState (I)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/RuleContext 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/tree/RuleNode -
 field public parent Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext; -
 field public invokingState I -
 method public <init> ()V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;I)V - -
 method public isEmpty ()Z - -
 method public getText ()Ljava/lang/String; - -
 method public getRuleIndex ()I - -
 method public setAltNumber (I)V - -
 method public setParent (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)V - -
 method public getChild (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree; - -
 method public getChildCount ()I - -
 method public toString ()Ljava/lang/String; - -
 method public toString (Ljava/util/List;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Ljava/lang/String; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/RuntimeMetaData 52 public,super java/lang/Object - -
 method public,static checkVersion (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static getMajorMinorVersion (Ljava/lang/String;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/Token 52 public,interface,abstract java/lang/Object - -
 method public,abstract getText ()Ljava/lang/String; - -
 method public,abstract getType ()I - -
 method public,abstract getLine ()I - -
 method public,abstract getCharPositionInLine ()I - -
 method public,abstract getChannel ()I - -
 method public,abstract getTokenIndex ()I - -
 method public,abstract getStartIndex ()I - -
 method public,abstract getStopIndex ()I - -
 method public,abstract getTokenSource ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory 52 public,interface,abstract java/lang/Object - <Symbol::Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;>Ljava/lang/Object;
 method public,abstract create (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair;ILjava/lang/String;IIIII)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair<Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;>;ILjava/lang/String;IIIII)TSymbol; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/TokenSource 52 public,interface,abstract java/lang/Object - -
 method public,abstract nextToken ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public,abstract getLine ()I - -
 method public,abstract getCharPositionInLine ()I - -
 method public,abstract getInputStream ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream; - -
 method public,abstract getTokenFactory ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory; ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenFactory<*>; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/TokenStream 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/IntStream -
 method public,abstract LT (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public,abstract get (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public,abstract getTokenSource ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenSource; - -
 method public,abstract getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Ljava/lang/String; - -
 method public,abstract getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary 52 public,interface,abstract java/lang/Object - -
 method public,abstract getLiteralName (I)Ljava/lang/String; - -
 method public,abstract getSymbolicName (I)Ljava/lang/String; - -
 method public,abstract getDisplayName (I)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/VocabularyImpl 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary -
 field public,static,final EMPTY_VOCABULARY Lcom/llamalad7/mixinextras/lib/antlr/runtime/VocabularyImpl; -
 method public <init> ([Ljava/lang/String;[Ljava/lang/String;)V - -
 method public <init> ([Ljava/lang/String;[Ljava/lang/String;[Ljava/lang/String;)V - -
 method public,static fromTokenNames ([Ljava/lang/String;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary; - -
 method public getLiteralName (I)Ljava/lang/String; - -
 method public getSymbolicName (I)Ljava/lang/String; - -
 method public getDisplayName (I)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/WritableToken 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/Token -
 method public,abstract setTokenIndex (I)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN 52 public,super java/lang/Object - -
 field public,final states Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;>;
 field public,final decisionToState Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState;>;
 field public ruleToStartState [Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleStartState; -
 field public ruleToStopState [Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleStopState; -
 field public,final modeNameToStartState Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/TokensStartState;>;
 field public,final grammarType Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNType; -
 field public,final maxTokenType I -
 field public ruleToTokenType [I -
 field public lexerActions [Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction; -
 field public,final modeToStartState Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/TokensStartState;>;
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNType;I)V - -
 method public nextTokens (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public nextTokens (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public addState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
 method public defineDecisionState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState;)I - -
 method public getDecisionState (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState; - -
 method public getNumberOfDecisions ()I - -
 method public getExpectedTokens (ILcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 field public,final state Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState; -
 field public,final alt I -
 field public context Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; -
 field public reachesIntoOuterContext I -
 field public,final semanticContext Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)V - -
 method public,final getOuterContextDepth ()I - -
 method public,final isPrecedenceFilterSuppressed ()Z - -
 method public,final setPrecedenceFilterSuppressed (Z)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public equals (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public toString (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Z)Ljava/lang/String; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Z)Ljava/lang/String; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet 52 public,super java/lang/Object java/util/Set Ljava/lang/Object;Ljava/util/Set<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet AbstractConfigHashSet public,static,abstract
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigEqualityComparator com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet ConfigEqualityComparator public,static,final
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet ConfigHashSet public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 field protected readonly Z -
 field public configLookup Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet; -
 field public,final configs Ljava/util/ArrayList; Ljava/util/ArrayList<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;
 field public uniqueAlt I -
 field protected conflictingAlts Ljava/util/BitSet; -
 field public hasSemanticContext Z -
 field public dipsIntoOuterContext Z -
 field public,final fullCtx Z -
 method public <init> (Z)V - -
 method public <init> ()V - -
 method public add (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)Z - -
 method public add (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap;)Z (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;>;)Z -
 method public elements ()Ljava/util/List; ()Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>; -
 method public getAlts ()Ljava/util/BitSet; - -
 method public optimizeConfigs (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNSimulator;)V - -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;)Z -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>; -
 method public clear ()V - -
 method public isReadonly ()Z - -
 method public setReadonly (Z)V - -
 method public toString ()Ljava/lang/String; - -
 method public toArray ()[Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public remove (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet 52 public,super,abstract com/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet - Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet AbstractConfigHashSet public,static,abstract
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator;)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<-Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;)V -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator;II)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<-Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;II)V -
 method protected,final asElementType (Ljava/lang/Object;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method protected,final createBuckets (I)[[Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method protected,final createBucket (I)[Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigEqualityComparator 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator - Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigEqualityComparator com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet ConfigEqualityComparator public,static,final
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigEqualityComparator; -
 method public hashCode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)I - -
 method public equals (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigHashSet 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet ConfigHashSet public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet AbstractConfigHashSet public,static,abstract
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$ConfigEqualityComparator com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet ConfigEqualityComparator public,static,final
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNDeserializationOptions 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getDefaultOptions ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNDeserializationOptions; - -
 method public,final makeReadOnly ()V - -
 method public,final isVerifyATN ()Z - -
 method public,final isGenerateRuleBypassTransitions ()Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNDeserializer 52 public,super java/lang/Object - -
 field public,static,final SERIALIZED_VERSION I -
 method public <init> ()V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNDeserializationOptions;)V - -
 method public deserialize ([C)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; - -
 method public deserialize ([I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; - -
 method protected markPrecedenceDecisions (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;)V - -
 method protected verifyATN (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;)V - -
 method protected checkCondition (Z)V - -
 method protected checkCondition (ZLjava/lang/String;)V - -
 method protected edgeFactory (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;IIIIIILjava/util/List;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;IIIIIILjava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;>;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition; -
 method protected stateFactory (II)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState; - -
 method protected lexerActionFactory (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType;II)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction; - -
 method public,static decodeIntsEncodedAs16BitWords ([C)[I - -
 method public,static decodeIntsEncodedAs16BitWords ([CZ)[I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNSimulator 52 public,super,abstract java/lang/Object - -
 field public,static,final ERROR Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; -
 field public,final atn Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; -
 field protected,final sharedContextCache Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache;)V - -
 method public,abstract reset ()V - -
 method public getCachedContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState 52 public,super,abstract java/lang/Object - -
 field public,static,final serializationNames Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public atn Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; -
 field public stateNumber I -
 field public ruleIndex I -
 field public epsilonOnlyTransitions Z -
 field protected,final transitions Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;>;
 field public nextTokenWithinRule Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; -
 method public <init> ()V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public getNumberOfTransitions ()I - -
 method public addTransition (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;)V - -
 method public addTransition (ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;)V - -
 method public transition (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition; - -
 method public removeTransition (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition; - -
 method public,abstract getStateType ()I - -
 method public,final onlyHasEpsilonTransitions ()Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNType;>;
 field public,static,final,enum LEXER Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNType; -
 field public,static,final,enum PARSER Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNType; -
 method public,static values ()[Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNType; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/AbstractPredicateTransition 52 public,super,abstract com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ActionTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 field public,final ruleIndex I -
 field public,final actionIndex I -
 field public,final isCtxDependent Z -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;IIZ)V - -
 method public getSerializationType ()I - -
 method public isEpsilon ()Z - -
 method public matches (III)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ArrayPredictionContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext - -
 field public,final parents [Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; -
 field public,final returnStates [I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext;)V - -
 method public <init> ([Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;[I)V - -
 method public isEmpty ()Z - -
 method public size ()I - -
 method public getParent (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
 method public getReturnState (I)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/AtomTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 field public,final label I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;I)V - -
 method public getSerializationType ()I - -
 method public label ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public matches (III)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/BasicBlockStartState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/BlockStartState - -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/BasicState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState - -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/BlockEndState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState - -
 field public startState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/BlockStartState; -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/BlockStartState 52 public,super,abstract com/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState - -
 field public endState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/BlockEndState; -
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState 52 public,super,abstract com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState - -
 field public decision I -
 field public nonGreedy Z -
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/EmptyPredictionContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext - -
 field public,static,final Instance Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/EmptyPredictionContext; -
 method public isEmpty ()Z - -
 method public size ()I - -
 method public getParent (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
 method public getReturnState (I)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/EpsilonTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;I)V - -
 method public outermostPrecedenceReturn ()I - -
 method public getSerializationType ()I - -
 method public isEpsilon ()Z - -
 method public matches (III)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LL1Analyzer 52 public,super java/lang/Object - -
 field public,final atn Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;)V - -
 method public LOOK (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public LOOK (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method protected _LOOK (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;Ljava/util/Set;Ljava/util/BitSet;ZZ)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;Ljava/util/Set<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;Ljava/util/BitSet;ZZ)V -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNConfig 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor;)V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)V - -
 method public,final getLexerActionExecutor ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor; - -
 method public,final hasPassedThroughNonGreedyDecision ()Z - -
 method public hashCode ()I - -
 method public equals (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNSimulator - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator$SimState com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator SimState protected,static
 field protected,final recog Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer; -
 field protected startIndex I -
 field protected line I -
 field protected charPositionInLine I -
 field public,final decisionToDFA [Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA; -
 field protected mode I -
 field protected,final prevAccept Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator$SimState; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;[Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache;)V - -
 method public match (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;I)I - -
 method public reset ()V - -
 method protected matchATN (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;)I - -
 method protected execATN (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;)I - -
 method protected getExistingTargetState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method protected computeTargetState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method protected failOrAccept (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator$SimState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;I)I - -
 method protected getReachableConfigSet (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;I)V - -
 method protected accept (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor;IIII)V - -
 method protected getReachableTarget (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState; - -
 method protected computeStartState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet; - -
 method protected closure (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;ZZZ)Z - -
 method protected getEpsilonTarget (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;ZZ)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNConfig; - -
 method protected evaluatePredicate (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;IIZ)Z - -
 method protected captureSimState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator$SimState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;)V - -
 method protected addDFAEdge (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method protected addDFAEdge (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;ILcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;)V - -
 method protected addDFAState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method public getText (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;)Ljava/lang/String; - -
 method public getLine ()I - -
 method public getCharPositionInLine ()I - -
 method public consume (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator$SimState 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator$SimState com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerATNSimulator SimState protected,static
 field protected index I -
 field protected line I -
 field protected charPos I -
 field protected dfaState Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; -
 method protected <init> ()V - -
 method protected reset ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction 52 public,interface,abstract java/lang/Object - -
 method public,abstract isPositionDependent ()Z - -
 method public,abstract execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor 52 public,super java/lang/Object - -
 method public <init> ([Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction;)V - -
 method public,static append (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor; - -
 method public fixOffsetBeforeMatch (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor; - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;I)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType;>;
 field public,static,final,enum CHANNEL Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 field public,static,final,enum CUSTOM Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 field public,static,final,enum MODE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 field public,static,final,enum MORE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 field public,static,final,enum POP_MODE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 field public,static,final,enum PUSH_MODE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 field public,static,final,enum SKIP Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 field public,static,final,enum TYPE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; -
 method public,static values ()[Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerChannelAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 method public <init> (I)V - -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerCustomAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 method public <init> (II)V - -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerIndexedCustomAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 method public <init> (ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction;)V - -
 method public getOffset ()I - -
 method public getAction ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerModeAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 method public <init> (I)V - -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerMoreAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerMoreAction; -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerPopModeAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerPopModeAction; -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerPushModeAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 method public <init> (I)V - -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerSkipAction 52 public,final,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerSkipAction; -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerTypeAction 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerAction -
 method public <init> (I)V - -
 method public getActionType ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionType; - -
 method public isPositionDependent ()Z - -
 method public execute (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Lexer;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/LoopEndState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState - -
 field public loopBackState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState; -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/NotSetTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/SetTransition - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;)V - -
 method public getSerializationType ()I - -
 method public matches (III)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/OrderedATNConfigSet 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/OrderedATNConfigSet$LexerConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/OrderedATNConfigSet LexerConfigHashSet public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet AbstractConfigHashSet public,static,abstract
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/OrderedATNConfigSet$LexerConfigHashSet 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/OrderedATNConfigSet$LexerConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/OrderedATNConfigSet LexerConfigHashSet public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet$AbstractConfigHashSet com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet AbstractConfigHashSet public,static,abstract
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/ParserATNSimulator 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNSimulator - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState PredPrediction public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext PrecedencePredicate public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Predicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Predicate public,static
 field public,static debug Z -
 field public,static trace_atn_sim Z -
 field public,static dfa_debug Z -
 field public,static retry_debug Z -
 field public,static,final TURN_OFF_LR_LOOP_ENTRY_BRANCH_OPT Z -
 field protected,final parser Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser; -
 field public,final decisionToDFA [Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA; -
 field protected mergeCache Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap; Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;>;
 field protected _input Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream; -
 field protected _startIndex I -
 field protected _outerContext Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext; -
 field protected _dfa Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Parser;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;[Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache;)V - -
 method public reset ()V - -
 method public adaptivePredict (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;ILcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)I - -
 method protected execATN (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;ILcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)I - -
 method protected getExistingTargetState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method protected computeTargetState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method protected predicateDFAState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState;)V - -
 method protected execATNWithFullContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;ILcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)I - -
 method protected computeReachSet (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;IZ)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet; - -
 method protected removeAllConfigsNotInRuleStopState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Z)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet; - -
 method protected computeStartState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;Z)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet; - -
 method protected applyPrecedenceFilter (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet; - -
 method protected getReachableTarget (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState; - -
 method protected getPredsForAmbigAlts (Ljava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;I)[Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; - -
 method protected getPredicatePredictions (Ljava/util/BitSet;[Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)[Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction; - -
 method protected getSynValidOrSemInvalidAltThatFinishedDecisionEntryRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)I - -
 method protected getAltThatFinishedDecisionEntryRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)I - -
 method protected splitAccordingToSemanticValidity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;>; -
 method protected evalSemanticContext ([Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;Z)Ljava/util/BitSet; - -
 method protected evalSemanticContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;IZ)Z - -
 method protected closure (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Ljava/util/Set;ZZZ)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Ljava/util/Set<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;ZZZ)V -
 method protected closureCheckingStopState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Ljava/util/Set;ZZIZ)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Ljava/util/Set<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;ZZIZ)V -
 method protected closure_ (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Ljava/util/Set;ZZIZ)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;Ljava/util/Set<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;ZZIZ)V -
 method protected canDropLoopEntryEdgeInLeftRecursiveRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)Z - -
 method public getRuleName (I)Ljava/lang/String; - -
 method protected getEpsilonTarget (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;ZZZZ)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method protected actionTransition (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ActionTransition;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method public precedenceTransition (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PrecedencePredicateTransition;ZZZ)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method protected predTransition (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredicateTransition;ZZZ)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method protected ruleTransition (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleTransition;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig; - -
 method protected getConflictingAlts (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Ljava/util/BitSet; - -
 method protected getConflictingAltsOrUniqueAlt (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Ljava/util/BitSet; - -
 method public getTokenName (I)Ljava/lang/String; - -
 method public getLookaheadName (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;)Ljava/lang/String; - -
 method protected noViableAlt (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/NoViableAltException; - -
 method protected,static getUniqueAlt (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)I - -
 method protected addDFAEdge (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;ILcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method protected addDFAState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method protected reportAttemptingFullContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Ljava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;II)V - -
 method protected reportContextSensitivity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;ILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;II)V - -
 method protected reportAmbiguity (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;IIZLjava/util/BitSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public,static getSafeEnv (Ljava/lang/String;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PlusBlockStartState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/BlockStartState - -
 field public loopBackState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PlusLoopbackState; -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PlusLoopbackState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState - -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PrecedencePredicateTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/AbstractPredicateTransition - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext PrecedencePredicate public,static
 field public,final precedence I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;I)V - -
 method public getSerializationType ()I - -
 method public isEpsilon ()Z - -
 method public matches (III)Z - -
 method public getPredicate ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate; - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredicateTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/AbstractPredicateTransition - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Predicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Predicate public,static
 field public,final ruleIndex I -
 field public,final predIndex I -
 field public,final isCtxDependent Z -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;IIZ)V - -
 method public getSerializationType ()I - -
 method public isEpsilon ()Z - -
 method public matches (III)Z - -
 method public getPredicate ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Predicate; - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext 52 public,super,abstract java/lang/Object - -
 field public,final id I -
 field public,final cachedHashCode I -
 method protected <init> (I)V - -
 method public,static fromRuleContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
 method public,abstract size ()I - -
 method public,abstract getParent (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
 method public,abstract getReturnState (I)I - -
 method public isEmpty ()Z - -
 method public hasEmptyPath ()Z - -
 method public,final hashCode ()I - -
 method public,abstract equals (Ljava/lang/Object;)Z - -
 method protected,static calculateEmptyHashCode ()I - -
 method protected,static calculateHashCode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;I)I - -
 method protected,static calculateHashCode ([Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;[I)I - -
 method public,static merge (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;ZLcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;ZLcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;>;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; -
 method public,static mergeSingletons (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext;ZLcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext;ZLcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;>;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; -
 method public,static mergeRoot (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext;Z)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
 method public,static mergeArrays (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ArrayPredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ArrayPredictionContext;ZLcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ArrayPredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ArrayPredictionContext;ZLcom/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;>;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; -
 method protected,static combineCommonParents ([Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)V - -
 method public,static getCachedContext (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache;Ljava/util/IdentityHashMap;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache;Ljava/util/IdentityHashMap<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;>;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; -
 method public toString (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;)Ljava/lang/String; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;)Ljava/lang/String; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache 52 public,super java/lang/Object - -
 field protected,final cache Ljava/util/Map; Ljava/util/Map<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;>;
 method public <init> ()V - -
 method public add (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
 method public get (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextConfigEqualityComparator com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode AltAndContextConfigEqualityComparator private,static,final
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextMap com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode AltAndContextMap static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 field public,static,final,enum SLL Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode; -
 field public,static,final,enum LL Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode; -
 field public,static,final,enum LL_EXACT_AMBIG_DETECTION Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode; -
 method public,static hasSLLConflictTerminatingPrediction (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Z - -
 method public,static hasConfigInRuleStopState (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Z - -
 method public,static allConfigsInRuleStopStates (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Z - -
 method public,static resolvesToJustOneViableAlt (Ljava/util/Collection;)I (Ljava/util/Collection<Ljava/util/BitSet;>;)I -
 method public,static allSubsetsConflict (Ljava/util/Collection;)Z (Ljava/util/Collection<Ljava/util/BitSet;>;)Z -
 method public,static hasNonConflictingAltSet (Ljava/util/Collection;)Z (Ljava/util/Collection<Ljava/util/BitSet;>;)Z -
 method public,static hasConflictingAltSet (Ljava/util/Collection;)Z (Ljava/util/Collection<Ljava/util/BitSet;>;)Z -
 method public,static allSubsetsEqual (Ljava/util/Collection;)Z (Ljava/util/Collection<Ljava/util/BitSet;>;)Z -
 method public,static getUniqueAlt (Ljava/util/Collection;)I (Ljava/util/Collection<Ljava/util/BitSet;>;)I -
 method public,static getAlts (Ljava/util/Collection;)Ljava/util/BitSet; (Ljava/util/Collection<Ljava/util/BitSet;>;)Ljava/util/BitSet; -
 method public,static getConflictingAltSubsets (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Ljava/util/Collection; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Ljava/util/Collection<Ljava/util/BitSet;>; -
 method public,static getStateToAltMap (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Ljava/util/Map; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Ljava/util/Map<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Ljava/util/BitSet;>; -
 method public,static hasStateAssociatedWithOneAlt (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)Z - -
 method public,static getSingleViableAlt (Ljava/util/Collection;)I (Ljava/util/Collection<Ljava/util/BitSet;>;)I -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextConfigEqualityComparator 52 final,super com/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator - Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextConfigEqualityComparator com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode AltAndContextConfigEqualityComparator private,static,final
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextConfigEqualityComparator; -
 method public hashCode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)I - -
 method public equals (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextMap 52 super com/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap - Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfig;Ljava/util/BitSet;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextMap com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode AltAndContextMap static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode$AltAndContextConfigEqualityComparator com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionMode AltAndContextConfigEqualityComparator private,static,final
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/RangeTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 field public,final from I -
 field public,final to I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;II)V - -
 method public getSerializationType ()I - -
 method public label ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public matches (III)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleStartState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState - -
 field public stopState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleStopState; -
 field public isLeftRecursiveRule Z -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleStopState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState - -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 field public,final ruleIndex I -
 field public,final precedence I -
 field public followState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/RuleStartState;IILcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
 method public getSerializationType ()I - -
 method public isEpsilon ()Z - -
 method public matches (III)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext 52 public,super,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$OR com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext OR public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$AND com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext AND public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Operator com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Operator public,static,abstract
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext PrecedencePredicate public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Predicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Predicate public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 method public <init> ()V - -
 method public,abstract eval (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z -
 method public evalPrecedence (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 method public,static and (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; - -
 method public,static or (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$AND 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Operator - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext PrecedencePredicate public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$AND com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext AND public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Operator com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Operator public,static,abstract
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 field public,final opnds [Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public eval (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z -
 method public evalPrecedence (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 field public,static,final Instance Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty; -
 method public <init> ()V - -
 method public eval (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$OR 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Operator - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext PrecedencePredicate public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$OR com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext OR public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Operator com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Operator public,static,abstract
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 field public,final opnds [Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public eval (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z -
 method public evalPrecedence (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Operator 52 public,super,abstract com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Operator com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Operator public,static,abstract
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext java/lang/Comparable Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;Ljava/lang/Comparable<Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext PrecedencePredicate public,static
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Empty com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Empty public,static
 field public,final precedence I -
 method protected <init> ()V - -
 method public <init> (I)V - -
 method public eval (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z -
 method public evalPrecedence (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 method public compareTo (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$PrecedencePredicate;)I - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Predicate 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext$Predicate com/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext Predicate public,static
 field public,final ruleIndex I -
 field public,final predIndex I -
 field public,final isCtxDependent Z -
 method protected <init> ()V - -
 method public <init> (IIZ)V - -
 method public eval (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Recognizer<**>;Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)Z -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SetTransition 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 field public,final set Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;)V - -
 method public getSerializationType ()I - -
 method public label ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public matches (III)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext - -
 field public,final parent Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; -
 field public,final returnState I -
 method public,static create (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext;I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SingletonPredictionContext; - -
 method public size ()I - -
 method public getParent (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContext; - -
 method public getReturnState (I)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/StarBlockStartState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/BlockStartState - -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/StarLoopEntryState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState - -
 field public loopBackState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/StarLoopbackState; -
 field public isPrecedenceDecision Z -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/StarLoopbackState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState - -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/TokensStartState 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState - -
 method public <init> ()V - -
 method public getStateType ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition 52 public,super,abstract java/lang/Object - -
 field public,static,final serializationNames Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public,static,final serializationTypes Ljava/util/Map; Ljava/util/Map<Ljava/lang/Class<+Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition;>;Ljava/lang/Integer;>;
 field public target Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState; -
 method protected <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
 method public,abstract getSerializationType ()I - -
 method public isEpsilon ()Z - -
 method public label ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public,abstract matches (III)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/atn/WildcardTransition 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/atn/Transition - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNState;)V - -
 method public getSerializationType ()I - -
 method public matches (III)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA 52 public,super java/lang/Object - -
 field public,final states Ljava/util/Map; Ljava/util/Map<Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;>;
 field public,volatile s0 Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; -
 field public,final decision I -
 field public,final atnStartState Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/DecisionState;I)V - -
 method public,final isPrecedenceDfa ()Z - -
 method public,final getPrecedenceStartState (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; - -
 method public,final setPrecedenceStartState (ILcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;)V - -
 method public getStates ()Ljava/util/List; ()Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;>; -
 method public toString ()Ljava/lang/String; - -
 method public toString (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFASerializer 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState PredPrediction public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA;Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary;)V - -
 method public toString ()Ljava/lang/String; - -
 method protected getEdgeLabel (I)Ljava/lang/String; - -
 method protected getStateString (Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState PredPrediction public,static
 field public stateNumber I -
 field public configs Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet; -
 field public edges [Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState; -
 field public isAcceptState Z -
 field public prediction I -
 field public lexerActionExecutor Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/LexerActionExecutor; -
 field public requiresFullContext Z -
 field public predicates [Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction; -
 method public <init> ()V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATNConfigSet;)V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState$PredPrediction com/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFAState PredPrediction public,static
 field public pred Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext; -
 field public alt I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/SemanticContext;I)V - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator 52 public,super,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/misc/EqualityComparator <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/EqualityComparator<TT;>;
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet 52 public,super java/lang/Object java/util/Set <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Set<TT;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet$SetIterator com/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet SetIterator protected
 field protected,final comparator Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator; Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<-TT;>;
 field protected buckets [[Ljava/lang/Object; [[TT;
 field protected n I -
 field protected currentPrime I -
 field protected threshold I -
 field protected,final initialCapacity I -
 field protected,final initialBucketCapacity I -
 method public <init> ()V - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator;II)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<-TT;>;II)V -
 method public,final getOrAdd (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
 method protected getOrAddImpl (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
 method protected,final getBucket (Ljava/lang/Object;)I (TT;)I -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method protected expand ()V - -
 method public,final add (Ljava/lang/Object;)Z (TT;)Z -
 method public,final size ()I - -
 method public,final isEmpty ()Z - -
 method public,final contains (Ljava/lang/Object;)Z - -
 method public containsFast (Ljava/lang/Object;)Z (TT;)Z -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TT;>; -
 method public toArray ()[Ljava/lang/Object; ()[TT; -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <U:Ljava/lang/Object;>([TU;)[TU; -
 method public,final remove (Ljava/lang/Object;)Z - -
 method public removeFast (Ljava/lang/Object;)Z (TT;)Z -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TT;>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public toString ()Ljava/lang/String; - -
 method protected asElementType (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TT; -
 method protected createBuckets (I)[[Ljava/lang/Object; (I)[[TT; -
 method protected createBucket (I)[Ljava/lang/Object; (I)[TT; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet$SetIterator 52 public,super java/lang/Object java/util/Iterator Ljava/lang/Object;Ljava/util/Iterator<TT;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet$SetIterator com/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet SetIterator protected
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Array2DHashSet;[Ljava/lang/Object;)V ([TT;)V -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TT; -
 method public remove ()V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/DoubleKeyMap 52 public,super java/lang/Object - <Key1:Ljava/lang/Object;Key2:Ljava/lang/Object;Value:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> ()V - -
 method public put (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TKey1;TKey2;TValue;)TValue; -
 method public get (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TKey1;TKey2;)TValue; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/EqualityComparator 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract hashCode (Ljava/lang/Object;)I (TT;)I -
 method public,abstract equals (Ljava/lang/Object;Ljava/lang/Object;)Z (TT;TT;)Z -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap 52 public,super java/lang/Object java/util/Map <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Map<TK;TV;>;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap$Entry com/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap Entry public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field protected,final comparator Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator; Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<-TK;>;
 field protected buckets [Ljava/util/LinkedList; [Ljava/util/LinkedList<Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap$Entry<TK;TV;>;>;
 field protected n I -
 field protected currentPrime I -
 field protected threshold I -
 field protected,final initialCapacity I -
 field protected,final initialBucketCapacity I -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator;)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<-TK;>;)V -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator;II)V (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<-TK;>;II)V -
 method protected getBucket (Ljava/lang/Object;)I (TK;)I -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public putAll (Ljava/util/Map;)V (Ljava/util/Map<+TK;+TV;>;)V -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<TV;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method protected expand ()V - -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public clear ()V - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap$Entry 52 public,super java/lang/Object - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;
 inner com/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap$Entry com/llamalad7/mixinextras/lib/antlr/runtime/misc/FlexibleHashMap Entry public,static
 field public,final key Ljava/lang/Object; TK;
 field public value Ljava/lang/Object; TV;
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;)V (TK;TV;)V -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/IntSet 52 public,interface,abstract java/lang/Object - -
 method public,abstract isNil ()Z - -
 method public,abstract toList ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/Integer;>; -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/IntegerList 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,final add (I)V - -
 method public,final get (I)I - -
 method public,final removeAt (I)I - -
 method public,final isEmpty ()Z - -
 method public,final size ()I - -
 method public,final clear ()V - -
 method public,final toArray ()[I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/IntegerStack 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/misc/IntegerList - -
 method public <init> ()V - -
 method public,final push (I)V - -
 method public,final pop ()I - -
 method public,final peek ()I - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval 52 public,super java/lang/Object - -
 field public,static,final INVALID Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval; -
 field public a I -
 field public b I -
 method public <init> (II)V - -
 method public,static of (II)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public startsBeforeDisjoint (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Z - -
 method public startsAfterDisjoint (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Z - -
 method public disjoint (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Z - -
 method public adjacent (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Z - -
 method public union (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval; - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/misc/IntSet -
 field public,static,final COMPLETE_CHAR_SET Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; -
 field public,static,final EMPTY_SET Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; -
 field protected intervals Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;>;
 field protected readonly Z -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;)V - -
 method public,varargs <init> ([I)V - -
 method public,static of (I)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public,static of (II)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public add (I)V - -
 method public add (II)V - -
 method protected add (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/Interval;)V - -
 method public addAll (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public complement (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public subtract (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public,static subtract (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public or (Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntSet;)Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/IntervalSet; - -
 method public contains (I)Z - -
 method public isNil ()Z - -
 method public getMinElement ()I - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public toString (Z)Ljava/lang/String; - -
 method public toString (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary;)Ljava/lang/String; - -
 method protected elementName (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary;I)Ljava/lang/String; - -
 method public size ()I - -
 method public toList ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/Integer;>; -
 method public remove (I)V - -
 method public setReadonly (Z)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/MurmurHash 52 public,final,super java/lang/Object - -
 method public,static initialize ()I - -
 method public,static initialize (I)I - -
 method public,static update (II)I - -
 method public,static update (ILjava/lang/Object;)I - -
 method public,static finish (II)I - -
 method public,static hashCode ([Ljava/lang/Object;I)I <T:Ljava/lang/Object;>([TT;I)I -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/ObjectEqualityComparator 52 public,final,super com/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator - Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/AbstractEqualityComparator<Ljava/lang/Object;>;
 field public,static,final INSTANCE Lcom/llamalad7/mixinextras/lib/antlr/runtime/misc/ObjectEqualityComparator; -
 method public <init> ()V - -
 method public hashCode (Ljava/lang/Object;)I - -
 method public equals (Ljava/lang/Object;Ljava/lang/Object;)Z - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/Pair 52 public,super java/lang/Object java/io/Serializable <A:Ljava/lang/Object;B:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;
 field public,final a Ljava/lang/Object; TA;
 field public,final b Ljava/lang/Object; TB;
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;)V (TA;TB;)V -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/misc/Utils 52 public,super java/lang/Object - -
 method public,static join (Ljava/util/Iterator;Ljava/lang/String;)Ljava/lang/String; <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Ljava/lang/String;)Ljava/lang/String; -
 method public,static escapeWhitespace (Ljava/lang/String;Z)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNode 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNodeImpl 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNodeImpl com/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNode -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree 52 public,interface,abstract java/lang/Object - -
 method public,abstract setParent (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)V - -
 method public,abstract getText ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener 52 public,interface,abstract java/lang/Object - -
 method public,abstract visitTerminal (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode;)V - -
 method public,abstract visitErrorNode (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ErrorNode;)V - -
 method public,abstract enterEveryRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
 method public,abstract exitEveryRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;)V - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/tree/RuleNode 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree -
 method public,abstract getSymbol ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
in 61
class com/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNodeImpl 52 public,super java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/tree/TerminalNode -
 field public symbol Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public parent Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTree; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;)V - -
 method public getSymbol ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; - -
 method public setParent (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;)V - -
 method public getText ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/lib/apache/commons/ArrayUtils 50 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field public,static,final EMPTY_OBJECT_ARRAY [Ljava/lang/Object; -
 field public,static,final EMPTY_CLASS_ARRAY [Ljava/lang/Class; [Ljava/lang/Class<*>;
 field public,static,final EMPTY_STRING_ARRAY [Ljava/lang/String; -
 field public,static,final EMPTY_LONG_ARRAY [J -
 field public,static,final EMPTY_LONG_OBJECT_ARRAY [Ljava/lang/Long; -
 field public,static,final EMPTY_INT_ARRAY [I -
 field public,static,final EMPTY_INTEGER_OBJECT_ARRAY [Ljava/lang/Integer; -
 field public,static,final EMPTY_SHORT_ARRAY [S -
 field public,static,final EMPTY_SHORT_OBJECT_ARRAY [Ljava/lang/Short; -
 field public,static,final EMPTY_BYTE_ARRAY [B -
 field public,static,final EMPTY_BYTE_OBJECT_ARRAY [Ljava/lang/Byte; -
 field public,static,final EMPTY_DOUBLE_ARRAY [D -
 field public,static,final EMPTY_DOUBLE_OBJECT_ARRAY [Ljava/lang/Double; -
 field public,static,final EMPTY_FLOAT_ARRAY [F -
 field public,static,final EMPTY_FLOAT_OBJECT_ARRAY [Ljava/lang/Float; -
 field public,static,final EMPTY_BOOLEAN_ARRAY [Z -
 field public,static,final EMPTY_BOOLEAN_OBJECT_ARRAY [Ljava/lang/Boolean; -
 field public,static,final EMPTY_CHAR_ARRAY [C -
 field public,static,final EMPTY_CHARACTER_OBJECT_ARRAY [Ljava/lang/Character; -
 method public,static clone ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public,static clone ([I)[I - -
 method public,static subarray ([Ljava/lang/Object;II)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;II)[TT; -
 method public,static getLength (Ljava/lang/Object;)I - -
 method public,static,varargs addAll ([Ljava/lang/Object;[Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;[TT;)[TT; -
 method public,static,varargs addAll ([I[I)[I - -
 method public,static add ([Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;TT;)[TT; -
 method public,static add ([Ljava/lang/Object;ILjava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;ITT;)[TT; -
 method public,static remove ([Ljava/lang/Object;I)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;I)[TT; -
 method public,static remove ([II)[I - -
in 22
class com/llamalad7/mixinextras/lib/apache/commons/ClassUtils 50 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field public,static,final PACKAGE_SEPARATOR Ljava/lang/String; -
 field public,static,final INNER_CLASS_SEPARATOR Ljava/lang/String; -
 method public,static getAllInterfaces (Ljava/lang/Class;)Ljava/util/List; (Ljava/lang/Class<*>;)Ljava/util/List<Ljava/lang/Class<*>;>; -
in 22
class com/llamalad7/mixinextras/lib/apache/commons/ObjectUtils 50 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/apache/commons/ObjectUtils$Null com/llamalad7/mixinextras/lib/apache/commons/ObjectUtils Null public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field public,static,final NULL Lcom/llamalad7/mixinextras/lib/apache/commons/ObjectUtils$Null; -
 method public,static,deprecated equals (Ljava/lang/Object;Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/lib/apache/commons/ObjectUtils$Null 50 public,super java/lang/Object java/io/Serializable -
 inner com/llamalad7/mixinextras/lib/apache/commons/ObjectUtils$Null com/llamalad7/mixinextras/lib/apache/commons/ObjectUtils Null public,static
in 22
class com/llamalad7/mixinextras/lib/apache/commons/StringUtils 50 public,super java/lang/Object - -
 inner java/text/Normalizer$Form java/text/Normalizer Form public,static,final,enum
 method public,static isEmpty (Ljava/lang/CharSequence;)Z - -
 method public,static substringBefore (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static substringAfter (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static substringBeforeLast (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static substringAfterLast (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static removeStart (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static removeEnd (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static replaceOnce (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static replace (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String; - -
 method public,static repeat (CI)Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder 50 public,super java/lang/Object - Ljava/lang/Object;
 method public <init> ()V - -
 method public append (Ljava/lang/Object;Ljava/lang/Object;)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator;)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/Comparator<*>;)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; -
 method public append (JJ)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (II)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (SS)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (CC)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (BB)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (DD)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (FF)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append (ZZ)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([Ljava/lang/Object;[Ljava/lang/Object;Ljava/util/Comparator;)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; ([Ljava/lang/Object;[Ljava/lang/Object;Ljava/util/Comparator<*>;)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; -
 method public append ([J[J)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([I[I)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([S[S)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([C[C)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([B[B)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([D[D)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([F[F)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public append ([Z[Z)Lcom/llamalad7/mixinextras/lib/apache/commons/builder/CompareToBuilder; - -
 method public toComparison ()I - -
in 63
class com/llamalad7/mixinextras/lib/apache/commons/mutable/MutableObject 50 public,super java/lang/Object java/io/Serializable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;
 method public <init> ()V - -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public setValue (Ljava/lang/Object;)V (TT;)V -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/lib/apache/commons/tuple/ImmutablePair 50 public,final,super com/llamalad7/mixinextras/lib/apache/commons/tuple/Pair - <L:Ljava/lang/Object;R:Ljava/lang/Object;>Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair<TL;TR;>;
 field public,final left Ljava/lang/Object; TL;
 field public,final right Ljava/lang/Object; TR;
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;)V (TL;TR;)V -
 method public getLeft ()Ljava/lang/Object; ()TL; -
 method public getRight ()Ljava/lang/Object; ()TR; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; (TR;)TR; -
in 22
class com/llamalad7/mixinextras/lib/apache/commons/tuple/Pair 50 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Comparable,java/util/Map$Entry <L:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;Ljava/lang/Comparable<Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair<TL;TR;>;>;Ljava/util/Map$Entry<TL;TR;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;)Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair; <L:Ljava/lang/Object;R:Ljava/lang/Object;>(TL;TR;)Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair<TL;TR;>; -
 method public,abstract getLeft ()Ljava/lang/Object; ()TL; -
 method public,abstract getRight ()Ljava/lang/Object; ()TR; -
 method public,final getKey ()Ljava/lang/Object; ()TL; -
 method public getValue ()Ljava/lang/Object; ()TR; -
 method public compareTo (Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair;)I (Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair<TL;TR;>;)I -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionLexer 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/Lexer - -
 field protected,static,final _decisionToDFA [Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA; -
 field protected,static,final _sharedContextCache Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache; -
 field public,static channelNames [Ljava/lang/String; -
 field public,static modeNames [Ljava/lang/String; -
 field public,static,final ruleNames [Ljava/lang/String; -
 field public,static,final VOCABULARY Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary; -
 field public,static,final,deprecated tokenNames [Ljava/lang/String; -
 field public,static,final _ATN Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; -
 method public,deprecated getTokenNames ()[Ljava/lang/String; - -
 method public getVocabulary ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary; - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/CharStream;)V - -
 method public getRuleNames ()[Ljava/lang/String; - -
 method public getATN ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; - -
 method public action (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;II)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/Parser - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser RootContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayStoreStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayStoreStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ReturnStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ReturnStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThrowStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThrowStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CapturingExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CapturingExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThisExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThisExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IntLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IntLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$DecimalLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser DecimalLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoolLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoolLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NullExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NullExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StringLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StringLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ClassConstantExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ClassConstantExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$SuperCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser SuperCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StaticMethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StaticMethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$FreeMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser FreeMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ConstructorReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ConstructorReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$UnaryExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser UnaryExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstantiationExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstantiationExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NonEmptyArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NewArrayExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NewArrayExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CastExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CastExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ParenthesizedExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ParenthesizedExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MultiplicativeExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MultiplicativeExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$AdditiveExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser AdditiveExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ShiftExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ShiftExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ComparisonExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ComparisonExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$EqualityExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser EqualityExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseAndExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseAndExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseXorExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseXorExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseOrExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseOrExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoundMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoundMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstanceofExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstanceofExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierNameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardNameContext public,static
 field protected,static,final _decisionToDFA [Lcom/llamalad7/mixinextras/lib/antlr/runtime/dfa/DFA; -
 field protected,static,final _sharedContextCache Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/PredictionContextCache; -
 field public,static,final ruleNames [Ljava/lang/String; -
 field public,static,final VOCABULARY Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary; -
 field public,static,final,deprecated tokenNames [Ljava/lang/String; -
 field public,static,final _ATN Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; -
 method public,deprecated getTokenNames ()[Ljava/lang/String; - -
 method public getVocabulary ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/Vocabulary; - -
 method public getRuleNames ()[Ljava/lang/String; - -
 method public getATN ()Lcom/llamalad7/mixinextras/lib/antlr/runtime/atn/ATN; - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/TokenStream;)V - -
 method public,final root ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,final statement ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,final name ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,final nameWithDims ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,final arguments ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public,final nonEmptyArguments ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext; - com/llamalad7/mixinextras/lib/antlr/runtime/RecognitionException
 method public sempred (Lcom/llamalad7/mixinextras/lib/antlr/runtime/RuleContext;II)Z - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$AdditiveExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$AdditiveExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser AdditiveExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public op Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NonEmptyArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 method public nonEmptyArguments ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext; - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public getRuleIndex ()I - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayAccessExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public arr Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public index Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayLitExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NonEmptyArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public elementType Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext; -
 field public values Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayStoreStatementContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayStoreStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayStoreStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 field public arr Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public index Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public value Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseAndExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseAndExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseAndExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseOrExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseOrExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseOrExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseXorExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseXorExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseXorExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoolLitExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoolLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoolLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public lit Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoundMethodReferenceExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoundMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoundMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 field public receiver Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public memberName Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CapturingExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CapturingExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CapturingExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public expr Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CastExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CastExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CastExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public type Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext; -
 field public expr Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ClassConstantExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ClassConstantExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ClassConstantExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public type Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ComparisonExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ComparisonExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ComparisonExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public op Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ConstructorReferenceExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ConstructorReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ConstructorReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public type Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$DecimalLitExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$DecimalLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser DecimalLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public lit Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$EqualityExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$EqualityExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser EqualityExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public op Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public getRuleIndex ()I - -
 method public <init> ()V - -
 method public copyFrom (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionStatementContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 method public expression ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$FreeMethodReferenceExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$FreeMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser FreeMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public memberName Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierAssignmentStatementContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 field public identifier Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 field public value Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public id Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierNameContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierNameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstanceofExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstanceofExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstanceofExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 field public expr Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public type Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstantiationExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstantiationExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstantiationExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public type Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 field public args Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IntLitExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IntLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IntLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public lit Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAccessExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 field public receiver Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public memberName Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAssignmentStatementContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 field public receiver Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public memberName Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 field public value Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MethodCallExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 field public receiver Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public memberName Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 field public args Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MultiplicativeExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MultiplicativeExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MultiplicativeExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public op Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public getRuleIndex ()I - -
 method public <init> ()V - -
 method public copyFrom (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 field public LeftBracket Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public dims Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;>;
 method public name ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public getRuleIndex ()I - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NewArrayExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NewArrayExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NewArrayExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public innerType Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 field public expression Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public dims Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;>;
 field public LeftBracket Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public blankDims Ljava/util/List; Ljava/util/List<Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token;>;
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NonEmptyArgumentsContext public,static
 method public expression ()Ljava/util/List; ()Ljava/util/List<Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;>; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public getRuleIndex ()I - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NullExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NullExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NullExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public lit Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ParenthesizedExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ParenthesizedExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ParenthesizedExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public expr Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ReturnStatementContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ReturnStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ReturnStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 field public value Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser RootContext public,static
 method public statement ()Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext; - -
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public getRuleIndex ()I - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ShiftExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ShiftExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ShiftExpressionContext public,static
 field public left Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 field public op Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public right Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext 52 public,super com/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/antlr/runtime/ParserRuleContext;I)V - -
 method public getRuleIndex ()I - -
 method public <init> ()V - -
 method public copyFrom (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StaticMethodCallExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StaticMethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StaticMethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public memberName Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 field public args Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StringLitExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StringLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StringLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public lit Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$SuperCallExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$SuperCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser SuperCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 field public memberName Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext; -
 field public args Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThisExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThisExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThisExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThrowStatementContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThrowStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThrowStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StatementContext public,static
 field public value Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StatementContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$UnaryExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$UnaryExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser UnaryExpressionContext public,static
 field public op Lcom/llamalad7/mixinextras/lib/antlr/runtime/Token; -
 field public expr Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext; -
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardExpressionContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionContext public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardNameContext 52 public,super com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext - -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardNameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameContext public,static
 method public <init> (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameContext;)V - -
 method public enterRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
 method public exitRule (Lcom/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener;)V - -
in 61
class com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParserListener 52 public,interface,abstract java/lang/Object com/llamalad7/mixinextras/lib/antlr/runtime/tree/ParseTreeListener -
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser RootContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayStoreStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayStoreStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierAssignmentStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierAssignmentStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ReturnStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ReturnStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThrowStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThrowStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionStatementContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ExpressionStatementContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseXorExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseXorExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ClassConstantExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ClassConstantExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StaticMethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StaticMethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoolLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoolLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$UnaryExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser UnaryExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$FreeMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser FreeMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ConstructorReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ConstructorReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstantiationExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstantiationExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IntLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IntLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThisExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ThisExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$DecimalLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser DecimalLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MethodCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MethodCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstanceofExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser InstanceofExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StringLitExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser StringLitExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$EqualityExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser EqualityExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MultiplicativeExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MultiplicativeExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseOrExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseOrExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ParenthesizedExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ParenthesizedExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$AdditiveExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser AdditiveExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser MemberAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoundMethodReferenceExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BoundMethodReferenceExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ShiftExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ShiftExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CapturingExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CapturingExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NullExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NullExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseAndExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser BitwiseAndExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ComparisonExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ComparisonExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$SuperCallExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser SuperCallExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CastExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser CastExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NewArrayExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NewArrayExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayAccessExpressionContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArrayAccessExpressionContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser IdentifierNameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardNameContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser WildcardNameContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NameWithDimsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser ArgumentsContext public,static
 inner com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext com/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser NonEmptyArgumentsContext public,static
 method public,abstract enterRoot (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext;)V - -
 method public,abstract exitRoot (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$RootContext;)V - -
 method public,abstract enterMemberAssignmentStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAssignmentStatementContext;)V - -
 method public,abstract exitMemberAssignmentStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAssignmentStatementContext;)V - -
 method public,abstract enterArrayStoreStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayStoreStatementContext;)V - -
 method public,abstract exitArrayStoreStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayStoreStatementContext;)V - -
 method public,abstract enterIdentifierAssignmentStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierAssignmentStatementContext;)V - -
 method public,abstract exitIdentifierAssignmentStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierAssignmentStatementContext;)V - -
 method public,abstract enterReturnStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ReturnStatementContext;)V - -
 method public,abstract exitReturnStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ReturnStatementContext;)V - -
 method public,abstract enterThrowStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThrowStatementContext;)V - -
 method public,abstract exitThrowStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThrowStatementContext;)V - -
 method public,abstract enterExpressionStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionStatementContext;)V - -
 method public,abstract exitExpressionStatement (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ExpressionStatementContext;)V - -
 method public,abstract enterBitwiseXorExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseXorExpressionContext;)V - -
 method public,abstract exitBitwiseXorExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseXorExpressionContext;)V - -
 method public,abstract enterClassConstantExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ClassConstantExpressionContext;)V - -
 method public,abstract exitClassConstantExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ClassConstantExpressionContext;)V - -
 method public,abstract enterStaticMethodCallExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StaticMethodCallExpressionContext;)V - -
 method public,abstract exitStaticMethodCallExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StaticMethodCallExpressionContext;)V - -
 method public,abstract enterBoolLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoolLitExpressionContext;)V - -
 method public,abstract exitBoolLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoolLitExpressionContext;)V - -
 method public,abstract enterUnaryExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$UnaryExpressionContext;)V - -
 method public,abstract exitUnaryExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$UnaryExpressionContext;)V - -
 method public,abstract enterFreeMethodReferenceExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$FreeMethodReferenceExpressionContext;)V - -
 method public,abstract exitFreeMethodReferenceExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$FreeMethodReferenceExpressionContext;)V - -
 method public,abstract enterConstructorReferenceExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ConstructorReferenceExpressionContext;)V - -
 method public,abstract exitConstructorReferenceExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ConstructorReferenceExpressionContext;)V - -
 method public,abstract enterInstantiationExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstantiationExpressionContext;)V - -
 method public,abstract exitInstantiationExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstantiationExpressionContext;)V - -
 method public,abstract enterIntLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IntLitExpressionContext;)V - -
 method public,abstract exitIntLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IntLitExpressionContext;)V - -
 method public,abstract enterThisExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThisExpressionContext;)V - -
 method public,abstract exitThisExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ThisExpressionContext;)V - -
 method public,abstract enterDecimalLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$DecimalLitExpressionContext;)V - -
 method public,abstract exitDecimalLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$DecimalLitExpressionContext;)V - -
 method public,abstract enterMethodCallExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MethodCallExpressionContext;)V - -
 method public,abstract exitMethodCallExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MethodCallExpressionContext;)V - -
 method public,abstract enterInstanceofExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstanceofExpressionContext;)V - -
 method public,abstract exitInstanceofExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$InstanceofExpressionContext;)V - -
 method public,abstract enterWildcardExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardExpressionContext;)V - -
 method public,abstract exitWildcardExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardExpressionContext;)V - -
 method public,abstract enterArrayLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayLitExpressionContext;)V - -
 method public,abstract exitArrayLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayLitExpressionContext;)V - -
 method public,abstract enterStringLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StringLitExpressionContext;)V - -
 method public,abstract exitStringLitExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$StringLitExpressionContext;)V - -
 method public,abstract enterEqualityExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$EqualityExpressionContext;)V - -
 method public,abstract exitEqualityExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$EqualityExpressionContext;)V - -
 method public,abstract enterMultiplicativeExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MultiplicativeExpressionContext;)V - -
 method public,abstract exitMultiplicativeExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MultiplicativeExpressionContext;)V - -
 method public,abstract enterBitwiseOrExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseOrExpressionContext;)V - -
 method public,abstract exitBitwiseOrExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseOrExpressionContext;)V - -
 method public,abstract enterParenthesizedExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ParenthesizedExpressionContext;)V - -
 method public,abstract exitParenthesizedExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ParenthesizedExpressionContext;)V - -
 method public,abstract enterAdditiveExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$AdditiveExpressionContext;)V - -
 method public,abstract exitAdditiveExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$AdditiveExpressionContext;)V - -
 method public,abstract enterMemberAccessExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAccessExpressionContext;)V - -
 method public,abstract exitMemberAccessExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$MemberAccessExpressionContext;)V - -
 method public,abstract enterBoundMethodReferenceExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoundMethodReferenceExpressionContext;)V - -
 method public,abstract exitBoundMethodReferenceExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BoundMethodReferenceExpressionContext;)V - -
 method public,abstract enterShiftExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ShiftExpressionContext;)V - -
 method public,abstract exitShiftExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ShiftExpressionContext;)V - -
 method public,abstract enterCapturingExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CapturingExpressionContext;)V - -
 method public,abstract exitCapturingExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CapturingExpressionContext;)V - -
 method public,abstract enterNullExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NullExpressionContext;)V - -
 method public,abstract exitNullExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NullExpressionContext;)V - -
 method public,abstract enterIdentifierExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierExpressionContext;)V - -
 method public,abstract exitIdentifierExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierExpressionContext;)V - -
 method public,abstract enterBitwiseAndExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseAndExpressionContext;)V - -
 method public,abstract exitBitwiseAndExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$BitwiseAndExpressionContext;)V - -
 method public,abstract enterComparisonExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ComparisonExpressionContext;)V - -
 method public,abstract exitComparisonExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ComparisonExpressionContext;)V - -
 method public,abstract enterSuperCallExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$SuperCallExpressionContext;)V - -
 method public,abstract exitSuperCallExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$SuperCallExpressionContext;)V - -
 method public,abstract enterCastExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CastExpressionContext;)V - -
 method public,abstract exitCastExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$CastExpressionContext;)V - -
 method public,abstract enterNewArrayExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NewArrayExpressionContext;)V - -
 method public,abstract exitNewArrayExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NewArrayExpressionContext;)V - -
 method public,abstract enterArrayAccessExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayAccessExpressionContext;)V - -
 method public,abstract exitArrayAccessExpression (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArrayAccessExpressionContext;)V - -
 method public,abstract enterIdentifierName (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierNameContext;)V - -
 method public,abstract exitIdentifierName (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$IdentifierNameContext;)V - -
 method public,abstract enterWildcardName (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardNameContext;)V - -
 method public,abstract exitWildcardName (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$WildcardNameContext;)V - -
 method public,abstract enterNameWithDims (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext;)V - -
 method public,abstract exitNameWithDims (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NameWithDimsContext;)V - -
 method public,abstract enterArguments (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext;)V - -
 method public,abstract exitArguments (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$ArgumentsContext;)V - -
 method public,abstract enterNonEmptyArguments (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext;)V - -
 method public,abstract exitNonEmptyArguments (Lcom/llamalad7/mixinextras/lib/grammar/expressions/ExpressionParser$NonEmptyArgumentsContext;)V - -
in 61
class com/llamalad7/mixinextras/lib/gson/Strictness 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/lib/gson/Strictness;>;
 field public,static,final,enum LENIENT Lcom/llamalad7/mixinextras/lib/gson/Strictness; -
 field public,static,final,enum LEGACY_STRICT Lcom/llamalad7/mixinextras/lib/gson/Strictness; -
 field public,static,final,enum STRICT Lcom/llamalad7/mixinextras/lib/gson/Strictness; -
in 61
class com/llamalad7/mixinextras/lib/gson/annotations/SerializedName 51 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract value ()Ljava/lang/String; - -
 method public,abstract alternate ()[Ljava/lang/String; - - []
in 61
class com/llamalad7/mixinextras/lib/gson/internal/JsonReaderInternalAccess 51 public,super,abstract java/lang/Object - -
 field public,static,volatile INSTANCE Lcom/llamalad7/mixinextras/lib/gson/internal/JsonReaderInternalAccess; -
 method public <init> ()V - -
in 61
class com/llamalad7/mixinextras/lib/gson/internal/TroubleshootingGuide 51 public,super java/lang/Object - -
 method public,static createUrl (Ljava/lang/String;)Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/gson/stream/JsonReader 51 public,super java/lang/Object java/io/Closeable -
 method public <init> (Ljava/io/Reader;)V - -
 method public,final setStrictness (Lcom/llamalad7/mixinextras/lib/gson/Strictness;)V - -
 method public beginObject ()V - java/io/IOException
 method public endObject ()V - java/io/IOException
 method public hasNext ()Z - java/io/IOException
 method public peek ()Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; - java/io/IOException
 method public nextName ()Ljava/lang/String; - java/io/IOException
 method public nextString ()Ljava/lang/String; - java/io/IOException
 method public close ()V - java/io/IOException
 method public skipValue ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/gson/stream/JsonToken 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken;>;
 field public,static,final,enum BEGIN_ARRAY Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum END_ARRAY Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum BEGIN_OBJECT Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum END_OBJECT Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum NAME Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum STRING Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum NUMBER Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum BOOLEAN Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum NULL Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
 field public,static,final,enum END_DOCUMENT Lcom/llamalad7/mixinextras/lib/gson/stream/JsonToken; -
in 61
class com/llamalad7/mixinextras/lib/gson/stream/MalformedJsonException 51 public,final,super java/io/IOException - -
 method public <init> (Ljava/lang/String;)V - -
in 61
class com/llamalad7/mixinextras/lib/semver/ParseException 52 public,super java/lang/RuntimeException - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lcom/llamalad7/mixinextras/lib/semver/UnexpectedCharacterException;)V - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/semver/UnexpectedCharacterException 52 public,super com/llamalad7/mixinextras/lib/semver/ParseException - -
 inner com/llamalad7/mixinextras/lib/semver/VersionParser$CharType com/llamalad7/mixinextras/lib/semver/VersionParser CharType static,abstract,enum
 inner com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType com/llamalad7/mixinextras/lib/semver/util/Stream ElementType public,static,interface,abstract
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/semver/Version 52 public,super java/lang/Object java/io/Serializable,java/lang/Comparable Ljava/lang/Object;Ljava/io/Serializable;Ljava/lang/Comparable<Lcom/llamalad7/mixinextras/lib/semver/Version;>;
 inner com/llamalad7/mixinextras/lib/semver/Version$Validators com/llamalad7/mixinextras/lib/semver/Version Validators static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INCREMENT_ORDER Ljava/util/Comparator; Ljava/util/Comparator<Lcom/llamalad7/mixinextras/lib/semver/Version;>;
 field public,static,final PRECEDENCE_ORDER Ljava/util/Comparator; Ljava/util/Comparator<Lcom/llamalad7/mixinextras/lib/semver/Version;>;
 field public,static,final,deprecated BUILD_AWARE_ORDER Ljava/util/Comparator; Ljava/util/Comparator<Lcom/llamalad7/mixinextras/lib/semver/Version;>;
 method public,static parse (Ljava/lang/String;)Lcom/llamalad7/mixinextras/lib/semver/Version; - -
 method public,static parse (Ljava/lang/String;Z)Lcom/llamalad7/mixinextras/lib/semver/Version; - -
 method public,static tryParse (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcom/llamalad7/mixinextras/lib/semver/Version;>; -
 method public,static tryParse (Ljava/lang/String;Z)Ljava/util/Optional; (Ljava/lang/String;Z)Ljava/util/Optional<Lcom/llamalad7/mixinextras/lib/semver/Version;>; -
 method public preReleaseVersion ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/String;>; -
 method public buildMetadata ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/String;>; -
 method public isHigherThan (Lcom/llamalad7/mixinextras/lib/semver/Version;)Z - -
 method public compareTo (Lcom/llamalad7/mixinextras/lib/semver/Version;)I - -
 method public compareToIgnoreBuildMetadata (Lcom/llamalad7/mixinextras/lib/semver/Version;)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 61
class com/llamalad7/mixinextras/lib/semver/Version$Validators 52 super java/lang/Object - -
 inner com/llamalad7/mixinextras/lib/semver/Version$Validators com/llamalad7/mixinextras/lib/semver/Version Validators static
in 61
class com/llamalad7/mixinextras/lib/semver/VersionParser 52 super java/lang/Object - Ljava/lang/Object;
 inner com/llamalad7/mixinextras/lib/semver/VersionParser$CharType com/llamalad7/mixinextras/lib/semver/VersionParser CharType static,abstract,enum
 inner com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType com/llamalad7/mixinextras/lib/semver/util/Stream ElementType public,static,interface,abstract
in 61
class com/llamalad7/mixinextras/lib/semver/VersionParser$CharType 52 super,abstract,enum java/lang/Enum com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType Ljava/lang/Enum<Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType;>;Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType<Ljava/lang/Character;>;
 inner com/llamalad7/mixinextras/lib/semver/VersionParser$CharType com/llamalad7/mixinextras/lib/semver/VersionParser CharType static,abstract,enum
 inner com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType com/llamalad7/mixinextras/lib/semver/util/Stream ElementType public,static,interface,abstract
 field public,static,final,enum DIGIT Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; -
 field public,static,final,enum LETTER Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; -
 field public,static,final,enum DOT Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; -
 field public,static,final,enum HYPHEN Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; -
 field public,static,final,enum PLUS Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; -
 field public,static,final,enum EOI Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; -
 field public,static,final,enum ILLEGAL Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; -
 method public,static values ()[Lcom/llamalad7/mixinextras/lib/semver/VersionParser$CharType; - -
in 61
class com/llamalad7/mixinextras/lib/semver/expr/Expression 52 public,interface,abstract java/lang/Object java/util/function/Predicate Ljava/lang/Object;Ljava/util/function/Predicate<Lcom/llamalad7/mixinextras/lib/semver/Version;>;
 method public,abstract interpret (Lcom/llamalad7/mixinextras/lib/semver/Version;)Z - -
 method public test (Lcom/llamalad7/mixinextras/lib/semver/Version;)Z - -
in 61
class com/llamalad7/mixinextras/lib/semver/util/Stream 52 public,super java/lang/Object java/lang/Iterable <E:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<TE;>;
 inner com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType com/llamalad7/mixinextras/lib/semver/util/Stream ElementType public,static,interface,abstract
 method public <init> ([Ljava/lang/Object;)V ([TE;)V -
 method public consume ()Ljava/lang/Object; ()TE; -
 method public,final,varargs consume ([Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType;)Ljava/lang/Object; <T::Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType<TE;>;>([TT;)TE; -
 method public lookahead (I)Ljava/lang/Object; (I)TE; -
 method public currentOffset ()I - -
 method public,final,varargs positiveLookahead ([Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType;)Z <T::Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType<TE;>;>([TT;)Z -
 method public,final,varargs positiveLookaheadBefore (Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType;[Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType;)Z <T::Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType<TE;>;>(Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType<TE;>;[TT;)Z -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TE;>; -
in 61
class com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType 52 public,interface,abstract java/lang/Object - <E:Ljava/lang/Object;>Ljava/lang/Object;
 inner com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType com/llamalad7/mixinextras/lib/semver/util/Stream ElementType public,static,interface,abstract
 method public,abstract isMatchedBy (Ljava/lang/Object;)Z (TE;)Z -
in 61
class com/llamalad7/mixinextras/lib/semver/util/UnexpectedElementException 52 public,super java/lang/RuntimeException - -
 inner com/llamalad7/mixinextras/lib/semver/util/Stream$ElementType com/llamalad7/mixinextras/lib/semver/util/Stream ElementType public,static,interface,abstract
 method public getUnexpectedElement ()Ljava/lang/Object; - -
 method public getPosition ()I - -
 method public getExpectedElementTypes ()[Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType; ()[Lcom/llamalad7/mixinextras/lib/semver/util/Stream$ElementType<*>; -
 method public toString ()Ljava/lang/String; - -
in 66
class com/llamalad7/mixinextras/platform/fabric/MixinExtrasConfigPlugin 52 public,super java/lang/Object org/spongepowered/asm/mixin/extensibility/IMixinConfigPlugin -
 method public <init> ()V - -
 method public onLoad (Ljava/lang/String;)V - -
 method public getRefMapperConfig ()Ljava/lang/String; - -
 method public shouldApplyMixin (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public acceptTargets (Ljava/util/Set;Ljava/util/Set;)V (Ljava/util/Set<Ljava/lang/String;>;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public getMixins ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public preApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)V - -
 method public postApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)V - -
in 46
class com/llamalad7/mixinextras/platform/neoforge/MixinExtrasConfigPlugin 61 public,super java/lang/Object org/spongepowered/asm/mixin/extensibility/IMixinConfigPlugin -
 method public <init> ()V - -
 method public onLoad (Ljava/lang/String;)V - -
 method public getRefMapperConfig ()Ljava/lang/String; - -
 method public shouldApplyMixin (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public acceptTargets (Ljava/util/Set;Ljava/util/Set;)V (Ljava/util/Set<Ljava/lang/String;>;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public getMixins ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public preApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)V - -
 method public postApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)V - -
in 22
class com/llamalad7/mixinextras/service/MixinExtrasService 52 public,interface,abstract java/lang/Object - -
 method public,abstract getVersion ()I - -
 method public,abstract shouldReplace (Ljava/lang/Object;)Z - -
 method public,abstract takeControlFrom (Ljava/lang/Object;)V - -
 method public,abstract concedeTo (Ljava/lang/Object;Z)V - -
 method public,abstract offerPackage (ILjava/lang/String;)V - -
 method public,abstract offerExtension (ILorg/spongepowered/asm/mixin/transformer/ext/IExtension;)V - -
 method public,abstract offerInjector (ILjava/lang/Class;)V (ILjava/lang/Class<+Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;>;)V -
 method public,abstract initialize ()V - -
 method public,static setup ()V - -
 method public,static getFrom (Ljava/lang/Object;)Lcom/llamalad7/mixinextras/service/MixinExtrasService; - -
 method public,static getInstance ()Lcom/llamalad7/mixinextras/service/MixinExtrasServiceImpl; - -
in 22
class com/llamalad7/mixinextras/service/MixinExtrasServiceImpl 52 public,super java/lang/Object com/llamalad7/mixinextras/service/MixinExtrasService -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getVersion ()I - -
 method public shouldReplace (Ljava/lang/Object;)Z - -
 method public takeControlFrom (Ljava/lang/Object;)V - -
 method public concedeTo (Ljava/lang/Object;Z)V - -
 method public offerPackage (ILjava/lang/String;)V - -
 method public offerExtension (ILorg/spongepowered/asm/mixin/transformer/ext/IExtension;)V - -
 method public offerInjector (ILjava/lang/Class;)V (ILjava/lang/Class<+Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;>;)V -
 method public toString ()Ljava/lang/String; - -
 method public initialize ()V - -
 method public changePackage (Ljava/lang/Class;Lorg/objectweb/asm/Type;Ljava/lang/Class;)Lorg/objectweb/asm/Type; (Ljava/lang/Class<*>;Lorg/objectweb/asm/Type;Ljava/lang/Class<*>;)Lorg/objectweb/asm/Type; -
 method public getAllClassNames (Ljava/lang/String;)Ljava/util/Set; (Ljava/lang/String;)Ljava/util/Set<Ljava/lang/String;>; -
 method public getAllClassNamesAtLeast (Ljava/lang/String;Lcom/llamalad7/mixinextras/service/MixinExtrasVersion;)Ljava/util/Set; (Ljava/lang/String;Lcom/llamalad7/mixinextras/service/MixinExtrasVersion;)Ljava/util/Set<Ljava/lang/String;>; -
 method public isClassOwned (Ljava/lang/String;)Z - -
in 22
class com/llamalad7/mixinextras/service/MixinExtrasVersion 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/service/MixinExtrasVersion;>;
 field public,static,final,enum V0_2_0_BETA_1 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_2 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_3 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_4 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_5 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_6 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_7 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_8 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_2_0_BETA_9 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_3_4 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final,enum V0_3_5 Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 field public,static,final LATEST Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; -
 method public,static values ()[Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/service/MixinExtrasVersion; - -
 method public toString ()Ljava/lang/String; - -
 method public getNumber ()I - -
in 22
class com/llamalad7/mixinextras/service/ServiceInitializationExtension 52 super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 method public <init> (Lcom/llamalad7/mixinextras/service/MixinExtrasService;)V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class com/llamalad7/mixinextras/service/Versioned 52 super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
in 65
class com/llamalad7/mixinextras/sugar/Cancellable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 22
class com/llamalad7/mixinextras/sugar/Local 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract print ()Z - - Z0
 method public,abstract ordinal ()I - - I-1
 method public,abstract index ()I - - I-1
 method public,abstract name ()[Ljava/lang/String; - - []
 method public,abstract argsOnly ()Z - - Z0
in 22
class com/llamalad7/mixinextras/sugar/Share 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/sugar/SugarBridge 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 65
class com/llamalad7/mixinextras/sugar/impl/CancellableSugarApplicator 52 super com/llamalad7/mixinextras/sugar/impl/SugarApplicator - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 22
class com/llamalad7/mixinextras/sugar/impl/LocalSugarApplicator 52 super com/llamalad7/mixinextras/sugar/impl/SugarApplicator - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 inner org/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable org/spongepowered/asm/util/PrettyPrinter IPrettyPrintable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 65
class com/llamalad7/mixinextras/sugar/impl/ShareInfo 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/sugar/impl/ShareInfo$ShareId com/llamalad7/mixinextras/sugar/impl/ShareInfo ShareId private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getLvtIndex ()I - -
 method public setLvtIndex (I)V - -
 method public getShareType ()Lcom/llamalad7/mixinextras/sugar/impl/ShareType; - -
 method public addToLvt (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method public initialize ()Lorg/objectweb/asm/tree/InsnList; - -
 method public load ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public stripInitializerFrom (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public,static getOrCreate (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AnnotationNode;Lorg/objectweb/asm/Type;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lcom/llamalad7/mixinextras/injector/StackExtension;)Lcom/llamalad7/mixinextras/sugar/impl/ShareInfo; - -
in 65
class com/llamalad7/mixinextras/sugar/impl/ShareInfo$ShareId 52 super java/lang/Object - -
 inner com/llamalad7/mixinextras/sugar/impl/ShareInfo$ShareId com/llamalad7/mixinextras/sugar/impl/ShareInfo ShareId private,static
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/sugar/impl/ShareSugarApplicator 52 super com/llamalad7/mixinextras/sugar/impl/SugarApplicator - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 65
class com/llamalad7/mixinextras/sugar/impl/ShareType 52 public,super java/lang/Object - -
 method public <init> (Lorg/objectweb/asm/Type;)V - -
 method public getInnerType ()Lorg/objectweb/asm/Type; - -
 method public getImplType ()Lorg/objectweb/asm/Type; - -
 method public initialize (I)Lorg/objectweb/asm/tree/InsnList; - -
 method public addToLvt (Lorg/spongepowered/asm/mixin/injection/struct/Target;I)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/SingleIterationList 52 public,super java/lang/Object java/util/List <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/List<TT;>;
 method public <init> (Ljava/util/List;I)V (Ljava/util/List<TT;>;I)V -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TT;>; -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public toArray ()[Ljava/lang/Object; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T1:Ljava/lang/Object;>([TT1;)[TT1; -
 method public add (Ljava/lang/Object;)Z (TT;)Z -
 method public remove (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TT;>;)Z -
 method public addAll (ILjava/util/Collection;)Z (ILjava/util/Collection<+TT;>;)Z -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public get (I)Ljava/lang/Object; (I)TT; -
 method public set (ILjava/lang/Object;)Ljava/lang/Object; (ITT;)TT; -
 method public add (ILjava/lang/Object;)V (ITT;)V -
 method public remove (I)Ljava/lang/Object; (I)TT; -
 method public indexOf (Ljava/lang/Object;)I - -
 method public lastIndexOf (Ljava/lang/Object;)I - -
 method public listIterator ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<TT;>; -
 method public listIterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<TT;>; -
 method public subList (II)Ljava/util/List; (II)Ljava/util/List<TT;>; -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarApplicationException 52 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarApplicator 52 super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 field protected,final mixin Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; -
 field protected,final info Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo; -
 field protected,final sugar Lorg/objectweb/asm/tree/AnnotationNode; -
 field protected,final paramType Lorg/objectweb/asm/Type; -
 field protected,final paramGeneric Lorg/objectweb/asm/Type; -
 field protected,final paramLvtIndex I -
 field protected,final paramIndex I -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarInjector 52 super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarMixinTransformer 52 public,super java/lang/Object com/llamalad7/mixinextras/transformer/MixinTransformer -
 method public <init> ()V - -
 method public transform (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarParameter 52 public,super java/lang/Object - -
 field public,final sugar Lorg/objectweb/asm/tree/AnnotationNode; -
 field public,final type Lorg/objectweb/asm/Type; -
 field public,final genericType Lorg/objectweb/asm/Type; -
 field public,final lvtIndex I -
 field public,final paramIndex I -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarPostProcessingExtension 52 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 65
class com/llamalad7/mixinextras/sugar/impl/SugarPostProcessingExtension$Task 52 super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lcom/llamalad7/mixinextras/sugar/impl/SugarPostProcessingExtension$Task;>;
 inner com/llamalad7/mixinextras/sugar/impl/SugarPostProcessingExtension$Task com/llamalad7/mixinextras/sugar/impl/SugarPostProcessingExtension Task private,static
 method public <init> (ILjava/lang/Runnable;)V - -
 method public run ()V - -
 method public compareTo (Lcom/llamalad7/mixinextras/sugar/impl/SugarPostProcessingExtension$Task;)I - -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarWrapper 52 interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarWrapperImpl 52 public,super com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl - -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl HandlerCallCallback public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected getDelegate ()Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo; - -
 method protected getHandler ()Lorg/objectweb/asm/tree/MethodNode; - -
 method protected prepare ()V - -
 method protected granularInject (Lcom/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback;)V - -
 method protected doPostInject (Ljava/lang/Runnable;)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/SugarWrapperInjectionInfo 52 public,super com/llamalad7/mixinextras/wrapper/WrapperInjectionInfo - -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl Factory public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo$ParameterWrapper com/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo ParameterWrapper private,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public wrapParameter (Lcom/llamalad7/mixinextras/sugar/impl/SugarParameter;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Ljava/util/function/BiConsumer;)V (Lcom/llamalad7/mixinextras/sugar/impl/SugarParameter;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Ljava/util/function/BiConsumer<Lorg/objectweb/asm/tree/InsnList;Ljava/lang/Runnable;>;)V -
 method public transformHandler (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public transformGenerics (Ljava/util/ArrayList;)V (Ljava/util/ArrayList<Lorg/objectweb/asm/Type;>;)V -
in 22
class com/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo$ParameterWrapper 52 super java/lang/Object - -
 inner com/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo$ParameterWrapper com/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo ParameterWrapper private,static
in 22
class com/llamalad7/mixinextras/sugar/impl/handlers/HandlerTransformer 52 public,super,abstract java/lang/Object - -
 field protected,final mixin Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; -
 field protected,final parameter Lcom/llamalad7/mixinextras/sugar/impl/SugarParameter; -
 method public,abstract isRequired (Lorg/objectweb/asm/tree/MethodNode;)Z - -
 method public,abstract transform (Lcom/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo;)V - -
 method public,static create (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lcom/llamalad7/mixinextras/sugar/impl/SugarParameter;)Lcom/llamalad7/mixinextras/sugar/impl/handlers/HandlerTransformer; - -
in 22
class com/llamalad7/mixinextras/sugar/impl/handlers/LocalHandlerTransformer 52 super com/llamalad7/mixinextras/sugar/impl/handlers/HandlerTransformer - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public isRequired (Lorg/objectweb/asm/tree/MethodNode;)Z - -
 method public transform (Lcom/llamalad7/mixinextras/sugar/impl/handlers/HandlerInfo;)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/ref/LocalRefClassGenerator 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getForType (Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/sugar/impl/ref/LocalRefRuntime 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static checkState (B)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/ref/LocalRefUtils 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getInterfaceFor (Lorg/objectweb/asm/Type;)Ljava/lang/Class; (Lorg/objectweb/asm/Type;)Ljava/lang/Class<*>; -
 method public,static getTargetType (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method public,static generateNew (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/Type;)V - -
 method public,static generateInitialization (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/Type;)V - -
 method public,static generateDisposal (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/Type;)V - -
 method public,static generateUnwrapping (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/Type;Ljava/lang/Runnable;)V - -
in 22
class com/llamalad7/mixinextras/sugar/impl/ref/generated/GeneratedImplDummy 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getLookup ()Ljava/lang/invoke/MethodHandles$Lookup; - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalBooleanRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()Z - -
 method public,abstract set (Z)V - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalByteRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()B - -
 method public,abstract set (B)V - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalCharRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()C - -
 method public,abstract set (C)V - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalDoubleRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()D - -
 method public,abstract set (D)V - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalFloatRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()F - -
 method public,abstract set (F)V - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalIntRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()I - -
 method public,abstract set (I)V - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalLongRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()J - -
 method public,abstract set (J)V - -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalRef 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract get ()Ljava/lang/Object; ()TT; -
 method public,abstract set (Ljava/lang/Object;)V (TT;)V -
in 22
class com/llamalad7/mixinextras/sugar/ref/LocalShortRef 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()S - -
 method public,abstract set (S)V - -
in 22
class com/llamalad7/mixinextras/transformer/MixinTransformer 52 public,interface,abstract java/lang/Object - -
 method public,abstract transform (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class com/llamalad7/mixinextras/transformer/MixinTransformerExtension 52 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class com/llamalad7/mixinextras/utils/ASMUtils 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static annotationToString (Lorg/objectweb/asm/tree/AnnotationNode;)Ljava/lang/String; - -
 method public,static typeToString (Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static isPrimitive (Lorg/objectweb/asm/Type;)Z - -
 method public,static getInvokeInstruction (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Lorg/objectweb/asm/tree/MethodInsnNode; - -
 method public,static getDummyOpcodeForType (Lorg/objectweb/asm/Type;)I - -
 method public,static findInitNodeFor (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/TypeInsnNode;)Lorg/objectweb/asm/tree/MethodInsnNode; - -
in 22
class com/llamalad7/mixinextras/utils/Blackboard 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static get (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,static put (Ljava/lang/String;Ljava/lang/Object;)V - -
in 22
class com/llamalad7/mixinextras/utils/ClassGenUtils 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/utils/ClassGenUtils$Definer com/llamalad7/mixinextras/utils/ClassGenUtils Definer private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static defineClass (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/invoke/MethodHandles$Lookup;)V - -
 method public,static getDefinitions ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;[B>; -
in 22
class com/llamalad7/mixinextras/utils/ClassGenUtils$Definer 52 interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/utils/ClassGenUtils$Definer com/llamalad7/mixinextras/utils/ClassGenUtils Definer private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract define (Ljava/lang/String;[BLjava/lang/invoke/MethodHandles$Lookup;)V - java/lang/Throwable
in 22
class com/llamalad7/mixinextras/utils/CompatibilityHelper 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 method public <init> ()V - -
 method public,static makeInvalidInjectionException (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)Ljava/lang/RuntimeException; - -
 method public,static getMixin (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public,static makeLvtContext (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;ZLorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context; - -
 method public,static preInject (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method public,static getAnnotation (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/objectweb/asm/tree/AnnotationNode; - -
in 22
class com/llamalad7/mixinextras/utils/Decorations 52 public,super java/lang/Object - -
 field public,static,final PERSISTENT Ljava/lang/String; - "mixinextras_persistent_"
 field public,static,final POPPED_OPERATION Ljava/lang/String; - "mixinextras_operationIsImmediatelyPopped"
 field public,static,final LOCAL_REF_MAP Ljava/lang/String; - "mixinextras_localRefMap"
 field public,static,final NEW_IS_DUPED Ljava/lang/String; - "mixinextras_newIsDuped"
 field public,static,final NEW_ARG_TYPES Ljava/lang/String; - "mixinextras_newArgTypes"
 field public,static,final WRAPPED Ljava/lang/String; - "mixinextras_wrappedOperation"
 method public <init> ()V - -
in 22
class com/llamalad7/mixinextras/utils/GenericParamParser 52 public,super org/objectweb/asm/signature/SignatureVisitor - -
 method public,static getParameterGenerics (Ljava/lang/String;Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/Type;>; -
 method public visitParameterType ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
in 22
class com/llamalad7/mixinextras/utils/InjectorUtils 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public,static isVirtualRedirect (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Z - -
 method public,static isDynamicInstanceofRedirect (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Z - -
 method public,static checkForDupedNews (Ljava/util/Map;)V (Ljava/util/Map<Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;>;)V -
 method public,static isDupedNew (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Z - -
 method public,static isDupedFactoryRedirect (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Z - -
 method public,static findFactoryRedirectThrowString (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,static checkForImmediatePops (Ljava/util/Map;)V (Ljava/util/Map<Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;>;)V -
in 22
class com/llamalad7/mixinextras/utils/InternalConstructor 52 interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs,abstract newInstance ([Ljava/lang/Object;)Ljava/lang/Object; ([Ljava/lang/Object;)TT; -
 method public,static,varargs of (Ljava/lang/Class;[Ljava/lang/Class;)Lcom/llamalad7/mixinextras/utils/InternalConstructor; <T:Ljava/lang/Object;>(Ljava/lang/Class<*>;[Ljava/lang/Class<*>;)Lcom/llamalad7/mixinextras/utils/InternalConstructor<TT;>; -
 method public,static,varargs of (Ljava/lang/String;[Ljava/lang/Class;)Lcom/llamalad7/mixinextras/utils/InternalConstructor; <T:Ljava/lang/Object;>(Ljava/lang/String;[Ljava/lang/Class<*>;)Lcom/llamalad7/mixinextras/utils/InternalConstructor<TT;>; -
in 22
class com/llamalad7/mixinextras/utils/InternalField 52 interface,abstract java/lang/Object - <O:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract get (Ljava/lang/Object;)Ljava/lang/Object; (TO;)TT; -
 method public,abstract set (Ljava/lang/Object;Ljava/lang/Object;)V (TO;TT;)V -
 method public,static of (Ljava/lang/Class;Ljava/lang/String;)Lcom/llamalad7/mixinextras/utils/InternalField; <O:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/lang/Class<*>;Ljava/lang/String;)Lcom/llamalad7/mixinextras/utils/InternalField<TO;TT;>; -
 method public,static of (Ljava/lang/String;Ljava/lang/String;)Lcom/llamalad7/mixinextras/utils/InternalField; <O:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/String;)Lcom/llamalad7/mixinextras/utils/InternalField<TO;TT;>; -
in 22
class com/llamalad7/mixinextras/utils/InternalMethod 52 interface,abstract java/lang/Object - <O:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs,abstract call (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object; (TO;[Ljava/lang/Object;)TR; -
 method public,static,varargs of (Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Lcom/llamalad7/mixinextras/utils/InternalMethod; <O:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/lang/Class<*>;Ljava/lang/String;[Ljava/lang/Class<*>;)Lcom/llamalad7/mixinextras/utils/InternalMethod<TO;TR;>; -
 method public,static,varargs of (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;)Lcom/llamalad7/mixinextras/utils/InternalMethod; <O:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class<*>;)Lcom/llamalad7/mixinextras/utils/InternalMethod<TO;TR;>; -
in 61
class com/llamalad7/mixinextras/utils/MixinAPInternals 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static registerInjectionPoint (Ljavax/annotation/processing/ProcessingEnvironment;Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public,static writeReferences (Ljavax/annotation/processing/ProcessingEnvironment;)V - -
in 61
class com/llamalad7/mixinextras/utils/MixinAPVersion 52 public,super java/lang/Object - -
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 method public <init> ()V - -
 method public,static check (Ljavax/annotation/processing/ProcessingEnvironment;)V - -
in 61
class com/llamalad7/mixinextras/utils/MixinConfigUtils 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/utils/MixinConfigUtils$JsonProcessor com/llamalad7/mixinextras/utils/MixinConfigUtils JsonProcessor private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static requireMinVersion (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;Lcom/llamalad7/mixinextras/service/MixinExtrasVersion;Ljava/lang/String;)V - -
in 62
class com/llamalad7/mixinextras/utils/MixinConfigUtils$JsonProcessor 52 interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner com/llamalad7/mixinextras/utils/MixinConfigUtils$JsonProcessor com/llamalad7/mixinextras/utils/MixinConfigUtils JsonProcessor private,static,interface,abstract
 method public,abstract process (Lcom/llamalad7/mixinextras/lib/gson/stream/JsonReader;)Ljava/lang/Object; (Lcom/llamalad7/mixinextras/lib/gson/stream/JsonReader;)TT; java/io/IOException
in 63
class com/llamalad7/mixinextras/utils/MixinConfigUtils$JsonProcessor 52 interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/utils/MixinConfigUtils$JsonProcessor com/llamalad7/mixinextras/utils/MixinConfigUtils JsonProcessor private,static,interface,abstract
 method public,abstract process (Lcom/llamalad7/mixinextras/lib/gson/stream/JsonReader;)V - java/io/IOException
in 22
class com/llamalad7/mixinextras/utils/MixinExtrasLogger 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs,abstract warn (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,varargs,abstract info (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,varargs,abstract debug (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract error (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static get (Ljava/lang/String;)Lcom/llamalad7/mixinextras/utils/MixinExtrasLogger; - -
in 22
class com/llamalad7/mixinextras/utils/MixinInternals 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getMixinsFor (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)Ljava/util/List; (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)Ljava/util/List<Lcom/llamalad7/mixinextras/lib/apache/commons/tuple/Pair<Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/objectweb/asm/tree/ClassNode;>;>; -
 method public,static getTargets (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Map; (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Map<Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;>; -
 method public,static getExtensions ()Lorg/spongepowered/asm/mixin/transformer/ext/Extensions; - -
 method public,static registerExtension (Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;)V - -
 method public,static registerExtension (Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;Z)V - -
 method public,static unregisterExtension (Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;)V - -
 method public,static getDecorations (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Ljava/util/Map; (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,static getInjector (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public,static registerClassInfo (Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public,static registerInjector (Ljava/lang/String;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/Class<*>;)V -
 method public,static unregisterInjector (Ljava/lang/String;)V - -
in 61
class com/llamalad7/mixinextras/utils/MixinInternals_v0_8_3 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getTargets (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Collection; (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Collection<Lorg/objectweb/asm/tree/MethodNode;>; -
in 61
class com/llamalad7/mixinextras/utils/MixinInternals_v0_8_6 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod org/spongepowered/asm/mixin/injection/selectors/TargetSelectors SelectedMethod public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getTargets (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Collection; (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Collection<Lorg/objectweb/asm/tree/MethodNode;>; -
in 67
class com/llamalad7/mixinextras/utils/OperationUtils 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/utils/OperationUtils$OperationContents com/llamalad7/mixinextras/utils/OperationUtils OperationContents public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static makeOperation ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;Z[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;Lcom/llamalad7/mixinextras/utils/OperationUtils$OperationContents;)V - -
in 61
class com/llamalad7/mixinextras/utils/OperationUtils 52 public,super java/lang/Object - -
 inner com/llamalad7/mixinextras/utils/OperationUtils$OperationContents com/llamalad7/mixinextras/utils/OperationUtils OperationContents public,static,interface,abstract
 method public <init> ()V - -
 method public,static makeOperation ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;Z[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;Lcom/llamalad7/mixinextras/utils/OperationUtils$OperationContents;)V - -
in 65
class com/llamalad7/mixinextras/utils/OperationUtils$OperationContents 52 public,interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/utils/OperationUtils$OperationContents com/llamalad7/mixinextras/utils/OperationUtils OperationContents public,static,interface,abstract
 method public,abstract generate (ILjava/util/function/Consumer;)Lorg/objectweb/asm/tree/InsnList; (ILjava/util/function/Consumer<Lorg/objectweb/asm/tree/InsnList;>;)Lorg/objectweb/asm/tree/InsnList; -
in 61
class com/llamalad7/mixinextras/utils/PreviousInjectorInsns 52 public,super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lcom/llamalad7/mixinextras/utils/PreviousInjectorInsns;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum DYNAMIC_INSTANCEOF_REDIRECT Lcom/llamalad7/mixinextras/utils/PreviousInjectorInsns; -
 field public,static,final,enum DUPED_FACTORY_REDIRECT Lcom/llamalad7/mixinextras/utils/PreviousInjectorInsns; -
 field public,static,final,enum COMPARISON_WRAPPER Lcom/llamalad7/mixinextras/utils/PreviousInjectorInsns; -
 method public,static values ()[Lcom/llamalad7/mixinextras/utils/PreviousInjectorInsns; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/llamalad7/mixinextras/utils/PreviousInjectorInsns; - -
 method protected,abstract getPredicates ()Ljava/util/List; ()Ljava/util/List<Ljava/util/function/Predicate<Lorg/objectweb/asm/tree/AbstractInsnNode;>;>; -
 method public moveNodes (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public getLast (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method protected,static,varargs isMessage (Lorg/objectweb/asm/tree/AbstractInsnNode;[Ljava/lang/String;)Z - -
in 22
class com/llamalad7/mixinextras/utils/ProxyUtils 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getProxy (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;Ljava/lang/Class<TT;>;)TT; -
in 63
class com/llamalad7/mixinextras/utils/ResourceUtils 52 super java/lang/Object - -
 method public,static getResourceAsStream (Ljava/lang/String;)Ljava/io/InputStream; - -
in 22
class com/llamalad7/mixinextras/utils/TargetDecorations 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static has (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;)Z - -
 method public,static get (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;)TT; -
 method public,static getOrPut (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static put (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,static modify (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;Ljava/util/function/UnaryOperator;)V <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;Ljava/util/function/UnaryOperator<TT;>;)V -
 method public,static remove (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;)V - -
in 22
class com/llamalad7/mixinextras/utils/UniquenessHelper 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getUniqueMethodName (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class com/llamalad7/mixinextras/versions/MixinVersion 52 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 method public <init> ()V - -
 method public,static getInstance ()Lcom/llamalad7/mixinextras/versions/MixinVersion; - -
 method public,abstract makeInvalidInjectionException (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)Ljava/lang/RuntimeException; - -
 method public,abstract getMixin (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public,abstract makeLvtContext (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;ZLorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context; - -
 method public,abstract preInject (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method public,abstract getAnnotation (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/objectweb/asm/tree/AnnotationNode; - -
in 22
class com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8 52 public,super com/llamalad7/mixinextras/versions/MixinVersion - -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 method public <init> ()V - -
 method public makeInvalidInjectionException (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)Ljava/lang/RuntimeException; - -
 method public getMixin (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public makeLvtContext (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;ZLorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context; - -
 method public preInject (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method public getAnnotation (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/objectweb/asm/tree/AnnotationNode; - -
in 22
class com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_3 52 public,super com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8 - -
 method public <init> ()V - -
 method public getMixin (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public preInject (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method public getAnnotation (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/objectweb/asm/tree/AnnotationNode; - -
in 22
class com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_4 52 public,super com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_3 - -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 method public <init> ()V - -
 method public makeInvalidInjectionException (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)Ljava/lang/RuntimeException; - -
 method public makeLvtContext (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;ZLorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context; - -
in 61
class com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_6 52 public,super com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_4 - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getTargets (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Collection; (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Ljava/util/Collection<Lorg/spongepowered/asm/mixin/injection/struct/Target;>; -
in 67
class com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_7 52 public,super com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_4 - -
 method public <init> ()V - -
 method public getOrder (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)I - -
in 61
class com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_7 52 public,super com/llamalad7/mixinextras/versions/MixinVersionImpl_v0_8_6 - -
 method public <init> ()V - -
 method public getOrder (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)I - -
in 22
class com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl 52 public,super,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl HandlerCallCallback public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl Factory public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final classNode Lorg/objectweb/asm/tree/ClassNode; -
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Z)V - -
 method public usesGranularInject ()Z - -
 method protected,abstract getDelegate ()Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo; - -
 method protected,abstract getHandler ()Lorg/objectweb/asm/tree/MethodNode; - -
 method protected isValid ()Z - -
 method protected prepare ()V - -
 method protected preInject ()V - -
 method protected inject ()V - -
 method protected granularInject (Lcom/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback;)V - -
 method protected doPostInject (Ljava/lang/Runnable;)V - -
 method protected addCallbackInvocation (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected granularInjectNotSupported ()Ljava/lang/RuntimeException; - -
in 22
class com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory 52 public,interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl Factory public,static,interface,abstract
 method public,abstract create (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)Lcom/llamalad7/mixinextras/wrapper/InjectorWrapperImpl; - -
in 22
class com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback 52 public,interface,abstract java/lang/Object - -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl HandlerCallCallback public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public,abstract onFound (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lorg/objectweb/asm/tree/MethodInsnNode;)V - -
in 22
class com/llamalad7/mixinextras/wrapper/WrapperInjectionInfo 52 public,super,abstract com/llamalad7/mixinextras/injector/MixinExtrasInjectionInfo com/llamalad7/mixinextras/injector/LateApplyingInjectorInfo -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl Factory public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lcom/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory;Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected readAnnotation ()V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public isValid ()Z - -
 method public prepare ()V - -
 method public preInject ()V - -
 method public inject ()V - -
 method public postInject ()V - -
 method public addCallbackInvocation (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public lateInject ()V - -
 method public latePostInject ()V - -
 method public wrap (Lcom/llamalad7/mixinextras/injector/LateApplyingInjectorInfo;)V - -
 method public getLateInjectionType ()Ljava/lang/String; - -
 method public getTargetMap ()Ljava/util/Map; ()Ljava/util/Map<Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;>; -
in 22
class com/llamalad7/mixinextras/wrapper/factory/FactoryRedirectWrapper 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
in 22
class com/llamalad7/mixinextras/wrapper/factory/FactoryRedirectWrapperImpl 52 public,super com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl HandlerCallCallback public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected getDelegate ()Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo; - -
 method protected getHandler ()Lorg/objectweb/asm/tree/MethodNode; - -
 method protected granularInject (Lcom/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$HandlerCallCallback;)V - -
in 22
class com/llamalad7/mixinextras/wrapper/factory/FactoryRedirectWrapperInjectionInfo 52 public,super com/llamalad7/mixinextras/wrapper/WrapperInjectionInfo - -
 inner com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl$Factory com/llamalad7/mixinextras/wrapper/InjectorWrapperImpl Factory public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
in 22
class com/llamalad7/mixinextras/wrapper/factory/FactoryRedirectWrapperMixinTransformer 52 public,super java/lang/Object com/llamalad7/mixinextras/transformer/MixinTransformer -
 method public <init> ()V - -
 method public transform (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/objectweb/asm/tree/ClassNode;)V - -
