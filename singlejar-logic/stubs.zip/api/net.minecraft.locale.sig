cg-stub-db 1
in 72
class net/minecraft/locale/DeprecatedTranslationsInfo 65 public,final,super java/lang/Record - -
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final EMPTY Lnet/minecraft/locale/DeprecatedTranslationsInfo; -
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/locale/DeprecatedTranslationsInfo;>;
 method public <init> (Ljava/util/List;Ljava/util/Map;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static loadFromJson (Ljava/io/InputStream;)Lnet/minecraft/locale/DeprecatedTranslationsInfo; - -
 method public,static loadFromResource (Ljava/lang/String;)Lnet/minecraft/locale/DeprecatedTranslationsInfo; - -
 method public,static loadFromDefaultResource ()Lnet/minecraft/locale/DeprecatedTranslationsInfo; - -
 method public applyToMap (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public removed ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public renamed ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
in 486
class net/minecraft/locale/Language 52 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static,synchronized forceData (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public <init> ()V - -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,synchronized getElement (Ljava/lang/String;)Ljava/lang/String; - -
 method public,synchronized exists (Ljava/lang/String;)Z - -
 method public getLastUpdateTime ()J - -
in 487
class net/minecraft/locale/Language 52 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static,synchronized forceData (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,synchronized getElement (Ljava/lang/String;)Ljava/lang/String; - -
 method public,synchronized exists (Ljava/lang/String;)Z - -
 method public getLastUpdateTime ()J - -
in 188
class net/minecraft/locale/Language 52 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public,abstract getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 110
class net/minecraft/locale/Language 60 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getLanguageData ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 341
class net/minecraft/locale/Language 61 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getLanguageData ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 604
class net/minecraft/locale/Language 61 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getLanguageData ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 272
class net/minecraft/locale/Language 61 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 273
class net/minecraft/locale/Language 65 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 518
class net/minecraft/locale/Language 65 public,super,abstract java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 197
class net/minecraft/locale/Language 52 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getLanguageData ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 199
class net/minecraft/locale/Language 65 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getLanguageData ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 200
class net/minecraft/locale/Language 65 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;Ljava/util/function/BiConsumer<Ljava/lang/String;Lnet/minecraft/network/chat/Component;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getLanguageData ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComponent (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 519
class net/minecraft/locale/Language 65 public,super,abstract java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;Ljava/util/function/BiConsumer<Ljava/lang/String;Lnet/minecraft/network/chat/Component;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public getLanguageData ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComponent (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 114
class net/minecraft/locale/Language 60 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public,abstract getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
in 342
class net/minecraft/locale/Language 61 public,super,abstract java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Ljava/lang/String; - "en_us"
 method public <init> ()V - -
 method public,static loadFromJson (Ljava/io/InputStream;Ljava/util/function/BiConsumer;)V (Ljava/io/InputStream;Ljava/util/function/BiConsumer<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getInstance ()Lnet/minecraft/locale/Language; - -
 method public,static inject (Lnet/minecraft/locale/Language;)V - -
 method public,abstract getOrDefault (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract has (Ljava/lang/String;)Z - -
 method public,abstract isDefaultRightToLeft ()Z - -
 method public,abstract getVisualOrder (Lnet/minecraft/network/chat/FormattedText;)Lnet/minecraft/util/FormattedCharSequence; - -
 method public getVisualOrder (Ljava/util/List;)Ljava/util/List; (Ljava/util/List<Lnet/minecraft/network/chat/FormattedText;>;)Ljava/util/List<Lnet/minecraft/util/FormattedCharSequence;>; -
