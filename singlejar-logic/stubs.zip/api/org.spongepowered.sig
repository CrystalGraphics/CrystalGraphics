cg-stub-db 1
in 22
class org/spongepowered/asm/bridge/RemapperAdapter 52 public,super,abstract java/lang/Object org/spongepowered/asm/mixin/extensibility/IRemapper,org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper -
 inner org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper org/spongepowered/asm/util/ObfuscationUtil IClassRemapper public,static,interface,abstract
 field protected,final logger Lorg/spongepowered/asm/logging/ILogger; -
 field protected,final remapper Lorg/objectweb/asm/commons/Remapper; -
 method public <init> (Lorg/objectweb/asm/commons/Remapper;)V - -
 method public toString ()Ljava/lang/String; - -
 method public mapMethodName (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public mapFieldName (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public map (Ljava/lang/String;)Ljava/lang/String; - -
 method public unmap (Ljava/lang/String;)Ljava/lang/String; - -
 method public mapDesc (Ljava/lang/String;)Ljava/lang/String; - -
 method public unmapDesc (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/bridge/RemapperAdapterFML 52 public,final,super org/spongepowered/asm/bridge/RemapperAdapter - -
 method public unmap (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static create ()Lorg/spongepowered/asm/mixin/extensibility/IRemapper; - -
in 22
class org/spongepowered/asm/launch/GlobalProperties 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 method public,static get (Lorg/spongepowered/asm/launch/GlobalProperties$Keys;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/launch/GlobalProperties$Keys;)TT; -
 method public,static put (Lorg/spongepowered/asm/launch/GlobalProperties$Keys;Ljava/lang/Object;)V - -
 method public,static get (Lorg/spongepowered/asm/launch/GlobalProperties$Keys;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/launch/GlobalProperties$Keys;TT;)TT; -
 method public,static getString (Lorg/spongepowered/asm/launch/GlobalProperties$Keys;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/GlobalProperties$Keys 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 field public,static,final INIT Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final AGENTS Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final CONFIGS Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final PLATFORM_MANAGER Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final FML_LOAD_CORE_MOD Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final FML_GET_REPARSEABLE_COREMODS Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final FML_CORE_MOD_MANAGER Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final FML_GET_IGNORED_MODS Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 method public,static of (Ljava/lang/String;)Lorg/spongepowered/asm/launch/GlobalProperties$Keys; - -
in 22
class org/spongepowered/asm/launch/IClassProcessor 52 public,interface,abstract java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 method public,abstract handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public,abstract processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public,abstract generatesClass (Lorg/objectweb/asm/Type;)Z - -
 method public,abstract generateClass (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/launch/MixinBootstrap 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 field public,static,final VERSION Ljava/lang/String; - "0.8.5"
 method public,static,deprecated addProxy ()V - -
 method public,static getPlatform ()Lorg/spongepowered/asm/launch/platform/MixinPlatformManager; - -
 method public,static init ()V - -
in 22
class org/spongepowered/asm/launch/MixinInitialisationError 50 public,super org/spongepowered/asm/mixin/throwables/MixinError - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/launch/MixinLaunchPlugin 60 public,super org/spongepowered/asm/launch/MixinLaunchPluginLegacy - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 method public <init> ()V - -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Lcpw/mods/modlauncher/api/NamedPath;)V - -
in 22
class org/spongepowered/asm/launch/MixinLaunchPluginLegacy 52 public,super java/lang/Object cpw/mods/modlauncher/serviceapi/ILaunchPluginService,org/spongepowered/asm/service/IClassBytecodeProvider -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader cpw/mods/modlauncher/serviceapi/ILaunchPluginService ITransformerLoader public,static,interface,abstract
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 field public,static,final NAME Ljava/lang/String; - "mixin"
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public handlesClass (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;Z)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;)Z - -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public customAuditConsumer (Ljava/lang/String;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/function/Consumer<[Ljava/lang/String;>;)V -
 method public,deprecated addResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public offerResource (Ljava/nio/file/Path;Ljava/lang/String;)V - -
 method public addResources (Ljava/util/List;)V - -
 method public getExtension ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;[Ljava/nio/file/Path;)V - -
 method protected initializeLaunch (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$ITransformerLoader;)V - -
 method public getClassNode (Ljava/lang/String;)Lorg/objectweb/asm/tree/ClassNode; - java/lang/ClassNotFoundException,java/io/IOException
 method public getClassNode (Ljava/lang/String;Z)Lorg/objectweb/asm/tree/ClassNode; - java/lang/ClassNotFoundException,java/io/IOException
in 22
class org/spongepowered/asm/launch/MixinTransformationService 60 public,super org/spongepowered/asm/launch/MixinTransformationServiceAbstract - -
 method public <init> ()V - -
in 22
class org/spongepowered/asm/launch/MixinTransformationServiceAbstract 52 public,super,abstract java/lang/Object cpw/mods/modlauncher/api/ITransformationService -
 inner cpw/mods/modlauncher/api/ITransformationService$OptionResult cpw/mods/modlauncher/api/ITransformationService OptionResult public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public name ()Ljava/lang/String; - -
 method public arguments (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<Ljava/lang/String;Ljava/lang/String;Ljoptsimple/OptionSpecBuilder;>;)V -
 method public argumentValues (Lcpw/mods/modlauncher/api/ITransformationService$OptionResult;)V - -
 method public onLoad (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set;)V (Lcpw/mods/modlauncher/api/IEnvironment;Ljava/util/Set<Ljava/lang/String;>;)V cpw/mods/modlauncher/api/IncompatibleEnvironmentException
 method public initialize (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
 method public runScan (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List; (Lcpw/mods/modlauncher/api/IEnvironment;)Ljava/util/List<Ljava/util/Map$Entry<Ljava/lang/String;Ljava/nio/file/Path;>;>; -
 method public transformers ()Ljava/util/List; ()Ljava/util/List<Lcpw/mods/modlauncher/api/ITransformer;>; -
in 22
class org/spongepowered/asm/launch/MixinTransformationServiceLegacy 52 public,super org/spongepowered/asm/launch/MixinTransformationServiceAbstract - -
 method public <init> ()V - -
 method public beginScanning (Lcpw/mods/modlauncher/api/IEnvironment;)V - -
in 22
class org/spongepowered/asm/launch/MixinTweaker 52 public,super java/lang/Object net/minecraft/launchwrapper/ITweaker -
 method public <init> ()V - -
 method public,final acceptOptions (Ljava/util/List;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V -
 method public,final injectIntoClassLoader (Lnet/minecraft/launchwrapper/LaunchClassLoader;)V - -
 method public getLaunchTarget ()Ljava/lang/String; - -
 method public getLaunchArguments ()[Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/Phases 52 public,final,super java/lang/Object - -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 field public,static,final NONE Ljava/util/EnumSet; Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>;
 field public,static,final BEFORE_ONLY Ljava/util/EnumSet; Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>;
 field public,static,final AFTER_ONLY Ljava/util/EnumSet; Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>;
in 22
class org/spongepowered/asm/launch/platform/CommandLineOptions 50 public,final,super java/lang/Object - -
 method public getConfigs ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,static defaultArgs ()Lorg/spongepowered/asm/launch/platform/CommandLineOptions; - -
 method public,static ofArgs (Ljava/util/List;)Lorg/spongepowered/asm/launch/platform/CommandLineOptions; (Ljava/util/List<Ljava/lang/String;>;)Lorg/spongepowered/asm/launch/platform/CommandLineOptions; -
 method public,static of (Ljava/util/List;)Lorg/spongepowered/asm/launch/platform/CommandLineOptions; (Ljava/util/List<Ljava/lang/String;>;)Lorg/spongepowered/asm/launch/platform/CommandLineOptions; -
in 22
class org/spongepowered/asm/launch/platform/IMixinPlatformAgent 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult org/spongepowered/asm/launch/platform/IMixinPlatformAgent AcceptResult public,static,final,enum
 method public,abstract accept (Lorg/spongepowered/asm/launch/platform/MixinPlatformManager;Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; - -
 method public,abstract getPhaseProvider ()Ljava/lang/String; - -
 method public,abstract prepare ()V - -
 method public,abstract initPrimaryContainer ()V - -
 method public,abstract inject ()V - -
in 22
class org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult;>;
 inner org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult org/spongepowered/asm/launch/platform/IMixinPlatformAgent AcceptResult public,static,final,enum
 field public,static,final,enum ACCEPTED Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; -
 field public,static,final,enum REJECTED Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; -
 field public,static,final,enum INVALID Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; -
 method public,static values ()[Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; - -
in 22
class org/spongepowered/asm/launch/platform/IMixinPlatformServiceAgent 50 public,interface,abstract java/lang/Object org/spongepowered/asm/launch/platform/IMixinPlatformAgent -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 method public,abstract init ()V - -
 method public,abstract getSideName ()Ljava/lang/String; - -
 method public,abstract getMixinContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
 method public,abstract,deprecated wire (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer;)V (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;>;)V -
 method public,abstract,deprecated unwire ()V - -
in 22
class org/spongepowered/asm/launch/platform/MainAttributes 50 public,final,super java/lang/Object - -
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 field protected,final attributes Ljava/util/jar/Attributes; -
 method public,final get (Ljava/lang/String;)Ljava/lang/String; - -
 method public,final get (Ljava/util/jar/Attributes$Name;)Ljava/lang/String; - -
 method public,static of (Ljava/io/File;)Lorg/spongepowered/asm/launch/platform/MainAttributes; - -
 method public,static of (Ljava/net/URI;)Lorg/spongepowered/asm/launch/platform/MainAttributes; - -
in 22
class org/spongepowered/asm/launch/platform/MixinConnectorManager 50 public,super java/lang/Object - -
in 22
class org/spongepowered/asm/launch/platform/MixinContainer 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult org/spongepowered/asm/launch/platform/IMixinPlatformAgent AcceptResult public,static,final,enum
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 method public <init> (Lorg/spongepowered/asm/launch/platform/MixinPlatformManager;Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)V - -
 method public getDescriptor ()Lorg/spongepowered/asm/launch/platform/container/IContainerHandle; - -
 method public getPhaseProviders ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public prepare ()V - -
 method public initPrimaryContainer ()V - -
 method public inject ()V - -
in 22
class org/spongepowered/asm/launch/platform/MixinPlatformAgentAbstract 50 public,super,abstract java/lang/Object org/spongepowered/asm/launch/platform/IMixinPlatformAgent -
 inner org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult org/spongepowered/asm/launch/platform/IMixinPlatformAgent AcceptResult public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 field protected,static,final logger Lorg/spongepowered/asm/logging/ILogger; -
 field protected manager Lorg/spongepowered/asm/launch/platform/MixinPlatformManager; -
 field protected handle Lorg/spongepowered/asm/launch/platform/container/IContainerHandle; -
 method protected <init> ()V - -
 method public accept (Lorg/spongepowered/asm/launch/platform/MixinPlatformManager;Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; - -
 method public getPhaseProvider ()Ljava/lang/String; - -
 method public prepare ()V - -
 method public initPrimaryContainer ()V - -
 method public inject ()V - -
 method public toString ()Ljava/lang/String; - -
 method protected,static invokeStringMethod (Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,deprecated wire (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer;)V (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;>;)V -
 method public,deprecated unwire ()V - -
in 22
class org/spongepowered/asm/launch/platform/MixinPlatformAgentDefault 50 public,super org/spongepowered/asm/launch/platform/MixinPlatformAgentAbstract - -
 inner org/spongepowered/asm/util/Constants$ManifestAttributes org/spongepowered/asm/util/Constants ManifestAttributes public,static,abstract
 method public <init> ()V - -
 method public prepare ()V - -
in 22
class org/spongepowered/asm/launch/platform/MixinPlatformAgentFMLLegacy 52 public,super org/spongepowered/asm/launch/platform/MixinPlatformAgentAbstract org/spongepowered/asm/launch/platform/IMixinPlatformServiceAgent -
 inner org/spongepowered/asm/launch/platform/MixinPlatformAgentFMLLegacy$MixinAppender org/spongepowered/asm/launch/platform/MixinPlatformAgentFMLLegacy MixinAppender static
 inner org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult org/spongepowered/asm/launch/platform/IMixinPlatformAgent AcceptResult public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 method public <init> ()V - -
 method public accept (Lorg/spongepowered/asm/launch/platform/MixinPlatformManager;Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; - -
 method public getPhaseProvider ()Ljava/lang/String; - -
 method public prepare ()V - -
 method public inject ()V - -
 method protected,final checkForCoInitialisation ()Z - -
 method public init ()V - -
 method public getSideName ()Ljava/lang/String; - -
 method public getMixinContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
 method public,deprecated wire (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer;)V (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;>;)V -
 method public,deprecated unwire ()V - -
in 22
class org/spongepowered/asm/launch/platform/MixinPlatformAgentFMLLegacy$MixinAppender 52 super org/apache/logging/log4j/core/appender/AbstractAppender - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/launch/platform/MixinPlatformAgentFMLLegacy$MixinAppender org/spongepowered/asm/launch/platform/MixinPlatformAgentFMLLegacy MixinAppender static
 method public append (Lorg/apache/logging/log4j/core/LogEvent;)V - -
in 22
class org/spongepowered/asm/launch/platform/MixinPlatformAgentLiteLoaderLegacy 52 public,super org/spongepowered/asm/launch/platform/MixinPlatformAgentAbstract org/spongepowered/asm/launch/platform/IMixinPlatformServiceAgent -
 inner org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult org/spongepowered/asm/launch/platform/IMixinPlatformAgent AcceptResult public,static,final,enum
 method public <init> ()V - -
 method public accept (Lorg/spongepowered/asm/launch/platform/MixinPlatformManager;Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; - -
 method public getSideName ()Ljava/lang/String; - -
 method public init ()V - -
 method public getMixinContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
in 22
class org/spongepowered/asm/launch/platform/MixinPlatformAgentMinecraftForge 52 public,super org/spongepowered/asm/launch/platform/MixinPlatformAgentAbstract org/spongepowered/asm/launch/platform/IMixinPlatformServiceAgent -
 inner org/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult org/spongepowered/asm/launch/platform/IMixinPlatformAgent AcceptResult public,static,final,enum
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner cpw/mods/modlauncher/api/IEnvironment$Keys cpw/mods/modlauncher/api/IEnvironment Keys public,static,final
 method public <init> ()V - -
 method public init ()V - -
 method public accept (Lorg/spongepowered/asm/launch/platform/MixinPlatformManager;Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)Lorg/spongepowered/asm/launch/platform/IMixinPlatformAgent$AcceptResult; - -
 method public getSideName ()Ljava/lang/String; - -
 method public getMixinContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
in 22
class org/spongepowered/asm/launch/platform/MixinPlatformManager 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 method public <init> ()V - -
 method public init ()V - -
 method public getPhaseProviderClasses ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,final addContainer (Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)Lorg/spongepowered/asm/launch/platform/MixinContainer; - -
 method public,final prepare (Lorg/spongepowered/asm/launch/platform/CommandLineOptions;)V - -
 method public,final inject ()V - -
 method public getLaunchTarget ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher 52 public,super org/spongepowered/asm/launch/platform/container/ContainerHandleVirtual - -
 inner org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher$Resource org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher Resource -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Ljava/lang/String;)V - -
 method public addResource (Ljava/lang/String;Ljava/nio/file/Path;)V - -
 method public addResource (Ljava/util/Map$Entry;)V (Ljava/util/Map$Entry<Ljava/lang/String;Ljava/nio/file/Path;>;)V -
 method public addResource (Ljava/lang/Object;)V - -
 method public addResources (Ljava/util/List;)V (Ljava/util/List<*>;)V -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher$Resource 52 super org/spongepowered/asm/launch/platform/container/ContainerHandleURI - -
 inner org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher$Resource org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher Resource -
 method public <init> (Lorg/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher;Ljava/lang/String;Ljava/nio/file/Path;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/nio/file/Path; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncherEx 60 public,super org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher - -
 inner org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncherEx$SecureJarResource org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncherEx SecureJarResource static
 method public <init> (Ljava/lang/String;)V - -
 method public addResource (Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncherEx$SecureJarResource 60 super org/spongepowered/asm/launch/platform/container/ContainerHandleURI - -
 inner org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncherEx$SecureJarResource org/spongepowered/asm/launch/platform/container/ContainerHandleModLauncherEx SecureJarResource static
 method public <init> (Lcpw/mods/jarhandling/SecureJar;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/nio/file/Path; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/platform/container/ContainerHandleURI 50 public,super java/lang/Object org/spongepowered/asm/launch/platform/container/IContainerHandle -
 method public <init> (Ljava/net/URI;)V - -
 method public getURI ()Ljava/net/URI; - -
 method public,deprecated getFile ()Ljava/io/File; - -
 method public getAttribute (Ljava/lang/String;)Ljava/lang/String; - -
 method public getNestedContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/platform/container/ContainerHandleVirtual 50 public,super java/lang/Object org/spongepowered/asm/launch/platform/container/IContainerHandle -
 method public <init> (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setAttribute (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/launch/platform/container/ContainerHandleVirtual; - -
 method public add (Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;)Lorg/spongepowered/asm/launch/platform/container/ContainerHandleVirtual; - -
 method public getAttribute (Ljava/lang/String;)Ljava/lang/String; - -
 method public getNestedContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/launch/platform/container/IContainerHandle 50 public,interface,abstract java/lang/Object - -
 method public,abstract getAttribute (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getNestedContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
in 22
class org/spongepowered/asm/lib/AnnotationVisitor 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
in 22
class org/spongepowered/asm/lib/Attribute 50 public,super java/lang/Object - -
 method public <init> ()V - -
in 22
class org/spongepowered/asm/lib/ClassVisitor 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public visit (IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
 method public visitSource (Ljava/lang/String;Ljava/lang/String;)V - -
 method public visitOuterClass (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public visitAnnotation (Ljava/lang/String;Z)Lorg/spongepowered/asm/lib/AnnotationVisitor; - -
 method public visitTypeAnnotation (ILorg/spongepowered/asm/lib/TypePath;Ljava/lang/String;Z)Lorg/spongepowered/asm/lib/AnnotationVisitor; - -
 method public visitAttribute (Lorg/spongepowered/asm/lib/Attribute;)V - -
 method public visitInnerClass (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V - -
 method public visitField (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Lorg/spongepowered/asm/lib/FieldVisitor; - -
 method public visitMethod (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lorg/spongepowered/asm/lib/MethodVisitor; - -
 method public visitEnd ()V - -
in 22
class org/spongepowered/asm/lib/FieldVisitor 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
in 22
class org/spongepowered/asm/lib/MethodVisitor 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
in 22
class org/spongepowered/asm/lib/TypePath 50 public,super java/lang/Object - -
 method public <init> ()V - -
in 22
class org/spongepowered/asm/lib/tree/ClassNode 50 public,super org/spongepowered/asm/lib/ClassVisitor - -
 field public,final version I -
 field public,final access I -
 field public,final name Ljava/lang/String; -
 field public,final signature Ljava/lang/String; -
 field public,final superName Ljava/lang/String; -
 field public,final interfaces Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 field public,final sourceFile Ljava/lang/String; -
 field public,final sourceDebug Ljava/lang/String; -
 field public,final outerClass Ljava/lang/String; -
 field public,final outerMethod Ljava/lang/String; -
 field public,final outerMethodDesc Ljava/lang/String; -
 method public <init> (Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public check (I)V - -
 method public accept (Lorg/spongepowered/asm/lib/ClassVisitor;)V - -
in 22
class org/spongepowered/asm/logging/ILogger 50 public,interface,abstract java/lang/Object - -
 method public,abstract getId ()Ljava/lang/String; - -
 method public,abstract getType ()Ljava/lang/String; - -
 method public,abstract catching (Lorg/spongepowered/asm/logging/Level;Ljava/lang/Throwable;)V - -
 method public,abstract catching (Ljava/lang/Throwable;)V - -
 method public,varargs,abstract debug (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract debug (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs,abstract error (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract error (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs,abstract fatal (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract fatal (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs,abstract info (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract info (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs,abstract log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,abstract throwing (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,varargs,abstract trace (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract trace (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs,abstract warn (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract warn (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/logging/Level 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/logging/Level;>;
 field public,static,final,enum FATAL Lorg/spongepowered/asm/logging/Level; -
 field public,static,final,enum ERROR Lorg/spongepowered/asm/logging/Level; -
 field public,static,final,enum WARN Lorg/spongepowered/asm/logging/Level; -
 field public,static,final,enum INFO Lorg/spongepowered/asm/logging/Level; -
 field public,static,final,enum DEBUG Lorg/spongepowered/asm/logging/Level; -
 field public,static,final,enum TRACE Lorg/spongepowered/asm/logging/Level; -
 method public,static values ()[Lorg/spongepowered/asm/logging/Level; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/logging/Level; - -
in 22
class org/spongepowered/asm/logging/LoggerAdapterAbstract 50 public,super,abstract java/lang/Object org/spongepowered/asm/logging/ILogger -
 inner org/spongepowered/asm/logging/LoggerAdapterAbstract$FormattedMessage org/spongepowered/asm/logging/LoggerAdapterAbstract FormattedMessage public,static
 method protected <init> (Ljava/lang/String;)V - -
 method public getId ()Ljava/lang/String; - -
 method public catching (Ljava/lang/Throwable;)V - -
 method public,varargs debug (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public debug (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs error (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public error (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs fatal (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public fatal (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs info (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public info (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs trace (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public trace (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs warn (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public warn (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/logging/LoggerAdapterAbstract$FormattedMessage 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/logging/LoggerAdapterAbstract$FormattedMessage org/spongepowered/asm/logging/LoggerAdapterAbstract FormattedMessage public,static
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public toString ()Ljava/lang/String; - -
 method public getMessage ()Ljava/lang/String; - -
 method public hasThrowable ()Z - -
 method public getThrowable ()Ljava/lang/Throwable; - -
in 22
class org/spongepowered/asm/logging/LoggerAdapterConsole 50 public,super org/spongepowered/asm/logging/LoggerAdapterAbstract - -
 inner org/spongepowered/asm/logging/LoggerAdapterAbstract$FormattedMessage org/spongepowered/asm/logging/LoggerAdapterAbstract FormattedMessage public,static
 method public <init> (Ljava/lang/String;)V - -
 method public getType ()Ljava/lang/String; - -
 method public setDebugStream (Ljava/io/PrintStream;)Lorg/spongepowered/asm/logging/LoggerAdapterConsole; - -
 method public catching (Lorg/spongepowered/asm/logging/Level;Ljava/lang/Throwable;)V - -
 method public,varargs log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public throwing (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
in 22
class org/spongepowered/asm/logging/LoggerAdapterDefault 50 public,super org/spongepowered/asm/logging/LoggerAdapterAbstract - -
 method public <init> (Ljava/lang/String;)V - -
 method public getType ()Ljava/lang/String; - -
 method public catching (Lorg/spongepowered/asm/logging/Level;Ljava/lang/Throwable;)V - -
 method public,varargs log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public throwing (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
in 22
class org/spongepowered/asm/logging/LoggerAdapterJava 50 public,super org/spongepowered/asm/logging/LoggerAdapterAbstract - -
 inner org/spongepowered/asm/logging/LoggerAdapterAbstract$FormattedMessage org/spongepowered/asm/logging/LoggerAdapterAbstract FormattedMessage public,static
 method public <init> (Ljava/lang/String;)V - -
 method public getType ()Ljava/lang/String; - -
 method public catching (Lorg/spongepowered/asm/logging/Level;Ljava/lang/Throwable;)V - -
 method public,varargs debug (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public debug (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs error (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public error (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs fatal (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public fatal (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs info (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public info (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public throwing (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,varargs trace (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public trace (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs warn (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public warn (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/Debug 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract export ()Z - - Z0
 method public,abstract print ()Z - - Z0
in 22
class org/spongepowered/asm/mixin/Dynamic 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()Ljava/lang/String; - - ""
 method public,abstract mixin ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
in 22
class org/spongepowered/asm/mixin/EnvironmentStateTweaker 52 public,super java/lang/Object net/minecraft/launchwrapper/ITweaker -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 method public <init> ()V - -
 method public acceptOptions (Ljava/util/List;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V -
 method public injectIntoClassLoader (Lnet/minecraft/launchwrapper/LaunchClassLoader;)V - -
 method public getLaunchTarget ()Ljava/lang/String; - -
 method public getLaunchArguments ()[Ljava/lang/String; - -
in 1177
class org/spongepowered/asm/mixin/FabricUtil 50 public,final,super java/lang/Object - -
 field public,static,final KEY_MOD_ID Ljava/lang/String; - "fabric-modId"
 field public,static,final KEY_COMPATIBILITY Ljava/lang/String; - "fabric-compat"
 field public,static,final COMPATIBILITY_0_9_2 I - I9002
 field public,static,final COMPATIBILITY_0_10_0 I - I10000
 field public,static,final COMPATIBILITY_LATEST I - I10000
 method public <init> ()V - -
 method public,static getModId (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;)Ljava/lang/String; - -
 method public,static getModId (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getModId (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/lang/String; - -
 method public,static getCompatibility (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)I - -
in 1178
class org/spongepowered/asm/mixin/FabricUtil 52 public,final,super java/lang/Object - -
 field public,static,final KEY_MOD_ID Ljava/lang/String; - "fabric-modId"
 field public,static,final KEY_COMPATIBILITY Ljava/lang/String; - "fabric-compat"
 field public,static,final COMPATIBILITY_0_9_2 I - I9002
 field public,static,final COMPATIBILITY_0_10_0 I - I10000
 field public,static,final COMPATIBILITY_0_14_0 I - I14000
 field public,static,final COMPATIBILITY_LATEST I - I14000
 method public,static getModId (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;)Ljava/lang/String; - -
 method public,static getModId (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getModId (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/lang/String; - -
 method public,static getCompatibility (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)I - -
in 1179
class org/spongepowered/asm/mixin/FabricUtil 52 public,final,super java/lang/Object - -
 field public,static,final KEY_MOD_ID Ljava/lang/String; - "fabric-modId"
 field public,static,final KEY_COMPATIBILITY Ljava/lang/String; - "fabric-compat"
 field public,static,final COMPATIBILITY_0_9_2 I - I9002
 field public,static,final COMPATIBILITY_0_10_0 I - I10000
 field public,static,final COMPATIBILITY_0_14_0 I - I14000
 field public,static,final COMPATIBILITY_0_16_5 I - I16005
 field public,static,final COMPATIBILITY_LATEST I - I16005
 method public,static getModId (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;)Ljava/lang/String; - -
 method public,static getModId (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getModId (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/lang/String; - -
 method public,static getCompatibility (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)I - -
in 22
class org/spongepowered/asm/mixin/Final 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 22
class org/spongepowered/asm/mixin/Implements 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()[Lorg/spongepowered/asm/mixin/Interface; - -
in 22
class org/spongepowered/asm/mixin/Interface 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/Interface$Remap org/spongepowered/asm/mixin/Interface Remap public,static,final,enum
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract iface ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
 method public,abstract prefix ()Ljava/lang/String; - -
 method public,abstract unique ()Z - - Z0
 method public,abstract remap ()Lorg/spongepowered/asm/mixin/Interface$Remap; - - ELorg/spongepowered/asm/mixin/Interface$Remap;#ALL
in 22
class org/spongepowered/asm/mixin/Interface$Remap 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/Interface$Remap;>;
 inner org/spongepowered/asm/mixin/Interface$Remap org/spongepowered/asm/mixin/Interface Remap public,static,final,enum
 field public,static,final,enum ALL Lorg/spongepowered/asm/mixin/Interface$Remap; -
 field public,static,final,enum FORCE Lorg/spongepowered/asm/mixin/Interface$Remap; -
 field public,static,final,enum ONLY_PREFIXED Lorg/spongepowered/asm/mixin/Interface$Remap; -
 field public,static,final,enum NONE Lorg/spongepowered/asm/mixin/Interface$Remap; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/Interface$Remap; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/Interface$Remap; - -
 method public forceRemap ()Z - -
in 22
class org/spongepowered/asm/mixin/Intrinsic 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract displace ()Z - - Z0
in 22
class org/spongepowered/asm/mixin/Mixin 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; - []
 method public,abstract targets ()[Ljava/lang/String; - - []
 method public,abstract priority ()I - - I1000
 method public,abstract remap ()Z - - Z1
in 22
class org/spongepowered/asm/mixin/MixinEnvironment 50 public,final,super java/lang/Object org/spongepowered/asm/util/ITokenProvider -
 inner org/spongepowered/asm/mixin/MixinEnvironment$PhaseConsumer org/spongepowered/asm/mixin/MixinEnvironment PhaseConsumer static
 inner org/spongepowered/asm/mixin/MixinEnvironment$TokenProviderWrapper org/spongepowered/asm/mixin/MixinEnvironment TokenProviderWrapper static
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Side org/spongepowered/asm/mixin/MixinEnvironment Side public,static,abstract,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 method public getPhase ()Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; - -
 method public,deprecated getMixinConfigs ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,deprecated addConfiguration (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public registerTokenProviderClass (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public registerTokenProvider (Lorg/spongepowered/asm/mixin/extensibility/IEnvironmentTokenProvider;)Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public getToken (Ljava/lang/String;)Ljava/lang/Integer; - -
 method public,deprecated getErrorHandlerClasses ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getActiveTransformer ()Ljava/lang/Object; - -
 method public setActiveTransformer (Lorg/spongepowered/asm/mixin/transformer/IMixinTransformer;)V - -
 method public setSide (Lorg/spongepowered/asm/mixin/MixinEnvironment$Side;)Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public getSide ()Lorg/spongepowered/asm/mixin/MixinEnvironment$Side; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getOption (Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;)Z - -
 method public setOption (Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;Z)V - -
 method public getOptionValue (Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;)Ljava/lang/String; - -
 method public getOption (Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;Ljava/lang/Enum;)Ljava/lang/Enum; <E:Ljava/lang/Enum<TE;>;>(Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;TE;)TE; -
 method public setObfuscationContext (Ljava/lang/String;)V - -
 method public getObfuscationContext ()Ljava/lang/String; - -
 method public getRefmapObfuscationContext ()Ljava/lang/String; - -
 method public getRemappers ()Lorg/spongepowered/asm/obfuscation/RemapperChain; - -
 method public audit ()V - -
 method public,deprecated getTransformers ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/service/ITransformer;>; -
 method public,deprecated addTransformerExclusion (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public,static init (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;)V - -
 method public,static getEnvironment (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;)Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public,static getDefaultEnvironment ()Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public,static getCurrentEnvironment ()Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public,static getCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public,static getMinCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public,static,deprecated setCompatibilityLevel (Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel;)V - java/lang/IllegalArgumentException
 method public,static,deprecated getProfiler ()Lorg/spongepowered/asm/util/perf/Profiler; - -
in 22
class org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel 50 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel;>;
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 field public,static,final,enum JAVA_6 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_7 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_8 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_9 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_10 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_11 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_12 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_13 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_14 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_15 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_16 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_17 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static,final,enum JAVA_18 Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static DEFAULT Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 field public,static MAX_SUPPORTED Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public,deprecated classVersion ()I - -
 method public getClassVersion ()I - -
 method public getClassMajorVersion ()I - -
 method public getLanguageFeatures ()I - -
 method public,deprecated supportsMethodsInInterfaces ()Z - -
 method public supports (I)Z - -
 method public isAtLeast (Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel;)Z - -
 method public isLessThan (Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel;)Z - -
 method public canElevateTo (Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel;)Z - -
 method public canSupport (Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel;)Z - -
 method public,static requiredFor (I)Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
in 189
class org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel$LanguageFeature 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel$LanguageFeature org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel LanguageFeature public,static
 field public,static,final METHODS_IN_INTERFACES I - I1
 field public,static,final PRIVATE_METHODS_IN_INTERFACES I - I2
 field public,static,final NESTING I - I4
 field public,static,final DYNAMIC_CONSTANTS I - I8
 method public <init> ()V - -
in 1180
class org/spongepowered/asm/mixin/MixinEnvironment$Feature 52 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/MixinEnvironment$Feature;>;
 inner org/spongepowered/asm/mixin/MixinEnvironment$Feature org/spongepowered/asm/mixin/MixinEnvironment Feature public,static,enum
 field public,static,final,enum UNSAFE_INJECTION Lorg/spongepowered/asm/mixin/MixinEnvironment$Feature; -
 field public,static,final,enum INJECTORS_IN_INTERFACE_MIXINS Lorg/spongepowered/asm/mixin/MixinEnvironment$Feature; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/MixinEnvironment$Feature; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment$Feature; - -
 method public isAvailable ()Z - -
 method public isEnabled ()Z - -
 method public,static get (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment$Feature; - -
 method public,static exists (Ljava/lang/String;)Z - -
 method public,static isActive (Ljava/lang/String;)Z - -
in 22
class org/spongepowered/asm/mixin/MixinEnvironment$Option 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;>;
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit org/spongepowered/asm/mixin/MixinEnvironment$Option Inherit private,static,final,enum
 field public,static,final,enum DEBUG_ALL Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_EXPORT Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_EXPORT_FILTER Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_EXPORT_DECOMPILE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_EXPORT_DECOMPILE_THREADED Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_EXPORT_DECOMPILE_MERGESIGNATURES Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_VERIFY Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_VERBOSE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_INJECTORS Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_STRICT Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_UNIQUE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_TARGETS Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEBUG_PROFILER Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DUMP_TARGET_ON_FAILURE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum CHECK_ALL Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum CHECK_IMPLEMENTS Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum CHECK_IMPLEMENTS_STRICT Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum IGNORE_CONSTRAINTS Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum HOT_SWAP Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum ENVIRONMENT Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum OBFUSCATION_TYPE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DISABLE_REFMAP Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum REFMAP_REMAP Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum REFMAP_REMAP_RESOURCE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum REFMAP_REMAP_SOURCE_ENV Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum REFMAP_REMAP_ALLOW_PERMISSIVE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum IGNORE_REQUIRED Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum DEFAULT_COMPATIBILITY_LEVEL Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum SHIFT_BY_VIOLATION_BEHAVIOUR Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 field public,static,final,enum INITIALISER_INJECTION_MODE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment$Option; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit;>;
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit org/spongepowered/asm/mixin/MixinEnvironment$Option Inherit private,static,final,enum
 field public,static,final,enum INHERIT Lorg/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit; -
 field public,static,final,enum ALLOW_OVERRIDE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit; -
 field public,static,final,enum INDEPENDENT Lorg/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit; -
 field public,static,final,enum ALWAYS_FALSE Lorg/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment$Option$Inherit; - -
in 22
class org/spongepowered/asm/mixin/MixinEnvironment$Phase 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 field public,static,final PREINIT Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; -
 field public,static,final INIT Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; -
 field public,static,final DEFAULT Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; -
 method public toString ()Ljava/lang/String; - -
 method public,static forName (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; - -
in 22
class org/spongepowered/asm/mixin/MixinEnvironment$PhaseConsumer 50 super java/lang/Object org/spongepowered/asm/util/IConsumer Ljava/lang/Object;Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;>;
 inner org/spongepowered/asm/mixin/MixinEnvironment$PhaseConsumer org/spongepowered/asm/mixin/MixinEnvironment PhaseConsumer static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 method public accept (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;)V - -
in 22
class org/spongepowered/asm/mixin/MixinEnvironment$Side 50 public,super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/MixinEnvironment$Side;>;
 inner org/spongepowered/asm/mixin/MixinEnvironment$Side org/spongepowered/asm/mixin/MixinEnvironment Side public,static,abstract,enum
 field public,static,final,enum UNKNOWN Lorg/spongepowered/asm/mixin/MixinEnvironment$Side; -
 field public,static,final,enum CLIENT Lorg/spongepowered/asm/mixin/MixinEnvironment$Side; -
 field public,static,final,enum SERVER Lorg/spongepowered/asm/mixin/MixinEnvironment$Side; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/MixinEnvironment$Side; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/MixinEnvironment$Side; - -
 method protected,abstract detect ()Z - -
in 22
class org/spongepowered/asm/mixin/MixinEnvironment$TokenProviderWrapper 50 super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lorg/spongepowered/asm/mixin/MixinEnvironment$TokenProviderWrapper;>;
 inner org/spongepowered/asm/mixin/MixinEnvironment$TokenProviderWrapper org/spongepowered/asm/mixin/MixinEnvironment TokenProviderWrapper static
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IEnvironmentTokenProvider;Lorg/spongepowered/asm/mixin/MixinEnvironment;)V - -
 method public compareTo (Lorg/spongepowered/asm/mixin/MixinEnvironment$TokenProviderWrapper;)I - -
 method public getProvider ()Lorg/spongepowered/asm/mixin/extensibility/IEnvironmentTokenProvider; - -
in 22
class org/spongepowered/asm/mixin/Mixins 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 method public,static,varargs addConfigurations ([Ljava/lang/String;)V - -
 method public,static addConfiguration (Ljava/lang/String;)V - -
 method public,static getUnvisitedCount ()I - -
 method public,static getConfigs ()Ljava/util/Set; ()Ljava/util/Set<Lorg/spongepowered/asm/mixin/transformer/Config;>; -
 method public,static getMixinsForClass (Ljava/lang/String;)Ljava/util/Set; (Ljava/lang/String;)Ljava/util/Set<Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;>; -
 method public,static registerErrorHandlerClass (Ljava/lang/String;)V - -
 method public,static getErrorHandlerClasses ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
in 22
class org/spongepowered/asm/mixin/Mutable 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 22
class org/spongepowered/asm/mixin/Overwrite 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract constraints ()Ljava/lang/String; - - ""
 method public,abstract aliases ()[Ljava/lang/String; - - []
 method public,abstract remap ()Z - - Z1
in 22
class org/spongepowered/asm/mixin/Pseudo 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 22
class org/spongepowered/asm/mixin/Shadow 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract prefix ()Ljava/lang/String; - - "shadow$"
 method public,abstract remap ()Z - - Z1
 method public,abstract aliases ()[Ljava/lang/String; - - []
in 22
class org/spongepowered/asm/mixin/SoftOverride 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 22
class org/spongepowered/asm/mixin/Unique 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract silent ()Z - - Z0
in 22
class org/spongepowered/asm/mixin/connect/IMixinConnector 50 public,interface,abstract java/lang/Object - -
 method public,abstract connect ()V - -
in 22
class org/spongepowered/asm/mixin/extensibility/IActivityContext 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity org/spongepowered/asm/mixin/extensibility/IActivityContext IActivity public,static,interface,abstract
 method public,abstract toString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,varargs,abstract begin (Ljava/lang/String;[Ljava/lang/Object;)Lorg/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity; - -
 method public,abstract begin (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity; - -
 method public,abstract clear ()V - -
in 22
class org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity org/spongepowered/asm/mixin/extensibility/IActivityContext IActivity public,static,interface,abstract
 method public,varargs,abstract next (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract next (Ljava/lang/String;)V - -
 method public,abstract end ()V - -
 method public,varargs,abstract append (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,abstract append (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/mixin/extensibility/IEnvironmentTokenProvider 50 public,interface,abstract java/lang/Object - -
 field public,static,final DEFAULT_PRIORITY I - I1000
 method public,abstract getPriority ()I - -
 method public,abstract getToken (Ljava/lang/String;Lorg/spongepowered/asm/mixin/MixinEnvironment;)Ljava/lang/Integer; - -
in 22
class org/spongepowered/asm/mixin/extensibility/IMixinConfig 50 public,interface,abstract java/lang/Object - -
 field public,static,final DEFAULT_PRIORITY I - I1000
 method public,abstract getEnvironment ()Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getMixinPackage ()Ljava/lang/String; - -
 method public,abstract getPriority ()I - -
 method public,abstract getPlugin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinConfigPlugin; - -
 method public,abstract isRequired ()Z - -
 method public,abstract getTargets ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract decorate (Ljava/lang/String;Ljava/lang/Object;)V <V:Ljava/lang/Object;>(Ljava/lang/String;TV;)V -
 method public,abstract hasDecoration (Ljava/lang/String;)Z - -
 method public,abstract getDecoration (Ljava/lang/String;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;)TV; -
in 22
class org/spongepowered/asm/mixin/extensibility/IMixinConfigPlugin 50 public,interface,abstract java/lang/Object - -
 method public,abstract onLoad (Ljava/lang/String;)V - -
 method public,abstract getRefMapperConfig ()Ljava/lang/String; - -
 method public,abstract shouldApplyMixin (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,abstract acceptTargets (Ljava/util/Set;Ljava/util/Set;)V (Ljava/util/Set<Ljava/lang/String;>;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public,abstract getMixins ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract preApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)V - -
 method public,abstract postApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)V - -
in 1180
class org/spongepowered/asm/mixin/extensibility/IMixinConfigSource 52 public,interface,abstract java/lang/Object - -
 method public,abstract getId ()Ljava/lang/String; - -
 method public,abstract getDescription ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler ErrorAction public,static,final,enum
 method public,abstract onPrepareError (Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction;)Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction; - -
 method public,abstract onApplyError (Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction;)Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction; - -
in 22
class org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction;>;
 inner org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler ErrorAction public,static,final,enum
 field public,static,final,enum NONE Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction; -
 field public,static,final,enum WARN Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction; -
 field public,static,final,enum ERROR Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction; -
 field public,final logLevel Lorg/spongepowered/asm/logging/Level; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction; - -
in 22
class org/spongepowered/asm/mixin/extensibility/IMixinInfo 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 method public,abstract getConfig ()Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getClassName ()Ljava/lang/String; - -
 method public,abstract getClassRef ()Ljava/lang/String; - -
 method public,abstract getClassBytes ()[B - -
 method public,abstract isDetachedSuper ()Z - -
 method public,abstract getClassNode (I)Lorg/objectweb/asm/tree/ClassNode; - -
 method public,abstract getTargetClasses ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract getPriority ()I - -
 method public,abstract getPhase ()Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; - -
in 22
class org/spongepowered/asm/mixin/extensibility/IRemapper 50 public,interface,abstract java/lang/Object - -
 method public,abstract mapMethodName (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract mapFieldName (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract map (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract unmap (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract mapDesc (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract unmapDesc (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/gen/Accessor 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()Ljava/lang/String; - - ""
 method public,abstract remap ()Z - - Z1
in 22
class org/spongepowered/asm/mixin/gen/AccessorGenerator 50 public,super,abstract java/lang/Object - -
 field protected,final info Lorg/spongepowered/asm/mixin/gen/AccessorInfo; -
 field protected,final targetIsStatic Z -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;Z)V - -
 method protected checkModifiers ()V - -
 method protected,final createMethod (II)Lorg/objectweb/asm/tree/MethodNode; - -
 method public validate ()V - -
 method public,abstract generate ()Lorg/objectweb/asm/tree/MethodNode; - -
in 22
class org/spongepowered/asm/mixin/gen/AccessorGeneratorField 50 public,super,abstract org/spongepowered/asm/mixin/gen/AccessorGenerator - -
 field protected,final targetField Lorg/objectweb/asm/tree/FieldNode; -
 field protected,final targetType Lorg/objectweb/asm/Type; -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;)V - -
in 22
class org/spongepowered/asm/mixin/gen/AccessorGeneratorFieldGetter 50 public,super org/spongepowered/asm/mixin/gen/AccessorGeneratorField - -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;)V - -
 method public generate ()Lorg/objectweb/asm/tree/MethodNode; - -
in 22
class org/spongepowered/asm/mixin/gen/AccessorGeneratorFieldSetter 50 public,super org/spongepowered/asm/mixin/gen/AccessorGeneratorField - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;)V - -
 method public validate ()V - -
 method public generate ()Lorg/objectweb/asm/tree/MethodNode; - -
in 22
class org/spongepowered/asm/mixin/gen/AccessorGeneratorMethodProxy 50 public,super org/spongepowered/asm/mixin/gen/AccessorGenerator - -
 field protected,final targetMethod Lorg/objectweb/asm/tree/MethodNode; -
 field protected,final argTypes [Lorg/objectweb/asm/Type; -
 field protected,final returnType Lorg/objectweb/asm/Type; -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;Z)V - -
 method public generate ()Lorg/objectweb/asm/tree/MethodNode; - -
in 22
class org/spongepowered/asm/mixin/gen/AccessorGeneratorObjectFactory 50 public,super org/spongepowered/asm/mixin/gen/AccessorGeneratorMethodProxy - -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;)V - -
 method public generate ()Lorg/objectweb/asm/tree/MethodNode; - -
in 22
class org/spongepowered/asm/mixin/gen/AccessorInfo 50 public,super org/spongepowered/asm/mixin/struct/SpecialMethodInfo - -
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName org/spongepowered/asm/mixin/gen/AccessorInfo AccessorName public,static,final
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType org/spongepowered/asm/mixin/gen/AccessorInfo AccessorType public,static,abstract,enum
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result org/spongepowered/asm/mixin/injection/selectors/TargetSelector Result public,static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 field protected,final annotationClass Ljava/lang/Class; Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;
 field protected,final argTypes [Lorg/objectweb/asm/Type; -
 field protected,final returnType Lorg/objectweb/asm/Type; -
 field protected,final isStatic Z -
 field protected,final specifiedName Ljava/lang/String; -
 field protected,final type Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; -
 field protected,final target Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; -
 field protected targetField Lorg/objectweb/asm/tree/FieldNode; -
 field protected targetMethod Lorg/objectweb/asm/tree/MethodNode; -
 field protected generator Lorg/spongepowered/asm/mixin/gen/AccessorGenerator; -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;)V (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)V -
 method protected initType ()Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; - -
 method protected initTargetFieldType ()Lorg/objectweb/asm/Type; - -
 method protected initTarget ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method protected getTargetName (Ljava/lang/String;)Ljava/lang/String; - -
 method protected inflectTarget ()Ljava/lang/String; - -
 method public,static inflectTarget (Ljava/lang/String;Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Z)Ljava/lang/String; - -
 method public,static inflectTarget (Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName;Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Z)Ljava/lang/String; - -
 method public,final getTarget ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,final getTargetFieldType ()Lorg/objectweb/asm/Type; - -
 method public,final getTargetField ()Lorg/objectweb/asm/tree/FieldNode; - -
 method public,final getTargetMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public,final getReturnType ()Lorg/objectweb/asm/Type; - -
 method public,final getArgTypes ()[Lorg/objectweb/asm/Type; - -
 method public isStatic ()Z - -
 method public toString ()Ljava/lang/String; - -
 method public locate ()V - -
 method public validate ()V - -
 method public generate ()Lorg/objectweb/asm/tree/MethodNode; - -
 method protected findTarget (Ljava/util/List;)Ljava/lang/Object; <TNode:Ljava/lang/Object;>(Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;>;)TTNode; -
 method public,static of (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;)Lorg/spongepowered/asm/mixin/gen/AccessorInfo; (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/asm/mixin/gen/AccessorInfo; -
in 22
class org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName org/spongepowered/asm/mixin/gen/AccessorInfo AccessorName public,static,final
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType org/spongepowered/asm/mixin/gen/AccessorInfo AccessorType public,static,abstract,enum
 field public,final methodName Ljava/lang/String; -
 field public,final prefix Ljava/lang/String; -
 field public,final name Ljava/lang/String; -
 method public toString ()Ljava/lang/String; - -
 method public,static of (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName; - -
 method public,static of (Ljava/lang/String;Z)Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName; - -
in 22
class org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType 50 public,super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType;>;
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType org/spongepowered/asm/mixin/gen/AccessorInfo AccessorType public,static,abstract,enum
 field public,static,final,enum FIELD_GETTER Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; -
 field public,static,final,enum FIELD_SETTER Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; -
 field public,static,final,enum METHOD_PROXY Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; -
 field public,static,final,enum OBJECT_FACTORY Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; - -
 method public isExpectedPrefix (Ljava/lang/String;)Z - -
 method public getExpectedPrefixes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
in 22
class org/spongepowered/asm/mixin/gen/Invoker 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()Ljava/lang/String; - - ""
 method public,abstract remap ()Z - - Z1
in 22
class org/spongepowered/asm/mixin/gen/InvokerInfo 50 super org/spongepowered/asm/mixin/gen/AccessorInfo - -
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType org/spongepowered/asm/mixin/gen/AccessorInfo AccessorType public,static,abstract,enum
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName org/spongepowered/asm/mixin/gen/AccessorInfo AccessorName public,static,final
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result org/spongepowered/asm/mixin/injection/selectors/TargetSelector Result public,static
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 method protected initType ()Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; - -
 method protected initTargetFieldType ()Lorg/objectweb/asm/Type; - -
 method protected initTarget ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public locate ()V - -
in 22
class org/spongepowered/asm/mixin/gen/throwables/InvalidAccessorException 50 public,super org/spongepowered/asm/mixin/transformer/throwables/InvalidMixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/gen/AccessorInfo;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getAccessorInfo ()Lorg/spongepowered/asm/mixin/gen/AccessorInfo; - -
in 22
class org/spongepowered/asm/mixin/injection/At 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/At$Shift org/spongepowered/asm/mixin/injection/At Shift public,static,final,enum
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract id ()Ljava/lang/String; - - ""
 method public,abstract value ()Ljava/lang/String; - -
 method public,abstract slice ()Ljava/lang/String; - - ""
 method public,abstract shift ()Lorg/spongepowered/asm/mixin/injection/At$Shift; - - ELorg/spongepowered/asm/mixin/injection/At$Shift;#NONE
 method public,abstract by ()I - - I0
 method public,abstract args ()[Ljava/lang/String; - - []
 method public,abstract target ()Ljava/lang/String; - - ""
 method public,abstract desc ()Lorg/spongepowered/asm/mixin/injection/Desc; - - @Lorg/spongepowered/asm/mixin/injection/Desc;(value="")
 method public,abstract ordinal ()I - - I-1
 method public,abstract opcode ()I - - I-1
 method public,abstract remap ()Z - - Z1
in 22
class org/spongepowered/asm/mixin/injection/At$Shift 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/At$Shift;>;
 inner org/spongepowered/asm/mixin/injection/At$Shift org/spongepowered/asm/mixin/injection/At Shift public,static,final,enum
 field public,static,final,enum NONE Lorg/spongepowered/asm/mixin/injection/At$Shift; -
 field public,static,final,enum BEFORE Lorg/spongepowered/asm/mixin/injection/At$Shift; -
 field public,static,final,enum AFTER Lorg/spongepowered/asm/mixin/injection/At$Shift; -
 field public,static,final,enum BY Lorg/spongepowered/asm/mixin/injection/At$Shift; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/At$Shift; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/At$Shift; - -
in 22
class org/spongepowered/asm/mixin/injection/Coerce 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#METHOD])
in 22
class org/spongepowered/asm/mixin/injection/Constant 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/Constant$Condition org/spongepowered/asm/mixin/injection/Constant Condition public,static,final,enum
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract nullValue ()Z - - Z0
 method public,abstract intValue ()I - - I0
 method public,abstract floatValue ()F - - F0.0
 method public,abstract longValue ()J - - J0
 method public,abstract doubleValue ()D - - D0.0
 method public,abstract stringValue ()Ljava/lang/String; - - ""
 method public,abstract classValue ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
 method public,abstract ordinal ()I - - I-1
 method public,abstract slice ()Ljava/lang/String; - - ""
 method public,abstract expandZeroConditions ()[Lorg/spongepowered/asm/mixin/injection/Constant$Condition; - - []
 method public,abstract log ()Z - - Z0
in 22
class org/spongepowered/asm/mixin/injection/Constant$Condition 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/Constant$Condition;>;
 inner org/spongepowered/asm/mixin/injection/Constant$Condition org/spongepowered/asm/mixin/injection/Constant Condition public,static,final,enum
 field public,static,final,enum LESS_THAN_ZERO Lorg/spongepowered/asm/mixin/injection/Constant$Condition; -
 field public,static,final,enum LESS_THAN_OR_EQUAL_TO_ZERO Lorg/spongepowered/asm/mixin/injection/Constant$Condition; -
 field public,static,final,enum GREATER_THAN_OR_EQUAL_TO_ZERO Lorg/spongepowered/asm/mixin/injection/Constant$Condition; -
 field public,static,final,enum GREATER_THAN_ZERO Lorg/spongepowered/asm/mixin/injection/Constant$Condition; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/Constant$Condition; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/Constant$Condition; - -
 method public getEquivalentCondition ()Lorg/spongepowered/asm/mixin/injection/Constant$Condition; - -
 method public getOpcodes ()[I - -
in 22
class org/spongepowered/asm/mixin/injection/Desc 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/spongepowered/asm/mixin/injection/Descriptors;)
 method public,abstract id ()Ljava/lang/String; - - ""
 method public,abstract owner ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
 method public,abstract value ()Ljava/lang/String; - -
 method public,abstract ret ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
 method public,abstract args ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; - []
 method public,abstract min ()I - - I0
 method public,abstract max ()I - - I2147483647
in 22
class org/spongepowered/asm/mixin/injection/Descriptors 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()[Lorg/spongepowered/asm/mixin/injection/Desc; - -
in 22
class org/spongepowered/asm/mixin/injection/Group 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract name ()Ljava/lang/String; - - ""
 method public,abstract min ()I - - I-1
 method public,abstract max ()I - - I-1
in 22
class org/spongepowered/asm/mixin/injection/IInjectionPointContext 50 public,interface,abstract java/lang/Object org/spongepowered/asm/util/IMessageSink,org/spongepowered/asm/mixin/injection/selectors/ISelectorContext -
 method public,abstract getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public,abstract getAnnotationNode ()Lorg/objectweb/asm/tree/AnnotationNode; - -
in 22
class org/spongepowered/asm/mixin/injection/Inject 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract id ()Ljava/lang/String; - - ""
 method public,abstract method ()[Ljava/lang/String; - - []
 method public,abstract target ()[Lorg/spongepowered/asm/mixin/injection/Desc; - - []
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract at ()[Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract cancellable ()Z - - Z0
 method public,abstract locals ()Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; - - ELorg/spongepowered/asm/mixin/injection/callback/LocalCapture;#NO_CAPTURE
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
 method public,abstract constraints ()Ljava/lang/String; - - ""
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Shift org/spongepowered/asm/mixin/injection/InjectionPoint Shift static,final
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Union org/spongepowered/asm/mixin/injection/InjectionPoint Union static,final
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Intersection org/spongepowered/asm/mixin/injection/InjectionPoint Intersection static,final
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$CompositeInjectionPoint org/spongepowered/asm/mixin/injection/InjectionPoint CompositeInjectionPoint static,abstract
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour org/spongepowered/asm/mixin/injection/InjectionPoint ShiftByViolationBehaviour static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Selector org/spongepowered/asm/mixin/injection/InjectionPoint Selector public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner org/spongepowered/asm/mixin/injection/At$Shift org/spongepowered/asm/mixin/injection/At Shift public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 field public,static,final DEFAULT_ALLOWED_SHIFT_BY I - I0
 field public,static,final MAX_ALLOWED_SHIFT_BY I - I5
 method protected <init> ()V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector;Ljava/lang/String;Lorg/spongepowered/asm/util/IMessageSink;)V - -
 method public getSlice ()Ljava/lang/String; - -
 method public getSelector ()Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; - -
 method public getId ()Ljava/lang/String; - -
 method protected,varargs addMessage (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public checkPriority (II)Z - -
 method public getTargetRestriction (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; - -
 method public,abstract find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method public toString ()Ljava/lang/String; - -
 method protected,static nextNode (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,static,varargs and ([Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static,varargs or ([Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static after (Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static before (Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static shift (Lorg/spongepowered/asm/mixin/injection/InjectionPoint;I)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/util/List;)Ljava/util/List; (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;)Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>; -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Ljava/util/List;)Ljava/util/List; (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;)Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>; -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Lorg/spongepowered/asm/mixin/injection/At;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Lorg/spongepowered/asm/mixin/injection/At;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/At$Shift;ILjava/util/List;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/At$Shift;ILjava/util/List<Ljava/lang/String;>;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/At$Shift;ILjava/util/List;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/At$Shift;ILjava/util/List<Ljava/lang/String;>;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint; -
 method protected getAtCode ()Ljava/lang/String; - -
 method public,static,deprecated register (Ljava/lang/Class;)V (Ljava/lang/Class<+Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method public,static register (Ljava/lang/Class;Ljava/lang/String;)V (Ljava/lang/Class<+Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;Ljava/lang/String;)V -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract namespace ()Ljava/lang/String; - - ""
 method public,abstract value ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$CompositeInjectionPoint 50 super,abstract org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$CompositeInjectionPoint org/spongepowered/asm/mixin/injection/InjectionPoint CompositeInjectionPoint static,abstract
 field protected,final components [Lorg/spongepowered/asm/mixin/injection/InjectionPoint; -
 method protected,varargs <init> ([Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)V - -
 method public toString ()Ljava/lang/String; - -
in 1180
class org/spongepowered/asm/mixin/injection/InjectionPoint$Flags 52 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Flags org/spongepowered/asm/mixin/injection/InjectionPoint Flags public,static,final
 field public,static,final UNSAFE I - I1
 method public <init> ()V - -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/At;)I - -
 method public,static parse (Lorg/objectweb/asm/tree/AnnotationNode;)I - -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$Intersection 50 final,super org/spongepowered/asm/mixin/injection/InjectionPoint$CompositeInjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Intersection org/spongepowered/asm/mixin/injection/InjectionPoint Intersection static,final
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$CompositeInjectionPoint org/spongepowered/asm/mixin/injection/InjectionPoint CompositeInjectionPoint static,abstract
 method public,varargs <init> ([Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)V - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel;>;
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 field public,static,final,enum METHODS_ONLY Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; -
 field public,static,final,enum CONSTRUCTORS_AFTER_DELEGATE Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; -
 field public,static,final,enum ALLOW_ALL Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; - -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$Selector 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector;>;
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Selector org/spongepowered/asm/mixin/injection/InjectionPoint Selector public,static,final,enum
 field public,static,final,enum FIRST Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; -
 field public,static,final,enum LAST Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; -
 field public,static,final,enum ONE Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; -
 field public,static,final DEFAULT Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; - -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$Shift 50 final,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Shift org/spongepowered/asm/mixin/injection/InjectionPoint Shift static,final
 method public <init> (Lorg/spongepowered/asm/mixin/injection/InjectionPoint;I)V - -
 method public toString ()Ljava/lang/String; - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour;>;
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour org/spongepowered/asm/mixin/injection/InjectionPoint ShiftByViolationBehaviour static,final,enum
 field public,static,final,enum IGNORE Lorg/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour; -
 field public,static,final,enum WARN Lorg/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour; -
 field public,static,final,enum ERROR Lorg/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$ShiftByViolationBehaviour; - -
in 1177
class org/spongepowered/asm/mixin/injection/InjectionPoint$Specifier 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier;>;
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Specifier org/spongepowered/asm/mixin/injection/InjectionPoint Specifier public,static,final,enum
 field public,static,final,enum ALL Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum FIRST Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum LAST Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum ONE Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum DEFAULT Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; - -
in 1180
class org/spongepowered/asm/mixin/injection/InjectionPoint$Specifier 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier;>;
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Specifier org/spongepowered/asm/mixin/injection/InjectionPoint Specifier public,static,final,enum
 field public,static,final,enum ALL Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum FIRST Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum LAST Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum ONE Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 field public,static,final,enum DEFAULT Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Specifier; - -
in 22
class org/spongepowered/asm/mixin/injection/InjectionPoint$Union 50 final,super org/spongepowered/asm/mixin/injection/InjectionPoint$CompositeInjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Union org/spongepowered/asm/mixin/injection/InjectionPoint Union static,final
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$CompositeInjectionPoint org/spongepowered/asm/mixin/injection/InjectionPoint CompositeInjectionPoint static,abstract
 method public,varargs <init> ([Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)V - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/ModifyArg 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - - []
 method public,abstract target ()[Lorg/spongepowered/asm/mixin/injection/Desc; - - []
 method public,abstract slice ()Lorg/spongepowered/asm/mixin/injection/Slice; - - @Lorg/spongepowered/asm/mixin/injection/Slice;()
 method public,abstract at ()Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract index ()I - - I-1
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
 method public,abstract constraints ()Ljava/lang/String; - - ""
in 22
class org/spongepowered/asm/mixin/injection/ModifyArgs 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - - []
 method public,abstract target ()[Lorg/spongepowered/asm/mixin/injection/Desc; - - []
 method public,abstract slice ()Lorg/spongepowered/asm/mixin/injection/Slice; - - @Lorg/spongepowered/asm/mixin/injection/Slice;()
 method public,abstract at ()Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
 method public,abstract constraints ()Ljava/lang/String; - - ""
in 22
class org/spongepowered/asm/mixin/injection/ModifyConstant 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - - []
 method public,abstract target ()[Lorg/spongepowered/asm/mixin/injection/Desc; - - []
 method public,abstract slice ()[Lorg/spongepowered/asm/mixin/injection/Slice; - - []
 method public,abstract constant ()[Lorg/spongepowered/asm/mixin/injection/Constant; - - []
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
 method public,abstract constraints ()Ljava/lang/String; - - ""
in 22
class org/spongepowered/asm/mixin/injection/ModifyVariable 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - - []
 method public,abstract target ()[Lorg/spongepowered/asm/mixin/injection/Desc; - - []
 method public,abstract slice ()Lorg/spongepowered/asm/mixin/injection/Slice; - - @Lorg/spongepowered/asm/mixin/injection/Slice;()
 method public,abstract at ()Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract print ()Z - - Z0
 method public,abstract ordinal ()I - - I-1
 method public,abstract index ()I - - I-1
 method public,abstract name ()[Ljava/lang/String; - - []
 method public,abstract argsOnly ()Z - - Z0
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
 method public,abstract constraints ()Ljava/lang/String; - - ""
in 1180
class org/spongepowered/asm/mixin/injection/Next 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract name ()Ljava/lang/String; - - ""
 method public,abstract ret ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
 method public,abstract args ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; - []
 method public,abstract min ()I - - I0
 method public,abstract max ()I - - I2147483647
in 22
class org/spongepowered/asm/mixin/injection/Redirect 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract method ()[Ljava/lang/String; - - []
 method public,abstract target ()[Lorg/spongepowered/asm/mixin/injection/Desc; - - []
 method public,abstract slice ()Lorg/spongepowered/asm/mixin/injection/Slice; - - @Lorg/spongepowered/asm/mixin/injection/Slice;()
 method public,abstract at ()Lorg/spongepowered/asm/mixin/injection/At; - -
 method public,abstract remap ()Z - - Z1
 method public,abstract require ()I - - I-1
 method public,abstract expect ()I - - I1
 method public,abstract allow ()I - - I-1
 method public,abstract constraints ()Ljava/lang/String; - - ""
in 22
class org/spongepowered/asm/mixin/injection/Slice 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract id ()Ljava/lang/String; - - ""
 method public,abstract from ()Lorg/spongepowered/asm/mixin/injection/At; - - @Lorg/spongepowered/asm/mixin/injection/At;(value="HEAD")
 method public,abstract to ()Lorg/spongepowered/asm/mixin/injection/At; - - @Lorg/spongepowered/asm/mixin/injection/At;(value="TAIL")
in 22
class org/spongepowered/asm/mixin/injection/Surrogate 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 22
class org/spongepowered/asm/mixin/injection/callback/CallbackInfo 50 public,super java/lang/Object org/spongepowered/asm/mixin/injection/callback/Cancellable -
 method public <init> (Ljava/lang/String;Z)V - -
 method public getId ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,final isCancellable ()Z - -
 method public,final isCancelled ()Z - -
 method public cancel ()V - org/spongepowered/asm/mixin/injection/callback/CancellationException
 method public,static getCallInfoClassName (Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable 50 public,super org/spongepowered/asm/mixin/injection/callback/CallbackInfo - <R:Ljava/lang/Object;>Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;
 method public <init> (Ljava/lang/String;Z)V - -
 method public <init> (Ljava/lang/String;ZLjava/lang/Object;)V (Ljava/lang/String;ZTR;)V -
 method public <init> (Ljava/lang/String;ZB)V - -
 method public <init> (Ljava/lang/String;ZC)V - -
 method public <init> (Ljava/lang/String;ZD)V - -
 method public <init> (Ljava/lang/String;ZF)V - -
 method public <init> (Ljava/lang/String;ZI)V - -
 method public <init> (Ljava/lang/String;ZJ)V - -
 method public <init> (Ljava/lang/String;ZS)V - -
 method public <init> (Ljava/lang/String;ZZ)V - -
 method public setReturnValue (Ljava/lang/Object;)V (TR;)V org/spongepowered/asm/mixin/injection/callback/CancellationException
 method public getReturnValue ()Ljava/lang/Object; ()TR; -
 method public getReturnValueB ()B - -
 method public getReturnValueC ()C - -
 method public getReturnValueD ()D - -
 method public getReturnValueF ()F - -
 method public getReturnValueI ()I - -
 method public getReturnValueJ ()J - -
 method public getReturnValueS ()S - -
 method public getReturnValueZ ()Z - -
in 22
class org/spongepowered/asm/mixin/injection/callback/CallbackInjector 50 public,super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/callback/CallbackInjector$Callback org/spongepowered/asm/mixin/injection/callback/CallbackInjector Callback private
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;ZLorg/spongepowered/asm/mixin/injection/callback/LocalCapture;Ljava/lang/String;)V - -
 method protected sanityCheck (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method protected addTargetNode (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/Set;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method protected preInject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected instanceCallbackInfo (Lorg/spongepowered/asm/mixin/injection/callback/CallbackInjector$Callback;Ljava/lang/String;Ljava/lang/String;Z)V - -
 method protected injectCancellationCode (Lorg/spongepowered/asm/mixin/injection/callback/CallbackInjector$Callback;)V - -
 method protected injectReturnCode (Lorg/spongepowered/asm/mixin/injection/callback/CallbackInjector$Callback;)V - -
 method protected isStatic ()Z - -
in 22
class org/spongepowered/asm/mixin/injection/callback/CallbackInjector$Callback 50 super org/objectweb/asm/tree/InsnList - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/mixin/injection/callback/CallbackInjector$Callback org/spongepowered/asm/mixin/injection/callback/CallbackInjector Callback private
in 22
class org/spongepowered/asm/mixin/injection/callback/Cancellable 50 public,interface,abstract java/lang/Object - -
 method public,abstract isCancellable ()Z - -
 method public,abstract isCancelled ()Z - -
 method public,abstract cancel ()V - org/spongepowered/asm/mixin/injection/callback/CancellationException
in 22
class org/spongepowered/asm/mixin/injection/callback/CancellationException 50 public,super java/lang/RuntimeException - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/injection/callback/LocalCapture 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture;>;
 field public,static,final,enum NO_CAPTURE Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; -
 field public,static,final,enum PRINT Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; -
 field public,static,final,enum CAPTURE_FAILSOFT Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; -
 field public,static,final,enum CAPTURE_FAILHARD Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; -
 field public,static,final,enum CAPTURE_FAILEXCEPTION Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/callback/LocalCapture; - -
in 1180
class org/spongepowered/asm/mixin/injection/code/IInsnListEx 52 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType org/spongepowered/asm/mixin/injection/code/IInsnListEx SpecialNodeType public,static,final,enum
 method public,abstract getTargetName ()Ljava/lang/String; - -
 method public,abstract getTargetDesc ()Ljava/lang/String; - -
 method public,abstract getTargetSignature ()Ljava/lang/String; - -
 method public,abstract getTargetAccess ()I - -
 method public,abstract isTargetStatic ()Z - -
 method public,abstract isTargetConstructor ()Z - -
 method public,abstract isTargetStaticInitialiser ()Z - -
 method public,abstract getSpecialNode (Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,abstract hasDecoration (Ljava/lang/String;)Z - -
 method public,abstract getDecoration (Ljava/lang/String;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;)TV; -
 method public,abstract getDecoration (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;TV;)TV; -
in 1180
class org/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType;>;
 inner org/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType org/spongepowered/asm/mixin/injection/code/IInsnListEx SpecialNodeType public,static,final,enum
 field public,static,final,enum DELEGATE_CTOR Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType; -
 field public,static,final,enum INITIALISER_INJECTION_POINT Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType; -
 field public,static,final,enum CTOR_BODY Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType; - -
in 22
class org/spongepowered/asm/mixin/injection/code/ISliceContext 50 public,interface,abstract java/lang/Object org/spongepowered/asm/mixin/injection/IInjectionPointContext -
 method public,abstract getSlice (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/code/MethodSlice; - -
in 22
class org/spongepowered/asm/mixin/injection/code/Injector 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 inner org/spongepowered/asm/mixin/injection/code/Injector$TargetNode org/spongepowered/asm/mixin/injection/code/Injector TargetNode public,static,final
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 inner org/spongepowered/asm/util/Bytecode$DelegateInitialiser org/spongepowered/asm/util/Bytecode DelegateInitialiser public,static
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup org/spongepowered/asm/mixin/transformer/ClassInfo TypeLookup public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Traversal org/spongepowered/asm/mixin/transformer/ClassInfo Traversal public,static,final,enum
 field protected,static,final logger Lorg/spongepowered/asm/logging/ILogger; -
 field protected info Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo; -
 field protected,final annotationType Ljava/lang/String; -
 field protected,final classNode Lorg/objectweb/asm/tree/ClassNode; -
 field protected,final methodNode Lorg/objectweb/asm/tree/MethodNode; -
 field protected,final methodArgs [Lorg/objectweb/asm/Type; -
 field protected,final returnType Lorg/objectweb/asm/Type; -
 field protected,final isStatic Z -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public,final find (Lorg/spongepowered/asm/mixin/injection/code/InjectorTarget;Ljava/util/List;)Ljava/util/List; (Lorg/spongepowered/asm/mixin/injection/code/InjectorTarget;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>; -
 method protected addTargetNode (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/Set;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method public,final preInject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;)V -
 method public,final inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;)V -
 method protected findTargetNodes (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/injection/InjectionPoint;Lorg/spongepowered/asm/mixin/injection/code/InjectorTarget;Ljava/util/Collection;)Z (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/injection/InjectionPoint;Lorg/spongepowered/asm/mixin/injection/code/InjectorTarget;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method protected sanityCheck (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method protected,final checkTargetModifiers (Lorg/spongepowered/asm/mixin/injection/struct/Target;Z)V - -
 method protected checkTargetForNode (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel;)V - -
 method protected preInject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected,abstract inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected postInject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected invokeHandler (Lorg/objectweb/asm/tree/InsnList;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method protected invokeHandler (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/MethodNode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method protected invokeHandlerWithArgs ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;[I)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method protected invokeHandlerWithArgs ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;[III)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method protected storeArgs (Lorg/spongepowered/asm/mixin/injection/struct/Target;[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;I)[I - -
 method protected storeArgs (Lorg/spongepowered/asm/mixin/injection/struct/Target;[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;ILorg/objectweb/asm/tree/LabelNode;Lorg/objectweb/asm/tree/LabelNode;)[I - -
 method protected storeArgs (Lorg/spongepowered/asm/mixin/injection/struct/Target;[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;[III)V - -
 method protected storeArgs (Lorg/spongepowered/asm/mixin/injection/struct/Target;[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;[IIILorg/objectweb/asm/tree/LabelNode;Lorg/objectweb/asm/tree/LabelNode;)V - -
 method protected pushArgs ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;[III)V - -
 method protected pushArgs ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;[IIILorg/spongepowered/asm/mixin/injection/struct/Target$Extension;)V - -
 method protected,final,varargs validateParams (Lorg/spongepowered/asm/mixin/injection/code/Injector$InjectorData;Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;)V - -
 method protected,final checkCoerce (ILorg/objectweb/asm/Type;Ljava/lang/String;Z)Z - -
 method protected throwException (Lorg/objectweb/asm/tree/InsnList;Lorg/spongepowered/asm/mixin/injection/struct/Target$Extension;Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static canCoerce (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Z - -
 method public,static canCoerce (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static canCoerce (CC)Z - -
in 22
class org/spongepowered/asm/mixin/injection/code/Injector$InjectorData 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 field public,final target Lorg/spongepowered/asm/mixin/injection/struct/Target; -
 field public description Ljava/lang/String; -
 field public allowCoerceArgs Z -
 field public captureTargetArgs I -
 field public coerceReturnType Z -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/lang/String;Z)V - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/code/Injector$TargetNode 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/code/Injector$TargetNode org/spongepowered/asm/mixin/injection/code/Injector TargetNode public,static,final
 method public getNode ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getNominators ()Ljava/util/Set; ()Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/injection/code/InjectorTarget 50 public,super java/lang/Object - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/code/ISliceContext;Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;)V - -
 method public toString ()Ljava/lang/String; - -
 method public getTarget ()Lorg/spongepowered/asm/mixin/injection/struct/Target; - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getSelector ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public isMerged ()Z - -
 method public getMergedBy ()Ljava/lang/String; - -
 method public getMergedPriority ()I - -
 method public getSlice (Ljava/lang/String;)Lorg/objectweb/asm/tree/InsnList; - -
 method public getSlice (Lorg/spongepowered/asm/mixin/injection/InjectionPoint;)Lorg/objectweb/asm/tree/InsnList; - -
 method public dispose ()V - -
in 1180
class org/spongepowered/asm/mixin/injection/code/InsnListEx 52 public,super org/spongepowered/asm/mixin/injection/code/InsnListReadOnly org/spongepowered/asm/mixin/injection/code/IInsnListEx -
 inner org/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType org/spongepowered/asm/mixin/injection/code/IInsnListEx SpecialNodeType public,static,final,enum
 inner org/spongepowered/asm/util/Bytecode$DelegateInitialiser org/spongepowered/asm/util/Bytecode DelegateInitialiser public,static
 inner org/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode org/spongepowered/asm/mixin/transformer/struct/Initialiser InjectionMode public,static,final,enum
 field protected,final target Lorg/spongepowered/asm/mixin/injection/struct/Target; -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method public toString ()Ljava/lang/String; - -
 method public getTargetName ()Ljava/lang/String; - -
 method public getTargetDesc ()Ljava/lang/String; - -
 method public getTargetSignature ()Ljava/lang/String; - -
 method public getTargetAccess ()I - -
 method public isTargetStatic ()Z - -
 method public isTargetConstructor ()Z - -
 method public isTargetStaticInitialiser ()Z - -
 method public getSpecialNode (Lorg/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public decorate (Ljava/lang/String;Ljava/lang/Object;)Lorg/spongepowered/asm/mixin/injection/code/InsnListEx; <V:Ljava/lang/Object;>(Ljava/lang/String;TV;)Lorg/spongepowered/asm/mixin/injection/code/InsnListEx; -
 method public undecorate (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/code/InsnListEx; - -
 method public undecorate ()Lorg/spongepowered/asm/mixin/injection/code/InsnListEx; - -
 method public hasDecoration (Ljava/lang/String;)Z - -
 method public getDecoration (Ljava/lang/String;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;)TV; -
 method public getDecoration (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;TV;)TV; -
in 22
class org/spongepowered/asm/mixin/injection/code/InsnListReadOnly 50 public,super org/objectweb/asm/tree/InsnList - -
 method public <init> (Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final set (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final add (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final add (Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final insertBefore (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final insertBefore (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final remove (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public toArray ()[Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public size ()I - -
 method public getFirst ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getLast ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public get (I)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public contains (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public indexOf (Lorg/objectweb/asm/tree/AbstractInsnNode;)I - -
 method public iterator ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public iterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public,final resetLabels ()V - -
in 22
class org/spongepowered/asm/mixin/injection/code/MethodSlice 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice org/spongepowered/asm/mixin/injection/code/MethodSlice InsnListSlice static,final
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Selector org/spongepowered/asm/mixin/injection/InjectionPoint Selector public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public getId ()Ljava/lang/String; - -
 method public getSlice (Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/mixin/injection/code/InsnListReadOnly; - -
 method public toString ()Ljava/lang/String; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/code/ISliceContext;Lorg/spongepowered/asm/mixin/injection/Slice;)Lorg/spongepowered/asm/mixin/injection/code/MethodSlice; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/code/ISliceContext;Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/MethodSlice; - -
in 22
class org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice 50 final,super org/spongepowered/asm/mixin/injection/code/InsnListReadOnly - -
 inner org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice org/spongepowered/asm/mixin/injection/code/MethodSlice InsnListSlice static,final
 inner org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice$SliceIterator org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice SliceIterator static
 method protected <init> (Lorg/objectweb/asm/tree/InsnList;II)V - -
 method public iterator ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public iterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public toArray ()[Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public size ()I - -
 method public getFirst ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getLast ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public get (I)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public contains (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public indexOf (Lorg/objectweb/asm/tree/AbstractInsnNode;)I - -
 method public realIndexOf (Lorg/objectweb/asm/tree/AbstractInsnNode;)I - -
in 22
class org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice$SliceIterator 50 super java/lang/Object java/util/ListIterator Ljava/lang/Object;Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>;
 inner org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice org/spongepowered/asm/mixin/injection/code/MethodSlice InsnListSlice static,final
 inner org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice$SliceIterator org/spongepowered/asm/mixin/injection/code/MethodSlice$InsnListSlice SliceIterator static
 method public <init> (Ljava/util/ListIterator;III)V (Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>;III)V -
 method public hasNext ()Z - -
 method public next ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public hasPrevious ()Z - -
 method public previous ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public nextIndex ()I - -
 method public previousIndex ()I - -
 method public remove ()V - -
 method public set (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public add (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/code/MethodSlices 50 public,final,super java/lang/Object - -
 method public get (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/code/MethodSlice; - -
 method public toString ()Ljava/lang/String; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/injection/code/MethodSlices; - -
in 189
class org/spongepowered/asm/mixin/injection/code/ReadOnlyInsnList 52 super org/objectweb/asm/tree/InsnList - -
 method public <init> (Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final set (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final add (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final add (Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final insert (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final insertBefore (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,final insertBefore (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public,final remove (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public toArray ()[Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public size ()I - -
 method public getFirst ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getLast ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public get (I)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public contains (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public indexOf (Lorg/objectweb/asm/tree/AbstractInsnNode;)I - -
 method public iterator ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public iterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public,final resetLabels ()V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/InvokeInjector 50 public,super,abstract org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)V - -
 method protected sanityCheck (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method protected checkTarget (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected,abstract injectAtInvoke (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/ModifyArgInjector 50 public,super org/spongepowered/asm/mixin/injection/invoke/InvokeInjector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;I)V - -
 method protected sanityCheck (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method protected checkTarget (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected injectAtInvoke (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected findArgIndex (Lorg/spongepowered/asm/mixin/injection/struct/Target;[Lorg/objectweb/asm/Type;)I - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/ModifyArgsInjector 50 public,super org/spongepowered/asm/mixin/injection/invoke/InvokeInjector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected checkTarget (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected injectAtInvoke (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/ModifyConstantInjector 50 public,super org/spongepowered/asm/mixin/injection/invoke/RedirectInjector - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/RedirectInjector 50 public,super org/spongepowered/asm/mixin/injection/invoke/InvokeInjector - -
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$RedirectedFieldData org/spongepowered/asm/mixin/injection/invoke/RedirectInjector RedirectedFieldData static
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$RedirectedInvokeData org/spongepowered/asm/mixin/injection/invoke/RedirectInjector RedirectedInvokeData static
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$ConstructorRedirectData org/spongepowered/asm/mixin/injection/invoke/RedirectInjector ConstructorRedirectData static
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$Meta org/spongepowered/asm/mixin/injection/invoke/RedirectInjector Meta -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 field protected meta Lorg/spongepowered/asm/mixin/injection/invoke/RedirectInjector$Meta; -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;)V - -
 method protected checkTarget (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method protected addTargetNode (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/Set;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;Lorg/objectweb/asm/tree/AbstractInsnNode;Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected preInject (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Z - -
 method protected postInject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected injectAtInvoke (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected injectAtConstructor (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected injectAtInstanceOf (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected injectAtInstanceOf (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/TypeInsnNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$ConstructorRedirectData 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$ConstructorRedirectData org/spongepowered/asm/mixin/injection/invoke/RedirectInjector ConstructorRedirectData static
 field public,static,final KEY Ljava/lang/String; - "ctor"
 method public throwOrCollect (Lorg/spongepowered/asm/mixin/injection/throwables/InvalidInjectionException;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$Meta 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$Meta org/spongepowered/asm/mixin/injection/invoke/RedirectInjector Meta -
 field public,static,final KEY Ljava/lang/String; - "redirector"
 method public <init> (Lorg/spongepowered/asm/mixin/injection/invoke/RedirectInjector;IZLjava/lang/String;Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$RedirectedFieldData 50 super org/spongepowered/asm/mixin/injection/code/Injector$InjectorData - -
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$RedirectedFieldData org/spongepowered/asm/mixin/injection/invoke/RedirectInjector RedirectedFieldData static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
in 22
class org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$RedirectedInvokeData 50 super org/spongepowered/asm/mixin/injection/code/Injector$InjectorData - -
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$RedirectedInvokeData org/spongepowered/asm/mixin/injection/invoke/RedirectInjector RedirectedInvokeData static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
in 22
class org/spongepowered/asm/mixin/injection/invoke/arg/Args 50 public,super,abstract java/lang/Object - -
 field protected,final values [Ljava/lang/Object; -
 method protected <init> ([Ljava/lang/Object;)V - -
 method public size ()I - -
 method public get (I)Ljava/lang/Object; <T:Ljava/lang/Object;>(I)TT; -
 method public,abstract set (ILjava/lang/Object;)V <T:Ljava/lang/Object;>(ITT;)V -
 method public,varargs,abstract setAll ([Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/arg/ArgsClassGenerator 50 public,final,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IClassGenerator -
 inner org/spongepowered/asm/mixin/injection/invoke/arg/ArgsClassGenerator$ArgsClassInfo org/spongepowered/asm/mixin/injection/invoke/arg/ArgsClassGenerator ArgsClassInfo -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 field public,static,final ARGS_NAME Ljava/lang/String; -
 field public,static,final ARGS_REF Ljava/lang/String; -
 field public,static,final GETTER_PREFIX Ljava/lang/String; - "$"
 method public <init> (Lorg/spongepowered/asm/util/IConsumer;)V (Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/service/ISyntheticClassInfo;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getArgsClass (Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)Lorg/spongepowered/asm/service/ISyntheticClassInfo; - -
 method public generate (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/arg/ArgsClassGenerator$ArgsClassInfo 50 super org/spongepowered/asm/mixin/transformer/SyntheticClassInfo - -
 inner org/spongepowered/asm/mixin/injection/invoke/arg/ArgsClassGenerator$ArgsClassInfo org/spongepowered/asm/mixin/injection/invoke/arg/ArgsClassGenerator ArgsClassInfo -
 method public isLoaded ()Z - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentCountException 50 public,super java/lang/IllegalArgumentException - -
 method public <init> (IILjava/lang/String;)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/arg/ArgumentIndexOutOfBoundsException 50 public,super java/lang/IndexOutOfBoundsException - -
 method public <init> (I)V - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder PopAnalyzer static
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder AnalyzerState static,final,enum
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalysisResultException org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder AnalysisResultException static
 method public <init> ()V - -
 method public findPopInsn (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalysisResultException 50 super java/lang/RuntimeException - -
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalysisResultException org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder AnalysisResultException static
 method public <init> (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public getResult ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState;>;
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder AnalyzerState static,final,enum
 field public,static,final,enum SEARCH Lorg/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState; -
 field public,static,final,enum ANALYSE Lorg/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState; -
 field public,static,final,enum COMPLETE Lorg/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState; - -
in 22
class org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer 50 super org/objectweb/asm/tree/analysis/Analyzer - Lorg/objectweb/asm/tree/analysis/Analyzer<Lorg/objectweb/asm/tree/analysis/BasicValue;>;
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder PopAnalyzer static
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer$PopFrame org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer PopFrame -
 field protected,final node Lorg/objectweb/asm/tree/AbstractInsnNode; -
 method public <init> (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method protected newFrame (II)Lorg/objectweb/asm/tree/analysis/Frame; (II)Lorg/objectweb/asm/tree/analysis/Frame<Lorg/objectweb/asm/tree/analysis/BasicValue;>; -
in 22
class org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer$PopFrame 50 super org/objectweb/asm/tree/analysis/Frame - Lorg/objectweb/asm/tree/analysis/Frame<Lorg/objectweb/asm/tree/analysis/BasicValue;>;
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalyzerState org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder AnalyzerState static,final,enum
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder PopAnalyzer static
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer$PopFrame org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer PopFrame -
 inner org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$AnalysisResultException org/spongepowered/asm/mixin/injection/invoke/util/InsnFinder AnalysisResultException static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/invoke/util/InsnFinder$PopAnalyzer;II)V - -
 method public execute (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/analysis/Interpreter;)V (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/analysis/Interpreter<Lorg/objectweb/asm/tree/analysis/BasicValue;>;)V org/objectweb/asm/tree/analysis/AnalyzerException
 method public push (Lorg/objectweb/asm/tree/analysis/BasicValue;)V - java/lang/IndexOutOfBoundsException
 method public pop ()Lorg/objectweb/asm/tree/analysis/BasicValue; - java/lang/IndexOutOfBoundsException
in 1177
class org/spongepowered/asm/mixin/injection/invoke/util/InvokeUtil 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/invoke/RedirectInjector$Meta org/spongepowered/asm/mixin/injection/invoke/RedirectInjector Meta public
 method public <init> ()V - -
 method public,static getOriginalArgs (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)[Lorg/objectweb/asm/Type; - -
 method public,static getCurrentArgs (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)[Lorg/objectweb/asm/Type; - -
in 22
class org/spongepowered/asm/mixin/injection/modify/AfterStoreLocal 50 public,super org/spongepowered/asm/mixin/injection/modify/BeforeLoadLocal - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
in 22
class org/spongepowered/asm/mixin/injection/modify/BeforeLoadLocal 50 public,super org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$LocalVariableInjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/modify/BeforeLoadLocal$SearchState org/spongepowered/asm/mixin/injection/modify/BeforeLoadLocal SearchState -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$LocalVariableInjectionPoint org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector LocalVariableInjectionPoint static,abstract
 field protected,final returnType Lorg/objectweb/asm/Type; -
 field protected,final discriminator Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator; -
 field protected,final opcode I -
 field protected,final ordinal I -
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;IZ)V - -
 method protected,varargs addMessage (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public toString ()Ljava/lang/String; - -
 method public toString (Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/modify/BeforeLoadLocal$SearchState 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/modify/BeforeLoadLocal$SearchState org/spongepowered/asm/mixin/injection/modify/BeforeLoadLocal SearchState -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
in 22
class org/spongepowered/asm/mixin/injection/modify/InvalidImplicitDiscriminatorException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context$Local org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context Local public
 method public <init> (ZIILjava/util/Set;Z)V (ZIILjava/util/Set<Ljava/lang/String;>;Z)V -
 method public isArgsOnly ()Z - -
 method public getOrdinal ()I - -
 method public getIndex ()I - -
 method public getNames ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public hasNames ()Z - -
 method public printLVT ()Z - -
 method public toString ()Ljava/lang/String; - -
 method public toString (Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context;)Ljava/lang/String; - -
 method protected isImplicit (Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context;)Z - -
 method public findLocal (Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context;)I - -
 method public,static parse (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator; - -
in 22
class org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context 50 public,super java/lang/Object org/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context$Local org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context Local public
 inner org/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable org/spongepowered/asm/util/PrettyPrinter IPrettyPrintable public,static,interface,abstract
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;ZLorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public getCandidateCount ()I - -
 method public print (Lorg/spongepowered/asm/util/PrettyPrinter;)V - -
in 22
class org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context$Local 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context$Local org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context Local public
 method public <init> (Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context;Ljava/lang/String;Lorg/objectweb/asm/Type;)V - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector 50 public,super org/spongepowered/asm/mixin/injection/code/Injector - -
 inner org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$LocalVariableInjectionPoint org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector LocalVariableInjectionPoint static,abstract
 inner org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$Context org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector Context static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/mixin/injection/code/Injector$InjectorData org/spongepowered/asm/mixin/injection/code/Injector InjectorData public,static
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 inner org/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable org/spongepowered/asm/util/PrettyPrinter IPrettyPrintable public,static,interface,abstract
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator;)V - -
 method protected findTargetNodes (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/injection/InjectionPoint;Lorg/spongepowered/asm/mixin/injection/code/InjectorTarget;Ljava/util/Collection;)Z (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/injection/InjectionPoint;Lorg/spongepowered/asm/mixin/injection/code/InjectorTarget;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method protected sanityCheck (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;)V -
 method protected getTargetNodeKey (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)Ljava/lang/String; - -
 method protected preInject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
 method protected inject (Lorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$Context 50 super org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context - -
 inner org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$Context org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector Context static
 inner org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator$Context org/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator Context public,static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Lorg/objectweb/asm/Type;ZLorg/spongepowered/asm/mixin/injection/struct/Target;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$LocalVariableInjectionPoint 50 super,abstract org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector$LocalVariableInjectionPoint org/spongepowered/asm/mixin/injection/modify/ModifyVariableInjector LocalVariableInjectionPoint static,abstract
 field protected,final mixin Lorg/spongepowered/asm/mixin/refmap/IMixinContext; -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/points/AfterInvoke 50 public,super org/spongepowered/asm/mixin/injection/points/BeforeInvoke - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method protected addInsn (Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;Lorg/objectweb/asm/tree/AbstractInsnNode;)Z (Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;Lorg/objectweb/asm/tree/AbstractInsnNode;)Z -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeConstant 50 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/Constant$Condition org/spongepowered/asm/mixin/injection/Constant Condition public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Selector org/spongepowered/asm/mixin/injection/InjectionPoint Selector public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method protected,varargs log (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeFieldAccess 50 public,super org/spongepowered/asm/mixin/injection/points/BeforeInvoke - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 field public,static,final ARRAY_SEARCH_FUZZ_DEFAULT I - I8
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public getFuzzFactor ()I - -
 method public getArrayOpcode ()I - -
 method protected matchesInsn (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method protected addInsn (Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;Lorg/objectweb/asm/tree/AbstractInsnNode;)Z (Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;Lorg/objectweb/asm/tree/AbstractInsnNode;)Z -
 method public,static findArrayNode (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/FieldInsnNode;II)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeFinalReturn 50 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public checkPriority (II)Z - -
 method public getTargetRestriction (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeInvoke 50 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType org/spongepowered/asm/mixin/injection/points/BeforeInvoke SearchType public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 field protected,final target Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; -
 field protected,final allowPermissive Z -
 field protected,final ordinal I -
 field protected,final className Ljava/lang/String; -
 field protected,final context Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext; -
 field protected,final mixin Lorg/spongepowered/asm/mixin/refmap/IMixinContext; -
 field protected,final logger Lorg/spongepowered/asm/logging/ILogger; -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public setLogging (Z)Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke; - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method protected find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType;)Z -
 method protected addInsn (Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;Lorg/objectweb/asm/tree/AbstractInsnNode;)Z (Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;Lorg/objectweb/asm/tree/AbstractInsnNode;)Z -
 method protected matchesInsn (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method protected inspectInsn (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method protected matchesOrdinal (I)Z - -
 method protected,varargs log (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType;>;
 inner org/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType org/spongepowered/asm/mixin/injection/points/BeforeInvoke SearchType public,static,final,enum
 field public,static,final,enum STRICT Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType; -
 field public,static,final,enum PERMISSIVE Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/points/BeforeInvoke$SearchType; - -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeNew 50 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public hasDescriptor ()Z - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method protected findCtor (Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/TypeInsnNode;)Z - -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeReturn 50 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel org/spongepowered/asm/mixin/injection/InjectionPoint RestrictTargetLevel public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public checkPriority (II)Z - -
 method public getTargetRestriction (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;)Lorg/spongepowered/asm/mixin/injection/InjectionPoint$RestrictTargetLevel; - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/points/BeforeStringInvoke 50 public,super org/spongepowered/asm/mixin/injection/points/BeforeInvoke - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
 method protected inspectInsn (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method protected matchesOrdinal (I)Z - -
in 1180
class org/spongepowered/asm/mixin/injection/points/ConstructorHead 52 public,super org/spongepowered/asm/mixin/injection/points/MethodHead - -
 inner org/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce org/spongepowered/asm/mixin/injection/points/ConstructorHead Enforce static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/code/IInsnListEx$SpecialNodeType org/spongepowered/asm/mixin/injection/code/IInsnListEx SpecialNodeType public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 field protected,final logger Lorg/spongepowered/asm/logging/ILogger; -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 1180
class org/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce;>;
 inner org/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce org/spongepowered/asm/mixin/injection/points/ConstructorHead Enforce static,final,enum
 field public,static,final,enum DEFAULT Lorg/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce; -
 field public,static,final,enum POST_DELEGATE Lorg/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce; -
 field public,static,final,enum POST_INIT Lorg/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce; -
 field public,static,final,enum PRE_BODY Lorg/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/points/ConstructorHead$Enforce; - -
in 22
class org/spongepowered/asm/mixin/injection/points/JumpInsnPoint 50 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/points/MethodHead 50 public,super org/spongepowered/asm/mixin/injection/InjectionPoint - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$AtCode org/spongepowered/asm/mixin/injection/InjectionPoint AtCode public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionPointData;)V - -
 method public checkPriority (II)Z - -
 method public find (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection;)Z (Ljava/lang/String;Lorg/objectweb/asm/tree/InsnList;Ljava/util/Collection<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Z -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode 50 public,super,abstract java/lang/Object - <TNode:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeIterable org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeIterable static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeIterator org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeIterator static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeFieldInsn org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeFieldInsn static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeInvokeDynamicInsn org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeInvokeDynamicInsn static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeMethodInsn org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeMethodInsn static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeField org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeField static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeMethod org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeMethod static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType org/spongepowered/asm/mixin/injection/selectors/ElementNode NodeType public,static,final,enum
 method public <init> ()V - -
 method public isField ()Z - -
 method public,abstract getType ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getField ()Lorg/objectweb/asm/tree/FieldNode; - -
 method public getInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,abstract getOwner ()Ljava/lang/String; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public getSyntheticName ()Ljava/lang/String; - -
 method public,abstract getDesc ()Ljava/lang/String; - -
 method public getDelegateDesc ()Ljava/lang/String; - -
 method public getImplDesc ()Ljava/lang/String; - -
 method public,abstract getSignature ()Ljava/lang/String; - -
 method public,abstract get ()Ljava/lang/Object; ()TTNode; -
 method public toString ()Ljava/lang/String; - -
 method public,static of (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/MethodNode;>; -
 method public,static of (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/FieldNode;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/FieldNode;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/FieldNode;>; -
 method public,static of (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/Object;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode; <TNode:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/ClassNode;TTNode;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>; -
 method public,static of (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode; <TNode:Lorg/objectweb/asm/tree/AbstractInsnNode;>(TTNode;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>; -
 method public,static listOf (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/List;)Ljava/util/List; <TNode:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/ClassNode;Ljava/util/List<TTNode;>;)Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;>; -
 method public,static fieldList (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/FieldNode;>;>; -
 method public,static methodList (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/MethodNode;>;>; -
 method public,static insnList (Lorg/objectweb/asm/tree/InsnList;)Ljava/lang/Iterable; (Lorg/objectweb/asm/tree/InsnList;)Ljava/lang/Iterable<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/AbstractInsnNode;>;>; -
 method public,static dynamicInsnList (Lorg/objectweb/asm/tree/InsnList;)Ljava/lang/Iterable; (Lorg/objectweb/asm/tree/InsnList;)Ljava/lang/Iterable<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/AbstractInsnNode;>;>; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeField 50 super org/spongepowered/asm/mixin/injection/selectors/ElementNode - Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/FieldNode;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeField org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeField static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType org/spongepowered/asm/mixin/injection/selectors/ElementNode NodeType public,static,final,enum
 method public getType ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
 method public isField ()Z - -
 method public getField ()Lorg/objectweb/asm/tree/FieldNode; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getSignature ()Ljava/lang/String; - -
 method public get ()Lorg/objectweb/asm/tree/FieldNode; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeFieldInsn 50 super org/spongepowered/asm/mixin/injection/selectors/ElementNode - Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/FieldInsnNode;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeFieldInsn org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeFieldInsn static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType org/spongepowered/asm/mixin/injection/selectors/ElementNode NodeType public,static,final,enum
 method public getType ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
 method public isField ()Z - -
 method public getInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getSignature ()Ljava/lang/String; - -
 method public get ()Lorg/objectweb/asm/tree/FieldInsnNode; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeInvokeDynamicInsn 50 super org/spongepowered/asm/mixin/injection/selectors/ElementNode - Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/InvokeDynamicInsnNode;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeInvokeDynamicInsn org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeInvokeDynamicInsn static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType org/spongepowered/asm/mixin/injection/selectors/ElementNode NodeType public,static,final,enum
 method public getType ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
 method public isField ()Z - -
 method public getInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getSyntheticName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getDelegateDesc ()Ljava/lang/String; - -
 method public getImplDesc ()Ljava/lang/String; - -
 method public getSignature ()Ljava/lang/String; - -
 method public get ()Lorg/objectweb/asm/tree/InvokeDynamicInsnNode; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeIterable 50 super java/lang/Object java/lang/Iterable Ljava/lang/Object;Ljava/lang/Iterable<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/AbstractInsnNode;>;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeIterable org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeIterable static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeIterator org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeIterator static
 method public <init> (Ljava/lang/Iterable;Z)V (Ljava/lang/Iterable<Lorg/objectweb/asm/tree/AbstractInsnNode;>;Z)V -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/AbstractInsnNode;>;>; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeIterator 50 super java/lang/Object java/util/Iterator Ljava/lang/Object;Ljava/util/Iterator<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/AbstractInsnNode;>;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeIterator org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeIterator static
 method public hasNext ()Z - -
 method public next ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode; ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeMethod 50 super org/spongepowered/asm/mixin/injection/selectors/ElementNode - Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/MethodNode;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeMethod org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeMethod static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType org/spongepowered/asm/mixin/injection/selectors/ElementNode NodeType public,static,final,enum
 method public getType ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getSignature ()Ljava/lang/String; - -
 method public get ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeMethodInsn 50 super org/spongepowered/asm/mixin/injection/selectors/ElementNode - Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<Lorg/objectweb/asm/tree/MethodInsnNode;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$ElementNodeMethodInsn org/spongepowered/asm/mixin/injection/selectors/ElementNode ElementNodeMethodInsn static
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType org/spongepowered/asm/mixin/injection/selectors/ElementNode NodeType public,static,final,enum
 method public getType ()Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
 method public getInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getSignature ()Ljava/lang/String; - -
 method public get ()Lorg/objectweb/asm/tree/MethodInsnNode; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType org/spongepowered/asm/mixin/injection/selectors/ElementNode NodeType public,static,final,enum
 field public,static,final,enum UNDEFINED Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; -
 field public,static,final,enum METHOD Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; -
 field public,static,final,enum FIELD Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; -
 field public,static,final,enum METHOD_INSN Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; -
 field public,static,final,enum FIELD_INSN Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; -
 field public,static,final,enum INVOKEDYNAMIC_INSN Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; -
 field public,final hasMethod Z -
 field public,final hasField Z -
 field public,final hasInsn Z -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode$NodeType; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ISelectorContext 50 public,interface,abstract java/lang/Object - -
 method public,abstract getParent ()Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext; - -
 method public,abstract getMixin ()Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public,abstract getMethod ()Ljava/lang/Object; - -
 method public,abstract getAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public,abstract getSelectorAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public,abstract getSelectorCoordinate (Z)Ljava/lang/String; - -
 method public,abstract remap (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelector 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 method public,abstract next ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,varargs,abstract configure (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure;[Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,abstract validate ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public,abstract attach (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public,abstract getMinMatchCount ()I - -
 method public,abstract getMaxMatchCount ()I - -
 method public,abstract match (Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; <TNode:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 field public,static,final,enum SELECT_MEMBER Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; -
 field public,static,final,enum SELECT_INSTRUCTION Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; -
 field public,static,final,enum MOVE Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; -
 field public,static,final,enum ORPHAN Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; -
 field public,static,final,enum TRANSFORM Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; -
 field public,static,final,enum PERMISSIVE Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; -
 field public,static,final,enum CLEAR_LIMITS Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure; - -
 method public,varargs checkArgs ([Ljava/lang/String;)V - java/lang/IllegalArgumentException
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName 50 public,interface,abstract java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelector -
 method public,abstract getOwner ()Ljava/lang/String; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getDesc ()Ljava/lang/String; - -
 method public,abstract toDescriptor ()Ljava/lang/String; - -
 method public,abstract matches (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorConstructor 50 public,interface,abstract java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName -
 method public,abstract toCtorType ()Ljava/lang/String; - -
 method public,abstract toCtorDesc ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic 50 public,interface,abstract java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelector -
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorAnnotation org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorAnnotation public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorId org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorId public,static,interface,abstract,annotation
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorAnnotation 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorAnnotation org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorAnnotation public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorId 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorId org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorId public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract namespace ()Ljava/lang/String; - - ""
 method public,abstract value ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable 50 public,interface,abstract java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName -
 method public,abstract isFullyQualified ()Z - -
 method public,abstract isField ()Z - -
 method public,abstract isConstructor ()Z - -
 method public,abstract isClassInitialiser ()Z - -
 method public,abstract isInitialiser ()Z - -
 method public,abstract asMapping ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping; ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>; -
 method public,abstract asMethodMapping ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public,abstract asFieldMapping ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public,abstract move (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public,abstract transform (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public,abstract remapUsing (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Z)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/InvalidSelector 50 public,super java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelector -
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public next ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,varargs configure (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure;[Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public validate ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public attach (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public getMinMatchCount ()I - -
 method public getMaxMatchCount ()I - -
 method public match (Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; <TNode:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/MatchResult 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult;>;
 field public,static,final,enum NONE Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
 field public,static,final,enum WEAK Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
 field public,static,final,enum MATCH Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
 field public,static,final,enum EXACT_MATCH Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; - -
 method public isAtLeast (Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult;)Z - -
 method public isMatch ()Z - -
 method public isExactMatch ()Z - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/MemberMatcher 50 public,final,super java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelector -
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 method public,static parse (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/MemberMatcher; - -
 method public validate ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public toString ()Ljava/lang/String; - -
 method public next ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,varargs configure (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure;[Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public attach (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public getMinMatchCount ()I - -
 method public getMaxMatchCount ()I - -
 method public match (Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; <TNode:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/TargetSelector 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelector$DynamicSelectorEntry org/spongepowered/asm/mixin/injection/selectors/TargetSelector DynamicSelectorEntry static
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result org/spongepowered/asm/mixin/injection/selectors/TargetSelector Result public,static
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorId org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorId public,static,interface,abstract,annotation
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 method public,static register (Ljava/lang/Class;Ljava/lang/String;)V (Ljava/lang/Class<+Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic;>;Ljava/lang/String;)V -
 method public,static parseAndValidate (Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public,static parseAndValidate (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public,static parseAndValidate (Ljava/lang/Iterable;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/util/Set; (Ljava/lang/Iterable<*>;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;>; org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public,static parse (Ljava/lang/Iterable;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/util/Set; (Ljava/lang/Iterable<*>;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;>; -
 method public,static parse (Ljava/lang/Iterable;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/util/Set;)Ljava/util/Set; (Ljava/lang/Iterable<*>;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;>;)Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;>; -
 method public,static parse (Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,static parse (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,static parseName (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Ljava/lang/String; - -
 method public,static run (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/Iterable;)Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result; <TNode:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/Iterable<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;>;)Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result<TTNode;>; -
 method public,static run (Ljava/lang/Iterable;Ljava/lang/Iterable;)Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result; <TNode:Ljava/lang/Object;>(Ljava/lang/Iterable<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;>;Ljava/lang/Iterable<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;>;)Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result<TTNode;>; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/TargetSelector$DynamicSelectorEntry 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelector$DynamicSelectorEntry org/spongepowered/asm/mixin/injection/selectors/TargetSelector DynamicSelectorEntry static
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorAnnotation org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorAnnotation public,static,interface,abstract,annotation
in 22
class org/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result 50 public,super java/lang/Object - <TNode:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result org/spongepowered/asm/mixin/injection/selectors/TargetSelector Result public,static
 field public,final exactMatch Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode; Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;
 field public,final candidates Ljava/util/List; Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;>;
 method public getSingleResult (Z)Ljava/lang/Object; (Z)TTNode; -
in 1180
class org/spongepowered/asm/mixin/injection/selectors/TargetSelectors 52 public,super java/lang/Object java/lang/Iterable Ljava/lang/Object;Ljava/lang/Iterable<Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod;>;
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod org/spongepowered/asm/mixin/injection/selectors/TargetSelectors SelectedMethod public,static
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelector$Result org/spongepowered/asm/mixin/injection/selectors/TargetSelector Result public,static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public parse (Ljava/util/Set;)V (Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;>;)V -
 method public addSelector (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;)Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelectors; - -
 method public size ()I - -
 method public clear ()V - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod;>; -
 method public remove (Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod;)V - -
 method public isPermissivePassEnabled ()Z - -
 method public setPermissivePass (Z)Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelectors; - -
 method public find ()V - -
 method protected findNestedTargets ()V - -
 method public validate (II)V - -
in 1180
class org/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod org/spongepowered/asm/mixin/injection/selectors/TargetSelectors SelectedMethod public,static
 method public toString ()Ljava/lang/String; - -
 method public getParent ()Lorg/spongepowered/asm/mixin/injection/selectors/TargetSelectors$SelectedMethod; - -
 method public next ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverDebug org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver ResolverObserverDebug static
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverBasic org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver ResolverObserverBasic static
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$IResolverObserver org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver IResolverObserver static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$Descriptor org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver Descriptor static,final
 field public,static PRINT_ID Ljava/lang/String; -
 method public,static resolve (Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/IResolvedDescriptor; - -
 method public,static resolve (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/IResolvedDescriptor; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$Descriptor 50 final,super java/lang/Object org/spongepowered/asm/mixin/injection/selectors/dynamic/IResolvedDescriptor -
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$Descriptor org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver Descriptor static,final
 method public isResolved ()Z - -
 method public getResolutionInfo ()Ljava/lang/String; - -
 method public getAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getId ()Ljava/lang/String; - -
 method public getOwner ()Lorg/objectweb/asm/Type; - -
 method public getName ()Ljava/lang/String; - -
 method public getArgs ()[Lorg/objectweb/asm/Type; - -
 method public getReturnType ()Lorg/objectweb/asm/Type; - -
 method public getMatches ()Lorg/spongepowered/asm/util/Quantifier; - -
 method public getNext ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/util/asm/IAnnotationHandle;>; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$IResolverObserver 50 interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$IResolverObserver org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver IResolverObserver static,interface,abstract
 method public,abstract visit (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)V - -
 method public,abstract getSearched ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract postResolve ()V - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverBasic 50 super java/lang/Object org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$IResolverObserver -
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverBasic org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver ResolverObserverBasic static
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$IResolverObserver org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver IResolverObserver static,interface,abstract
 method public visit (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)V - -
 method public getSearched ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public postResolve ()V - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverDebug 50 super org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverBasic - -
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverDebug org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver ResolverObserverDebug static
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver$ResolverObserverBasic org/spongepowered/asm/mixin/injection/selectors/dynamic/DescriptorResolver ResolverObserverBasic static
 method public visit (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)V - -
 method public postResolve ()V - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc 50 public,super java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic,org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName -
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc$Next org/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc Next final
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorId org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorId public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic$SelectorAnnotation org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorDynamic SelectorAnnotation public,static,interface,abstract,annotation
 method protected <init> (Lorg/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException;Ljava/lang/String;Lorg/objectweb/asm/Type;Ljava/lang/String;[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Lorg/spongepowered/asm/util/Quantifier;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException;Ljava/lang/String;Lorg/objectweb/asm/Type;Ljava/lang/String;[Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Lorg/spongepowered/asm/util/Quantifier;Ljava/util/List<Lorg/spongepowered/asm/util/asm/IAnnotationHandle;>;)V -
 method public,static parse (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc; - -
 method public,static parse (Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc; - -
 method public,static resolve (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc; - -
 method public,static of (Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc; - -
 method public,static of (Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/IResolvedDescriptor;)Lorg/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc; - -
 method public toString ()Ljava/lang/String; - -
 method public getId ()Ljava/lang/String; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getArgs ()[Lorg/objectweb/asm/Type; - -
 method public getReturnType ()Lorg/objectweb/asm/Type; - -
 method public getDesc ()Ljava/lang/String; - -
 method public toDescriptor ()Ljava/lang/String; - -
 method public validate ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public next ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method protected next (I)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public,varargs configure (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure;[Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public attach (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public getMinMatchCount ()I - -
 method public getMaxMatchCount ()I - -
 method public matches (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; - -
 method public match (Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; <TNode:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc$Next 50 final,super org/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc - -
 inner org/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc$Next org/spongepowered/asm/mixin/injection/selectors/dynamic/DynamicSelectorDesc Next final
 method public next ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/dynamic/IResolvedDescriptor 50 public,interface,abstract java/lang/Object - -
 method public,abstract isResolved ()Z - -
 method public,abstract getAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public,abstract getResolutionInfo ()Ljava/lang/String; - -
 method public,abstract getId ()Ljava/lang/String; - -
 method public,abstract getOwner ()Lorg/objectweb/asm/Type; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getArgs ()[Lorg/objectweb/asm/Type; - -
 method public,abstract getReturnType ()Lorg/objectweb/asm/Type; - -
 method public,abstract getMatches ()Lorg/spongepowered/asm/util/Quantifier; - -
 method public,abstract getNext ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/util/asm/IAnnotationHandle;>; -
in 22
class org/spongepowered/asm/mixin/injection/selectors/throwables/SelectorConstraintException 50 public,super org/spongepowered/asm/mixin/injection/selectors/throwables/SelectorException - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/injection/selectors/throwables/SelectorException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getSelector ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
in 1180
class org/spongepowered/asm/mixin/injection/struct/ArgOffsets 52 public,super java/lang/Object org/spongepowered/asm/mixin/injection/struct/IChainedDecoration Ljava/lang/Object;Lorg/spongepowered/asm/mixin/injection/struct/IChainedDecoration<Lorg/spongepowered/asm/mixin/injection/struct/ArgOffsets;>;
 inner org/spongepowered/asm/mixin/injection/struct/ArgOffsets$Default org/spongepowered/asm/mixin/injection/struct/ArgOffsets Default private,static
 field public,static DEFAULT Lorg/spongepowered/asm/mixin/injection/struct/ArgOffsets; -
 field public,static,final KEY Ljava/lang/String; - "argOffsets"
 method public <init> (II)V - -
 method public toString ()Ljava/lang/String; - -
 method public replace (Lorg/spongepowered/asm/mixin/injection/struct/ArgOffsets;)V - -
 method public getLength ()I - -
 method public isEmpty ()Z - -
 method public getStartIndex ()I - -
 method public getEndIndex ()I - -
 method public getArgIndex (I)I - -
 method public getArgIndex (IZ)I - -
 method public apply ([Lorg/objectweb/asm/Type;)[Lorg/objectweb/asm/Type; - -
in 1180
class org/spongepowered/asm/mixin/injection/struct/ArgOffsets$Default 52 super org/spongepowered/asm/mixin/injection/struct/ArgOffsets - -
 inner org/spongepowered/asm/mixin/injection/struct/ArgOffsets$Default org/spongepowered/asm/mixin/injection/struct/ArgOffsets Default private,static
 method public <init> ()V - -
 method public getArgIndex (I)I - -
 method public apply ([Lorg/objectweb/asm/Type;)[Lorg/objectweb/asm/Type; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/CallbackInjectionInfo 50 public,super org/spongepowered/asm/mixin/injection/struct/InjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public getSliceId (Ljava/lang/String;)Ljava/lang/String; - -
in 1180
class org/spongepowered/asm/mixin/injection/struct/Constructor 52 public,super org/spongepowered/asm/mixin/injection/struct/Target - -
 inner org/spongepowered/asm/util/Bytecode$DelegateInitialiser org/spongepowered/asm/util/Bytecode DelegateInitialiser public,static
 inner org/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode org/spongepowered/asm/mixin/transformer/struct/Initialiser InjectionMode public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public findDelegateInitNode ()Lorg/spongepowered/asm/util/Bytecode$DelegateInitialiser; - -
 method public isInjectable ()Z - -
 method public inspect (Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser;)V - -
 method public findInitialiserInjectionPoint (Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode;)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public findFirstBodyInsn ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,static getRange (Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/mixin/transformer/struct/InsnRange; - -
in 1180
class org/spongepowered/asm/mixin/injection/struct/IChainedDecoration 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract replace (Ljava/lang/Object;)V (TT;)V -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionInfo 50 public,super,abstract org/spongepowered/asm/mixin/struct/SpecialMethodInfo org/spongepowered/asm/mixin/injection/code/ISliceContext -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$SelectedTarget org/spongepowered/asm/mixin/injection/struct/InjectionInfo SelectedTarget static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$InjectorEntry org/spongepowered/asm/mixin/injection/struct/InjectionInfo InjectorEntry static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo$Map org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo Map public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 field public,static,final DEFAULT_PREFIX Ljava/lang/String; - "handler"
 field protected,final isStatic Z -
 field protected,final selectors Ljava/util/Set; Ljava/util/Set<Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;>;
 field protected,final targets Ljava/util/List; Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo$SelectedTarget;>;
 field protected,final slices Lorg/spongepowered/asm/mixin/injection/code/MethodSlices; -
 field protected,final atKey Ljava/lang/String; -
 field protected,final injectionPoints Ljava/util/List; Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/InjectionPoint;>;
 field protected,final targetNodes Ljava/util/Map; Ljava/util/Map<Lorg/spongepowered/asm/mixin/injection/struct/Target;Ljava/util/List<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;>;
 field protected targetCount I -
 field protected injector Lorg/spongepowered/asm/mixin/injection/code/Injector; -
 field protected group Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; -
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)V - -
 method protected readAnnotation ()V - -
 method protected parseSelectors ()V - -
 method protected readInjectionPoints ()Ljava/util/List; ()Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>; -
 method protected parseInjectionPoints (Ljava/util/List;)V (Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;)V -
 method protected parseRequirements ()V - -
 method protected,abstract parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method public isValid ()Z - -
 method public prepare ()V - -
 method public preInject ()V - -
 method public inject ()V - -
 method public postInject ()V - -
 method public notifyInjected (Lorg/spongepowered/asm/mixin/injection/struct/Target;)V - -
 method protected getDescription ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public getTargetCount ()I - -
 method public getSlice (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/code/MethodSlice; - -
 method public getSliceId (Ljava/lang/String;)Ljava/lang/String; - -
 method public getInjectedCallbackCount ()I - -
 method public addMethod (ILjava/lang/String;Ljava/lang/String;)Lorg/objectweb/asm/tree/MethodNode; - -
 method public addCallbackInvocation (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public,varargs addMessage (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method protected getMessages ()Ljava/lang/String; - -
 method protected findTargets ()V - -
 method protected validateTargets ()V - -
 method protected checkTarget (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected getDynamicInfo ()Ljava/lang/String; - -
 method public,static parse (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo; - -
 method public,static getInjectorAnnotation (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/objectweb/asm/tree/MethodNode;)Lorg/objectweb/asm/tree/AnnotationNode; - -
 method public,static getInjectorPrefix (Lorg/objectweb/asm/tree/AnnotationNode;)Ljava/lang/String; - -
 method public,static register (Ljava/lang/Class;)V (Ljava/lang/Class<+Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;>;)V -
 method public,static getRegisteredAnnotations ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;>; -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionInfo$InjectorEntry 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$InjectorEntry org/spongepowered/asm/mixin/injection/struct/InjectionInfo InjectorEntry static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
in 1180
class org/spongepowered/asm/mixin/injection/struct/InjectionInfo$InjectorOrder 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$InjectorOrder org/spongepowered/asm/mixin/injection/struct/InjectionInfo InjectorOrder public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 field public,static,final EARLY I - I0
 field public,static,final DEFAULT I - I1000
 field public,static,final LATE I - I2000
 field public,static,final REDIRECT I - I10000
 field public,static,final AFTER_REDIRECT I - I20000
 method public,abstract value ()I - - I1000
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionInfo$SelectedTarget 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$SelectedTarget org/spongepowered/asm/mixin/injection/struct/InjectionInfo SelectedTarget static
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionNodes 50 public,super java/util/ArrayList - Ljava/util/ArrayList<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public <init> ()V - -
 method public add (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
 method public get (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
 method public contains (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public replace (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public remove (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode 50 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;>;
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 method public <init> (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public getId ()I - -
 method public getOriginalTarget ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public getCurrentTarget ()Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public replace (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
 method public remove ()Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
 method public matches (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public isReplaced ()Z - -
 method public isRemoved ()Z - -
 method public decorate (Ljava/lang/String;Ljava/lang/Object;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; <V:Ljava/lang/Object;>(Ljava/lang/String;TV;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; -
 method public hasDecoration (Ljava/lang/String;)Z - -
 method public getDecoration (Ljava/lang/String;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;)TV; -
 method public compareTo (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)I - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionPointAnnotationContext 50 public,super org/spongepowered/asm/mixin/injection/struct/SelectorAnnotationContext org/spongepowered/asm/mixin/injection/IInjectionPointContext -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)V - -
 method public,varargs addMessage (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getAnnotationNode ()Lorg/objectweb/asm/tree/AnnotationNode; - -
 method public getAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectionPointData 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/InjectionPoint$Selector org/spongepowered/asm/mixin/injection/InjectionPoint Selector public,static,final,enum
 inner org/spongepowered/asm/util/Annotations$Handle org/spongepowered/asm/util/Annotations Handle public,static
 method public <init> (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;)V (Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext;Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;)V -
 method public getMessageSink ()Lorg/spongepowered/asm/util/IMessageSink; - -
 method public getAt ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getSelector ()Lorg/spongepowered/asm/mixin/injection/InjectionPoint$Selector; - -
 method public getContext ()Lorg/spongepowered/asm/mixin/injection/IInjectionPointContext; - -
 method public getMixin ()Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getMethodReturnType ()Lorg/objectweb/asm/Type; - -
 method public getParent ()Lorg/objectweb/asm/tree/AnnotationNode; - -
 method public getSlice ()Ljava/lang/String; - -
 method public getLocalVariableDiscriminator ()Lorg/spongepowered/asm/mixin/injection/modify/LocalVariableDiscriminator; - -
 method public get (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public get (Ljava/lang/String;I)I - -
 method public get (Ljava/lang/String;Z)Z - -
 method public get (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public getTarget ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getOrdinal ()I - -
 method public getOpcode ()I - -
 method public getOpcode (I)I - -
 method public,varargs getOpcode (I[I)I - -
 method public getId ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static parseType (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo$Map org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo Map public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isDefault ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public getMinRequired ()I - -
 method public getMaxAllowed ()I - -
 method public getMembers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;>; -
 method public setMinRequired (I)V - -
 method public setMaxAllowed (I)V - -
 method public add (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;)Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; - -
 method public validate ()Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; - org/spongepowered/asm/mixin/injection/throwables/InjectionValidationException
in 22
class org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo$Map 50 public,final,super java/util/HashMap - Ljava/util/HashMap<Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo;>;
 inner org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo$Map org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo Map public,static,final
 method public <init> ()V - -
 method public get (Ljava/lang/Object;)Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; - -
 method public forName (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; - -
 method public parseGroup (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; - -
 method public parseGroup (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; - -
 method public validateAll ()V - org/spongepowered/asm/mixin/injection/throwables/InjectionValidationException
in 22
class org/spongepowered/asm/mixin/injection/struct/InvalidMemberDescriptorException 50 public,super org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getInput ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/MemberInfo 50 public,final,super java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable,org/spongepowered/asm/mixin/injection/selectors/ITargetSelectorConstructor -
 inner org/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure org/spongepowered/asm/mixin/injection/selectors/ITargetSelector Configure public,static,final,enum
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/util/Quantifier;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/util/Quantifier;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/util/Quantifier;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/util/Quantifier;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/util/Quantifier;Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public <init> (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)V (Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)V -
 method public next ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getMinMatchCount ()I - -
 method public getMaxMatchCount ()I - -
 method public toString ()Ljava/lang/String; - -
 method public,deprecated toSrg ()Ljava/lang/String; - -
 method public toDescriptor ()Ljava/lang/String; - -
 method public toCtorType ()Ljava/lang/String; - -
 method public toCtorDesc ()Ljava/lang/String; - -
 method public asMapping ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping; ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>; -
 method public asMethodMapping ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public asFieldMapping ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public isFullyQualified ()Z - -
 method public isField ()Z - -
 method public isConstructor ()Z - -
 method public isClassInitialiser ()Z - -
 method public isInitialiser ()Z - -
 method public validate ()Lorg/spongepowered/asm/mixin/injection/struct/MemberInfo; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public match (Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; <TNode:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ElementNode<TTNode;>;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; -
 method public matches (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/MatchResult; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,varargs configure (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector$Configure;[Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - -
 method public attach (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector; - org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException
 method public move (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public transform (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public remapUsing (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Z)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public,static parse (Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)Lorg/spongepowered/asm/mixin/injection/struct/MemberInfo; - -
 method public,static fromMapping (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)Lorg/spongepowered/asm/mixin/injection/struct/MemberInfo; (Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)Lorg/spongepowered/asm/mixin/injection/struct/MemberInfo; -
in 22
class org/spongepowered/asm/mixin/injection/struct/ModifyArgInjectionInfo 50 public,super org/spongepowered/asm/mixin/injection/struct/InjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method protected getDescription ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/ModifyArgsInjectionInfo 50 public,super org/spongepowered/asm/mixin/injection/struct/InjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method protected getDescription ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/ModifyConstantInjectionInfo 50 public,super org/spongepowered/asm/mixin/injection/struct/InjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected readInjectionPoints ()Ljava/util/List; ()Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>; -
 method protected parseInjectionPoints (Ljava/util/List;)V (Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;)V -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method protected getDescription ()Ljava/lang/String; - -
 method public getSliceId (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/ModifyVariableInjectionInfo 50 public,super org/spongepowered/asm/mixin/injection/struct/InjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method protected getDescription ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/RedirectInjectionInfo 50 public,super org/spongepowered/asm/mixin/injection/struct/InjectionInfo - -
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$AnnotationType org/spongepowered/asm/mixin/injection/struct/InjectionInfo AnnotationType public,static,interface,abstract,annotation
 inner org/spongepowered/asm/mixin/injection/struct/InjectionInfo$HandlerPrefix org/spongepowered/asm/mixin/injection/struct/InjectionInfo HandlerPrefix public,static,interface,abstract,annotation
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected parseInjector (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/mixin/injection/code/Injector; - -
 method protected getDescription ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/SelectorAnnotationContext 50 public,super java/lang/Object org/spongepowered/asm/mixin/injection/selectors/ISelectorContext -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/lang/String;)V - -
 method public getParent ()Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext; - -
 method public getMixin ()Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public getMethod ()Ljava/lang/Object; - -
 method public getAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getSelectorAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getSelectorCoordinate (Z)Ljava/lang/String; - -
 method public remap (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/injection/struct/Target 50 public,super java/lang/Object java/lang/Comparable,java/lang/Iterable Ljava/lang/Object;Ljava/lang/Comparable<Lorg/spongepowered/asm/mixin/injection/struct/Target;>;Ljava/lang/Iterable<Lorg/objectweb/asm/tree/AbstractInsnNode;>;
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 inner org/spongepowered/asm/util/Bytecode$DelegateInitialiser org/spongepowered/asm/util/Bytecode DelegateInitialiser public,static
 inner org/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode org/spongepowered/asm/mixin/injection/struct/InjectionNodes InjectionNode public,static
 inner org/spongepowered/asm/util/Locals$SyntheticLocalVariableNode org/spongepowered/asm/util/Locals SyntheticLocalVariableNode public,static
 field public,final classNode Lorg/objectweb/asm/tree/ClassNode; -
 field public,final method Lorg/objectweb/asm/tree/MethodNode; -
 field public,final insns Lorg/objectweb/asm/tree/InsnList; -
 field public,final isStatic Z -
 field public,final isCtor Z -
 field public,final arguments [Lorg/objectweb/asm/Type; -
 field public,final returnType Lorg/objectweb/asm/Type; -
 method public <init> (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public addInjectionNode (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
 method public getInjectionNode (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode; - -
 method public getMaxLocals ()I - -
 method public getMaxStack ()I - -
 method public getCurrentMaxLocals ()I - -
 method public getCurrentMaxStack ()I - -
 method public allocateLocal ()I - -
 method public allocateLocals (I)I - -
 method public extendLocals ()Lorg/spongepowered/asm/mixin/injection/struct/Target$Extension; - -
 method public extendStack ()Lorg/spongepowered/asm/mixin/injection/struct/Target$Extension; - -
 method public generateArgMap ([Lorg/objectweb/asm/Type;I)[I - -
 method public getArgIndices ()[I - -
 method public getCallbackInfoClass ()Ljava/lang/String; - -
 method public getSimpleCallbackDescriptor ()Ljava/lang/String; - -
 method public getCallbackDescriptor ([Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public getCallbackDescriptor (Z[Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;II)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public compareTo (Lorg/spongepowered/asm/mixin/injection/struct/Target;)I - -
 method public indexOf (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;)I - -
 method public indexOf (Lorg/objectweb/asm/tree/AbstractInsnNode;)I - -
 method public get (I)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public findInitNodeFor (Lorg/objectweb/asm/tree/TypeInsnNode;)Lorg/objectweb/asm/tree/MethodInsnNode; - -
 method public findDelegateInitNode ()Lorg/spongepowered/asm/util/Bytecode$DelegateInitialiser; - -
 method public insertBefore (Lorg/spongepowered/asm/mixin/injection/struct/InjectionNodes$InjectionNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public insertBefore (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public replaceNode (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public replaceNode (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public wrapNode (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public replaceNode (Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/InsnList;)V - -
 method public removeNode (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public addLocalVariable (ILjava/lang/String;Ljava/lang/String;)V - -
 method public addLocalVariable (ILjava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/tree/LabelNode;Lorg/objectweb/asm/tree/LabelNode;)V - -
in 22
class org/spongepowered/asm/mixin/injection/struct/Target$Extension 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/injection/struct/Target$Extension org/spongepowered/asm/mixin/injection/struct/Target Extension public
 method public add ()Lorg/spongepowered/asm/mixin/injection/struct/Target$Extension; - -
 method public add (I)Lorg/spongepowered/asm/mixin/injection/struct/Target$Extension; - -
 method public add ([Lorg/objectweb/asm/Type;)Lorg/spongepowered/asm/mixin/injection/struct/Target$Extension; - -
 method public set (I)Lorg/spongepowered/asm/mixin/injection/struct/Target$Extension; - -
 method public get ()I - -
 method public apply ()V - -
in 22
class org/spongepowered/asm/mixin/injection/struct/TargetNotSupportedException 50 public,super org/spongepowered/asm/mixin/injection/selectors/InvalidSelectorException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/injection/throwables/InjectionError 50 public,super org/spongepowered/asm/mixin/throwables/MixinError - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/injection/throwables/InjectionValidationException 50 public,super java/lang/Exception - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo;Ljava/lang/String;)V - -
 method public getGroup ()Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo; - -
in 22
class org/spongepowered/asm/mixin/injection/throwables/InvalidInjectionException 50 public,super org/spongepowered/asm/mixin/transformer/throwables/InvalidMixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public getContext ()Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext; - -
in 22
class org/spongepowered/asm/mixin/injection/throwables/InvalidInjectionPointException 50 public,super org/spongepowered/asm/mixin/injection/throwables/InvalidInjectionException - -
 method public,varargs <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,varargs <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,varargs <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,varargs <init> (Lorg/spongepowered/asm/mixin/injection/struct/InjectionInfo;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/mixin/injection/throwables/InvalidSliceException 50 public,super org/spongepowered/asm/mixin/injection/throwables/InvalidInjectionException - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/code/ISliceContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/code/ISliceContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/code/ISliceContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 1177
class org/spongepowered/asm/mixin/refmap/IClassReferenceMapper 50 public,interface,abstract java/lang/Object - -
 method public,abstract remapClassName (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract remapClassNameWithContext (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 1180
class org/spongepowered/asm/mixin/refmap/IClassReferenceMapper 52 public,interface,abstract java/lang/Object - -
 method public,abstract remapClassName (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract remapClassNameWithContext (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/refmap/IMixinContext 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public,abstract getMixin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
 method public,abstract getExtensions ()Lorg/spongepowered/asm/mixin/transformer/ext/Extensions; - -
 method public,abstract getClassName ()Ljava/lang/String; - -
 method public,abstract getClassRef ()Ljava/lang/String; - -
 method public,abstract getTargetClassRef ()Ljava/lang/String; - -
 method public,abstract getReferenceMapper ()Lorg/spongepowered/asm/mixin/refmap/IReferenceMapper; - -
 method public,abstract getOption (Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;)Z - -
 method public,abstract getPriority ()I - -
in 22
class org/spongepowered/asm/mixin/refmap/IReferenceMapper 50 public,interface,abstract java/lang/Object - -
 method public,abstract isDefault ()Z - -
 method public,abstract getResourceName ()Ljava/lang/String; - -
 method public,abstract getStatus ()Ljava/lang/String; - -
 method public,abstract getContext ()Ljava/lang/String; - -
 method public,abstract setContext (Ljava/lang/String;)V - -
 method public,abstract remap (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract remapWithContext (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/refmap/ReferenceMapper 50 public,final,super java/lang/Object org/spongepowered/asm/mixin/refmap/IReferenceMapper,java/io/Serializable -
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 field public,static,final DEFAULT_RESOURCE Ljava/lang/String; - "mixin.refmap.json"
 field public,static,final DEFAULT_MAPPER Lorg/spongepowered/asm/mixin/refmap/ReferenceMapper; -
 method public <init> ()V - -
 method public isDefault ()Z - -
 method public getResourceName ()Ljava/lang/String; - -
 method public getStatus ()Ljava/lang/String; - -
 method public getContext ()Ljava/lang/String; - -
 method public setContext (Ljava/lang/String;)V - -
 method public remap (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public remapWithContext (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public addMapping (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public write (Ljava/lang/Appendable;)V - -
 method public,static read (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/refmap/ReferenceMapper; - -
 method public,static read (Ljava/io/Reader;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/refmap/ReferenceMapper; - -
in 22
class org/spongepowered/asm/mixin/refmap/RemappingReferenceMapper 50 public,final,super java/lang/Object org/spongepowered/asm/mixin/refmap/IReferenceMapper -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public isDefault ()Z - -
 method public getResourceName ()Ljava/lang/String; - -
 method public getStatus ()Ljava/lang/String; - -
 method public getContext ()Ljava/lang/String; - -
 method public setContext (Ljava/lang/String;)V - -
 method public remap (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public remapWithContext (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static of (Lorg/spongepowered/asm/mixin/MixinEnvironment;Lorg/spongepowered/asm/mixin/refmap/IReferenceMapper;)Lorg/spongepowered/asm/mixin/refmap/IReferenceMapper; - -
in 22
class org/spongepowered/asm/mixin/struct/AnnotatedMethodInfo 50 public,super java/lang/Object org/spongepowered/asm/mixin/injection/IInjectionPointContext -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 field protected,final method Lorg/objectweb/asm/tree/MethodNode; -
 field protected,final annotation Lorg/objectweb/asm/tree/AnnotationNode; -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method public remap (Ljava/lang/String;)Ljava/lang/String; - -
 method public getParent ()Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext; - -
 method public,final getMixin ()Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public,final getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getMethodName ()Ljava/lang/String; - -
 method public getAnnotationNode ()Lorg/objectweb/asm/tree/AnnotationNode; - -
 method public,final getAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getSelectorAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getSelectorCoordinate (Z)Ljava/lang/String; - -
 method public,varargs addMessage (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/mixin/struct/MemberRef 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/struct/MemberRef$Handle org/spongepowered/asm/mixin/struct/MemberRef Handle public,static,final
 inner org/spongepowered/asm/mixin/struct/MemberRef$Field org/spongepowered/asm/mixin/struct/MemberRef Field public,static,final
 inner org/spongepowered/asm/mixin/struct/MemberRef$Method org/spongepowered/asm/mixin/struct/MemberRef Method public,static,final
 method public <init> ()V - -
 method public,abstract isField ()Z - -
 method public,abstract getOpcode ()I - -
 method public,abstract setOpcode (I)V - -
 method public,abstract getOwner ()Ljava/lang/String; - -
 method public,abstract setOwner (Ljava/lang/String;)V - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract setName (Ljava/lang/String;)V - -
 method public,abstract getDesc ()Ljava/lang/String; - -
 method public,abstract setDesc (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/struct/MemberRef$Field 50 public,final,super org/spongepowered/asm/mixin/struct/MemberRef - -
 inner org/spongepowered/asm/mixin/struct/MemberRef$Field org/spongepowered/asm/mixin/struct/MemberRef Field public,static,final
 field public,final insn Lorg/objectweb/asm/tree/FieldInsnNode; -
 method public <init> (Lorg/objectweb/asm/tree/FieldInsnNode;)V - -
 method public isField ()Z - -
 method public getOpcode ()I - -
 method public setOpcode (I)V - -
 method public getOwner ()Ljava/lang/String; - -
 method public setOwner (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public getDesc ()Ljava/lang/String; - -
 method public setDesc (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/mixin/struct/MemberRef$Handle 50 public,final,super org/spongepowered/asm/mixin/struct/MemberRef - -
 inner org/spongepowered/asm/mixin/struct/MemberRef$Handle org/spongepowered/asm/mixin/struct/MemberRef Handle public,static,final
 method public <init> (Lorg/objectweb/asm/Handle;)V - -
 method public getMethodHandle ()Lorg/objectweb/asm/Handle; - -
 method public isField ()Z - -
 method public getOpcode ()I - -
 method public setOpcode (I)V - -
 method public getOwner ()Ljava/lang/String; - -
 method public setOwner (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public getDesc ()Ljava/lang/String; - -
 method public setDesc (Ljava/lang/String;)V - -
 method public setHandle (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V - -
in 22
class org/spongepowered/asm/mixin/struct/MemberRef$Method 50 public,final,super org/spongepowered/asm/mixin/struct/MemberRef - -
 inner org/spongepowered/asm/mixin/struct/MemberRef$Method org/spongepowered/asm/mixin/struct/MemberRef Method public,static,final
 field public,final insn Lorg/objectweb/asm/tree/MethodInsnNode; -
 method public <init> (Lorg/objectweb/asm/tree/MethodInsnNode;)V - -
 method public isField ()Z - -
 method public getOpcode ()I - -
 method public setOpcode (I)V - -
 method public getOwner ()Ljava/lang/String; - -
 method public setOwner (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public getDesc ()Ljava/lang/String; - -
 method public setDesc (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/mixin/struct/SourceMap 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/struct/SourceMap$Stratum org/spongepowered/asm/mixin/struct/SourceMap Stratum static
 inner org/spongepowered/asm/mixin/struct/SourceMap$File org/spongepowered/asm/mixin/struct/SourceMap File public,static
 method public <init> (Ljava/lang/String;)V - -
 method public getSourceFile ()Ljava/lang/String; - -
 method public getPseudoGeneratedSourceFile ()Ljava/lang/String; - -
 method public addFile (Lorg/objectweb/asm/tree/ClassNode;)Lorg/spongepowered/asm/mixin/struct/SourceMap$File; - -
 method public addFile (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Lorg/spongepowered/asm/mixin/struct/SourceMap$File; - -
 method public addFile (Ljava/lang/String;Ljava/lang/String;I)Lorg/spongepowered/asm/mixin/struct/SourceMap$File; - -
 method public addFile (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Lorg/spongepowered/asm/mixin/struct/SourceMap$File; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/struct/SourceMap$File 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/struct/SourceMap$File org/spongepowered/asm/mixin/struct/SourceMap File public,static
 field public,final id I -
 field public,final lineOffset I -
 field public,final size I -
 field public,final sourceFileName Ljava/lang/String; -
 field public,final sourceFilePath Ljava/lang/String; -
 method public <init> (IIILjava/lang/String;)V - -
 method public <init> (IIILjava/lang/String;Ljava/lang/String;)V - -
 method public applyOffset (Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public applyOffset (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public appendLines (Ljava/lang/StringBuilder;)V - -
in 22
class org/spongepowered/asm/mixin/struct/SourceMap$Stratum 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/struct/SourceMap$File org/spongepowered/asm/mixin/struct/SourceMap File public,static
 inner org/spongepowered/asm/mixin/struct/SourceMap$Stratum org/spongepowered/asm/mixin/struct/SourceMap Stratum static
 field public,final name Ljava/lang/String; -
 method public <init> (Ljava/lang/String;)V - -
 method public addFile (IILjava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/struct/SourceMap$File; - -
in 22
class org/spongepowered/asm/mixin/struct/SpecialMethodInfo 50 public,super org/spongepowered/asm/mixin/struct/AnnotatedMethodInfo - -
 field protected,final annotationType Ljava/lang/String; -
 field protected,final classNode Lorg/objectweb/asm/tree/ClassNode; -
 field protected,final methodName Ljava/lang/String; -
 field protected,final mixin Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext; -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method public,final getClassNode ()Lorg/objectweb/asm/tree/ClassNode; - -
 method public,final getClassInfo ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getMethodName ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/throwables/ClassAlreadyLoadedException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/throwables/ClassMetadataNotFoundException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
in 22
class org/spongepowered/asm/mixin/throwables/CompanionPluginError 50 public,super java/lang/LinkageError - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/throwables/MixinApplyError 50 public,super org/spongepowered/asm/mixin/throwables/MixinError - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/throwables/MixinError 50 public,super java/lang/Error - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/throwables/MixinException 50 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public prepend (Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public getMessage ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/throwables/MixinPrepareError 50 public,super org/spongepowered/asm/mixin/throwables/MixinError - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ActivityStack 50 public,super java/lang/Object org/spongepowered/asm/mixin/extensibility/IActivityContext -
 inner org/spongepowered/asm/mixin/transformer/ActivityStack$Activity org/spongepowered/asm/mixin/transformer/ActivityStack Activity public
 inner org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity org/spongepowered/asm/mixin/extensibility/IActivityContext IActivity public,static,interface,abstract
 field public,static,final GLUE_STRING Ljava/lang/String; - " -> "
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public clear ()V - -
 method public begin (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity; - -
 method public,varargs begin (Ljava/lang/String;[Ljava/lang/Object;)Lorg/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity; - -
 method public toString ()Ljava/lang/String; - -
 method public toString (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/ActivityStack$Activity 50 public,super java/lang/Object org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity -
 inner org/spongepowered/asm/mixin/transformer/ActivityStack$Activity org/spongepowered/asm/mixin/transformer/ActivityStack Activity public
 inner org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity org/spongepowered/asm/mixin/extensibility/IActivityContext IActivity public,static,interface,abstract
 field public description Ljava/lang/String; -
 method public append (Ljava/lang/String;)V - -
 method public,varargs append (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public end ()V - -
 method public next (Ljava/lang/String;)V - -
 method public,varargs next (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassContext 50 super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/struct/MemberRef$Method org/spongepowered/asm/mixin/struct/MemberRef Method public,static,final
 method protected upgradeMethods ()V - -
 method protected upgradeMethodRef (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/struct/MemberRef;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Field org/spongepowered/asm/mixin/transformer/ClassInfo Field public
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$InterfaceMethod org/spongepowered/asm/mixin/transformer/ClassInfo InterfaceMethod public
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member org/spongepowered/asm/mixin/transformer/ClassInfo Member static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$FrameData org/spongepowered/asm/mixin/transformer/ClassInfo FrameData public,static
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Traversal org/spongepowered/asm/mixin/transformer/ClassInfo Traversal public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup org/spongepowered/asm/mixin/transformer/ClassInfo TypeLookup public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$SearchType org/spongepowered/asm/mixin/transformer/ClassInfo SearchType public,static,final,enum
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type org/spongepowered/asm/mixin/transformer/ClassInfo$Member Type static,final,enum
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 field public,static,final INCLUDE_PRIVATE I - I2
 field public,static,final INCLUDE_STATIC I - I8
 field public,static,final INCLUDE_ALL I - I10
 field public,static,final INCLUDE_INITIALISERS I - I262144
 method public getAppliedMixins ()Ljava/util/Set; ()Ljava/util/Set<Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;>; -
 method public isMixin ()Z - -
 method public isLoadable ()Z - -
 method public isPublic ()Z - -
 method public isReallyPublic ()Z - -
 method public isProtected ()Z - -
 method public isPrivate ()Z - -
 method public isAbstract ()Z - -
 method public isSynthetic ()Z - -
 method public isProbablyStatic ()Z - -
 method public isInner ()Z - -
 method public isInterface ()Z - -
 method public getInterfaces ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public toString ()Ljava/lang/String; - -
 method public getAccess ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getSimpleName ()Ljava/lang/String; - -
 method public getType ()Lorg/objectweb/asm/Type; - -
 method public getSuperName ()Ljava/lang/String; - -
 method public getSuperClass ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getOuterName ()Ljava/lang/String; - -
 method public getOuterClass ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getSignature ()Lorg/spongepowered/asm/util/ClassSignature; - -
 method public getNestHost ()Ljava/lang/String; - -
 method public getNestMembers ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public resolveNestHost ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getMethods ()Ljava/util/Set; ()Ljava/util/Set<Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;>; -
 method public getInterfaceMethods (Z)Ljava/util/Set; (Z)Ljava/util/Set<Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;>; -
 method public hasSuperClass (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public hasSuperClass (Ljava/lang/Class;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Z (Ljava/lang/Class<*>;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Z -
 method public hasSuperClass (Ljava/lang/Class;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;Z)Z (Ljava/lang/Class<*>;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;Z)Z -
 method public hasSuperClass (Ljava/lang/String;)Z - -
 method public hasSuperClass (Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Z - -
 method public hasSuperClass (Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;Z)Z - -
 method public hasSuperClass (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;)Z - -
 method public hasSuperClass (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Z - -
 method public hasSuperClass (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;Z)Z - -
 method public findSuperClass (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public findSuperClass (Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public findSuperClass (Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;Z)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public hasMixinInHierarchy ()Z - -
 method public hasMixinTargetInHierarchy ()Z - -
 method public findMethodInHierarchy (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Lorg/objectweb/asm/tree/MethodInsnNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Lorg/objectweb/asm/tree/MethodInsnNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethodInHierarchy (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findFieldInHierarchy (Lorg/objectweb/asm/tree/FieldNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findFieldInHierarchy (Lorg/objectweb/asm/tree/FieldNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findFieldInHierarchy (Lorg/objectweb/asm/tree/FieldInsnNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findFieldInHierarchy (Lorg/objectweb/asm/tree/FieldInsnNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findFieldInHierarchy (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findFieldInHierarchy (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findFieldInHierarchy (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findMethod (Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethod (Lorg/objectweb/asm/tree/MethodNode;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethod (Lorg/objectweb/asm/tree/MethodInsnNode;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethod (Lorg/objectweb/asm/tree/MethodInsnNode;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findMethod (Ljava/lang/String;Ljava/lang/String;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method public findField (Lorg/objectweb/asm/tree/FieldNode;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findField (Lorg/objectweb/asm/tree/FieldInsnNode;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public findField (Ljava/lang/String;Ljava/lang/String;I)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Field; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static forName (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static forDescriptor (Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static forType (Lorg/objectweb/asm/Type;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static fromCache (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static fromCache (Lorg/objectweb/asm/Type;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static getCommonSuperClass (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static getCommonSuperClass (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static getCommonSuperClassOrInterface (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static getCommonSuperClassOrInterface (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,static getCommonSuperClassOrInterface (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/spongepowered/asm/mixin/transformer/ClassInfo;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$Field 50 public,super org/spongepowered/asm/mixin/transformer/ClassInfo$Member - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member org/spongepowered/asm/mixin/transformer/ClassInfo Member static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Field org/spongepowered/asm/mixin/transformer/ClassInfo Field public
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type org/spongepowered/asm/mixin/transformer/ClassInfo$Member Type static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/objectweb/asm/tree/FieldNode;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/objectweb/asm/tree/FieldNode;Z)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;I)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;IZ)V - -
 method public getOwner ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public equals (Ljava/lang/Object;)Z - -
 method protected getDisplayFormat ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$FrameData 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$FrameData org/spongepowered/asm/mixin/transformer/ClassInfo FrameData public,static
 field public,final index I -
 field public,final type I -
 field public,final locals I -
 field public,final size I -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$InterfaceMethod 50 public,super org/spongepowered/asm/mixin/transformer/ClassInfo$Method - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member org/spongepowered/asm/mixin/transformer/ClassInfo Member static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$InterfaceMethod org/spongepowered/asm/mixin/transformer/ClassInfo InterfaceMethod public
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member;)V - -
 method public getOwner ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getImplementor ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$Member 50 super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member org/spongepowered/asm/mixin/transformer/ClassInfo Member static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type org/spongepowered/asm/mixin/transformer/ClassInfo$Member Type static,final,enum
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member;)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type;Ljava/lang/String;Ljava/lang/String;I)V - -
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type;Ljava/lang/String;Ljava/lang/String;IZ)V - -
 method public getOriginalName ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getOriginalDesc ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public isInjected ()Z - -
 method public isRenamed ()Z - -
 method public isRemapped ()Z - -
 method public isPrivate ()Z - -
 method public isStatic ()Z - -
 method public isAbstract ()Z - -
 method public isFinal ()Z - -
 method public isSynthetic ()Z - -
 method public isUnique ()Z - -
 method public setUnique (Z)V - -
 method public isDecoratedFinal ()Z - -
 method public isDecoratedMutable ()Z - -
 method protected setDecoratedFinal (ZZ)V - -
 method public matchesFlags (I)Z - -
 method public,abstract getOwner ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getImplementor ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getAccess ()I - -
 method public renameTo (Ljava/lang/String;)Ljava/lang/String; - -
 method public remapTo (Ljava/lang/String;)Ljava/lang/String; - -
 method public equals (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method protected getDisplayFormat ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type;>;
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member org/spongepowered/asm/mixin/transformer/ClassInfo Member static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type org/spongepowered/asm/mixin/transformer/ClassInfo$Member Type static,final,enum
 field public,static,final,enum METHOD Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type; -
 field public,static,final,enum FIELD Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$Method 50 public,super org/spongepowered/asm/mixin/transformer/ClassInfo$Member - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$FrameData org/spongepowered/asm/mixin/transformer/ClassInfo FrameData public,static
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member org/spongepowered/asm/mixin/transformer/ClassInfo Member static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Member$Type org/spongepowered/asm/mixin/transformer/ClassInfo$Member Type static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Member;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Lorg/objectweb/asm/tree/MethodNode;Z)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;I)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;IZ)V - -
 method public getFrames ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ClassInfo$FrameData;>; -
 method public getOwner ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public isAccessor ()Z - -
 method public isConformed ()Z - -
 method public renameTo (Ljava/lang/String;)Ljava/lang/String; - -
 method public conform (Ljava/lang/String;)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$SearchType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType;>;
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$SearchType org/spongepowered/asm/mixin/transformer/ClassInfo SearchType public,static,final,enum
 field public,static,final,enum ALL_CLASSES Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType; -
 field public,static,final,enum SUPER_CLASSES_ONLY Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$Traversal 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal;>;
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Traversal org/spongepowered/asm/mixin/transformer/ClassInfo Traversal public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$SearchType org/spongepowered/asm/mixin/transformer/ClassInfo SearchType public,static,final,enum
 field public,static,final,enum NONE Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal; -
 field public,static,final,enum ALL Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal; -
 field public,static,final,enum IMMEDIATE Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal; -
 field public,static,final,enum SUPER Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal; - -
 method public next ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Traversal; - -
 method public canTraverse ()Z - -
 method public getSearchType ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo$SearchType; - -
in 22
class org/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup;>;
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup org/spongepowered/asm/mixin/transformer/ClassInfo TypeLookup public,static,final,enum
 field public,static,final,enum DECLARED_TYPE Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup; -
 field public,static,final,enum ELEMENT_TYPE Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup; - -
in 22
class org/spongepowered/asm/mixin/transformer/Config 50 public,super java/lang/Object - -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinConfig;)V - -
 method public getName ()Ljava/lang/String; - -
 method public isVisited ()Z - -
 method public getConfig ()Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig; - -
 method public getEnvironment ()Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public getParent ()Lorg/spongepowered/asm/mixin/transformer/Config; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static,deprecated create (Ljava/lang/String;Lorg/spongepowered/asm/mixin/MixinEnvironment;)Lorg/spongepowered/asm/mixin/transformer/Config; - -
 method public,static create (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/Config; - -
in 22
class org/spongepowered/asm/mixin/transformer/DefaultExtensions 50 final,super java/lang/Object - -
in 22
class org/spongepowered/asm/mixin/transformer/IMixinTransformer 50 public,interface,abstract java/lang/Object - -
 method public,abstract audit (Lorg/spongepowered/asm/mixin/MixinEnvironment;)V - -
 method public,abstract reload (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract computeFramesForClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
 method public,abstract transformClassBytes (Ljava/lang/String;Ljava/lang/String;[B)[B - -
 method public,abstract transformClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;[B)[B - -
 method public,abstract transformClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
 method public,abstract generateClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;)[B - -
 method public,abstract generateClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
 method public,abstract getExtensions ()Lorg/spongepowered/asm/mixin/transformer/ext/IExtensionRegistry; - -
in 22
class org/spongepowered/asm/mixin/transformer/IMixinTransformerFactory 50 public,interface,abstract java/lang/Object org/spongepowered/asm/service/IMixinInternal -
 method public,abstract createTransformer ()Lorg/spongepowered/asm/mixin/transformer/IMixinTransformer; - org/spongepowered/asm/launch/MixinInitialisationError
in 22
class org/spongepowered/asm/mixin/transformer/InnerClassGenerator 50 final,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IClassGenerator -
 inner org/spongepowered/asm/mixin/transformer/InnerClassGenerator$InnerClassAdapter org/spongepowered/asm/mixin/transformer/InnerClassGenerator InnerClassAdapter static
 inner org/spongepowered/asm/mixin/transformer/InnerClassGenerator$InnerClassInfo org/spongepowered/asm/mixin/transformer/InnerClassGenerator InnerClassInfo static
 method public <init> (Lorg/spongepowered/asm/util/IConsumer;Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessorNestHost;)V (Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/service/ISyntheticClassInfo;>;Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessorNestHost;)V -
 method public getName ()Ljava/lang/String; - -
 method public generate (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/mixin/transformer/InnerClassGenerator$InnerClassAdapter 50 super org/objectweb/asm/commons/ClassRemapper - -
 inner org/spongepowered/asm/mixin/transformer/InnerClassGenerator$InnerClassInfo org/spongepowered/asm/mixin/transformer/InnerClassGenerator InnerClassInfo static
 inner org/spongepowered/asm/mixin/transformer/InnerClassGenerator$InnerClassAdapter org/spongepowered/asm/mixin/transformer/InnerClassGenerator InnerClassAdapter static
 method public visitNestHost (Ljava/lang/String;)V - -
 method public visitSource (Ljava/lang/String;Ljava/lang/String;)V - -
 method public visitInnerClass (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V - -
in 22
class org/spongepowered/asm/mixin/transformer/InnerClassGenerator$InnerClassInfo 50 super org/objectweb/asm/commons/Remapper org/spongepowered/asm/service/ISyntheticClassInfo -
 inner org/spongepowered/asm/mixin/transformer/InnerClassGenerator$InnerClassInfo org/spongepowered/asm/mixin/transformer/InnerClassGenerator InnerClassInfo static
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 method public getMixin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
 method public isLoaded ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
 method public mapMethodName (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public map (Ljava/lang/String;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/InterfaceInfo 50 final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 method public getPrefix ()Ljava/lang/String; - -
 method public getIface ()Lorg/objectweb/asm/Type; - -
 method public getName ()Ljava/lang/String; - -
 method public getInternalName ()Ljava/lang/String; - -
 method public isUnique ()Z - -
 method public renameMethod (Lorg/objectweb/asm/tree/MethodNode;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/mixin/transformer/MethodMapper 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 method public <init> (Lorg/spongepowered/asm/mixin/MixinEnvironment;Lorg/spongepowered/asm/mixin/transformer/ClassInfo;)V - -
 method public getClassInfo ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public remapHandlerMethod (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;)V - -
 method public getHandlerName (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)Ljava/lang/String; - -
 method public getUniqueName (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/String;Z)Ljava/lang/String; - -
 method public getUniqueName (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinApplicatorInterface 50 super org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Field org/spongepowered/asm/mixin/transformer/ClassInfo Field public
 method protected applyInterfaces (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyFields (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyInitialisers (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected prepareInjections (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyInjections (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$Range org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard Range -
 inner org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard InitialiserInjectionMode static,final,enum
 inner org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard ApplicatorPass static,final,enum
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity org/spongepowered/asm/mixin/extensibility/IActivityContext IActivity public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Field org/spongepowered/asm/mixin/transformer/ClassInfo Field public
 inner org/spongepowered/asm/util/Bytecode$DelegateInitialiser org/spongepowered/asm/util/Bytecode DelegateInitialiser public,static
 inner org/spongepowered/asm/util/ConstraintParser$Constraint org/spongepowered/asm/util/ConstraintParser Constraint public,static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 field protected,static,final CONSTRAINED_ANNOTATIONS Ljava/util/List; Ljava/util/List<Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;>;
 field protected,static,final INITIALISER_OPCODE_BLACKLIST [I -
 field protected,final logger Lorg/spongepowered/asm/logging/ILogger; -
 field protected,final context Lorg/spongepowered/asm/mixin/transformer/TargetClassContext; -
 field protected,final targetName Ljava/lang/String; -
 field protected,final targetClass Lorg/objectweb/asm/tree/ClassNode; -
 field protected,final targetClassInfo Lorg/spongepowered/asm/mixin/transformer/ClassInfo; -
 field protected,final profiler Lorg/spongepowered/asm/util/perf/Profiler; -
 field protected,final auditTrail Lorg/spongepowered/asm/service/IMixinAuditTrail; -
 field protected,final activities Lorg/spongepowered/asm/mixin/transformer/ActivityStack; -
 field protected,final mergeSignatures Z -
 method protected,final applyMixin (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass;)V - -
 method protected applySignature (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyInterfaces (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyAttributes (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyAnnotations (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyFields (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected mergeShadowFields (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected mergeNewFields (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyMethods (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyShadowMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected applyNormalMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected mergeMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected isAlreadyMerged (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;ZLorg/objectweb/asm/tree/MethodNode;)Z - -
 method protected mergeIntrinsic (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;ZLorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)Z - -
 method protected displaceIntrinsic (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected,final appendInsns (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected applyInitialisers (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected getConstructor (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)Lorg/objectweb/asm/tree/MethodNode; - -
 method protected,final getInitialiser (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/Deque; (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/Deque<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method protected,final injectInitialiser (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/util/Deque;)V (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/util/Deque<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)V -
 method protected findInitialiserInjectionPoint (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/util/Deque;)Lorg/objectweb/asm/tree/AbstractInsnNode; (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Ljava/util/Deque<Lorg/objectweb/asm/tree/AbstractInsnNode;>;)Lorg/objectweb/asm/tree/AbstractInsnNode; -
 method protected prepareInjections (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyInjections (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected applyAccessors (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected checkMethodVisibility (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected applySourceMap (Lorg/spongepowered/asm/mixin/transformer/TargetClassContext;)V - -
 method protected checkMethodConstraints (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method protected,final checkConstraints (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AnnotationNode;)V - -
 method protected,final findTargetMethod (Lorg/objectweb/asm/tree/MethodNode;)Lorg/objectweb/asm/tree/MethodNode; - -
 method protected,final findTargetField (Lorg/objectweb/asm/tree/FieldNode;)Lorg/objectweb/asm/tree/FieldNode; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass;>;
 inner org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard ApplicatorPass static,final,enum
 field public,static,final,enum MAIN Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass; -
 field public,static,final,enum PREINJECT Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass; -
 field public,static,final,enum INJECT Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$ApplicatorPass; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode;>;
 inner org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard InitialiserInjectionMode static,final,enum
 field public,static,final,enum DEFAULT Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode; -
 field public,static,final,enum SAFE Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$InitialiserInjectionMode; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$Range 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard$Range org/spongepowered/asm/mixin/transformer/MixinApplicatorStandard Range -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinClassGenerator 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
in 22
class org/spongepowered/asm/mixin/transformer/MixinConfig 50 final,super java/lang/Object java/lang/Comparable,org/spongepowered/asm/mixin/extensibility/IMixinConfig Ljava/lang/Object;Ljava/lang/Comparable<Lorg/spongepowered/asm/mixin/transformer/MixinConfig;>;Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$IListener org/spongepowered/asm/mixin/transformer/MixinConfig IListener static,interface,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$OverwriteOptions org/spongepowered/asm/mixin/transformer/MixinConfig OverwriteOptions static
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$InjectorOptions org/spongepowered/asm/mixin/transformer/MixinConfig InjectorOptions static
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Side org/spongepowered/asm/mixin/MixinEnvironment Side public,static,abstract,enum
 method public getHandle ()Lorg/spongepowered/asm/mixin/transformer/Config; - -
 method public isRequired ()Z - -
 method public getEnvironment ()Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public getName ()Ljava/lang/String; - -
 method public getMixinPackage ()Ljava/lang/String; - -
 method public getPriority ()I - -
 method public getDefaultMixinPriority ()I - -
 method public getDefaultRequiredInjections ()I - -
 method public getDefaultInjectorGroup ()Ljava/lang/String; - -
 method public conformOverwriteVisibility ()Z - -
 method public requireOverwriteAnnotations ()Z - -
 method public getMaxShiftByValue ()I - -
 method public select (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public getClasses ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public shouldSetSourceFile ()Z - -
 method public getReferenceMapper ()Lorg/spongepowered/asm/mixin/refmap/IReferenceMapper; - -
 method public getPlugin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinConfigPlugin; - -
 method public getTargetsSet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getTargets ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getUnhandledTargets ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public decorate (Ljava/lang/String;Ljava/lang/Object;)V <V:Ljava/lang/Object;>(Ljava/lang/String;TV;)V -
 method public hasDecoration (Ljava/lang/String;)Z - -
 method public getDecoration (Ljava/lang/String;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/lang/String;)TV; -
 method public getLoggingLevel ()Lorg/spongepowered/asm/logging/Level; - -
 method public isVerboseLogging ()Z - -
 method public packageMatch (Ljava/lang/String;)Z - -
 method public hasMixinsFor (Ljava/lang/String;)Z - -
 method public getMixinsFor (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/MixinInfo;>; -
 method public reloadMixin (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Ljava/lang/String;>; -
 method public toString ()Ljava/lang/String; - -
 method public compareTo (Lorg/spongepowered/asm/mixin/transformer/MixinConfig;)I - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinConfig$IListener 50 interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$IListener org/spongepowered/asm/mixin/transformer/MixinConfig IListener static,interface,abstract
 method public,abstract onPrepare (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public,abstract onInit (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinConfig$InjectorOptions 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$InjectorOptions org/spongepowered/asm/mixin/transformer/MixinConfig InjectorOptions static
in 22
class org/spongepowered/asm/mixin/transformer/MixinConfig$OverwriteOptions 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$OverwriteOptions org/spongepowered/asm/mixin/transformer/MixinConfig OverwriteOptions static
in 22
class org/spongepowered/asm/mixin/transformer/MixinCoprocessor 50 super,abstract java/lang/Object org/spongepowered/asm/mixin/transformer/MixinConfig$IListener -
 inner org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult org/spongepowered/asm/mixin/transformer/MixinCoprocessor ProcessResult static,final,enum
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$IListener org/spongepowered/asm/mixin/transformer/MixinConfig IListener static,interface,abstract
 method public onPrepare (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public onInit (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult;>;
 inner org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult org/spongepowered/asm/mixin/transformer/MixinCoprocessor ProcessResult static,final,enum
 field public,static,final,enum NONE Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult; -
 field public,static,final,enum TRANSFORMED Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult; -
 field public,static,final,enum PASSTHROUGH_NONE Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult; -
 field public,static,final,enum PASSTHROUGH_TRANSFORMED Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinCoprocessorAccessor 50 super org/spongepowered/asm/mixin/transformer/MixinCoprocessor - -
 inner org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult org/spongepowered/asm/mixin/transformer/MixinCoprocessor ProcessResult static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 field protected,final sessionId Ljava/lang/String; -
 method public onPrepare (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinCoprocessorNestHost 50 super org/spongepowered/asm/mixin/transformer/MixinCoprocessor - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
in 22
class org/spongepowered/asm/mixin/transformer/MixinCoprocessorPassthrough 50 super org/spongepowered/asm/mixin/transformer/MixinCoprocessor - -
 inner org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult org/spongepowered/asm/mixin/transformer/MixinCoprocessor ProcessResult static,final,enum
 method public onPrepare (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinCoprocessorSyntheticInner 50 super org/spongepowered/asm/mixin/transformer/MixinCoprocessor - -
 inner org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult org/spongepowered/asm/mixin/transformer/MixinCoprocessor ProcessResult static,final,enum
 method public onInit (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinCoprocessors 50 super java/util/ArrayList - Ljava/util/ArrayList<Lorg/spongepowered/asm/mixin/transformer/MixinCoprocessor;>;
 inner org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult org/spongepowered/asm/mixin/transformer/MixinCoprocessor ProcessResult static,final,enum
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo 50 super java/lang/Object java/lang/Comparable,org/spongepowered/asm/mixin/extensibility/IMixinInfo Ljava/lang/Object;Ljava/lang/Comparable<Lorg/spongepowered/asm/mixin/transformer/MixinInfo;>;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$DeclaredTarget org/spongepowered/asm/mixin/transformer/MixinInfo DeclaredTarget static,final
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType org/spongepowered/asm/mixin/transformer/MixinInfo SubType static,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$Reloaded org/spongepowered/asm/mixin/transformer/MixinInfo Reloaded -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$State org/spongepowered/asm/mixin/transformer/MixinInfo State -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$Variant org/spongepowered/asm/mixin/transformer/MixinInfo Variant static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Accessor org/spongepowered/asm/mixin/transformer/MixinInfo$SubType Accessor static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method protected readDeclaredTargets (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode;Z)Ljava/util/List; (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode;Z)Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/MixinInfo$DeclaredTarget;>; -
 method protected readPriority (Lorg/objectweb/asm/tree/ClassNode;)I - -
 method protected readPseudo (Lorg/objectweb/asm/tree/ClassNode;)Z - -
 method public hasDeclaredTarget (Ljava/lang/String;)Z - -
 method public getConfig ()Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig; - -
 method public getPriority ()I - -
 method public getName ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getClassRef ()Ljava/lang/String; - -
 method public getClassBytes ()[B - -
 method public isDetachedSuper ()Z - -
 method public isUnique ()Z - -
 method public isVirtual ()Z - -
 method public isAccessor ()Z - -
 method public isLoadable ()Z - -
 method public isRequired ()Z - -
 method public getLoggingLevel ()Lorg/spongepowered/asm/logging/Level; - -
 method public getPhase ()Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; - -
 method public getClassNode (I)Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode; - -
 method public getTargetClasses ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public compareTo (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)I - -
 method public preApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)V - java/lang/Exception
 method public postApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)V - java/lang/Exception
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$DeclaredTarget 50 final,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$DeclaredTarget org/spongepowered/asm/mixin/transformer/MixinInfo DeclaredTarget static,final
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode 50 super org/objectweb/asm/tree/ClassNode - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 field public,final mixinMethods Ljava/util/List; Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;>;
 method protected <init> (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;I)V - -
 method public getMixin ()Lorg/spongepowered/asm/mixin/transformer/MixinInfo; - -
 method public getFields ()Ljava/util/List; ()Ljava/util/List<Lorg/objectweb/asm/tree/FieldNode;>; -
 method public visitMethod (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Lorg/objectweb/asm/MethodVisitor; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode 50 super org/spongepowered/asm/util/asm/MethodNodeEx - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V - -
 method public,varargs visitInvokeDynamicInsn (Ljava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/Handle;[Ljava/lang/Object;)V - -
 method public isInjector ()Z - -
 method public isSurrogate ()Z - -
 method public isSynthetic ()Z - -
 method public getVisibleAnnotation (Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public getInjectorAnnotation ()Lorg/objectweb/asm/tree/AnnotationNode; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$Reloaded 50 super org/spongepowered/asm/mixin/transformer/MixinInfo$State - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$State org/spongepowered/asm/mixin/transformer/MixinInfo State -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$Reloaded org/spongepowered/asm/mixin/transformer/MixinInfo Reloaded -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType org/spongepowered/asm/mixin/transformer/MixinInfo SubType static,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 method protected validateChanges (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$SubType;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$SubType;Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ClassInfo;>;)V -
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$State 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$State org/spongepowered/asm/mixin/transformer/MixinInfo State -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType org/spongepowered/asm/mixin/transformer/MixinInfo SubType static,abstract
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$Reloaded org/spongepowered/asm/mixin/transformer/MixinInfo Reloaded -
 field protected,final interfaces Ljava/util/Set; Ljava/util/Set<Ljava/lang/String;>;
 field protected,final softImplements Ljava/util/List; Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/InterfaceInfo;>;
 field protected,final syntheticInnerClasses Ljava/util/Set; Ljava/util/Set<Ljava/lang/String;>;
 field protected,final innerClasses Ljava/util/Set; Ljava/util/Set<Ljava/lang/String;>;
 field protected validationClassNode Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode; -
 method protected connect ()V - -
 method protected complete ()V - -
 method protected validateChanges (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$SubType;Ljava/util/List;)V (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$SubType;Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ClassInfo;>;)V -
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$SubType 50 super,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType org/spongepowered/asm/mixin/transformer/MixinInfo SubType static,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Accessor org/spongepowered/asm/mixin/transformer/MixinInfo$SubType Accessor static
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Interface org/spongepowered/asm/mixin/transformer/MixinInfo$SubType Interface static
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Standard org/spongepowered/asm/mixin/transformer/MixinInfo$SubType Standard static
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$State org/spongepowered/asm/mixin/transformer/MixinInfo State -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$Variant org/spongepowered/asm/mixin/transformer/MixinInfo Variant static,final,enum
 field protected,final mixin Lorg/spongepowered/asm/mixin/transformer/MixinInfo; -
 field protected,final annotationType Ljava/lang/String; -
 field protected,final targetMustBeInterface Z -
 field protected detached Z -
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Accessor 50 super org/spongepowered/asm/mixin/transformer/MixinInfo$SubType - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType org/spongepowered/asm/mixin/transformer/MixinInfo SubType static,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Accessor org/spongepowered/asm/mixin/transformer/MixinInfo$SubType Accessor static
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$State org/spongepowered/asm/mixin/transformer/MixinInfo State -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Interface 50 super org/spongepowered/asm/mixin/transformer/MixinInfo$SubType - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType org/spongepowered/asm/mixin/transformer/MixinInfo SubType static,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Interface org/spongepowered/asm/mixin/transformer/MixinInfo$SubType Interface static
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$State org/spongepowered/asm/mixin/transformer/MixinInfo State -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Standard 50 super org/spongepowered/asm/mixin/transformer/MixinInfo$SubType - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType org/spongepowered/asm/mixin/transformer/MixinInfo SubType static,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$SubType$Standard org/spongepowered/asm/mixin/transformer/MixinInfo$SubType Standard static
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$State org/spongepowered/asm/mixin/transformer/MixinInfo State -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Traversal org/spongepowered/asm/mixin/transformer/ClassInfo Traversal public,static,final,enum
in 22
class org/spongepowered/asm/mixin/transformer/MixinInfo$Variant 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinInfo$Variant;>;
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$Variant org/spongepowered/asm/mixin/transformer/MixinInfo Variant static,final,enum
 field public,static,final,enum STANDARD Lorg/spongepowered/asm/mixin/transformer/MixinInfo$Variant; -
 field public,static,final,enum INTERFACE Lorg/spongepowered/asm/mixin/transformer/MixinInfo$Variant; -
 field public,static,final,enum ACCESSOR Lorg/spongepowered/asm/mixin/transformer/MixinInfo$Variant; -
 field public,static,final,enum PROXY Lorg/spongepowered/asm/mixin/transformer/MixinInfo$Variant; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinInfo$Variant; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinInfo$Variant; - -
in 1177
class org/spongepowered/asm/mixin/transformer/MixinInheritanceTracker 50 public,final,super,enum java/lang/Enum org/spongepowered/asm/mixin/transformer/MixinConfig$IListener Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker;>;Lorg/spongepowered/asm/mixin/transformer/MixinConfig$IListener;
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$IListener org/spongepowered/asm/mixin/transformer/MixinConfig IListener static,interface,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 field public,static,final,enum INSTANCE Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker; - -
 method public onPrepare (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public onInit (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public findOverrides (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List; (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/tree/MethodNode;>; -
 method public findOverrides (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/tree/MethodNode;>; -
in 1180
class org/spongepowered/asm/mixin/transformer/MixinInheritanceTracker 52 public,final,super,enum java/lang/Enum org/spongepowered/asm/mixin/transformer/MixinConfig$IListener Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker;>;Lorg/spongepowered/asm/mixin/transformer/MixinConfig$IListener;
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$IListener org/spongepowered/asm/mixin/transformer/MixinConfig IListener static,interface,abstract
 field public,static,final,enum INSTANCE Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinInheritanceTracker; - -
 method public onPrepare (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public onInit (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public findOverrides (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List; (Lorg/spongepowered/asm/mixin/transformer/ClassInfo;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/tree/MethodNode;>; -
 method public findOverrides (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/tree/MethodNode;>; -
in 189
class org/spongepowered/asm/mixin/transformer/MixinPostProcessor 52 super java/lang/Object org/spongepowered/asm/mixin/transformer/MixinConfig$IListener -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel$LanguageFeature org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel LanguageFeature public,static
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$IListener org/spongepowered/asm/mixin/transformer/MixinConfig IListener static,interface,abstract
 method public onInit (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public onPrepare (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - -
 method public processClass (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinPreProcessorAccessor 50 super org/spongepowered/asm/mixin/transformer/MixinPreProcessorInterface - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinInfo;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinPreProcessorInterface 50 super org/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard - -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 method protected prepareMethod (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;)V - -
 method protected validateField (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/FieldNode;Lorg/objectweb/asm/tree/AnnotationNode;)Z - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod org/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard SpecialMethod static,final,enum
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinClassNode -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity org/spongepowered/asm/mixin/extensibility/IActivityContext IActivity public,static,interface,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode org/spongepowered/asm/mixin/transformer/MixinInfo MixinMethodNode -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Field org/spongepowered/asm/mixin/transformer/ClassInfo Field public
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$SearchType org/spongepowered/asm/mixin/transformer/ClassInfo SearchType public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup org/spongepowered/asm/mixin/transformer/ClassInfo TypeLookup public,static,final,enum
 field protected,final mixin Lorg/spongepowered/asm/mixin/transformer/MixinInfo; -
 field protected,final classNode Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinClassNode; -
 field protected,final env Lorg/spongepowered/asm/mixin/MixinEnvironment; -
 field protected,final profiler Lorg/spongepowered/asm/util/perf/Profiler; -
 field protected,final activities Lorg/spongepowered/asm/mixin/transformer/ActivityStack; -
 method protected prepareInnerClasses (Lorg/spongepowered/asm/mixin/transformer/ext/Extensions;)V - -
 method protected prepareMethod (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;)V - -
 method protected prepareShadow (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;)V - -
 method protected prepareSoftImplements (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;)V - -
 method protected prepareField (Lorg/objectweb/asm/tree/FieldNode;)V - -
 method protected attachMethods (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected validateMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)Z - -
 method protected attachInjectorMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)Z - -
 method protected attachAccessorMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)Z - -
 method protected attachAccessorMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod;)Z - -
 method protected attachShadowMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)Z - -
 method protected attachOverwriteMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)Z - -
 method protected attachSpecialMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod;)Z - -
 method protected getSpecialMethod (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod;)Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method; - -
 method protected checkMethodNotUnique (Lorg/spongepowered/asm/mixin/transformer/ClassInfo$Method;Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod;)V - -
 method protected checkMixinNotUnique (Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod;)V - -
 method protected attachUniqueMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)Z - -
 method protected attachMethod (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/spongepowered/asm/mixin/transformer/MixinInfo$MixinMethodNode;)V - -
 method protected attachFields (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected validateField (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/FieldNode;Lorg/objectweb/asm/tree/AnnotationNode;)Z - -
 method protected transform (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;)V - -
 method protected transformMethod (Lorg/objectweb/asm/tree/MethodInsnNode;)V - -
 method protected transformField (Lorg/objectweb/asm/tree/FieldInsnNode;)V - -
 method protected,static getDynamicInfo (Lorg/objectweb/asm/tree/MethodNode;)Ljava/lang/String; - -
 method protected,static getDynamicInfo (Lorg/objectweb/asm/tree/FieldNode;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod;>;
 inner org/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod org/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard SpecialMethod static,final,enum
 field public,static,final,enum MERGE Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod; -
 field public,static,final,enum OVERWRITE Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod; -
 field public,static,final,enum SHADOW Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod; -
 field public,static,final,enum ACCESSOR Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod; -
 field public,static,final,enum INVOKER Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinPreProcessorStandard$SpecialMethod; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinProcessor 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase org/spongepowered/asm/mixin/transformer/MixinProcessor ErrorPhase static,abstract,enum
 inner org/spongepowered/asm/mixin/transformer/MixinCoprocessor$ProcessResult org/spongepowered/asm/mixin/transformer/MixinCoprocessor ProcessResult static,final,enum
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/mixin/transformer/MixinInfo$Variant org/spongepowered/asm/mixin/transformer/MixinInfo Variant static,final,enum
 inner org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler ErrorAction public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/MixinConfig$IListener org/spongepowered/asm/mixin/transformer/MixinConfig IListener static,interface,abstract
 method public audit (Lorg/spongepowered/asm/mixin/MixinEnvironment;)V - -
 method public reload (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Ljava/lang/String;>; -
in 22
class org/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase 50 super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase;>;
 inner org/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase org/spongepowered/asm/mixin/transformer/MixinProcessor ErrorPhase static,abstract,enum
 inner org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler$ErrorAction org/spongepowered/asm/mixin/extensibility/IMixinErrorHandler ErrorAction public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 field public,static,final,enum PREPARE Lorg/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase; -
 field public,static,final,enum APPLY Lorg/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/MixinProcessor$ErrorPhase; - -
 method protected,abstract getContext (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;)Ljava/lang/String; - -
 method public getLogMessage (Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/throwables/InvalidMixinException;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)Ljava/lang/String; - -
 method public getErrorMessage (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Lorg/spongepowered/asm/mixin/extensibility/IMixinConfig;Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinTargetContext 50 public,super org/spongepowered/asm/mixin/transformer/ClassContext org/spongepowered/asm/mixin/refmap/IMixinContext -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Field org/spongepowered/asm/mixin/transformer/ClassInfo Field public
 inner org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo$Map org/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo Map public,static,final
 inner org/spongepowered/asm/mixin/struct/SourceMap$File org/spongepowered/asm/mixin/struct/SourceMap File public,static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/extensibility/IActivityContext$IActivity org/spongepowered/asm/mixin/extensibility/IActivityContext IActivity public,static,interface,abstract
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/asm/mixin/struct/MemberRef$Handle org/spongepowered/asm/mixin/struct/MemberRef Handle public,static,final
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Traversal org/spongepowered/asm/mixin/transformer/ClassInfo Traversal public,static,final,enum
 inner org/spongepowered/asm/mixin/struct/MemberRef$Method org/spongepowered/asm/mixin/struct/MemberRef Method public,static,final
 inner org/spongepowered/asm/mixin/struct/MemberRef$Field org/spongepowered/asm/mixin/struct/MemberRef Field public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$SearchType org/spongepowered/asm/mixin/transformer/ClassInfo SearchType public,static,final,enum
 field protected,final activities Lorg/spongepowered/asm/mixin/transformer/ActivityStack; -
 method public toString ()Ljava/lang/String; - -
 method public getEnvironment ()Lorg/spongepowered/asm/mixin/MixinEnvironment; - -
 method public getOption (Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;)Z - -
 method public getClassNode ()Lorg/objectweb/asm/tree/ClassNode; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getClassRef ()Ljava/lang/String; - -
 method public getTarget ()Lorg/spongepowered/asm/mixin/transformer/TargetClassContext; - -
 method public getTargetClassRef ()Ljava/lang/String; - -
 method public getTargetClassNode ()Lorg/objectweb/asm/tree/ClassNode; - -
 method public getTargetClassInfo ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getClassInfo ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public getSignature ()Lorg/spongepowered/asm/util/ClassSignature; - -
 method public getStratum ()Lorg/spongepowered/asm/mixin/struct/SourceMap$File; - -
 method public getMinRequiredClassVersion ()I - -
 method public getDefaultRequiredInjections ()I - -
 method public getDefaultInjectorGroup ()Ljava/lang/String; - -
 method public getMaxShiftByValue ()I - -
 method public getInjectorGroups ()Lorg/spongepowered/asm/mixin/injection/struct/InjectorGroupInfo$Map; - -
 method public requireOverwriteAnnotations ()Z - -
 method public getTargetMethod (Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/mixin/injection/struct/Target; - -
 method protected requireVersion (I)V - -
 method public getExtensions ()Lorg/spongepowered/asm/mixin/transformer/ext/Extensions; - -
 method public getMixin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
 method public getPriority ()I - -
 method public getReferenceMapper ()Lorg/spongepowered/asm/mixin/refmap/IReferenceMapper; - -
in 189
class org/spongepowered/asm/mixin/transformer/MixinTransformationHandler 52 public,super java/lang/Object org/spongepowered/asm/launch/IClassProcessor -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 method public <init> ()V - -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public,synchronized processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinTransformer 50 final,super org/spongepowered/asm/transformers/TreeTransformer org/spongepowered/asm/mixin/transformer/IMixinTransformer -
 inner org/spongepowered/asm/mixin/transformer/MixinTransformer$Factory org/spongepowered/asm/mixin/transformer/MixinTransformer Factory static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 method public getExtensions ()Lorg/spongepowered/asm/mixin/transformer/ext/IExtensionRegistry; - -
 method public getName ()Ljava/lang/String; - -
 method public isDelegationExcluded ()Z - -
 method public audit (Lorg/spongepowered/asm/mixin/MixinEnvironment;)V - -
 method public reload (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Ljava/lang/String;>; -
 method public transformClassBytes (Ljava/lang/String;Ljava/lang/String;[B)[B - -
 method public computeFramesForClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
 method public transformClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;[B)[B - -
 method public transformClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
 method public generateClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;)[B - -
 method public generateClass (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/mixin/transformer/MixinTransformer$Factory 50 super java/lang/Object org/spongepowered/asm/mixin/transformer/IMixinTransformerFactory -
 inner org/spongepowered/asm/mixin/transformer/MixinTransformer$Factory org/spongepowered/asm/mixin/transformer/MixinTransformer Factory static
 method public createTransformer ()Lorg/spongepowered/asm/mixin/transformer/IMixinTransformer; - org/spongepowered/asm/launch/MixinInitialisationError
in 22
class org/spongepowered/asm/mixin/transformer/PluginHandle 50 super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode org/spongepowered/asm/mixin/transformer/PluginHandle CompatibilityMode static,final,enum
 method public preApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - java/lang/Exception
 method public postApply (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Lorg/spongepowered/asm/mixin/transformer/MixinInfo;)V - java/lang/Exception
in 22
class org/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode;>;
 inner org/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode org/spongepowered/asm/mixin/transformer/PluginHandle CompatibilityMode static,final,enum
 field public,static,final,enum NORMAL Lorg/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode; -
 field public,static,final,enum COMPATIBLE Lorg/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode; -
 field public,static,final,enum FAILED Lorg/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/PluginHandle$CompatibilityMode; - -
in 22
class org/spongepowered/asm/mixin/transformer/Proxy 52 public,final,super java/lang/Object net/minecraft/launchwrapper/IClassTransformer,org/spongepowered/asm/service/ILegacyClassTransformer -
 method public <init> ()V - -
 method public transform (Ljava/lang/String;Ljava/lang/String;[B)[B - -
 method public getName ()Ljava/lang/String; - -
 method public isDelegationExcluded ()Z - -
 method public transformClassBytes (Ljava/lang/String;Ljava/lang/String;[B)[B - -
in 22
class org/spongepowered/asm/mixin/transformer/SyntheticClassInfo 50 public,super,abstract java/lang/Object org/spongepowered/asm/service/ISyntheticClassInfo -
 field protected,final mixin Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; -
 field protected,final name Ljava/lang/String; -
 method protected <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;)V - -
 method public,final getMixin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
 method public getName ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/SyntheticClassRegistry 50 super java/lang/Object org/spongepowered/asm/service/ISyntheticClassRegistry -
 method public findSyntheticClass (Ljava/lang/String;)Lorg/spongepowered/asm/service/ISyntheticClassInfo; - -
in 22
class org/spongepowered/asm/mixin/transformer/TargetClassContext 50 final,super org/spongepowered/asm/mixin/transformer/ClassContext org/spongepowered/asm/mixin/transformer/ext/ITargetClassContext -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass$ValidationFailedException org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass ValidationFailedException public,static
 inner org/spongepowered/asm/mixin/struct/SourceMap$File org/spongepowered/asm/mixin/struct/SourceMap File public,static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public toString ()Ljava/lang/String; - -
 method public getClassNode ()Lorg/objectweb/asm/tree/ClassNode; - -
 method public getClassInfo ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
in 22
class org/spongepowered/asm/mixin/transformer/debug/RuntimeDecompiler 50 public,super org/jetbrains/java/decompiler/main/extern/IFernflowerLogger org/spongepowered/asm/mixin/transformer/ext/IDecompiler,org/jetbrains/java/decompiler/main/extern/IResultSaver -
 inner org/jetbrains/java/decompiler/main/extern/IFernflowerLogger$Severity org/jetbrains/java/decompiler/main/extern/IFernflowerLogger Severity public,static,final,enum
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 field protected,final logger Lorg/spongepowered/asm/logging/ILogger; -
 method public <init> (Ljava/io/File;)V - -
 method public toString ()Ljava/lang/String; - -
 method public decompile (Ljava/io/File;)V - -
 method public saveFolder (Ljava/lang/String;)V - -
 method public saveClassFile (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[I)V - -
 method public startReadingClass (Ljava/lang/String;)V - -
 method public writeMessage (Ljava/lang/String;Lorg/jetbrains/java/decompiler/main/extern/IFernflowerLogger$Severity;)V - -
 method public writeMessage (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public writeMessage (Ljava/lang/String;Lorg/jetbrains/java/decompiler/main/extern/IFernflowerLogger$Severity;Ljava/lang/Throwable;)V - -
 method public copyFile (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public createArchive (Ljava/lang/String;Ljava/lang/String;Ljava/util/jar/Manifest;)V - -
 method public saveDirEntry (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public copyEntry (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public saveClassEntry (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public closeArchive (Ljava/lang/String;Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/debug/RuntimeDecompilerAsync 50 public,super org/spongepowered/asm/mixin/transformer/debug/RuntimeDecompiler java/lang/Runnable,java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Ljava/io/File;)V - -
 method public decompile (Ljava/io/File;)V - -
 method public run ()V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/Extensions 50 public,final,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtensionRegistry -
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 method public <init> (Lorg/spongepowered/asm/service/ISyntheticClassRegistry;)V - -
 method public add (Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;)V - -
 method public getExtensions ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>; -
 method public getActiveExtensions ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>; -
 method public getExtension (Ljava/lang/Class;)Lorg/spongepowered/asm/mixin/transformer/ext/IExtension; <T::Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>(Ljava/lang/Class<+Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>;)TT; -
 method public getSyntheticClassRegistry ()Lorg/spongepowered/asm/service/ISyntheticClassRegistry; - -
 method public select (Lorg/spongepowered/asm/mixin/MixinEnvironment;)V - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
 method public add (Lorg/spongepowered/asm/mixin/transformer/ext/IClassGenerator;)V - -
 method public getGenerators ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ext/IClassGenerator;>; -
 method public getGenerator (Ljava/lang/Class;)Lorg/spongepowered/asm/mixin/transformer/ext/IClassGenerator; <T::Lorg/spongepowered/asm/mixin/transformer/ext/IClassGenerator;>(Ljava/lang/Class<+Lorg/spongepowered/asm/mixin/transformer/ext/IClassGenerator;>;)TT; -
in 22
class org/spongepowered/asm/mixin/transformer/ext/IClassGenerator 50 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract generate (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/IDecompiler 50 public,interface,abstract java/lang/Object - -
 method public,abstract decompile (Ljava/io/File;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/IExtension 50 public,interface,abstract java/lang/Object - -
 method public,abstract checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public,abstract preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public,abstract postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public,abstract export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/IExtensionRegistry 50 public,interface,abstract java/lang/Object - -
 method public,abstract getExtensions ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>; -
 method public,abstract getActiveExtensions ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>; -
 method public,abstract getExtension (Ljava/lang/Class;)Lorg/spongepowered/asm/mixin/transformer/ext/IExtension; <T::Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>(Ljava/lang/Class<+Lorg/spongepowered/asm/mixin/transformer/ext/IExtension;>;)TT; -
 method public,abstract getSyntheticClassRegistry ()Lorg/spongepowered/asm/service/ISyntheticClassRegistry; - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/IHotSwap 50 public,interface,abstract java/lang/Object - -
 method public,abstract registerMixinClass (Ljava/lang/String;)V - -
 method public,abstract registerTargetClass (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/ITargetClassContext 50 public,interface,abstract java/lang/Object - -
 method public,abstract getClassInfo ()Lorg/spongepowered/asm/mixin/transformer/ClassInfo; - -
 method public,abstract getClassNode ()Lorg/objectweb/asm/tree/ClassNode; - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass 50 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass$ValidationFailedException org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass ValidationFailedException public,static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass$ValidationFailedException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 inner org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass$ValidationFailedException org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckClass ValidationFailedException public,static
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionCheckInterfaces 50 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$SearchType org/spongepowered/asm/mixin/transformer/ClassInfo SearchType public,static,final,enum
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Traversal org/spongepowered/asm/mixin/transformer/ClassInfo Traversal public,static,final,enum
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionClassExporter 50 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/mixin/MixinEnvironment;)V - -
 method public isDecompilerActive ()Z - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
 method public dumpClass (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Ljava/io/File; - -
in 1177
class org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionLVTCleaner 50 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner org/spongepowered/asm/util/Locals$SyntheticLocalVariableNode org/spongepowered/asm/util/Locals SyntheticLocalVariableNode public,static
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 1180
class org/spongepowered/asm/mixin/transformer/ext/extensions/ExtensionLVTCleaner 52 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IExtension -
 inner org/spongepowered/asm/util/Locals$SyntheticLocalVariableNode org/spongepowered/asm/util/Locals SyntheticLocalVariableNode public,static
 method public <init> ()V - -
 method public checkActive (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Z - -
 method public preApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public postApply (Lorg/spongepowered/asm/mixin/transformer/ext/ITargetClassContext;)V - -
 method public export (Lorg/spongepowered/asm/mixin/MixinEnvironment;Ljava/lang/String;ZLorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/meta/MixinInner 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract mixin ()Ljava/lang/String; - -
 method public,abstract name ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/meta/MixinMerged 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract mixin ()Ljava/lang/String; - -
 method public,abstract priority ()I - -
in 22
class org/spongepowered/asm/mixin/transformer/meta/MixinProxy 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 22
class org/spongepowered/asm/mixin/transformer/meta/MixinRenamed 50 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract originalName ()Ljava/lang/String; - -
 method public,abstract isInterfaceMember ()Z - -
in 1180
class org/spongepowered/asm/mixin/transformer/struct/Initialiser 52 public,super java/lang/Object - -
 inner org/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode org/spongepowered/asm/mixin/transformer/struct/Initialiser InjectionMode public,static,final,enum
 field protected,static,final OPCODE_BLACKLIST [I -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/MixinTargetContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/mixin/transformer/struct/InsnRange;)V - -
 method public size ()I - -
 method public getMaxStack ()I - -
 method public getCtor ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getInsns ()Ljava/util/Deque; ()Ljava/util/Deque<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
 method public injectInto (Lorg/spongepowered/asm/mixin/injection/struct/Constructor;)V - -
in 1180
class org/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode;>;
 inner org/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode org/spongepowered/asm/mixin/transformer/struct/Initialiser InjectionMode public,static,final,enum
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 field public,static,final,enum DEFAULT Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode; -
 field public,static,final,enum SAFE Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode; -
 method public,static values ()[Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode; - -
 method public,static ofEnvironment (Lorg/spongepowered/asm/mixin/MixinEnvironment;)Lorg/spongepowered/asm/mixin/transformer/struct/Initialiser$InjectionMode; - -
in 1180
class org/spongepowered/asm/mixin/transformer/struct/InsnRange 52 public,super java/lang/Object - -
 field public,final start I -
 field public,final end I -
 field public,final marker I -
 method public <init> (III)V - -
 method public isValid ()Z - -
 method public contains (I)Z - -
 method public excludes (I)Z - -
 method public toString ()Ljava/lang/String; - -
 method public apply (Lorg/objectweb/asm/tree/InsnList;Z)Ljava/util/Deque; (Lorg/objectweb/asm/tree/InsnList;Z)Ljava/util/Deque<Lorg/objectweb/asm/tree/AbstractInsnNode;>; -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/IllegalClassLoadError 50 public,super org/spongepowered/asm/mixin/transformer/throwables/MixinTransformerError - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/InvalidInterfaceMixinException 50 public,super org/spongepowered/asm/mixin/transformer/throwables/InvalidMixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/InvalidMixinException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public getMixin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/MixinApplicatorException 50 public,super org/spongepowered/asm/mixin/transformer/throwables/InvalidMixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/MixinPreProcessorException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/mixin/extensibility/IActivityContext;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/MixinReloadException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;)V - -
 method public getMixinInfo ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/MixinTargetAlreadyLoadedException 50 public,super org/spongepowered/asm/mixin/transformer/throwables/InvalidMixinException - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTarget ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/MixinTransformerError 50 public,super org/spongepowered/asm/mixin/throwables/MixinError - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/mixin/transformer/throwables/ReEntrantTransformerError 50 public,super org/spongepowered/asm/mixin/transformer/throwables/MixinTransformerError - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/obfuscation/RemapperChain 50 public,super java/lang/Object org/spongepowered/asm/mixin/extensibility/IRemapper -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public add (Lorg/spongepowered/asm/mixin/extensibility/IRemapper;)Lorg/spongepowered/asm/obfuscation/RemapperChain; - -
 method public mapMethodName (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public mapFieldName (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public map (Ljava/lang/String;)Ljava/lang/String; - -
 method public unmap (Ljava/lang/String;)Ljava/lang/String; - -
 method public mapDesc (Ljava/lang/String;)Ljava/lang/String; - -
 method public unmapDesc (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/obfuscation/mapping/IMapping 50 public,interface,abstract java/lang/Object - <TMapping:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 method public,abstract getType ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; - -
 method public,abstract move (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TTMapping; -
 method public,abstract remap (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TTMapping; -
 method public,abstract transform (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TTMapping; -
 method public,abstract copy ()Ljava/lang/Object; ()TTMapping; -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getSimpleName ()Ljava/lang/String; - -
 method public,abstract getOwner ()Ljava/lang/String; - -
 method public,abstract getDesc ()Ljava/lang/String; - -
 method public,abstract getSuper ()Ljava/lang/Object; ()TTMapping; -
 method public,abstract serialise ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/obfuscation/mapping/IMapping$Type 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type;>;
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 field public,static,final,enum FIELD Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; -
 field public,static,final,enum METHOD Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; -
 field public,static,final,enum CLASS Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; -
 field public,static,final,enum PACKAGE Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; -
 method public,static values ()[Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; - -
in 22
class org/spongepowered/asm/obfuscation/mapping/common/MappingField 50 public,super java/lang/Object org/spongepowered/asm/obfuscation/mapping/IMapping Ljava/lang/Object;Lorg/spongepowered/asm/obfuscation/mapping/IMapping<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getType ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; - -
 method public getName ()Ljava/lang/String; - -
 method public,final getSimpleName ()Ljava/lang/String; - -
 method public,final getOwner ()Ljava/lang/String; - -
 method public,final getDesc ()Ljava/lang/String; - -
 method public getSuper ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public move (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public remap (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public transform (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public copy ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public serialise ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/obfuscation/mapping/common/MappingMethod 50 public,super java/lang/Object org/spongepowered/asm/obfuscation/mapping/IMapping Ljava/lang/Object;Lorg/spongepowered/asm/obfuscation/mapping/IMapping<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getType ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; - -
 method public getName ()Ljava/lang/String; - -
 method public getSimpleName ()Ljava/lang/String; - -
 method public getOwner ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getSuper ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public isConstructor ()Z - -
 method public move (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public remap (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public transform (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public copy ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public addPrefix (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public serialise ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/obfuscation/mapping/mcp/MappingFieldSrg 50 public,super org/spongepowered/asm/obfuscation/mapping/common/MappingField - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)V - -
 method public serialise ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/service/IClassBytecodeProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract getClassNode (Ljava/lang/String;)Lorg/objectweb/asm/tree/ClassNode; - java/lang/ClassNotFoundException,java/io/IOException
 method public,abstract getClassNode (Ljava/lang/String;Z)Lorg/objectweb/asm/tree/ClassNode; - java/lang/ClassNotFoundException,java/io/IOException
in 22
class org/spongepowered/asm/service/IClassProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract,deprecated getClassPath ()[Ljava/net/URL; - -
 method public,abstract findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public,abstract findClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public,abstract findAgentClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
in 22
class org/spongepowered/asm/service/IClassTracker 50 public,interface,abstract java/lang/Object - -
 method public,abstract registerInvalidClass (Ljava/lang/String;)V - -
 method public,abstract isClassLoaded (Ljava/lang/String;)Z - -
 method public,abstract getClassRestrictions (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/service/IGlobalPropertyService 50 public,interface,abstract java/lang/Object - -
 method public,abstract resolveKey (Ljava/lang/String;)Lorg/spongepowered/asm/service/IPropertyKey; - -
 method public,abstract getProperty (Lorg/spongepowered/asm/service/IPropertyKey;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/service/IPropertyKey;)TT; -
 method public,abstract setProperty (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/Object;)V - -
 method public,abstract getProperty (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/service/IPropertyKey;TT;)TT; -
 method public,abstract getPropertyString (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/service/ILegacyClassTransformer 50 public,interface,abstract java/lang/Object org/spongepowered/asm/service/ITransformer -
 method public,abstract transformClassBytes (Ljava/lang/String;Ljava/lang/String;[B)[B - -
in 22
class org/spongepowered/asm/service/IMixinAuditTrail 50 public,interface,abstract java/lang/Object - -
 method public,abstract onApply (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,abstract onPostProcess (Ljava/lang/String;)V - -
 method public,abstract onGenerate (Ljava/lang/String;Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/service/IMixinInternal 50 public,interface,abstract java/lang/Object - -
in 22
class org/spongepowered/asm/service/IMixinService 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract isValid ()Z - -
 method public,abstract prepare ()V - -
 method public,abstract getInitialPhase ()Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; - -
 method public,abstract offer (Lorg/spongepowered/asm/service/IMixinInternal;)V - -
 method public,abstract init ()V - -
 method public,abstract beginPhase ()V - -
 method public,abstract checkEnv (Ljava/lang/Object;)V - -
 method public,abstract getReEntranceLock ()Lorg/spongepowered/asm/util/ReEntranceLock; - -
 method public,abstract getClassProvider ()Lorg/spongepowered/asm/service/IClassProvider; - -
 method public,abstract getBytecodeProvider ()Lorg/spongepowered/asm/service/IClassBytecodeProvider; - -
 method public,abstract getTransformerProvider ()Lorg/spongepowered/asm/service/ITransformerProvider; - -
 method public,abstract getClassTracker ()Lorg/spongepowered/asm/service/IClassTracker; - -
 method public,abstract getAuditTrail ()Lorg/spongepowered/asm/service/IMixinAuditTrail; - -
 method public,abstract getPlatformAgents ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,abstract getPrimaryContainer ()Lorg/spongepowered/asm/launch/platform/container/IContainerHandle; - -
 method public,abstract getMixinContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
 method public,abstract getResourceAsStream (Ljava/lang/String;)Ljava/io/InputStream; - -
 method public,abstract getSideName ()Ljava/lang/String; - -
 method public,abstract getMinCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public,abstract getMaxCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public,abstract getLogger (Ljava/lang/String;)Lorg/spongepowered/asm/logging/ILogger; - -
in 22
class org/spongepowered/asm/service/IMixinServiceBootstrap 50 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getServiceClassName ()Ljava/lang/String; - -
 method public,abstract bootstrap ()V - -
in 22
class org/spongepowered/asm/service/IPropertyKey 50 public,interface,abstract java/lang/Object - -
in 22
class org/spongepowered/asm/service/ISyntheticClassInfo 50 public,interface,abstract java/lang/Object - -
 method public,abstract getMixin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getClassName ()Ljava/lang/String; - -
 method public,abstract isLoaded ()Z - -
in 22
class org/spongepowered/asm/service/ISyntheticClassRegistry 50 public,interface,abstract java/lang/Object - -
 method public,abstract findSyntheticClass (Ljava/lang/String;)Lorg/spongepowered/asm/service/ISyntheticClassInfo; - -
in 22
class org/spongepowered/asm/service/ITransformer 50 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract isDelegationExcluded ()Z - -
in 22
class org/spongepowered/asm/service/ITransformerProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract getTransformers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/service/ITransformer;>; -
 method public,abstract getDelegatedTransformers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/service/ITransformer;>; -
 method public,abstract addTransformerExclusion (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/service/ITreeClassTransformer 50 public,interface,abstract java/lang/Object org/spongepowered/asm/service/ITransformer -
 method public,abstract transformClassNode (Ljava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/service/MixinService 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/service/MixinService$LogBuffer org/spongepowered/asm/service/MixinService LogBuffer static
 method public,static boot ()V - -
 method public,static getService ()Lorg/spongepowered/asm/service/IMixinService; - -
 method public,static getGlobalPropertyService ()Lorg/spongepowered/asm/service/IGlobalPropertyService; - -
in 22
class org/spongepowered/asm/service/MixinService$LogBuffer 50 super java/lang/Object - -
 inner org/spongepowered/asm/service/MixinService$LogBuffer org/spongepowered/asm/service/MixinService LogBuffer static
 inner org/spongepowered/asm/service/MixinService$LogBuffer$LogEntry org/spongepowered/asm/service/MixinService$LogBuffer LogEntry public,static
in 22
class org/spongepowered/asm/service/MixinService$LogBuffer$LogEntry 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/service/MixinService$LogBuffer org/spongepowered/asm/service/MixinService LogBuffer static
 inner org/spongepowered/asm/service/MixinService$LogBuffer$LogEntry org/spongepowered/asm/service/MixinService$LogBuffer LogEntry public,static
 field public message Ljava/lang/String; -
 field public params [Ljava/lang/Object; -
 field public t Ljava/lang/Throwable; -
 method public <init> (Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/service/MixinServiceAbstract 50 public,super,abstract java/lang/Object org/spongepowered/asm/service/IMixinService -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 field protected,static,final LAUNCH_PACKAGE Ljava/lang/String; - "org.spongepowered.asm.launch."
 field protected,static,final MIXIN_PACKAGE Ljava/lang/String; - "org.spongepowered.asm.mixin."
 field protected,static,final SERVICE_PACKAGE Ljava/lang/String; - "org.spongepowered.asm.service."
 field protected,final lock Lorg/spongepowered/asm/util/ReEntranceLock; -
 method protected <init> ()V - -
 method public prepare ()V - -
 method public getInitialPhase ()Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; - -
 method public getMinCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public getMaxCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method public offer (Lorg/spongepowered/asm/service/IMixinInternal;)V - -
 method protected,final getInternal (Ljava/lang/Class;)Lorg/spongepowered/asm/service/IMixinInternal; <T::Lorg/spongepowered/asm/service/IMixinInternal;>(Ljava/lang/Class<TT;>;)TT; -
 method public init ()V - -
 method public beginPhase ()V - -
 method public checkEnv (Ljava/lang/Object;)V - -
 method public getReEntranceLock ()Lorg/spongepowered/asm/util/ReEntranceLock; - -
 method public getMixinContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
 method protected,final getContainersFromAgents (Lcom/google/common/collect/ImmutableList$Builder;)V (Lcom/google/common/collect/ImmutableList$Builder<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>;)V -
 method public,final getSideName ()Ljava/lang/String; - -
 method public,synchronized getLogger (Ljava/lang/String;)Lorg/spongepowered/asm/logging/ILogger; - -
 method protected createLogger (Ljava/lang/String;)Lorg/spongepowered/asm/logging/ILogger; - -
 method public,deprecated wire (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer;)V (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;>;)V -
 method public,deprecated unwire ()V - -
in 22
class org/spongepowered/asm/service/ServiceInitialisationException 50 public,super java/lang/RuntimeException - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/service/ServiceNotAvailableError 50 public,super java/lang/Error - -
 method public <init> (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/service/ServiceVersionError 50 public,super java/lang/Error - -
 method public <init> (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/service/modlauncher/Blackboard 52 public,super java/lang/Object org/spongepowered/asm/service/IGlobalPropertyService -
 inner org/spongepowered/asm/service/modlauncher/Blackboard$Key org/spongepowered/asm/service/modlauncher/Blackboard Key -
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public resolveKey (Ljava/lang/String;)Lorg/spongepowered/asm/service/IPropertyKey; - -
 method public getProperty (Lorg/spongepowered/asm/service/IPropertyKey;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/service/IPropertyKey;)TT; -
 method public setProperty (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/Object;)V - -
 method public getPropertyString (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/String;)Ljava/lang/String; - -
 method public getProperty (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/service/IPropertyKey;TT;)TT; -
in 22
class org/spongepowered/asm/service/modlauncher/Blackboard$Key 52 super java/lang/Object org/spongepowered/asm/service/IPropertyKey <V:Ljava/lang/Object;>Ljava/lang/Object;Lorg/spongepowered/asm/service/IPropertyKey;
 inner cpw/mods/modlauncher/api/TypesafeMap$Key cpw/mods/modlauncher/api/TypesafeMap Key public,static,final
 inner org/spongepowered/asm/service/modlauncher/Blackboard$Key org/spongepowered/asm/service/modlauncher/Blackboard Key -
 method public <init> (Lorg/spongepowered/asm/service/modlauncher/Blackboard;Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class;)V (Lcpw/mods/modlauncher/api/TypesafeMap;Ljava/lang/String;Ljava/lang/Class<TV;>;)V -
in 22
class org/spongepowered/asm/service/modlauncher/LoggerAdapterLog4j2 52 public,super org/spongepowered/asm/logging/LoggerAdapterAbstract - -
 method public <init> (Ljava/lang/String;)V - -
 method public getType ()Ljava/lang/String; - -
 method public catching (Lorg/spongepowered/asm/logging/Level;Ljava/lang/Throwable;)V - -
 method public catching (Ljava/lang/Throwable;)V - -
 method public,varargs debug (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public debug (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs error (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public error (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs fatal (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public fatal (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs info (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public info (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public throwing (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,varargs trace (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public trace (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs warn (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public warn (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/service/modlauncher/MixinServiceModLauncher 52 public,super org/spongepowered/asm/service/MixinServiceAbstract - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 method public <init> ()V - -
 method public onInit (Lorg/spongepowered/asm/service/IClassBytecodeProvider;)V - -
 method public onStartup ()V - -
 method public offer (Lorg/spongepowered/asm/service/IMixinInternal;)V - -
 method public wire (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer;)V (Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;Lorg/spongepowered/asm/util/IConsumer<Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getMinCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method protected createLogger (Ljava/lang/String;)Lorg/spongepowered/asm/logging/ILogger; - -
 method public isValid ()Z - -
 method public getClassProvider ()Lorg/spongepowered/asm/service/IClassProvider; - -
 method public getBytecodeProvider ()Lorg/spongepowered/asm/service/IClassBytecodeProvider; - -
 method public getTransformerProvider ()Lorg/spongepowered/asm/service/ITransformerProvider; - -
 method public getClassTracker ()Lorg/spongepowered/asm/service/IClassTracker; - -
 method public getAuditTrail ()Lorg/spongepowered/asm/service/IMixinAuditTrail; - -
 method public getPlatformAgents ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getPrimaryContainer ()Lorg/spongepowered/asm/launch/platform/container/ContainerHandleModLauncher; - -
 method public getResourceAsStream (Ljava/lang/String;)Ljava/io/InputStream; - -
 method public getProcessors ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/IClassProcessor;>; -
in 22
class org/spongepowered/asm/service/modlauncher/MixinServiceModLauncherBootstrap 52 public,super java/lang/Object org/spongepowered/asm/service/IMixinServiceBootstrap -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getServiceClassName ()Ljava/lang/String; - -
 method public bootstrap ()V - -
in 22
class org/spongepowered/asm/service/modlauncher/MixinTransformationHandler 52 public,super java/lang/Object org/spongepowered/asm/launch/IClassProcessor -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 method public <init> ()V - -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public generatesClass (Lorg/objectweb/asm/Type;)Z - -
 method public,synchronized processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public generateClass (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/service/modlauncher/ModLauncherAuditTrail 52 public,super java/lang/Object org/spongepowered/asm/service/IMixinAuditTrail -
 method public <init> ()V - -
 method public setConsumer (Ljava/lang/String;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/function/Consumer<[Ljava/lang/String;>;)V -
 method public onApply (Ljava/lang/String;Ljava/lang/String;)V - -
 method public onPostProcess (Ljava/lang/String;)V - -
 method public onGenerate (Ljava/lang/String;Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/service/modlauncher/ModLauncherClassProvider 52 super java/lang/Object org/spongepowered/asm/service/IClassProvider -
 method public,deprecated getClassPath ()[Ljava/net/URL; - -
 method public findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public findClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public findAgentClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
in 22
class org/spongepowered/asm/service/modlauncher/ModLauncherClassTracker 52 public,super java/lang/Object org/spongepowered/asm/launch/IClassProcessor,org/spongepowered/asm/service/IClassTracker -
 inner cpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase cpw/mods/modlauncher/serviceapi/ILaunchPluginService Phase public,static,final,enum
 method public <init> ()V - -
 method public registerInvalidClass (Ljava/lang/String;)V - -
 method public isClassLoaded (Ljava/lang/String;)Z - -
 method public getClassRestrictions (Ljava/lang/String;)Ljava/lang/String; - -
 method public handlesClass (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet; (Lorg/objectweb/asm/Type;ZLjava/lang/String;)Ljava/util/EnumSet<Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;>; -
 method public processClass (Lcpw/mods/modlauncher/serviceapi/ILaunchPluginService$Phase;Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/Type;Ljava/lang/String;)Z - -
 method public generatesClass (Lorg/objectweb/asm/Type;)Z - -
 method public generateClass (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/ClassNode;)Z - -
in 22
class org/spongepowered/asm/service/mojang/Blackboard 52 public,super java/lang/Object org/spongepowered/asm/service/IGlobalPropertyService -
 inner org/spongepowered/asm/service/mojang/Blackboard$Key org/spongepowered/asm/service/mojang/Blackboard Key -
 method public <init> ()V - -
 method public resolveKey (Ljava/lang/String;)Lorg/spongepowered/asm/service/IPropertyKey; - -
 method public,final getProperty (Lorg/spongepowered/asm/service/IPropertyKey;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/service/IPropertyKey;)TT; -
 method public,final setProperty (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/Object;)V - -
 method public,final getProperty (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/service/IPropertyKey;TT;)TT; -
 method public,final getPropertyString (Lorg/spongepowered/asm/service/IPropertyKey;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/service/mojang/Blackboard$Key 52 super java/lang/Object org/spongepowered/asm/service/IPropertyKey -
 inner org/spongepowered/asm/service/mojang/Blackboard$Key org/spongepowered/asm/service/mojang/Blackboard Key -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/service/mojang/LaunchClassLoaderUtil 52 final,super java/lang/Object org/spongepowered/asm/service/IClassTracker -
 method public isClassLoaded (Ljava/lang/String;)Z - -
 method public getClassRestrictions (Ljava/lang/String;)Ljava/lang/String; - -
 method public registerInvalidClass (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/service/mojang/LegacyTransformerHandle 52 super java/lang/Object org/spongepowered/asm/service/ILegacyClassTransformer -
 method public getName ()Ljava/lang/String; - -
 method public isDelegationExcluded ()Z - -
 method public transformClassBytes (Ljava/lang/String;Ljava/lang/String;[B)[B - -
in 22
class org/spongepowered/asm/service/mojang/LoggerAdapterLog4j2 52 public,super org/spongepowered/asm/logging/LoggerAdapterAbstract - -
 method public <init> (Ljava/lang/String;)V - -
 method public getType ()Ljava/lang/String; - -
 method public catching (Lorg/spongepowered/asm/logging/Level;Ljava/lang/Throwable;)V - -
 method public catching (Ljava/lang/Throwable;)V - -
 method public,varargs debug (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public debug (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs error (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public error (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs fatal (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public fatal (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs info (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public info (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public log (Lorg/spongepowered/asm/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public throwing (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,varargs trace (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public trace (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs warn (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public warn (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/service/mojang/MixinServiceLaunchWrapper 52 public,super org/spongepowered/asm/service/MixinServiceAbstract org/spongepowered/asm/service/IClassProvider,org/spongepowered/asm/service/IClassBytecodeProvider,org/spongepowered/asm/service/ITransformerProvider -
 inner org/spongepowered/asm/launch/GlobalProperties$Keys org/spongepowered/asm/launch/GlobalProperties Keys public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$Phase org/spongepowered/asm/mixin/MixinEnvironment Phase public,static,final
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/util/Constants$ManifestAttributes org/spongepowered/asm/util/Constants ManifestAttributes public,static,abstract
 field public,static,final BLACKBOARD_KEY_TWEAKCLASSES Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 field public,static,final BLACKBOARD_KEY_TWEAKS Lorg/spongepowered/asm/launch/GlobalProperties$Keys; -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public isValid ()Z - -
 method public prepare ()V - -
 method public getInitialPhase ()Lorg/spongepowered/asm/mixin/MixinEnvironment$Phase; - -
 method public getMaxCompatibilityLevel ()Lorg/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel; - -
 method protected createLogger (Ljava/lang/String;)Lorg/spongepowered/asm/logging/ILogger; - -
 method public init ()V - -
 method public getPlatformAgents ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public getPrimaryContainer ()Lorg/spongepowered/asm/launch/platform/container/IContainerHandle; - -
 method public getMixinContainers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/launch/platform/container/IContainerHandle;>; -
 method public getClassProvider ()Lorg/spongepowered/asm/service/IClassProvider; - -
 method public getBytecodeProvider ()Lorg/spongepowered/asm/service/IClassBytecodeProvider; - -
 method public getTransformerProvider ()Lorg/spongepowered/asm/service/ITransformerProvider; - -
 method public getClassTracker ()Lorg/spongepowered/asm/service/IClassTracker; - -
 method public getAuditTrail ()Lorg/spongepowered/asm/service/IMixinAuditTrail; - -
 method public findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public findClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public findAgentClass (Ljava/lang/String;Z)Ljava/lang/Class; (Ljava/lang/String;Z)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public beginPhase ()V - -
 method public checkEnv (Ljava/lang/Object;)V - -
 method public getResourceAsStream (Ljava/lang/String;)Ljava/io/InputStream; - -
 method public,deprecated getClassPath ()[Ljava/net/URL; - -
 method public getTransformers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/service/ITransformer;>; -
 method public getDelegatedTransformers ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/asm/service/ITransformer;>; -
 method public addTransformerExclusion (Ljava/lang/String;)V - -
 method public,deprecated getClassBytes (Ljava/lang/String;Ljava/lang/String;)[B - java/io/IOException
 method public,deprecated getClassBytes (Ljava/lang/String;Z)[B - java/lang/ClassNotFoundException,java/io/IOException
 method public getClassNode (Ljava/lang/String;)Lorg/objectweb/asm/tree/ClassNode; - java/lang/ClassNotFoundException,java/io/IOException
 method public getClassNode (Ljava/lang/String;Z)Lorg/objectweb/asm/tree/ClassNode; - java/lang/ClassNotFoundException,java/io/IOException
in 22
class org/spongepowered/asm/service/mojang/MixinServiceLaunchWrapperBootstrap 52 public,super java/lang/Object org/spongepowered/asm/service/IMixinServiceBootstrap -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getServiceClassName ()Ljava/lang/String; - -
 method public bootstrap ()V - -
in 22
class org/spongepowered/asm/transformers/MixinClassReader 50 public,super org/objectweb/asm/ClassReader - -
 method public <init> ([BLjava/lang/String;)V - -
in 22
class org/spongepowered/asm/transformers/MixinClassWriter 50 public,super org/objectweb/asm/ClassWriter - -
 method public <init> (I)V - -
 method public <init> (Lorg/objectweb/asm/ClassReader;I)V - -
 method protected getCommonSuperClass (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/transformers/TreeTransformer 50 public,super,abstract java/lang/Object org/spongepowered/asm/service/ILegacyClassTransformer -
 method public <init> ()V - -
 method protected,final readClass (Ljava/lang/String;[B)Lorg/objectweb/asm/tree/ClassNode; - -
 method protected,final readClass (Ljava/lang/String;[BZ)Lorg/objectweb/asm/tree/ClassNode; - -
 method protected,final writeClass (Lorg/objectweb/asm/tree/ClassNode;)[B - -
in 22
class org/spongepowered/asm/util/Annotations 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/util/Annotations$Handle org/spongepowered/asm/util/Annotations Handle public,static
 method public,static handleOf (Ljava/lang/Object;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public,static getDesc (Ljava/lang/Class;)Ljava/lang/String; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Ljava/lang/String; -
 method public,static getSimpleName (Ljava/lang/Class;)Ljava/lang/String; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Ljava/lang/String; -
 method public,static getSimpleName (Lorg/objectweb/asm/tree/AnnotationNode;)Ljava/lang/String; - -
 method public,static,varargs setVisible (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class;[Ljava/lang/Object;)V (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;[Ljava/lang/Object;)V -
 method public,static,varargs setInvisible (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class;[Ljava/lang/Object;)V (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;[Ljava/lang/Object;)V -
 method public,static,varargs setVisible (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;[Ljava/lang/Object;)V (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;[Ljava/lang/Object;)V -
 method public,static,varargs setInvisible (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;[Ljava/lang/Object;)V (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;[Ljava/lang/Object;)V -
 method public,static getVisible (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getInvisible (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/FieldNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getVisible (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getInvisible (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static,varargs getSingleVisible (Lorg/objectweb/asm/tree/MethodNode;[Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/MethodNode;[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static,varargs getSingleInvisible (Lorg/objectweb/asm/tree/MethodNode;[Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/MethodNode;[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getVisible (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getInvisible (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/Class;)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getVisibleParameter (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;I)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;I)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getInvisibleParameter (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class;I)Lorg/objectweb/asm/tree/AnnotationNode; (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;I)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getParameter ([Ljava/util/List;Ljava/lang/String;I)Lorg/objectweb/asm/tree/AnnotationNode; ([Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;Ljava/lang/String;I)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static get (Ljava/util/List;Ljava/lang/String;)Lorg/objectweb/asm/tree/AnnotationNode; (Ljava/util/List<Lorg/objectweb/asm/tree/AnnotationNode;>;Ljava/lang/String;)Lorg/objectweb/asm/tree/AnnotationNode; -
 method public,static getValue (Lorg/objectweb/asm/tree/AnnotationNode;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/AnnotationNode;)TT; -
 method public,static getValue (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;TT;)TT; -
 method public,static getValue (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Ljava/lang/Class<*>;)TT; -
 method public,static getValue (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;)TT; -
 method public,static getValue (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Enum;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Ljava/lang/Class<TT;>;TT;)TT; -
 method public,static getValue (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Z)Ljava/util/List; <T:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Z)Ljava/util/List<TT;>; -
 method public,static getValue (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;ZLjava/lang/Class;)Ljava/util/List; <T:Ljava/lang/Enum<TT;>;>(Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;ZLjava/lang/Class<TT;>;)Ljava/util/List<TT;>; -
 method public,static setValue (Lorg/objectweb/asm/tree/AnnotationNode;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,static merge (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public,static merge (Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public,static merge (Lorg/objectweb/asm/tree/FieldNode;Lorg/objectweb/asm/tree/FieldNode;)V - -
in 22
class org/spongepowered/asm/util/Annotations$Handle 50 public,super java/lang/Object org/spongepowered/asm/util/asm/IAnnotationHandle -
 inner org/spongepowered/asm/util/Annotations$Handle org/spongepowered/asm/util/Annotations Handle public,static
 method public exists ()Z - -
 method public getNode ()Lorg/objectweb/asm/tree/AnnotationNode; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getAnnotationList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lorg/spongepowered/asm/util/asm/IAnnotationHandle;>; -
 method public getTypeValue (Ljava/lang/String;)Lorg/objectweb/asm/Type; - -
 method public getTypeList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/Type;>; -
 method public getAnnotation (Ljava/lang/String;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getValue (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public getValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public getValue (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public getBoolean (Ljava/lang/String;Z)Z - -
 method public getList ()Ljava/util/List; <T:Ljava/lang/Object;>()Ljava/util/List<TT;>; -
 method public getList (Ljava/lang/String;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/lang/String;)Ljava/util/List<TT;>; -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/Bytecode 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/util/Bytecode$DelegateInitialiser org/spongepowered/asm/util/Bytecode DelegateInitialiser public,static
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 inner org/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem org/spongepowered/asm/util/throwables/SyntheticBridgeException Problem public,static,final,enum
 field public,static,final CONSTANTS_INT [I -
 field public,static,final CONSTANTS_FLOAT [I -
 field public,static,final CONSTANTS_DOUBLE [I -
 field public,static,final CONSTANTS_LONG [I -
 field public,static,final CONSTANTS_ALL [I -
 method public,static findMethod (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;Ljava/lang/String;)Lorg/objectweb/asm/tree/MethodNode; - -
 method public,static findInsn (Lorg/objectweb/asm/tree/MethodNode;I)Lorg/objectweb/asm/tree/AbstractInsnNode; - -
 method public,static findDelegateInit (Lorg/objectweb/asm/tree/MethodNode;Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/util/Bytecode$DelegateInitialiser; - -
 method public,static textify (Lorg/objectweb/asm/tree/ClassNode;Ljava/io/OutputStream;)V - -
 method public,static textify (Lorg/objectweb/asm/tree/MethodNode;Ljava/io/OutputStream;)V - -
 method public,static dumpClass (Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public,static dumpClass ([B)V - -
 method public,static printMethodWithOpcodeIndices (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public,static printMethod (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public,static printNode (Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public,static describeNode (Lorg/objectweb/asm/tree/AbstractInsnNode;)Ljava/lang/String; - -
 method public,static describeNode (Lorg/objectweb/asm/tree/AbstractInsnNode;Z)Ljava/lang/String; - -
 method public,static getOpcodeName (Lorg/objectweb/asm/tree/AbstractInsnNode;)Ljava/lang/String; - -
 method public,static getOpcodeName (I)Ljava/lang/String; - -
 method public,static methodHasLineNumbers (Lorg/objectweb/asm/tree/MethodNode;)Z - -
 method public,static isStatic (Lorg/objectweb/asm/tree/MethodNode;)Z - -
 method public,static isStatic (Lorg/objectweb/asm/tree/FieldNode;)Z - -
 method public,static getFirstNonArgLocalIndex (Lorg/objectweb/asm/tree/MethodNode;)I - -
 method public,static getFirstNonArgLocalIndex ([Lorg/objectweb/asm/Type;Z)I - -
 method public,static getArgsSize ([Lorg/objectweb/asm/Type;)I - -
 method public,static getArgsSize ([Lorg/objectweb/asm/Type;II)I - -
 method public,static loadArgs ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;I)V - -
 method public,static loadArgs ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;II)V - -
 method public,static loadArgs ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;II[Lorg/objectweb/asm/Type;)V - -
 method public,static,varargs getTypes ([Ljava/lang/Class;)[Lorg/objectweb/asm/Type; ([Ljava/lang/Class<*>;)[Lorg/objectweb/asm/Type; -
 method public,static cloneLabels (Lorg/objectweb/asm/tree/InsnList;)Ljava/util/Map; (Lorg/objectweb/asm/tree/InsnList;)Ljava/util/Map<Lorg/objectweb/asm/tree/LabelNode;Lorg/objectweb/asm/tree/LabelNode;>; -
 method public,static,varargs generateDescriptor (Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static,varargs generateDescriptor (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs getDescriptor ([Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static,varargs getDescriptor (Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static changeDescriptorReturnType (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getSimpleName (Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static getSimpleName (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static isConstant (Lorg/objectweb/asm/tree/AbstractInsnNode;)Z - -
 method public,static getConstant (Lorg/objectweb/asm/tree/AbstractInsnNode;)Ljava/lang/Object; - -
 method public,static getConstantType (Lorg/objectweb/asm/tree/AbstractInsnNode;)Lorg/objectweb/asm/Type; - -
 method public,static hasFlag (Lorg/objectweb/asm/tree/ClassNode;I)Z - -
 method public,static hasFlag (Lorg/objectweb/asm/tree/MethodNode;I)Z - -
 method public,static hasFlag (Lorg/objectweb/asm/tree/FieldNode;I)Z - -
 method public,static compareFlags (Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/MethodNode;I)Z - -
 method public,static compareFlags (Lorg/objectweb/asm/tree/FieldNode;Lorg/objectweb/asm/tree/FieldNode;I)Z - -
 method public,static isVirtual (Lorg/objectweb/asm/tree/MethodNode;)Z - -
 method public,static getVisibility (Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
 method public,static getVisibility (Lorg/objectweb/asm/tree/FieldNode;)Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
 method public,static setVisibility (Lorg/objectweb/asm/tree/ClassNode;Lorg/spongepowered/asm/util/Bytecode$Visibility;)V - -
 method public,static setVisibility (Lorg/objectweb/asm/tree/MethodNode;Lorg/spongepowered/asm/util/Bytecode$Visibility;)V - -
 method public,static setVisibility (Lorg/objectweb/asm/tree/FieldNode;Lorg/spongepowered/asm/util/Bytecode$Visibility;)V - -
 method public,static setVisibility (Lorg/objectweb/asm/tree/ClassNode;I)V - -
 method public,static setVisibility (Lorg/objectweb/asm/tree/MethodNode;I)V - -
 method public,static setVisibility (Lorg/objectweb/asm/tree/FieldNode;I)V - -
 method public,static getMaxLineNumber (Lorg/objectweb/asm/tree/ClassNode;II)I - -
 method public,static getBoxingType (Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static getUnboxingMethod (Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static compareBridgeMethods (Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public,static merge (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public,static replace (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/ClassNode;)V - -
in 22
class org/spongepowered/asm/util/Bytecode$DelegateInitialiser 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/util/Bytecode$DelegateInitialiser org/spongepowered/asm/util/Bytecode DelegateInitialiser public,static
 field public,static,final NONE Lorg/spongepowered/asm/util/Bytecode$DelegateInitialiser; -
 field public,final insn Lorg/objectweb/asm/tree/MethodInsnNode; -
 field public,final isSuper Z -
 field public,final isPresent Z -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/Bytecode$Visibility 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/util/Bytecode$Visibility;>;
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 field public,static,final,enum PRIVATE Lorg/spongepowered/asm/util/Bytecode$Visibility; -
 field public,static,final,enum PROTECTED Lorg/spongepowered/asm/util/Bytecode$Visibility; -
 field public,static,final,enum PACKAGE Lorg/spongepowered/asm/util/Bytecode$Visibility; -
 field public,static,final,enum PUBLIC Lorg/spongepowered/asm/util/Bytecode$Visibility; -
 method public,static values ()[Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
 method public isAtLeast (Lorg/spongepowered/asm/util/Bytecode$Visibility;)Z - -
 method public isLessThan (Lorg/spongepowered/asm/util/Bytecode$Visibility;)Z - -
in 22
class org/spongepowered/asm/util/ClassSignature 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureRemapper org/spongepowered/asm/util/ClassSignature SignatureRemapper -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$TokenHandle org/spongepowered/asm/util/ClassSignature TokenHandle -
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 inner org/spongepowered/asm/util/ClassSignature$IToken org/spongepowered/asm/util/ClassSignature IToken static,interface,abstract
 inner org/spongepowered/asm/util/ClassSignature$TypeVar org/spongepowered/asm/util/ClassSignature TypeVar static
 inner org/spongepowered/asm/util/ClassSignature$Lazy org/spongepowered/asm/util/ClassSignature Lazy static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field protected,static,final OBJECT Ljava/lang/String; - "java/lang/Object"
 method protected getTypeVar (Ljava/lang/String;)Lorg/spongepowered/asm/util/ClassSignature$TypeVar; - -
 method protected getType (Ljava/lang/String;)Lorg/spongepowered/asm/util/ClassSignature$TokenHandle; - -
 method protected getTypeVar (Lorg/spongepowered/asm/util/ClassSignature$TokenHandle;)Ljava/lang/String; - -
 method protected addTypeVar (Lorg/spongepowered/asm/util/ClassSignature$TypeVar;Lorg/spongepowered/asm/util/ClassSignature$TokenHandle;)V - java/lang/IllegalArgumentException
 method protected setSuperClass (Lorg/spongepowered/asm/util/ClassSignature$Token;)V - -
 method public getSuperClass ()Ljava/lang/String; - -
 method protected addInterface (Lorg/spongepowered/asm/util/ClassSignature$Token;)V - -
 method public addInterface (Ljava/lang/String;)V - -
 method protected addRawInterface (Ljava/lang/String;)V - -
 method public merge (Lorg/spongepowered/asm/util/ClassSignature;)V - -
 method public getRemapper ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public toString ()Ljava/lang/String; - -
 method public wake ()Lorg/spongepowered/asm/util/ClassSignature; - -
 method public,static of (Ljava/lang/String;)Lorg/spongepowered/asm/util/ClassSignature; - -
 method public,static of (Lorg/objectweb/asm/tree/ClassNode;)Lorg/spongepowered/asm/util/ClassSignature; - -
 method public,static ofLazy (Lorg/objectweb/asm/tree/ClassNode;)Lorg/spongepowered/asm/util/ClassSignature; - -
in 22
class org/spongepowered/asm/util/ClassSignature$IToken 50 interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 inner org/spongepowered/asm/util/ClassSignature$IToken org/spongepowered/asm/util/ClassSignature IToken static,interface,abstract
 field public,static,final WILDCARDS Ljava/lang/String; - "+-"
 method public,abstract asType ()Ljava/lang/String; - -
 method public,abstract asBound ()Ljava/lang/String; - -
 method public,abstract asToken ()Lorg/spongepowered/asm/util/ClassSignature$Token; - -
 method public,abstract setArray (Z)Lorg/spongepowered/asm/util/ClassSignature$IToken; - -
 method public,abstract setWildcard (C)Lorg/spongepowered/asm/util/ClassSignature$IToken; - -
in 22
class org/spongepowered/asm/util/ClassSignature$Lazy 50 super org/spongepowered/asm/util/ClassSignature - -
 inner org/spongepowered/asm/util/ClassSignature$Lazy org/spongepowered/asm/util/ClassSignature Lazy static
 method public wake ()Lorg/spongepowered/asm/util/ClassSignature; - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser 50 super org/objectweb/asm/signature/SignatureVisitor - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$InterfaceElement org/spongepowered/asm/util/ClassSignature$SignatureParser InterfaceElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$SuperClassElement org/spongepowered/asm/util/ClassSignature$SignatureParser SuperClassElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$BoundElement org/spongepowered/asm/util/ClassSignature$SignatureParser BoundElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TypeArgElement org/spongepowered/asm/util/ClassSignature$SignatureParser TypeArgElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$FormalParamElement org/spongepowered/asm/util/ClassSignature$SignatureParser FormalParamElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement org/spongepowered/asm/util/ClassSignature$SignatureParser TokenElement abstract
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$SignatureElement org/spongepowered/asm/util/ClassSignature$SignatureParser SignatureElement abstract
 method public visitFormalTypeParameter (Ljava/lang/String;)V - -
 method public visitClassBound ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitInterfaceBound ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitSuperclass ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitInterface ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser$BoundElement 50 super org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement org/spongepowered/asm/util/ClassSignature$SignatureParser TokenElement abstract
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$BoundElement org/spongepowered/asm/util/ClassSignature$SignatureParser BoundElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TypeArgElement org/spongepowered/asm/util/ClassSignature$SignatureParser TypeArgElement -
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 inner org/spongepowered/asm/util/ClassSignature$IToken org/spongepowered/asm/util/ClassSignature IToken static,interface,abstract
 method public visitClassType (Ljava/lang/String;)V - -
 method public visitTypeArgument ()V - -
 method public visitTypeArgument (C)Lorg/objectweb/asm/signature/SignatureVisitor; - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser$FormalParamElement 50 super org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement - -
 inner org/spongepowered/asm/util/ClassSignature$TokenHandle org/spongepowered/asm/util/ClassSignature TokenHandle -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$FormalParamElement org/spongepowered/asm/util/ClassSignature$SignatureParser FormalParamElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement org/spongepowered/asm/util/ClassSignature$SignatureParser TokenElement abstract
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser$InterfaceElement 50 super org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$InterfaceElement org/spongepowered/asm/util/ClassSignature$SignatureParser InterfaceElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement org/spongepowered/asm/util/ClassSignature$SignatureParser TokenElement abstract
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 method public visitEnd ()V - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser$SignatureElement 50 super,abstract org/objectweb/asm/signature/SignatureVisitor - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$SignatureElement org/spongepowered/asm/util/ClassSignature$SignatureParser SignatureElement abstract
 method public <init> (Lorg/spongepowered/asm/util/ClassSignature$SignatureParser;)V - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser$SuperClassElement 50 super org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$SuperClassElement org/spongepowered/asm/util/ClassSignature$SignatureParser SuperClassElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement org/spongepowered/asm/util/ClassSignature$SignatureParser TokenElement abstract
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 method public visitEnd ()V - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement 50 super,abstract org/spongepowered/asm/util/ClassSignature$SignatureParser$SignatureElement - -
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement org/spongepowered/asm/util/ClassSignature$SignatureParser TokenElement abstract
 inner org/spongepowered/asm/util/ClassSignature$IToken org/spongepowered/asm/util/ClassSignature IToken static,interface,abstract
 inner org/spongepowered/asm/util/ClassSignature$TokenHandle org/spongepowered/asm/util/ClassSignature TokenHandle -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$BoundElement org/spongepowered/asm/util/ClassSignature$SignatureParser BoundElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TypeArgElement org/spongepowered/asm/util/ClassSignature$SignatureParser TypeArgElement -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$SignatureElement org/spongepowered/asm/util/ClassSignature$SignatureParser SignatureElement abstract
 field protected token Lorg/spongepowered/asm/util/ClassSignature$Token; -
 method public getToken ()Lorg/spongepowered/asm/util/ClassSignature$Token; - -
 method protected setArray ()V - -
 method public visitClassType (Ljava/lang/String;)V - -
 method public visitClassBound ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitInterfaceBound ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitInnerClassType (Ljava/lang/String;)V - -
 method public visitArrayType ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitTypeArgument (C)Lorg/objectweb/asm/signature/SignatureVisitor; - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureParser$TypeArgElement 50 super org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser org/spongepowered/asm/util/ClassSignature SignatureParser -
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TokenElement org/spongepowered/asm/util/ClassSignature$SignatureParser TokenElement abstract
 inner org/spongepowered/asm/util/ClassSignature$SignatureParser$TypeArgElement org/spongepowered/asm/util/ClassSignature$SignatureParser TypeArgElement -
 inner org/spongepowered/asm/util/ClassSignature$TokenHandle org/spongepowered/asm/util/ClassSignature TokenHandle -
 inner org/spongepowered/asm/util/ClassSignature$IToken org/spongepowered/asm/util/ClassSignature IToken static,interface,abstract
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 method public visitArrayType ()Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitBaseType (C)V - -
 method public visitTypeVariable (Ljava/lang/String;)V - -
 method public visitClassType (Ljava/lang/String;)V - -
 method public visitTypeArgument ()V - -
 method public visitTypeArgument (C)Lorg/objectweb/asm/signature/SignatureVisitor; - -
 method public visitEnd ()V - -
in 22
class org/spongepowered/asm/util/ClassSignature$SignatureRemapper 50 super org/objectweb/asm/signature/SignatureWriter - -
 inner org/spongepowered/asm/util/ClassSignature$SignatureRemapper org/spongepowered/asm/util/ClassSignature SignatureRemapper -
 inner org/spongepowered/asm/util/ClassSignature$TypeVar org/spongepowered/asm/util/ClassSignature TypeVar static
 method public visitFormalTypeParameter (Ljava/lang/String;)V - -
 method public visitTypeVariable (Ljava/lang/String;)V - -
in 22
class org/spongepowered/asm/util/ClassSignature$Token 50 super java/lang/Object org/spongepowered/asm/util/ClassSignature$IToken -
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 inner org/spongepowered/asm/util/ClassSignature$IToken org/spongepowered/asm/util/ClassSignature IToken static,interface,abstract
 inner org/spongepowered/asm/util/ClassSignature$TokenHandle org/spongepowered/asm/util/ClassSignature TokenHandle -
 method public setArray (Z)Lorg/spongepowered/asm/util/ClassSignature$IToken; - -
 method public setWildcard (C)Lorg/spongepowered/asm/util/ClassSignature$IToken; - -
 method public toString ()Ljava/lang/String; - -
 method public asBound ()Ljava/lang/String; - -
 method public asType ()Ljava/lang/String; - -
 method public asType (Z)Ljava/lang/String; - -
 method public asToken ()Lorg/spongepowered/asm/util/ClassSignature$Token; - -
in 22
class org/spongepowered/asm/util/ClassSignature$TokenHandle 50 super java/lang/Object org/spongepowered/asm/util/ClassSignature$IToken -
 inner org/spongepowered/asm/util/ClassSignature$Token org/spongepowered/asm/util/ClassSignature Token static
 inner org/spongepowered/asm/util/ClassSignature$TokenHandle org/spongepowered/asm/util/ClassSignature TokenHandle -
 inner org/spongepowered/asm/util/ClassSignature$IToken org/spongepowered/asm/util/ClassSignature IToken static,interface,abstract
 method public setArray (Z)Lorg/spongepowered/asm/util/ClassSignature$IToken; - -
 method public setWildcard (C)Lorg/spongepowered/asm/util/ClassSignature$IToken; - -
 method public asBound ()Ljava/lang/String; - -
 method public asType ()Ljava/lang/String; - -
 method public asToken ()Lorg/spongepowered/asm/util/ClassSignature$Token; - -
 method public toString ()Ljava/lang/String; - -
 method public clone ()Lorg/spongepowered/asm/util/ClassSignature$TokenHandle; - -
in 22
class org/spongepowered/asm/util/ClassSignature$TypeVar 50 super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lorg/spongepowered/asm/util/ClassSignature$TypeVar;>;
 inner org/spongepowered/asm/util/ClassSignature$TypeVar org/spongepowered/asm/util/ClassSignature TypeVar static
 method public compareTo (Lorg/spongepowered/asm/util/ClassSignature$TypeVar;)I - -
 method public toString ()Ljava/lang/String; - -
 method public matches (Ljava/lang/String;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 1177
class org/spongepowered/asm/util/CompareUtil 50 public,final,super java/lang/Object - -
 method public,static compare (II)I - -
 method public,static compare (JJ)I - -
in 22
class org/spongepowered/asm/util/Constants 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/Constants$ManifestAttributes org/spongepowered/asm/util/Constants ManifestAttributes public,static,abstract
 field public,static,final CTOR Ljava/lang/String; - "<init>"
 field public,static,final CLINIT Ljava/lang/String; - "<clinit>"
 field public,static,final IMAGINARY_SUPER Ljava/lang/String; - "super$"
 field public,static,final DEBUG_OUTPUT_PATH Ljava/lang/String; - ".mixin.out"
 field public,static,final MIXIN_PACKAGE Ljava/lang/String; -
 field public,static,final MIXIN_PACKAGE_REF Ljava/lang/String; -
 field public,static,final STRING Ljava/lang/String; - "java/lang/String"
 field public,static,final OBJECT Ljava/lang/String; - "java/lang/Object"
 field public,static,final CLASS Ljava/lang/String; - "java/lang/Class"
 field public,static,final STRING_DESC Ljava/lang/String; - "Ljava/lang/String;"
 field public,static,final OBJECT_DESC Ljava/lang/String; - "Ljava/lang/Object;"
 field public,static,final CLASS_DESC Ljava/lang/String; - "Ljava/lang/Class;"
 field public,static,final SYNTHETIC_PACKAGE Ljava/lang/String; - "org.spongepowered.asm.synthetic"
 field public,static,final UNICODE_SNOWMAN C - I9731
 field public,static,final DEBUG_OUTPUT_DIR Ljava/io/File; -
 field public,static,final SIDE_DEDICATEDSERVER Ljava/lang/String; - "DEDICATEDSERVER"
 field public,static,final SIDE_SERVER Ljava/lang/String; - "SERVER"
 field public,static,final SIDE_CLIENT Ljava/lang/String; - "CLIENT"
 field public,static,final SIDE_UNKNOWN Ljava/lang/String; - "UNKNOWN"
in 22
class org/spongepowered/asm/util/Constants$ManifestAttributes 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/Constants$ManifestAttributes org/spongepowered/asm/util/Constants ManifestAttributes public,static,abstract
 field public,static,final TWEAKER Ljava/lang/String; - "TweakClass"
 field public,static,final MAINCLASS Ljava/lang/String; - "Main-Class"
 field public,static,final MIXINCONFIGS Ljava/lang/String; - "MixinConfigs"
 field public,static,final TOKENPROVIDERS Ljava/lang/String; - "MixinTokenProviders"
 field public,static,final MIXINCONNECTOR Ljava/lang/String; - "MixinConnector"
 field public,static,final,deprecated COMPATIBILITY Ljava/lang/String; - "MixinCompatibilityLevel"
in 22
class org/spongepowered/asm/util/ConstraintParser 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/util/ConstraintParser$Constraint org/spongepowered/asm/util/ConstraintParser Constraint public,static
 method public,static parse (Ljava/lang/String;)Lorg/spongepowered/asm/util/ConstraintParser$Constraint; - -
 method public,static parse (Lorg/objectweb/asm/tree/AnnotationNode;)Lorg/spongepowered/asm/util/ConstraintParser$Constraint; - -
in 22
class org/spongepowered/asm/util/ConstraintParser$Constraint 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/util/ConstraintParser$Constraint org/spongepowered/asm/util/ConstraintParser Constraint public,static
 field public,static,final NONE Lorg/spongepowered/asm/util/ConstraintParser$Constraint; -
 method public getToken ()Ljava/lang/String; - -
 method public getMin ()I - -
 method public getMax ()I - -
 method public check (Lorg/spongepowered/asm/util/ITokenProvider;)V - org/spongepowered/asm/util/throwables/ConstraintViolationException
 method public getRangeHumanReadable ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/Counter 50 public,final,super java/lang/Object - -
 field public value I -
 method public <init> ()V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/util/Files 50 public,final,super java/lang/Object - -
 method public,static toFile (Ljava/net/URL;)Ljava/io/File; - java/net/URISyntaxException
 method public,static toFile (Ljava/net/URI;)Ljava/io/File; - -
in 22
class org/spongepowered/asm/util/Handles 50 public,final,super java/lang/Object - -
 method public,static isField (Lorg/objectweb/asm/Handle;)Z - -
 method public,static opcodeFromTag (I)I - -
 method public,static tagFromOpcode (I)I - -
in 22
class org/spongepowered/asm/util/IConsumer 50 public,interface,abstract java/lang/Object - <TItem:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract accept (Ljava/lang/Object;)V (TTItem;)V -
in 22
class org/spongepowered/asm/util/IMessageSink 50 public,interface,abstract java/lang/Object - -
 method public,varargs,abstract addMessage (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 22
class org/spongepowered/asm/util/ITokenProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract getToken (Ljava/lang/String;)Ljava/lang/Integer; - -
in 22
class org/spongepowered/asm/util/JavaVersion 50 public,super,abstract java/lang/Object - -
 field public,static,final JAVA_6 D - D1.6
 field public,static,final JAVA_7 D - D1.7
 field public,static,final JAVA_8 D - D1.8
 field public,static,final JAVA_9 D - D9.0
 field public,static,final JAVA_10 D - D10.0
 field public,static,final JAVA_11 D - D11.0
 field public,static,final JAVA_12 D - D12.0
 field public,static,final JAVA_13 D - D13.0
 field public,static,final JAVA_14 D - D14.0
 field public,static,final JAVA_15 D - D15.0
 field public,static,final JAVA_16 D - D16.0
 field public,static,final JAVA_17 D - D17.0
 field public,static,final JAVA_18 D - D18.0
 method public,static current ()D - -
in 22
class org/spongepowered/asm/util/LanguageFeatures 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 field public,static,final METHODS_IN_INTERFACES I - I1
 field public,static,final PRIVATE_SYNTHETIC_METHODS_IN_INTERFACES I - I2
 field public,static,final PRIVATE_METHODS_IN_INTERFACES I - I4
 field public,static,final NESTING I - I8
 field public,static,final DYNAMIC_CONSTANTS I - I16
 field public,static,final RECORDS I - I32
 field public,static,final SEALED_CLASSES I - I64
 method public,static scan (Lorg/objectweb/asm/tree/ClassNode;)I - -
 method public,static,final format (I)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/Locals 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/util/Locals$Settings org/spongepowered/asm/util/Locals Settings public,static
 inner org/spongepowered/asm/util/Locals$ZombieLocalVariableNode org/spongepowered/asm/util/Locals ZombieLocalVariableNode static
 inner org/spongepowered/asm/util/Locals$SyntheticLocalVariableNode org/spongepowered/asm/util/Locals SyntheticLocalVariableNode public,static
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$FrameData org/spongepowered/asm/mixin/transformer/ClassInfo FrameData public,static
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$Method org/spongepowered/asm/mixin/transformer/ClassInfo Method public
 method public,static loadLocals ([Lorg/objectweb/asm/Type;Lorg/objectweb/asm/tree/InsnList;II)V - -
 method public,static getLocalsAt (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)[Lorg/objectweb/asm/tree/LocalVariableNode; - -
 method public,static getLocalsAt (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AbstractInsnNode;Lorg/spongepowered/asm/util/Locals$Settings;)[Lorg/objectweb/asm/tree/LocalVariableNode; - -
 method public,static getLocalVariableAt (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/AbstractInsnNode;I)Lorg/objectweb/asm/tree/LocalVariableNode; - -
 method public,static getLocalVariableTable (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/List<Lorg/objectweb/asm/tree/LocalVariableNode;>; -
 method public,static getGeneratedLocalVariableTable (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/List<Lorg/objectweb/asm/tree/LocalVariableNode;>; -
 method public,static generateLocalVariableTable (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Ljava/util/List<Lorg/objectweb/asm/tree/LocalVariableNode;>; -
 method public,static computeFrameSize (Lorg/objectweb/asm/tree/FrameNode;I)I - -
 method public,static getFrameTypeName (Ljava/lang/Object;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/Locals$Settings 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/util/Locals$Settings org/spongepowered/asm/util/Locals Settings public,static
 field public,static RESURRECT_FOR_BOGUS_TOP I -
 field public,static RESURRECT_EXPOSED_ON_LOAD I -
 field public,static RESURRECT_EXPOSED_ON_STORE I -
 field public,static DEFAULT_FLAGS I -
 field public,static DEFAULT Lorg/spongepowered/asm/util/Locals$Settings; -
 method public <init> (IIII)V - -
 method public <init> (IIIIII)V - -
in 22
class org/spongepowered/asm/util/Locals$SyntheticLocalVariableNode 50 public,super org/objectweb/asm/tree/LocalVariableNode - -
 inner org/spongepowered/asm/util/Locals$SyntheticLocalVariableNode org/spongepowered/asm/util/Locals SyntheticLocalVariableNode public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/objectweb/asm/tree/LabelNode;Lorg/objectweb/asm/tree/LabelNode;I)V - -
in 22
class org/spongepowered/asm/util/Locals$ZombieLocalVariableNode 50 super org/objectweb/asm/tree/LocalVariableNode - -
 inner org/spongepowered/asm/util/Locals$ZombieLocalVariableNode org/spongepowered/asm/util/Locals ZombieLocalVariableNode static
 inner org/spongepowered/asm/util/Locals$Settings org/spongepowered/asm/util/Locals Settings public,static
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/ObfuscationUtil 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper org/spongepowered/asm/util/ObfuscationUtil IClassRemapper public,static,interface,abstract
 method public,static mapDescriptor (Ljava/lang/String;Lorg/spongepowered/asm/util/ObfuscationUtil$IClassRemapper;)Ljava/lang/String; - -
 method public,static unmapDescriptor (Ljava/lang/String;Lorg/spongepowered/asm/util/ObfuscationUtil$IClassRemapper;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper org/spongepowered/asm/util/ObfuscationUtil IClassRemapper public,static,interface,abstract
 method public,abstract map (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract unmap (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/PrettyPrinter 50 public,super java/lang/Object - -
 inner org/spongepowered/asm/util/PrettyPrinter$Row org/spongepowered/asm/util/PrettyPrinter Row static
 inner org/spongepowered/asm/util/PrettyPrinter$Column org/spongepowered/asm/util/PrettyPrinter Column static
 inner org/spongepowered/asm/util/PrettyPrinter$Table org/spongepowered/asm/util/PrettyPrinter Table static
 inner org/spongepowered/asm/util/PrettyPrinter$Alignment org/spongepowered/asm/util/PrettyPrinter Alignment public,static,final,enum
 inner org/spongepowered/asm/util/PrettyPrinter$CentredText org/spongepowered/asm/util/PrettyPrinter CentredText -
 inner org/spongepowered/asm/util/PrettyPrinter$HorizontalRule org/spongepowered/asm/util/PrettyPrinter HorizontalRule -
 inner org/spongepowered/asm/util/PrettyPrinter$KeyValue org/spongepowered/asm/util/PrettyPrinter KeyValue -
 inner org/spongepowered/asm/util/PrettyPrinter$ISpecialEntry org/spongepowered/asm/util/PrettyPrinter ISpecialEntry static,interface,abstract
 inner org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry org/spongepowered/asm/util/PrettyPrinter IVariableWidthEntry static,interface,abstract
 inner org/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable org/spongepowered/asm/util/PrettyPrinter IPrettyPrintable public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field protected width I -
 field protected wrapWidth I -
 field protected kvKeyWidth I -
 field protected kvFormat Ljava/lang/String; -
 method public <init> ()V - -
 method public <init> (I)V - -
 method public wrapTo (I)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public wrapTo ()I - -
 method public table ()Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,varargs table ([Ljava/lang/String;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,varargs table ([Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public spacing (I)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public th ()Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,varargs tr ([Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add ()Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add (Ljava/lang/String;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,varargs add (Ljava/lang/String;[Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add ([Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add ([Ljava/lang/Object;Ljava/lang/String;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public addIndexed ([Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public addWithIndices (Ljava/util/Collection;)Lorg/spongepowered/asm/util/PrettyPrinter; (Ljava/util/Collection<*>;)Lorg/spongepowered/asm/util/PrettyPrinter; -
 method public add (Lorg/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add (Ljava/lang/Throwable;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add (Ljava/lang/Throwable;I)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add ([Ljava/lang/StackTraceElement;I)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add (Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add (Ljava/lang/Object;I)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,varargs addWrapped (Ljava/lang/String;[Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,varargs addWrapped (ILjava/lang/String;[Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,varargs kv (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public kv (Ljava/lang/String;Ljava/lang/Object;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public kvWidth (I)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public add (Ljava/util/Map;)Lorg/spongepowered/asm/util/PrettyPrinter; (Ljava/util/Map<**>;)Lorg/spongepowered/asm/util/PrettyPrinter; -
 method public hr ()Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public hr (C)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public centre ()Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace ()Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/lang/String;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/lang/String;Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Lorg/spongepowered/asm/logging/ILogger;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Lorg/spongepowered/asm/logging/ILogger;Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/io/PrintStream;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/io/PrintStream;Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/io/PrintStream;Ljava/lang/String;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/io/PrintStream;Ljava/lang/String;Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/io/PrintStream;Lorg/spongepowered/asm/logging/ILogger;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public trace (Ljava/io/PrintStream;Lorg/spongepowered/asm/logging/ILogger;Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public print ()Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public print (Ljava/io/PrintStream;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public log (Lorg/spongepowered/asm/logging/ILogger;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public log (Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public log (Lorg/spongepowered/asm/logging/ILogger;Lorg/spongepowered/asm/logging/Level;)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public,static dumpStack ()V - -
 method public,static print (Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$Alignment 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/util/PrettyPrinter$Alignment;>;
 inner org/spongepowered/asm/util/PrettyPrinter$Alignment org/spongepowered/asm/util/PrettyPrinter Alignment public,static,final,enum
 field public,static,final,enum LEFT Lorg/spongepowered/asm/util/PrettyPrinter$Alignment; -
 field public,static,final,enum RIGHT Lorg/spongepowered/asm/util/PrettyPrinter$Alignment; -
 method public,static values ()[Lorg/spongepowered/asm/util/PrettyPrinter$Alignment; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/util/PrettyPrinter$Alignment; - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$CentredText 50 super java/lang/Object - -
 inner org/spongepowered/asm/util/PrettyPrinter$CentredText org/spongepowered/asm/util/PrettyPrinter CentredText -
 method public <init> (Lorg/spongepowered/asm/util/PrettyPrinter;Ljava/lang/Object;)V - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$Column 50 super java/lang/Object - -
 inner org/spongepowered/asm/util/PrettyPrinter$Table org/spongepowered/asm/util/PrettyPrinter Table static
 inner org/spongepowered/asm/util/PrettyPrinter$Alignment org/spongepowered/asm/util/PrettyPrinter Alignment public,static,final,enum
 inner org/spongepowered/asm/util/PrettyPrinter$Column org/spongepowered/asm/util/PrettyPrinter Column static
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$HorizontalRule 50 super java/lang/Object org/spongepowered/asm/util/PrettyPrinter$ISpecialEntry -
 inner org/spongepowered/asm/util/PrettyPrinter$HorizontalRule org/spongepowered/asm/util/PrettyPrinter HorizontalRule -
 inner org/spongepowered/asm/util/PrettyPrinter$ISpecialEntry org/spongepowered/asm/util/PrettyPrinter ISpecialEntry static,interface,abstract
 method public,varargs <init> (Lorg/spongepowered/asm/util/PrettyPrinter;[C)V - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/PrettyPrinter$IPrettyPrintable org/spongepowered/asm/util/PrettyPrinter IPrettyPrintable public,static,interface,abstract
 method public,abstract print (Lorg/spongepowered/asm/util/PrettyPrinter;)V - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$ISpecialEntry 50 interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/PrettyPrinter$ISpecialEntry org/spongepowered/asm/util/PrettyPrinter ISpecialEntry static,interface,abstract
in 22
class org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry 50 interface,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry org/spongepowered/asm/util/PrettyPrinter IVariableWidthEntry static,interface,abstract
 method public,abstract getWidth ()I - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$KeyValue 50 super java/lang/Object org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry -
 inner org/spongepowered/asm/util/PrettyPrinter$KeyValue org/spongepowered/asm/util/PrettyPrinter KeyValue -
 inner org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry org/spongepowered/asm/util/PrettyPrinter IVariableWidthEntry static,interface,abstract
 method public <init> (Lorg/spongepowered/asm/util/PrettyPrinter;Ljava/lang/String;Ljava/lang/Object;)V - -
 method public toString ()Ljava/lang/String; - -
 method public getWidth ()I - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$Row 50 super java/lang/Object org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry -
 inner org/spongepowered/asm/util/PrettyPrinter$Table org/spongepowered/asm/util/PrettyPrinter Table static
 inner org/spongepowered/asm/util/PrettyPrinter$Row org/spongepowered/asm/util/PrettyPrinter Row static
 inner org/spongepowered/asm/util/PrettyPrinter$Column org/spongepowered/asm/util/PrettyPrinter Column static
 inner org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry org/spongepowered/asm/util/PrettyPrinter IVariableWidthEntry static,interface,abstract
 method public,varargs <init> (Lorg/spongepowered/asm/util/PrettyPrinter$Table;[Ljava/lang/Object;)V - -
 method public toString ()Ljava/lang/String; - -
 method public getWidth ()I - -
in 22
class org/spongepowered/asm/util/PrettyPrinter$Table 50 super java/lang/Object org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry -
 inner org/spongepowered/asm/util/PrettyPrinter$Column org/spongepowered/asm/util/PrettyPrinter Column static
 inner org/spongepowered/asm/util/PrettyPrinter$Row org/spongepowered/asm/util/PrettyPrinter Row static
 inner org/spongepowered/asm/util/PrettyPrinter$Table org/spongepowered/asm/util/PrettyPrinter Table static
 inner org/spongepowered/asm/util/PrettyPrinter$Alignment org/spongepowered/asm/util/PrettyPrinter Alignment public,static,final,enum
 inner org/spongepowered/asm/util/PrettyPrinter$IVariableWidthEntry org/spongepowered/asm/util/PrettyPrinter IVariableWidthEntry static,interface,abstract
 method public toString ()Ljava/lang/String; - -
 method public getWidth ()I - -
in 22
class org/spongepowered/asm/util/Quantifier 50 public,final,super java/lang/Object - -
 field public,static DEFAULT Lorg/spongepowered/asm/util/Quantifier; -
 field public,static NONE Lorg/spongepowered/asm/util/Quantifier; -
 field public,static SINGLE Lorg/spongepowered/asm/util/Quantifier; -
 field public,static ANY Lorg/spongepowered/asm/util/Quantifier; -
 field public,static PLUS Lorg/spongepowered/asm/util/Quantifier; -
 method public <init> (II)V - -
 method public isDefault ()Z - -
 method public getMin ()I - -
 method public getMax ()I - -
 method public getClampedMin ()I - -
 method public getClampedMax ()I - -
 method public toString ()Ljava/lang/String; - -
 method public,static parse (Ljava/lang/String;)Lorg/spongepowered/asm/util/Quantifier; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/asm/util/ReEntranceLock 50 public,super java/lang/Object - -
 method public <init> (I)V - -
 method public getMaxDepth ()I - -
 method public getDepth ()I - -
 method public push ()Lorg/spongepowered/asm/util/ReEntranceLock; - -
 method public pop ()Lorg/spongepowered/asm/util/ReEntranceLock; - -
 method public check ()Z - -
 method public checkAndSet ()Z - -
 method public set ()Lorg/spongepowered/asm/util/ReEntranceLock; - -
 method public isSet ()Z - -
 method public clear ()Lorg/spongepowered/asm/util/ReEntranceLock; - -
in 22
class org/spongepowered/asm/util/SignaturePrinter 50 public,super java/lang/Object - -
 method public <init> (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public <init> (Lorg/objectweb/asm/tree/MethodNode;[Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> ([Lorg/objectweb/asm/Type;)V - -
 method public <init> (Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;)V - -
 method public <init> (Ljava/lang/String;Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;)V - -
 method public <init> (Ljava/lang/String;Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/tree/LocalVariableNode;)V - -
 method public <init> (Ljava/lang/String;Lorg/objectweb/asm/Type;[Lorg/objectweb/asm/Type;[Ljava/lang/String;)V - -
 method public getFormattedArgs ()Ljava/lang/String; - -
 method public getReturnType ()Ljava/lang/String; - -
 method public setModifiers (Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public setModifiers (Ljava/lang/String;)Lorg/spongepowered/asm/util/SignaturePrinter; - -
 method public setFullyQualified (Z)Lorg/spongepowered/asm/util/SignaturePrinter; - -
 method public isFullyQualified ()Z - -
 method public toString ()Ljava/lang/String; - -
 method public toDescriptor ()Ljava/lang/String; - -
 method public,static getTypeName (Lorg/objectweb/asm/Type;)Ljava/lang/String; - -
 method public,static getTypeName (Lorg/objectweb/asm/Type;Z)Ljava/lang/String; - -
 method public,static getTypeName (Lorg/objectweb/asm/Type;ZZ)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/VersionNumber 50 public,final,super java/lang/Object java/lang/Comparable,java/io/Serializable Ljava/lang/Object;Ljava/lang/Comparable<Lorg/spongepowered/asm/util/VersionNumber;>;Ljava/io/Serializable;
 field public,static,final NONE Lorg/spongepowered/asm/util/VersionNumber; -
 method public getMajor ()S - -
 method public getMinor ()S - -
 method public getPatch ()S - -
 method public getRevision ()S - -
 method public getSuffix ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public compareTo (Lorg/spongepowered/asm/util/VersionNumber;)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static parse (Ljava/lang/String;)Lorg/spongepowered/asm/util/VersionNumber; - -
 method public,static parse (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/util/VersionNumber; - -
in 22
class org/spongepowered/asm/util/asm/ASM 50 public,final,super java/lang/Object - -
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 field public,static,final API_VERSION I -
 method public,static isAtLeastVersion (I)Z - -
 method public,static isAtLeastVersion (II)Z - -
 method public,static isAtLeastVersion (III)Z - -
 method public,static getApiVersionMajor ()I - -
 method public,static getApiVersionMinor ()I - -
 method public,static getApiVersionString ()Ljava/lang/String; - -
 method public,static getVersionString ()Ljava/lang/String; - -
 method public,static getMaxSupportedClassVersion ()I - -
 method public,static getMaxSupportedClassVersionMajor ()I - -
 method public,static getMaxSupportedClassVersionMinor ()I - -
 method public,static getClassVersionString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/asm/ClassNodeAdapter 50 public,final,super java/lang/Object - -
 method public,static getNestHostClass (Lorg/objectweb/asm/tree/ClassNode;)Ljava/lang/String; - -
 method public,static setNestHostClass (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/String;)V - -
 method public,static getNestMembers (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getNestMembersAsList (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static setNestMembers (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/List;)V (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/List<Ljava/lang/String;>;)V -
in 189
class org/spongepowered/asm/util/asm/ElementNode 52 public,super,abstract java/lang/Object - <TNode:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/spongepowered/asm/util/asm/ElementNode$ElementNodeField org/spongepowered/asm/util/asm/ElementNode ElementNodeField static
 inner org/spongepowered/asm/util/asm/ElementNode$ElementNodeMethod org/spongepowered/asm/util/asm/ElementNode ElementNodeMethod static
 method protected <init> (Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public isMethod ()Z - -
 method public isField ()Z - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getField ()Lorg/objectweb/asm/tree/FieldNode; - -
 method public getOwner ()Lorg/objectweb/asm/tree/ClassNode; - -
 method public getOwnerName ()Ljava/lang/String; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getDesc ()Ljava/lang/String; - -
 method public,abstract getSignature ()Ljava/lang/String; - -
 method public,abstract get ()Ljava/lang/Object; ()TTNode; -
 method public,static of (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/util/asm/ElementNode; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/MethodNode;)Lorg/spongepowered/asm/util/asm/ElementNode<Lorg/objectweb/asm/tree/MethodNode;>; -
 method public,static of (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/FieldNode;)Lorg/spongepowered/asm/util/asm/ElementNode; (Lorg/objectweb/asm/tree/ClassNode;Lorg/objectweb/asm/tree/FieldNode;)Lorg/spongepowered/asm/util/asm/ElementNode<Lorg/objectweb/asm/tree/FieldNode;>; -
 method public,static of (Lorg/objectweb/asm/tree/ClassNode;Ljava/lang/Object;)Lorg/spongepowered/asm/util/asm/ElementNode; <TNode:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/ClassNode;TTNode;)Lorg/spongepowered/asm/util/asm/ElementNode<TTNode;>; -
 method public,static listOf (Lorg/objectweb/asm/tree/ClassNode;Ljava/util/List;)Ljava/util/List; <TNode:Ljava/lang/Object;>(Lorg/objectweb/asm/tree/ClassNode;Ljava/util/List<TTNode;>;)Ljava/util/List<Lorg/spongepowered/asm/util/asm/ElementNode<TTNode;>;>; -
 method public,static fieldList (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Lorg/spongepowered/asm/util/asm/ElementNode<Lorg/objectweb/asm/tree/FieldNode;>;>; -
 method public,static methodList (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List; (Lorg/objectweb/asm/tree/ClassNode;)Ljava/util/List<Lorg/spongepowered/asm/util/asm/ElementNode<Lorg/objectweb/asm/tree/MethodNode;>;>; -
in 189
class org/spongepowered/asm/util/asm/ElementNode$ElementNodeField 52 super org/spongepowered/asm/util/asm/ElementNode - Lorg/spongepowered/asm/util/asm/ElementNode<Lorg/objectweb/asm/tree/FieldNode;>;
 inner org/spongepowered/asm/util/asm/ElementNode$ElementNodeField org/spongepowered/asm/util/asm/ElementNode ElementNodeField static
 method public isField ()Z - -
 method public getField ()Lorg/objectweb/asm/tree/FieldNode; - -
 method public getName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getSignature ()Ljava/lang/String; - -
 method public get ()Lorg/objectweb/asm/tree/FieldNode; - -
 method public toString ()Ljava/lang/String; - -
in 189
class org/spongepowered/asm/util/asm/ElementNode$ElementNodeMethod 52 super org/spongepowered/asm/util/asm/ElementNode - Lorg/spongepowered/asm/util/asm/ElementNode<Lorg/objectweb/asm/tree/MethodNode;>;
 inner org/spongepowered/asm/util/asm/ElementNode$ElementNodeMethod org/spongepowered/asm/util/asm/ElementNode ElementNodeMethod static
 method public isMethod ()Z - -
 method public getMethod ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public getName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public getSignature ()Ljava/lang/String; - -
 method public get ()Lorg/objectweb/asm/tree/MethodNode; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/asm/IAnnotatedElement 50 public,interface,abstract java/lang/Object - -
 method public,abstract getAnnotation (Ljava/lang/Class;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; -
in 22
class org/spongepowered/asm/util/asm/IAnnotationHandle 50 public,interface,abstract java/lang/Object - -
 method public,abstract exists ()Z - -
 method public,abstract getDesc ()Ljava/lang/String; - -
 method public,abstract getAnnotationList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lorg/spongepowered/asm/util/asm/IAnnotationHandle;>; -
 method public,abstract getTypeValue (Ljava/lang/String;)Lorg/objectweb/asm/Type; - -
 method public,abstract getTypeList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/Type;>; -
 method public,abstract getAnnotation (Ljava/lang/String;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public,abstract getValue (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public,abstract getValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public,abstract getValue (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,abstract getBoolean (Ljava/lang/String;Z)Z - -
 method public,abstract getList ()Ljava/util/List; <T:Ljava/lang/Object;>()Ljava/util/List<TT;>; -
 method public,abstract getList (Ljava/lang/String;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/lang/String;)Ljava/util/List<TT;>; -
in 1180
class org/spongepowered/asm/util/asm/MarkerNode 52 public,super org/objectweb/asm/tree/LabelNode - -
 field public,static,final INITIALISER_TAIL I - I1
 field public,static,final BODY_START I - I2
 field public,final type I -
 method public <init> (I)V - -
 method public accept (Lorg/objectweb/asm/MethodVisitor;)V - -
in 22
class org/spongepowered/asm/util/asm/MethodNodeEx 50 public,super org/objectweb/asm/tree/MethodNode - -
 method public <init> (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo;)V - -
 method public toString ()Ljava/lang/String; - -
 method public getQualifiedName ()Ljava/lang/String; - -
 method public getOriginalName ()Ljava/lang/String; - -
 method public getOwner ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
 method public,static getName (Lorg/objectweb/asm/tree/MethodNode;)Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/asm/MethodVisitorEx 50 public,super org/objectweb/asm/MethodVisitor - -
 method public <init> (Lorg/objectweb/asm/MethodVisitor;)V - -
 method public visitConstant (B)V - -
in 22
class org/spongepowered/asm/util/asm/MixinVerifier 50 public,super org/objectweb/asm/tree/analysis/SimpleVerifier - -
 inner org/spongepowered/asm/mixin/transformer/ClassInfo$TypeLookup org/spongepowered/asm/mixin/transformer/ClassInfo TypeLookup public,static,final,enum
 method public <init> (ILorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Ljava/util/List;Z)V (ILorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;Ljava/util/List<Lorg/objectweb/asm/Type;>;Z)V -
 method protected isInterface (Lorg/objectweb/asm/Type;)Z - -
 method protected getSuperClass (Lorg/objectweb/asm/Type;)Lorg/objectweb/asm/Type; - -
 method protected isAssignableFrom (Lorg/objectweb/asm/Type;Lorg/objectweb/asm/Type;)Z - -
in 22
class org/spongepowered/asm/util/logging/MessageRouter 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/util/logging/MessageRouter$DebugInterceptingMessager org/spongepowered/asm/util/logging/MessageRouter DebugInterceptingMessager static
 inner org/spongepowered/asm/util/logging/MessageRouter$LoggingMessager org/spongepowered/asm/util/logging/MessageRouter LoggingMessager static
 method public,static getMessager ()Ljavax/annotation/processing/Messager; - -
 method public,static setMessager (Ljavax/annotation/processing/Messager;)V - -
in 22
class org/spongepowered/asm/util/logging/MessageRouter$DebugInterceptingMessager 50 super java/lang/Object javax/annotation/processing/Messager -
 inner org/spongepowered/asm/util/logging/MessageRouter$DebugInterceptingMessager org/spongepowered/asm/util/logging/MessageRouter DebugInterceptingMessager static
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
in 22
class org/spongepowered/asm/util/logging/MessageRouter$LoggingMessager 50 super java/lang/Object javax/annotation/processing/Messager -
 inner org/spongepowered/asm/util/logging/MessageRouter$LoggingMessager org/spongepowered/asm/util/logging/MessageRouter LoggingMessager static
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
in 22
class org/spongepowered/asm/util/perf/Profiler 50 public,final,super java/lang/Object - -
 inner org/spongepowered/asm/util/perf/Profiler$ResultSection org/spongepowered/asm/util/perf/Profiler ResultSection static
 inner org/spongepowered/asm/util/perf/Profiler$SubSection org/spongepowered/asm/util/perf/Profiler SubSection -
 inner org/spongepowered/asm/util/perf/Profiler$LiveSection org/spongepowered/asm/util/perf/Profiler LiveSection -
 inner org/spongepowered/asm/util/perf/Profiler$DisabledSection org/spongepowered/asm/util/perf/Profiler DisabledSection -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner org/spongepowered/asm/util/PrettyPrinter$Alignment org/spongepowered/asm/util/PrettyPrinter Alignment public,static,final,enum
 field public,static,final ROOT I - I1
 field public,static,final FINE I - I2
 method public <init> (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public,static setActive (Z)V - -
 method public,synchronized reset ()V - -
 method public,synchronized get (Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public,varargs begin ([Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public,varargs begin (I[Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public begin (Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public,synchronized begin (ILjava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public,synchronized mark (Ljava/lang/String;)V - -
 method public,synchronized getSections ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/util/perf/Profiler$Section;>; -
 method public printer (ZZ)Lorg/spongepowered/asm/util/PrettyPrinter; - -
 method public printSummary ()V - -
 method public,static printAuditSummary ()V - -
 method public,static getProfiler (Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler; - -
 method public,static getProfilers ()Ljava/util/Collection; ()Ljava/util/Collection<Lorg/spongepowered/asm/util/perf/Profiler;>; -
in 22
class org/spongepowered/asm/util/perf/Profiler$DisabledSection 50 super org/spongepowered/asm/util/perf/Profiler$Section - -
 inner org/spongepowered/asm/util/perf/Profiler$DisabledSection org/spongepowered/asm/util/perf/Profiler DisabledSection -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 method public end ()Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public next (Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
in 22
class org/spongepowered/asm/util/perf/Profiler$LiveSection 50 super org/spongepowered/asm/util/perf/Profiler$DisabledSection - -
 inner org/spongepowered/asm/util/perf/Profiler$LiveSection org/spongepowered/asm/util/perf/Profiler LiveSection -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/util/perf/Profiler$DisabledSection org/spongepowered/asm/util/perf/Profiler DisabledSection -
 method protected getCursor ()I - -
 method protected stop ()Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public end ()Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public getTime ()J - -
 method public getTotalTime ()J - -
 method public getSeconds ()D - -
 method public getTotalSeconds ()D - -
 method public getTimes ()[J - -
 method public getCount ()I - -
 method public getTotalCount ()I - -
 method public getAverageTime ()D - -
 method public getTotalAverageTime ()D - -
 method protected getMarkedTime ()J - -
 method protected getMarkedCount ()I - -
in 22
class org/spongepowered/asm/util/perf/Profiler$ResultSection 50 super org/spongepowered/asm/util/perf/Profiler$Section - -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/util/perf/Profiler$ResultSection org/spongepowered/asm/util/perf/Profiler ResultSection static
 method public getTime ()J - -
 method public getTotalTime ()J - -
 method public getSeconds ()D - -
 method public getTotalSeconds ()D - -
 method public getTimes ()[J - -
 method public getCount ()I - -
 method public getTotalCount ()I - -
 method protected getMarkedTime ()J - -
 method protected getMarkedCount ()I - -
 method public getAverageTime ()D - -
 method public getTotalAverageTime ()D - -
in 22
class org/spongepowered/asm/util/perf/Profiler$Section 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 field protected invalidated Z -
 method protected getCursor ()I - -
 method public isRoot ()Z - -
 method public isFine ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public getBaseName ()Ljava/lang/String; - -
 method public setInfo (Ljava/lang/String;)V - -
 method public getInfo ()Ljava/lang/String; - -
 method protected stop ()Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public end ()Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public next (Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public getTime ()J - -
 method public getTotalTime ()J - -
 method public getSeconds ()D - -
 method public getTotalSeconds ()D - -
 method public getTimes ()[J - -
 method public getCount ()I - -
 method public getTotalCount ()I - -
 method public getAverageTime ()D - -
 method public getTotalAverageTime ()D - -
 method public,final toString ()Ljava/lang/String; - -
 method protected getMarkedTime ()J - -
 method protected getMarkedCount ()I - -
in 22
class org/spongepowered/asm/util/perf/Profiler$SubSection 50 super org/spongepowered/asm/util/perf/Profiler$LiveSection - -
 inner org/spongepowered/asm/util/perf/Profiler$Section org/spongepowered/asm/util/perf/Profiler Section public,static,abstract
 inner org/spongepowered/asm/util/perf/Profiler$SubSection org/spongepowered/asm/util/perf/Profiler SubSection -
 inner org/spongepowered/asm/util/perf/Profiler$LiveSection org/spongepowered/asm/util/perf/Profiler LiveSection -
 method public getBaseName ()Ljava/lang/String; - -
 method public setInfo (Ljava/lang/String;)V - -
 method public end ()Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
 method public next (Ljava/lang/String;)Lorg/spongepowered/asm/util/perf/Profiler$Section; - -
in 22
class org/spongepowered/asm/util/throwables/ConstraintViolationException 50 public,super java/lang/Exception - -
 inner org/spongepowered/asm/util/ConstraintParser$Constraint org/spongepowered/asm/util/ConstraintParser Constraint public,static
 method public <init> (Lorg/spongepowered/asm/util/ConstraintParser$Constraint;)V - -
 method public <init> (Lorg/spongepowered/asm/util/ConstraintParser$Constraint;I)V - -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/util/ConstraintParser$Constraint;)V - -
 method public <init> (Ljava/lang/String;Lorg/spongepowered/asm/util/ConstraintParser$Constraint;I)V - -
 method public <init> (Ljava/lang/Throwable;Lorg/spongepowered/asm/util/ConstraintParser$Constraint;)V - -
 method public <init> (Ljava/lang/Throwable;Lorg/spongepowered/asm/util/ConstraintParser$Constraint;I)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/util/ConstraintParser$Constraint;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;Lorg/spongepowered/asm/util/ConstraintParser$Constraint;I)V - -
 method public getConstraint ()Lorg/spongepowered/asm/util/ConstraintParser$Constraint; - -
 method public getBadValue ()Ljava/lang/String; - -
in 22
class org/spongepowered/asm/util/throwables/InvalidConstraintException 50 public,super java/lang/IllegalArgumentException - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/util/throwables/LVTGeneratorError 50 public,super org/spongepowered/asm/mixin/throwables/MixinError - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class org/spongepowered/asm/util/throwables/SyntheticBridgeException 50 public,super org/spongepowered/asm/mixin/throwables/MixinException - -
 inner org/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem org/spongepowered/asm/util/throwables/SyntheticBridgeException Problem public,static,final,enum
 method public <init> (Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem;Ljava/lang/String;Ljava/lang/String;ILorg/objectweb/asm/tree/AbstractInsnNode;Lorg/objectweb/asm/tree/AbstractInsnNode;)V - -
 method public printAnalysis (Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/objectweb/asm/tree/MethodNode;Lorg/objectweb/asm/tree/MethodNode;)V - -
in 22
class org/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem;>;
 inner org/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem org/spongepowered/asm/util/throwables/SyntheticBridgeException Problem public,static,final,enum
 field public,static,final,enum BAD_INSN Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; -
 field public,static,final,enum BAD_LOAD Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; -
 field public,static,final,enum BAD_CAST Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; -
 field public,static,final,enum BAD_INVOKE_NAME Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; -
 field public,static,final,enum BAD_INVOKE_DESC Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; -
 field public,static,final,enum BAD_LENGTH Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; -
 method public,static values ()[Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/asm/util/throwables/SyntheticBridgeException$Problem; - -
in 1181
class org/spongepowered/include/com/google/common/base/Absent 52 final,super org/spongepowered/include/com/google/common/base/Optional - <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/base/Optional<TT;>;
 method public or (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/base/Charsets 52 public,final,super java/lang/Object - -
 field public,static,final US_ASCII Ljava/nio/charset/Charset; -
 field public,static,final ISO_8859_1 Ljava/nio/charset/Charset; -
 field public,static,final UTF_8 Ljava/nio/charset/Charset; -
 field public,static,final UTF_16BE Ljava/nio/charset/Charset; -
 field public,static,final UTF_16LE Ljava/nio/charset/Charset; -
 field public,static,final UTF_16 Ljava/nio/charset/Charset; -
in 1181
class org/spongepowered/include/com/google/common/base/ExtraObjectsMethodsForWeb 52 super,abstract java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/common/base/Function 52 public,interface,abstract java/lang/Object java/util/function/Function <F:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TF;TT;>;
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TF;)TT; -
 method public,abstract equals (Ljava/lang/Object;)Z - -
in 1181
class org/spongepowered/include/com/google/common/base/Functions 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/base/Functions$ToStringFunction org/spongepowered/include/com/google/common/base/Functions ToStringFunction private,static,final,enum
 method public,static toStringFunction ()Lorg/spongepowered/include/com/google/common/base/Function; ()Lorg/spongepowered/include/com/google/common/base/Function<Ljava/lang/Object;Ljava/lang/String;>; -
in 1181
class org/spongepowered/include/com/google/common/base/Functions$ToStringFunction 52 final,super,enum java/lang/Enum org/spongepowered/include/com/google/common/base/Function Ljava/lang/Enum<Lorg/spongepowered/include/com/google/common/base/Functions$ToStringFunction;>;Lorg/spongepowered/include/com/google/common/base/Function<Ljava/lang/Object;Ljava/lang/String;>;
 inner org/spongepowered/include/com/google/common/base/Functions$ToStringFunction org/spongepowered/include/com/google/common/base/Functions ToStringFunction private,static,final,enum
 field public,static,final,enum INSTANCE Lorg/spongepowered/include/com/google/common/base/Functions$ToStringFunction; -
 method public,static values ()[Lorg/spongepowered/include/com/google/common/base/Functions$ToStringFunction; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/base/Functions$ToStringFunction; - -
 method public apply (Ljava/lang/Object;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/base/Joiner 52 public,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/base/Joiner$MapJoiner org/spongepowered/include/com/google/common/base/Joiner MapJoiner public,static,final
 method public,static on (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/base/Joiner; - -
 method public,static on (C)Lorg/spongepowered/include/com/google/common/base/Joiner; - -
 method public appendTo (Ljava/lang/Appendable;Ljava/util/Iterator;)Ljava/lang/Appendable; <A::Ljava/lang/Appendable;>(TA;Ljava/util/Iterator<*>;)TA; java/io/IOException
 method public,final appendTo (Ljava/lang/StringBuilder;Ljava/util/Iterator;)Ljava/lang/StringBuilder; (Ljava/lang/StringBuilder;Ljava/util/Iterator<*>;)Ljava/lang/StringBuilder; -
 method public,final join (Ljava/lang/Iterable;)Ljava/lang/String; (Ljava/lang/Iterable<*>;)Ljava/lang/String; -
 method public,final join (Ljava/util/Iterator;)Ljava/lang/String; (Ljava/util/Iterator<*>;)Ljava/lang/String; -
 method public,final join ([Ljava/lang/Object;)Ljava/lang/String; - -
 method public useForNull (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/base/Joiner; - -
 method public withKeyValueSeparator (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/base/Joiner$MapJoiner; - -
in 1181
class org/spongepowered/include/com/google/common/base/Joiner$MapJoiner 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/base/Joiner$MapJoiner org/spongepowered/include/com/google/common/base/Joiner MapJoiner public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public appendTo (Ljava/lang/StringBuilder;Ljava/util/Map;)Ljava/lang/StringBuilder; (Ljava/lang/StringBuilder;Ljava/util/Map<**>;)Ljava/lang/StringBuilder; -
 method public appendTo (Ljava/lang/Appendable;Ljava/util/Iterator;)Ljava/lang/Appendable; <A::Ljava/lang/Appendable;>(TA;Ljava/util/Iterator<+Ljava/util/Map$Entry<**>;>;)TA; java/io/IOException
 method public appendTo (Ljava/lang/StringBuilder;Ljava/lang/Iterable;)Ljava/lang/StringBuilder; (Ljava/lang/StringBuilder;Ljava/lang/Iterable<+Ljava/util/Map$Entry<**>;>;)Ljava/lang/StringBuilder; -
 method public appendTo (Ljava/lang/StringBuilder;Ljava/util/Iterator;)Ljava/lang/StringBuilder; (Ljava/lang/StringBuilder;Ljava/util/Iterator<+Ljava/util/Map$Entry<**>;>;)Ljava/lang/StringBuilder; -
in 1181
class org/spongepowered/include/com/google/common/base/Objects 52 public,final,super org/spongepowered/include/com/google/common/base/ExtraObjectsMethodsForWeb - -
 method public,static equal (Ljava/lang/Object;Ljava/lang/Object;)Z - -
 method public,static,varargs hashCode ([Ljava/lang/Object;)I - -
in 1181
class org/spongepowered/include/com/google/common/base/Optional 52 public,super,abstract java/lang/Object java/io/Serializable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;
 method public,static absent ()Lorg/spongepowered/include/com/google/common/base/Optional; <T:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/base/Optional<TT;>; -
 method public,abstract or (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
in 1181
class org/spongepowered/include/com/google/common/base/PatternCompiler 52 interface,abstract java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/common/base/Platform 52 final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/base/Platform$JdkPatternCompiler org/spongepowered/include/com/google/common/base/Platform JdkPatternCompiler private,static,final
in 1181
class org/spongepowered/include/com/google/common/base/Platform$JdkPatternCompiler 52 final,super java/lang/Object org/spongepowered/include/com/google/common/base/PatternCompiler -
 inner org/spongepowered/include/com/google/common/base/Platform$JdkPatternCompiler org/spongepowered/include/com/google/common/base/Platform JdkPatternCompiler private,static,final
in 1182
class org/spongepowered/include/com/google/common/base/Preconditions 52 public,final,super java/lang/Object - -
 method public,static checkArgument (Z)V - -
 method public,static checkArgument (ZLjava/lang/Object;)V - -
 method public,static checkArgument (ZLjava/lang/String;I)V - -
 method public,static checkArgument (ZLjava/lang/String;Ljava/lang/Object;)V - -
 method public,static checkState (ZLjava/lang/Object;)V - -
 method public,static checkNotNull (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;)TT; -
 method public,static checkNotNull (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/lang/Object;)TT; -
 method public,static checkElementIndex (II)I - -
 method public,static checkElementIndex (IILjava/lang/String;)I - -
 method public,static checkPositionIndex (II)I - -
 method public,static checkPositionIndex (IILjava/lang/String;)I - -
 method public,static checkPositionIndexes (III)V - -
in 525
class org/spongepowered/include/com/google/common/base/Preconditions 52 public,final,super java/lang/Object - -
 method public,static checkArgument (Z)V - -
 method public,static checkArgument (ZLjava/lang/Object;)V - -
 method public,static checkArgument (ZLjava/lang/String;I)V - -
 method public,static checkArgument (ZLjava/lang/String;Ljava/lang/Object;)V - -
 method public,static checkState (Z)V - -
 method public,static checkState (ZLjava/lang/Object;)V - -
 method public,static checkNotNull (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;)TT; -
 method public,static checkNotNull (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/lang/Object;)TT; -
 method public,static checkElementIndex (II)I - -
 method public,static checkElementIndex (IILjava/lang/String;)I - -
 method public,static checkPositionIndex (II)I - -
 method public,static checkPositionIndex (IILjava/lang/String;)I - -
 method public,static checkPositionIndexes (III)V - -
in 1181
class org/spongepowered/include/com/google/common/base/Predicate 52 public,interface,abstract java/lang/Object java/util/function/Predicate <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Predicate<TT;>;
 method public,abstract apply (Ljava/lang/Object;)Z (TT;)Z -
 method public test (Ljava/lang/Object;)Z (TT;)Z -
in 1181
class org/spongepowered/include/com/google/common/base/Predicates 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/base/Predicates$InPredicate org/spongepowered/include/com/google/common/base/Predicates InPredicate private,static
 inner org/spongepowered/include/com/google/common/base/Predicates$IsEqualToPredicate org/spongepowered/include/com/google/common/base/Predicates IsEqualToPredicate private,static
 inner org/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate org/spongepowered/include/com/google/common/base/Predicates ObjectPredicate static,abstract,enum
 method public,static isNull ()Lorg/spongepowered/include/com/google/common/base/Predicate; <T:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/base/Predicate<TT;>; -
 method public,static equalTo (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/base/Predicate; <T:Ljava/lang/Object;>(TT;)Lorg/spongepowered/include/com/google/common/base/Predicate<TT;>; -
 method public,static in (Ljava/util/Collection;)Lorg/spongepowered/include/com/google/common/base/Predicate; <T:Ljava/lang/Object;>(Ljava/util/Collection<+TT;>;)Lorg/spongepowered/include/com/google/common/base/Predicate<TT;>; -
in 1181
class org/spongepowered/include/com/google/common/base/Predicates$InPredicate 52 super java/lang/Object java/io/Serializable,org/spongepowered/include/com/google/common/base/Predicate <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;Lorg/spongepowered/include/com/google/common/base/Predicate<TT;>;
 inner org/spongepowered/include/com/google/common/base/Predicates$InPredicate org/spongepowered/include/com/google/common/base/Predicates InPredicate private,static
 method public apply (Ljava/lang/Object;)Z (TT;)Z -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/base/Predicates$IsEqualToPredicate 52 super java/lang/Object java/io/Serializable,org/spongepowered/include/com/google/common/base/Predicate <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;Lorg/spongepowered/include/com/google/common/base/Predicate<TT;>;
 inner org/spongepowered/include/com/google/common/base/Predicates$IsEqualToPredicate org/spongepowered/include/com/google/common/base/Predicates IsEqualToPredicate private,static
 method public apply (Ljava/lang/Object;)Z (TT;)Z -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate 52 super,abstract,enum java/lang/Enum org/spongepowered/include/com/google/common/base/Predicate Ljava/lang/Enum<Lorg/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate;>;Lorg/spongepowered/include/com/google/common/base/Predicate<Ljava/lang/Object;>;
 inner org/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate org/spongepowered/include/com/google/common/base/Predicates ObjectPredicate static,abstract,enum
 field public,static,final,enum ALWAYS_TRUE Lorg/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate; -
 field public,static,final,enum ALWAYS_FALSE Lorg/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate; -
 field public,static,final,enum IS_NULL Lorg/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate; -
 field public,static,final,enum NOT_NULL Lorg/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate; -
 method public,static values ()[Lorg/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/base/Predicates$ObjectPredicate; - -
in 1181
class org/spongepowered/include/com/google/common/base/Strings 52 public,final,super java/lang/Object - -
 method public,static nullToEmpty (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static emptyToNull (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static isNullOrEmpty (Ljava/lang/String;)Z - -
 method public,static padStart (Ljava/lang/String;IC)Ljava/lang/String; - -
 method public,static repeat (Ljava/lang/String;I)Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/base/Throwables 52 public,final,super java/lang/Object - -
 method public,static throwIfInstanceOf (Ljava/lang/Throwable;Ljava/lang/Class;)V <X:Ljava/lang/Throwable;>(Ljava/lang/Throwable;Ljava/lang/Class<TX;>;)V^TX; java/lang/Throwable
 method public,static,deprecated propagateIfInstanceOf (Ljava/lang/Throwable;Ljava/lang/Class;)V <X:Ljava/lang/Throwable;>(Ljava/lang/Throwable;Ljava/lang/Class<TX;>;)V^TX; java/lang/Throwable
 method public,static throwIfUnchecked (Ljava/lang/Throwable;)V - -
 method public,static,deprecated propagateIfPossible (Ljava/lang/Throwable;)V - -
 method public,static propagateIfPossible (Ljava/lang/Throwable;Ljava/lang/Class;)V <X:Ljava/lang/Throwable;>(Ljava/lang/Throwable;Ljava/lang/Class<TX;>;)V^TX; java/lang/Throwable
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractIndexedListIterator 52 super,abstract org/spongepowered/include/com/google/common/collect/UnmodifiableListIterator - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator<TE;>;
 method protected,abstract get (I)Ljava/lang/Object; (I)TE; -
 method protected <init> (II)V - -
 method public,final hasNext ()Z - -
 method public,final next ()Ljava/lang/Object; ()TE; -
 method public,final nextIndex ()I - -
 method public,final hasPrevious ()Z - -
 method public,final previous ()Ljava/lang/Object; ()TE; -
 method public,final previousIndex ()I - -
in 525
class org/spongepowered/include/com/google/common/collect/AbstractIterator 52 public,super,abstract org/spongepowered/include/com/google/common/collect/UnmodifiableIterator - <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>;
 inner org/spongepowered/include/com/google/common/collect/AbstractIterator$State org/spongepowered/include/com/google/common/collect/AbstractIterator State private,static,final,enum
 method protected <init> ()V - -
 method protected,abstract computeNext ()Ljava/lang/Object; ()TT; -
 method protected,final endOfData ()Ljava/lang/Object; ()TT; -
 method public,final hasNext ()Z - -
 method public,final next ()Ljava/lang/Object; ()TT; -
in 525
class org/spongepowered/include/com/google/common/collect/AbstractIterator$State 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/include/com/google/common/collect/AbstractIterator$State;>;
 inner org/spongepowered/include/com/google/common/collect/AbstractIterator$State org/spongepowered/include/com/google/common/collect/AbstractIterator State private,static,final,enum
 field public,static,final,enum READY Lorg/spongepowered/include/com/google/common/collect/AbstractIterator$State; -
 field public,static,final,enum NOT_READY Lorg/spongepowered/include/com/google/common/collect/AbstractIterator$State; -
 field public,static,final,enum DONE Lorg/spongepowered/include/com/google/common/collect/AbstractIterator$State; -
 field public,static,final,enum FAILED Lorg/spongepowered/include/com/google/common/collect/AbstractIterator$State; -
 method public,static values ()[Lorg/spongepowered/include/com/google/common/collect/AbstractIterator$State; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/collect/AbstractIterator$State; - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap 52 super,abstract org/spongepowered/include/com/google/common/collect/AbstractMultimap java/io/Serializable <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/AbstractMultimap<TK;TV;>;Ljava/io/Serializable;
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$NavigableAsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap NavigableAsMap -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedAsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap SortedAsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap AsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$NavigableKeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap NavigableKeySet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedKeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap SortedKeySet private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$KeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap KeySet private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$RandomAccessWrappedList org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap RandomAccessWrappedList private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedList private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedNavigableSet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedNavigableSet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSortedSet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedSortedSet private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedSet private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<TK;Ljava/util/Collection<TV;>;>;)V -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Z (TK;TV;)Z -
 method public removeAll (Ljava/lang/Object;)Ljava/util/Collection; (Ljava/lang/Object;)Ljava/util/Collection<TV;>; -
 method public clear ()V - -
 method public get (Ljava/lang/Object;)Ljava/util/Collection; (TK;)Ljava/util/Collection<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap 52 super org/spongepowered/include/com/google/common/collect/Maps$ViewCachingAbstractMap - Lorg/spongepowered/include/com/google/common/collect/Maps$ViewCachingAbstractMap<TK;Ljava/util/Collection<TV;>;>;
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap AsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap$AsMapIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap AsMapIterator -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap$AsMapEntries org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap AsMapEntries -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$ViewCachingAbstractMap org/spongepowered/include/com/google/common/collect/Maps ViewCachingAbstractMap static,abstract
 method protected createEntrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>;>; -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public get (Ljava/lang/Object;)Ljava/util/Collection; (Ljava/lang/Object;)Ljava/util/Collection<TV;>; -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public size ()I - -
 method public remove (Ljava/lang/Object;)Ljava/util/Collection; (Ljava/lang/Object;)Ljava/util/Collection<TV;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public clear ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap$AsMapEntries 52 super org/spongepowered/include/com/google/common/collect/Maps$EntrySet - Lorg/spongepowered/include/com/google/common/collect/Maps$EntrySet<TK;Ljava/util/Collection<TV;>;>;
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap AsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap$AsMapEntries org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap AsMapEntries -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$EntrySet org/spongepowered/include/com/google/common/collect/Maps EntrySet static,abstract
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap$AsMapIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap AsMapIterator -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>;>; -
 method public contains (Ljava/lang/Object;)Z - -
 method public remove (Ljava/lang/Object;)Z - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap$AsMapIterator 52 super java/lang/Object java/util/Iterator Ljava/lang/Object;Ljava/util/Iterator<Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap AsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap$AsMapIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap AsMapIterator -
 method public hasNext ()Z - -
 method public next ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public remove ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$KeySet 52 super org/spongepowered/include/com/google/common/collect/Maps$KeySet - Lorg/spongepowered/include/com/google/common/collect/Maps$KeySet<TK;Ljava/util/Collection<TV;>;>;
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$KeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap KeySet private
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$KeySet org/spongepowered/include/com/google/common/collect/Maps KeySet static
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TK;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TK;>; -
 method public remove (Ljava/lang/Object;)Z - -
 method public clear ()V - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$NavigableAsMap 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedAsMap java/util/NavigableMap -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$NavigableAsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap NavigableAsMap -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedAsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap SortedAsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$NavigableKeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap NavigableKeySet -
 method public lowerEntry (Ljava/lang/Object;)Ljava/util/Map$Entry; (TK;)Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public lowerKey (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public floorEntry (Ljava/lang/Object;)Ljava/util/Map$Entry; (TK;)Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public floorKey (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public ceilingEntry (Ljava/lang/Object;)Ljava/util/Map$Entry; (TK;)Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public ceilingKey (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public higherEntry (Ljava/lang/Object;)Ljava/util/Map$Entry; (TK;)Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public higherKey (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public firstEntry ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public lastEntry ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public pollFirstEntry ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public pollLastEntry ()Ljava/util/Map$Entry; ()Ljava/util/Map$Entry<TK;Ljava/util/Collection<TV;>;>; -
 method public descendingMap ()Ljava/util/NavigableMap; ()Ljava/util/NavigableMap<TK;Ljava/util/Collection<TV;>;>; -
 method public keySet ()Ljava/util/NavigableSet; ()Ljava/util/NavigableSet<TK;>; -
 method public navigableKeySet ()Ljava/util/NavigableSet; ()Ljava/util/NavigableSet<TK;>; -
 method public descendingKeySet ()Ljava/util/NavigableSet; ()Ljava/util/NavigableSet<TK;>; -
 method public subMap (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/NavigableMap; (TK;TK;)Ljava/util/NavigableMap<TK;Ljava/util/Collection<TV;>;>; -
 method public subMap (Ljava/lang/Object;ZLjava/lang/Object;Z)Ljava/util/NavigableMap; (TK;ZTK;Z)Ljava/util/NavigableMap<TK;Ljava/util/Collection<TV;>;>; -
 method public headMap (Ljava/lang/Object;)Ljava/util/NavigableMap; (TK;)Ljava/util/NavigableMap<TK;Ljava/util/Collection<TV;>;>; -
 method public headMap (Ljava/lang/Object;Z)Ljava/util/NavigableMap; (TK;Z)Ljava/util/NavigableMap<TK;Ljava/util/Collection<TV;>;>; -
 method public tailMap (Ljava/lang/Object;)Ljava/util/NavigableMap; (TK;)Ljava/util/NavigableMap<TK;Ljava/util/Collection<TV;>;>; -
 method public tailMap (Ljava/lang/Object;Z)Ljava/util/NavigableMap; (TK;Z)Ljava/util/NavigableMap<TK;Ljava/util/Collection<TV;>;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$NavigableKeySet 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedKeySet java/util/NavigableSet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$NavigableKeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap NavigableKeySet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedKeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap SortedKeySet private
 method public lower (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public floor (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public ceiling (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public higher (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
 method public pollFirst ()Ljava/lang/Object; ()TK; -
 method public pollLast ()Ljava/lang/Object; ()TK; -
 method public descendingSet ()Ljava/util/NavigableSet; ()Ljava/util/NavigableSet<TK;>; -
 method public descendingIterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TK;>; -
 method public headSet (Ljava/lang/Object;)Ljava/util/NavigableSet; (TK;)Ljava/util/NavigableSet<TK;>; -
 method public headSet (Ljava/lang/Object;Z)Ljava/util/NavigableSet; (TK;Z)Ljava/util/NavigableSet<TK;>; -
 method public subSet (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/NavigableSet; (TK;TK;)Ljava/util/NavigableSet<TK;>; -
 method public subSet (Ljava/lang/Object;ZLjava/lang/Object;Z)Ljava/util/NavigableSet; (TK;ZTK;Z)Ljava/util/NavigableSet<TK;>; -
 method public tailSet (Ljava/lang/Object;)Ljava/util/NavigableSet; (TK;)Ljava/util/NavigableSet<TK;>; -
 method public tailSet (Ljava/lang/Object;Z)Ljava/util/NavigableSet; (TK;Z)Ljava/util/NavigableSet<TK;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$RandomAccessWrappedList 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList java/util/RandomAccess -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$RandomAccessWrappedList org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap RandomAccessWrappedList private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedList private
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedAsMap 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap java/util/SortedMap -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedAsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap SortedAsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$AsMap org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap AsMap private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedKeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap SortedKeySet private
 method public comparator ()Ljava/util/Comparator; ()Ljava/util/Comparator<-TK;>; -
 method public firstKey ()Ljava/lang/Object; ()TK; -
 method public lastKey ()Ljava/lang/Object; ()TK; -
 method public headMap (Ljava/lang/Object;)Ljava/util/SortedMap; (TK;)Ljava/util/SortedMap<TK;Ljava/util/Collection<TV;>;>; -
 method public subMap (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/SortedMap; (TK;TK;)Ljava/util/SortedMap<TK;Ljava/util/Collection<TV;>;>; -
 method public tailMap (Ljava/lang/Object;)Ljava/util/SortedMap; (TK;)Ljava/util/SortedMap<TK;Ljava/util/Collection<TV;>;>; -
 method public keySet ()Ljava/util/SortedSet; ()Ljava/util/SortedSet<TK;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedKeySet 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$KeySet java/util/SortedSet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$SortedKeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap SortedKeySet private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$KeySet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap KeySet private
 method public comparator ()Ljava/util/Comparator; ()Ljava/util/Comparator<-TK;>; -
 method public first ()Ljava/lang/Object; ()TK; -
 method public headSet (Ljava/lang/Object;)Ljava/util/SortedSet; (TK;)Ljava/util/SortedSet<TK;>; -
 method public last ()Ljava/lang/Object; ()TK; -
 method public subSet (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/SortedSet; (TK;TK;)Ljava/util/SortedSet<TK;>; -
 method public tailSet (Ljava/lang/Object;)Ljava/util/SortedSet; (TK;)Ljava/util/SortedSet<TK;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection 52 super java/util/AbstractCollection - Ljava/util/AbstractCollection<TV;>;
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection$WrappedIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection WrappedIterator -
 method public size ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TV;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TV;>; -
 method public add (Ljava/lang/Object;)Z (TV;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TV;>;)Z -
 method public contains (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public remove (Ljava/lang/Object;)Z - -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection$WrappedIterator 52 super java/lang/Object java/util/Iterator Ljava/lang/Object;Ljava/util/Iterator<TV;>;
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection$WrappedIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection WrappedIterator -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TV; -
 method public remove ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection java/util/List -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedList private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList$WrappedListIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList WrappedListIterator private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 method public addAll (ILjava/util/Collection;)Z (ILjava/util/Collection<+TV;>;)Z -
 method public get (I)Ljava/lang/Object; (I)TV; -
 method public set (ILjava/lang/Object;)Ljava/lang/Object; (ITV;)TV; -
 method public add (ILjava/lang/Object;)V (ITV;)V -
 method public remove (I)Ljava/lang/Object; (I)TV; -
 method public indexOf (Ljava/lang/Object;)I - -
 method public lastIndexOf (Ljava/lang/Object;)I - -
 method public listIterator ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<TV;>; -
 method public listIterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<TV;>; -
 method public subList (II)Ljava/util/List; (II)Ljava/util/List<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList$WrappedListIterator 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection$WrappedIterator java/util/ListIterator -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedList private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList$WrappedListIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList WrappedListIterator private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection$WrappedIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection WrappedIterator -
 method public <init> (Lorg/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedList;I)V - -
 method public hasPrevious ()Z - -
 method public previous ()Ljava/lang/Object; ()TV; -
 method public nextIndex ()I - -
 method public previousIndex ()I - -
 method public set (Ljava/lang/Object;)V (TV;)V -
 method public add (Ljava/lang/Object;)V (TV;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedNavigableSet 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSortedSet java/util/NavigableSet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedNavigableSet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedNavigableSet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSortedSet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedSortedSet private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection$WrappedIterator org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection WrappedIterator -
 method public lower (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
 method public floor (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
 method public ceiling (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
 method public higher (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
 method public pollFirst ()Ljava/lang/Object; ()TV; -
 method public pollLast ()Ljava/lang/Object; ()TV; -
 method public descendingSet ()Ljava/util/NavigableSet; ()Ljava/util/NavigableSet<TV;>; -
 method public descendingIterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TV;>; -
 method public subSet (Ljava/lang/Object;ZLjava/lang/Object;Z)Ljava/util/NavigableSet; (TV;ZTV;Z)Ljava/util/NavigableSet<TV;>; -
 method public headSet (Ljava/lang/Object;Z)Ljava/util/NavigableSet; (TV;Z)Ljava/util/NavigableSet<TV;>; -
 method public tailSet (Ljava/lang/Object;Z)Ljava/util/NavigableSet; (TV;Z)Ljava/util/NavigableSet<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSet 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection java/util/Set -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedSet private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSortedSet 52 super org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection java/util/SortedSet -
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedCollection org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedCollection private
 inner org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap$WrappedSortedSet org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap WrappedSortedSet private
 method public comparator ()Ljava/util/Comparator; ()Ljava/util/Comparator<-TV;>; -
 method public first ()Ljava/lang/Object; ()TV; -
 method public last ()Ljava/lang/Object; ()TV; -
 method public headSet (Ljava/lang/Object;)Ljava/util/SortedSet; (TV;)Ljava/util/SortedSet<TV;>; -
 method public subSet (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/SortedSet; (TV;TV;)Ljava/util/SortedSet<TV;>; -
 method public tailSet (Ljava/lang/Object;)Ljava/util/SortedSet; (TV;)Ljava/util/SortedSet<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMapEntry 52 super,abstract java/lang/Object java/util/Map$Entry <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Map$Entry<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract getKey ()Ljava/lang/Object; ()TK; -
 method public,abstract getValue ()Ljava/lang/Object; ()TV; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractMultimap 52 super,abstract java/lang/Object org/spongepowered/include/com/google/common/collect/Multimap <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Lorg/spongepowered/include/com/google/common/collect/Multimap<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$KeySet org/spongepowered/include/com/google/common/collect/Maps KeySet static
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Z (TK;TV;)Z -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public asMap ()Ljava/util/Map; ()Ljava/util/Map<TK;Ljava/util/Collection<TV;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/AbstractSetMultimap 52 super,abstract org/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap org/spongepowered/include/com/google/common/collect/SetMultimap <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/AbstractMapBasedMultimap<TK;TV;>;Lorg/spongepowered/include/com/google/common/collect/SetMultimap<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<TK;Ljava/util/Collection<TV;>;>;)V -
 method public get (Ljava/lang/Object;)Ljava/util/Set; (TK;)Ljava/util/Set<TV;>; -
 method public removeAll (Ljava/lang/Object;)Ljava/util/Set; (Ljava/lang/Object;)Ljava/util/Set<TV;>; -
 method public asMap ()Ljava/util/Map; ()Ljava/util/Map<TK;Ljava/util/Collection<TV;>;>; -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Z (TK;TV;)Z -
 method public equals (Ljava/lang/Object;)Z - -
in 1181
class org/spongepowered/include/com/google/common/collect/BiMap 52 public,interface,abstract java/lang/Object java/util/Map <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Map<TK;TV;>;
 method public,abstract put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public,abstract forcePut (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public,abstract values ()Ljava/util/Set; ()Ljava/util/Set<TV;>; -
 method public,abstract inverse ()Lorg/spongepowered/include/com/google/common/collect/BiMap; ()Lorg/spongepowered/include/com/google/common/collect/BiMap<TV;TK;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ByFunctionOrdering 52 final,super org/spongepowered/include/com/google/common/collect/Ordering java/io/Serializable <F:Ljava/lang/Object;T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/Ordering<TF;>;Ljava/io/Serializable;
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)I (TF;TF;)I -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/CollectPreconditions 52 final,super java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/common/collect/CollectSpliterators 52 final,super java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/common/collect/Collections2 52 public,final,super java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/common/collect/ComparatorOrdering 52 final,super org/spongepowered/include/com/google/common/collect/Ordering java/io/Serializable <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/Ordering<TT;>;Ljava/io/Serializable;
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/DescendingImmutableSortedSet 52 super org/spongepowered/include/com/google/common/collect/ImmutableSortedSet - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>;
 method public contains (Ljava/lang/Object;)Z - -
 method public size ()I - -
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public descendingSet ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public descendingIterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public lower (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public floor (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public ceiling (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public higher (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
in 1181
class org/spongepowered/include/com/google/common/collect/FluentIterable 52 public,super,abstract java/lang/Object java/lang/Iterable <E:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<TE;>;
 method protected <init> ()V - -
 method public,static concat (Ljava/lang/Iterable;Ljava/lang/Iterable;)Lorg/spongepowered/include/com/google/common/collect/FluentIterable; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<+TT;>;Ljava/lang/Iterable<+TT;>;)Lorg/spongepowered/include/com/google/common/collect/FluentIterable<TT;>; -
 method public,static concat (Ljava/lang/Iterable;)Lorg/spongepowered/include/com/google/common/collect/FluentIterable; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<+Ljava/lang/Iterable<+TT;>;>;)Lorg/spongepowered/include/com/google/common/collect/FluentIterable<TT;>; -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/ForwardingCollection 52 public,super,abstract org/spongepowered/include/com/google/common/collect/ForwardingObject java/util/Collection <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ForwardingObject;Ljava/util/Collection<TE;>;
 method protected <init> ()V - -
 method protected,abstract delegate ()Ljava/util/Collection; ()Ljava/util/Collection<TE;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TE;>; -
 method public size ()I - -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public add (Ljava/lang/Object;)Z (TE;)Z -
 method public remove (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TE;>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public toArray ()[Ljava/lang/Object; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
in 1181
class org/spongepowered/include/com/google/common/collect/ForwardingObject 52 public,super,abstract java/lang/Object - -
 method protected <init> ()V - -
 method protected,abstract delegate ()Ljava/lang/Object; - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/ForwardingSet 52 public,super,abstract org/spongepowered/include/com/google/common/collect/ForwardingCollection java/util/Set <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ForwardingCollection<TE;>;Ljava/util/Set<TE;>;
 method protected <init> ()V - -
 method protected,abstract delegate ()Ljava/util/Set; ()Ljava/util/Set<TE;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/ForwardingSortedSet 52 public,super,abstract org/spongepowered/include/com/google/common/collect/ForwardingSet java/util/SortedSet <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ForwardingSet<TE;>;Ljava/util/SortedSet<TE;>;
 method protected <init> ()V - -
 method protected,abstract delegate ()Ljava/util/SortedSet; ()Ljava/util/SortedSet<TE;>; -
 method public comparator ()Ljava/util/Comparator; ()Ljava/util/Comparator<-TE;>; -
 method public first ()Ljava/lang/Object; ()TE; -
 method public headSet (Ljava/lang/Object;)Ljava/util/SortedSet; (TE;)Ljava/util/SortedSet<TE;>; -
 method public last ()Ljava/lang/Object; ()TE; -
 method public subSet (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/SortedSet; (TE;TE;)Ljava/util/SortedSet<TE;>; -
 method public tailSet (Ljava/lang/Object;)Ljava/util/SortedSet; (TE;)Ljava/util/SortedSet<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap 52 public,final,super org/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap java/io/Serializable,org/spongepowered/include/com/google/common/collect/BiMap <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap<TK;TV;>;Ljava/io/Serializable;Lorg/spongepowered/include/com/google/common/collect/BiMap<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse org/spongepowered/include/com/google/common/collect/HashBiMap Inverse private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$KeySet org/spongepowered/include/com/google/common/collect/HashBiMap KeySet private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Itr org/spongepowered/include/com/google/common/collect/HashBiMap Itr abstract
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap org/spongepowered/include/com/google/common/collect/Maps IteratorBasedAbstractMap static,abstract
 method public,static create ()Lorg/spongepowered/include/com/google/common/collect/HashBiMap; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/HashBiMap<TK;TV;>; -
 method public,static create (I)Lorg/spongepowered/include/com/google/common/collect/HashBiMap; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(I)Lorg/spongepowered/include/com/google/common/collect/HashBiMap<TK;TV;>; -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public forcePut (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public clear ()V - -
 method public size ()I - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public values ()Ljava/util/Set; ()Ljava/util/Set<TV;>; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<-TK;-TV;>;)V -
 method public replaceAll (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<-TK;-TV;+TV;>;)V -
 method public inverse ()Lorg/spongepowered/include/com/google/common/collect/BiMap; ()Lorg/spongepowered/include/com/google/common/collect/BiMap<TV;TK;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap$1$MapEntry 52 super org/spongepowered/include/com/google/common/collect/AbstractMapEntry - Lorg/spongepowered/include/com/google/common/collect/AbstractMapEntry<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$1$MapEntry org/spongepowered/include/com/google/common/collect/HashBiMap$1 MapEntry -
 method public getKey ()Ljava/lang/Object; ()TK; -
 method public getValue ()Ljava/lang/Object; ()TV; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableEntry - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableEntry<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse 52 final,super org/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap java/io/Serializable,org/spongepowered/include/com/google/common/collect/BiMap Lorg/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap<TV;TK;>;Ljava/io/Serializable;Lorg/spongepowered/include/com/google/common/collect/BiMap<TV;TK;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse org/spongepowered/include/com/google/common/collect/HashBiMap Inverse private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse$InverseKeySet org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse InverseKeySet private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap org/spongepowered/include/com/google/common/collect/Maps IteratorBasedAbstractMap static,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public size ()I - -
 method public clear ()V - -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TK; -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TV;TK;)TK; -
 method public forcePut (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TV;TK;)TK; -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TK; -
 method public inverse ()Lorg/spongepowered/include/com/google/common/collect/BiMap; ()Lorg/spongepowered/include/com/google/common/collect/BiMap<TK;TV;>; -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TV;>; -
 method public values ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<-TV;-TK;>;)V -
 method public replaceAll (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<-TV;-TK;+TK;>;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse$1$InverseEntry 52 super org/spongepowered/include/com/google/common/collect/AbstractMapEntry - Lorg/spongepowered/include/com/google/common/collect/AbstractMapEntry<TV;TK;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse org/spongepowered/include/com/google/common/collect/HashBiMap Inverse private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse$1$InverseEntry org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse$1 InverseEntry -
 method public getKey ()Ljava/lang/Object; ()TV; -
 method public getValue ()Ljava/lang/Object; ()TK; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; (TK;)TK; -
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse$InverseKeySet 52 final,super org/spongepowered/include/com/google/common/collect/Maps$KeySet - Lorg/spongepowered/include/com/google/common/collect/Maps$KeySet<TV;TK;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse org/spongepowered/include/com/google/common/collect/HashBiMap Inverse private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse$InverseKeySet org/spongepowered/include/com/google/common/collect/HashBiMap$Inverse InverseKeySet private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
 inner org/spongepowered/include/com/google/common/collect/Maps$KeySet org/spongepowered/include/com/google/common/collect/Maps KeySet static
 method public remove (Ljava/lang/Object;)Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap$Itr 52 super,abstract java/lang/Object java/util/Iterator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TT;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$Itr org/spongepowered/include/com/google/common/collect/HashBiMap Itr abstract
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TT; -
 method public remove ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/HashBiMap$KeySet 52 final,super org/spongepowered/include/com/google/common/collect/Maps$KeySet - Lorg/spongepowered/include/com/google/common/collect/Maps$KeySet<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$KeySet org/spongepowered/include/com/google/common/collect/HashBiMap KeySet private,final
 inner org/spongepowered/include/com/google/common/collect/HashBiMap$BiEntry org/spongepowered/include/com/google/common/collect/HashBiMap BiEntry private,static,final
 inner org/spongepowered/include/com/google/common/collect/Maps$KeySet org/spongepowered/include/com/google/common/collect/Maps KeySet static
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TK;>; -
 method public remove (Ljava/lang/Object;)Z - -
in 1181
class org/spongepowered/include/com/google/common/collect/HashMultimap 52 public,final,super org/spongepowered/include/com/google/common/collect/AbstractSetMultimap - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/AbstractSetMultimap<TK;TV;>;
 method public,static create ()Lorg/spongepowered/include/com/google/common/collect/HashMultimap; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/HashMultimap<TK;TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Hashing 52 final,super java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableAsList 52 super,abstract org/spongepowered/include/com/google/common/collect/ImmutableList - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>;
 method public contains (Ljava/lang/Object;)Z - -
 method public size ()I - -
 method public isEmpty ()Z - -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableBiMap 52 public,super,abstract org/spongepowered/include/com/google/common/collect/ImmutableBiMapFauxverideShim org/spongepowered/include/com/google/common/collect/BiMap <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMapFauxverideShim<TK;TV;>;Lorg/spongepowered/include/com/google/common/collect/BiMap<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static of ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TK;TV;>; -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(TK;TV;)Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TK;TV;>; -
 method public,abstract inverse ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TV;TK;>; -
 method public values ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TV;>; -
 method public,deprecated forcePut (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableBiMapFauxverideShim 52 super,abstract org/spongepowered/include/com/google/common/collect/ImmutableMap - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableMap<TK;TV;>;
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableCollection 52 public,super,abstract java/util/AbstractCollection java/io/Serializable <E:Ljava/lang/Object;>Ljava/util/AbstractCollection<TE;>;Ljava/io/Serializable;
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder org/spongepowered/include/com/google/common/collect/ImmutableCollection ArrayBasedBuilder static,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder org/spongepowered/include/com/google/common/collect/ImmutableCollection Builder public,static,abstract
 method public,abstract iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
 method public,final toArray ()[Ljava/lang/Object; - -
 method public,final toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public,abstract contains (Ljava/lang/Object;)Z - -
 method public,final,deprecated add (Ljava/lang/Object;)Z (TE;)Z -
 method public,final,deprecated remove (Ljava/lang/Object;)Z - -
 method public,final,deprecated addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TE;>;)Z -
 method public,final,deprecated removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public,final,deprecated removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TE;>;)Z -
 method public,final,deprecated retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public,final,deprecated clear ()V - -
 method public asList ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder 52 super,abstract org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder<TE;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder org/spongepowered/include/com/google/common/collect/ImmutableCollection ArrayBasedBuilder static,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder org/spongepowered/include/com/google/common/collect/ImmutableCollection Builder public,static,abstract
 method public add (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder; (TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder<TE;>; -
 method public,varargs add ([Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder; ([TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder<TE;>; -
 method public addAll (Ljava/lang/Iterable;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder; (Ljava/lang/Iterable<+TE;>;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder 52 public,super,abstract java/lang/Object - <E:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder org/spongepowered/include/com/google/common/collect/ImmutableCollection Builder public,static,abstract
 method public,abstract add (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder; (TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder<TE;>; -
 method public,varargs add ([Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder; ([TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder<TE;>; -
 method public addAll (Ljava/lang/Iterable;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder; (Ljava/lang/Iterable<+TE;>;)Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableEntry 52 super org/spongepowered/include/com/google/common/collect/AbstractMapEntry java/io/Serializable <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/AbstractMapEntry<TK;TV;>;Ljava/io/Serializable;
 method public,final getKey ()Ljava/lang/Object; ()TK; -
 method public,final getValue ()Ljava/lang/Object; ()TV; -
 method public,final setValue (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableList 52 public,super,abstract org/spongepowered/include/com/google/common/collect/ImmutableCollection java/util/List,java/util/RandomAccess <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection<TE;>;Ljava/util/List<TE;>;Ljava/util/RandomAccess;
 inner org/spongepowered/include/com/google/common/collect/ImmutableList$Builder org/spongepowered/include/com/google/common/collect/ImmutableList Builder public,static,final
 inner org/spongepowered/include/com/google/common/collect/ImmutableList$SubList org/spongepowered/include/com/google/common/collect/ImmutableList SubList -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static of ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList; <E:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public,static of (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList; <E:Ljava/lang/Object;>(TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList; <E:Ljava/lang/Object;>(TE;TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList; <E:Ljava/lang/Object;>(TE;TE;TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList; <E:Ljava/lang/Object;>(TE;TE;TE;TE;TE;TE;TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public listIterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator<TE;>; -
 method public listIterator (I)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator; (I)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator<TE;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TE;>;)V -
 method public indexOf (Ljava/lang/Object;)I - -
 method public lastIndexOf (Ljava/lang/Object;)I - -
 method public contains (Ljava/lang/Object;)Z - -
 method public subList (II)Lorg/spongepowered/include/com/google/common/collect/ImmutableList; (II)Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public,final,deprecated addAll (ILjava/util/Collection;)Z (ILjava/util/Collection<+TE;>;)Z -
 method public,final,deprecated set (ILjava/lang/Object;)Ljava/lang/Object; (ITE;)TE; -
 method public,final,deprecated add (ILjava/lang/Object;)V (ITE;)V -
 method public,final,deprecated remove (I)Ljava/lang/Object; (I)TE; -
 method public,final,deprecated replaceAll (Ljava/util/function/UnaryOperator;)V (Ljava/util/function/UnaryOperator<TE;>;)V -
 method public,final,deprecated sort (Ljava/util/Comparator;)V (Ljava/util/Comparator<-TE;>;)V -
 method public,final asList ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static builder ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder; <E:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableList$Builder 52 public,final,super org/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder<TE;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableList$Builder org/spongepowered/include/com/google/common/collect/ImmutableList Builder public,static,final
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder org/spongepowered/include/com/google/common/collect/ImmutableCollection ArrayBasedBuilder static,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder org/spongepowered/include/com/google/common/collect/ImmutableCollection Builder public,static,abstract
 method public <init> ()V - -
 method public add (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder; (TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder<TE;>; -
 method public addAll (Ljava/lang/Iterable;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder; (Ljava/lang/Iterable<+TE;>;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder<TE;>; -
 method public,varargs add ([Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder; ([TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableList$Builder<TE;>; -
 method public build ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableList$SubList 52 super org/spongepowered/include/com/google/common/collect/ImmutableList - Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableList$SubList org/spongepowered/include/com/google/common/collect/ImmutableList SubList -
 method public size ()I - -
 method public get (I)Ljava/lang/Object; (I)TE; -
 method public subList (II)Lorg/spongepowered/include/com/google/common/collect/ImmutableList; (II)Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMap 52 public,super,abstract java/lang/Object java/io/Serializable,java/util/Map <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/io/Serializable;Ljava/util/Map<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableMap$Builder org/spongepowered/include/com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static of ()Lorg/spongepowered/include/com/google/common/collect/ImmutableMap; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/ImmutableMap<TK;TV;>; -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableMap; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(TK;TV;)Lorg/spongepowered/include/com/google/common/collect/ImmutableMap<TK;TV;>; -
 method public,static builder ()Lorg/spongepowered/include/com/google/common/collect/ImmutableMap$Builder; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/ImmutableMap$Builder<TK;TV;>; -
 method public,final,deprecated put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public,final,deprecated putIfAbsent (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public,final,deprecated replace (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z (TK;TV;TV;)Z -
 method public,final,deprecated replace (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public,final,deprecated computeIfAbsent (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; (TK;Ljava/util/function/Function<-TK;+TV;>;)TV; -
 method public,final,deprecated computeIfPresent (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;Ljava/util/function/BiFunction<-TK;-TV;+TV;>;)TV; -
 method public,final,deprecated compute (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;Ljava/util/function/BiFunction<-TK;-TV;+TV;>;)TV; -
 method public,final,deprecated merge (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;TV;Ljava/util/function/BiFunction<-TV;-TV;+TV;>;)TV; -
 method public,final,deprecated putAll (Ljava/util/Map;)V (Ljava/util/Map<+TK;+TV;>;)V -
 method public,final,deprecated replaceAll (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<-TK;-TV;+TV;>;)V -
 method public,final,deprecated remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public,final,deprecated remove (Ljava/lang/Object;Ljava/lang/Object;)Z - -
 method public,final,deprecated clear ()V - -
 method public isEmpty ()Z - -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public,abstract get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public,final getOrDefault (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;TV;)TV; -
 method public entrySet ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public keySet ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TK;>; -
 method public values ()Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection<TV;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMap$Builder 52 public,super java/lang/Object - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/spongepowered/include/com/google/common/collect/ImmutableMap$Builder org/spongepowered/include/com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder org/spongepowered/include/com/google/common/collect/ImmutableCollection Builder public,static,abstract
 method public <init> ()V - -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableMap$Builder; (TK;TV;)Lorg/spongepowered/include/com/google/common/collect/ImmutableMap$Builder<TK;TV;>; -
 method public build ()Lorg/spongepowered/include/com/google/common/collect/ImmutableMap; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableMap<TK;TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMapEntry 52 super org/spongepowered/include/com/google/common/collect/ImmutableEntry - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableEntry<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableMapEntry$NonTerminalImmutableMapEntry org/spongepowered/include/com/google/common/collect/ImmutableMapEntry NonTerminalImmutableMapEntry static
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMapEntry$NonTerminalImmutableMapEntry 52 super org/spongepowered/include/com/google/common/collect/ImmutableMapEntry - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableMapEntry<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableMapEntry$NonTerminalImmutableMapEntry org/spongepowered/include/com/google/common/collect/ImmutableMapEntry NonTerminalImmutableMapEntry static
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet 52 super,abstract org/spongepowered/include/com/google/common/collect/ImmutableSet - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<Ljava/util/Map$Entry<TK;TV;>;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet$RegularEntrySet org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet RegularEntrySet static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public size ()I - -
 method public contains (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet$RegularEntrySet 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet$RegularEntrySet org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet RegularEntrySet static,final
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Ljava/util/Map$Entry<TK;TV;>;>;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMapKeySet 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed<TK;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed org/spongepowered/include/com/google/common/collect/ImmutableSet Indexed static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public size ()I - -
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TK;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TK;>; -
 method public contains (Ljava/lang/Object;)Z - -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TK;>;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableMapValues 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableCollection - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection<TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public size ()I - -
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TV;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TV;>; -
 method public contains (Ljava/lang/Object;)Z - -
 method public asList ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TV;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TV;>;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableSet 52 public,super,abstract org/spongepowered/include/com/google/common/collect/ImmutableCollection java/util/Set <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection<TE;>;Ljava/util/Set<TE;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableSet$Builder org/spongepowered/include/com/google/common/collect/ImmutableSet Builder public,static
 inner org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed org/spongepowered/include/com/google/common/collect/ImmutableSet Indexed static,abstract
 method public,static of ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; <E:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>; -
 method public,static of (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; <E:Ljava/lang/Object;>(TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>; -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; <E:Ljava/lang/Object;>(TE;TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>; -
 method public,static of (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; <E:Ljava/lang/Object;>(TE;TE;TE;TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>; -
 method public,static,varargs of (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; <E:Ljava/lang/Object;>(TE;TE;TE;TE;TE;TE;[TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>; -
 method public,static copyOf ([Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; <E:Ljava/lang/Object;>([TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,abstract iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public asList ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public,static builder ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder; <E:Ljava/lang/Object;>()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableSet$Builder 52 public,super org/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder<TE;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableSet$Builder org/spongepowered/include/com/google/common/collect/ImmutableSet Builder public,static
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$ArrayBasedBuilder org/spongepowered/include/com/google/common/collect/ImmutableCollection ArrayBasedBuilder static,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableCollection$Builder org/spongepowered/include/com/google/common/collect/ImmutableCollection Builder public,static,abstract
 method public <init> ()V - -
 method public add (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder; (TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder<TE;>; -
 method public,varargs add ([Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder; ([TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder<TE;>; -
 method public addAll (Ljava/lang/Iterable;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder; (Ljava/lang/Iterable<+TE;>;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Builder<TE;>; -
 method public build ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed 52 super,abstract org/spongepowered/include/com/google/common/collect/ImmutableSet - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed org/spongepowered/include/com/google/common/collect/ImmutableSet Indexed static,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TE;>;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableSortedSet 52 public,super,abstract org/spongepowered/include/com/google/common/collect/ImmutableSortedSetFauxverideShim java/util/NavigableSet,org/spongepowered/include/com/google/common/collect/SortedIterable <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSetFauxverideShim<TE;>;Ljava/util/NavigableSet<TE;>;Lorg/spongepowered/include/com/google/common/collect/SortedIterable<TE;>;
 method public comparator ()Ljava/util/Comparator; ()Ljava/util/Comparator<-TE;>; -
 method public,abstract iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public headSet (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; (TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public headSet (Ljava/lang/Object;Z)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; (TE;Z)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public subSet (Ljava/lang/Object;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; (TE;TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public subSet (Ljava/lang/Object;ZLjava/lang/Object;Z)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; (TE;ZTE;Z)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public tailSet (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; (TE;)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public tailSet (Ljava/lang/Object;Z)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; (TE;Z)Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public lower (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public floor (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public ceiling (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public higher (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public first ()Ljava/lang/Object; ()TE; -
 method public last ()Ljava/lang/Object; ()TE; -
 method public,final,deprecated pollFirst ()Ljava/lang/Object; ()TE; -
 method public,final,deprecated pollLast ()Ljava/lang/Object; ()TE; -
 method public descendingSet ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableSortedSet<TE;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
 method public,abstract descendingIterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/ImmutableSortedSetFauxverideShim 52 super,abstract org/spongepowered/include/com/google/common/collect/ImmutableSet - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>;
in 1181
class org/spongepowered/include/com/google/common/collect/Iterables 52 public,final,super java/lang/Object - -
 method public,static toString (Ljava/lang/Iterable;)Ljava/lang/String; (Ljava/lang/Iterable<*>;)Ljava/lang/String; -
 method public,static concat (Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/lang/Iterable; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<+TT;>;Ljava/lang/Iterable<+TT;>;)Ljava/lang/Iterable<TT;>; -
 method public,static transform (Ljava/lang/Iterable;Lorg/spongepowered/include/com/google/common/base/Function;)Ljava/lang/Iterable; <F:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/lang/Iterable<TF;>;Lorg/spongepowered/include/com/google/common/base/Function<-TF;+TT;>;)Ljava/lang/Iterable<TT;>; -
 method public,static getFirst (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<+TT;>;TT;)TT; -
in 1182
class org/spongepowered/include/com/google/common/collect/Iterators 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/collect/Iterators$ConcatenatedIterator org/spongepowered/include/com/google/common/collect/Iterators ConcatenatedIterator private,static
 method public,static unmodifiableIterator (Ljava/util/Iterator;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; <T:Ljava/lang/Object;>(Ljava/util/Iterator<+TT;>;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>; -
 method public,static contains (Ljava/util/Iterator;Ljava/lang/Object;)Z (Ljava/util/Iterator<*>;Ljava/lang/Object;)Z -
 method public,static removeAll (Ljava/util/Iterator;Ljava/util/Collection;)Z (Ljava/util/Iterator<*>;Ljava/util/Collection<*>;)Z -
 method public,static removeIf (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Predicate;)Z <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Lorg/spongepowered/include/com/google/common/base/Predicate<-TT;>;)Z -
 method public,static elementsEqual (Ljava/util/Iterator;Ljava/util/Iterator;)Z (Ljava/util/Iterator<*>;Ljava/util/Iterator<*>;)Z -
 method public,static toString (Ljava/util/Iterator;)Ljava/lang/String; (Ljava/util/Iterator<*>;)Ljava/lang/String; -
 method public,static concat (Ljava/util/Iterator;)Ljava/util/Iterator; <T:Ljava/lang/Object;>(Ljava/util/Iterator<+Ljava/util/Iterator<+TT;>;>;)Ljava/util/Iterator<TT;>; -
 method public,static any (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Predicate;)Z <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Lorg/spongepowered/include/com/google/common/base/Predicate<-TT;>;)Z -
 method public,static indexOf (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Predicate;)I <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Lorg/spongepowered/include/com/google/common/base/Predicate<-TT;>;)I -
 method public,static transform (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Function;)Ljava/util/Iterator; <F:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/util/Iterator<TF;>;Lorg/spongepowered/include/com/google/common/base/Function<-TF;+TT;>;)Ljava/util/Iterator<TT;>; -
 method public,static getNext (Ljava/util/Iterator;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Iterator<+TT;>;TT;)TT; -
 method public,static,varargs forArray ([Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; <T:Ljava/lang/Object;>([TT;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>; -
 method public,static singletonIterator (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; <T:Ljava/lang/Object;>(TT;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>; -
in 525
class org/spongepowered/include/com/google/common/collect/Iterators 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/collect/Iterators$ConcatenatedIterator org/spongepowered/include/com/google/common/collect/Iterators ConcatenatedIterator private,static
 method public,static unmodifiableIterator (Ljava/util/Iterator;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; <T:Ljava/lang/Object;>(Ljava/util/Iterator<+TT;>;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>; -
 method public,static contains (Ljava/util/Iterator;Ljava/lang/Object;)Z (Ljava/util/Iterator<*>;Ljava/lang/Object;)Z -
 method public,static removeAll (Ljava/util/Iterator;Ljava/util/Collection;)Z (Ljava/util/Iterator<*>;Ljava/util/Collection<*>;)Z -
 method public,static removeIf (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Predicate;)Z <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Lorg/spongepowered/include/com/google/common/base/Predicate<-TT;>;)Z -
 method public,static elementsEqual (Ljava/util/Iterator;Ljava/util/Iterator;)Z (Ljava/util/Iterator<*>;Ljava/util/Iterator<*>;)Z -
 method public,static toString (Ljava/util/Iterator;)Ljava/lang/String; (Ljava/util/Iterator<*>;)Ljava/lang/String; -
 method public,static concat (Ljava/util/Iterator;)Ljava/util/Iterator; <T:Ljava/lang/Object;>(Ljava/util/Iterator<+Ljava/util/Iterator<+TT;>;>;)Ljava/util/Iterator<TT;>; -
 method public,static filter (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Predicate;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Lorg/spongepowered/include/com/google/common/base/Predicate<-TT;>;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>; -
 method public,static any (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Predicate;)Z <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Lorg/spongepowered/include/com/google/common/base/Predicate<-TT;>;)Z -
 method public,static indexOf (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Predicate;)I <T:Ljava/lang/Object;>(Ljava/util/Iterator<TT;>;Lorg/spongepowered/include/com/google/common/base/Predicate<-TT;>;)I -
 method public,static transform (Ljava/util/Iterator;Lorg/spongepowered/include/com/google/common/base/Function;)Ljava/util/Iterator; <F:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/util/Iterator<TF;>;Lorg/spongepowered/include/com/google/common/base/Function<-TF;+TT;>;)Ljava/util/Iterator<TT;>; -
 method public,static getNext (Ljava/util/Iterator;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Iterator<+TT;>;TT;)TT; -
 method public,static,varargs forArray ([Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; <T:Ljava/lang/Object;>([TT;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>; -
 method public,static singletonIterator (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; <T:Ljava/lang/Object;>(TT;)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TT;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Iterators$ConcatenatedIterator 52 super org/spongepowered/include/com/google/common/collect/MultitransformedIterator - <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/MultitransformedIterator<Ljava/util/Iterator<+TT;>;TT;>;
 inner org/spongepowered/include/com/google/common/collect/Iterators$ConcatenatedIterator org/spongepowered/include/com/google/common/collect/Iterators ConcatenatedIterator private,static
 method public <init> (Ljava/util/Iterator;)V (Ljava/util/Iterator<+Ljava/util/Iterator<+TT;>;>;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/ListMultimap 52 public,interface,abstract java/lang/Object org/spongepowered/include/com/google/common/collect/Multimap <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Lorg/spongepowered/include/com/google/common/collect/Multimap<TK;TV;>;
 method public,abstract get (Ljava/lang/Object;)Ljava/util/List; (TK;)Ljava/util/List<TV;>; -
 method public,abstract removeAll (Ljava/lang/Object;)Ljava/util/List; (Ljava/lang/Object;)Ljava/util/List<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Lists 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/collect/Lists$TransformingRandomAccessList org/spongepowered/include/com/google/common/collect/Lists TransformingRandomAccessList private,static
 inner org/spongepowered/include/com/google/common/collect/Lists$TransformingSequentialList org/spongepowered/include/com/google/common/collect/Lists TransformingSequentialList private,static
 method public,static newArrayList ()Ljava/util/ArrayList; <E:Ljava/lang/Object;>()Ljava/util/ArrayList<TE;>; -
 method public,static transform (Ljava/util/List;Lorg/spongepowered/include/com/google/common/base/Function;)Ljava/util/List; <F:Ljava/lang/Object;T:Ljava/lang/Object;>(Ljava/util/List<TF;>;Lorg/spongepowered/include/com/google/common/base/Function<-TF;+TT;>;)Ljava/util/List<TT;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Lists$TransformingRandomAccessList 52 super java/util/AbstractList java/io/Serializable,java/util/RandomAccess <F:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/util/AbstractList<TT;>;Ljava/io/Serializable;Ljava/util/RandomAccess;
 inner org/spongepowered/include/com/google/common/collect/Lists$TransformingRandomAccessList org/spongepowered/include/com/google/common/collect/Lists TransformingRandomAccessList private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public clear ()V - -
 method public get (I)Ljava/lang/Object; (I)TT; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TT;>; -
 method public listIterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<TT;>; -
 method public isEmpty ()Z - -
 method public removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TT;>;)Z -
 method public remove (I)Ljava/lang/Object; (I)TT; -
 method public size ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/Lists$TransformingSequentialList 52 super java/util/AbstractSequentialList java/io/Serializable <F:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/util/AbstractSequentialList<TT;>;Ljava/io/Serializable;
 inner org/spongepowered/include/com/google/common/collect/Lists$TransformingSequentialList org/spongepowered/include/com/google/common/collect/Lists TransformingSequentialList private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public clear ()V - -
 method public size ()I - -
 method public listIterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<TT;>; -
 method public removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TT;>;)Z -
in 1181
class org/spongepowered/include/com/google/common/collect/Maps 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/collect/Maps$EntrySet org/spongepowered/include/com/google/common/collect/Maps EntrySet static,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$Values org/spongepowered/include/com/google/common/collect/Maps Values static
 inner org/spongepowered/include/com/google/common/collect/Maps$KeySet org/spongepowered/include/com/google/common/collect/Maps KeySet static
 inner org/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap org/spongepowered/include/com/google/common/collect/Maps IteratorBasedAbstractMap static,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$ViewCachingAbstractMap org/spongepowered/include/com/google/common/collect/Maps ViewCachingAbstractMap static,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$EntryFunction org/spongepowered/include/com/google/common/collect/Maps EntryFunction private,static,abstract,enum
 inner org/spongepowered/include/com/google/common/base/Joiner$MapJoiner org/spongepowered/include/com/google/common/base/Joiner MapJoiner public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableMap$Builder org/spongepowered/include/com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/stream/Collector$Characteristics java/util/stream/Collector Characteristics public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static newTreeMap ()Ljava/util/TreeMap; <K::Ljava/lang/Comparable;V:Ljava/lang/Object;>()Ljava/util/TreeMap<TK;TV;>; -
 method public,static immutableEntry (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(TK;TV;)Ljava/util/Map$Entry<TK;TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Maps$EntryFunction 52 super,abstract,enum java/lang/Enum org/spongepowered/include/com/google/common/base/Function Ljava/lang/Enum<Lorg/spongepowered/include/com/google/common/collect/Maps$EntryFunction;>;Lorg/spongepowered/include/com/google/common/base/Function<Ljava/util/Map$Entry<**>;Ljava/lang/Object;>;
 inner org/spongepowered/include/com/google/common/collect/Maps$EntryFunction org/spongepowered/include/com/google/common/collect/Maps EntryFunction private,static,abstract,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field public,static,final,enum KEY Lorg/spongepowered/include/com/google/common/collect/Maps$EntryFunction; -
 field public,static,final,enum VALUE Lorg/spongepowered/include/com/google/common/collect/Maps$EntryFunction; -
 method public,static values ()[Lorg/spongepowered/include/com/google/common/collect/Maps$EntryFunction; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/collect/Maps$EntryFunction; - -
in 1181
class org/spongepowered/include/com/google/common/collect/Maps$EntrySet 52 super,abstract org/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet<Ljava/util/Map$Entry<TK;TV;>;>;
 inner org/spongepowered/include/com/google/common/collect/Maps$EntrySet org/spongepowered/include/com/google/common/collect/Maps EntrySet static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet org/spongepowered/include/com/google/common/collect/Sets ImprovedAbstractSet static,abstract
 method public size ()I - -
 method public clear ()V - -
 method public contains (Ljava/lang/Object;)Z - -
 method public isEmpty ()Z - -
 method public remove (Ljava/lang/Object;)Z - -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
in 1181
class org/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap 52 super,abstract java/util/AbstractMap - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/util/AbstractMap<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/Maps$IteratorBasedAbstractMap org/spongepowered/include/com/google/common/collect/Maps IteratorBasedAbstractMap static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract size ()I - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public clear ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/Maps$KeySet 52 super org/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet<TK;>;
 inner org/spongepowered/include/com/google/common/collect/Maps$KeySet org/spongepowered/include/com/google/common/collect/Maps KeySet static
 inner org/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet org/spongepowered/include/com/google/common/collect/Sets ImprovedAbstractSet static,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TK;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TK;>;)V -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public remove (Ljava/lang/Object;)Z - -
 method public clear ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/Maps$Values 52 super java/util/AbstractCollection - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/util/AbstractCollection<TV;>;
 inner org/spongepowered/include/com/google/common/collect/Maps$Values org/spongepowered/include/com/google/common/collect/Maps Values static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TV;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TV;>;)V -
 method public remove (Ljava/lang/Object;)Z - -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public clear ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/Maps$ViewCachingAbstractMap 52 super,abstract java/util/AbstractMap - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/util/AbstractMap<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$ViewCachingAbstractMap org/spongepowered/include/com/google/common/collect/Maps ViewCachingAbstractMap static,abstract
 inner org/spongepowered/include/com/google/common/collect/Maps$KeySet org/spongepowered/include/com/google/common/collect/Maps KeySet static
 inner org/spongepowered/include/com/google/common/collect/Maps$Values org/spongepowered/include/com/google/common/collect/Maps Values static
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Multimap 52 public,interface,abstract java/lang/Object - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract put (Ljava/lang/Object;Ljava/lang/Object;)Z (TK;TV;)Z -
 method public,abstract removeAll (Ljava/lang/Object;)Ljava/util/Collection; (Ljava/lang/Object;)Ljava/util/Collection<TV;>; -
 method public,abstract get (Ljava/lang/Object;)Ljava/util/Collection; (TK;)Ljava/util/Collection<TV;>; -
 method public,abstract asMap ()Ljava/util/Map; ()Ljava/util/Map<TK;Ljava/util/Collection<TV;>;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Multimaps 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/util/stream/Collector$Characteristics java/util/stream/Collector Characteristics public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 1181
class org/spongepowered/include/com/google/common/collect/Multiset 52 public,interface,abstract java/lang/Object java/util/Collection <E:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Collection<TE;>;
 inner org/spongepowered/include/com/google/common/collect/Multiset$Entry org/spongepowered/include/com/google/common/collect/Multiset Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract size ()I - -
 method public,abstract elementSet ()Ljava/util/Set; ()Ljava/util/Set<TE;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<Lorg/spongepowered/include/com/google/common/collect/Multiset$Entry<TE;>;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TE;>;)V -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Multiset$Entry 52 public,interface,abstract java/lang/Object - <E:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/spongepowered/include/com/google/common/collect/Multiset$Entry org/spongepowered/include/com/google/common/collect/Multiset Entry public,static,interface,abstract
 method public,abstract getElement ()Ljava/lang/Object; ()TE; -
 method public,abstract getCount ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/Multisets 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/collect/Multiset$Entry org/spongepowered/include/com/google/common/collect/Multiset Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 1181
class org/spongepowered/include/com/google/common/collect/MultitransformedIterator 52 super,abstract java/lang/Object java/util/Iterator <F:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TT;>;
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TT; -
 method public remove ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/ObjectArrays 52 public,final,super java/lang/Object - -
 method public,static newArray (Ljava/lang/Class;I)[Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;I)[TT; -
 method public,static newArray ([Ljava/lang/Object;I)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;I)[TT; -
 method public,static concat ([Ljava/lang/Object;[Ljava/lang/Object;Ljava/lang/Class;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;[TT;Ljava/lang/Class<TT;>;)[TT; -
 method public,static concat (Ljava/lang/Object;[Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;[TT;)[TT; -
 method public,static concat ([Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;TT;)[TT; -
in 1181
class org/spongepowered/include/com/google/common/collect/Ordering 52 public,super,abstract java/lang/Object java/util/Comparator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Comparator<TT;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static from (Ljava/util/Comparator;)Lorg/spongepowered/include/com/google/common/collect/Ordering; <T:Ljava/lang/Object;>(Ljava/util/Comparator<TT;>;)Lorg/spongepowered/include/com/google/common/collect/Ordering<TT;>; -
 method protected <init> ()V - -
 method public reverse ()Lorg/spongepowered/include/com/google/common/collect/Ordering; <S:TT;>()Lorg/spongepowered/include/com/google/common/collect/Ordering<TS;>; -
 method public onResultOf (Lorg/spongepowered/include/com/google/common/base/Function;)Lorg/spongepowered/include/com/google/common/collect/Ordering; <F:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/common/base/Function<TF;+TT;>;)Lorg/spongepowered/include/com/google/common/collect/Ordering<TF;>; -
 method public,abstract compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I -
in 1181
class org/spongepowered/include/com/google/common/collect/Platform 52 final,super java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableAsList 52 super org/spongepowered/include/com/google/common/collect/ImmutableAsList - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableAsList<TE;>;
 method public listIterator (I)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator; (I)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator<TE;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TE;>;)V -
 method public get (I)Ljava/lang/Object; (I)TE; -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap 52 super org/spongepowered/include/com/google/common/collect/ImmutableBiMap - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap Inverse private,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet$RegularEntrySet org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet RegularEntrySet static,final
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<-TK;-TV;>;)V -
 method public hashCode ()I - -
 method public size ()I - -
 method public inverse ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TV;TK;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableBiMap - Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TV;TK;>;
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap Inverse private,final
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse$InverseEntrySet org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse InverseEntrySet final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public size ()I - -
 method public inverse ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TK;TV;>; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<-TV;-TK;>;)V -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TK; -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse$InverseEntrySet 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet - Lorg/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet<TV;TK;>;
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap Inverse private,final
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse$InverseEntrySet org/spongepowered/include/com/google/common/collect/RegularImmutableBiMap$Inverse InverseEntrySet final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public hashCode ()I - -
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<Ljava/util/Map$Entry<TV;TK;>;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Ljava/util/Map$Entry<TV;TK;>;>;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableList 52 super org/spongepowered/include/com/google/common/collect/ImmutableList - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>;
 method public size ()I - -
 method public get (I)Ljava/lang/Object; (I)TE; -
 method public listIterator (I)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator; (I)Lorg/spongepowered/include/com/google/common/collect/UnmodifiableListIterator<TE;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableMap 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableMap - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableMap<TK;TV;>;
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableMap$Values org/spongepowered/include/com/google/common/collect/RegularImmutableMap Values private,static,final
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableMap$KeySet org/spongepowered/include/com/google/common/collect/RegularImmutableMap KeySet private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/common/collect/ImmutableMapEntry$NonTerminalImmutableMapEntry org/spongepowered/include/com/google/common/collect/ImmutableMapEntry NonTerminalImmutableMapEntry static
 inner org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet$RegularEntrySet org/spongepowered/include/com/google/common/collect/ImmutableMapEntrySet RegularEntrySet static,final
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<-TK;-TV;>;)V -
 method public size ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableMap$KeySet 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed<TK;>;
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableMap$KeySet org/spongepowered/include/com/google/common/collect/RegularImmutableMap KeySet private,static,final
 inner org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed org/spongepowered/include/com/google/common/collect/ImmutableSet Indexed static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public contains (Ljava/lang/Object;)Z - -
 method public size ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableMap$Values 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableList - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TV;>;
 inner org/spongepowered/include/com/google/common/collect/RegularImmutableMap$Values org/spongepowered/include/com/google/common/collect/RegularImmutableMap Values private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public get (I)Ljava/lang/Object; (I)TV; -
 method public size ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/RegularImmutableSet 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed<TE;>;
 inner org/spongepowered/include/com/google/common/collect/ImmutableSet$Indexed org/spongepowered/include/com/google/common/collect/ImmutableSet Indexed static,abstract
 method public contains (Ljava/lang/Object;)Z - -
 method public size ()I - -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
 method public hashCode ()I - -
in 1181
class org/spongepowered/include/com/google/common/collect/ReverseOrdering 52 final,super org/spongepowered/include/com/google/common/collect/Ordering java/io/Serializable <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/Ordering<TT;>;Ljava/io/Serializable;
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I -
 method public reverse ()Lorg/spongepowered/include/com/google/common/collect/Ordering; <S:TT;>()Lorg/spongepowered/include/com/google/common/collect/Ordering<TS;>; -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/SetMultimap 52 public,interface,abstract java/lang/Object org/spongepowered/include/com/google/common/collect/Multimap <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Lorg/spongepowered/include/com/google/common/collect/Multimap<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,abstract get (Ljava/lang/Object;)Ljava/util/Set; (TK;)Ljava/util/Set<TV;>; -
 method public,abstract removeAll (Ljava/lang/Object;)Ljava/util/Set; (Ljava/lang/Object;)Ljava/util/Set<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Sets 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/collect/Sets$UnmodifiableNavigableSet org/spongepowered/include/com/google/common/collect/Sets UnmodifiableNavigableSet static,final
 inner org/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet org/spongepowered/include/com/google/common/collect/Sets ImprovedAbstractSet static,abstract
 method public,static newHashSet ()Ljava/util/HashSet; <E:Ljava/lang/Object;>()Ljava/util/HashSet<TE;>; -
 method public,static,varargs newHashSet ([Ljava/lang/Object;)Ljava/util/HashSet; <E:Ljava/lang/Object;>([TE;)Ljava/util/HashSet<TE;>; -
 method public,static newHashSetWithExpectedSize (I)Ljava/util/HashSet; <E:Ljava/lang/Object;>(I)Ljava/util/HashSet<TE;>; -
 method public,static unmodifiableNavigableSet (Ljava/util/NavigableSet;)Ljava/util/NavigableSet; <E:Ljava/lang/Object;>(Ljava/util/NavigableSet<TE;>;)Ljava/util/NavigableSet<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet 52 super,abstract java/util/AbstractSet - <E:Ljava/lang/Object;>Ljava/util/AbstractSet<TE;>;
 inner org/spongepowered/include/com/google/common/collect/Sets$ImprovedAbstractSet org/spongepowered/include/com/google/common/collect/Sets ImprovedAbstractSet static,abstract
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
in 1181
class org/spongepowered/include/com/google/common/collect/Sets$UnmodifiableNavigableSet 52 final,super org/spongepowered/include/com/google/common/collect/ForwardingSortedSet java/io/Serializable,java/util/NavigableSet <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ForwardingSortedSet<TE;>;Ljava/io/Serializable;Ljava/util/NavigableSet<TE;>;
 inner org/spongepowered/include/com/google/common/collect/Sets$UnmodifiableNavigableSet org/spongepowered/include/com/google/common/collect/Sets UnmodifiableNavigableSet static,final
 method protected delegate ()Ljava/util/SortedSet; ()Ljava/util/SortedSet<TE;>; -
 method public lower (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public floor (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public ceiling (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public higher (Ljava/lang/Object;)Ljava/lang/Object; (TE;)TE; -
 method public pollFirst ()Ljava/lang/Object; ()TE; -
 method public pollLast ()Ljava/lang/Object; ()TE; -
 method public descendingSet ()Ljava/util/NavigableSet; ()Ljava/util/NavigableSet<TE;>; -
 method public descendingIterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TE;>; -
 method public subSet (Ljava/lang/Object;ZLjava/lang/Object;Z)Ljava/util/NavigableSet; (TE;ZTE;Z)Ljava/util/NavigableSet<TE;>; -
 method public headSet (Ljava/lang/Object;Z)Ljava/util/NavigableSet; (TE;Z)Ljava/util/NavigableSet<TE;>; -
 method public tailSet (Ljava/lang/Object;Z)Ljava/util/NavigableSet; (TE;Z)Ljava/util/NavigableSet<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/SingletonImmutableBiMap 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableBiMap - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public size ()I - -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<-TK;-TV;>;)V -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public inverse ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap; ()Lorg/spongepowered/include/com/google/common/collect/ImmutableBiMap<TV;TK;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/SingletonImmutableList 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableList - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>;
 method public get (I)Ljava/lang/Object; (I)TE; -
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TE;>; -
 method public size ()I - -
 method public subList (II)Lorg/spongepowered/include/com/google/common/collect/ImmutableList; (II)Lorg/spongepowered/include/com/google/common/collect/ImmutableList<TE;>; -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/SingletonImmutableSet 52 final,super org/spongepowered/include/com/google/common/collect/ImmutableSet - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/ImmutableSet<TE;>;
 method public size ()I - -
 method public contains (Ljava/lang/Object;)Z - -
 method public iterator ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator; ()Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>; -
 method public,final hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/collect/SortedIterable 52 interface,abstract java/lang/Object java/lang/Iterable -
in 1181
class org/spongepowered/include/com/google/common/collect/SortedMultiset 52 public,interface,abstract java/lang/Object org/spongepowered/include/com/google/common/collect/SortedIterable,org/spongepowered/include/com/google/common/collect/SortedMultisetBridge <E:Ljava/lang/Object;>Ljava/lang/Object;Lorg/spongepowered/include/com/google/common/collect/SortedIterable<TE;>;Lorg/spongepowered/include/com/google/common/collect/SortedMultisetBridge<TE;>;
 inner org/spongepowered/include/com/google/common/collect/Multiset$Entry org/spongepowered/include/com/google/common/collect/Multiset Entry public,static,interface,abstract
 method public,abstract elementSet ()Ljava/util/NavigableSet; ()Ljava/util/NavigableSet<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/SortedMultisetBridge 52 interface,abstract java/lang/Object org/spongepowered/include/com/google/common/collect/Multiset <E:Ljava/lang/Object;>Ljava/lang/Object;Lorg/spongepowered/include/com/google/common/collect/Multiset<TE;>;
 method public,abstract elementSet ()Ljava/util/SortedSet; ()Ljava/util/SortedSet<TE;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/SortedSetMultimap 52 public,interface,abstract java/lang/Object org/spongepowered/include/com/google/common/collect/SetMultimap <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Lorg/spongepowered/include/com/google/common/collect/SetMultimap<TK;TV;>;
 method public,abstract get (Ljava/lang/Object;)Ljava/util/SortedSet; (TK;)Ljava/util/SortedSet<TV;>; -
 method public,abstract removeAll (Ljava/lang/Object;)Ljava/util/SortedSet; (Ljava/lang/Object;)Ljava/util/SortedSet<TV;>; -
in 1181
class org/spongepowered/include/com/google/common/collect/TransformedIterator 52 super,abstract java/lang/Object java/util/Iterator <F:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TT;>;
 method public,final hasNext ()Z - -
 method public,final next ()Ljava/lang/Object; ()TT; -
 method public,final remove ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/TransformedListIterator 52 super,abstract org/spongepowered/include/com/google/common/collect/TransformedIterator java/util/ListIterator <F:Ljava/lang/Object;T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/TransformedIterator<TF;TT;>;Ljava/util/ListIterator<TT;>;
 method public,final hasPrevious ()Z - -
 method public,final previous ()Ljava/lang/Object; ()TT; -
 method public,final nextIndex ()I - -
 method public,final previousIndex ()I - -
 method public set (Ljava/lang/Object;)V (TT;)V -
 method public add (Ljava/lang/Object;)V (TT;)V -
in 1181
class org/spongepowered/include/com/google/common/collect/TreeTraverser 52 public,super,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/UnmodifiableIterator 52 public,super,abstract java/lang/Object java/util/Iterator <E:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TE;>;
 method protected <init> ()V - -
 method public,final,deprecated remove ()V - -
in 1181
class org/spongepowered/include/com/google/common/collect/UnmodifiableListIterator 52 public,super,abstract org/spongepowered/include/com/google/common/collect/UnmodifiableIterator java/util/ListIterator <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/common/collect/UnmodifiableIterator<TE;>;Ljava/util/ListIterator<TE;>;
 method protected <init> ()V - -
 method public,final,deprecated add (Ljava/lang/Object;)V (TE;)V -
 method public,final,deprecated set (Ljava/lang/Object;)V (TE;)V -
in 1181
class org/spongepowered/include/com/google/common/io/ByteSink 52 public,super,abstract java/lang/Object - -
 inner org/spongepowered/include/com/google/common/io/ByteSink$AsCharSink org/spongepowered/include/com/google/common/io/ByteSink AsCharSink private,final
 method protected <init> ()V - -
 method public asCharSink (Ljava/nio/charset/Charset;)Lorg/spongepowered/include/com/google/common/io/CharSink; - -
 method public,abstract openStream ()Ljava/io/OutputStream; - java/io/IOException
 method public write ([B)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/ByteSink$AsCharSink 52 final,super org/spongepowered/include/com/google/common/io/CharSink - -
 inner org/spongepowered/include/com/google/common/io/ByteSink$AsCharSink org/spongepowered/include/com/google/common/io/ByteSink AsCharSink private,final
 method public openStream ()Ljava/io/Writer; - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/io/ByteSource 52 public,super,abstract java/lang/Object - -
 inner org/spongepowered/include/com/google/common/io/ByteSource$AsCharSource org/spongepowered/include/com/google/common/io/ByteSource AsCharSource private,final
 method protected <init> ()V - -
 method public asCharSource (Ljava/nio/charset/Charset;)Lorg/spongepowered/include/com/google/common/io/CharSource; - -
 method public,abstract openStream ()Ljava/io/InputStream; - java/io/IOException
 method public openBufferedStream ()Ljava/io/InputStream; - java/io/IOException
 method public read ()[B - java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/ByteSource$AsCharSource 52 final,super org/spongepowered/include/com/google/common/io/CharSource - -
 inner org/spongepowered/include/com/google/common/io/ByteSource$AsCharSource org/spongepowered/include/com/google/common/io/ByteSource AsCharSource private,final
 method public openStream ()Ljava/io/Reader; - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/io/ByteStreams 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/io/ByteStreams$FastByteArrayOutputStream org/spongepowered/include/com/google/common/io/ByteStreams FastByteArrayOutputStream private,static,final
 method public,static copy (Ljava/io/InputStream;Ljava/io/OutputStream;)J - java/io/IOException
 method public,static toByteArray (Ljava/io/InputStream;)[B - java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/ByteStreams$FastByteArrayOutputStream 52 final,super java/io/ByteArrayOutputStream - -
 inner org/spongepowered/include/com/google/common/io/ByteStreams$FastByteArrayOutputStream org/spongepowered/include/com/google/common/io/ByteStreams FastByteArrayOutputStream private,static,final
in 1181
class org/spongepowered/include/com/google/common/io/CharSink 52 public,super,abstract java/lang/Object - -
 method protected <init> ()V - -
 method public,abstract openStream ()Ljava/io/Writer; - java/io/IOException
 method public write (Ljava/lang/CharSequence;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/CharSource 52 public,super,abstract java/lang/Object - -
 method protected <init> ()V - -
 method public,abstract openStream ()Ljava/io/Reader; - java/io/IOException
 method public readLines (Lorg/spongepowered/include/com/google/common/io/LineProcessor;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/common/io/LineProcessor<TT;>;)TT; java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/CharStreams 52 public,final,super java/lang/Object - -
 method public,static readLines (Ljava/lang/Readable;Lorg/spongepowered/include/com/google/common/io/LineProcessor;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Readable;Lorg/spongepowered/include/com/google/common/io/LineProcessor<TT;>;)TT; java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/Closeables 52 public,final,super java/lang/Object - -
 method public,static close (Ljava/io/Closeable;Z)V - java/io/IOException
 method public,static closeQuietly (Ljava/io/InputStream;)V - -
 method public,static closeQuietly (Ljava/io/Reader;)V - -
in 1181
class org/spongepowered/include/com/google/common/io/Closer 52 public,final,super java/lang/Object java/io/Closeable -
 inner org/spongepowered/include/com/google/common/io/Closer$SuppressingSuppressor org/spongepowered/include/com/google/common/io/Closer SuppressingSuppressor static,final
 inner org/spongepowered/include/com/google/common/io/Closer$LoggingSuppressor org/spongepowered/include/com/google/common/io/Closer LoggingSuppressor static,final
 inner org/spongepowered/include/com/google/common/io/Closer$Suppressor org/spongepowered/include/com/google/common/io/Closer Suppressor static,interface,abstract
 method public,static create ()Lorg/spongepowered/include/com/google/common/io/Closer; - -
 method public register (Ljava/io/Closeable;)Ljava/io/Closeable; <C::Ljava/io/Closeable;>(TC;)TC; -
 method public rethrow (Ljava/lang/Throwable;)Ljava/lang/RuntimeException; - java/io/IOException
 method public close ()V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/Closer$LoggingSuppressor 52 final,super java/lang/Object org/spongepowered/include/com/google/common/io/Closer$Suppressor -
 inner org/spongepowered/include/com/google/common/io/Closer$LoggingSuppressor org/spongepowered/include/com/google/common/io/Closer LoggingSuppressor static,final
 inner org/spongepowered/include/com/google/common/io/Closer$Suppressor org/spongepowered/include/com/google/common/io/Closer Suppressor static,interface,abstract
 method public suppress (Ljava/io/Closeable;Ljava/lang/Throwable;Ljava/lang/Throwable;)V - -
in 1181
class org/spongepowered/include/com/google/common/io/Closer$SuppressingSuppressor 52 final,super java/lang/Object org/spongepowered/include/com/google/common/io/Closer$Suppressor -
 inner org/spongepowered/include/com/google/common/io/Closer$SuppressingSuppressor org/spongepowered/include/com/google/common/io/Closer SuppressingSuppressor static,final
 inner org/spongepowered/include/com/google/common/io/Closer$Suppressor org/spongepowered/include/com/google/common/io/Closer Suppressor static,interface,abstract
 inner org/spongepowered/include/com/google/common/io/Closer$LoggingSuppressor org/spongepowered/include/com/google/common/io/Closer LoggingSuppressor static,final
 method public suppress (Ljava/io/Closeable;Ljava/lang/Throwable;Ljava/lang/Throwable;)V - -
in 1181
class org/spongepowered/include/com/google/common/io/Closer$Suppressor 52 interface,abstract java/lang/Object - -
 inner org/spongepowered/include/com/google/common/io/Closer$Suppressor org/spongepowered/include/com/google/common/io/Closer Suppressor static,interface,abstract
 method public,abstract suppress (Ljava/io/Closeable;Ljava/lang/Throwable;Ljava/lang/Throwable;)V - -
in 1181
class org/spongepowered/include/com/google/common/io/FileWriteMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/include/com/google/common/io/FileWriteMode;>;
 field public,static,final,enum APPEND Lorg/spongepowered/include/com/google/common/io/FileWriteMode; -
 method public,static values ()[Lorg/spongepowered/include/com/google/common/io/FileWriteMode; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/io/FileWriteMode; - -
in 1181
class org/spongepowered/include/com/google/common/io/Files 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/io/Files$FileByteSink org/spongepowered/include/com/google/common/io/Files FileByteSink private,static,final
 inner org/spongepowered/include/com/google/common/io/Files$FileByteSource org/spongepowered/include/com/google/common/io/Files FileByteSource private,static,final
 inner java/nio/channels/FileChannel$MapMode java/nio/channels/FileChannel MapMode public,static
 method public,static asByteSource (Ljava/io/File;)Lorg/spongepowered/include/com/google/common/io/ByteSource; - -
 method public,static,varargs asByteSink (Ljava/io/File;[Lorg/spongepowered/include/com/google/common/io/FileWriteMode;)Lorg/spongepowered/include/com/google/common/io/ByteSink; - -
 method public,static asCharSource (Ljava/io/File;Ljava/nio/charset/Charset;)Lorg/spongepowered/include/com/google/common/io/CharSource; - -
 method public,static,varargs asCharSink (Ljava/io/File;Ljava/nio/charset/Charset;[Lorg/spongepowered/include/com/google/common/io/FileWriteMode;)Lorg/spongepowered/include/com/google/common/io/CharSink; - -
 method public,static write ([BLjava/io/File;)V - java/io/IOException
 method public,static write (Ljava/lang/CharSequence;Ljava/io/File;Ljava/nio/charset/Charset;)V - java/io/IOException
 method public,static append (Ljava/lang/CharSequence;Ljava/io/File;Ljava/nio/charset/Charset;)V - java/io/IOException
 method public,static readLines (Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/util/List; (Ljava/io/File;Ljava/nio/charset/Charset;)Ljava/util/List<Ljava/lang/String;>; java/io/IOException
 method public,static readLines (Ljava/io/File;Ljava/nio/charset/Charset;Lorg/spongepowered/include/com/google/common/io/LineProcessor;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/io/File;Ljava/nio/charset/Charset;Lorg/spongepowered/include/com/google/common/io/LineProcessor<TT;>;)TT; java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/Files$FileByteSink 52 final,super org/spongepowered/include/com/google/common/io/ByteSink - -
 inner org/spongepowered/include/com/google/common/io/Files$FileByteSink org/spongepowered/include/com/google/common/io/Files FileByteSink private,static,final
 method public openStream ()Ljava/io/FileOutputStream; - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/io/Files$FileByteSource 52 final,super org/spongepowered/include/com/google/common/io/ByteSource - -
 inner org/spongepowered/include/com/google/common/io/Files$FileByteSource org/spongepowered/include/com/google/common/io/Files FileByteSource private,static,final
 method public openStream ()Ljava/io/FileInputStream; - java/io/IOException
 method public read ()[B - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 1177
class org/spongepowered/include/com/google/common/io/InsecureRecursiveDeleteException 52 public,final,super java/nio/file/FileSystemException - -
 method public <init> (Ljava/lang/String;)V - -
in 1181
class org/spongepowered/include/com/google/common/io/LineBuffer 52 super,abstract java/lang/Object - -
 method protected add ([CII)V - java/io/IOException
 method protected finish ()V - java/io/IOException
 method protected,abstract handleLine (Ljava/lang/String;Ljava/lang/String;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/common/io/LineProcessor 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract processLine (Ljava/lang/String;)Z - java/io/IOException
 method public,abstract getResult ()Ljava/lang/Object; ()TT; -
in 1181
class org/spongepowered/include/com/google/common/io/LineReader 52 public,final,super java/lang/Object - -
 method public <init> (Ljava/lang/Readable;)V - -
 method public readLine ()Ljava/lang/String; - java/io/IOException
in 1177
class org/spongepowered/include/com/google/common/io/MoreFiles 52 public,final,super java/lang/Object - -
 method public,static,varargs deleteRecursively (Ljava/nio/file/Path;[Lorg/spongepowered/include/com/google/common/io/RecursiveDeleteOption;)V - java/io/IOException
in 1177
class org/spongepowered/include/com/google/common/io/RecursiveDeleteOption 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/include/com/google/common/io/RecursiveDeleteOption;>;
 field public,static,final,enum ALLOW_INSECURE Lorg/spongepowered/include/com/google/common/io/RecursiveDeleteOption; -
 method public,static values ()[Lorg/spongepowered/include/com/google/common/io/RecursiveDeleteOption; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/common/io/RecursiveDeleteOption; - -
in 1181
class org/spongepowered/include/com/google/common/io/Resources 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/io/Resources$UrlByteSource org/spongepowered/include/com/google/common/io/Resources UrlByteSource private,static,final
 method public,static asByteSource (Ljava/net/URL;)Lorg/spongepowered/include/com/google/common/io/ByteSource; - -
in 1181
class org/spongepowered/include/com/google/common/io/Resources$UrlByteSource 52 final,super org/spongepowered/include/com/google/common/io/ByteSource - -
 inner org/spongepowered/include/com/google/common/io/Resources$UrlByteSource org/spongepowered/include/com/google/common/io/Resources UrlByteSource private,static,final
 method public openStream ()Ljava/io/InputStream; - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/primitives/Chars 52 public,final,super java/lang/Object - -
 method public,static contains ([CC)Z - -
in 1181
class org/spongepowered/include/com/google/common/primitives/Doubles 52 public,final,super java/lang/Object - -
 method public,static tryParse (Ljava/lang/String;)Ljava/lang/Double; - -
in 1181
class org/spongepowered/include/com/google/common/primitives/Floats 52 public,final,super java/lang/Object - -
 method public,static tryParse (Ljava/lang/String;)Ljava/lang/Float; - -
in 1181
class org/spongepowered/include/com/google/common/primitives/Ints 52 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/common/primitives/Ints$IntArrayAsList org/spongepowered/include/com/google/common/primitives/Ints IntArrayAsList private,static
 method public,static hashCode (I)I - -
 method public,static compare (II)I - -
 method public,static contains ([II)Z - -
 method public,static indexOf ([II)I - -
 method public,static,varargs concat ([[I)[I - -
 method public,static toArray (Ljava/util/Collection;)[I (Ljava/util/Collection<+Ljava/lang/Number;>;)[I -
 method public,static tryParse (Ljava/lang/String;)Ljava/lang/Integer; - -
 method public,static tryParse (Ljava/lang/String;I)Ljava/lang/Integer; - -
in 1181
class org/spongepowered/include/com/google/common/primitives/Ints$IntArrayAsList 52 super java/util/AbstractList java/io/Serializable,java/util/RandomAccess Ljava/util/AbstractList<Ljava/lang/Integer;>;Ljava/io/Serializable;Ljava/util/RandomAccess;
 inner org/spongepowered/include/com/google/common/primitives/Ints$IntArrayAsList org/spongepowered/include/com/google/common/primitives/Ints IntArrayAsList private,static
 method public size ()I - -
 method public isEmpty ()Z - -
 method public get (I)Ljava/lang/Integer; - -
 method public contains (Ljava/lang/Object;)Z - -
 method public indexOf (Ljava/lang/Object;)I - -
 method public lastIndexOf (Ljava/lang/Object;)I - -
 method public set (ILjava/lang/Integer;)Ljava/lang/Integer; - -
 method public subList (II)Ljava/util/List; (II)Ljava/util/List<Ljava/lang/Integer;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/common/primitives/Longs 52 public,final,super java/lang/Object - -
 method public,static tryParse (Ljava/lang/String;)Ljava/lang/Long; - -
 method public,static tryParse (Ljava/lang/String;I)Ljava/lang/Long; - -
in 1181
class org/spongepowered/include/com/google/common/util/concurrent/ListenableFuture 52 public,interface,abstract java/lang/Object java/util/concurrent/Future <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/Future<TV;>;
in 1181
class org/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture 52 public,interface,abstract java/lang/Object java/util/concurrent/ScheduledFuture,org/spongepowered/include/com/google/common/util/concurrent/ListenableFuture <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/ScheduledFuture<TV;>;Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableFuture<TV;>;
in 1181
class org/spongepowered/include/com/google/common/util/concurrent/ListeningExecutorService 52 public,interface,abstract java/lang/Object java/util/concurrent/ExecutorService -
 method public,abstract submit (Ljava/util/concurrent/Callable;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableFuture; <T:Ljava/lang/Object;>(Ljava/util/concurrent/Callable<TT;>;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableFuture<TT;>; -
 method public,abstract submit (Ljava/lang/Runnable;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableFuture; (Ljava/lang/Runnable;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableFuture<*>; -
 method public,abstract submit (Ljava/lang/Runnable;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Runnable;TT;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableFuture<TT;>; -
in 1181
class org/spongepowered/include/com/google/common/util/concurrent/ListeningScheduledExecutorService 52 public,interface,abstract java/lang/Object java/util/concurrent/ScheduledExecutorService,org/spongepowered/include/com/google/common/util/concurrent/ListeningExecutorService -
 method public,abstract schedule (Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture; (Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture<*>; -
 method public,abstract schedule (Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture; <V:Ljava/lang/Object;>(Ljava/util/concurrent/Callable<TV;>;JLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture<TV;>; -
 method public,abstract scheduleAtFixedRate (Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture; (Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture<*>; -
 method public,abstract scheduleWithFixedDelay (Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture; (Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lorg/spongepowered/include/com/google/common/util/concurrent/ListenableScheduledFuture<*>; -
in 1181
class org/spongepowered/include/com/google/gson/DefaultDateTypeAdapter 49 final,super java/lang/Object org/spongepowered/include/com/google/gson/JsonDeserializer,org/spongepowered/include/com/google/gson/JsonSerializer Ljava/lang/Object;Lorg/spongepowered/include/com/google/gson/JsonDeserializer<Ljava/util/Date;>;Lorg/spongepowered/include/com/google/gson/JsonSerializer<Ljava/util/Date;>;
 method public <init> (II)V - -
 method public serialize (Ljava/util/Date;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/JsonSerializationContext;)Lorg/spongepowered/include/com/google/gson/JsonElement; - -
 method public deserialize (Lorg/spongepowered/include/com/google/gson/JsonElement;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/JsonDeserializationContext;)Ljava/util/Date; - org/spongepowered/include/com/google/gson/JsonParseException
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/ExclusionStrategy 49 public,interface,abstract java/lang/Object - -
 method public,abstract shouldSkipField (Lorg/spongepowered/include/com/google/gson/FieldAttributes;)Z - -
 method public,abstract shouldSkipClass (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
in 1181
class org/spongepowered/include/com/google/gson/FieldAttributes 49 public,final,super java/lang/Object - -
 method public <init> (Ljava/lang/reflect/Field;)V - -
in 1181
class org/spongepowered/include/com/google/gson/FieldNamingPolicy 49 public,super,abstract,enum java/lang/Enum org/spongepowered/include/com/google/gson/FieldNamingStrategy Ljava/lang/Enum<Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy;>;Lorg/spongepowered/include/com/google/gson/FieldNamingStrategy;
 field public,static,final,enum IDENTITY Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy; -
 field public,static,final,enum UPPER_CAMEL_CASE Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy; -
 field public,static,final,enum UPPER_CAMEL_CASE_WITH_SPACES Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy; -
 field public,static,final,enum LOWER_CASE_WITH_UNDERSCORES Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy; -
 field public,static,final,enum LOWER_CASE_WITH_DASHES Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy; -
 method public,static values ()[Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/gson/FieldNamingPolicy; - -
in 1181
class org/spongepowered/include/com/google/gson/FieldNamingStrategy 49 public,interface,abstract java/lang/Object - -
 method public,abstract translateName (Ljava/lang/reflect/Field;)Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/Gson 49 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/gson/Gson$FutureTypeAdapter org/spongepowered/include/com/google/gson/Gson FutureTypeAdapter static
 method public <init> ()V - -
 method public getAdapter (Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
 method public getDelegateAdapter (Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
 method public getAdapter (Ljava/lang/Class;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
 method public toJson (Ljava/lang/Object;Ljava/lang/Appendable;)V - org/spongepowered/include/com/google/gson/JsonIOException
 method public toJson (Ljava/lang/Object;Ljava/lang/reflect/Type;Ljava/lang/Appendable;)V - org/spongepowered/include/com/google/gson/JsonIOException
 method public toJson (Ljava/lang/Object;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;)V - org/spongepowered/include/com/google/gson/JsonIOException
 method public toJson (Lorg/spongepowered/include/com/google/gson/JsonElement;)Ljava/lang/String; - -
 method public toJson (Lorg/spongepowered/include/com/google/gson/JsonElement;Ljava/lang/Appendable;)V - org/spongepowered/include/com/google/gson/JsonIOException
 method public toJson (Lorg/spongepowered/include/com/google/gson/JsonElement;Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;)V - org/spongepowered/include/com/google/gson/JsonIOException
 method public fromJson (Ljava/io/Reader;Ljava/lang/Class;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/io/Reader;Ljava/lang/Class<TT;>;)TT; org/spongepowered/include/com/google/gson/JsonSyntaxException,org/spongepowered/include/com/google/gson/JsonIOException
 method public fromJson (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;Ljava/lang/reflect/Type;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/stream/JsonReader;Ljava/lang/reflect/Type;)TT; org/spongepowered/include/com/google/gson/JsonIOException,org/spongepowered/include/com/google/gson/JsonSyntaxException
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/Gson$FutureTypeAdapter 49 super org/spongepowered/include/com/google/gson/TypeAdapter - <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>;
 inner org/spongepowered/include/com/google/gson/Gson$FutureTypeAdapter org/spongepowered/include/com/google/gson/Gson FutureTypeAdapter static
 method public setDelegate (Lorg/spongepowered/include/com/google/gson/TypeAdapter;)V (Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>;)V -
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Object; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)TT; java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Object;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;TT;)V java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/GsonBuilder 49 public,final,super java/lang/Object - -
 method public <init> ()V - -
 method public setPrettyPrinting ()Lorg/spongepowered/include/com/google/gson/GsonBuilder; - -
 method public disableHtmlEscaping ()Lorg/spongepowered/include/com/google/gson/GsonBuilder; - -
 method public create ()Lorg/spongepowered/include/com/google/gson/Gson; - -
in 1181
class org/spongepowered/include/com/google/gson/InstanceCreator 49 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract createInstance (Ljava/lang/reflect/Type;)Ljava/lang/Object; (Ljava/lang/reflect/Type;)TT; -
in 1181
class org/spongepowered/include/com/google/gson/JsonArray 49 public,final,super org/spongepowered/include/com/google/gson/JsonElement java/lang/Iterable Lorg/spongepowered/include/com/google/gson/JsonElement;Ljava/lang/Iterable<Lorg/spongepowered/include/com/google/gson/JsonElement;>;
 method public <init> ()V - -
 method public add (Lorg/spongepowered/include/com/google/gson/JsonElement;)V - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lorg/spongepowered/include/com/google/gson/JsonElement;>; -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public getAsString ()Ljava/lang/String; - -
 method public getAsDouble ()D - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsBoolean ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 1181
class org/spongepowered/include/com/google/gson/JsonDeserializationContext 49 public,interface,abstract java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/gson/JsonDeserializer 49 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract deserialize (Lorg/spongepowered/include/com/google/gson/JsonElement;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/JsonDeserializationContext;)Ljava/lang/Object; (Lorg/spongepowered/include/com/google/gson/JsonElement;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/JsonDeserializationContext;)TT; org/spongepowered/include/com/google/gson/JsonParseException
in 1181
class org/spongepowered/include/com/google/gson/JsonElement 49 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public isJsonArray ()Z - -
 method public isJsonObject ()Z - -
 method public isJsonPrimitive ()Z - -
 method public isJsonNull ()Z - -
 method public getAsJsonObject ()Lorg/spongepowered/include/com/google/gson/JsonObject; - -
 method public getAsJsonArray ()Lorg/spongepowered/include/com/google/gson/JsonArray; - -
 method public getAsJsonPrimitive ()Lorg/spongepowered/include/com/google/gson/JsonPrimitive; - -
 method public getAsBoolean ()Z - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public getAsString ()Ljava/lang/String; - -
 method public getAsDouble ()D - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/JsonIOException 49 public,final,super org/spongepowered/include/com/google/gson/JsonParseException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
in 1181
class org/spongepowered/include/com/google/gson/JsonNull 49 public,final,super org/spongepowered/include/com/google/gson/JsonElement - -
 field public,static,final INSTANCE Lorg/spongepowered/include/com/google/gson/JsonNull; -
 method public,deprecated <init> ()V - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 1181
class org/spongepowered/include/com/google/gson/JsonObject 49 public,final,super org/spongepowered/include/com/google/gson/JsonElement - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public add (Ljava/lang/String;Lorg/spongepowered/include/com/google/gson/JsonElement;)V - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Lorg/spongepowered/include/com/google/gson/JsonElement;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 1181
class org/spongepowered/include/com/google/gson/JsonParseException 49 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
in 1181
class org/spongepowered/include/com/google/gson/JsonPrimitive 49 public,final,super org/spongepowered/include/com/google/gson/JsonElement - -
 method public <init> (Ljava/lang/Boolean;)V - -
 method public <init> (Ljava/lang/Number;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public isBoolean ()Z - -
 method public getAsBoolean ()Z - -
 method public isNumber ()Z - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public isString ()Z - -
 method public getAsString ()Ljava/lang/String; - -
 method public getAsDouble ()D - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 1181
class org/spongepowered/include/com/google/gson/JsonSerializationContext 49 public,interface,abstract java/lang/Object - -
in 1181
class org/spongepowered/include/com/google/gson/JsonSerializer 49 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract serialize (Ljava/lang/Object;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/JsonSerializationContext;)Lorg/spongepowered/include/com/google/gson/JsonElement; (TT;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/JsonSerializationContext;)Lorg/spongepowered/include/com/google/gson/JsonElement; -
in 1181
class org/spongepowered/include/com/google/gson/JsonSyntaxException 49 public,final,super org/spongepowered/include/com/google/gson/JsonParseException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
in 1181
class org/spongepowered/include/com/google/gson/LongSerializationPolicy 49 public,super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/include/com/google/gson/LongSerializationPolicy;>;
 field public,static,final,enum DEFAULT Lorg/spongepowered/include/com/google/gson/LongSerializationPolicy; -
 field public,static,final,enum STRING Lorg/spongepowered/include/com/google/gson/LongSerializationPolicy; -
 method public,static values ()[Lorg/spongepowered/include/com/google/gson/LongSerializationPolicy; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/gson/LongSerializationPolicy; - -
in 1181
class org/spongepowered/include/com/google/gson/TreeTypeAdapter 49 final,super org/spongepowered/include/com/google/gson/TypeAdapter - <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>;
 inner org/spongepowered/include/com/google/gson/TreeTypeAdapter$SingleTypeFactory org/spongepowered/include/com/google/gson/TreeTypeAdapter SingleTypeFactory private,static
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Object; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)TT; java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Object;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;TT;)V java/io/IOException
 method public,static newFactory (Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; (Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<*>;Ljava/lang/Object;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
in 1181
class org/spongepowered/include/com/google/gson/TreeTypeAdapter$SingleTypeFactory 49 super java/lang/Object org/spongepowered/include/com/google/gson/TypeAdapterFactory -
 inner org/spongepowered/include/com/google/gson/TreeTypeAdapter$SingleTypeFactory org/spongepowered/include/com/google/gson/TreeTypeAdapter SingleTypeFactory private,static
 method public create (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
in 1181
class org/spongepowered/include/com/google/gson/TypeAdapter 49 public,super,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> ()V - -
 method public,abstract write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Object;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;TT;)V java/io/IOException
 method public,final toJsonTree (Ljava/lang/Object;)Lorg/spongepowered/include/com/google/gson/JsonElement; (TT;)Lorg/spongepowered/include/com/google/gson/JsonElement; -
 method public,abstract read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Object; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)TT; java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/TypeAdapterFactory 49 public,interface,abstract java/lang/Object - -
 method public,abstract create (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
in 1181
class org/spongepowered/include/com/google/gson/annotations/Expose 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract serialize ()Z - - Z1
 method public,abstract deserialize ()Z - - Z1
in 1181
class org/spongepowered/include/com/google/gson/annotations/SerializedName 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/annotations/Since 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()D - -
in 1181
class org/spongepowered/include/com/google/gson/annotations/Until 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()D - -
in 1181
class org/spongepowered/include/com/google/gson/internal/$Gson$Preconditions 49 public,final,super java/lang/Object - -
 method public,static checkNotNull (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;)TT; -
 method public,static checkArgument (Z)V - -
in 1181
class org/spongepowered/include/com/google/gson/internal/$Gson$Types 49 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/gson/internal/$Gson$Types$WildcardTypeImpl org/spongepowered/include/com/google/gson/internal/$Gson$Types WildcardTypeImpl private,static,final
 inner org/spongepowered/include/com/google/gson/internal/$Gson$Types$GenericArrayTypeImpl org/spongepowered/include/com/google/gson/internal/$Gson$Types GenericArrayTypeImpl private,static,final
 inner org/spongepowered/include/com/google/gson/internal/$Gson$Types$ParameterizedTypeImpl org/spongepowered/include/com/google/gson/internal/$Gson$Types ParameterizedTypeImpl private,static,final
 method public,static,varargs newParameterizedTypeWithOwner (Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)Ljava/lang/reflect/ParameterizedType; - -
 method public,static arrayOf (Ljava/lang/reflect/Type;)Ljava/lang/reflect/GenericArrayType; - -
 method public,static subtypeOf (Ljava/lang/reflect/Type;)Ljava/lang/reflect/WildcardType; - -
 method public,static supertypeOf (Ljava/lang/reflect/Type;)Ljava/lang/reflect/WildcardType; - -
 method public,static canonicalize (Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; - -
 method public,static getRawType (Ljava/lang/reflect/Type;)Ljava/lang/Class; (Ljava/lang/reflect/Type;)Ljava/lang/Class<*>; -
 method public,static equals (Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;)Z - -
 method public,static typeToString (Ljava/lang/reflect/Type;)Ljava/lang/String; - -
 method public,static getArrayComponentType (Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; - -
 method public,static getCollectionElementType (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/reflect/Type; -
 method public,static getMapKeyAndValueTypes (Ljava/lang/reflect/Type;Ljava/lang/Class;)[Ljava/lang/reflect/Type; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)[Ljava/lang/reflect/Type; -
 method public,static resolve (Ljava/lang/reflect/Type;Ljava/lang/Class;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; -
in 1181
class org/spongepowered/include/com/google/gson/internal/$Gson$Types$GenericArrayTypeImpl 49 final,super java/lang/Object java/io/Serializable,java/lang/reflect/GenericArrayType -
 inner org/spongepowered/include/com/google/gson/internal/$Gson$Types$GenericArrayTypeImpl org/spongepowered/include/com/google/gson/internal/$Gson$Types GenericArrayTypeImpl private,static,final
 method public <init> (Ljava/lang/reflect/Type;)V - -
 method public getGenericComponentType ()Ljava/lang/reflect/Type; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/$Gson$Types$ParameterizedTypeImpl 49 final,super java/lang/Object java/io/Serializable,java/lang/reflect/ParameterizedType -
 inner org/spongepowered/include/com/google/gson/internal/$Gson$Types$ParameterizedTypeImpl org/spongepowered/include/com/google/gson/internal/$Gson$Types ParameterizedTypeImpl private,static,final
 method public,varargs <init> (Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)V - -
 method public getActualTypeArguments ()[Ljava/lang/reflect/Type; - -
 method public getRawType ()Ljava/lang/reflect/Type; - -
 method public getOwnerType ()Ljava/lang/reflect/Type; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/$Gson$Types$WildcardTypeImpl 49 final,super java/lang/Object java/io/Serializable,java/lang/reflect/WildcardType -
 inner org/spongepowered/include/com/google/gson/internal/$Gson$Types$WildcardTypeImpl org/spongepowered/include/com/google/gson/internal/$Gson$Types WildcardTypeImpl private,static,final
 method public <init> ([Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)V - -
 method public getUpperBounds ()[Ljava/lang/reflect/Type; - -
 method public getLowerBounds ()[Ljava/lang/reflect/Type; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/ConstructorConstructor 49 public,final,super java/lang/Object - -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/InstanceCreator<*>;>;)V -
 method public get (Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/internal/ObjectConstructor; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/internal/ObjectConstructor<TT;>; -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/Excluder 49 public,final,super java/lang/Object java/lang/Cloneable,org/spongepowered/include/com/google/gson/TypeAdapterFactory -
 field public,static,final DEFAULT Lorg/spongepowered/include/com/google/gson/internal/Excluder; -
 method public <init> ()V - -
 method protected clone ()Lorg/spongepowered/include/com/google/gson/internal/Excluder; - -
 method public create (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
 method public excludeField (Ljava/lang/reflect/Field;Z)Z - -
 method public excludeClass (Ljava/lang/Class;Z)Z (Ljava/lang/Class<*>;Z)Z -
in 1181
class org/spongepowered/include/com/google/gson/internal/JsonReaderInternalAccess 49 public,super,abstract java/lang/Object - -
 field public,static INSTANCE Lorg/spongepowered/include/com/google/gson/internal/JsonReaderInternalAccess; -
 method public <init> ()V - -
 method public,abstract promoteNameToValue (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/LazilyParsedNumber 49 public,final,super java/lang/Number - -
 method public <init> (Ljava/lang/String;)V - -
 method public intValue ()I - -
 method public longValue ()J - -
 method public floatValue ()F - -
 method public doubleValue ()D - -
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/LinkedTreeMap 49 public,final,super java/util/AbstractMap java/io/Serializable <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/util/AbstractMap<TK;TV;>;Ljava/io/Serializable;
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$KeySet org/spongepowered/include/com/google/gson/internal/LinkedTreeMap KeySet -
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$EntrySet org/spongepowered/include/com/google/gson/internal/LinkedTreeMap EntrySet -
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$LinkedTreeMapIterator org/spongepowered/include/com/google/gson/internal/LinkedTreeMap LinkedTreeMapIterator private,abstract
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node org/spongepowered/include/com/google/gson/internal/LinkedTreeMap Node static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public <init> (Ljava/util/Comparator;)V (Ljava/util/Comparator<-TK;>;)V -
 method public size ()I - -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public clear ()V - -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
in 1181
class org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$EntrySet 49 super java/util/AbstractSet - Ljava/util/AbstractSet<Ljava/util/Map$Entry<TK;TV;>;>;
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$EntrySet org/spongepowered/include/com/google/gson/internal/LinkedTreeMap EntrySet -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node org/spongepowered/include/com/google/gson/internal/LinkedTreeMap Node static,final
 method public size ()I - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public contains (Ljava/lang/Object;)Z - -
 method public remove (Ljava/lang/Object;)Z - -
 method public clear ()V - -
in 1181
class org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$KeySet 49 super java/util/AbstractSet - Ljava/util/AbstractSet<TK;>;
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$KeySet org/spongepowered/include/com/google/gson/internal/LinkedTreeMap KeySet -
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node org/spongepowered/include/com/google/gson/internal/LinkedTreeMap Node static,final
 method public size ()I - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TK;>; -
 method public contains (Ljava/lang/Object;)Z - -
 method public remove (Ljava/lang/Object;)Z - -
 method public clear ()V - -
in 1181
class org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$LinkedTreeMapIterator 49 super,abstract java/lang/Object java/util/Iterator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TT;>;
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node org/spongepowered/include/com/google/gson/internal/LinkedTreeMap Node static,final
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$LinkedTreeMapIterator org/spongepowered/include/com/google/gson/internal/LinkedTreeMap LinkedTreeMapIterator private,abstract
 method public,final hasNext ()Z - -
 method public,final remove ()V - -
in 1181
class org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node 49 final,super java/lang/Object java/util/Map$Entry <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Map$Entry<TK;TV;>;
 inner org/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node org/spongepowered/include/com/google/gson/internal/LinkedTreeMap Node static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public getKey ()Ljava/lang/Object; ()TK; -
 method public getValue ()Ljava/lang/Object; ()TV; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public first ()Lorg/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node; ()Lorg/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node<TK;TV;>; -
 method public last ()Lorg/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node; ()Lorg/spongepowered/include/com/google/gson/internal/LinkedTreeMap$Node<TK;TV;>; -
in 1181
class org/spongepowered/include/com/google/gson/internal/ObjectConstructor 49 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract construct ()Ljava/lang/Object; ()TT; -
in 1181
class org/spongepowered/include/com/google/gson/internal/Primitives 49 public,final,super java/lang/Object - -
 method public,static isPrimitive (Ljava/lang/reflect/Type;)Z - -
 method public,static wrap (Ljava/lang/Class;)Ljava/lang/Class; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Ljava/lang/Class<TT;>; -
in 1181
class org/spongepowered/include/com/google/gson/internal/Streams 49 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter org/spongepowered/include/com/google/gson/internal/Streams AppendableWriter private,static,final
 method public,static parse (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Lorg/spongepowered/include/com/google/gson/JsonElement; - org/spongepowered/include/com/google/gson/JsonParseException
 method public,static write (Lorg/spongepowered/include/com/google/gson/JsonElement;Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;)V - java/io/IOException
 method public,static writerForAppendable (Ljava/lang/Appendable;)Ljava/io/Writer; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter 49 final,super java/io/Writer - -
 inner org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter org/spongepowered/include/com/google/gson/internal/Streams AppendableWriter private,static,final
 inner org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter$CurrentWrite org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter CurrentWrite static
 method public write ([CII)V - java/io/IOException
 method public write (I)V - java/io/IOException
 method public flush ()V - -
 method public close ()V - -
in 1181
class org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter$CurrentWrite 49 super java/lang/Object java/lang/CharSequence -
 inner org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter org/spongepowered/include/com/google/gson/internal/Streams AppendableWriter private,static,final
 inner org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter$CurrentWrite org/spongepowered/include/com/google/gson/internal/Streams$AppendableWriter CurrentWrite static
 method public length ()I - -
 method public charAt (I)C - -
 method public subSequence (II)Ljava/lang/CharSequence; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/UnsafeAllocator 49 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract newInstance (Ljava/lang/Class;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)TT; java/lang/Exception
 method public,static create ()Lorg/spongepowered/include/com/google/gson/internal/UnsafeAllocator; - -
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/ArrayTypeAdapter 49 public,final,super org/spongepowered/include/com/google/gson/TypeAdapter - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Object;>;
 field public,static,final FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public <init> (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/TypeAdapter;Ljava/lang/Class;)V (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/TypeAdapter<TE;>;Ljava/lang/Class<TE;>;)V -
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Object; - java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Object;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/CollectionTypeAdapterFactory 49 public,final,super java/lang/Object org/spongepowered/include/com/google/gson/TypeAdapterFactory -
 inner org/spongepowered/include/com/google/gson/internal/bind/CollectionTypeAdapterFactory$Adapter org/spongepowered/include/com/google/gson/internal/bind/CollectionTypeAdapterFactory Adapter private,static,final
 method public <init> (Lorg/spongepowered/include/com/google/gson/internal/ConstructorConstructor;)V - -
 method public create (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/CollectionTypeAdapterFactory$Adapter 49 final,super org/spongepowered/include/com/google/gson/TypeAdapter - <E:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/util/Collection<TE;>;>;
 inner org/spongepowered/include/com/google/gson/internal/bind/CollectionTypeAdapterFactory$Adapter org/spongepowered/include/com/google/gson/internal/bind/CollectionTypeAdapterFactory Adapter private,static,final
 method public <init> (Lorg/spongepowered/include/com/google/gson/Gson;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/TypeAdapter;Lorg/spongepowered/include/com/google/gson/internal/ObjectConstructor;)V (Lorg/spongepowered/include/com/google/gson/Gson;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/TypeAdapter<TE;>;Lorg/spongepowered/include/com/google/gson/internal/ObjectConstructor<+Ljava/util/Collection<TE;>;>;)V -
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/util/Collection; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/util/Collection<TE;>; java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/util/Collection;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/util/Collection<TE;>;)V java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/DateTypeAdapter 49 public,final,super org/spongepowered/include/com/google/gson/TypeAdapter - Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/util/Date;>;
 field public,static,final FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public <init> ()V - -
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/util/Date; - java/io/IOException
 method public,synchronized write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/util/Date;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/JsonTreeReader 49 public,final,super org/spongepowered/include/com/google/gson/stream/JsonReader - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public beginArray ()V - java/io/IOException
 method public endArray ()V - java/io/IOException
 method public beginObject ()V - java/io/IOException
 method public endObject ()V - java/io/IOException
 method public hasNext ()Z - java/io/IOException
 method public peek ()Lorg/spongepowered/include/com/google/gson/stream/JsonToken; - java/io/IOException
 method public nextName ()Ljava/lang/String; - java/io/IOException
 method public nextString ()Ljava/lang/String; - java/io/IOException
 method public nextBoolean ()Z - java/io/IOException
 method public nextNull ()V - java/io/IOException
 method public nextDouble ()D - java/io/IOException
 method public nextLong ()J - java/io/IOException
 method public nextInt ()I - java/io/IOException
 method public close ()V - java/io/IOException
 method public skipValue ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
 method public promoteNameToValue ()V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/JsonTreeWriter 49 public,final,super org/spongepowered/include/com/google/gson/stream/JsonWriter - -
 method public <init> ()V - -
 method public get ()Lorg/spongepowered/include/com/google/gson/JsonElement; - -
 method public beginArray ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public endArray ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public beginObject ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public endObject ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public name (Ljava/lang/String;)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (Ljava/lang/String;)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public nullValue ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (Z)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (J)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (Ljava/lang/Number;)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public flush ()V - java/io/IOException
 method public close ()V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/MapTypeAdapterFactory 49 public,final,super java/lang/Object org/spongepowered/include/com/google/gson/TypeAdapterFactory -
 inner org/spongepowered/include/com/google/gson/internal/bind/MapTypeAdapterFactory$Adapter org/spongepowered/include/com/google/gson/internal/bind/MapTypeAdapterFactory Adapter private,final
 method public <init> (Lorg/spongepowered/include/com/google/gson/internal/ConstructorConstructor;Z)V - -
 method public create (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/MapTypeAdapterFactory$Adapter 49 final,super org/spongepowered/include/com/google/gson/TypeAdapter - <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/util/Map<TK;TV;>;>;
 inner org/spongepowered/include/com/google/gson/internal/bind/MapTypeAdapterFactory$Adapter org/spongepowered/include/com/google/gson/internal/bind/MapTypeAdapterFactory Adapter private,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Lorg/spongepowered/include/com/google/gson/internal/bind/MapTypeAdapterFactory;Lorg/spongepowered/include/com/google/gson/Gson;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/TypeAdapter;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/TypeAdapter;Lorg/spongepowered/include/com/google/gson/internal/ObjectConstructor;)V (Lorg/spongepowered/include/com/google/gson/Gson;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/TypeAdapter<TK;>;Ljava/lang/reflect/Type;Lorg/spongepowered/include/com/google/gson/TypeAdapter<TV;>;Lorg/spongepowered/include/com/google/gson/internal/ObjectConstructor<+Ljava/util/Map<TK;TV;>;>;)V -
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/util/Map; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/util/Map<TK;TV;>; java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/util/Map;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/util/Map<TK;TV;>;)V java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/ObjectTypeAdapter 49 public,final,super org/spongepowered/include/com/google/gson/TypeAdapter - Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Object;>;
 field public,static,final FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Object; - java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Object;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory 49 public,final,super java/lang/Object org/spongepowered/include/com/google/gson/TypeAdapterFactory -
 inner org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$Adapter org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory Adapter public,static,final
 inner org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$BoundField org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory BoundField static,abstract
 method public <init> (Lorg/spongepowered/include/com/google/gson/internal/ConstructorConstructor;Lorg/spongepowered/include/com/google/gson/FieldNamingStrategy;Lorg/spongepowered/include/com/google/gson/internal/Excluder;)V - -
 method public excludeField (Ljava/lang/reflect/Field;Z)Z - -
 method public create (Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken;)Lorg/spongepowered/include/com/google/gson/TypeAdapter; <T:Ljava/lang/Object;>(Lorg/spongepowered/include/com/google/gson/Gson;Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>; -
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$Adapter 49 public,final,super org/spongepowered/include/com/google/gson/TypeAdapter - <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>;
 inner org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$BoundField org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory BoundField static,abstract
 inner org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$Adapter org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory Adapter public,static,final
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Object; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)TT; java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Object;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;TT;)V java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$BoundField 49 super,abstract java/lang/Object - -
 inner org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$BoundField org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory BoundField static,abstract
 method protected <init> (Ljava/lang/String;ZZ)V - -
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/SqlDateTypeAdapter 49 public,final,super org/spongepowered/include/com/google/gson/TypeAdapter - Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/sql/Date;>;
 field public,static,final FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public <init> ()V - -
 method public,synchronized read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/sql/Date; - java/io/IOException
 method public,synchronized write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/sql/Date;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/TimeTypeAdapter 49 public,final,super org/spongepowered/include/com/google/gson/TypeAdapter - Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/sql/Time;>;
 field public,static,final FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public <init> ()V - -
 method public,synchronized read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/sql/Time; - java/io/IOException
 method public,synchronized write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/sql/Time;)V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/TypeAdapterRuntimeTypeWrapper 49 final,super org/spongepowered/include/com/google/gson/TypeAdapter - <T:Ljava/lang/Object;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>;
 inner org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory$Adapter org/spongepowered/include/com/google/gson/internal/bind/ReflectiveTypeAdapterFactory Adapter public,static,final
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Object; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)TT; java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Object;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;TT;)V java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/TypeAdapters 49 public,final,super java/lang/Object - -
 inner org/spongepowered/include/com/google/gson/internal/bind/TypeAdapters$EnumTypeAdapter org/spongepowered/include/com/google/gson/internal/bind/TypeAdapters EnumTypeAdapter private,static,final
 field public,static,final CLASS Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Class;>;
 field public,static,final CLASS_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final BIT_SET Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/util/BitSet;>;
 field public,static,final BIT_SET_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final BOOLEAN Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Boolean;>;
 field public,static,final BOOLEAN_AS_STRING Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Boolean;>;
 field public,static,final BOOLEAN_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final BYTE Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Number;>;
 field public,static,final BYTE_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final SHORT Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Number;>;
 field public,static,final SHORT_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final INTEGER Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Number;>;
 field public,static,final INTEGER_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final LONG Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Number;>;
 field public,static,final FLOAT Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Number;>;
 field public,static,final DOUBLE Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Number;>;
 field public,static,final NUMBER Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Number;>;
 field public,static,final NUMBER_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final CHARACTER Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/Character;>;
 field public,static,final CHARACTER_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final STRING Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/String;>;
 field public,static,final BIG_DECIMAL Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/math/BigDecimal;>;
 field public,static,final BIG_INTEGER Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/math/BigInteger;>;
 field public,static,final STRING_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final STRING_BUILDER Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/StringBuilder;>;
 field public,static,final STRING_BUILDER_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final STRING_BUFFER Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/lang/StringBuffer;>;
 field public,static,final STRING_BUFFER_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final URL Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/net/URL;>;
 field public,static,final URL_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final URI Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/net/URI;>;
 field public,static,final URI_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final INET_ADDRESS Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/net/InetAddress;>;
 field public,static,final INET_ADDRESS_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final UUID Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/util/UUID;>;
 field public,static,final UUID_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final TIMESTAMP_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final CALENDAR Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/util/Calendar;>;
 field public,static,final CALENDAR_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final LOCALE Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Ljava/util/Locale;>;
 field public,static,final LOCALE_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final JSON_ELEMENT Lorg/spongepowered/include/com/google/gson/TypeAdapter; Lorg/spongepowered/include/com/google/gson/TypeAdapter<Lorg/spongepowered/include/com/google/gson/JsonElement;>;
 field public,static,final JSON_ELEMENT_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 field public,static,final ENUM_FACTORY Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public,static newEnumTypeHierarchyFactory ()Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; - -
 method public,static newFactory (Ljava/lang/Class;Lorg/spongepowered/include/com/google/gson/TypeAdapter;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; <TT:Ljava/lang/Object;>(Ljava/lang/Class<TTT;>;Lorg/spongepowered/include/com/google/gson/TypeAdapter<TTT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public,static newFactory (Ljava/lang/Class;Ljava/lang/Class;Lorg/spongepowered/include/com/google/gson/TypeAdapter;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; <TT:Ljava/lang/Object;>(Ljava/lang/Class<TTT;>;Ljava/lang/Class<TTT;>;Lorg/spongepowered/include/com/google/gson/TypeAdapter<-TTT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public,static newFactoryForMultipleTypes (Ljava/lang/Class;Ljava/lang/Class;Lorg/spongepowered/include/com/google/gson/TypeAdapter;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; <TT:Ljava/lang/Object;>(Ljava/lang/Class<TTT;>;Ljava/lang/Class<+TTT;>;Lorg/spongepowered/include/com/google/gson/TypeAdapter<-TTT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
 method public,static newTypeHierarchyFactory (Ljava/lang/Class;Lorg/spongepowered/include/com/google/gson/TypeAdapter;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; <TT:Ljava/lang/Object;>(Ljava/lang/Class<TTT;>;Lorg/spongepowered/include/com/google/gson/TypeAdapter<TTT;>;)Lorg/spongepowered/include/com/google/gson/TypeAdapterFactory; -
in 1181
class org/spongepowered/include/com/google/gson/internal/bind/TypeAdapters$EnumTypeAdapter 49 final,super org/spongepowered/include/com/google/gson/TypeAdapter - <T:Ljava/lang/Enum<TT;>;>Lorg/spongepowered/include/com/google/gson/TypeAdapter<TT;>;
 inner org/spongepowered/include/com/google/gson/internal/bind/TypeAdapters$EnumTypeAdapter org/spongepowered/include/com/google/gson/internal/bind/TypeAdapters EnumTypeAdapter private,static,final
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<TT;>;)V -
 method public read (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)Ljava/lang/Enum; (Lorg/spongepowered/include/com/google/gson/stream/JsonReader;)TT; java/io/IOException
 method public write (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;Ljava/lang/Enum;)V (Lorg/spongepowered/include/com/google/gson/stream/JsonWriter;TT;)V java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/reflect/TypeToken 49 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method protected <init> ()V - -
 method public,final getRawType ()Ljava/lang/Class; ()Ljava/lang/Class<-TT;>; -
 method public,final getType ()Ljava/lang/reflect/Type; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public,final toString ()Ljava/lang/String; - -
 method public,static get (Ljava/lang/reflect/Type;)Lorg/spongepowered/include/com/google/gson/reflect/TypeToken; (Ljava/lang/reflect/Type;)Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<*>; -
 method public,static get (Ljava/lang/Class;)Lorg/spongepowered/include/com/google/gson/reflect/TypeToken; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Lorg/spongepowered/include/com/google/gson/reflect/TypeToken<TT;>; -
in 1181
class org/spongepowered/include/com/google/gson/stream/JsonReader 49 public,super java/lang/Object java/io/Closeable -
 method public <init> (Ljava/io/Reader;)V - -
 method public,final setLenient (Z)V - -
 method public,final isLenient ()Z - -
 method public beginArray ()V - java/io/IOException
 method public endArray ()V - java/io/IOException
 method public beginObject ()V - java/io/IOException
 method public endObject ()V - java/io/IOException
 method public hasNext ()Z - java/io/IOException
 method public peek ()Lorg/spongepowered/include/com/google/gson/stream/JsonToken; - java/io/IOException
 method public nextName ()Ljava/lang/String; - java/io/IOException
 method public nextString ()Ljava/lang/String; - java/io/IOException
 method public nextBoolean ()Z - java/io/IOException
 method public nextNull ()V - java/io/IOException
 method public nextDouble ()D - java/io/IOException
 method public nextLong ()J - java/io/IOException
 method public nextInt ()I - java/io/IOException
 method public close ()V - java/io/IOException
 method public skipValue ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 1181
class org/spongepowered/include/com/google/gson/stream/JsonToken 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/include/com/google/gson/stream/JsonToken;>;
 field public,static,final,enum BEGIN_ARRAY Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum END_ARRAY Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum BEGIN_OBJECT Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum END_OBJECT Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum NAME Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum STRING Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum NUMBER Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum BOOLEAN Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum NULL Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 field public,static,final,enum END_DOCUMENT Lorg/spongepowered/include/com/google/gson/stream/JsonToken; -
 method public,static values ()[Lorg/spongepowered/include/com/google/gson/stream/JsonToken; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/include/com/google/gson/stream/JsonToken; - -
in 1181
class org/spongepowered/include/com/google/gson/stream/JsonWriter 49 public,super java/lang/Object java/io/Closeable,java/io/Flushable -
 method public <init> (Ljava/io/Writer;)V - -
 method public,final setIndent (Ljava/lang/String;)V - -
 method public,final setLenient (Z)V - -
 method public isLenient ()Z - -
 method public,final setHtmlSafe (Z)V - -
 method public,final isHtmlSafe ()Z - -
 method public,final setSerializeNulls (Z)V - -
 method public,final getSerializeNulls ()Z - -
 method public beginArray ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public endArray ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public beginObject ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public endObject ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public name (Ljava/lang/String;)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (Ljava/lang/String;)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public nullValue ()Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (Z)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (J)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public value (Ljava/lang/Number;)Lorg/spongepowered/include/com/google/gson/stream/JsonWriter; - java/io/IOException
 method public flush ()V - java/io/IOException
 method public close ()V - java/io/IOException
in 1181
class org/spongepowered/include/com/google/gson/stream/MalformedJsonException 49 public,final,super java/io/IOException - -
 method public <init> (Ljava/lang/String;)V - -
in 22
class org/spongepowered/tools/agent/MixinAgent 50 public,super java/lang/Object org/spongepowered/asm/mixin/transformer/ext/IHotSwap -
 inner org/spongepowered/tools/agent/MixinAgent$Transformer org/spongepowered/tools/agent/MixinAgent Transformer -
 field public,static,final ERROR_BYTECODE [B -
 method public <init> (Lorg/spongepowered/asm/mixin/transformer/IMixinTransformer;)V - -
 method public registerMixinClass (Ljava/lang/String;)V - -
 method public registerTargetClass (Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;)V - -
 method public,static init (Ljava/lang/instrument/Instrumentation;)V - -
 method public,static premain (Ljava/lang/String;Ljava/lang/instrument/Instrumentation;)V - -
 method public,static agentmain (Ljava/lang/String;Ljava/lang/instrument/Instrumentation;)V - -
in 22
class org/spongepowered/tools/agent/MixinAgent$Transformer 50 super java/lang/Object java/lang/instrument/ClassFileTransformer -
 inner org/spongepowered/tools/agent/MixinAgent$Transformer org/spongepowered/tools/agent/MixinAgent Transformer -
 method public transform (Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/Class;Ljava/security/ProtectionDomain;[B)[B (Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/Class<*>;Ljava/security/ProtectionDomain;[B)[B java/lang/instrument/IllegalClassFormatException
in 22
class org/spongepowered/tools/agent/MixinAgentClassLoader 50 super java/lang/ClassLoader - -
 inner org/spongepowered/asm/mixin/MixinEnvironment$CompatibilityLevel org/spongepowered/asm/mixin/MixinEnvironment CompatibilityLevel public,static,enum
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixin 50 super java/lang/Object org/spongepowered/asm/mixin/refmap/IMixinContext,org/spongepowered/asm/util/asm/IAnnotatedElement -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass org/spongepowered/tools/obfuscation/interfaces/IMixinValidator ValidationPass public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementInjector static
 inner org/spongepowered/asm/mixin/MixinEnvironment$Option org/spongepowered/asm/mixin/MixinEnvironment Option public,static,final,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite AnnotatedElementOverwrite static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadowField -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadowMethod -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementInjectionPoint static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementSliceInjectionPoint org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementSliceInjectionPoint static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor AnnotatedElementAccessor static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor AnnotatedElementInvoker static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadow static,abstract
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;Ljavax/lang/model/element/TypeElement;)V - -
 method public toString ()Ljava/lang/String; - -
 method public getAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getMixinElement ()Ljavax/lang/model/element/TypeElement; - -
 method public getHandle ()Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public getClassRef ()Ljava/lang/String; - -
 method public isInterface ()Z - -
 method public,deprecated getPrimaryTarget ()Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public getTargets ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>; -
 method public isMultiTarget ()Z - -
 method public remap ()Z - -
 method public getMappings ()Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer; - -
 method public registerOverwrite (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public registerShadow (Ljavax/lang/model/element/VariableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public registerShadow (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public registerInjector (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/struct/InjectorRemap;)V - -
 method public registerInjectionPoint (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/struct/InjectorRemap;Ljava/lang/String;)V - -
 method public registerSliceInjectionPoint (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/struct/InjectorRemap;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)V - -
 method public registerAccessor (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public registerInvoker (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public registerSoftImplements (Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public getReferenceMapper ()Lorg/spongepowered/asm/mixin/refmap/ReferenceMapper; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getTargetClassRef ()Ljava/lang/String; - -
 method public getMixin ()Lorg/spongepowered/asm/mixin/extensibility/IMixinInfo; - -
 method public getExtensions ()Lorg/spongepowered/asm/mixin/transformer/ext/Extensions; - -
 method public getOption (Lorg/spongepowered/asm/mixin/MixinEnvironment$Option;)Z - -
 method public getPriority ()I - -
 method public getAnnotation (Ljava/lang/Class;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler 50 super,abstract java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler ShadowElementName static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AliasedElementName static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElementExecutable static,abstract
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElement static,abstract
 inner org/spongepowered/asm/util/ConstraintParser$Constraint org/spongepowered/asm/util/ConstraintParser Constraint public,static
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 field protected,final mixin Lorg/spongepowered/tools/obfuscation/AnnotatedMixin; -
 field protected,final classRef Ljava/lang/String; -
 field protected,final ap Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor; -
 field protected,final obf Lorg/spongepowered/tools/obfuscation/interfaces/IObfuscationManager; -
 method protected,final addFieldMappings (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;)V -
 method protected,final addFieldMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName;Ljava/lang/String;Ljava/lang/String;)V - -
 method protected,final addFieldMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method protected,final addMethodMappings (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
 method protected,final addMethodMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName;Ljava/lang/String;Ljava/lang/String;)V - -
 method protected,final addMethodMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method protected,final checkConstraints (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method protected,final validateTarget (Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName;Ljava/lang/String;)V - -
 method protected,final validateTargetMethod (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName;Ljava/lang/String;ZZ)V - -
 method protected,final validateTargetField (Ljavax/lang/model/element/VariableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName;Ljava/lang/String;)V - -
 method protected,final validateReferencedTarget (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Ljava/lang/String;)V - -
 method protected,static stripOwnerData (Lorg/spongepowered/tools/obfuscation/ObfuscationData;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T::Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TT;>;>(Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
 method protected,static stripDescriptors (Lorg/spongepowered/tools/obfuscation/ObfuscationData;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T::Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TT;>;>(Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName 50 super java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AliasedElementName static
 field protected,final originalName Ljava/lang/String; -
 method public <init> (Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public setCaseSensitive (Z)Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName; - -
 method public isCaseSensitive ()Z - -
 method public hasAliases ()Z - -
 method public getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public elementName ()Ljava/lang/String; - -
 method public baseName ()Ljava/lang/String; - -
 method public hasPrefix ()Z - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement 50 super,abstract java/lang/Object org/spongepowered/asm/util/asm/IAnnotatedElement <E::Ljavax/lang/model/element/Element;>Ljava/lang/Object;Lorg/spongepowered/asm/util/asm/IAnnotatedElement;
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElement static,abstract
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 field protected,final element Ljavax/lang/model/element/Element; TE;
 field protected,final annotation Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; -
 method public <init> (Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V (TE;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V -
 method public getElement ()Ljavax/lang/model/element/Element; ()TE; -
 method public getAnnotation ()Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; - -
 method public getSimpleName ()Ljava/lang/String; - -
 method public getDesc ()Ljava/lang/String; - -
 method public,final printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx;Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;)V - -
 method public,final printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerSuppressible;Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public getAnnotation (Ljava/lang/Class;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable 50 super,abstract org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement org/spongepowered/asm/mixin/injection/selectors/ISelectorContext Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement<Ljavax/lang/model/element/ExecutableElement;>;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElementExecutable static,abstract
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElement static,abstract
 method public <init> (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;)V - -
 method public getParent ()Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext; - -
 method public getMixin ()Lorg/spongepowered/asm/mixin/refmap/IMixinContext; - -
 method public getMethod ()Ljava/lang/Object; - -
 method public getSelectorAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getSelectorCoordinate (Z)Ljava/lang/String; - -
 method public remap (Ljava/lang/String;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler ShadowElementName static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AliasedElementName static
 method public toString ()Ljava/lang/String; - -
 method public baseName ()Ljava/lang/String; - -
 method public setObfuscatedName (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName; (Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName; -
 method public setObfuscatedName (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName; - -
 method public hasPrefix ()Z - -
 method public prefix ()Ljava/lang/String; - -
 method public name ()Ljava/lang/String; - -
 method public obfuscated ()Ljava/lang/String; - -
 method public prefix (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor AnnotatedElementInvoker static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor AnnotatedElementAccessor static
 inner org/spongepowered/tools/obfuscation/ReferenceManager$ReferenceConflictException org/spongepowered/tools/obfuscation/ReferenceManager ReferenceConflictException public,static
 inner org/spongepowered/tools/obfuscation/mirror/TypeUtils$EquivalencyResult org/spongepowered/tools/obfuscation/mirror/TypeUtils EquivalencyResult public,static
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType org/spongepowered/asm/mixin/gen/AccessorInfo AccessorType public,static,abstract,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner org/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency org/spongepowered/tools/obfuscation/mirror/TypeUtils Equivalency public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;Lorg/spongepowered/tools/obfuscation/AnnotatedMixin;)V - -
 method public registerAccessor (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor;)V - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor AnnotatedElementAccessor static
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType org/spongepowered/asm/mixin/gen/AccessorInfo AccessorType public,static,abstract,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElementExecutable static,abstract
 field protected,final shouldRemap Z -
 field protected,final returnType Ljavax/lang/model/type/TypeMirror; -
 field protected targetName Ljava/lang/String; -
 method public <init> (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Z)V - -
 method public attach (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)V - -
 method public shouldRemap ()Z - -
 method public getAnnotationValue ()Ljava/lang/String; - -
 method public getTargetType ()Ljavax/lang/model/type/TypeMirror; - -
 method public getTargetTypeName ()Ljava/lang/String; - -
 method public getTargetDesc ()Ljava/lang/String; - -
 method public getContext ()Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public getAccessorType ()Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; - -
 method public setTargetName (Ljava/lang/String;)V - -
 method public getTargetName ()Ljava/lang/String; - -
 method public getReturnType ()Ljavax/lang/model/type/TypeMirror; - -
 method public isStatic ()Z - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor - -
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType org/spongepowered/asm/mixin/gen/AccessorInfo AccessorType public,static,abstract,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementInvoker org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor AnnotatedElementInvoker static
 inner org/spongepowered/asm/mixin/gen/AccessorInfo$AccessorName org/spongepowered/asm/mixin/gen/AccessorInfo AccessorName public,static,final
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor$AnnotatedElementAccessor org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerAccessor AnnotatedElementAccessor static
 method public <init> (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Z)V - -
 method public attach (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)V - -
 method public shouldRemap ()Z - -
 method public getTargetDesc ()Ljava/lang/String; - -
 method public getAccessorType ()Lorg/spongepowered/asm/mixin/gen/AccessorInfo$AccessorType; - -
 method public getTargetTypeName ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementSliceInjectionPoint org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementSliceInjectionPoint static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementInjectionPoint static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementInjector static
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner org/spongepowered/tools/obfuscation/ReferenceManager$ReferenceConflictException org/spongepowered/tools/obfuscation/ReferenceManager ReferenceConflictException public,static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElementExecutable static,abstract
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor CompilerEnvironment public,static,enum
 method public registerInjector (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector;)V - -
 method public registerInjectionPoint (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint;Ljava/lang/String;)V - -
 method protected,final remapNewTarget (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint;)V - -
 method protected,final remapReference (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelector;Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint;)V - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementInjectionPoint static
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor CompilerEnvironment public,static,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElementExecutable static,abstract
 method public <init> (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/struct/InjectorRemap;)V - -
 method public shouldRemap ()Z - -
 method public getAt ()Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; - -
 method public getAtErrorElement (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment;)Ljavax/lang/model/element/AnnotationMirror; - -
 method public getSelectorAnnotation ()Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getAtArg (Ljava/lang/String;)Ljava/lang/String; - -
 method public notifyRemapped ()V - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjector org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementInjector static
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElementExecutable org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElementExecutable static,abstract
 method public <init> (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Lorg/spongepowered/tools/obfuscation/struct/InjectorRemap;)V - -
 method public shouldRemap ()Z - -
 method public hasCoerceArgument ()Z - -
 method public addMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementSliceInjectionPoint 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementSliceInjectionPoint org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementSliceInjectionPoint static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector$AnnotatedElementInjectionPoint org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerInjector AnnotatedElementInjectionPoint static
 method public <init> (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/asm/mixin/refmap/IMixinContext;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Lorg/spongepowered/tools/obfuscation/struct/InjectorRemap;Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext;)V - -
 method public getParent ()Lorg/spongepowered/asm/mixin/injection/selectors/ISelectorContext; - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite AnnotatedElementOverwrite static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AliasedElementName static
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner org/spongepowered/tools/obfuscation/Mappings$MappingConflictException org/spongepowered/tools/obfuscation/Mappings MappingConflictException public,static
 method public registerMerge (Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle;)V - -
 method public registerOverwrite (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite;)V - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement - Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement<Ljavax/lang/model/element/ExecutableElement;>;
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite$AnnotatedElementOverwrite org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerOverwrite AnnotatedElementOverwrite static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElement static,abstract
 method public <init> (Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public shouldRemap ()Z - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler - -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadowMethod -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadowField -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadow static,abstract
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner org/spongepowered/tools/obfuscation/Mappings$MappingConflictException org/spongepowered/tools/obfuscation/Mappings MappingConflictException public,static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler ShadowElementName static
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AliasedElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AliasedElementName static
 method public registerShadow (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow;)V (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<**>;)V -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow 50 super,abstract org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement - <E::Ljavax/lang/model/element/Element;M::Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TM;>;>Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement<TE;>;
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler ShadowElementName static
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadow static,abstract
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$AnnotatedElement org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler AnnotatedElement static,abstract
 method protected <init> (Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;ZLorg/spongepowered/asm/obfuscation/mapping/IMapping$Type;)V (TE;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;ZLorg/spongepowered/asm/obfuscation/mapping/IMapping$Type;)V -
 method public shouldRemap ()Z - -
 method public getName ()Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName; - -
 method public getElementType ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping$Type; - -
 method public toString ()Ljava/lang/String; - -
 method public setObfuscatedName (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName; (Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName; -
 method public setObfuscatedName (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName; - -
 method public getObfuscationData (Lorg/spongepowered/tools/obfuscation/interfaces/IObfuscationDataProvider;Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/tools/obfuscation/interfaces/IObfuscationDataProvider;Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TM;>; -
 method public,abstract getMapping (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/IMapping; (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;)TM; -
 method public,abstract addMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)V (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)V -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow - Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<Ljavax/lang/model/element/VariableElement;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowField org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadowField -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadow static,abstract
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler ShadowElementName static
 method public <init> (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow;Ljavax/lang/model/element/VariableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public getMapping (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public addMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)V (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)V -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow - Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow<Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadowMethod org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadowMethod -
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow$AnnotatedElementShadow org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow AnnotatedElementShadow static,abstract
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 inner org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler$ShadowElementName org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler ShadowElementName static
 method public <init> (Lorg/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerShadow;Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Z)V - -
 method public getMapping (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public addMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)V (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)V -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandlerSoftImplements 50 super org/spongepowered/tools/obfuscation/AnnotatedMixinElementHandler - -
 inner org/spongepowered/asm/mixin/Interface$Remap org/spongepowered/asm/mixin/Interface Remap public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public process (Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
in 22
class org/spongepowered/tools/obfuscation/AnnotatedMixins 50 final,super java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor,org/spongepowered/asm/util/ITokenProvider,org/spongepowered/tools/obfuscation/interfaces/ITypeHandleProvider,org/spongepowered/tools/obfuscation/interfaces/IJavadocProvider -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor CompilerEnvironment public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass org/spongepowered/tools/obfuscation/interfaces/IMixinValidator ValidationPass public,static,final,enum
 inner javax/tools/JavaFileManager$Location javax/tools/JavaFileManager Location public,static,interface,abstract
 method protected initTargetMap ()Lorg/spongepowered/tools/obfuscation/TargetMap; - -
 method public getTypeProvider ()Lorg/spongepowered/tools/obfuscation/interfaces/ITypeHandleProvider; - -
 method public getTokenProvider ()Lorg/spongepowered/asm/util/ITokenProvider; - -
 method public getObfuscationManager ()Lorg/spongepowered/tools/obfuscation/interfaces/IObfuscationManager; - -
 method public getJavadocProvider ()Lorg/spongepowered/tools/obfuscation/interfaces/IJavadocProvider; - -
 method public getProcessingEnvironment ()Ljavax/annotation/processing/ProcessingEnvironment; - -
 method public getCompilerEnvironment ()Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; - -
 method public getToken (Ljava/lang/String;)Ljava/lang/Integer; - -
 method public getOption (Ljava/lang/String;)Ljava/lang/String; - -
 method public getOption (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public getOption (Ljava/lang/String;Z)Z - -
 method public getOptions (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public getProperties ()Ljava/util/Properties; - -
 method public writeMappings ()V - -
 method public writeReferences ()V - -
 method public clear ()V - -
 method public registerMixin (Ljavax/lang/model/element/TypeElement;)V - -
 method public getMixin (Ljavax/lang/model/element/TypeElement;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixin; - -
 method public getMixin (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixin; - -
 method public getMixinsTargeting (Ljavax/lang/model/type/TypeMirror;)Ljava/util/Collection; (Ljavax/lang/model/type/TypeMirror;)Ljava/util/Collection<Ljavax/lang/model/type/TypeMirror;>; -
 method public getMixinsTargeting (Ljavax/lang/model/element/TypeElement;)Ljava/util/Collection; (Ljavax/lang/model/element/TypeElement;)Ljava/util/Collection<Ljavax/lang/model/type/TypeMirror;>; -
 method public registerAccessor (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;)V - -
 method public registerInvoker (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;)V - -
 method public registerOverwrite (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;)V - -
 method public registerShadow (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/VariableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public registerShadow (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public registerInjector (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/ExecutableElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public registerSoftImplements (Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public onPassStarted ()V - -
 method public onPassCompleted (Ljavax/annotation/processing/RoundEnvironment;)V - -
 method public printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;)V - -
 method public printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
 method public printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public getTypeHandle (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public getTypeHandle (Ljava/lang/Object;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public getTypeElement (Ljava/lang/String;)Ljavax/lang/model/element/TypeElement; - -
 method public getSimulatedHandle (Ljava/lang/String;Ljavax/lang/model/type/TypeMirror;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public getJavadoc (Ljavax/lang/model/element/Element;)Ljava/lang/String; - -
 method public,static getMixinsForEnvironment (Ljavax/annotation/processing/ProcessingEnvironment;)Lorg/spongepowered/tools/obfuscation/AnnotatedMixins; - -
in 22
class org/spongepowered/tools/obfuscation/Mappings 50 super java/lang/Object org/spongepowered/tools/obfuscation/mapping/IMappingConsumer -
 inner org/spongepowered/tools/obfuscation/Mappings$UniqueMappings org/spongepowered/tools/obfuscation/Mappings UniqueMappings static
 inner org/spongepowered/tools/obfuscation/Mappings$MappingConflictException org/spongepowered/tools/obfuscation/Mappings MappingConflictException public,static
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet Pair public,static
 method public <init> ()V - -
 method public asUnique ()Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer; - -
 method public getFieldMappings (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet; (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public getMethodMappings (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet; (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public clear ()V - -
 method public addFieldMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)V - -
 method public addMethodMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)V - -
in 22
class org/spongepowered/tools/obfuscation/Mappings$MappingConflictException 50 public,super java/lang/RuntimeException - -
 inner org/spongepowered/tools/obfuscation/Mappings$MappingConflictException org/spongepowered/tools/obfuscation/Mappings MappingConflictException public,static
 method public <init> (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)V (Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>;)V -
 method public getOld ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping; ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>; -
 method public getNew ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping; ()Lorg/spongepowered/asm/obfuscation/mapping/IMapping<*>; -
in 22
class org/spongepowered/tools/obfuscation/Mappings$UniqueMappings 50 super java/lang/Object org/spongepowered/tools/obfuscation/mapping/IMappingConsumer -
 inner org/spongepowered/tools/obfuscation/Mappings$UniqueMappings org/spongepowered/tools/obfuscation/Mappings UniqueMappings static
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 inner org/spongepowered/tools/obfuscation/Mappings$MappingConflictException org/spongepowered/tools/obfuscation/Mappings MappingConflictException public,static
 method public <init> (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer;)V - -
 method public clear ()V - -
 method protected clearMaps ()V - -
 method public addFieldMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)V - -
 method public addMethodMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)V - -
 method public getFieldMappings (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet; (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public getMethodMappings (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet; (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
in 22
class org/spongepowered/tools/obfuscation/MixinObfuscationProcessor 50 super,abstract javax/annotation/processing/AbstractProcessor - -
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 field protected mixins Lorg/spongepowered/tools/obfuscation/AnnotatedMixins; -
 method public,synchronized init (Ljavax/annotation/processing/ProcessingEnvironment;)V - -
 method protected processMixins (Ljavax/annotation/processing/RoundEnvironment;)V - -
 method protected postProcess (Ljavax/annotation/processing/RoundEnvironment;)V - -
 method public getSupportedSourceVersion ()Ljavax/lang/model/SourceVersion; - -
 method public getSupportedOptions ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
in 22
class org/spongepowered/tools/obfuscation/MixinObfuscationProcessorInjection 50 public,super org/spongepowered/tools/obfuscation/MixinObfuscationProcessor - -
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public <init> ()V - -
 method public getSupportedAnnotationTypes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public process (Ljava/util/Set;Ljavax/annotation/processing/RoundEnvironment;)Z (Ljava/util/Set<+Ljavax/lang/model/element/TypeElement;>;Ljavax/annotation/processing/RoundEnvironment;)Z -
 method protected postProcess (Ljavax/annotation/processing/RoundEnvironment;)V - -
in 22
class org/spongepowered/tools/obfuscation/MixinObfuscationProcessorTargets 50 public,super org/spongepowered/tools/obfuscation/MixinObfuscationProcessor - -
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public <init> ()V - -
 method public process (Ljava/util/Set;Ljavax/annotation/processing/RoundEnvironment;)Z (Ljava/util/Set<+Ljavax/lang/model/element/TypeElement;>;Ljavax/annotation/processing/RoundEnvironment;)Z -
 method protected postProcess (Ljavax/annotation/processing/RoundEnvironment;)V - -
in 22
class org/spongepowered/tools/obfuscation/MixinValidator 50 public,super,abstract java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IMixinValidator -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass org/spongepowered/tools/obfuscation/interfaces/IMixinValidator ValidationPass public,static,final,enum
 field protected,final processingEnv Ljavax/annotation/processing/ProcessingEnvironment; -
 field protected,final messager Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerSuppressible; -
 field protected,final options Lorg/spongepowered/tools/obfuscation/interfaces/IOptionProvider; -
 field protected,final pass Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass; -
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass;)V - -
 method public,final validate (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass;Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection;)Z (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass;Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>;)Z -
 method protected,abstract validate (Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection;)Z (Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>;)Z -
 method protected,final getMixinsTargeting (Ljavax/lang/model/type/TypeMirror;)Ljava/util/Collection; (Ljavax/lang/model/type/TypeMirror;)Ljava/util/Collection<Ljavax/lang/model/type/TypeMirror;>; -
in 22
class org/spongepowered/tools/obfuscation/ObfuscationData 50 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lorg/spongepowered/tools/obfuscation/ObfuscationType;>;
 method public <init> ()V - -
 method public <init> (Ljava/lang/Object;)V (TT;)V -
 method public,deprecated add (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Ljava/lang/Object;)V (Lorg/spongepowered/tools/obfuscation/ObfuscationType;TT;)V -
 method public put (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Ljava/lang/Object;)V (Lorg/spongepowered/tools/obfuscation/ObfuscationType;TT;)V -
 method public isEmpty ()Z - -
 method public get (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Ljava/lang/Object; (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)TT; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lorg/spongepowered/tools/obfuscation/ObfuscationType;>; -
 method public toString ()Ljava/lang/String; - -
 method public values ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/ObfuscationDataProvider 50 public,super java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IObfuscationDataProvider -
 inner org/spongepowered/asm/obfuscation/mapping/IMapping$Type org/spongepowered/asm/obfuscation/mapping/IMapping Type public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;Ljava/util/List;)V (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;Ljava/util/List<Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment;>;)V -
 method public getObfEntryRecursive (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
 method public getObfEntry (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
 method public getObfEntry (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TT;>;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
 method public getObfMethodRecursive (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public getObfMethod (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public getRemappedMethod (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public getObfMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public getRemappedMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public remapDescriptor (Lorg/spongepowered/tools/obfuscation/ObfuscationData;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public getObfFieldRecursive (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public getObfField (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public getObfField (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public getObfClass (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Ljava/lang/String;>; -
 method public getObfClass (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Ljava/lang/String;>; -
in 22
class org/spongepowered/tools/obfuscation/ObfuscationEnvironment 50 public,super,abstract java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IObfuscationEnvironment -
 inner org/spongepowered/tools/obfuscation/ObfuscationEnvironment$RemapperProxy org/spongepowered/tools/obfuscation/ObfuscationEnvironment RemapperProxy final
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper org/spongepowered/asm/util/ObfuscationUtil IClassRemapper public,static,interface,abstract
 field protected,final type Lorg/spongepowered/tools/obfuscation/ObfuscationType; -
 field protected,final mappingProvider Lorg/spongepowered/tools/obfuscation/mapping/IMappingProvider; -
 field protected,final mappingWriter Lorg/spongepowered/tools/obfuscation/mapping/IMappingWriter; -
 field protected,final remapper Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment$RemapperProxy; -
 field protected,final ap Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor; -
 field protected,final outFileName Ljava/lang/String; -
 field protected,final inFileNames Ljava/util/List; Ljava/util/List<Ljava/lang/String;>;
 method protected <init> (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)V - -
 method public toString ()Ljava/lang/String; - -
 method protected,abstract getMappingProvider (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingProvider; - -
 method protected,abstract getMappingWriter (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingWriter; - -
 method public getType ()Lorg/spongepowered/tools/obfuscation/ObfuscationType; - -
 method public getObfMethod (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public getObfMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public getObfMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Z)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public remapDescriptor (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public remapDescriptor (Ljava/lang/String;)Ljava/lang/String; - -
 method public getObfField (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public getObfField (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public getObfField (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;Z)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public getObfClass (Ljava/lang/String;)Ljava/lang/String; - -
 method public writeMappings (Ljava/util/Collection;)V (Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer;>;)V -
in 22
class org/spongepowered/tools/obfuscation/ObfuscationEnvironment$RemapperProxy 50 final,super java/lang/Object org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper -
 inner org/spongepowered/tools/obfuscation/ObfuscationEnvironment$RemapperProxy org/spongepowered/tools/obfuscation/ObfuscationEnvironment RemapperProxy final
 inner org/spongepowered/asm/util/ObfuscationUtil$IClassRemapper org/spongepowered/asm/util/ObfuscationUtil IClassRemapper public,static,interface,abstract
 method public map (Ljava/lang/String;)Ljava/lang/String; - -
 method public unmap (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/ObfuscationManager 50 public,super java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IObfuscationManager -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor CompilerEnvironment public,static,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)V - -
 method public init ()V - -
 method public getDataProvider ()Lorg/spongepowered/tools/obfuscation/interfaces/IObfuscationDataProvider; - -
 method public getReferenceManager ()Lorg/spongepowered/tools/obfuscation/interfaces/IReferenceManager; - -
 method public createMappingConsumer ()Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer; - -
 method public getEnvironments ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment;>; -
 method public writeMappings ()V - -
 method public writeReferences ()V - -
in 22
class org/spongepowered/tools/obfuscation/ObfuscationType 50 public,final,super java/lang/Object - -
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 field public,static,final DEFAULT_TYPE Ljava/lang/String; - "searge"
 method public,final createEnvironment ()Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment; - -
 method public toString ()Ljava/lang/String; - -
 method public getKey ()Ljava/lang/String; - -
 method public getConfig ()Lorg/spongepowered/tools/obfuscation/service/ObfuscationTypeDescriptor; - -
 method public getAnnotationProcessor ()Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor; - -
 method public isDefault ()Z - -
 method public isSupported ()Z - -
 method public getInputFileNames ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getOutputFileName ()Ljava/lang/String; - -
 method public,static types ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lorg/spongepowered/tools/obfuscation/ObfuscationType;>; -
 method public,static create (Lorg/spongepowered/tools/obfuscation/service/ObfuscationTypeDescriptor;Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Lorg/spongepowered/tools/obfuscation/ObfuscationType; - -
 method public,static get (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/ObfuscationType; - -
in 22
class org/spongepowered/tools/obfuscation/ReferenceManager 50 public,super java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IReferenceManager -
 inner org/spongepowered/tools/obfuscation/ReferenceManager$ReferenceConflictException org/spongepowered/tools/obfuscation/ReferenceManager ReferenceConflictException public,static
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner javax/tools/JavaFileManager$Location javax/tools/JavaFileManager Location public,static,interface,abstract
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;Ljava/util/List;)V (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;Ljava/util/List<Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment;>;)V -
 method public getAllowConflicts ()Z - -
 method public setAllowConflicts (Z)V - -
 method public write ()V - -
 method public getMapper ()Lorg/spongepowered/asm/mixin/refmap/ReferenceMapper; - -
 method public addMethodMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
 method public addMethodMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
 method public addFieldMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;)V -
 method public addClassMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Ljava/lang/String;>;)V -
 method protected addMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
in 22
class org/spongepowered/tools/obfuscation/ReferenceManager$ReferenceConflictException 50 public,super java/lang/RuntimeException - -
 inner org/spongepowered/tools/obfuscation/ReferenceManager$ReferenceConflictException org/spongepowered/tools/obfuscation/ReferenceManager ReferenceConflictException public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public getOld ()Ljava/lang/String; - -
 method public getNew ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/SupportedOptions 50 public,final,super java/lang/Object - -
 inner com/google/common/collect/ImmutableSet$Builder com/google/common/collect/ImmutableSet Builder public,static
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 field public,static,final TOKENS Ljava/lang/String; - "tokens"
 field public,static,final OUT_REFMAP_FILE Ljava/lang/String; - "outRefMapFile"
 field public,static,final DISABLE_TARGET_VALIDATOR Ljava/lang/String; - "disableTargetValidator"
 field public,static,final DISABLE_TARGET_EXPORT Ljava/lang/String; - "disableTargetExport"
 field public,static,final DISABLE_OVERWRITE_CHECKER Ljava/lang/String; - "disableOverwriteChecker"
 field public,static,final OVERWRITE_ERROR_LEVEL Ljava/lang/String; - "overwriteErrorLevel"
 field public,static,final DEFAULT_OBFUSCATION_ENV Ljava/lang/String; - "defaultObfuscationEnv"
 field public,static,final DEPENDENCY_TARGETS_FILE Ljava/lang/String; - "dependencyTargetsFile"
 field public,static,final MAPPING_TYPES Ljava/lang/String; - "mappingTypes"
 field public,static,final PLUGIN_VERSION Ljava/lang/String; - "pluginVersion"
 field public,static,final QUIET Ljava/lang/String; - "quiet"
 field public,static,final SHOW_MESSAGE_TYPES Ljava/lang/String; - "showMessageTypes"
 method public,static getAllOptions ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
in 22
class org/spongepowered/tools/obfuscation/SuppressedBy 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/tools/obfuscation/SuppressedBy;>;
 field public,static,final,enum CONSTRAINTS Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum VISIBILITY Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum TARGET Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum MAPPING Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum OVERWRITE Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum DEFAULT_PACKAGE Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum PUBLIC_TARGET Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum UNRESOLVABLE_TARGET Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 field public,static,final,enum RAW_TYPES Lorg/spongepowered/tools/obfuscation/SuppressedBy; -
 method public,static values ()[Lorg/spongepowered/tools/obfuscation/SuppressedBy; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/SuppressedBy; - -
 method public getToken ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/TargetMap 50 public,final,super java/util/HashMap - Ljava/util/HashMap<Lorg/spongepowered/tools/obfuscation/mirror/TypeReference;Ljava/util/Set<Lorg/spongepowered/tools/obfuscation/mirror/TypeReference;>;>;
 method public getSessionId ()Ljava/lang/String; - -
 method public readImports (Ljava/io/File;)V - java/io/IOException
 method public write (Z)V - -
 method public,static create (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/TargetMap; - -
in 22
class org/spongepowered/tools/obfuscation/ext/SpecialPackages 50 public,final,super java/lang/Object - -
 method public,static,final addExcludedPackage (Ljava/lang/String;)V - -
 method public,static isExcludedPackage (Ljava/lang/String;)Z - -
in 22
class org/spongepowered/tools/obfuscation/fg3/ObfuscationEnvironmentFG3 50 public,super org/spongepowered/tools/obfuscation/ObfuscationEnvironment - -
 method protected <init> (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)V - -
 method protected getMappingProvider (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingProvider; - -
 method protected getMappingWriter (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingWriter; - -
in 22
class org/spongepowered/tools/obfuscation/fg3/ObfuscationServiceFG3 50 public,super java/lang/Object org/spongepowered/tools/obfuscation/service/IObfuscationService -
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 field public,static,final SEARGE Ljava/lang/String; - "searge"
 field public,static,final REOBF_TSRG_FILE Ljava/lang/String; - "reobfTsrgFile"
 field public,static,final REOBF_EXTRA_TSRG_FILES Ljava/lang/String; - "reobfTsrgFiles"
 field public,static,final OUT_TSRG_SRG_FILE Ljava/lang/String; - "outTsrgFile"
 field public,static,final TSRG_OUTPUT_BEHAVIOUR Ljava/lang/String; - "mergeBehaviour"
 method public <init> ()V - -
 method public getSupportedOptions ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getObfuscationTypes (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Ljava/util/Collection; (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/service/ObfuscationTypeDescriptor;>; -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IJavadocProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract getJavadoc (Ljavax/lang/model/element/Element;)Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IMessagerEx 50 public,interface,abstract java/lang/Object javax/annotation/processing/Messager -
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public,abstract printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;)V - -
 method public,abstract printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public,abstract printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public,abstract printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;>;
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor CompilerEnvironment public,static,enum
 field public,static,final,enum INFO Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NOTE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ERROR Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum WARNING Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MIXIN_ON_INVALID_TYPE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MIXIN_SOFT_TARGET_NOT_FOUND Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MIXIN_SOFT_TARGET_NOT_RESOLVED Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MIXIN_SOFT_TARGET_IS_PUBLIC Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MIXIN_NO_TARGETS Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum PARENT_VALIDATOR Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum TARGET_VALIDATOR Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ACCESSOR_ATTACH_ERROR Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ACCESSOR_TARGET_NOT_FOUND Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ACCESSOR_TYPE_UNSUPPORTED Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ACCESSOR_NAME_UNRESOLVED Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum INVOKER_RAW_RETURN_TYPE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum FACTORY_INVOKER_GENERIC_ARGS Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum FACTORY_INVOKER_RETURN_TYPE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum FACTORY_INVOKER_NONSTATIC Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum CONSTRAINT_VIOLATION Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum INVALID_CONSTRAINT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ACCESSOR_MAPPING_CONFLICT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum INJECTOR_MAPPING_CONFLICT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum OVERWRITE_MAPPING_CONFLICT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum SHADOW_MAPPING_CONFLICT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum INJECTOR_IN_INTERFACE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum INJECTOR_ON_NON_METHOD_ELEMENT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum OVERWRITE_ON_NON_METHOD_ELEMENT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ACCESSOR_ON_NON_METHOD_ELEMENT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum SHADOW_ON_INVALID_ELEMENT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum INJECTOR_ON_NON_MIXIN_METHOD Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum OVERWRITE_ON_NON_MIXIN_METHOD Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum ACCESSOR_ON_NON_MIXIN_METHOD Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum SHADOW_ON_NON_MIXIN_ELEMENT Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum SOFT_IMPLEMENTS_ON_INVALID_TYPE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum SOFT_IMPLEMENTS_ON_NON_MIXIN Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum SOFT_IMPLEMENTS_EMPTY Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum TARGET_SELECTOR_VALIDATION Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum INJECTOR_TARGET_NOT_FULLY_QUALIFIED Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MISSING_INJECTOR_DESC_MULTITARGET Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MISSING_INJECTOR_DESC_SINGLETARGET Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum MISSING_INJECTOR_DESC_SIMULATED Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum TARGET_ELEMENT_NOT_FOUND Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum METHOD_VISIBILITY Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_ACCESSOR Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_CLASS Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_TARGET Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_CTOR Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_OVERWRITE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_STATIC_OVERWRITE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_FIELD Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_METHOD Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_SHADOW Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_SIMULATED_SHADOW Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum NO_OBFDATA_FOR_SOFT_IMPLEMENTS Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum BARE_REFERENCE Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 field public,static,final,enum OVERWRITE_DOCS Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; -
 method public,static values ()[Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType; - -
 method public isError ()Z - -
 method public getKind ()Ljavax/tools/Diagnostic$Kind; - -
 method public setKind (Ljavax/tools/Diagnostic$Kind;)V - -
 method public quench (Ljavax/tools/Diagnostic$Kind;)V - -
 method public isEnabled ()Z - -
 method public setEnabled (Z)V - -
 method public reset ()V - -
 method public decorate (Ljava/lang/CharSequence;)Ljava/lang/CharSequence; - -
 method public,static setDecoration (Z)V - -
 method public,static setPrefix (Ljava/lang/String;)V - -
 method public,static getSupportedOptions ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,static applyOptions (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment;Lorg/spongepowered/tools/obfuscation/interfaces/IOptionProvider;)V - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IMessagerSuppressible 50 public,interface,abstract java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IMessagerEx -
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public,abstract printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public,abstract printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public,abstract printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public,abstract printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public,abstract printMessage (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
 method public,abstract printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;Lorg/spongepowered/tools/obfuscation/SuppressedBy;)V - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor 50 public,interface,abstract java/lang/Object org/spongepowered/tools/obfuscation/interfaces/IMessagerSuppressible,org/spongepowered/tools/obfuscation/interfaces/IOptionProvider -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor CompilerEnvironment public,static,enum
 method public,abstract getCompilerEnvironment ()Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; - -
 method public,abstract getProcessingEnvironment ()Ljavax/annotation/processing/ProcessingEnvironment; - -
 method public,abstract getObfuscationManager ()Lorg/spongepowered/tools/obfuscation/interfaces/IObfuscationManager; - -
 method public,abstract getTokenProvider ()Lorg/spongepowered/asm/util/ITokenProvider; - -
 method public,abstract getTypeProvider ()Lorg/spongepowered/tools/obfuscation/interfaces/ITypeHandleProvider; - -
 method public,abstract getJavadocProvider ()Lorg/spongepowered/tools/obfuscation/interfaces/IJavadocProvider; - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment 50 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment;>;
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment org/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor CompilerEnvironment public,static,enum
 field public,static,final,enum JAVAC Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; -
 field public,static,final,enum JDT Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; -
 field public,static,final,enum IDEA Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; -
 method public,static values ()[Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; - -
 method public isCompiler ()Z - -
 method public isDevelopmentEnvironment ()Z - -
 method public getFriendlyName ()Ljava/lang/String; - -
 method protected isDetected (Ljavax/annotation/processing/ProcessingEnvironment;)Z - -
 method public,static detect (Ljavax/annotation/processing/ProcessingEnvironment;)Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor$CompilerEnvironment; - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IMixinValidator 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass org/spongepowered/tools/obfuscation/interfaces/IMixinValidator ValidationPass public,static,final,enum
 method public,abstract validate (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass;Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection;)Z (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass;Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>;)Z -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass;>;
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass org/spongepowered/tools/obfuscation/interfaces/IMixinValidator ValidationPass public,static,final,enum
 field public,static,final,enum EARLY Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass; -
 field public,static,final,enum LATE Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass; -
 field public,static,final,enum FINAL Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass; -
 method public,static values ()[Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass; - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IObfuscationDataProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract getObfEntryRecursive (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
 method public,abstract getObfEntry (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
 method public,abstract getObfEntry (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; <T:Ljava/lang/Object;>(Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TT;>;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<TT;>; -
 method public,abstract getObfMethodRecursive (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public,abstract getObfMethod (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public,abstract getRemappedMethod (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public,abstract getObfMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public,abstract getRemappedMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
 method public,abstract getObfFieldRecursive (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public,abstract getObfField (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public,abstract getObfField (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public,abstract getObfClass (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Ljava/lang/String;>; -
 method public,abstract getObfClass (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/ObfuscationData; (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/ObfuscationData<Ljava/lang/String;>; -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IObfuscationEnvironment 50 public,interface,abstract java/lang/Object - -
 method public,abstract getObfMethod (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public,abstract getObfMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public,abstract getObfMethod (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Z)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public,abstract getObfField (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public,abstract getObfField (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public,abstract getObfField (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;Z)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public,abstract getObfClass (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract remapDescriptor (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;)Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable; - -
 method public,abstract remapDescriptor (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract writeMappings (Ljava/util/Collection;)V (Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer;>;)V -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IObfuscationManager 50 public,interface,abstract java/lang/Object - -
 method public,abstract init ()V - -
 method public,abstract getDataProvider ()Lorg/spongepowered/tools/obfuscation/interfaces/IObfuscationDataProvider; - -
 method public,abstract getReferenceManager ()Lorg/spongepowered/tools/obfuscation/interfaces/IReferenceManager; - -
 method public,abstract createMappingConsumer ()Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer; - -
 method public,abstract getEnvironments ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment;>; -
 method public,abstract writeMappings ()V - -
 method public,abstract writeReferences ()V - -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IOptionProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract getOption (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOption (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getOption (Ljava/lang/String;Z)Z - -
 method public,abstract getOptions (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
in 22
class org/spongepowered/tools/obfuscation/interfaces/IReferenceManager 50 public,interface,abstract java/lang/Object - -
 method public,abstract setAllowConflicts (Z)V - -
 method public,abstract getAllowConflicts ()Z - -
 method public,abstract write ()V - -
 method public,abstract getMapper ()Lorg/spongepowered/asm/mixin/refmap/ReferenceMapper; - -
 method public,abstract addMethodMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
 method public,abstract addMethodMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
 method public,abstract addFieldMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorRemappable;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;)V -
 method public,abstract addClassMapping (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData;)V (Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationData<Ljava/lang/String;>;)V -
in 22
class org/spongepowered/tools/obfuscation/interfaces/ITypeHandleProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract getTypeHandle (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public,abstract getTypeHandle (Ljava/lang/Object;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public,abstract getSimulatedHandle (Ljava/lang/String;Ljavax/lang/model/type/TypeMirror;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
in 22
class org/spongepowered/tools/obfuscation/mapping/IMappingConsumer 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 method public,abstract clear ()V - -
 method public,abstract addFieldMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)V - -
 method public,abstract addMethodMapping (Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)V - -
 method public,abstract getFieldMappings (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet; (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>; -
 method public,abstract getMethodMappings (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet; (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>; -
in 22
class org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet 50 public,super java/util/LinkedHashSet - <TMapping::Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TTMapping;>;>Ljava/util/LinkedHashSet<Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair<TTMapping;>;>;
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet Pair public,static
 method public <init> ()V - -
in 22
class org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair 50 public,super java/lang/Object - <TMapping::Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TTMapping;>;>Ljava/lang/Object;
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet Pair public,static
 field public,final from Lorg/spongepowered/asm/obfuscation/mapping/IMapping; TTMapping;
 field public,final to Lorg/spongepowered/asm/obfuscation/mapping/IMapping; TTMapping;
 method public <init> (Lorg/spongepowered/asm/obfuscation/mapping/IMapping;Lorg/spongepowered/asm/obfuscation/mapping/IMapping;)V (TTMapping;TTMapping;)V -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/mapping/IMappingProvider 50 public,interface,abstract java/lang/Object - -
 method public,abstract clear ()V - -
 method public,abstract isEmpty ()Z - -
 method public,abstract read (Ljava/io/File;)V - java/io/IOException
 method public,abstract getMethodMapping (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public,abstract getFieldMapping (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public,abstract getClassMapping (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getPackageMapping (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/mapping/IMappingWriter 50 public,interface,abstract java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 method public,abstract write (Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet;)V (Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
in 22
class org/spongepowered/tools/obfuscation/mapping/common/MappingProvider 50 public,super,abstract java/lang/Object org/spongepowered/tools/obfuscation/mapping/IMappingProvider -
 field protected,final messager Ljavax/annotation/processing/Messager; -
 field protected,final filer Ljavax/annotation/processing/Filer; -
 field protected,final packageMap Lcom/google/common/collect/BiMap; Lcom/google/common/collect/BiMap<Ljava/lang/String;Ljava/lang/String;>;
 field protected,final classMap Lcom/google/common/collect/BiMap; Lcom/google/common/collect/BiMap<Ljava/lang/String;Ljava/lang/String;>;
 field protected,final fieldMap Lcom/google/common/collect/BiMap; Lcom/google/common/collect/BiMap<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;
 field protected,final methodMap Lcom/google/common/collect/BiMap; Lcom/google/common/collect/BiMap<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;
 method public <init> (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)V - -
 method public clear ()V - -
 method public isEmpty ()Z - -
 method public getMethodMapping (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public getFieldMapping (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public getClassMapping (Ljava/lang/String;)Ljava/lang/String; - -
 method public getPackageMapping (Ljava/lang/String;)Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/mapping/common/MappingWriter 50 public,super,abstract java/lang/Object org/spongepowered/tools/obfuscation/mapping/IMappingWriter -
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 inner javax/tools/JavaFileManager$Location javax/tools/JavaFileManager Location public,static,interface,abstract
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 method public <init> (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)V - -
 method protected openFileWriter (Ljava/lang/String;Ljava/lang/String;)Ljava/io/PrintWriter; - java/io/IOException
 method protected printMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;)V - -
in 22
class org/spongepowered/tools/obfuscation/mapping/fg3/MappingMethodLazy 50 public,super org/spongepowered/asm/obfuscation/mapping/common/MappingMethod - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/mapping/IMappingProvider;)V - -
 method public getDesc ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/mapping/fg3/MappingProviderTSrg 50 public,super org/spongepowered/tools/obfuscation/mapping/common/MappingProvider - -
 method public <init> (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)V - -
 method public read (Ljava/io/File;)V - java/io/IOException
 method public getFieldMapping (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
in 22
class org/spongepowered/tools/obfuscation/mapping/fg3/MappingWriterTSrg 50 public,super org/spongepowered/tools/obfuscation/mapping/mcp/MappingWriterSrg - -
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet Pair public,static
 method public <init> (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;Lorg/spongepowered/tools/obfuscation/mapping/fg3/MappingProviderTSrg;Z)V - -
 method protected openFileWriter (Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Ljava/io/PrintWriter; - java/io/IOException
 method protected writeHeader (Ljava/io/PrintWriter;)V - -
 method protected formatFieldMapping (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair;)Ljava/lang/String; (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;)Ljava/lang/String; -
 method protected formatMethodMapping (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair;)Ljava/lang/String; (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)Ljava/lang/String; -
in 22
class org/spongepowered/tools/obfuscation/mapping/mcp/MappingProviderSrg 50 public,super org/spongepowered/tools/obfuscation/mapping/common/MappingProvider - -
 method public <init> (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)V - -
 method public read (Ljava/io/File;)V - java/io/IOException
 method public getFieldMapping (Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
in 22
class org/spongepowered/tools/obfuscation/mapping/mcp/MappingWriterSrg 50 public,super org/spongepowered/tools/obfuscation/mapping/common/MappingWriter - -
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet org/spongepowered/tools/obfuscation/mapping/IMappingConsumer MappingSet public,static
 inner org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair org/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet Pair public,static
 method public <init> (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)V - -
 method public write (Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet;)V (Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationType;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
 method protected openFileWriter (Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/ObfuscationType;)Ljava/io/PrintWriter; - java/io/IOException
 method protected writeHeader (Ljava/io/PrintWriter;)V - -
 method protected writeFieldMappings (Ljava/io/PrintWriter;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet;)V (Ljava/io/PrintWriter;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;)V -
 method protected writeMethodMappings (Ljava/io/PrintWriter;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet;)V (Ljava/io/PrintWriter;Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)V -
 method protected formatFieldMapping (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair;)Ljava/lang/String; (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;)Ljava/lang/String; -
 method protected formatMethodMapping (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair;)Ljava/lang/String; (Lorg/spongepowered/tools/obfuscation/mapping/IMappingConsumer$MappingSet$Pair<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;)Ljava/lang/String; -
in 22
class org/spongepowered/tools/obfuscation/mcp/ObfuscationEnvironmentMCP 50 public,super org/spongepowered/tools/obfuscation/ObfuscationEnvironment - -
 method protected <init> (Lorg/spongepowered/tools/obfuscation/ObfuscationType;)V - -
 method protected getMappingProvider (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingProvider; - -
 method protected getMappingWriter (Ljavax/annotation/processing/Messager;Ljavax/annotation/processing/Filer;)Lorg/spongepowered/tools/obfuscation/mapping/IMappingWriter; - -
in 22
class org/spongepowered/tools/obfuscation/mcp/ObfuscationServiceMCP 50 public,super java/lang/Object org/spongepowered/tools/obfuscation/service/IObfuscationService -
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 field public,static,final SEARGE Ljava/lang/String; - "searge"
 field public,static,final NOTCH Ljava/lang/String; - "notch"
 field public,static,final REOBF_SRG_FILE Ljava/lang/String; - "reobfSrgFile"
 field public,static,final REOBF_EXTRA_SRG_FILES Ljava/lang/String; - "reobfSrgFiles"
 field public,static,final REOBF_NOTCH_FILE Ljava/lang/String; - "reobfNotchSrgFile"
 field public,static,final REOBF_EXTRA_NOTCH_FILES Ljava/lang/String; - "reobfNotchSrgFiles"
 field public,static,final OUT_SRG_SRG_FILE Ljava/lang/String; - "outSrgFile"
 field public,static,final OUT_NOTCH_SRG_FILE Ljava/lang/String; - "outNotchSrgFile"
 method public <init> ()V - -
 method public getSupportedOptions ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getObfuscationTypes (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Ljava/util/Collection; (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/service/ObfuscationTypeDescriptor;>; -
in 22
class org/spongepowered/tools/obfuscation/mirror/AnnotationHandle 50 public,final,super java/lang/Object org/spongepowered/asm/util/asm/IAnnotationHandle -
 field public,static,final MISSING Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; -
 method public asMirror ()Ljavax/lang/model/element/AnnotationMirror; - -
 method public exists ()Z - -
 method public getDesc ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public getValue (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public getValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public getValue (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public getBoolean (Ljava/lang/String;Z)Z - -
 method public getAnnotation (Ljava/lang/String;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; - -
 method public getList ()Ljava/util/List; <T:Ljava/lang/Object;>()Ljava/util/List<TT;>; -
 method public getList (Ljava/lang/String;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/lang/String;)Ljava/util/List<TT;>; -
 method public getAnnotationList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lorg/spongepowered/asm/util/asm/IAnnotationHandle;>; -
 method public getTypeValue (Ljava/lang/String;)Lorg/objectweb/asm/Type; - -
 method public getTypeList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lorg/objectweb/asm/Type;>; -
 method protected getAnnotationValue (Ljava/lang/String;)Ljavax/lang/model/element/AnnotationValue; - -
 method protected,static unwrapAnnotationValueList (Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<Ljavax/lang/model/element/AnnotationValue;>;)Ljava/util/List<TT;>; -
 method protected,static getAnnotation (Ljavax/lang/model/element/Element;Ljava/lang/Class;)Ljavax/lang/model/element/AnnotationMirror; (Ljavax/lang/model/element/Element;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Ljavax/lang/model/element/AnnotationMirror; -
 method public,static asMirror (Lorg/spongepowered/asm/util/asm/IAnnotationHandle;)Ljavax/lang/model/element/AnnotationMirror; - -
 method public,static of (Ljavax/lang/model/element/AnnotationMirror;)Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; - -
 method public,static of (Ljavax/lang/model/element/Element;Ljava/lang/Class;)Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; (Ljavax/lang/model/element/Element;Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; -
in 22
class org/spongepowered/tools/obfuscation/mirror/FieldHandle 50 public,super org/spongepowered/tools/obfuscation/mirror/MemberHandle - Lorg/spongepowered/tools/obfuscation/mirror/MemberHandle<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField;>;
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 method public <init> (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/VariableElement;)V - -
 method public <init> (Ljava/lang/String;Ljavax/lang/model/element/VariableElement;)V - -
 method public <init> (Ljavax/lang/model/element/TypeElement;Ljavax/lang/model/element/VariableElement;Z)V - -
 method public <init> (Ljava/lang/String;Ljavax/lang/model/element/VariableElement;Z)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljavax/lang/model/element/VariableElement;ZLjava/lang/String;Ljava/lang/String;)V - -
 method public isImaginary ()Z - -
 method public getElement ()Ljavax/lang/model/element/VariableElement; - -
 method public getVisibility ()Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
 method public isRawType ()Z - -
 method public asMapping (Z)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingField; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/FieldHandleASM 50 public,super org/spongepowered/tools/obfuscation/mirror/FieldHandle - -
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Lorg/objectweb/asm/tree/FieldNode;)V - -
 method public getVisibility ()Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/MemberHandle 50 public,super,abstract java/lang/Object - <T::Lorg/spongepowered/asm/obfuscation/mapping/IMapping<TT;>;>Ljava/lang/Object;
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public,final getOwner ()Ljava/lang/String; - -
 method public,final getName ()Ljava/lang/String; - -
 method public,final getDesc ()Ljava/lang/String; - -
 method public,abstract getVisibility ()Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
 method public,abstract asMapping (Z)Lorg/spongepowered/asm/obfuscation/mapping/IMapping; (Z)TT; -
in 22
class org/spongepowered/tools/obfuscation/mirror/MethodHandle 50 public,super org/spongepowered/tools/obfuscation/mirror/MemberHandle - Lorg/spongepowered/tools/obfuscation/mirror/MemberHandle<Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod;>;
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljavax/lang/model/element/ExecutableElement;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;)V - -
 method public isImaginary ()Z - -
 method public getElement ()Ljavax/lang/model/element/ExecutableElement; - -
 method public getJavaSignature ()Ljava/lang/String; - -
 method public getVisibility ()Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
 method public asMapping (Z)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public toString ()Ljava/lang/String; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/MethodHandleASM 50 public,super org/spongepowered/tools/obfuscation/mirror/MethodHandle - -
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Lorg/objectweb/asm/tree/MethodNode;)V - -
 method public getJavaSignature ()Ljava/lang/String; - -
 method public getVisibility ()Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/TypeHandle 50 public,super java/lang/Object - -
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 method public <init> (Ljavax/lang/model/element/PackageElement;Ljava/lang/String;)V - -
 method public <init> (Ljavax/lang/model/element/TypeElement;)V - -
 method public <init> (Ljavax/lang/model/type/DeclaredType;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final getName ()Ljava/lang/String; - -
 method public,final getSimpleName ()Ljava/lang/String; - -
 method public,final getPackage ()Ljavax/lang/model/element/PackageElement; - -
 method public,final getElement ()Ljavax/lang/model/element/TypeElement; - -
 method protected getTargetElement ()Ljavax/lang/model/element/TypeElement; - -
 method public getAnnotation (Ljava/lang/Class;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; -
 method protected,final getEnclosedElements ()Ljava/util/List; ()Ljava/util/List<+Ljavax/lang/model/element/Element;>; -
 method protected,varargs getEnclosedElements ([Ljavax/lang/model/element/ElementKind;)Ljava/util/List; <T::Ljavax/lang/model/element/Element;>([Ljavax/lang/model/element/ElementKind;)Ljava/util/List<TT;>; -
 method public hasTypeMirror ()Z - -
 method public getTypeMirror ()Ljavax/lang/model/type/TypeMirror; - -
 method public getSuperclass ()Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public getInterfaces ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>; -
 method public getMethods ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle;>; -
 method public isPublic ()Z - -
 method public isImaginary ()Z - -
 method public isSimulated ()Z - -
 method public,final getReference ()Lorg/spongepowered/tools/obfuscation/mirror/TypeReference; - -
 method public getMappingMethod (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public findDescriptor (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName;)Ljava/lang/String; - -
 method public,final findField (Ljavax/lang/model/element/VariableElement;)Lorg/spongepowered/tools/obfuscation/mirror/FieldHandle; - -
 method public,final findField (Ljavax/lang/model/element/VariableElement;Z)Lorg/spongepowered/tools/obfuscation/mirror/FieldHandle; - -
 method public,final findField (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/mirror/FieldHandle; - -
 method public findField (Ljava/lang/String;Ljava/lang/String;Z)Lorg/spongepowered/tools/obfuscation/mirror/FieldHandle; - -
 method public,final findMethod (Ljavax/lang/model/element/ExecutableElement;)Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle; - -
 method public,final findMethod (Ljavax/lang/model/element/ExecutableElement;Z)Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle; - -
 method public,final findMethod (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle; - -
 method public findMethod (Ljava/lang/String;Ljava/lang/String;Z)Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle; - -
 method protected,static findMethod (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle; - -
 method protected,static compareElement (Ljavax/lang/model/element/Element;Ljava/lang/String;Ljava/lang/String;Z)Z - -
 method protected,static,varargs getEnclosedElements (Ljavax/lang/model/element/TypeElement;[Ljavax/lang/model/element/ElementKind;)Ljava/util/List; <T::Ljavax/lang/model/element/Element;>(Ljavax/lang/model/element/TypeElement;[Ljavax/lang/model/element/ElementKind;)Ljava/util/List<TT;>; -
 method protected,static getEnclosedElements (Ljavax/lang/model/element/TypeElement;)Ljava/util/List; (Ljavax/lang/model/element/TypeElement;)Ljava/util/List<+Ljavax/lang/model/element/Element;>; -
in 22
class org/spongepowered/tools/obfuscation/mirror/TypeHandleASM 50 public,super org/spongepowered/tools/obfuscation/mirror/TypeHandle - -
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner javax/tools/JavaFileManager$Location javax/tools/JavaFileManager Location public,static,interface,abstract
 method protected <init> (Ljavax/lang/model/element/PackageElement;Ljava/lang/String;Lorg/objectweb/asm/tree/ClassNode;Lorg/spongepowered/tools/obfuscation/interfaces/ITypeHandleProvider;)V - -
 method public getAnnotation (Ljava/lang/Class;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/asm/util/asm/IAnnotationHandle; -
 method public,varargs getEnclosedElements ([Ljavax/lang/model/element/ElementKind;)Ljava/util/List; <T::Ljavax/lang/model/element/Element;>([Ljavax/lang/model/element/ElementKind;)Ljava/util/List<TT;>; -
 method public hasTypeMirror ()Z - -
 method public getTypeMirror ()Ljavax/lang/model/type/TypeMirror; - -
 method public getSuperclass ()Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public getInterfaces ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>; -
 method public getMethods ()Ljava/util/List; ()Ljava/util/List<Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle;>; -
 method public isPublic ()Z - -
 method public isImaginary ()Z - -
 method public findDescriptor (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName;)Ljava/lang/String; - -
 method public findField (Ljava/lang/String;Ljava/lang/String;Z)Lorg/spongepowered/tools/obfuscation/mirror/FieldHandle; - -
 method public findMethod (Ljava/lang/String;Ljava/lang/String;Z)Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle; - -
 method protected,static compareElement (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Z - -
 method public,static of (Ljavax/lang/model/element/PackageElement;Ljava/lang/String;Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/TypeHandleSimulated 50 public,super org/spongepowered/tools/obfuscation/mirror/TypeHandle - -
 method public <init> (Ljava/lang/String;Ljavax/lang/model/type/TypeMirror;)V - -
 method public <init> (Ljavax/lang/model/element/PackageElement;Ljava/lang/String;Ljavax/lang/model/type/TypeMirror;)V - -
 method protected getTargetElement ()Ljavax/lang/model/element/TypeElement; - -
 method public isPublic ()Z - -
 method public isImaginary ()Z - -
 method public isSimulated ()Z - -
 method public getAnnotation (Ljava/lang/Class;)Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; (Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>;)Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle; -
 method public getSuperclass ()Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public findDescriptor (Lorg/spongepowered/asm/mixin/injection/selectors/ITargetSelectorByName;)Ljava/lang/String; - -
 method public findField (Ljava/lang/String;Ljava/lang/String;Z)Lorg/spongepowered/tools/obfuscation/mirror/FieldHandle; - -
 method public findMethod (Ljava/lang/String;Ljava/lang/String;Z)Lorg/spongepowered/tools/obfuscation/mirror/MethodHandle; - -
 method public getMappingMethod (Ljava/lang/String;Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/TypeReference 50 public,super java/lang/Object java/io/Serializable,java/lang/Comparable Ljava/lang/Object;Ljava/io/Serializable;Ljava/lang/Comparable<Lorg/spongepowered/tools/obfuscation/mirror/TypeReference;>;
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
 method public getHandle (Ljavax/annotation/processing/ProcessingEnvironment;)Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle; - -
 method public toString ()Ljava/lang/String; - -
 method public compareTo (Lorg/spongepowered/tools/obfuscation/mirror/TypeReference;)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class org/spongepowered/tools/obfuscation/mirror/TypeUtils 50 public,super,abstract java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/mirror/TypeUtils$EquivalencyResult org/spongepowered/tools/obfuscation/mirror/TypeUtils EquivalencyResult public,static
 inner org/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency org/spongepowered/tools/obfuscation/mirror/TypeUtils Equivalency public,static,final,enum
 inner org/spongepowered/asm/util/Bytecode$Visibility org/spongepowered/asm/util/Bytecode Visibility public,static,final,enum
 method public,static getPackage (Ljavax/lang/model/type/TypeMirror;)Ljavax/lang/model/element/PackageElement; - -
 method public,static getPackage (Ljavax/lang/model/element/TypeElement;)Ljavax/lang/model/element/PackageElement; - -
 method public,static getElementType (Ljavax/lang/model/element/Element;)Ljava/lang/String; - -
 method public,static stripGenerics (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getName (Ljavax/lang/model/element/VariableElement;)Ljava/lang/String; - -
 method public,static getName (Ljavax/lang/model/element/ExecutableElement;)Ljava/lang/String; - -
 method public,static getJavaSignature (Ljavax/lang/model/element/Element;)Ljava/lang/String; - -
 method public,static getJavaSignature (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getSimpleName (Ljavax/lang/model/type/TypeMirror;)Ljava/lang/String; - -
 method public,static getTypeName (Ljavax/lang/model/type/TypeMirror;)Ljava/lang/String; - -
 method public,static getTypeName (Ljavax/lang/model/type/DeclaredType;)Ljava/lang/String; - -
 method public,static getDescriptor (Ljavax/lang/model/element/Element;)Ljava/lang/String; - -
 method public,static getDescriptor (Ljavax/lang/model/element/ExecutableElement;)Ljava/lang/String; - -
 method public,static getInternalName (Ljavax/lang/model/element/VariableElement;)Ljava/lang/String; - -
 method public,static getInternalName (Ljavax/lang/model/type/TypeMirror;)Ljava/lang/String; - -
 method public,static getInternalName (Ljavax/lang/model/type/DeclaredType;)Ljava/lang/String; - -
 method public,static getInternalName (Ljavax/lang/model/element/TypeElement;)Ljava/lang/String; - -
 method public,static isAssignable (Ljavax/annotation/processing/ProcessingEnvironment;Ljavax/lang/model/type/TypeMirror;Ljavax/lang/model/type/TypeMirror;)Z - -
 method public,static isEquivalentType (Ljavax/annotation/processing/ProcessingEnvironment;Ljavax/lang/model/type/TypeMirror;Ljavax/lang/model/type/TypeMirror;)Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$EquivalencyResult; - -
 method public,static getVisibility (Ljavax/lang/model/element/Element;)Lorg/spongepowered/asm/util/Bytecode$Visibility; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency;>;
 inner org/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency org/spongepowered/tools/obfuscation/mirror/TypeUtils Equivalency public,static,final,enum
 field public,static,final,enum NOT_EQUIVALENT Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency; -
 field public,static,final,enum EQUIVALENT_BUT_RAW Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency; -
 field public,static,final,enum BOUNDS_MISMATCH Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency; -
 field public,static,final,enum EQUIVALENT Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency; -
 method public,static values ()[Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/TypeUtils$EquivalencyResult 50 public,super java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/mirror/TypeUtils$EquivalencyResult org/spongepowered/tools/obfuscation/mirror/TypeUtils EquivalencyResult public,static
 inner org/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency org/spongepowered/tools/obfuscation/mirror/TypeUtils Equivalency public,static,final,enum
 field public,final type Lorg/spongepowered/tools/obfuscation/mirror/TypeUtils$Equivalency; -
 field public,final detail Ljava/lang/String; -
 field public,final rawType I -
 method public toString ()Ljava/lang/String; - -
in 189
class org/spongepowered/tools/obfuscation/mirror/Visibility 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/tools/obfuscation/mirror/Visibility;>;
 field public,static,final,enum PRIVATE Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 field public,static,final,enum PROTECTED Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 field public,static,final,enum PACKAGE Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 field public,static,final,enum PUBLIC Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 method public,static values ()[Lorg/spongepowered/tools/obfuscation/mirror/Visibility; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/mirror/Visibility; - -
in 190
class org/spongepowered/tools/obfuscation/mirror/Visibility 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/spongepowered/tools/obfuscation/mirror/Visibility;>;
 field public,static,final,enum PRIVATE Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 field public,static,final,enum PROTECTED Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 field public,static,final,enum PACKAGE Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 field public,static,final,enum PUBLIC Lorg/spongepowered/tools/obfuscation/mirror/Visibility; -
 method public,static values ()[Lorg/spongepowered/tools/obfuscation/mirror/Visibility; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/spongepowered/tools/obfuscation/mirror/Visibility; - -
in 22
class org/spongepowered/tools/obfuscation/mirror/mapping/MappingMethodResolvable 50 public,final,super org/spongepowered/asm/obfuscation/mapping/common/MappingMethod - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getSuper ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public move (Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public remap (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public transform (Ljava/lang/String;)Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
 method public copy ()Lorg/spongepowered/asm/obfuscation/mapping/common/MappingMethod; - -
in 22
class org/spongepowered/tools/obfuscation/service/IObfuscationService 50 public,interface,abstract java/lang/Object - -
 method public,abstract getSupportedOptions ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract getObfuscationTypes (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Ljava/util/Collection; (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/service/ObfuscationTypeDescriptor;>; -
in 22
class org/spongepowered/tools/obfuscation/service/ObfuscationServices 50 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public,static getInstance ()Lorg/spongepowered/tools/obfuscation/service/ObfuscationServices; - -
 method public initProviders (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)V - -
 method public getSupportedOptions ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getService (Ljava/lang/Class;)Lorg/spongepowered/tools/obfuscation/service/IObfuscationService; (Ljava/lang/Class<+Lorg/spongepowered/tools/obfuscation/service/IObfuscationService;>;)Lorg/spongepowered/tools/obfuscation/service/IObfuscationService; -
in 22
class org/spongepowered/tools/obfuscation/service/ObfuscationTypeDescriptor 50 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class<+Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class<+Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment;>;)V -
 method public,final getKey ()Ljava/lang/String; - -
 method public getInputFileOption ()Ljava/lang/String; - -
 method public getExtraInputFilesOption ()Ljava/lang/String; - -
 method public getOutputFileOption ()Ljava/lang/String; - -
 method public getEnvironmentType ()Ljava/lang/Class; ()Ljava/lang/Class<+Lorg/spongepowered/tools/obfuscation/ObfuscationEnvironment;>; -
in 22
class org/spongepowered/tools/obfuscation/struct/InjectorRemap 50 public,super java/lang/Object - -
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public <init> (Z)V - -
 method public shouldRemap ()Z - -
 method public notifyRemapped ()V - -
 method public addMessage (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public clearMessage ()V - -
 method public dispatchPendingMessages (Ljavax/annotation/processing/Messager;)V - -
in 22
class org/spongepowered/tools/obfuscation/struct/Message 50 public,super java/lang/Object - -
 inner javax/tools/Diagnostic$Kind javax/tools/Diagnostic Kind public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;)V - -
 method public <init> (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public <init> (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public <init> (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public <init> (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Ljavax/lang/model/element/AnnotationValue;)V - -
 method public <init> (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Lorg/spongepowered/tools/obfuscation/mirror/AnnotationHandle;Ljavax/lang/model/element/AnnotationValue;)V - -
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
 method public <init> (Ljavax/tools/Diagnostic$Kind;Ljava/lang/CharSequence;Ljavax/lang/model/element/Element;Ljavax/lang/model/element/AnnotationMirror;Ljavax/lang/model/element/AnnotationValue;)V - -
 method public sendTo (Ljavax/annotation/processing/Messager;)Lorg/spongepowered/tools/obfuscation/struct/Message; - -
 method public getKind ()Ljavax/tools/Diagnostic$Kind; - -
 method public setKind (Ljavax/tools/Diagnostic$Kind;)Lorg/spongepowered/tools/obfuscation/struct/Message; - -
 method public getMsg ()Ljava/lang/CharSequence; - -
 method public setMsg (Ljava/lang/CharSequence;)Lorg/spongepowered/tools/obfuscation/struct/Message; - -
 method public getElement ()Ljavax/lang/model/element/Element; - -
 method public getAnnotation ()Ljavax/lang/model/element/AnnotationMirror; - -
 method public getValue ()Ljavax/lang/model/element/AnnotationValue; - -
in 22
class org/spongepowered/tools/obfuscation/validation/ParentValidator 50 public,super org/spongepowered/tools/obfuscation/MixinValidator - -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass org/spongepowered/tools/obfuscation/interfaces/IMixinValidator ValidationPass public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)V - -
 method public validate (Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection;)Z (Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>;)Z -
in 22
class org/spongepowered/tools/obfuscation/validation/TargetValidator 50 public,super org/spongepowered/tools/obfuscation/MixinValidator - -
 inner org/spongepowered/tools/obfuscation/interfaces/IMixinValidator$ValidationPass org/spongepowered/tools/obfuscation/interfaces/IMixinValidator ValidationPass public,static,final,enum
 inner org/spongepowered/tools/obfuscation/interfaces/IMessagerEx$MessageType org/spongepowered/tools/obfuscation/interfaces/IMessagerEx MessageType public,static,final,enum
 method public <init> (Lorg/spongepowered/tools/obfuscation/interfaces/IMixinAnnotationProcessor;)V - -
 method public validate (Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection;)Z (Ljavax/lang/model/element/TypeElement;Lorg/spongepowered/asm/util/asm/IAnnotationHandle;Ljava/util/Collection<Lorg/spongepowered/tools/obfuscation/mirror/TypeHandle;>;)Z -
