cg-stub-db 1
in 1102
class org/checkerframework/checker/builder/qual/CalledMethods 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/builder/qual/NotCalledMethods 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/builder/qual/ReturnsReceiver 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Inherited;()
in 1102
class org/checkerframework/checker/calledmethods/qual/CalledMethods 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - - []
in 1102
class org/checkerframework/checker/calledmethods/qual/CalledMethodsBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/calledmethods/qual/CalledMethodsPredicate 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Ljava/lang/String; - -
in 47
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract methods ()[Ljava/lang/String; - -
in 1103
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods$List org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods$List;)
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract methods ()[Ljava/lang/String; - -
in 1103
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods$List org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/calledmethods/qual/EnsuresCalledMethods; - -
in 1104
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf$List org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract result ()Z - -
 method public,abstract methods ()[Ljava/lang/String; - -
in 1105
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf$List org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf$List;)
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract methods ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf$List org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsIf; - -
in 1105
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException$List org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException$List;)
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract methods ()[Ljava/lang/String; - -
in 1105
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException$List org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsOnException; - -
in 1106
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsVarArgs 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
in 483
class org/checkerframework/checker/calledmethods/qual/EnsuresCalledMethodsVarargs 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
in 1105
class org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods$List org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/calledmethods/qual/RequiresCalledMethods$List;)
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract methods ()[Ljava/lang/String; - -
in 49
class org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods$List org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract methods ()[Ljava/lang/String; - -
in 1103
class org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods$List org/checkerframework/checker/calledmethods/qual/RequiresCalledMethods List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/calledmethods/qual/RequiresCalledMethods; - -
in 1102
class org/checkerframework/checker/compilermsgs/qual/CompilerMessageKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/compilermsgs/qual/CompilerMessageKeyBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/compilermsgs/qual/UnknownCompilerMessageKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/AwtAlphaCompositingRule 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/AwtColorSpace 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/AwtCursorType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/AwtFlowLayout 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/Fenum 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/fenum/qual/FenumBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/FenumTop 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/FenumUnqualified 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/checker/fenum/qual/PolyFenum 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingBoxOrientation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingCompassDirection 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingElementOrientation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingHorizontalOrientation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingSplitPaneOrientation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingTextOrientation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingTitleJustification 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingTitlePosition 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/fenum/qual/SwingVerticalOrientation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/formatter/qual/ConversionCategory 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/checkerframework/checker/formatter/qual/ConversionCategory;>;
 field public,static,final,enum GENERAL Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum CHAR Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum INT Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum FLOAT Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum TIME Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum CHAR_AND_INT Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum INT_AND_TIME Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum NULL Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,static,final,enum UNUSED Lorg/checkerframework/checker/formatter/qual/ConversionCategory; -
 field public,final types [Ljava/lang/Class; [Ljava/lang/Class<*>;
 field public,final chars Ljava/lang/String; -
 method public,static values ()[Lorg/checkerframework/checker/formatter/qual/ConversionCategory; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/checkerframework/checker/formatter/qual/ConversionCategory; - -
 method public,static fromConversionChar (C)Lorg/checkerframework/checker/formatter/qual/ConversionCategory; - -
 method public,static isSubsetOf (Lorg/checkerframework/checker/formatter/qual/ConversionCategory;Lorg/checkerframework/checker/formatter/qual/ConversionCategory;)Z - -
 method public,static intersect (Lorg/checkerframework/checker/formatter/qual/ConversionCategory;Lorg/checkerframework/checker/formatter/qual/ConversionCategory;)Lorg/checkerframework/checker/formatter/qual/ConversionCategory; - -
 method public,static union (Lorg/checkerframework/checker/formatter/qual/ConversionCategory;Lorg/checkerframework/checker/formatter/qual/ConversionCategory;)Lorg/checkerframework/checker/formatter/qual/ConversionCategory; - -
 method public isAssignableFrom (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public toString ()Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/formatter/qual/Format 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Lorg/checkerframework/checker/formatter/qual/ConversionCategory; - -
in 1102
class org/checkerframework/checker/formatter/qual/FormatBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/formatter/qual/FormatMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1102
class org/checkerframework/checker/formatter/qual/InvalidFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/formatter/qual/ReturnsFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/checker/formatter/qual/UnknownFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/guieffect/qual/AlwaysSafe 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/guieffect/qual/PolyUI 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/guieffect/qual/PolyUIEffect 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD])
in 1102
class org/checkerframework/checker/guieffect/qual/PolyUIType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
in 1102
class org/checkerframework/checker/guieffect/qual/SafeEffect 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD])
in 1102
class org/checkerframework/checker/guieffect/qual/SafeType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
in 1102
class org/checkerframework/checker/guieffect/qual/UI 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/guieffect/qual/UIEffect 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD])
in 1102
class org/checkerframework/checker/guieffect/qual/UIPackage 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PACKAGE])
in 1102
class org/checkerframework/checker/guieffect/qual/UIType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
in 1102
class org/checkerframework/checker/i18n/qual/LocalizableKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/i18n/qual/LocalizableKeyBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/i18n/qual/Localized 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/i18n/qual/UnknownLocalizableKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/i18n/qual/UnknownLocalized 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nChecksFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nConversionCategory 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory;>;
 field public,static,final,enum UNUSED Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; -
 field public,static,final,enum GENERAL Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; -
 field public,static,final,enum DATE Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; -
 field public,static,final,enum NUMBER Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; -
 field public,final types [Ljava/lang/Class; [Ljava/lang/Class<*>;
 field public,final strings [Ljava/lang/String; -
 method public,static values ()[Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; - -
 method public,static stringToI18nConversionCategory (Ljava/lang/String;)Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; - -
 method public,static isSubsetOf (Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory;Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory;)Z - -
 method public,static intersect (Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory;Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory;)Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; - -
 method public,static union (Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory;Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory;)Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; - -
 method public isAssignableFrom (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public toString ()Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Lorg/checkerframework/checker/i18nformatter/qual/I18nConversionCategory; - -
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nFormatBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nFormatFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nInvalidFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nMakeFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nUnknownFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/i18nformatter/qual/I18nValidFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/checker/index/qual/EnsuresLTLengthOf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/index/qual/EnsuresLTLengthOf$List org/checkerframework/checker/index/qual/EnsuresLTLengthOf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/index/qual/EnsuresLTLengthOf$List;)
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract targetValue ()[Ljava/lang/String; - -
 method public,abstract offset ()[Ljava/lang/String; - - []
in 1102
class org/checkerframework/checker/index/qual/EnsuresLTLengthOf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/index/qual/EnsuresLTLengthOf$List org/checkerframework/checker/index/qual/EnsuresLTLengthOf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/index/qual/EnsuresLTLengthOf; - -
in 1104
class org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf$List org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/index/qual/EnsuresLTLengthOfIf$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract result ()Z - -
 method public,abstract targetValue ()[Ljava/lang/String; - -
 method public,abstract offset ()[Ljava/lang/String; - - []
in 1105
class org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf$List org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/index/qual/EnsuresLTLengthOfIf$List;)
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract targetValue ()[Ljava/lang/String; - -
 method public,abstract offset ()[Ljava/lang/String; - - []
in 1102
class org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf$List org/checkerframework/checker/index/qual/EnsuresLTLengthOfIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/index/qual/EnsuresLTLengthOfIf; - -
in 1102
class org/checkerframework/checker/index/qual/GTENegativeOne 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/HasSubsequence 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract subsequence ()Ljava/lang/String; - -
 method public,abstract from ()Ljava/lang/String; - -
 method public,abstract to ()Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/IndexFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/IndexOrHigh 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/IndexOrLow 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/LTEqLengthOf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/LTLengthOf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract offset ()[Ljava/lang/String; - - []
in 1102
class org/checkerframework/checker/index/qual/LTOMLengthOf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/LengthOf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/LessThan 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/LessThanBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1102
class org/checkerframework/checker/index/qual/LessThanUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1102
class org/checkerframework/checker/index/qual/LowerBoundBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/LowerBoundUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/NegativeIndexFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/NonNegative 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/PolyIndex 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/PolyLength 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/PolyLowerBound 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/PolySameLen 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/PolyUpperBound 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/Positive 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/SameLen 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/SameLenBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/SameLenUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/SearchIndexBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/SearchIndexFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/SearchIndexUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/SubstringIndexBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/SubstringIndexFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract offset ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/index/qual/SubstringIndexUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/index/qual/UpperBoundBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/checker/index/qual/UpperBoundLiteral 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()I - -
in 1102
class org/checkerframework/checker/index/qual/UpperBoundUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/initialization/qual/FBCBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/initialization/qual/Initialized 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/initialization/qual/NotOnlyInitialized 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 1102
class org/checkerframework/checker/initialization/qual/UnderInitialization 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
in 1102
class org/checkerframework/checker/initialization/qual/UnknownInitialization 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
in 1102
class org/checkerframework/checker/interning/qual/CompareToMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 1102
class org/checkerframework/checker/interning/qual/EqualsMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 1102
class org/checkerframework/checker/interning/qual/FindDistinct 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER])
in 1102
class org/checkerframework/checker/interning/qual/InternMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 1102
class org/checkerframework/checker/interning/qual/Interned 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/interning/qual/InternedDistinct 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/interning/qual/PolyInterned 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/interning/qual/UnknownInterned 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/interning/qual/UsesObjectEquals 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Inherited;()
in 1102
class org/checkerframework/checker/lock/qual/EnsuresLockHeld 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/lock/qual/EnsuresLockHeld$List org/checkerframework/checker/lock/qual/EnsuresLockHeld List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/lock/qual/EnsuresLockHeld$List;)
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/lock/qual/EnsuresLockHeld$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/lock/qual/EnsuresLockHeld$List org/checkerframework/checker/lock/qual/EnsuresLockHeld List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/lock/qual/EnsuresLockHeld; - -
in 1104
class org/checkerframework/checker/lock/qual/EnsuresLockHeldIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/lock/qual/EnsuresLockHeldIf$List org/checkerframework/checker/lock/qual/EnsuresLockHeldIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/lock/qual/EnsuresLockHeldIf$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract result ()Z - -
in 1105
class org/checkerframework/checker/lock/qual/EnsuresLockHeldIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/lock/qual/EnsuresLockHeldIf$List org/checkerframework/checker/lock/qual/EnsuresLockHeldIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/lock/qual/EnsuresLockHeldIf$List;)
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/lock/qual/EnsuresLockHeldIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/lock/qual/EnsuresLockHeldIf$List org/checkerframework/checker/lock/qual/EnsuresLockHeldIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/lock/qual/EnsuresLockHeldIf; - -
in 1102
class org/checkerframework/checker/lock/qual/GuardSatisfied 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()I - - I-1
in 1102
class org/checkerframework/checker/lock/qual/GuardedBy 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - - []
in 1102
class org/checkerframework/checker/lock/qual/GuardedByBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/lock/qual/GuardedByUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/lock/qual/Holding 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/lock/qual/LockHeld 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/checker/lock/qual/LockPossiblyHeld 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/checker/lock/qual/LockingFree 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1102
class org/checkerframework/checker/lock/qual/MayReleaseLocks 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1103
class org/checkerframework/checker/lock/qual/NewObject 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/lock/qual/ReleasesNoLocks 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1103
class org/checkerframework/checker/mustcall/qual/CreatesMustCallFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/mustcall/qual/CreatesMustCallFor$List org/checkerframework/checker/mustcall/qual/CreatesMustCallFor List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/mustcall/qual/CreatesMustCallFor$List;)
 method public,abstract value ()Ljava/lang/String; - - "this"
in 1103
class org/checkerframework/checker/mustcall/qual/CreatesMustCallFor$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/mustcall/qual/CreatesMustCallFor$List org/checkerframework/checker/mustcall/qual/CreatesMustCallFor List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract value ()[Lorg/checkerframework/checker/mustcall/qual/CreatesMustCallFor; - -
in 1103
class org/checkerframework/checker/mustcall/qual/InheritableMustCall 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Inherited;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()[Ljava/lang/String; - - []
in 1103
class org/checkerframework/checker/mustcall/qual/MustCall 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - - []
in 1103
class org/checkerframework/checker/mustcall/qual/MustCallAlias 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1103
class org/checkerframework/checker/mustcall/qual/MustCallUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/checker/mustcall/qual/NotOwning 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#FIELD])
in 1103
class org/checkerframework/checker/mustcall/qual/Owning 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#FIELD])
in 1103
class org/checkerframework/checker/mustcall/qual/PolyMustCall 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 483
class org/checkerframework/checker/nonempty/qual/EnsuresNonEmpty 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
in 483
class org/checkerframework/checker/nonempty/qual/EnsuresNonEmptyIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nonempty/qual/EnsuresNonEmptyIf$List org/checkerframework/checker/nonempty/qual/EnsuresNonEmptyIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
in 483
class org/checkerframework/checker/nonempty/qual/EnsuresNonEmptyIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nonempty/qual/EnsuresNonEmptyIf$List org/checkerframework/checker/nonempty/qual/EnsuresNonEmptyIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/nonempty/qual/EnsuresNonEmptyIf; - -
in 483
class org/checkerframework/checker/nonempty/qual/NonEmpty 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 483
class org/checkerframework/checker/nonempty/qual/PolyNonEmpty 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 483
class org/checkerframework/checker/nonempty/qual/RequiresNonEmpty 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nonempty/qual/RequiresNonEmpty$List org/checkerframework/checker/nonempty/qual/RequiresNonEmpty List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 483
class org/checkerframework/checker/nonempty/qual/RequiresNonEmpty$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nonempty/qual/RequiresNonEmpty$List org/checkerframework/checker/nonempty/qual/RequiresNonEmpty List public,static,interface,abstract,annotation
 method public,abstract value ()[Lorg/checkerframework/checker/nonempty/qual/RequiresNonEmpty; - -
in 483
class org/checkerframework/checker/nonempty/qual/UnknownNonEmpty 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1102
class org/checkerframework/checker/nullness/qual/AssertNonNullIfNonNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/nullness/qual/EnsuresKeyFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresKeyFor$List org/checkerframework/checker/nullness/qual/EnsuresKeyFor List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/nullness/qual/EnsuresKeyFor$List;)
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract map ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/nullness/qual/EnsuresKeyFor$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresKeyFor$List org/checkerframework/checker/nullness/qual/EnsuresKeyFor List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/nullness/qual/EnsuresKeyFor; - -
in 1102
class org/checkerframework/checker/nullness/qual/EnsuresKeyForIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresKeyForIf$List org/checkerframework/checker/nullness/qual/EnsuresKeyForIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/nullness/qual/EnsuresKeyForIf$List;)
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract map ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/nullness/qual/EnsuresKeyForIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresKeyForIf$List org/checkerframework/checker/nullness/qual/EnsuresKeyForIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/nullness/qual/EnsuresKeyForIf; - -
in 1102
class org/checkerframework/checker/nullness/qual/EnsuresNonNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresNonNull$List org/checkerframework/checker/nullness/qual/EnsuresNonNull List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/nullness/qual/EnsuresNonNull$List;)
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/nullness/qual/EnsuresNonNull$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresNonNull$List org/checkerframework/checker/nullness/qual/EnsuresNonNull List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/nullness/qual/EnsuresNonNull; - -
in 1104
class org/checkerframework/checker/nullness/qual/EnsuresNonNullIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresNonNullIf$List org/checkerframework/checker/nullness/qual/EnsuresNonNullIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/nullness/qual/EnsuresNonNullIf$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract result ()Z - -
in 1105
class org/checkerframework/checker/nullness/qual/EnsuresNonNullIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresNonNullIf$List org/checkerframework/checker/nullness/qual/EnsuresNonNullIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/nullness/qual/EnsuresNonNullIf$List;)
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/nullness/qual/EnsuresNonNullIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/EnsuresNonNullIf$List org/checkerframework/checker/nullness/qual/EnsuresNonNullIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/nullness/qual/EnsuresNonNullIf; - -
in 1102
class org/checkerframework/checker/nullness/qual/KeyFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/checker/nullness/qual/KeyForBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/nullness/qual/MonotonicNonNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1102
class org/checkerframework/checker/nullness/qual/NonNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/nullness/qual/Nullable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/nullness/qual/PolyKeyFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/nullness/qual/PolyNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 47
class org/checkerframework/checker/nullness/qual/RequiresNonNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
in 1103
class org/checkerframework/checker/nullness/qual/RequiresNonNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/RequiresNonNull$List org/checkerframework/checker/nullness/qual/RequiresNonNull List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/checker/nullness/qual/RequiresNonNull$List;)
 method public,abstract value ()[Ljava/lang/String; - -
in 1103
class org/checkerframework/checker/nullness/qual/RequiresNonNull$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/nullness/qual/RequiresNonNull$List org/checkerframework/checker/nullness/qual/RequiresNonNull List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/nullness/qual/RequiresNonNull; - -
in 1102
class org/checkerframework/checker/nullness/qual/UnknownKeyFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1105
class org/checkerframework/checker/optional/qual/EnsuresPresent 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
in 1105
class org/checkerframework/checker/optional/qual/EnsuresPresentIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/optional/qual/EnsuresPresentIf$List org/checkerframework/checker/optional/qual/EnsuresPresentIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
in 1105
class org/checkerframework/checker/optional/qual/EnsuresPresentIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/optional/qual/EnsuresPresentIf$List org/checkerframework/checker/optional/qual/EnsuresPresentIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/optional/qual/EnsuresPresentIf; - -
in 1102
class org/checkerframework/checker/optional/qual/MaybePresent 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1107
class org/checkerframework/checker/optional/qual/OptionalBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1105
class org/checkerframework/checker/optional/qual/OptionalCreator 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1105
class org/checkerframework/checker/optional/qual/OptionalEliminator 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1105
class org/checkerframework/checker/optional/qual/OptionalPropagator 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/checker/optional/qual/PolyPresent 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/optional/qual/Present 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1105
class org/checkerframework/checker/optional/qual/RequiresPresent 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/optional/qual/RequiresPresent$List org/checkerframework/checker/optional/qual/RequiresPresent List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Ljava/lang/String; - -
in 1105
class org/checkerframework/checker/optional/qual/RequiresPresent$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/checker/optional/qual/RequiresPresent$List org/checkerframework/checker/optional/qual/RequiresPresent List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/checker/optional/qual/RequiresPresent; - -
in 1102
class org/checkerframework/checker/propkey/qual/PropertyKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/propkey/qual/PropertyKeyBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/propkey/qual/UnknownPropertyKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/regex/qual/PartialRegex 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[])
 method public,abstract value ()Ljava/lang/String; - - ""
in 1102
class org/checkerframework/checker/regex/qual/PolyRegex 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/regex/qual/Regex 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()I - - I0
in 1102
class org/checkerframework/checker/regex/qual/RegexBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/regex/qual/UnknownRegex 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/ArrayWithoutPackage 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/BinaryName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/BinaryNameOrPrimitiveType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1107
class org/checkerframework/checker/signature/qual/BinaryNameWithoutPackage 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/CanonicalName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/CanonicalNameAndBinaryName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/CanonicalNameOrEmpty 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/CanonicalNameOrPrimitiveType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/ClassGetName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/ClassGetSimpleName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/DotSeparatedIdentifiers 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/DotSeparatedIdentifiersOrPrimitiveType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/FieldDescriptor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/FieldDescriptorForPrimitive 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/FieldDescriptorWithoutPackage 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/FqBinaryName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/FullyQualifiedName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/Identifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/IdentifierOrPrimitiveType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/InternalForm 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/MethodDescriptor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/PolySignature 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/PrimitiveType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/SignatureBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signature/qual/SignatureUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/checker/signedness/qual/PolySigned 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signedness/qual/Signed 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signedness/qual/SignedPositive 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1104
class org/checkerframework/checker/signedness/qual/SignedPositiveFromUnsigned 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signedness/qual/SignednessBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signedness/qual/SignednessGlb 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signedness/qual/UnknownSignedness 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/signedness/qual/Unsigned 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 483
class org/checkerframework/checker/sqlquotes/qual/SqlEvenQuotes 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 483
class org/checkerframework/checker/sqlquotes/qual/SqlOddQuotes 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 483
class org/checkerframework/checker/sqlquotes/qual/SqlQuotesBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 483
class org/checkerframework/checker/sqlquotes/qual/SqlQuotesUnknown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/tainting/qual/PolyTainted 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/tainting/qual/Tainted 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/tainting/qual/Untainted 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/A 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/Acceleration 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Angle 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Area 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/C 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Current 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/checker/units/qual/Force 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/K 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/Length 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Luminance 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Mass 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/MixedUnits 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1103
class org/checkerframework/checker/units/qual/N 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/PolyUnit 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Prefix 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/checkerframework/checker/units/qual/Prefix;>;
 field public,static,final,enum yotta Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum zetta Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum exa Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum peta Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum tera Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum giga Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum mega Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum kilo Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum hecto Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum deca Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum one Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum deci Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum centi Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum milli Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum micro Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum nano Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum pico Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum femto Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum atto Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum zepto Lorg/checkerframework/checker/units/qual/Prefix; -
 field public,static,final,enum yocto Lorg/checkerframework/checker/units/qual/Prefix; -
 method public,static values ()[Lorg/checkerframework/checker/units/qual/Prefix; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/checkerframework/checker/units/qual/Prefix; - -
in 1102
class org/checkerframework/checker/units/qual/Speed 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Substance 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Temperature 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/Time 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/UnitsBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/UnitsMultiple 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract quantity ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
 method public,abstract prefix ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/UnitsRelations 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
in 1102
class org/checkerframework/checker/units/qual/UnknownUnits 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/checker/units/qual/Volume 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/cd 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/degrees 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/g 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/h 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/checker/units/qual/kN 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/kg 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/km 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/km2 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/checker/units/qual/km3 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/kmPERh 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/m 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/m2 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1103
class org/checkerframework/checker/units/qual/m3 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/mPERs 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/mPERs2 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/min 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/mm 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/mm2 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/checker/units/qual/mm3 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/checker/units/qual/mol 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/radians 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1102
class org/checkerframework/checker/units/qual/s 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()Lorg/checkerframework/checker/units/qual/Prefix; - - ELorg/checkerframework/checker/units/qual/Prefix;#one
in 1103
class org/checkerframework/checker/units/qual/t 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/aliasing/qual/LeakedToResult 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1102
class org/checkerframework/common/aliasing/qual/MaybeAliased 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1102
class org/checkerframework/common/aliasing/qual/MaybeLeaked 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/common/aliasing/qual/NonLeaked 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1102
class org/checkerframework/common/aliasing/qual/Unique 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/initializedfields/qual/EnsuresInitializedFields 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/common/initializedfields/qual/EnsuresInitializedFields$List org/checkerframework/common/initializedfields/qual/EnsuresInitializedFields List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/common/initializedfields/qual/EnsuresInitializedFields$List;)
 method public,abstract value ()[Ljava/lang/String; - - ["this"]
 method public,abstract fields ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/initializedfields/qual/EnsuresInitializedFields$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/common/initializedfields/qual/EnsuresInitializedFields$List org/checkerframework/common/initializedfields/qual/EnsuresInitializedFields List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/common/initializedfields/qual/EnsuresInitializedFields; - -
in 1102
class org/checkerframework/common/initializedfields/qual/InitializedFields 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - - []
in 1102
class org/checkerframework/common/initializedfields/qual/InitializedFieldsBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/initializedfields/qual/PolyInitializedFields 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/reflection/qual/ClassBound 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/reflection/qual/ClassVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/reflection/qual/ClassValBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/reflection/qual/ForName 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/common/reflection/qual/GetClass 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/common/reflection/qual/GetConstructor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/common/reflection/qual/GetMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/common/reflection/qual/Invoke 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/common/reflection/qual/MethodVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract className ()[Ljava/lang/String; - -
 method public,abstract methodName ()[Ljava/lang/String; - -
 method public,abstract params ()[I - -
in 1102
class org/checkerframework/common/reflection/qual/MethodValBottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/reflection/qual/NewInstance 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/common/reflection/qual/UnknownClass 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/reflection/qual/UnknownMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/returnsreceiver/qual/BottomThis 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/returnsreceiver/qual/This 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/returnsreceiver/qual/UnknownThis 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/subtyping/qual/Bottom 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/subtyping/qual/Unqualified 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportCall 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportCreation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportInherit 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportOverride 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportReadWrite 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportUnqualified 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportUse 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PACKAGE,ELjava/lang/annotation/ElementType;#TYPE])
in 1105
class org/checkerframework/common/util/count/report/qual/ReportWrite 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 1104
class org/checkerframework/common/util/report/qual/ReportCall 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1104
class org/checkerframework/common/util/report/qual/ReportCreation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1104
class org/checkerframework/common/util/report/qual/ReportInherit 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
in 1104
class org/checkerframework/common/util/report/qual/ReportOverride 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1104
class org/checkerframework/common/util/report/qual/ReportReadWrite 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 1104
class org/checkerframework/common/util/report/qual/ReportUnqualified 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1104
class org/checkerframework/common/util/report/qual/ReportUse 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PACKAGE,ELjava/lang/annotation/ElementType;#TYPE])
in 1104
class org/checkerframework/common/util/report/qual/ReportWrite 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 1102
class org/checkerframework/common/value/qual/ArrayLen 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[I - -
in 1102
class org/checkerframework/common/value/qual/ArrayLenRange 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract from ()I - - I0
 method public,abstract to ()I - - I2147483647
in 1102
class org/checkerframework/common/value/qual/BoolVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[Z - -
in 1102
class org/checkerframework/common/value/qual/BottomVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1103
class org/checkerframework/common/value/qual/DoesNotMatchRegex 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/value/qual/DoubleVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[D - -
in 1104
class org/checkerframework/common/value/qual/EnsuresMinLenIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/common/value/qual/EnsuresMinLenIf$List org/checkerframework/common/value/qual/EnsuresMinLenIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/common/value/qual/EnsuresMinLenIf$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract result ()Z - -
 method public,abstract targetValue ()I - - I0
in 1105
class org/checkerframework/common/value/qual/EnsuresMinLenIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/common/value/qual/EnsuresMinLenIf$List org/checkerframework/common/value/qual/EnsuresMinLenIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/common/value/qual/EnsuresMinLenIf$List;)
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract targetValue ()I - - I0
in 1102
class org/checkerframework/common/value/qual/EnsuresMinLenIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/common/value/qual/EnsuresMinLenIf$List org/checkerframework/common/value/qual/EnsuresMinLenIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/common/value/qual/EnsuresMinLenIf; - -
in 1102
class org/checkerframework/common/value/qual/EnumVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/value/qual/IntRange 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract from ()J - - J-9223372036854775808
 method public,abstract to ()J - - J9223372036854775807
in 1102
class org/checkerframework/common/value/qual/IntRangeFromGTENegativeOne 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/common/value/qual/IntRangeFromNonNegative 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/common/value/qual/IntRangeFromPositive 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[])
in 1102
class org/checkerframework/common/value/qual/IntVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[J - -
in 1102
class org/checkerframework/common/value/qual/MatchesRegex 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/value/qual/MinLen 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
 method public,abstract value ()I - - I0
in 1102
class org/checkerframework/common/value/qual/MinLenFieldInvariant 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Inherited;()
 method public,abstract minLen ()[I - -
 method public,abstract field ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/value/qual/PolyValue 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/common/value/qual/StaticallyExecutable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1102
class org/checkerframework/common/value/qual/StringVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/common/value/qual/UnknownVal 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_PARAMETER,ELjava/lang/annotation/ElementType;#TYPE_USE])
in 1105
class org/checkerframework/dataflow/qual/AssertMethod 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/AssertionError;
 method public,abstract parameter ()I - - I1
 method public,abstract isAssertFalse ()Z - - Z0
in 1102
class org/checkerframework/dataflow/qual/Deterministic 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1105
class org/checkerframework/dataflow/qual/Impure 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1102
class org/checkerframework/dataflow/qual/Pure 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/dataflow/qual/Pure$Kind org/checkerframework/dataflow/qual/Pure Kind public,static,final,enum
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1102
class org/checkerframework/dataflow/qual/Pure$Kind 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/checkerframework/dataflow/qual/Pure$Kind;>;
 inner org/checkerframework/dataflow/qual/Pure$Kind org/checkerframework/dataflow/qual/Pure Kind public,static,final,enum
 field public,static,final,enum SIDE_EFFECT_FREE Lorg/checkerframework/dataflow/qual/Pure$Kind; -
 field public,static,final,enum DETERMINISTIC Lorg/checkerframework/dataflow/qual/Pure$Kind; -
 method public,static values ()[Lorg/checkerframework/dataflow/qual/Pure$Kind; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/checkerframework/dataflow/qual/Pure$Kind; - -
in 1102
class org/checkerframework/dataflow/qual/SideEffectFree 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1102
class org/checkerframework/dataflow/qual/TerminatesExecution 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1102
class org/checkerframework/framework/qual/AnnotatedFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#PACKAGE])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/framework/qual/CFComment 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/framework/qual/ConditionalPostconditionAnnotation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract qualifier ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/Covariant 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()[I - -
in 1102
class org/checkerframework/framework/qual/DefaultFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()[Lorg/checkerframework/framework/qual/TypeUseLocation; - - []
 method public,abstract typeKinds ()[Lorg/checkerframework/framework/qual/TypeKind; - - []
 method public,abstract types ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; - []
 method public,abstract names ()[Ljava/lang/String; - - []
 method public,abstract namesExceptions ()[Ljava/lang/String; - - []
in 1107
class org/checkerframework/framework/qual/DefaultQualifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/DefaultQualifier$List org/checkerframework/framework/qual/DefaultQualifier List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PACKAGE,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#PARAMETER])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/framework/qual/DefaultQualifier$List;)
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
 method public,abstract locations ()[Lorg/checkerframework/framework/qual/TypeUseLocation; - - [ELorg/checkerframework/framework/qual/TypeUseLocation;#ALL]
in 483
class org/checkerframework/framework/qual/DefaultQualifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/DefaultQualifier$List org/checkerframework/framework/qual/DefaultQualifier List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PACKAGE,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#PARAMETER])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/framework/qual/DefaultQualifier$List;)
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
 method public,abstract locations ()[Lorg/checkerframework/framework/qual/TypeUseLocation; - - [ELorg/checkerframework/framework/qual/TypeUseLocation;#ALL]
in 1102
class org/checkerframework/framework/qual/DefaultQualifier$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/DefaultQualifier$List org/checkerframework/framework/qual/DefaultQualifier List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PACKAGE,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#PARAMETER])
 method public,abstract value ()[Lorg/checkerframework/framework/qual/DefaultQualifier; - -
in 1102
class org/checkerframework/framework/qual/DefaultQualifierForUse 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; - []
in 1102
class org/checkerframework/framework/qual/DefaultQualifierInHierarchy 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
in 1102
class org/checkerframework/framework/qual/EnsuresQualifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/EnsuresQualifier$List org/checkerframework/framework/qual/EnsuresQualifier List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/framework/qual/EnsuresQualifier$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract qualifier ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/EnsuresQualifier$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/EnsuresQualifier$List org/checkerframework/framework/qual/EnsuresQualifier List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/framework/qual/EnsuresQualifier; - -
in 1104
class org/checkerframework/framework/qual/EnsuresQualifierIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/EnsuresQualifierIf$List org/checkerframework/framework/qual/EnsuresQualifierIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/framework/qual/EnsuresQualifierIf$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract qualifier ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
 method public,abstract result ()Z - -
in 1105
class org/checkerframework/framework/qual/EnsuresQualifierIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/EnsuresQualifierIf$List org/checkerframework/framework/qual/EnsuresQualifierIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/framework/qual/EnsuresQualifierIf$List;)
 method public,abstract result ()Z - -
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract qualifier ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/EnsuresQualifierIf$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/EnsuresQualifierIf$List org/checkerframework/framework/qual/EnsuresQualifierIf List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract value ()[Lorg/checkerframework/framework/qual/EnsuresQualifierIf; - -
in 1102
class org/checkerframework/framework/qual/FieldInvariant 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Inherited;()
 method public,abstract qualifier ()[Ljava/lang/Class; ()[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
 method public,abstract field ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/framework/qual/FromByteCode 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1102
class org/checkerframework/framework/qual/FromStubFile 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
in 1102
class org/checkerframework/framework/qual/HasQualifierParameter 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Inherited;()
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/IgnoreInWholeProgramInference 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#FIELD])
in 1102
class org/checkerframework/framework/qual/InheritedAnnotation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
in 1102
class org/checkerframework/framework/qual/InvisibleQualifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
in 1102
class org/checkerframework/framework/qual/JavaExpression 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
in 1102
class org/checkerframework/framework/qual/LiteralKind 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/checkerframework/framework/qual/LiteralKind;>;
 field public,static,final,enum NULL Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum INT Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum LONG Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum FLOAT Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum DOUBLE Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum BOOLEAN Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum CHAR Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum STRING Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum ALL Lorg/checkerframework/framework/qual/LiteralKind; -
 field public,static,final,enum PRIMITIVE Lorg/checkerframework/framework/qual/LiteralKind; -
 method public,static values ()[Lorg/checkerframework/framework/qual/LiteralKind; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/checkerframework/framework/qual/LiteralKind; - -
 method public,static allLiteralKinds ()Ljava/util/List; ()Ljava/util/List<Lorg/checkerframework/framework/qual/LiteralKind;>; -
 method public,static primitiveLiteralKinds ()Ljava/util/List; ()Ljava/util/List<Lorg/checkerframework/framework/qual/LiteralKind;>; -
in 1102
class org/checkerframework/framework/qual/MonotonicQualifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/NoDefaultQualifierForUse 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; - []
in 1102
class org/checkerframework/framework/qual/NoQualifierParameter 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Inherited;()
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/PolymorphicQualifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; - TLjava/lang/annotation/Annotation;
in 1102
class org/checkerframework/framework/qual/PostconditionAnnotation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract qualifier ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/PreconditionAnnotation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract qualifier ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/PurityUnqualified 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE,ELjava/lang/annotation/ElementType;#TYPE_PARAMETER])
in 1102
class org/checkerframework/framework/qual/QualifierArgument 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract value ()Ljava/lang/String; - - ""
in 1102
class org/checkerframework/framework/qual/QualifierForLiterals 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()[Lorg/checkerframework/framework/qual/LiteralKind; - - []
 method public,abstract stringPatterns ()[Ljava/lang/String; - - []
in 1102
class org/checkerframework/framework/qual/RelevantJavaTypes 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Inherited;()
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; -
in 1102
class org/checkerframework/framework/qual/RequiresQualifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/RequiresQualifier$List org/checkerframework/framework/qual/RequiresQualifier List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLorg/checkerframework/framework/qual/RequiresQualifier$List;)
 method public,abstract expression ()[Ljava/lang/String; - -
 method public,abstract qualifier ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/RequiresQualifier$List 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/checkerframework/framework/qual/RequiresQualifier$List org/checkerframework/framework/qual/RequiresQualifier List public,static,interface,abstract,annotation
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 method public,abstract value ()[Lorg/checkerframework/framework/qual/RequiresQualifier; - -
in 1102
class org/checkerframework/framework/qual/StubFiles 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()[Ljava/lang/String; - -
in 1102
class org/checkerframework/framework/qual/SubtypeOf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/TargetLocations 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()[Lorg/checkerframework/framework/qual/TypeUseLocation; - -
in 1102
class org/checkerframework/framework/qual/TypeKind 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/checkerframework/framework/qual/TypeKind;>;
 field public,static,final,enum BOOLEAN Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum BYTE Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum SHORT Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum INT Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum LONG Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum CHAR Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum FLOAT Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum DOUBLE Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum VOID Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum NONE Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum NULL Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum ARRAY Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum DECLARED Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum ERROR Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum TYPEVAR Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum WILDCARD Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum PACKAGE Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum EXECUTABLE Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum OTHER Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum UNION Lorg/checkerframework/framework/qual/TypeKind; -
 field public,static,final,enum INTERSECTION Lorg/checkerframework/framework/qual/TypeKind; -
 method public,static values ()[Lorg/checkerframework/framework/qual/TypeKind; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/checkerframework/framework/qual/TypeKind; - -
in 1102
class org/checkerframework/framework/qual/TypeUseLocation 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/checkerframework/framework/qual/TypeUseLocation;>;
 field public,static,final,enum FIELD Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum LOCAL_VARIABLE Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum RESOURCE_VARIABLE Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum EXCEPTION_PARAMETER Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum RECEIVER Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum PARAMETER Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum RETURN Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum CONSTRUCTOR_RESULT Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum LOWER_BOUND Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum EXPLICIT_LOWER_BOUND Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum IMPLICIT_LOWER_BOUND Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum UPPER_BOUND Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum EXPLICIT_UPPER_BOUND Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum IMPLICIT_UPPER_BOUND Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum OTHERWISE Lorg/checkerframework/framework/qual/TypeUseLocation; -
 field public,static,final,enum ALL Lorg/checkerframework/framework/qual/TypeUseLocation; -
 method public,static values ()[Lorg/checkerframework/framework/qual/TypeUseLocation; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/checkerframework/framework/qual/TypeUseLocation; - -
in 1102
class org/checkerframework/framework/qual/Unused 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract when ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/lang/annotation/Annotation;>; -
in 1102
class org/checkerframework/framework/qual/UpperBoundFor 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract typeKinds ()[Lorg/checkerframework/framework/qual/TypeKind; - - []
 method public,abstract types ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; - []
