cg-stub-db 1
in 24
class net/minecraft/item/EnumAction 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/EnumAction;>;
 field public,static,final,enum NONE Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum EAT Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum DRINK Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum BLOCK Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum BOW Lnet/minecraft/item/EnumAction; -
 method public,static values ()[Lnet/minecraft/item/EnumAction; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/EnumAction; - -
in 326
class net/minecraft/item/EnumAction 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/EnumAction;>;
 field public,static,final,enum NONE Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum EAT Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum DRINK Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum BLOCK Lnet/minecraft/item/EnumAction; -
 field public,static,final,enum BOW Lnet/minecraft/item/EnumAction; -
 method public,static values ()[Lnet/minecraft/item/EnumAction; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/EnumAction; - -
in 24
class net/minecraft/item/EnumDyeColor 50 public,final,super,enum java/lang/Enum net/minecraft/util/IStringSerializable Ljava/lang/Enum<Lnet/minecraft/item/EnumDyeColor;>;Lnet/minecraft/util/IStringSerializable;
 field public,static,final,enum WHITE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum ORANGE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum MAGENTA Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum LIGHT_BLUE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum YELLOW Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum LIME Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum PINK Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum GRAY Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum SILVER Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum CYAN Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum PURPLE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum BLUE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum BROWN Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum GREEN Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum RED Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum BLACK Lnet/minecraft/item/EnumDyeColor; -
 method public,static values ()[Lnet/minecraft/item/EnumDyeColor; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/EnumDyeColor; - -
 method public getMetadata ()I - -
 method public getDyeDamage ()I - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public getMapColor ()Lnet/minecraft/block/material/MapColor; - -
 method public,static byDyeDamage (I)Lnet/minecraft/item/EnumDyeColor; - -
 method public,static byMetadata (I)Lnet/minecraft/item/EnumDyeColor; - -
 method public toString ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
in 326
class net/minecraft/item/EnumDyeColor 52 public,final,super,enum java/lang/Enum net/minecraft/util/IStringSerializable Ljava/lang/Enum<Lnet/minecraft/item/EnumDyeColor;>;Lnet/minecraft/util/IStringSerializable;
 field public,static,final,enum WHITE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum ORANGE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum MAGENTA Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum LIGHT_BLUE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum YELLOW Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum LIME Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum PINK Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum GRAY Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum SILVER Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum CYAN Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum PURPLE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum BLUE Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum BROWN Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum GREEN Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum RED Lnet/minecraft/item/EnumDyeColor; -
 field public,static,final,enum BLACK Lnet/minecraft/item/EnumDyeColor; -
 method public,static values ()[Lnet/minecraft/item/EnumDyeColor; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/EnumDyeColor; - -
 method public getMetadata ()I - -
 method public getDyeDamage ()I - -
 method public getDyeColorName ()Ljava/lang/String; - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getColorValue ()I - -
 method public getColorComponentValues ()[F - -
 method public,static byDyeDamage (I)Lnet/minecraft/item/EnumDyeColor; - -
 method public,static byMetadata (I)Lnet/minecraft/item/EnumDyeColor; - -
 method public toString ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
in 90
class net/minecraft/item/EnumRarity 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/EnumRarity;>;
 field public,static,final,enum COMMON Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum UNCOMMON Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum RARE Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum EPIC Lnet/minecraft/item/EnumRarity; -
 field public,final rarityColor Lnet/minecraft/util/EnumChatFormatting; -
 field public,final rarityName Ljava/lang/String; -
 method public,static values ()[Lnet/minecraft/item/EnumRarity; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/EnumRarity; - -
in 91
class net/minecraft/item/EnumRarity 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/EnumRarity;>;
 field public,static,final,enum COMMON Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum UNCOMMON Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum RARE Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum EPIC Lnet/minecraft/item/EnumRarity; -
 field public,final rarityColor Lnet/minecraft/util/text/TextFormatting; -
 field public,final rarityName Ljava/lang/String; -
 method public,static values ()[Lnet/minecraft/item/EnumRarity; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/EnumRarity; - -
in 326
class net/minecraft/item/EnumRarity 52 public,final,super,enum java/lang/Enum net/minecraftforge/common/IRarity Ljava/lang/Enum<Lnet/minecraft/item/EnumRarity;>;Lnet/minecraftforge/common/IRarity;
 field public,static,final,enum COMMON Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum UNCOMMON Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum RARE Lnet/minecraft/item/EnumRarity; -
 field public,static,final,enum EPIC Lnet/minecraft/item/EnumRarity; -
 field public,final color Lnet/minecraft/util/text/TextFormatting; -
 field public,final rarityName Ljava/lang/String; -
 method public,static values ()[Lnet/minecraft/item/EnumRarity; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/EnumRarity; - -
 method public getColor ()Lnet/minecraft/util/text/TextFormatting; - -
 method public getName ()Ljava/lang/String; - -
in 91
class net/minecraft/item/IItemPropertyGetter 50 public,interface,abstract java/lang/Object - -
 method public,abstract apply (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)F - -
in 326
class net/minecraft/item/IItemPropertyGetter 52 public,interface,abstract java/lang/Object - -
 method public,abstract apply (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)F - -
in 90
class net/minecraft/item/Item 50 public,super java/lang/Object - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 field public,static,final itemRegistry Lnet/minecraft/util/RegistryNamespaced; Lnet/minecraft/util/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/item/Item;>;
 field protected,static,final itemModifierUUID Ljava/util/UUID; -
 field protected,static itemRand Ljava/util/Random; -
 field protected maxStackSize I -
 field protected bFull3D Z -
 field protected hasSubtypes Z -
 field public,final delegate Lnet/minecraftforge/fml/common/registry/RegistryDelegate; Lnet/minecraftforge/fml/common/registry/RegistryDelegate<Lnet/minecraft/item/Item;>;
 field protected canRepair Z -
 method public <init> ()V - -
 method public,static getIdFromItem (Lnet/minecraft/item/Item;)I - -
 method public,static getItemById (I)Lnet/minecraft/item/Item; - -
 method public,static getItemFromBlock (Lnet/minecraft/block/Block;)Lnet/minecraft/item/Item; - -
 method public,static getByNameOrId (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public updateItemStackNBT (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public setMaxStackSize (I)Lnet/minecraft/item/Item; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/Block;)F - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public,deprecated getItemStackLimit ()I - -
 method public getMetadata (I)I - -
 method public getHasSubtypes ()Z - -
 method public setHasSubtypes (Z)Lnet/minecraft/item/Item; - -
 method public getMaxDamage ()I - -
 method public setMaxDamage (I)Lnet/minecraft/item/Item; - -
 method public isDamageable ()Z - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;)Z - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public setFull3D ()Lnet/minecraft/item/Item; - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public setUnlocalizedName (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public getUnlocalizedNameInefficiently (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public setContainerItem (Lnet/minecraft/item/Item;)Lnet/minecraft/item/Item; - -
 method public getShareTag ()Z - -
 method public getContainerItem ()Lnet/minecraft/item/Item; - -
 method public,deprecated hasContainerItem ()Z - -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public onUpdate (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public onCreated (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isMap ()Z - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public onPlayerStoppedUsing (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;I)V - -
 method public setPotionEffect (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public getPotionEffect (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public isPotionIngredient (Lnet/minecraft/item/ItemStack;)Z - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public isItemTool (Lnet/minecraft/item/ItemStack;)Z - -
 method protected getMovingObjectPositionFromPlayer (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Z)Lnet/minecraft/util/MovingObjectPosition; - -
 method public getItemEnchantability ()I - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public setCreativeTab (Lnet/minecraft/creativetab/CreativeTabs;)Lnet/minecraft/item/Item; - -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public canItemEditBlocks ()Z - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,deprecated getItemAttributeModifiers ()Lcom/google/common/collect/Multimap; ()Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getAttributeModifiers (Lnet/minecraft/item/ItemStack;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/item/ItemStack;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public onDroppedByPlayer (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getHighlightTip (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)Ljava/lang/String; - -
 method public onItemUseFirst (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getDigSpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public isRepairable ()Z - -
 method public setNoRepair ()Lnet/minecraft/item/Item; - -
 method public onBlockStartBreak (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onUsingTick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;I)V - -
 method public onLeftClickEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;)Z - -
 method public getModel (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/client/resources/model/ModelResourceLocation; - -
 method public getContainerItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public hasContainerItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getEntityLifespan (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)I - -
 method public hasCustomEntity (Lnet/minecraft/item/ItemStack;)Z - -
 method public createEntity (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/Entity; - -
 method public onEntityItemUpdate (Lnet/minecraft/entity/item/EntityItem;)Z - -
 method public getCreativeTabs ()[Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getSmeltingExperience (Lnet/minecraft/item/ItemStack;)F - -
 method public getChestGenBase (Lnet/minecraftforge/common/ChestGenHooks;Ljava/util/Random;Lnet/minecraft/util/WeightedRandomChestContent;)Lnet/minecraft/util/WeightedRandomChestContent; - -
 method public doesSneakBypassUse (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onArmorTick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public isValidArmor (Lnet/minecraft/item/ItemStack;ILnet/minecraft/entity/Entity;)Z - -
 method public isBookEnchantable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getArmorTexture (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/Entity;ILjava/lang/String;)Ljava/lang/String; - -
 method public getFontRenderer (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/client/gui/FontRenderer; - -
 method public,deprecated getArmorModel (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;I)Lnet/minecraft/client/model/ModelBiped; - -
 method public getArmorModel (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;ILnet/minecraft/client/model/ModelBiped;)Lnet/minecraft/client/model/ModelBiped; - -
 method public onEntitySwing (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;)Z - -
 method public renderHelmetOverlay (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/client/gui/ScaledResolution;F)V - -
 method public getDamage (Lnet/minecraft/item/ItemStack;)I - -
 method public getMetadata (Lnet/minecraft/item/ItemStack;)I - -
 method public showDurabilityBar (Lnet/minecraft/item/ItemStack;)Z - -
 method public getDurabilityForDisplay (Lnet/minecraft/item/ItemStack;)D - -
 method public getMaxDamage (Lnet/minecraft/item/ItemStack;)I - -
 method public isDamaged (Lnet/minecraft/item/ItemStack;)Z - -
 method public setDamage (Lnet/minecraft/item/ItemStack;I)V - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public setHarvestLevel (Ljava/lang/String;I)V - -
 method public getToolClasses (Lnet/minecraft/item/ItemStack;)Ljava/util/Set; (Lnet/minecraft/item/ItemStack;)Ljava/util/Set<Ljava/lang/String;>; -
 method public getHarvestLevel (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)I - -
 method public getItemEnchantability (Lnet/minecraft/item/ItemStack;)I - -
 method public isBeaconPayment (Lnet/minecraft/item/ItemStack;)Z - -
 method public shouldCauseReequipAnimation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Z)Z - -
 method public,final setRegistryName (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public,final setRegistryName (Lnet/minecraft/util/ResourceLocation;)Lnet/minecraft/item/Item; - -
 method public,final setRegistryName (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public,final getRegistryName ()Ljava/lang/String; - -
 method public initCapabilities (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
 method public,static registerItems ()V - -
 method protected,static registerItemBlock (Lnet/minecraft/block/Block;Lnet/minecraft/item/Item;)V - -
in 91
class net/minecraft/item/Item 50 public,super net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl - Lnet/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl<Lnet/minecraft/item/Item;>;
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl net/minecraftforge/fml/common/registry/IForgeRegistryEntry Impl public,static
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespaced; Lnet/minecraft/util/registry/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/item/Item;>;
 field protected,static,final ATTACK_DAMAGE_MODIFIER Ljava/util/UUID; -
 field protected,static,final ATTACK_SPEED_MODIFIER Ljava/util/UUID; -
 field protected,static itemRand Ljava/util/Random; -
 field protected maxStackSize I -
 field protected bFull3D Z -
 field protected hasSubtypes Z -
 field protected canRepair Z -
 method public,static getIdFromItem (Lnet/minecraft/item/Item;)I - -
 method public,static getItemById (I)Lnet/minecraft/item/Item; - -
 method public,static getItemFromBlock (Lnet/minecraft/block/Block;)Lnet/minecraft/item/Item; - -
 method public,static getByNameOrId (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public,final addPropertyOverride (Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/item/IItemPropertyGetter;)V - -
 method public getPropertyGetter (Lnet/minecraft/util/ResourceLocation;)Lnet/minecraft/item/IItemPropertyGetter; - -
 method public updateItemStackNBT (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public hasCustomProperties ()Z - -
 method public <init> ()V - -
 method public setMaxStackSize (I)Lnet/minecraft/item/Item; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public,deprecated getItemStackLimit ()I - -
 method public getMetadata (I)I - -
 method public getHasSubtypes ()Z - -
 method public setHasSubtypes (Z)Lnet/minecraft/item/Item; - -
 method public,deprecated getMaxDamage ()I - -
 method public setMaxDamage (I)Lnet/minecraft/item/Item; - -
 method public isDamageable ()Z - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public setFull3D ()Lnet/minecraft/item/Item; - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public setUnlocalizedName (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public getUnlocalizedNameInefficiently (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public setContainerItem (Lnet/minecraft/item/Item;)Lnet/minecraft/item/Item; - -
 method public getShareTag ()Z - -
 method public getContainerItem ()Lnet/minecraft/item/Item; - -
 method public,deprecated hasContainerItem ()Z - -
 method public onUpdate (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public onCreated (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isMap ()Z - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public onPlayerStoppedUsing (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public isEnchantable (Lnet/minecraft/item/ItemStack;)Z - -
 method protected rayTrace (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Z)Lnet/minecraft/util/math/RayTraceResult; - -
 method public getItemEnchantability ()I - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public setCreativeTab (Lnet/minecraft/creativetab/CreativeTabs;)Lnet/minecraft/item/Item; - -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public canItemEditBlocks ()Z - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,deprecated getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public onDroppedByPlayer (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getHighlightTip (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)Ljava/lang/String; - -
 method public onItemUseFirst (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;FFFLnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method public isRepairable ()Z - -
 method public setNoRepair ()Lnet/minecraft/item/Item; - -
 method public getNBTShareTag (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public onBlockStartBreak (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onUsingTick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public onLeftClickEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;)Z - -
 method public getContainerItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public hasContainerItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getEntityLifespan (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)I - -
 method public hasCustomEntity (Lnet/minecraft/item/ItemStack;)Z - -
 method public createEntity (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/Entity; - -
 method public onEntityItemUpdate (Lnet/minecraft/entity/item/EntityItem;)Z - -
 method public getCreativeTabs ()[Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getSmeltingExperience (Lnet/minecraft/item/ItemStack;)F - -
 method public doesSneakBypassUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onArmorTick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public isValidArmor (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/entity/Entity;)Z - -
 method public isBookEnchantable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getArmorTexture (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/Entity;Lnet/minecraft/inventory/EntityEquipmentSlot;Ljava/lang/String;)Ljava/lang/String; - -
 method public getFontRenderer (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/client/gui/FontRenderer; - -
 method public getArmorModel (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/client/model/ModelBiped;)Lnet/minecraft/client/model/ModelBiped; - -
 method public onEntitySwing (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;)Z - -
 method public renderHelmetOverlay (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/client/gui/ScaledResolution;F)V - -
 method public getDamage (Lnet/minecraft/item/ItemStack;)I - -
 method public getMetadata (Lnet/minecraft/item/ItemStack;)I - -
 method public showDurabilityBar (Lnet/minecraft/item/ItemStack;)Z - -
 method public getDurabilityForDisplay (Lnet/minecraft/item/ItemStack;)D - -
 method public getMaxDamage (Lnet/minecraft/item/ItemStack;)I - -
 method public isDamaged (Lnet/minecraft/item/ItemStack;)Z - -
 method public setDamage (Lnet/minecraft/item/ItemStack;I)V - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public setHarvestLevel (Ljava/lang/String;I)V - -
 method public getToolClasses (Lnet/minecraft/item/ItemStack;)Ljava/util/Set; (Lnet/minecraft/item/ItemStack;)Ljava/util/Set<Ljava/lang/String;>; -
 method public,deprecated getHarvestLevel (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)I - -
 method public getHarvestLevel (Lnet/minecraft/item/ItemStack;Ljava/lang/String;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/block/state/IBlockState;)I - -
 method public getItemEnchantability (Lnet/minecraft/item/ItemStack;)I - -
 method public isBeaconPayment (Lnet/minecraft/item/ItemStack;)Z - -
 method public shouldCauseReequipAnimation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Z)Z - -
 method public shouldCauseBlockBreakReset (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public initCapabilities (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
 method public getAnimationParameters (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lcom/google/common/collect/ImmutableMap; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lcom/google/common/collect/ImmutableMap<Ljava/lang/String;Lnet/minecraftforge/common/animation/ITimeValue;>; -
 method public,static registerItems ()V - -
 method protected,static registerItemBlock (Lnet/minecraft/block/Block;Lnet/minecraft/item/Item;)V - -
in 326
class net/minecraft/item/Item 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl - Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/Item;>;
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 inner net/minecraft/item/ItemMultiTexture$Mapper net/minecraft/item/ItemMultiTexture Mapper public,static,interface,abstract
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespaced; Lnet/minecraft/util/registry/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/item/Item;>;
 field protected,static,final ATTACK_DAMAGE_MODIFIER Ljava/util/UUID; -
 field protected,static,final ATTACK_SPEED_MODIFIER Ljava/util/UUID; -
 field protected,static itemRand Ljava/util/Random; -
 field protected maxStackSize I -
 field protected bFull3D Z -
 field protected hasSubtypes Z -
 field protected canRepair Z -
 method public,static getIdFromItem (Lnet/minecraft/item/Item;)I - -
 method public,static getItemById (I)Lnet/minecraft/item/Item; - -
 method public,static getItemFromBlock (Lnet/minecraft/block/Block;)Lnet/minecraft/item/Item; - -
 method public,static getByNameOrId (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public,final addPropertyOverride (Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/item/IItemPropertyGetter;)V - -
 method public getPropertyGetter (Lnet/minecraft/util/ResourceLocation;)Lnet/minecraft/item/IItemPropertyGetter; - -
 method public updateItemStackNBT (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public hasCustomProperties ()Z - -
 method public <init> ()V - -
 method public setMaxStackSize (I)Lnet/minecraft/item/Item; - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getDestroySpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public,deprecated getItemStackLimit ()I - -
 method public getMetadata (I)I - -
 method public getHasSubtypes ()Z - -
 method public setHasSubtypes (Z)Lnet/minecraft/item/Item; - -
 method public,deprecated getMaxDamage ()I - -
 method public setMaxDamage (I)Lnet/minecraft/item/Item; - -
 method public isDamageable ()Z - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public setFull3D ()Lnet/minecraft/item/Item; - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public setTranslationKey (Ljava/lang/String;)Lnet/minecraft/item/Item; - -
 method public getUnlocalizedNameInefficiently (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public setContainerItem (Lnet/minecraft/item/Item;)Lnet/minecraft/item/Item; - -
 method public getShareTag ()Z - -
 method public getContainerItem ()Lnet/minecraft/item/Item; - -
 method public,deprecated hasContainerItem ()Z - -
 method public onUpdate (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public onCreated (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isMap ()Z - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public onPlayerStoppedUsing (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public,deprecated getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public isEnchantable (Lnet/minecraft/item/ItemStack;)Z - -
 method protected rayTrace (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Z)Lnet/minecraft/util/math/RayTraceResult; - -
 method public getItemEnchantability ()I - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method protected isInCreativeTab (Lnet/minecraft/creativetab/CreativeTabs;)Z - -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public setCreativeTab (Lnet/minecraft/creativetab/CreativeTabs;)Lnet/minecraft/item/Item; - -
 method public canItemEditBlocks ()Z - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,deprecated getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public onDroppedByPlayer (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getHighlightTip (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)Ljava/lang/String; - -
 method public onItemUseFirst (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;FFFLnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method public isRepairable ()Z - -
 method public setNoRepair ()Lnet/minecraft/item/Item; - -
 method public getXpRepairRatio (Lnet/minecraft/item/ItemStack;)F - -
 method public getNBTShareTag (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readNBTShareTag (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onBlockStartBreak (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onUsingTick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public onLeftClickEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/Entity;)Z - -
 method public getContainerItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public hasContainerItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getEntityLifespan (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)I - -
 method public hasCustomEntity (Lnet/minecraft/item/ItemStack;)Z - -
 method public createEntity (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/Entity; - -
 method public onEntityItemUpdate (Lnet/minecraft/entity/item/EntityItem;)Z - -
 method public getCreativeTabs ()[Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getSmeltingExperience (Lnet/minecraft/item/ItemStack;)F - -
 method public doesSneakBypassUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onArmorTick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public isValidArmor (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/entity/Entity;)Z - -
 method public getEquipmentSlot (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public isBookEnchantable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getArmorTexture (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/Entity;Lnet/minecraft/inventory/EntityEquipmentSlot;Ljava/lang/String;)Ljava/lang/String; - -
 method public getFontRenderer (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/client/gui/FontRenderer; - -
 method public getArmorModel (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/client/model/ModelBiped;)Lnet/minecraft/client/model/ModelBiped; - -
 method public onEntitySwing (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;)Z - -
 method public renderHelmetOverlay (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/client/gui/ScaledResolution;F)V - -
 method public getDamage (Lnet/minecraft/item/ItemStack;)I - -
 method public getMetadata (Lnet/minecraft/item/ItemStack;)I - -
 method public showDurabilityBar (Lnet/minecraft/item/ItemStack;)Z - -
 method public getDurabilityForDisplay (Lnet/minecraft/item/ItemStack;)D - -
 method public getRGBDurabilityForDisplay (Lnet/minecraft/item/ItemStack;)I - -
 method public getMaxDamage (Lnet/minecraft/item/ItemStack;)I - -
 method public isDamaged (Lnet/minecraft/item/ItemStack;)Z - -
 method public setDamage (Lnet/minecraft/item/ItemStack;I)V - -
 method public canDestroyBlockInCreative (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public setHarvestLevel (Ljava/lang/String;I)V - -
 method public getToolClasses (Lnet/minecraft/item/ItemStack;)Ljava/util/Set; (Lnet/minecraft/item/ItemStack;)Ljava/util/Set<Ljava/lang/String;>; -
 method public getHarvestLevel (Lnet/minecraft/item/ItemStack;Ljava/lang/String;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/block/state/IBlockState;)I - -
 method public getItemEnchantability (Lnet/minecraft/item/ItemStack;)I - -
 method public canApplyAtEnchantingTable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public isBeaconPayment (Lnet/minecraft/item/ItemStack;)Z - -
 method public shouldCauseReequipAnimation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Z)Z - -
 method public shouldCauseBlockBreakReset (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public canContinueUsing (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getCreatorModId (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public initCapabilities (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
 method public getAnimationParameters (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lcom/google/common/collect/ImmutableMap; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lcom/google/common/collect/ImmutableMap<Ljava/lang/String;Lnet/minecraftforge/common/animation/ITimeValue;>; -
 method public canDisableShield (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public isShield (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getItemBurnTime (Lnet/minecraft/item/ItemStack;)I - -
 method public getHorseArmorType (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public getHorseArmorTexture (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onHorseArmorTick (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/item/ItemStack;)V - -
 method public,final getTileEntityItemStackRenderer ()Lnet/minecraft/client/renderer/tileentity/TileEntityItemStackRenderer; - -
 method public setTileEntityItemStackRenderer (Lnet/minecraft/client/renderer/tileentity/TileEntityItemStackRenderer;)V - -
 method public getForgeRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraftforge/common/IRarity; - -
 method public,static registerItems ()V - -
 method protected,static registerItemBlock (Lnet/minecraft/block/Block;Lnet/minecraft/item/Item;)V - -
 method public getDefaultInstance ()Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/item/Item$ToolMaterial 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/Item$ToolMaterial;>;
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 field public,static,final,enum WOOD Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum STONE Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum IRON Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum EMERALD Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum GOLD Lnet/minecraft/item/Item$ToolMaterial; -
 field public,deprecated customCraftingMaterial Lnet/minecraft/item/Item; -
 method public,static values ()[Lnet/minecraft/item/Item$ToolMaterial; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getMaxUses ()I - -
 method public getEfficiencyOnProperMaterial ()F - -
 method public getDamageVsEntity ()F - -
 method public getHarvestLevel ()I - -
 method public getEnchantability ()I - -
 method public,deprecated getRepairItem ()Lnet/minecraft/item/Item; - -
 method public setRepairItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getRepairItemStack ()Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/Item$ToolMaterial 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/Item$ToolMaterial;>;
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 field public,static,final,enum WOOD Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum STONE Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum IRON Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum DIAMOND Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum GOLD Lnet/minecraft/item/Item$ToolMaterial; -
 field public,deprecated customCraftingMaterial Lnet/minecraft/item/Item; -
 method public,static values ()[Lnet/minecraft/item/Item$ToolMaterial; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getMaxUses ()I - -
 method public getEfficiencyOnProperMaterial ()F - -
 method public getDamageVsEntity ()F - -
 method public getHarvestLevel ()I - -
 method public getEnchantability ()I - -
 method public,deprecated getRepairItem ()Lnet/minecraft/item/Item; - -
 method public setRepairItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getRepairItemStack ()Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/Item$ToolMaterial 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/Item$ToolMaterial;>;
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 field public,static,final,enum WOOD Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum STONE Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum IRON Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum DIAMOND Lnet/minecraft/item/Item$ToolMaterial; -
 field public,static,final,enum GOLD Lnet/minecraft/item/Item$ToolMaterial; -
 method public,static values ()[Lnet/minecraft/item/Item$ToolMaterial; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getMaxUses ()I - -
 method public getEfficiency ()F - -
 method public getAttackDamage ()F - -
 method public getHarvestLevel ()I - -
 method public getEnchantability ()I - -
 method public,deprecated getRepairItem ()Lnet/minecraft/item/Item; - -
 method public setRepairItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getRepairItemStack ()Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/ItemAir 52 public,super net/minecraft/item/Item - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
in 24
class net/minecraft/item/ItemAnvilBlock 50 public,super net/minecraft/item/ItemMultiTexture - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public getMetadata (I)I - -
in 326
class net/minecraft/item/ItemAnvilBlock 52 public,super net/minecraft/item/ItemMultiTexture - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public getMetadata (I)I - -
in 24
class net/minecraft/item/ItemAppleGold 50 public,super net/minecraft/item/ItemFood - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> (IFZ)V - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 326
class net/minecraft/item/ItemAppleGold 52 public,super net/minecraft/item/ItemFood - -
 method public <init> (IFZ)V - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
in 90
class net/minecraft/item/ItemArmor 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 field public,static,final EMPTY_SLOT_NAMES [Ljava/lang/String; -
 field public,final armorType I -
 field public,final damageReduceAmount I -
 field public,final renderIndex I -
 method public <init> (Lnet/minecraft/item/ItemArmor$ArmorMaterial;II)V - -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public getItemEnchantability ()I - -
 method public getArmorMaterial ()Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public hasColor (Lnet/minecraft/item/ItemStack;)Z - -
 method public getColor (Lnet/minecraft/item/ItemStack;)I - -
 method public removeColor (Lnet/minecraft/item/ItemStack;)V - -
 method public setColor (Lnet/minecraft/item/ItemStack;I)V - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemArmor 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 inner net/minecraft/util/EntitySelectors$ArmoredMob net/minecraft/util/EntitySelectors ArmoredMob public,static
 field public,static,final EMPTY_SLOT_NAMES [Ljava/lang/String; -
 field public,static,final DISPENSER_BEHAVIOR Lnet/minecraft/dispenser/IBehaviorDispenseItem; -
 field public,final armorType Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,final damageReduceAmount I -
 field public,final toughness F -
 field public,final renderIndex I -
 method public,static dispenseArmor (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public <init> (Lnet/minecraft/item/ItemArmor$ArmorMaterial;ILnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getEquipmentSlot ()Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public getItemEnchantability ()I - -
 method public getArmorMaterial ()Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public hasColor (Lnet/minecraft/item/ItemStack;)Z - -
 method public getColor (Lnet/minecraft/item/ItemStack;)I - -
 method public removeColor (Lnet/minecraft/item/ItemStack;)V - -
 method public setColor (Lnet/minecraft/item/ItemStack;I)V - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public hasOverlay (Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/item/ItemArmor 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 inner net/minecraft/util/EntitySelectors$ArmoredMob net/minecraft/util/EntitySelectors ArmoredMob public,static
 field public,static,final EMPTY_SLOT_NAMES [Ljava/lang/String; -
 field public,static,final DISPENSER_BEHAVIOR Lnet/minecraft/dispenser/IBehaviorDispenseItem; -
 field public,final armorType Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,final damageReduceAmount I -
 field public,final toughness F -
 field public,final renderIndex I -
 method public,static dispenseArmor (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public <init> (Lnet/minecraft/item/ItemArmor$ArmorMaterial;ILnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getEquipmentSlot ()Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public getItemEnchantability ()I - -
 method public getArmorMaterial ()Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public hasColor (Lnet/minecraft/item/ItemStack;)Z - -
 method public getColor (Lnet/minecraft/item/ItemStack;)I - -
 method public removeColor (Lnet/minecraft/item/ItemStack;)V - -
 method public setColor (Lnet/minecraft/item/ItemStack;I)V - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public hasOverlay (Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/item/ItemArmor$ArmorMaterial 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/ItemArmor$ArmorMaterial;>;
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 field public,static,final,enum LEATHER Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum CHAIN Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum IRON Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum GOLD Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum DIAMOND Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public customCraftingMaterial Lnet/minecraft/item/Item; -
 method public,static values ()[Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public getDurability (I)I - -
 method public getDamageReductionAmount (I)I - -
 method public getEnchantability ()I - -
 method public getRepairItem ()Lnet/minecraft/item/Item; - -
 method public getName ()Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemArmor$ArmorMaterial 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/ItemArmor$ArmorMaterial;>;
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 field public,static,final,enum LEATHER Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum CHAIN Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum IRON Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum GOLD Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum DIAMOND Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public customCraftingMaterial Lnet/minecraft/item/Item; -
 method public,static values ()[Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public getDurability (Lnet/minecraft/inventory/EntityEquipmentSlot;)I - -
 method public getDamageReductionAmount (Lnet/minecraft/inventory/EntityEquipmentSlot;)I - -
 method public getEnchantability ()I - -
 method public getSoundEvent ()Lnet/minecraft/util/SoundEvent; - -
 method public getRepairItem ()Lnet/minecraft/item/Item; - -
 method public getName ()Ljava/lang/String; - -
 method public getToughness ()F - -
in 326
class net/minecraft/item/ItemArmor$ArmorMaterial 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/ItemArmor$ArmorMaterial;>;
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 field public,static,final,enum LEATHER Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum CHAIN Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum IRON Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum GOLD Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public,static,final,enum DIAMOND Lnet/minecraft/item/ItemArmor$ArmorMaterial; -
 field public repairMaterial Lnet/minecraft/item/ItemStack; -
 method public,static values ()[Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public getDurability (Lnet/minecraft/inventory/EntityEquipmentSlot;)I - -
 method public getDamageReductionAmount (Lnet/minecraft/inventory/EntityEquipmentSlot;)I - -
 method public getEnchantability ()I - -
 method public getSoundEvent ()Lnet/minecraft/util/SoundEvent; - -
 method public,deprecated getRepairItem ()Lnet/minecraft/item/Item; - -
 method public getName ()Ljava/lang/String; - -
 method public getToughness ()F - -
 method public setRepairItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemArmor$ArmorMaterial; - -
 method public getRepairItemStack ()Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/item/ItemArmorStand 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemArmorStand 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemArmorStand 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 91
class net/minecraft/item/ItemArrow 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public createArrow (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/projectile/EntityArrow; - -
 method public isInfinite (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 326
class net/minecraft/item/ItemArrow 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public createArrow (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/projectile/EntityArrow; - -
 method public isInfinite (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 90
class net/minecraft/item/ItemAxe 50 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/Block;)F - -
in 91
class net/minecraft/item/ItemAxe 50 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;FF)V - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
in 326
class net/minecraft/item/ItemAxe 52 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;FF)V - -
 method public getDestroySpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
in 90
class net/minecraft/item/ItemBanner 50 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/tileentity/TileEntityBanner$EnumBannerPattern net/minecraft/tileentity/TileEntityBanner EnumBannerPattern public,static,final,enum
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemBanner 50 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/tileentity/TileEntityBanner$EnumBannerPattern net/minecraft/tileentity/TileEntityBanner EnumBannerPattern public,static,final,enum
 method public,static appendHoverTextFromTileEntityTag (Lnet/minecraft/item/ItemStack;Ljava/util/List;)V (Lnet/minecraft/item/ItemStack;Ljava/util/List<Ljava/lang/String;>;)V -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public,static getBaseColor (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumDyeColor; - -
in 326
class net/minecraft/item/ItemBanner 52 public,super net/minecraft/item/ItemBlock - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public,static appendHoverTextFromTileEntityTag (Lnet/minecraft/item/ItemStack;Ljava/util/List;)V (Lnet/minecraft/item/ItemStack;Ljava/util/List<Ljava/lang/String;>;)V -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public,static makeBanner (Lnet/minecraft/item/EnumDyeColor;Lnet/minecraft/nbt/NBTTagList;)Lnet/minecraft/item/ItemStack; - -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public,static getBaseColor (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumDyeColor; - -
in 90
class net/minecraft/item/ItemBed 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockBed$EnumPartType net/minecraft/block/BlockBed EnumPartType public,static,final,enum
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemBed 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockBed$EnumPartType net/minecraft/block/BlockBed EnumPartType public,static,final,enum
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemBed 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockBed$EnumPartType net/minecraft/block/BlockBed EnumPartType public,static,final,enum
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
in 90
class net/minecraft/item/ItemBlock 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 field public,final block Lnet/minecraft/block/Block; -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public setUnlocalizedName (Ljava/lang/String;)Lnet/minecraft/item/ItemBlock; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public,static setTileEntityNBT (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/BlockPos;Lnet/minecraft/item/ItemStack;)Z - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getBlock ()Lnet/minecraft/block/Block; - -
 method public placeBlockAt (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFFLnet/minecraft/block/state/IBlockState;)Z - -
in 91
class net/minecraft/item/ItemBlock 50 public,super net/minecraft/item/Item - -
 field public,final block Lnet/minecraft/block/Block; -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public setUnlocalizedName (Ljava/lang/String;)Lnet/minecraft/item/ItemBlock; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static setTileEntityNBT (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/item/ItemStack;)Z - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getBlock ()Lnet/minecraft/block/Block; - -
 method public placeBlockAt (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;FFFLnet/minecraft/block/state/IBlockState;)Z - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
in 326
class net/minecraft/item/ItemBlock 52 public,super net/minecraft/item/Item - -
 field protected,final block Lnet/minecraft/block/Block; -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static setTileEntityNBT (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/item/ItemStack;)Z - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public getBlock ()Lnet/minecraft/block/Block; - -
 method public placeBlockAt (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;FFFLnet/minecraft/block/state/IBlockState;)Z - -
in 91
class net/minecraft/item/ItemBlockSpecial 50 public,super net/minecraft/item/Item - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getBlock ()Lnet/minecraft/block/Block; - -
in 326
class net/minecraft/item/ItemBlockSpecial 52 public,super net/minecraft/item/Item - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getBlock ()Lnet/minecraft/block/Block; - -
in 90
class net/minecraft/item/ItemBoat 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemBoat 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/entity/item/EntityBoat$Type;)V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemBoat 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/entity/item/EntityBoat$Type;)V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemBook 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public isItemTool (Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemEnchantability ()I - -
in 91
class net/minecraft/item/ItemBook 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public isEnchantable (Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemEnchantability ()I - -
in 326
class net/minecraft/item/ItemBook 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public isEnchantable (Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemEnchantability ()I - -
in 90
class net/minecraft/item/ItemBow 50 public,super net/minecraft/item/Item - -
 field public,static,final bowPullIconNameArray [Ljava/lang/String; -
 method public <init> ()V - -
 method public onPlayerStoppedUsing (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;I)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public getItemEnchantability ()I - -
in 91
class net/minecraft/item/ItemBow 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/projectile/EntityArrow$PickupStatus net/minecraft/entity/projectile/EntityArrow PickupStatus public,static,final,enum
 method public <init> ()V - -
 method protected isArrow (Lnet/minecraft/item/ItemStack;)Z - -
 method public onPlayerStoppedUsing (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public,static getArrowVelocity (I)F - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getItemEnchantability ()I - -
in 326
class net/minecraft/item/ItemBow 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/projectile/EntityArrow$PickupStatus net/minecraft/entity/projectile/EntityArrow PickupStatus public,static,final,enum
 method public <init> ()V - -
 method protected findAmmo (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method protected isArrow (Lnet/minecraft/item/ItemStack;)Z - -
 method public onPlayerStoppedUsing (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public,static getArrowVelocity (I)F - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getItemEnchantability ()I - -
 method public customizeArrow (Lnet/minecraft/entity/projectile/EntityArrow;)Lnet/minecraft/entity/projectile/EntityArrow; - -
in 90
class net/minecraft/item/ItemBucket 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public tryPlaceContainedLiquid (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Z - -
in 91
class net/minecraft/item/ItemBucket 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public tryPlaceContainedLiquid (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public initCapabilities (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
in 326
class net/minecraft/item/ItemBucket 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public tryPlaceContainedLiquid (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public initCapabilities (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
in 90
class net/minecraft/item/ItemBucketMilk 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemBucketMilk 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public initCapabilities (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
in 326
class net/minecraft/item/ItemBucketMilk 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public initCapabilities (Lnet/minecraft/item/ItemStack;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemCarrotOnAStick 50 public,super net/minecraft/item/Item - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemCarrotOnAStick 50 public,super net/minecraft/item/Item - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemCarrotOnAStick 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 91
class net/minecraft/item/ItemChorusFruit 50 public,super net/minecraft/item/ItemFood - -
 method public <init> (IF)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/ItemChorusFruit 52 public,super net/minecraft/item/ItemFood - -
 method public <init> (IF)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemClock 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
in 326
class net/minecraft/item/ItemClock 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
in 24
class net/minecraft/item/ItemCloth 50 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemCloth 52 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public getMetadata (I)I - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 24
class net/minecraft/item/ItemCoal 50 public,super net/minecraft/item/Item - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> ()V - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemCoal 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
in 90
class net/minecraft/item/ItemColored 50 public,super net/minecraft/item/ItemBlock - -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public <init> (Lnet/minecraft/block/Block;Z)V - -
 method public getMetadata (I)I - -
 method public setSubtypeNames ([Ljava/lang/String;)Lnet/minecraft/item/ItemColored; - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemColored 50 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;Z)V - -
 method public getMetadata (I)I - -
 method public setSubtypeNames ([Ljava/lang/String;)Lnet/minecraft/item/ItemColored; - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemColored 52 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;Z)V - -
 method public getMetadata (I)I - -
 method public setSubtypeNames ([Ljava/lang/String;)Lnet/minecraft/item/ItemColored; - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemCompass 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
in 326
class net/minecraft/item/ItemCompass 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
in 90
class net/minecraft/item/ItemDoor 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockDoor$EnumHingePosition net/minecraft/block/BlockDoor EnumHingePosition public,static,final,enum
 inner net/minecraft/block/BlockDoor$EnumDoorHalf net/minecraft/block/BlockDoor EnumDoorHalf public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public,static placeDoor (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/block/Block;)V - -
in 91
class net/minecraft/item/ItemDoor 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockDoor$EnumHingePosition net/minecraft/block/BlockDoor EnumHingePosition public,static,final,enum
 inner net/minecraft/block/BlockDoor$EnumDoorHalf net/minecraft/block/BlockDoor EnumDoorHalf public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static placeDoor (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/block/Block;Z)V - -
in 326
class net/minecraft/item/ItemDoor 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockDoor$EnumHingePosition net/minecraft/block/BlockDoor EnumHingePosition public,static,final,enum
 inner net/minecraft/block/BlockDoor$EnumDoorHalf net/minecraft/block/BlockDoor EnumDoorHalf public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static placeDoor (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/block/Block;Z)V - -
in 90
class net/minecraft/item/ItemDoublePlant 50 public,super net/minecraft/item/ItemMultiTexture - -
 inner net/minecraft/block/BlockDoublePlant$EnumPlantType net/minecraft/block/BlockDoublePlant EnumPlantType public,static,final,enum
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;Lcom/google/common/base/Function;)V (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;Lcom/google/common/base/Function<Lnet/minecraft/item/ItemStack;Ljava/lang/String;>;)V -
in 90
class net/minecraft/item/ItemDye 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 field public,static,final dyeColors [I -
 method public <init> ()V - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public,static applyBonemeal (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Z - -
 method public,static applyBonemeal (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,static spawnBonemealParticles (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;I)V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
in 91
class net/minecraft/item/ItemDye 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 field public,static,final DYE_COLORS [I -
 method public <init> ()V - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static applyBonemeal (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public,static applyBonemeal (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,static spawnBonemealParticles (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;I)V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
in 326
class net/minecraft/item/ItemDye 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 field public,static,final DYE_COLORS [I -
 method public <init> ()V - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static applyBonemeal (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public,static applyBonemeal (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public,static spawnBonemealParticles (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;I)V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
in 90
class net/minecraft/item/ItemEditableBook 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/IChatComponent$Serializer net/minecraft/util/IChatComponent Serializer public,static
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public <init> ()V - -
 method public,static validBookTagContents (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public,static getGeneration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/item/ItemEgg 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemEgg 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemEgg 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 91
class net/minecraft/item/ItemElytra 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public,static isBroken (Lnet/minecraft/item/ItemStack;)Z - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemElytra 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public,static isUsable (Lnet/minecraft/item/ItemStack;)Z - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemEmptyMap 50 public,super net/minecraft/item/ItemMapBase - -
 method protected <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemEmptyMap 50 public,super net/minecraft/item/ItemMapBase - -
 method protected <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemEmptyMap 52 public,super net/minecraft/item/ItemMapBase - -
 method protected <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemEnchantedBook 50 public,super net/minecraft/item/Item - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getAll (Lnet/minecraft/enchantment/Enchantment;Ljava/util/List;)V (Lnet/minecraft/enchantment/Enchantment;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> ()V - -
 method public isItemTool (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public getEnchantments (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagList; - -
 method public addEnchantment (Lnet/minecraft/item/ItemStack;Lnet/minecraft/enchantment/EnchantmentData;)V - -
 method public getEnchantedItemStack (Lnet/minecraft/enchantment/EnchantmentData;)Lnet/minecraft/item/ItemStack; - -
 method public getRandom (Ljava/util/Random;)Lnet/minecraft/util/WeightedRandomChestContent; - -
 method public getRandom (Ljava/util/Random;III)Lnet/minecraft/util/WeightedRandomChestContent; - -
in 91
class net/minecraft/item/ItemEnchantedBook 50 public,super net/minecraft/item/Item - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getAll (Lnet/minecraft/enchantment/Enchantment;Ljava/util/List;)V (Lnet/minecraft/enchantment/Enchantment;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> ()V - -
 method public isEnchantable (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public getEnchantments (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagList; - -
 method public addEnchantment (Lnet/minecraft/item/ItemStack;Lnet/minecraft/enchantment/EnchantmentData;)V - -
 method public getEnchantedItemStack (Lnet/minecraft/enchantment/EnchantmentData;)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/ItemEnchantedBook 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public isEnchantable (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public,static getEnchantments (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/nbt/NBTTagList; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public,static addEnchantment (Lnet/minecraft/item/ItemStack;Lnet/minecraft/enchantment/EnchantmentData;)V - -
 method public,static getEnchantedItemStack (Lnet/minecraft/enchantment/EnchantmentData;)Lnet/minecraft/item/ItemStack; - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
in 91
class net/minecraft/item/ItemEndCrystal 50 public,super net/minecraft/item/Item - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemEndCrystal 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/item/ItemEnderEye 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemEnderEye 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/state/pattern/BlockPattern$PatternHelper net/minecraft/block/state/pattern/BlockPattern PatternHelper public,static
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemEnderEye 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/state/pattern/BlockPattern$PatternHelper net/minecraft/block/state/pattern/BlockPattern PatternHelper public,static
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemEnderPearl 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemEnderPearl 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemEnderPearl 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemExpBottle 50 public,super net/minecraft/item/Item - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemExpBottle 50 public,super net/minecraft/item/Item - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemExpBottle 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemFireball 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemFireball 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemFireball 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 90
class net/minecraft/item/ItemFirework 50 public,super net/minecraft/item/Item - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemFirework 50 public,super net/minecraft/item/Item - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemFirework 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
in 90
class net/minecraft/item/ItemFireworkCharge 50 public,super net/minecraft/item/Item - -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public,static getExplosionTag (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)Lnet/minecraft/nbt/NBTBase; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public,static addExplosionInfo (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List;)V (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List<Ljava/lang/String;>;)V -
 method public <init> ()V - -
in 91
class net/minecraft/item/ItemFireworkCharge 50 public,super net/minecraft/item/Item - -
 method public,static getExplosionTag (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)Lnet/minecraft/nbt/NBTBase; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public,static addExplosionInfo (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List;)V (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List<Ljava/lang/String;>;)V -
 method public <init> ()V - -
in 326
class net/minecraft/item/ItemFireworkCharge 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public,static getExplosionTag (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)Lnet/minecraft/nbt/NBTBase; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public,static addExplosionInfo (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List;)V (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List<Ljava/lang/String;>;)V -
in 90
class net/minecraft/item/ItemFishFood 50 public,super net/minecraft/item/ItemFood - -
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> (Z)V - -
 method public getHealAmount (Lnet/minecraft/item/ItemStack;)I - -
 method public getSaturationModifier (Lnet/minecraft/item/ItemStack;)F - -
 method public getPotionEffect (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemFishFood 50 public,super net/minecraft/item/ItemFood - -
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> (Z)V - -
 method public getHealAmount (Lnet/minecraft/item/ItemStack;)I - -
 method public getSaturationModifier (Lnet/minecraft/item/ItemStack;)F - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemFishFood 52 public,super net/minecraft/item/ItemFood - -
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 method public <init> (Z)V - -
 method public getHealAmount (Lnet/minecraft/item/ItemStack;)I - -
 method public getSaturationModifier (Lnet/minecraft/item/ItemStack;)F - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 24
class net/minecraft/item/ItemFishFood$FishType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/ItemFishFood$FishType;>;
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 field public,static,final,enum COD Lnet/minecraft/item/ItemFishFood$FishType; -
 field public,static,final,enum SALMON Lnet/minecraft/item/ItemFishFood$FishType; -
 field public,static,final,enum CLOWNFISH Lnet/minecraft/item/ItemFishFood$FishType; -
 field public,static,final,enum PUFFERFISH Lnet/minecraft/item/ItemFishFood$FishType; -
 method public,static values ()[Lnet/minecraft/item/ItemFishFood$FishType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/ItemFishFood$FishType; - -
 method public getMetadata ()I - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public getUncookedHealAmount ()I - -
 method public getUncookedSaturationModifier ()F - -
 method public getCookedHealAmount ()I - -
 method public getCookedSaturationModifier ()F - -
 method public canCook ()Z - -
 method public,static byMetadata (I)Lnet/minecraft/item/ItemFishFood$FishType; - -
 method public,static byItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemFishFood$FishType; - -
in 326
class net/minecraft/item/ItemFishFood$FishType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/item/ItemFishFood$FishType;>;
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 field public,static,final,enum COD Lnet/minecraft/item/ItemFishFood$FishType; -
 field public,static,final,enum SALMON Lnet/minecraft/item/ItemFishFood$FishType; -
 field public,static,final,enum CLOWNFISH Lnet/minecraft/item/ItemFishFood$FishType; -
 field public,static,final,enum PUFFERFISH Lnet/minecraft/item/ItemFishFood$FishType; -
 method public,static values ()[Lnet/minecraft/item/ItemFishFood$FishType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/item/ItemFishFood$FishType; - -
 method public getMetadata ()I - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getUncookedHealAmount ()I - -
 method public getUncookedSaturationModifier ()F - -
 method public getCookedHealAmount ()I - -
 method public getCookedSaturationModifier ()F - -
 method public canCook ()Z - -
 method public,static byMetadata (I)Lnet/minecraft/item/ItemFishFood$FishType; - -
 method public,static byItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemFishFood$FishType; - -
in 90
class net/minecraft/item/ItemFishingRod 50 public,super net/minecraft/item/Item - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public isItemTool (Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemEnchantability ()I - -
in 91
class net/minecraft/item/ItemFishingRod 50 public,super net/minecraft/item/Item - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public isEnchantable (Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemEnchantability ()I - -
in 326
class net/minecraft/item/ItemFishingRod 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public isFull3D ()Z - -
 method public shouldRotateAroundWhenRendering ()Z - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getItemEnchantability ()I - -
in 90
class net/minecraft/item/ItemFlintAndSteel 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemFlintAndSteel 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemFlintAndSteel 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 90
class net/minecraft/item/ItemFood 50 public,super net/minecraft/item/Item - -
 field public,final itemUseDuration I - I32
 method public <init> (IFZ)V - -
 method public <init> (IZ)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public getHealAmount (Lnet/minecraft/item/ItemStack;)I - -
 method public getSaturationModifier (Lnet/minecraft/item/ItemStack;)F - -
 method public isWolfsFavoriteMeat ()Z - -
 method public setPotionEffect (IIIF)Lnet/minecraft/item/ItemFood; - -
 method public setAlwaysEdible ()Lnet/minecraft/item/ItemFood; - -
in 91
class net/minecraft/item/ItemFood 50 public,super net/minecraft/item/Item - -
 field public,final itemUseDuration I - I32
 method public <init> (IFZ)V - -
 method public <init> (IZ)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getHealAmount (Lnet/minecraft/item/ItemStack;)I - -
 method public getSaturationModifier (Lnet/minecraft/item/ItemStack;)F - -
 method public isWolfsFavoriteMeat ()Z - -
 method public setPotionEffect (Lnet/minecraft/potion/PotionEffect;F)Lnet/minecraft/item/ItemFood; - -
 method public setAlwaysEdible ()Lnet/minecraft/item/ItemFood; - -
in 326
class net/minecraft/item/ItemFood 52 public,super net/minecraft/item/Item - -
 field public,final itemUseDuration I - I32
 method public <init> (IFZ)V - -
 method public <init> (IZ)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method protected onFoodEaten (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getHealAmount (Lnet/minecraft/item/ItemStack;)I - -
 method public getSaturationModifier (Lnet/minecraft/item/ItemStack;)F - -
 method public isWolfsFavoriteMeat ()Z - -
 method public setPotionEffect (Lnet/minecraft/potion/PotionEffect;F)Lnet/minecraft/item/ItemFood; - -
 method public setAlwaysEdible ()Lnet/minecraft/item/ItemFood; - -
in 90
class net/minecraft/item/ItemGlassBottle 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemGlassBottle 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method protected turnBottleIntoItem (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/ItemGlassBottle 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method protected turnBottleIntoItem (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/item/ItemHangingEntity 50 public,super net/minecraft/item/Item - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/entity/EntityHanging;>;)V -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemHangingEntity 50 public,super net/minecraft/item/Item - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/entity/EntityHanging;>;)V -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemHangingEntity 52 public,super net/minecraft/item/Item - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/entity/EntityHanging;>;)V -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 90
class net/minecraft/item/ItemHoe 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 inner net/minecraft/block/BlockDirt$DirtType net/minecraft/block/BlockDirt DirtType public,static,final,enum
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 field protected theToolMaterial Lnet/minecraft/item/Item$ToolMaterial; -
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method protected useHoe (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;)Z - -
 method public isFull3D ()Z - -
 method public getMaterialName ()Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemHoe 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 inner net/minecraft/block/BlockDirt$DirtType net/minecraft/block/BlockDirt DirtType public,static,final,enum
 field protected theToolMaterial Lnet/minecraft/item/Item$ToolMaterial; -
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method protected setBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method public isFull3D ()Z - -
 method public getMaterialName ()Ljava/lang/String; - -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
in 326
class net/minecraft/item/ItemHoe 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 inner net/minecraft/block/BlockDirt$DirtType net/minecraft/block/BlockDirt DirtType public,static,final,enum
 field protected toolMaterial Lnet/minecraft/item/Item$ToolMaterial; -
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method protected setBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method public isFull3D ()Z - -
 method public getMaterialName ()Ljava/lang/String; - -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
in 326
class net/minecraft/item/ItemKnowledgeBook 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemLead 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public,static attachToFence (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Z - -
in 91
class net/minecraft/item/ItemLead 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static attachToFence (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 326
class net/minecraft/item/ItemLead 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static attachToFence (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 90
class net/minecraft/item/ItemLeaves 50 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public <init> (Lnet/minecraft/block/BlockLeaves;)V - -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemLeaves 50 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 method public <init> (Lnet/minecraft/block/BlockLeaves;)V - -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemLeaves 52 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 method public <init> (Lnet/minecraft/block/BlockLeaves;)V - -
 method public getMetadata (I)I - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 90
class net/minecraft/item/ItemLilyPad 50 public,super net/minecraft/item/ItemColored - -
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 inner net/minecraftforge/event/world/BlockEvent$PlaceEvent net/minecraftforge/event/world/BlockEvent PlaceEvent public,static
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
in 91
class net/minecraft/item/ItemLilyPad 50 public,super net/minecraft/item/ItemColored - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 inner net/minecraftforge/event/world/BlockEvent$PlaceEvent net/minecraftforge/event/world/BlockEvent PlaceEvent public,static
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemLilyPad 52 public,super net/minecraft/item/ItemColored - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 inner net/minecraftforge/event/world/BlockEvent$PlaceEvent net/minecraftforge/event/world/BlockEvent PlaceEvent public,static
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 91
class net/minecraft/item/ItemLingeringPotion 50 public,super net/minecraft/item/ItemPotion - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemLingeringPotion 52 public,super net/minecraft/item/ItemPotion - -
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemMap 50 public,super net/minecraft/item/ItemMapBase - -
 inner net/minecraft/util/BlockPos$MutableBlockPos net/minecraft/util/BlockPos MutableBlockPos public,static,final
 inner net/minecraft/world/storage/MapData$MapInfo net/minecraft/world/storage/MapData MapInfo public
 inner net/minecraft/block/BlockDirt$DirtType net/minecraft/block/BlockDirt DirtType public,static,final,enum
 inner net/minecraft/block/BlockStone$EnumType net/minecraft/block/BlockStone EnumType public,static,final,enum
 method protected <init> ()V - -
 method public,static loadMapData (ILnet/minecraft/world/World;)Lnet/minecraft/world/storage/MapData; - -
 method public getMapData (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)Lnet/minecraft/world/storage/MapData; - -
 method public updateMapData (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/world/storage/MapData;)V - -
 method public onUpdate (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public createMapDataPacket (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet; - -
 method public onCreated (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
in 91
class net/minecraft/item/ItemMap 50 public,super net/minecraft/item/ItemMapBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/world/storage/MapData$MapInfo net/minecraft/world/storage/MapData MapInfo public
 inner net/minecraft/block/BlockDirt$DirtType net/minecraft/block/BlockDirt DirtType public,static,final,enum
 inner net/minecraft/block/BlockStone$EnumType net/minecraft/block/BlockStone EnumType public,static,final,enum
 method protected <init> ()V - -
 method public,static loadMapData (ILnet/minecraft/world/World;)Lnet/minecraft/world/storage/MapData; - -
 method public getMapData (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)Lnet/minecraft/world/storage/MapData; - -
 method public updateMapData (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/world/storage/MapData;)V - -
 method public onUpdate (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public createMapDataPacket (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet<*>; -
 method public onCreated (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected,static scaleMap (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;I)V - -
 method protected,static enableMapTracking (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)V - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
in 326
class net/minecraft/item/ItemMap 52 public,super net/minecraft/item/ItemMapBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/world/storage/MapData$MapInfo net/minecraft/world/storage/MapData MapInfo public
 inner net/minecraft/block/BlockDirt$DirtType net/minecraft/block/BlockDirt DirtType public,static,final,enum
 inner net/minecraft/block/BlockStone$EnumType net/minecraft/block/BlockStone EnumType public,static,final,enum
 method protected <init> ()V - -
 method public,static setupNewMap (Lnet/minecraft/world/World;DDBZZ)Lnet/minecraft/item/ItemStack; - -
 method public,static loadMapData (ILnet/minecraft/world/World;)Lnet/minecraft/world/storage/MapData; - -
 method public getMapData (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)Lnet/minecraft/world/storage/MapData; - -
 method public updateMapData (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/world/storage/MapData;)V - -
 method public,static renderBiomePreviewMap (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;)V - -
 method public onUpdate (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public createMapDataPacket (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet<*>; -
 method public onCreated (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected,static scaleMap (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;I)V - -
 method protected,static enableMapTracking (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;)V - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public,static getColor (Lnet/minecraft/item/ItemStack;)I - -
in 90
class net/minecraft/item/ItemMapBase 50 public,super net/minecraft/item/Item - -
 method protected <init> ()V - -
 method public isMap ()Z - -
 method public createMapDataPacket (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet; - -
in 91
class net/minecraft/item/ItemMapBase 50 public,super net/minecraft/item/Item - -
 method protected <init> ()V - -
 method public isMap ()Z - -
 method public createMapDataPacket (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet<*>; -
in 326
class net/minecraft/item/ItemMapBase 52 public,super net/minecraft/item/Item - -
 method protected <init> ()V - -
 method public isMap ()Z - -
 method public createMapDataPacket (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/network/Packet<*>; -
in 90
class net/minecraft/item/ItemMinecart 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 inner net/minecraft/block/BlockRailBase$EnumRailDirection net/minecraft/block/BlockRailBase EnumRailDirection public,static,final,enum
 method public <init> (Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemMinecart 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 inner net/minecraft/block/BlockRailBase$EnumRailDirection net/minecraft/block/BlockRailBase EnumRailDirection public,static,final,enum
 method public <init> (Lnet/minecraft/entity/item/EntityMinecart$Type;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemMinecart 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 inner net/minecraft/block/BlockRailBase$EnumRailDirection net/minecraft/block/BlockRailBase EnumRailDirection public,static,final,enum
 method public <init> (Lnet/minecraft/entity/item/EntityMinecart$Type;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 90
class net/minecraft/item/ItemMonsterPlacer 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public,static,deprecated spawnCreature (Lnet/minecraft/world/World;IDDD)Lnet/minecraft/entity/Entity; - -
 method public,static spawnCreature (Lnet/minecraft/world/World;Ljava/lang/String;DDD)Lnet/minecraft/entity/Entity; - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public,static getEntityName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemMonsterPlacer 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public,static applyItemEntityDataToEntity (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/Entity;)V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public,static spawnCreature (Lnet/minecraft/world/World;Ljava/lang/String;DDD)Lnet/minecraft/entity/Entity; - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public,static applyEntityIdToItemStack (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)V - -
 method public,static getEntityIdFromItem (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemMonsterPlacer 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method protected getYOffset (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)D - -
 method public,static applyItemEntityDataToEntity (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/Entity;)V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public,static spawnCreature (Lnet/minecraft/world/World;Lnet/minecraft/util/ResourceLocation;DDD)Lnet/minecraft/entity/Entity; - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public,static applyEntityIdToItemStack (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/ResourceLocation;)V - -
 method public,static getNamedIdFrom (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/util/ResourceLocation; - -
in 24
class net/minecraft/item/ItemMultiTexture 50 public,super net/minecraft/item/ItemBlock - -
 field protected,final theBlock Lnet/minecraft/block/Block; -
 field protected,final nameFunction Lcom/google/common/base/Function; Lcom/google/common/base/Function<Lnet/minecraft/item/ItemStack;Ljava/lang/String;>;
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;Lcom/google/common/base/Function;)V (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;Lcom/google/common/base/Function<Lnet/minecraft/item/ItemStack;Ljava/lang/String;>;)V -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;[Ljava/lang/String;)V - -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemMultiTexture 52 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/item/ItemMultiTexture$Mapper net/minecraft/item/ItemMultiTexture Mapper public,static,interface,abstract
 field protected,final unused Lnet/minecraft/block/Block; -
 field protected,final nameFunction Lnet/minecraft/item/ItemMultiTexture$Mapper; -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;Lnet/minecraft/item/ItemMultiTexture$Mapper;)V - -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;[Ljava/lang/String;)V - -
 method public getMetadata (I)I - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemMultiTexture$Mapper 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/item/ItemMultiTexture$Mapper net/minecraft/item/ItemMultiTexture Mapper public,static,interface,abstract
 method public,abstract apply (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 90
class net/minecraft/item/ItemNameTag 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;)Z - -
in 91
class net/minecraft/item/ItemNameTag 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
in 326
class net/minecraft/item/ItemNameTag 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
in 90
class net/minecraft/item/ItemPickaxe 50 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;)Z - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/Block;)F - -
in 91
class net/minecraft/item/ItemPickaxe 50 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
in 326
class net/minecraft/item/ItemPickaxe 52 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public getDestroySpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
in 24
class net/minecraft/item/ItemPiston 50 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public getMetadata (I)I - -
in 326
class net/minecraft/item/ItemPiston 52 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public getMetadata (I)I - -
in 90
class net/minecraft/item/ItemPotion 50 public,super net/minecraft/item/Item - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public getColorFromDamage (I)I - -
 method public getColorFromItemStack (Lnet/minecraft/item/ItemStack;I)I - -
 method public isEffectInstant (I)Z - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> ()V - -
 method public getEffects (Lnet/minecraft/item/ItemStack;)Ljava/util/List; (Lnet/minecraft/item/ItemStack;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public getEffects (I)Ljava/util/List; (I)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public,static isSplash (I)Z - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 91
class net/minecraft/item/ItemPotion 50 public,super net/minecraft/item/Item - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public <init> ()V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemPotion 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public getDefaultInstance ()Lnet/minecraft/item/ItemStack; - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/item/ItemRecord 50 public,super net/minecraft/item/Item - -
 field public,final recordName Ljava/lang/String; -
 method protected <init> (Ljava/lang/String;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getRecordNameLocal ()Ljava/lang/String; - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public,static getRecord (Ljava/lang/String;)Lnet/minecraft/item/ItemRecord; - -
 method public getRecordResource (Ljava/lang/String;)Lnet/minecraft/util/ResourceLocation; - -
in 91
class net/minecraft/item/ItemRecord 50 public,super net/minecraft/item/Item - -
 method protected <init> (Ljava/lang/String;Lnet/minecraft/util/SoundEvent;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getRecordResource (Ljava/lang/String;)Lnet/minecraft/util/ResourceLocation; - -
 method public getRecordNameLocal ()Ljava/lang/String; - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public,static getBySound (Lnet/minecraft/util/SoundEvent;)Lnet/minecraft/item/ItemRecord; - -
 method public getSound ()Lnet/minecraft/util/SoundEvent; - -
in 326
class net/minecraft/item/ItemRecord 52 public,super net/minecraft/item/Item - -
 method protected <init> (Ljava/lang/String;Lnet/minecraft/util/SoundEvent;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public getRecordNameLocal ()Ljava/lang/String; - -
 method public getRarity (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumRarity; - -
 method public,static getBySound (Lnet/minecraft/util/SoundEvent;)Lnet/minecraft/item/ItemRecord; - -
 method public getSound ()Lnet/minecraft/util/SoundEvent; - -
in 90
class net/minecraft/item/ItemRedstone 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemRedstone 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemRedstone 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 90
class net/minecraft/item/ItemReed 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 90
class net/minecraft/item/ItemSaddle 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
in 91
class net/minecraft/item/ItemSaddle 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
in 326
class net/minecraft/item/ItemSaddle 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
in 90
class net/minecraft/item/ItemSeedFood 50 public,super net/minecraft/item/ItemFood net/minecraftforge/common/IPlantable -
 method public <init> (IFLnet/minecraft/block/Block;Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getPlantType (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;)Lnet/minecraft/block/state/IBlockState; - -
in 91
class net/minecraft/item/ItemSeedFood 50 public,super net/minecraft/item/ItemFood net/minecraftforge/common/IPlantable -
 method public <init> (IFLnet/minecraft/block/Block;Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getPlantType (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState; - -
in 326
class net/minecraft/item/ItemSeedFood 52 public,super net/minecraft/item/ItemFood net/minecraftforge/common/IPlantable -
 method public <init> (IFLnet/minecraft/block/Block;Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getPlantType (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState; - -
in 90
class net/minecraft/item/ItemSeeds 50 public,super net/minecraft/item/Item net/minecraftforge/common/IPlantable -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getPlantType (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;)Lnet/minecraft/block/state/IBlockState; - -
in 91
class net/minecraft/item/ItemSeeds 50 public,super net/minecraft/item/Item net/minecraftforge/common/IPlantable -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getPlantType (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState; - -
in 326
class net/minecraft/item/ItemSeeds 52 public,super net/minecraft/item/Item net/minecraftforge/common/IPlantable -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getPlantType (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState; - -
in 90
class net/minecraft/item/ItemShears 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;)Z - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/Block;)F - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockStartBreak (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 91
class net/minecraft/item/ItemShears 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public onBlockStartBreak (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 326
class net/minecraft/item/ItemShears 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public itemInteractionForEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public onBlockStartBreak (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getDestroySpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
in 91
class net/minecraft/item/ItemShield 50 public,super net/minecraft/item/Item - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getCreativeTab ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/item/ItemShield 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/item/ItemShulkerBox 52 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
in 90
class net/minecraft/item/ItemSign 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemSign 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemSign 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 24
class net/minecraft/item/ItemSimpleFoiled 50 public,super net/minecraft/item/Item - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public <init> ()V - -
in 326
class net/minecraft/item/ItemSimpleFoiled 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/item/ItemSkull 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public updateItemStackNBT (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
in 91
class net/minecraft/item/ItemSkull 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public updateItemStackNBT (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
in 326
class net/minecraft/item/ItemSkull 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public getMetadata (I)I - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public updateItemStackNBT (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
in 90
class net/minecraft/item/ItemSlab 50 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/block/BlockSlab$EnumBlockHalf net/minecraft/block/BlockSlab EnumBlockHalf public,static,final,enum
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/BlockSlab;Lnet/minecraft/block/BlockSlab;)V - -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
in 91
class net/minecraft/item/ItemSlab 50 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/block/BlockSlab$EnumBlockHalf net/minecraft/block/BlockSlab EnumBlockHalf public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/BlockSlab;Lnet/minecraft/block/BlockSlab;)V - -
 method public getMetadata (I)I - -
 method public getUnlocalizedName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method protected makeState (Lnet/minecraft/block/properties/IProperty;Ljava/lang/Comparable;)Lnet/minecraft/block/state/IBlockState; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/block/properties/IProperty<TT;>;Ljava/lang/Comparable<*>;)Lnet/minecraft/block/state/IBlockState; -
in 326
class net/minecraft/item/ItemSlab 52 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/block/BlockSlab$EnumBlockHalf net/minecraft/block/BlockSlab EnumBlockHalf public,static,final,enum
 method public <init> (Lnet/minecraft/block/Block;Lnet/minecraft/block/BlockSlab;Lnet/minecraft/block/BlockSlab;)V - -
 method public getMetadata (I)I - -
 method public getTranslationKey (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method protected makeState (Lnet/minecraft/block/properties/IProperty;Ljava/lang/Comparable;)Lnet/minecraft/block/state/IBlockState; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/block/properties/IProperty<TT;>;Ljava/lang/Comparable<*>;)Lnet/minecraft/block/state/IBlockState; -
in 90
class net/minecraft/item/ItemSnow 50 public,super net/minecraft/item/ItemBlock - -
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getMetadata (I)I - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
in 91
class net/minecraft/item/ItemSnow 50 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getMetadata (I)I - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/item/ItemSnow 52 public,super net/minecraft/item/ItemBlock - -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getMetadata (I)I - -
 method public canPlaceBlockOnSide (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/item/ItemSnowball 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemSnowball 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemSnowball 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemSoup 50 public,super net/minecraft/item/ItemFood - -
 method public <init> (I)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/item/ItemSoup 50 public,super net/minecraft/item/ItemFood - -
 method public <init> (I)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/ItemSoup 52 public,super net/minecraft/item/ItemFood - -
 method public <init> (I)V - -
 method public onItemUseFinish (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/item/ItemSpade 50 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;)Z - -
in 91
class net/minecraft/item/ItemSpade 50 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public onItemUse (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 326
class net/minecraft/item/ItemSpade 52 public,super net/minecraft/item/ItemTool - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
in 91
class net/minecraft/item/ItemSpectralArrow 50 public,super net/minecraft/item/ItemArrow - -
 method public <init> ()V - -
 method public createArrow (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/projectile/EntityArrow; - -
in 326
class net/minecraft/item/ItemSpectralArrow 52 public,super net/minecraft/item/ItemArrow - -
 method public <init> ()V - -
 method public createArrow (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/projectile/EntityArrow; - -
in 91
class net/minecraft/item/ItemSplashPotion 50 public,super net/minecraft/item/ItemPotion - -
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemSplashPotion 52 public,super net/minecraft/item/ItemPotion - -
 method public <init> ()V - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/item/ItemStack 50 public,final,super java/lang/Object net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/event/HoverEvent$Action net/minecraft/event/HoverEvent Action public,static,final,enum
 field public,static,final DECIMALFORMAT Ljava/text/DecimalFormat; -
 field public stackSize I -
 field public animationsToGo I -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public <init> (Lnet/minecraft/block/Block;I)V - -
 method public <init> (Lnet/minecraft/block/Block;II)V - -
 method public <init> (Lnet/minecraft/item/Item;)V - -
 method public <init> (Lnet/minecraft/item/Item;I)V - -
 method public <init> (Lnet/minecraft/item/Item;II)V - -
 method public <init> (Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static loadItemStackFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/item/ItemStack; - -
 method public splitStack (I)Lnet/minecraft/item/ItemStack; - -
 method public getItem ()Lnet/minecraft/item/Item; - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;FFF)Z - -
 method public getStrVsBlock (Lnet/minecraft/block/Block;)F - -
 method public useItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public onItemUseFinish (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getMaxStackSize ()I - -
 method public isStackable ()Z - -
 method public isItemStackDamageable ()Z - -
 method public getHasSubtypes ()Z - -
 method public isItemDamaged ()Z - -
 method public getItemDamage ()I - -
 method public getMetadata ()I - -
 method public setItemDamage (I)V - -
 method public getMaxDamage ()I - -
 method public attemptDamageItem (ILjava/util/Random;)Z - -
 method public damageItem (ILnet/minecraft/entity/EntityLivingBase;)V - -
 method public hitEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onBlockDestroyed (Lnet/minecraft/world/World;Lnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;)Z - -
 method public interactWithEntity (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public copy ()Lnet/minecraft/item/ItemStack; - -
 method public,static areItemStackTagsEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemStacksEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemsEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public isItemEqual (Lnet/minecraft/item/ItemStack;)Z - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public,static copyItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public toString ()Ljava/lang/String; - -
 method public updateAnimation (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public onCrafting (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;I)V - -
 method public getIsItemStackEqual (Lnet/minecraft/item/ItemStack;)Z - -
 method public getMaxItemUseDuration ()I - -
 method public getItemUseAction ()Lnet/minecraft/item/EnumAction; - -
 method public onPlayerStoppedUsing (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;I)V - -
 method public hasTagCompound ()Z - -
 method public getTagCompound ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getSubCompound (Ljava/lang/String;Z)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getEnchantmentTagList ()Lnet/minecraft/nbt/NBTTagList; - -
 method public setTagCompound (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public setStackDisplayName (Ljava/lang/String;)Lnet/minecraft/item/ItemStack; - -
 method public clearCustomName ()V - -
 method public hasDisplayName ()Z - -
 method public getTooltip (Lnet/minecraft/entity/player/EntityPlayer;Z)Ljava/util/List; (Lnet/minecraft/entity/player/EntityPlayer;Z)Ljava/util/List<Ljava/lang/String;>; -
 method public hasEffect ()Z - -
 method public getRarity ()Lnet/minecraft/item/EnumRarity; - -
 method public isItemEnchantable ()Z - -
 method public addEnchantment (Lnet/minecraft/enchantment/Enchantment;I)V - -
 method public isItemEnchanted ()Z - -
 method public setTagInfo (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V - -
 method public canEditBlocks ()Z - -
 method public isOnItemFrame ()Z - -
 method public setItemFrame (Lnet/minecraft/entity/item/EntityItemFrame;)V - -
 method public getItemFrame ()Lnet/minecraft/entity/item/EntityItemFrame; - -
 method public getRepairCost ()I - -
 method public setRepairCost (I)V - -
 method public getAttributeModifiers ()Lcom/google/common/collect/Multimap; ()Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public setItem (Lnet/minecraft/item/Item;)V - -
 method public getChatComponent ()Lnet/minecraft/util/IChatComponent; - -
 method public canDestroy (Lnet/minecraft/block/Block;)Z - -
 method public canPlaceOn (Lnet/minecraft/block/Block;)Z - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 91
class net/minecraft/item/ItemStack 50 public,final,super java/lang/Object net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/util/text/event/HoverEvent$Action net/minecraft/util/text/event/HoverEvent Action public,static,final,enum
 field public,static,final DECIMALFORMAT Ljava/text/DecimalFormat; -
 field public stackSize I -
 field public animationsToGo I -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public <init> (Lnet/minecraft/block/Block;I)V - -
 method public <init> (Lnet/minecraft/block/Block;II)V - -
 method public <init> (Lnet/minecraft/item/Item;)V - -
 method public <init> (Lnet/minecraft/item/Item;I)V - -
 method public <init> (Lnet/minecraft/item/Item;II)V - -
 method public <init> (Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static loadItemStackFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/item/ItemStack; - -
 method public,static registerFixes (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public splitStack (I)Lnet/minecraft/item/ItemStack; - -
 method public getItem ()Lnet/minecraft/item/Item; - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getStrVsBlock (Lnet/minecraft/block/state/IBlockState;)F - -
 method public useItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public onItemUseFinish (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getMaxStackSize ()I - -
 method public isStackable ()Z - -
 method public isItemStackDamageable ()Z - -
 method public getHasSubtypes ()Z - -
 method public isItemDamaged ()Z - -
 method public getItemDamage ()I - -
 method public getMetadata ()I - -
 method public setItemDamage (I)V - -
 method public getMaxDamage ()I - -
 method public attemptDamageItem (ILjava/util/Random;)Z - -
 method public damageItem (ILnet/minecraft/entity/EntityLivingBase;)V - -
 method public hitEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onBlockDestroyed (Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public interactWithEntity (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public copy ()Lnet/minecraft/item/ItemStack; - -
 method public,static areItemStackTagsEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemStacksEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemsEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemsEqualIgnoreDurability (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public isItemEqual (Lnet/minecraft/item/ItemStack;)Z - -
 method public isItemEqualIgnoreDurability (Lnet/minecraft/item/ItemStack;)Z - -
 method public getUnlocalizedName ()Ljava/lang/String; - -
 method public,static copyItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public toString ()Ljava/lang/String; - -
 method public updateAnimation (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public onCrafting (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;I)V - -
 method public getMaxItemUseDuration ()I - -
 method public getItemUseAction ()Lnet/minecraft/item/EnumAction; - -
 method public onPlayerStoppedUsing (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public hasTagCompound ()Z - -
 method public getTagCompound ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getSubCompound (Ljava/lang/String;Z)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getEnchantmentTagList ()Lnet/minecraft/nbt/NBTTagList; - -
 method public setTagCompound (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public setStackDisplayName (Ljava/lang/String;)Lnet/minecraft/item/ItemStack; - -
 method public clearCustomName ()V - -
 method public hasDisplayName ()Z - -
 method public getTooltip (Lnet/minecraft/entity/player/EntityPlayer;Z)Ljava/util/List; (Lnet/minecraft/entity/player/EntityPlayer;Z)Ljava/util/List<Ljava/lang/String;>; -
 method public hasEffect ()Z - -
 method public getRarity ()Lnet/minecraft/item/EnumRarity; - -
 method public isItemEnchantable ()Z - -
 method public addEnchantment (Lnet/minecraft/enchantment/Enchantment;I)V - -
 method public isItemEnchanted ()Z - -
 method public setTagInfo (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V - -
 method public canEditBlocks ()Z - -
 method public isOnItemFrame ()Z - -
 method public setItemFrame (Lnet/minecraft/entity/item/EntityItemFrame;)V - -
 method public getItemFrame ()Lnet/minecraft/entity/item/EntityItemFrame; - -
 method public getRepairCost ()I - -
 method public setRepairCost (I)V - -
 method public getAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public addAttributeModifier (Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public,deprecated setItem (Lnet/minecraft/item/Item;)V - -
 method public getTextComponent ()Lnet/minecraft/util/text/ITextComponent; - -
 method public canDestroy (Lnet/minecraft/block/Block;)Z - -
 method public canPlaceOn (Lnet/minecraft/block/Block;)Z - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public areCapsCompatible (Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/item/ItemStack 52 public,final,super java/lang/Object net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/util/text/event/HoverEvent$Action net/minecraft/util/text/event/HoverEvent Action public,static,final,enum
 field public,static,final EMPTY Lnet/minecraft/item/ItemStack; -
 field public,static,final DECIMALFORMAT Ljava/text/DecimalFormat; -
 method public <init> (Lnet/minecraft/block/Block;)V - -
 method public <init> (Lnet/minecraft/block/Block;I)V - -
 method public <init> (Lnet/minecraft/block/Block;II)V - -
 method public <init> (Lnet/minecraft/item/Item;)V - -
 method public <init> (Lnet/minecraft/item/Item;I)V - -
 method public <init> (Lnet/minecraft/item/Item;II)V - -
 method public <init> (Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)V - -
 method public <init> (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public isEmpty ()Z - -
 method public,static registerFixes (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public splitStack (I)Lnet/minecraft/item/ItemStack; - -
 method public getItem ()Lnet/minecraft/item/Item; - -
 method public onItemUse (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public onItemUseFirst (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumHand;Lnet/minecraft/util/EnumFacing;FFF)Lnet/minecraft/util/EnumActionResult; - -
 method public getDestroySpeed (Lnet/minecraft/block/state/IBlockState;)F - -
 method public useItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public onItemUseFinish (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getMaxStackSize ()I - -
 method public isStackable ()Z - -
 method public isItemStackDamageable ()Z - -
 method public getHasSubtypes ()Z - -
 method public isItemDamaged ()Z - -
 method public getItemDamage ()I - -
 method public getMetadata ()I - -
 method public setItemDamage (I)V - -
 method public getMaxDamage ()I - -
 method public attemptDamageItem (ILjava/util/Random;Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public damageItem (ILnet/minecraft/entity/EntityLivingBase;)V - -
 method public hitEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onBlockDestroyed (Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public interactWithEntity (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/util/EnumHand;)Z - -
 method public copy ()Lnet/minecraft/item/ItemStack; - -
 method public,static areItemStackTagsEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemStacksEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemsEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemsEqualIgnoreDurability (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public isItemEqual (Lnet/minecraft/item/ItemStack;)Z - -
 method public isItemEqualIgnoreDurability (Lnet/minecraft/item/ItemStack;)Z - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public updateAnimation (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;IZ)V - -
 method public onCrafting (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;I)V - -
 method public getMaxItemUseDuration ()I - -
 method public getItemUseAction ()Lnet/minecraft/item/EnumAction; - -
 method public onPlayerStoppedUsing (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public hasTagCompound ()Z - -
 method public getTagCompound ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getOrCreateSubCompound (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getSubCompound (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public removeSubCompound (Ljava/lang/String;)V - -
 method public getEnchantmentTagList ()Lnet/minecraft/nbt/NBTTagList; - -
 method public setTagCompound (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public setTranslatableName (Ljava/lang/String;)Lnet/minecraft/item/ItemStack; - -
 method public setStackDisplayName (Ljava/lang/String;)Lnet/minecraft/item/ItemStack; - -
 method public clearCustomName ()V - -
 method public hasDisplayName ()Z - -
 method public getTooltip (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/client/util/ITooltipFlag;)Ljava/util/List; (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/client/util/ITooltipFlag;)Ljava/util/List<Ljava/lang/String;>; -
 method public hasEffect ()Z - -
 method public,deprecated getRarity ()Lnet/minecraft/item/EnumRarity; - -
 method public isItemEnchantable ()Z - -
 method public addEnchantment (Lnet/minecraft/enchantment/Enchantment;I)V - -
 method public isItemEnchanted ()Z - -
 method public setTagInfo (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V - -
 method public canEditBlocks ()Z - -
 method public isOnItemFrame ()Z - -
 method public setItemFrame (Lnet/minecraft/entity/item/EntityItemFrame;)V - -
 method public getItemFrame ()Lnet/minecraft/entity/item/EntityItemFrame; - -
 method public getRepairCost ()I - -
 method public setRepairCost (I)V - -
 method public getAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public addAttributeModifier (Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getTextComponent ()Lnet/minecraft/util/text/ITextComponent; - -
 method public canDestroy (Lnet/minecraft/block/Block;)Z - -
 method public canPlaceOn (Lnet/minecraft/block/Block;)Z - -
 method public getAnimationsToGo ()I - -
 method public setAnimationsToGo (I)V - -
 method public getCount ()I - -
 method public setCount (I)V - -
 method public grow (I)V - -
 method public shrink (I)V - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public areCapsCompatible (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemStacksEqualUsingNBTShareTag (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static areItemStackShareTagsEqual (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public doesSneakBypassUse (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 90
class net/minecraft/item/ItemSword 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public getDamageVsEntity ()F - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/Block;)F - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public isFull3D ()Z - -
 method public getItemUseAction (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumAction; - -
 method public getMaxItemUseDuration (Lnet/minecraft/item/ItemStack;)I - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;)Z - -
 method public getItemEnchantability ()I - -
 method public getToolMaterialName ()Ljava/lang/String; - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemAttributeModifiers ()Lcom/google/common/collect/Multimap; ()Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
in 91
class net/minecraft/item/ItemSword 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public getDamageVsEntity ()F - -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public isFull3D ()Z - -
 method public getItemEnchantability ()I - -
 method public getToolMaterialName ()Ljava/lang/String; - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
in 326
class net/minecraft/item/ItemSword 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method public <init> (Lnet/minecraft/item/Item$ToolMaterial;)V - -
 method public getAttackDamage ()F - -
 method public getDestroySpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public isFull3D ()Z - -
 method public getItemEnchantability ()I - -
 method public getToolMaterialName ()Ljava/lang/String; - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
in 91
class net/minecraft/item/ItemTippedArrow 50 public,super net/minecraft/item/ItemArrow - -
 method public getSubItems (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List;)V (Lnet/minecraft/item/Item;Lnet/minecraft/creativetab/CreativeTabs;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public <init> ()V - -
 method public createArrow (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/projectile/EntityArrow; - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 326
class net/minecraft/item/ItemTippedArrow 52 public,super net/minecraft/item/ItemArrow - -
 method public <init> ()V - -
 method public getDefaultInstance ()Lnet/minecraft/item/ItemStack; - -
 method public createArrow (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/projectile/EntityArrow; - -
 method public getSubItems (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/creativetab/CreativeTabs;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
in 90
class net/minecraft/item/ItemTool 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 field protected efficiencyOnProperMaterial F -
 field protected toolMaterial Lnet/minecraft/item/Item$ToolMaterial; -
 method protected <init> (FLnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set;)V (FLnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set<Lnet/minecraft/block/Block;>;)V -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/Block;)F - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public isFull3D ()Z - -
 method public getToolMaterial ()Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getItemEnchantability ()I - -
 method public getToolMaterialName ()Ljava/lang/String; - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemAttributeModifiers ()Lcom/google/common/collect/Multimap; ()Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getHarvestLevel (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)I - -
 method public getToolClasses (Lnet/minecraft/item/ItemStack;)Ljava/util/Set; (Lnet/minecraft/item/ItemStack;)Ljava/util/Set<Ljava/lang/String;>; -
 method public getDigSpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
in 91
class net/minecraft/item/ItemTool 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 field protected efficiencyOnProperMaterial F -
 field protected damageVsEntity F -
 field protected attackSpeed F -
 field protected toolMaterial Lnet/minecraft/item/Item$ToolMaterial; -
 method protected <init> (FFLnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set;)V (FFLnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set<Lnet/minecraft/block/Block;>;)V -
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set;)V (Lnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set<Lnet/minecraft/block/Block;>;)V -
 method public getStrVsBlock (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public isFull3D ()Z - -
 method public getToolMaterial ()Lnet/minecraft/item/Item$ToolMaterial; - -
 method public getItemEnchantability ()I - -
 method public getToolMaterialName ()Ljava/lang/String; - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getHarvestLevel (Lnet/minecraft/item/ItemStack;Ljava/lang/String;)I - -
 method public getToolClasses (Lnet/minecraft/item/ItemStack;)Ljava/util/Set; (Lnet/minecraft/item/ItemStack;)Ljava/util/Set<Ljava/lang/String;>; -
in 326
class net/minecraft/item/ItemTool 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 field protected efficiency F -
 field protected attackDamage F -
 field protected attackSpeed F -
 field protected toolMaterial Lnet/minecraft/item/Item$ToolMaterial; -
 method protected <init> (FFLnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set;)V (FFLnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set<Lnet/minecraft/block/Block;>;)V -
 method protected <init> (Lnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set;)V (Lnet/minecraft/item/Item$ToolMaterial;Ljava/util/Set<Lnet/minecraft/block/Block;>;)V -
 method public getDestroySpeed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/block/state/IBlockState;)F - -
 method public hitEntity (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onBlockDestroyed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public isFull3D ()Z - -
 method public getItemEnchantability ()I - -
 method public getToolMaterialName ()Ljava/lang/String; - -
 method public getIsRepairable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemAttributeModifiers (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap; (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getHarvestLevel (Lnet/minecraft/item/ItemStack;Ljava/lang/String;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/block/state/IBlockState;)I - -
 method public getToolClasses (Lnet/minecraft/item/ItemStack;)Ljava/util/Set; (Lnet/minecraft/item/ItemStack;)Ljava/util/Set<Ljava/lang/String;>; -
in 90
class net/minecraft/item/ItemWritableBook 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public,static isNBTValid (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
in 91
class net/minecraft/item/ItemWritableBook 50 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public,static isNBTValid (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
in 326
class net/minecraft/item/ItemWritableBook 52 public,super net/minecraft/item/Item - -
 method public <init> ()V - -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public,static isNBTValid (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
in 91
class net/minecraft/item/ItemWrittenBook 50 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List;Z)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/player/EntityPlayer;Ljava/util/List<Ljava/lang/String;>;Z)V -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
 method public <init> ()V - -
 method public,static validBookTagContents (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public,static getGeneration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public onItemRightClick (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/item/ItemWrittenBook 52 public,super net/minecraft/item/Item - -
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public <init> ()V - -
 method public,static validBookTagContents (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public,static getGeneration (Lnet/minecraft/item/ItemStack;)I - -
 method public getItemStackDisplayName (Lnet/minecraft/item/ItemStack;)Ljava/lang/String; - -
 method public addInformation (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List;Lnet/minecraft/client/util/ITooltipFlag;)V (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/World;Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/client/util/ITooltipFlag;)V -
 method public onItemRightClick (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult; (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/ActionResult<Lnet/minecraft/item/ItemStack;>; -
 method public hasEffect (Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/item/crafting/CraftingManager 50 public,super java/lang/Object - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 inner net/minecraft/block/BlockWall$EnumType net/minecraft/block/BlockWall EnumType public,static,final,enum
 inner net/minecraft/block/BlockStoneSlab$EnumType net/minecraft/block/BlockStoneSlab EnumType public,static,final,enum
 inner net/minecraft/block/BlockStone$EnumType net/minecraft/block/BlockStone EnumType public,static,final,enum
 inner net/minecraft/block/BlockStoneSlabNew$EnumType net/minecraft/block/BlockStoneSlabNew EnumType public,static,final,enum
 method public,static getInstance ()Lnet/minecraft/item/crafting/CraftingManager; - -
 method public,varargs addRecipe (Lnet/minecraft/item/ItemStack;[Ljava/lang/Object;)Lnet/minecraft/item/crafting/ShapedRecipes; - -
 method public,varargs addShapelessRecipe (Lnet/minecraft/item/ItemStack;[Ljava/lang/Object;)V - -
 method public addRecipe (Lnet/minecraft/item/crafting/IRecipe;)V - -
 method public findMatchingRecipe (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Lnet/minecraft/item/ItemStack; - -
 method public func_180303_b (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)[Lnet/minecraft/item/ItemStack; - -
 method public getRecipeList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>; -
in 91
class net/minecraft/item/crafting/CraftingManager 50 public,super java/lang/Object - -
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 inner net/minecraft/block/BlockWall$EnumType net/minecraft/block/BlockWall EnumType public,static,final,enum
 inner net/minecraft/block/BlockStoneSlab$EnumType net/minecraft/block/BlockStoneSlab EnumType public,static,final,enum
 inner net/minecraft/block/BlockStone$EnumType net/minecraft/block/BlockStone EnumType public,static,final,enum
 inner net/minecraft/block/BlockStoneSlabNew$EnumType net/minecraft/block/BlockStoneSlabNew EnumType public,static,final,enum
 method public,static getInstance ()Lnet/minecraft/item/crafting/CraftingManager; - -
 method public,varargs addRecipe (Lnet/minecraft/item/ItemStack;[Ljava/lang/Object;)Lnet/minecraft/item/crafting/ShapedRecipes; - -
 method public,varargs addShapelessRecipe (Lnet/minecraft/item/ItemStack;[Ljava/lang/Object;)V - -
 method public addRecipe (Lnet/minecraft/item/crafting/IRecipe;)V - -
 method public findMatchingRecipe (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)[Lnet/minecraft/item/ItemStack; - -
 method public getRecipeList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>; -
in 326
class net/minecraft/item/crafting/CraftingManager 52 public,super java/lang/Object - -
 inner net/minecraft/item/crafting/RecipesBanners$RecipeDuplicatePattern net/minecraft/item/crafting/RecipesBanners RecipeDuplicatePattern public,static
 inner net/minecraft/item/crafting/RecipesBanners$RecipeAddPattern net/minecraft/item/crafting/RecipesBanners RecipeAddPattern public,static
 inner net/minecraft/item/crafting/ShieldRecipes$Decoration net/minecraft/item/crafting/ShieldRecipes Decoration public,static
 inner net/minecraft/item/crafting/ShulkerBoxRecipes$ShulkerBoxColoring net/minecraft/item/crafting/ShulkerBoxRecipes ShulkerBoxColoring public,static
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespaced; Lnet/minecraft/util/registry/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/item/crafting/IRecipe;>;
 method public <init> ()V - -
 method public,static init ()Z - -
 method public,static findMatchingResult (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Lnet/minecraft/item/ItemStack; - -
 method public,static findMatchingRecipe (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Lnet/minecraft/item/crafting/IRecipe; - -
 method public,static getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public,static getRecipe (Lnet/minecraft/util/ResourceLocation;)Lnet/minecraft/item/crafting/IRecipe; - -
 method public,static,deprecated getIDForRecipe (Lnet/minecraft/item/crafting/IRecipe;)I - -
 method public,static,deprecated getRecipeById (I)Lnet/minecraft/item/crafting/IRecipe; - -
in 24
class net/minecraft/item/crafting/FurnaceRecipes 50 public,super java/lang/Object - -
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static instance ()Lnet/minecraft/item/crafting/FurnaceRecipes; - -
 method public addSmeltingRecipeForBlock (Lnet/minecraft/block/Block;Lnet/minecraft/item/ItemStack;F)V - -
 method public addSmelting (Lnet/minecraft/item/Item;Lnet/minecraft/item/ItemStack;F)V - -
 method public addSmeltingRecipe (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;F)V - -
 method public getSmeltingResult (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public getSmeltingList ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;>; -
 method public getSmeltingExperience (Lnet/minecraft/item/ItemStack;)F - -
in 326
class net/minecraft/item/crafting/FurnaceRecipes 52 public,super java/lang/Object - -
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static instance ()Lnet/minecraft/item/crafting/FurnaceRecipes; - -
 method public addSmeltingRecipeForBlock (Lnet/minecraft/block/Block;Lnet/minecraft/item/ItemStack;F)V - -
 method public addSmelting (Lnet/minecraft/item/Item;Lnet/minecraft/item/ItemStack;F)V - -
 method public addSmeltingRecipe (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;F)V - -
 method public getSmeltingResult (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public getSmeltingList ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;>; -
 method public getSmeltingExperience (Lnet/minecraft/item/ItemStack;)F - -
in 24
class net/minecraft/item/crafting/IRecipe 50 public,interface,abstract java/lang/Object - -
 method public,abstract matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public,abstract getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public,abstract getRecipeSize ()I - -
 method public,abstract getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public,abstract getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/IRecipe 52 public,interface,abstract java/lang/Object net/minecraftforge/registries/IForgeRegistryEntry Ljava/lang/Object;Lnet/minecraftforge/registries/IForgeRegistryEntry<Lnet/minecraft/item/crafting/IRecipe;>;
 method public,abstract matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public,abstract getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public,abstract canFit (II)Z - -
 method public,abstract getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public getIngredients ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/crafting/Ingredient;>; -
 method public isDynamic ()Z - -
 method public getGroup ()Ljava/lang/String; - -
in 326
class net/minecraft/item/crafting/Ingredient 52 public,super java/lang/Object com/google/common/base/Predicate Ljava/lang/Object;Lcom/google/common/base/Predicate<Lnet/minecraft/item/ItemStack;>;
 field public,static,final EMPTY Lnet/minecraft/item/crafting/Ingredient; -
 method protected <init> (I)V - -
 method protected,varargs <init> ([Lnet/minecraft/item/ItemStack;)V - -
 method public getMatchingStacks ()[Lnet/minecraft/item/ItemStack; - -
 method public apply (Lnet/minecraft/item/ItemStack;)Z - -
 method public getValidItemStacksPacked ()Lit/unimi/dsi/fastutil/ints/IntList; - -
 method public,static invalidateAll ()V - -
 method protected invalidate ()V - -
 method public,static fromItem (Lnet/minecraft/item/Item;)Lnet/minecraft/item/crafting/Ingredient; - -
 method public,static,varargs fromItems ([Lnet/minecraft/item/Item;)Lnet/minecraft/item/crafting/Ingredient; - -
 method public,static,varargs fromStacks ([Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/crafting/Ingredient; - -
 method public,static merge (Ljava/util/Collection;)Lnet/minecraft/item/crafting/Ingredient; (Ljava/util/Collection<Lnet/minecraft/item/crafting/Ingredient;>;)Lnet/minecraft/item/crafting/Ingredient; -
 method public isSimple ()Z - -
in 24
class net/minecraft/item/crafting/RecipeBookCloning 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipeBookCloning 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 24
class net/minecraft/item/crafting/RecipeFireworks 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipeFireworks 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 24
class net/minecraft/item/crafting/RecipeRepairItem 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipeRepairItem 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 91
class net/minecraft/item/crafting/RecipeTippedArrow 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipeTippedArrow 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 24
class net/minecraft/item/crafting/RecipesArmor 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 24
class net/minecraft/item/crafting/RecipesArmorDyes 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipesArmorDyes 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 24
class net/minecraft/item/crafting/RecipesBanners 50 public,super java/lang/Object - -
 inner net/minecraft/item/crafting/RecipesBanners$RecipeDuplicatePattern net/minecraft/item/crafting/RecipesBanners RecipeDuplicatePattern public,static
 inner net/minecraft/item/crafting/RecipesBanners$RecipeAddPattern net/minecraft/item/crafting/RecipesBanners RecipeAddPattern public,static
 method public <init> ()V - -
in 326
class net/minecraft/item/crafting/RecipesBanners 52 public,super java/lang/Object - -
 inner net/minecraft/item/crafting/RecipesBanners$RecipeDuplicatePattern net/minecraft/item/crafting/RecipesBanners RecipeDuplicatePattern public,static
 inner net/minecraft/item/crafting/RecipesBanners$RecipeAddPattern net/minecraft/item/crafting/RecipesBanners RecipeAddPattern public,static
 method public <init> ()V - -
in 24
class net/minecraft/item/crafting/RecipesBanners$RecipeAddPattern 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 inner net/minecraft/item/crafting/RecipesBanners$RecipeAddPattern net/minecraft/item/crafting/RecipesBanners RecipeAddPattern public,static
 inner net/minecraft/tileentity/TileEntityBanner$EnumBannerPattern net/minecraft/tileentity/TileEntityBanner EnumBannerPattern public,static,final,enum
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipesBanners$RecipeAddPattern 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraft/item/crafting/RecipesBanners$RecipeAddPattern net/minecraft/item/crafting/RecipesBanners RecipeAddPattern public,static
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 24
class net/minecraft/item/crafting/RecipesBanners$RecipeDuplicatePattern 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 inner net/minecraft/item/crafting/RecipesBanners$RecipeDuplicatePattern net/minecraft/item/crafting/RecipesBanners RecipeDuplicatePattern public,static
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipesBanners$RecipeDuplicatePattern 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraft/item/crafting/RecipesBanners$RecipeDuplicatePattern net/minecraft/item/crafting/RecipesBanners RecipeDuplicatePattern public,static
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 24
class net/minecraft/item/crafting/RecipesCrafting 50 public,super java/lang/Object - -
 inner net/minecraft/block/BlockSand$EnumType net/minecraft/block/BlockSand EnumType public,static,final,enum
 inner net/minecraft/block/BlockSandStone$EnumType net/minecraft/block/BlockSandStone EnumType public,static,final,enum
 inner net/minecraft/block/BlockRedSandstone$EnumType net/minecraft/block/BlockRedSandstone EnumType public,static,final,enum
 inner net/minecraft/block/BlockStoneSlab$EnumType net/minecraft/block/BlockStoneSlab EnumType public,static,final,enum
 inner net/minecraft/block/BlockStoneSlabNew$EnumType net/minecraft/block/BlockStoneSlabNew EnumType public,static,final,enum
 inner net/minecraft/block/BlockQuartz$EnumType net/minecraft/block/BlockQuartz EnumType public,static,final,enum
 inner net/minecraft/block/BlockStone$EnumType net/minecraft/block/BlockStone EnumType public,static,final,enum
 inner net/minecraft/block/BlockDirt$DirtType net/minecraft/block/BlockDirt DirtType public,static,final,enum
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 24
class net/minecraft/item/crafting/RecipesDyes 50 public,super java/lang/Object - -
 inner net/minecraft/block/BlockFlower$EnumFlowerType net/minecraft/block/BlockFlower EnumFlowerType public,static,final,enum
 inner net/minecraft/block/BlockDoublePlant$EnumPlantType net/minecraft/block/BlockDoublePlant EnumPlantType public,static,final,enum
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 24
class net/minecraft/item/crafting/RecipesFood 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 24
class net/minecraft/item/crafting/RecipesIngots 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 24
class net/minecraft/item/crafting/RecipesMapCloning 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipesMapCloning 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 24
class net/minecraft/item/crafting/RecipesMapExtending 50 public,super net/minecraft/item/crafting/ShapedRecipes - -
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/RecipesMapExtending 52 public,super net/minecraft/item/crafting/ShapedRecipes - -
 inner net/minecraft/world/storage/MapDecoration$Type net/minecraft/world/storage/MapDecoration Type public,static,final,enum
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public isDynamic ()Z - -
in 24
class net/minecraft/item/crafting/RecipesTools 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 24
class net/minecraft/item/crafting/RecipesWeapons 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 24
class net/minecraft/item/crafting/ShapedRecipes 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 field public,final recipeWidth I -
 field public,final recipeHeight I -
 field public,final recipeItems [Lnet/minecraft/item/ItemStack; -
 method public <init> (II[Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
in 326
class net/minecraft/item/crafting/ShapedRecipes 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/common/crafting/IShapedRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraftforge/common/crafting/IShapedRecipe;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 field public,final recipeWidth I -
 field public,final recipeHeight I -
 field public,final recipeItems Lnet/minecraft/util/NonNullList; Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/crafting/Ingredient;>;
 method public <init> (Ljava/lang/String;IILnet/minecraft/util/NonNullList;Lnet/minecraft/item/ItemStack;)V (Ljava/lang/String;IILnet/minecraft/util/NonNullList<Lnet/minecraft/item/crafting/Ingredient;>;Lnet/minecraft/item/ItemStack;)V -
 method public getGroup ()Ljava/lang/String; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public getIngredients ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/crafting/Ingredient;>; -
 method public canFit (II)Z - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public,static deserialize (Lcom/google/gson/JsonObject;)Lnet/minecraft/item/crafting/ShapedRecipes; - -
 method public,static deserializeIngredient (Lcom/google/gson/JsonElement;)Lnet/minecraft/item/crafting/Ingredient; - -
 method public,static deserializeItem (Lcom/google/gson/JsonObject;Z)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeWidth ()I - -
 method public getRecipeHeight ()I - -
in 24
class net/minecraft/item/crafting/ShapelessRecipes 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 field public,final recipeItems Ljava/util/List; Ljava/util/List<Lnet/minecraft/item/ItemStack;>;
 method public <init> (Lnet/minecraft/item/ItemStack;Ljava/util/List;)V (Lnet/minecraft/item/ItemStack;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
in 326
class net/minecraft/item/crafting/ShapelessRecipes 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 field public,final recipeItems Lnet/minecraft/util/NonNullList; Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/crafting/Ingredient;>;
 method public <init> (Ljava/lang/String;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/NonNullList;)V (Ljava/lang/String;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/crafting/Ingredient;>;)V -
 method public getGroup ()Ljava/lang/String; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getIngredients ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/crafting/Ingredient;>; -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public,static deserialize (Lcom/google/gson/JsonObject;)Lnet/minecraft/item/crafting/ShapelessRecipes; - -
 method public canFit (II)Z - -
in 91
class net/minecraft/item/crafting/ShieldRecipes 50 public,super java/lang/Object - -
 inner net/minecraft/item/crafting/ShieldRecipes$Decoration net/minecraft/item/crafting/ShieldRecipes Decoration public,static
 method public <init> ()V - -
 method public addRecipes (Lnet/minecraft/item/crafting/CraftingManager;)V - -
in 326
class net/minecraft/item/crafting/ShieldRecipes 52 public,super java/lang/Object - -
 inner net/minecraft/item/crafting/ShieldRecipes$Decoration net/minecraft/item/crafting/ShieldRecipes Decoration public,static
 method public <init> ()V - -
in 91
class net/minecraft/item/crafting/ShieldRecipes$Decoration 50 public,super java/lang/Object net/minecraft/item/crafting/IRecipe -
 inner net/minecraft/item/crafting/ShieldRecipes$Decoration net/minecraft/item/crafting/ShieldRecipes Decoration public,static
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeSize ()I - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)[Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/item/crafting/ShieldRecipes$Decoration 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraft/item/crafting/ShieldRecipes$Decoration net/minecraft/item/crafting/ShieldRecipes Decoration public,static
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
in 326
class net/minecraft/item/crafting/ShulkerBoxRecipes 52 public,super java/lang/Object - -
 inner net/minecraft/item/crafting/ShulkerBoxRecipes$ShulkerBoxColoring net/minecraft/item/crafting/ShulkerBoxRecipes ShulkerBoxColoring public,static
 method public <init> ()V - -
in 326
class net/minecraft/item/crafting/ShulkerBoxRecipes$ShulkerBoxColoring 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraft/item/crafting/IRecipe Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/item/crafting/IRecipe;
 inner net/minecraft/item/crafting/ShulkerBoxRecipes$ShulkerBoxColoring net/minecraft/item/crafting/ShulkerBoxRecipes ShulkerBoxColoring public,static
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public matches (Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/world/World;)Z - -
 method public getCraftingResult (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/item/ItemStack; - -
 method public getRecipeOutput ()Lnet/minecraft/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList; (Lnet/minecraft/inventory/InventoryCrafting;)Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isDynamic ()Z - -
 method public canFit (II)Z - -
