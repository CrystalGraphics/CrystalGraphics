cg-stub-db 1
in 90
class tv/twitch/AuthToken 50 public,super java/lang/Object - -
 field public data Ljava/lang/String; -
 method public <init> ()V - -
 method public getIsValid ()Z - -
in 90
class tv/twitch/Core 50 public,super java/lang/Object - -
 method public,static getInstance ()Ltv/twitch/Core; - -
 method public <init> (Ltv/twitch/CoreAPI;)V - -
 method public getIsInitialized ()Z - -
 method public initialize (Ljava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public shutdown ()Ltv/twitch/ErrorCode; - -
 method public setTraceLevel (Ltv/twitch/MessageLevel;)Ltv/twitch/ErrorCode; - -
 method public errorToString (Ltv/twitch/ErrorCode;)Ljava/lang/String; - -
in 90
class tv/twitch/CoreAPI 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract init (Ljava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract shutdown ()Ltv/twitch/ErrorCode; - -
 method public,abstract setTraceLevel (Ltv/twitch/MessageLevel;)Ltv/twitch/ErrorCode; - -
 method public,abstract setTraceOutput (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract errorToString (Ltv/twitch/ErrorCode;)Ljava/lang/String; - -
in 90
class tv/twitch/ErrorCode 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/ErrorCode;>;
 field public,static,final,enum TTV_EC_SUCCESS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_UNKNOWN_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CANNOT_OPEN_FILE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_ALREADY_INITIALIZED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CANNOT_WRITE_TO_FILE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CANNOT_CREATE_MUTEX Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CANNOT_DESTROY_MUTEX Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_COULD_NOT_TAKE_MUTEX Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_COULD_NOT_RELEASE_MUTEX Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_MUTEX Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WAIT_TIMED_OUT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_ARG Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_NOT_INITIALIZED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_AUTHENTICATION Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_AUTHTOKEN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_MEMORY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_ALIGN16_REQUIRED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_UNSUPPORTED_INPUT_FORMAT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_UNSUPPORTED_OUTPUT_FORMAT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_RESOLUTION Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_FPS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_BITRATE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_FAILED_TO_INIT_SPEAKER_CAPTURE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_FRAME_QUEUE_FULL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_HTTPREQUEST_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_CLIENTID Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_CHANNEL_NAME Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_API_REQUEST_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_API_REQUEST_TIMEDOUT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_HTTP_REQUEST_PARAMS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_COINITIALIZE_FAIED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_INVALID_JSON Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_AUTHTOKEN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_STREAMKEY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_CHANNELNAME Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_INGESTS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_RECORDING_STATUS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_STREAMINFO Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_INVALID_VIEWERS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_USERNAME Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBAPI_RESULT_NO_USER_DISPLAY_NAME Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_NO_STREAM_KEY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_NEED_TO_LOGIN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_VIDEOFRAME Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_BUFFER Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_CALLBACK Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_JSON Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_NO_SPSPPS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_NO_D3D_SUPPORT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_NO_INGEST_SERVER_AVAILABLE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_INGEST_SERVER Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CANNOT_SUSPEND_THREADSYNC Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CANNOT_SIGNAL_THREADSYNC Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_ENCODER Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_AUDIO_DEVICE_INIT_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_AUDIO_BUFFER_TOO_BIG Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_AUDIO_PASSTHROUGH_NOT_ENABLED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_SAMPLERATE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_X264_INVALID_PRESET Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_X264_INVALID_PROFILE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_FLV_UNABLE_TO_OPEN_FILE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_FLV_FILE_NOT_OPEN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_FLV_UNSUPPORTED_AUDIO_RATE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_FLV_UNSUPPORTED_AUDIO_CODEC Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_RTMP_REJECTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_RTMP_WRONG_PROTOCOL_IN_URL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_RTMP_UNABLE_TO_SEND_DATA Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_RTMP_INVALID_FLV_PACKET Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_RTMP_TIMEOUT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_MAC_INPUT_Q_SETUP_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_MAC_INPUT_Q_BUFFER_SETUP_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_MAC_INPUT_Q_START_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INTEL_FAILED_SESSION_INIT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INTEL_FAILED_VPP_INIT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INTEL_FAILED_ENCODER_INIT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INTEL_FAILED_SURFACE_ALLOCATION Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INTEL_FAILED_TASKPOLL_INIT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INTEL_NO_FREE_TASK Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INTEL_NO_FREE_SURFACE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_APPLEENCODER_FAILED_START Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_APPLEENCODER_FAILED_FRAME_SUBMISSION Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_LAMEMP3_FAILED_INIT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_LAMEMP3_FAILED_SHUTDOWN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_APPLEAAC_FAILED_INIT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_APPLEAAC_FAILED_ENCODING Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_APPLEAAC_FAILED_SHUTDOWN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_REQUEST_PENDING Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WSASTARTUP_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WSACLEANUP_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_GETADDRINFO_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_CREATE_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_CONNECT_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_SEND_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_RECV_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_IOCTL_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_OS_TOO_OLD Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ERR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EINTR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EBADF Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EACCES Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EFAULT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EINVAL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EMFILE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EWOULDBLOCK Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EINPROGRESS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EALREADY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENOTSOCK Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EDESTADDRREQ Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EMSGSIZE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EPROTOTYPE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENOPROTOOPT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EPROTONOSUPPORT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ESOCKTNOSUPPORT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EOPNOTSUPP Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EPFNOSUPPORT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EAFNOSUPPORT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EADDRINUSE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EADDRNOTAVAIL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENETDOWN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENETUNREACH Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENETRESET Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ECONNABORTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ECONNRESET Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENOBUFS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EISCONN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENOTCONN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ESHUTDOWN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ETOOMANYREFS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ETIMEDOUT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ECONNREFUSED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ELOOP Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENAMETOOLONG Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EHOSTDOWN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EHOSTUNREACH Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENOTEMPTY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EPROCLIM Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EUSERS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EDQUOT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ESTALE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EREMOTE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_SYSNOTREADY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_VERNOTSUPPORTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_NOTINITIALISED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EDISCON Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ENOMORE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_ECANCELLED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EINVALIDPROCTABLE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EINVALIDPROVIDER Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EPROVIDERFAILEDINIT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_SYSCALLFAILURE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_SERVICE_NOT_FOUND Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_TYPE_NOT_FOUND Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_E_NO_MORE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_E_CANCELLED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_EREFUSED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_HOST_NOT_FOUND Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_TRY_AGAIN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_NO_RECOVERY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_NO_DATA Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_RECEIVERS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_SENDERS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_NO_SENDERS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_NO_RECEIVERS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_REQUEST_CONFIRMED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_ADMISSION_FAILURE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_POLICY_FAILURE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_BAD_STYLE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_BAD_OBJECT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_TRAFFIC_CTRL_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_GENERIC_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_ESERVICETYPE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EFLOWSPEC Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EPROVSPECBUF Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EFILTERSTYLE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EFILTERTYPE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EFILTERCOUNT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EOBJLENGTH Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EFLOWCOUNT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EUNKOWNPSOBJ Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EPOLICYOBJ Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EFLOWDESC Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EPSFLOWSPEC Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_EPSFILTERSPEC Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_ESDMODEOBJ Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_ESHAPERATEOBJ Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_QOS_RESERVED_PETYPE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_SECURE_HOST_NOT_FOUND Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_IPSEC_NAME_POLICY_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOCKET_END Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_NOT_INITIALIZED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_ALREADY_INITIALIZED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_ALREADY_IN_CHANNEL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_INVALID_LOGIN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_INVALID_CHANNEL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_LOST_CONNECTION Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_COULD_NOT_CONNECT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_NOT_IN_CHANNEL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_INVALID_MESSAGE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_TOO_MANY_REQUESTS Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_LEAVING_CHANNEL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_SHUTTING_DOWN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_ANON_DENIED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_EMOTICON_DATA_NOT_READY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_EMOTICON_DATA_DOWNLOADING Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_EMOTICON_DATA_LOCKED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_CHAT_EMOTICON_DOWNLOAD_FAILED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_NO_PLATFORM_SUPPORT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_COULD_NOT_COMPLETE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_OUT_OF_MEMORY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_UNKNOWN_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_INVALID_PARAMETER Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_INVALID_CAPABILITY Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_BUFFER_NOT_BIG_ENOUGH Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_DEVICE_NOT_STARTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_DEVICE_ALREADY_STARTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_DEVICE_NOT_FOUND Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_FRAME_NOT_AVAILABLE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_NOT_INITIALIZED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_FAILED_TO_START Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_LEFT_IN_UNSAFE_STATE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_UNSUPPORTED_SOURCE_FORMAT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WEBCAM_UNSUPPORTED_TARGET_FORMAT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_INVALID_STRUCT_SIZE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_STREAM_ALREADY_STARTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_STREAM_NOT_STARTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_REQUEST_ABORTED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_FRAME_QUEUE_TOO_LONG Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_GRAPHICS_API_ERROR Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_METADATA_CACHE_FULL Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_SOUNDFLOWER_NOT_INSTALLED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_STILL_IN_USE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_NO_ENCODER_PLUGIN Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_EC_WARNING_START Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_MUTEX_LOCKED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_FAILED_TO_INIT_MIC_CAPTURE Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_NOTENOUGHDATA Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_NOMOREDATA Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_FRAMES_QUEUEING Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_MUTEX_NOT_AQUIRED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_PREV_GAME_NAME_MATCH_REQUEST_DROPPED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_DEPRECATED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_CHAT_MESSAGE_SPAM_DISCARDED Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_WAIT_TIMEOUT Ltv/twitch/ErrorCode; -
 field public,static,final,enum TTV_WRN_STREAMINFO_PENDING Ltv/twitch/ErrorCode; -
 method public,static values ()[Ltv/twitch/ErrorCode; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,static lookupValue (I)Ltv/twitch/ErrorCode; - -
 method public getValue ()I - -
 method public,static succeeded (Ltv/twitch/ErrorCode;)Z - -
 method public,static failed (Ltv/twitch/ErrorCode;)Z - -
 method public,static getString (Ltv/twitch/ErrorCode;)Ljava/lang/String; - -
in 90
class tv/twitch/MessageLevel 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/MessageLevel;>;
 field public,static,final,enum TTV_ML_DEBUG Ltv/twitch/MessageLevel; -
 field public,static,final,enum TTV_ML_INFO Ltv/twitch/MessageLevel; -
 field public,static,final,enum TTV_ML_WARNING Ltv/twitch/MessageLevel; -
 field public,static,final,enum TTV_ML_ERROR Ltv/twitch/MessageLevel; -
 field public,static,final,enum TTV_ML_CHAT Ltv/twitch/MessageLevel; -
 field public,static,final,enum TTV_ML_NONE Ltv/twitch/MessageLevel; -
 method public,static values ()[Ltv/twitch/MessageLevel; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/MessageLevel; - -
 method public,static lookupValue (I)Ltv/twitch/MessageLevel; - -
 method public getValue ()I - -
in 90
class tv/twitch/StandardCoreAPI 50 public,super tv/twitch/CoreAPI - -
 method public <init> ()V - -
 method protected finalize ()V - -
 method public init (Ljava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public shutdown ()Ltv/twitch/ErrorCode; - -
 method public setTraceLevel (Ltv/twitch/MessageLevel;)Ltv/twitch/ErrorCode; - -
 method public setTraceOutput (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public errorToString (Ltv/twitch/ErrorCode;)Ljava/lang/String; - -
in 90
class tv/twitch/VideoEncoder 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/VideoEncoder;>;
 field public,static,final,enum TTV_VID_ENC_DISABLE Ltv/twitch/VideoEncoder; -
 field public,static,final,enum TTV_VID_ENC_DEFAULT Ltv/twitch/VideoEncoder; -
 field public,static,final,enum TTV_VID_ENC_INTEL Ltv/twitch/VideoEncoder; -
 field public,static,final,enum TTV_VID_ENC_APPLE Ltv/twitch/VideoEncoder; -
 field public,static,final,enum TTV_VID_ENC_PLUGIN Ltv/twitch/VideoEncoder; -
 method public,static values ()[Ltv/twitch/VideoEncoder; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/VideoEncoder; - -
 method public,static lookupValue (I)Ltv/twitch/VideoEncoder; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/ArchivingState 50 public,super java/lang/Object - -
 field public recordingEnabled Z -
 field public cureUrl Ljava/lang/String; -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/AudioDeviceType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/AudioDeviceType;>;
 field public,static,final,enum TTV_PLAYBACK_DEVICE Ltv/twitch/broadcast/AudioDeviceType; -
 field public,static,final,enum TTV_RECORDER_DEVICE Ltv/twitch/broadcast/AudioDeviceType; -
 field public,static,final,enum TTV_PASSTHROUGH_DEVICE Ltv/twitch/broadcast/AudioDeviceType; -
 field public,static,final,enum TTV_DEVICE_NUM Ltv/twitch/broadcast/AudioDeviceType; -
 method public,static values ()[Ltv/twitch/broadcast/AudioDeviceType; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/AudioDeviceType; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/AudioDeviceType; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/AudioEncoder 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/AudioEncoder;>;
 field public,static,final,enum TTV_AUD_ENC_DEFAULT Ltv/twitch/broadcast/AudioEncoder; -
 field public,static,final,enum TTV_AUD_ENC_LAMEMP3 Ltv/twitch/broadcast/AudioEncoder; -
 field public,static,final,enum TTV_AUD_ENC_APPLEAAC Ltv/twitch/broadcast/AudioEncoder; -
 method public,static values ()[Ltv/twitch/broadcast/AudioEncoder; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/AudioEncoder; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/AudioEncoder; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/AudioParams 50 public,super java/lang/Object - -
 field public audioEnabled Z -
 field public enableMicCapture Z -
 field public enablePlaybackCapture Z -
 field public enablePassthroughAudio Z -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/AudioSampleFormat 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/AudioSampleFormat;>;
 field public,static,final,enum TTV_ASF_PCM_S16 Ltv/twitch/broadcast/AudioSampleFormat; -
 method public,static values ()[Ltv/twitch/broadcast/AudioSampleFormat; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/AudioSampleFormat; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/AudioSampleFormat; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/AuthFlag 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/AuthFlag;>;
 field public,static,final,enum TTV_AuthOption_None Ltv/twitch/broadcast/AuthFlag; -
 field public,static,final,enum TTV_AuthOption_Broadcast Ltv/twitch/broadcast/AuthFlag; -
 field public,static,final,enum TTV_AuthOption_Chat Ltv/twitch/broadcast/AuthFlag; -
 method public,static values ()[Ltv/twitch/broadcast/AuthFlag; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/AuthFlag; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/AuthFlag; - -
 method public,static getNativeValue (Ljava/util/HashSet;)I (Ljava/util/HashSet<Ltv/twitch/broadcast/AuthFlag;>;)I -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/AuthParams 50 public,super java/lang/Object - -
 field public userName Ljava/lang/String; -
 field public password Ljava/lang/String; -
 field public clientSecret Ljava/lang/String; -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/ChannelInfo 50 public,super java/lang/Object - -
 field public displayName Ljava/lang/String; -
 field public name Ljava/lang/String; -
 field public channelUrl Ljava/lang/String; -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/Constants 50 public,super java/lang/Object - -
 field public,static,final TTV_MIN_BITRATE I - I230
 field public,static,final TTV_MAX_BITRATE I - I3500
 field public,static,final TTV_MIN_FPS I - I10
 field public,static,final TTV_MAX_FPS I - I60
 field public,static,final TTV_MAX_WIDTH I - I1920
 field public,static,final TTV_MAX_HEIGHT I - I1200
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/DesktopStreamAPI 50 public,super tv/twitch/broadcast/StreamAPI - -
 method public <init> ()V - -
 method protected finalize ()V - -
 method public setStreamCallbacks (Ltv/twitch/broadcast/IStreamCallbacks;)V - -
 method public getStreamCallbacks ()Ltv/twitch/broadcast/IStreamCallbacks; - -
 method public setStatCallbacks (Ltv/twitch/broadcast/IStatCallbacks;)V - -
 method public getStatCallbacks ()Ltv/twitch/broadcast/IStatCallbacks; - -
 method public requestAuthToken (Ltv/twitch/broadcast/AuthParams;Ljava/util/HashSet;)Ltv/twitch/ErrorCode; (Ltv/twitch/broadcast/AuthParams;Ljava/util/HashSet<Ltv/twitch/broadcast/AuthFlag;>;)Ltv/twitch/ErrorCode; -
 method public login (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public getIngestServers (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public getUserInfo (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public getStreamInfo (Ltv/twitch/AuthToken;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public setStreamInfo (Ltv/twitch/AuthToken;Ljava/lang/String;Ltv/twitch/broadcast/StreamInfoForSetting;)Ltv/twitch/ErrorCode; - -
 method public getArchivingState (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public runCommercial (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public setVolume (Ltv/twitch/broadcast/AudioDeviceType;F)Ltv/twitch/ErrorCode; - -
 method public getVolume (Ltv/twitch/broadcast/AudioDeviceType;)F - -
 method public getGameNameList (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public getDefaultParams (Ltv/twitch/broadcast/VideoParams;)Ltv/twitch/ErrorCode; - -
 method public getMaxResolution (IIFF)[I - -
 method public pollTasks ()Ltv/twitch/ErrorCode; - -
 method public pollStats ()Ltv/twitch/ErrorCode; - -
 method public sendActionMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public sendStartSpanMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;)J - -
 method public sendEndSpanMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public submitVideoFrame (J)Ltv/twitch/ErrorCode; - -
 method public start (Ltv/twitch/broadcast/VideoParams;Ltv/twitch/broadcast/AudioParams;Ltv/twitch/broadcast/IngestServer;IZ)Ltv/twitch/ErrorCode; - -
 method public stop (Z)Ltv/twitch/ErrorCode; - -
 method public pauseVideo ()Ltv/twitch/ErrorCode; - -
 method public allocateFrameBuffer (I)J - -
 method public freeFrameBuffer (J)Ltv/twitch/ErrorCode; - -
 method public memsetFrameBuffer (JII)Ltv/twitch/ErrorCode; - -
 method public randomizeFrameBuffer (JI)Ltv/twitch/ErrorCode; - -
 method public captureFrameBuffer_ReadPixels (J)Ltv/twitch/ErrorCode; - -
 method public getStreamTime ()J - -
in 90
class tv/twitch/broadcast/EncodingCpuUsage 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/EncodingCpuUsage;>;
 field public,static,final,enum TTV_ECU_LOW Ltv/twitch/broadcast/EncodingCpuUsage; -
 field public,static,final,enum TTV_ECU_MEDIUM Ltv/twitch/broadcast/EncodingCpuUsage; -
 field public,static,final,enum TTV_ECU_HIGH Ltv/twitch/broadcast/EncodingCpuUsage; -
 method public,static values ()[Ltv/twitch/broadcast/EncodingCpuUsage; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/EncodingCpuUsage; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/EncodingCpuUsage; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/FrameBuffer 50 public,super java/lang/Object - -
 field protected m_NativeAddress J -
 field protected m_Size I -
 field protected m_API Ltv/twitch/broadcast/StreamAPI; -
 method public,static lookupBuffer (J)Ltv/twitch/broadcast/FrameBuffer; - -
 method protected,static registerBuffer (Ltv/twitch/broadcast/FrameBuffer;)V - -
 method protected,static unregisterBuffer (Ltv/twitch/broadcast/FrameBuffer;)V - -
 method public getIsValid ()Z - -
 method public getSize ()I - -
 method public getAddress ()J - -
 method public free ()V - -
 method protected finalize ()V - -
in 90
class tv/twitch/broadcast/GameInfo 50 public,super java/lang/Object - -
 field public name Ljava/lang/String; -
 field public popularity I -
 field public id I -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/GameInfoList 50 public,super java/lang/Object - -
 field public list [Ltv/twitch/broadcast/GameInfo; -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/IStatCallbacks 50 public,interface,abstract java/lang/Object - -
 method public,abstract statCallback (Ltv/twitch/broadcast/StatType;J)V - -
in 90
class tv/twitch/broadcast/IStreamCallbacks 50 public,interface,abstract java/lang/Object - -
 method public,abstract requestAuthTokenCallback (Ltv/twitch/ErrorCode;Ltv/twitch/AuthToken;)V - -
 method public,abstract loginCallback (Ltv/twitch/ErrorCode;Ltv/twitch/broadcast/ChannelInfo;)V - -
 method public,abstract getIngestServersCallback (Ltv/twitch/ErrorCode;Ltv/twitch/broadcast/IngestList;)V - -
 method public,abstract getUserInfoCallback (Ltv/twitch/ErrorCode;Ltv/twitch/broadcast/UserInfo;)V - -
 method public,abstract getStreamInfoCallback (Ltv/twitch/ErrorCode;Ltv/twitch/broadcast/StreamInfo;)V - -
 method public,abstract getArchivingStateCallback (Ltv/twitch/ErrorCode;Ltv/twitch/broadcast/ArchivingState;)V - -
 method public,abstract runCommercialCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract setStreamInfoCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract getGameNameListCallback (Ltv/twitch/ErrorCode;Ltv/twitch/broadcast/GameInfoList;)V - -
 method public,abstract bufferUnlockCallback (J)V - -
 method public,abstract startCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract stopCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract sendActionMetaDataCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract sendStartSpanMetaDataCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract sendEndSpanMetaDataCallback (Ltv/twitch/ErrorCode;)V - -
in 90
class tv/twitch/broadcast/IngestList 50 public,super java/lang/Object - -
 field protected servers [Ltv/twitch/broadcast/IngestServer; -
 field protected defaultServer Ltv/twitch/broadcast/IngestServer; -
 method public getServers ()[Ltv/twitch/broadcast/IngestServer; - -
 method public getDefaultServer ()Ltv/twitch/broadcast/IngestServer; - -
 method public <init> ([Ltv/twitch/broadcast/IngestServer;)V - -
 method public getBestServer ()Ltv/twitch/broadcast/IngestServer; - -
in 90
class tv/twitch/broadcast/IngestServer 50 public,super java/lang/Object - -
 field public serverName Ljava/lang/String; -
 field public serverUrl Ljava/lang/String; -
 field public defaultServer Z -
 field public bitrateKbps F -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/PixelFormat 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/PixelFormat;>;
 field public,static,final,enum TTV_PF_BGRA Ltv/twitch/broadcast/PixelFormat; -
 field public,static,final,enum TTV_PF_ABGR Ltv/twitch/broadcast/PixelFormat; -
 field public,static,final,enum TTV_PF_RGBA Ltv/twitch/broadcast/PixelFormat; -
 field public,static,final,enum TTV_PF_ARGB Ltv/twitch/broadcast/PixelFormat; -
 method public,static values ()[Ltv/twitch/broadcast/PixelFormat; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/PixelFormat; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/PixelFormat; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/RTMPState 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/RTMPState;>;
 field public,static,final,enum Invalid Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum Idle Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum Initialize Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum Handshake Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum Connect Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum CreateStream Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum Publish Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum SendVideo Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum Shutdown Ltv/twitch/broadcast/RTMPState; -
 field public,static,final,enum Error Ltv/twitch/broadcast/RTMPState; -
 method public,static values ()[Ltv/twitch/broadcast/RTMPState; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/RTMPState; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/RTMPState; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/StartFlags 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/StartFlags;>;
 field public,static,final,enum None Ltv/twitch/broadcast/StartFlags; -
 field public,static,final,enum TTV_Start_BandwidthTest Ltv/twitch/broadcast/StartFlags; -
 method public,static values ()[Ltv/twitch/broadcast/StartFlags; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/StartFlags; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/StartFlags; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/StatType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/broadcast/StatType;>;
 field public,static,final,enum TTV_ST_RTMPSTATE Ltv/twitch/broadcast/StatType; -
 field public,static,final,enum TTV_ST_RTMPDATASENT Ltv/twitch/broadcast/StatType; -
 method public,static values ()[Ltv/twitch/broadcast/StatType; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/broadcast/StatType; - -
 method public,static lookupValue (I)Ltv/twitch/broadcast/StatType; - -
 method public getValue ()I - -
in 90
class tv/twitch/broadcast/Stream 50 public,super java/lang/Object - -
 method public,static getInstance ()Ltv/twitch/broadcast/Stream; - -
 method public <init> (Ltv/twitch/broadcast/StreamAPI;)V - -
 method protected finalize ()V - -
 method public getStreamCallbacks ()Ltv/twitch/broadcast/IStreamCallbacks; - -
 method public setStreamCallbacks (Ltv/twitch/broadcast/IStreamCallbacks;)V - -
 method public getStatCallbacks ()Ltv/twitch/broadcast/IStatCallbacks; - -
 method public setStatCallbacks (Ltv/twitch/broadcast/IStatCallbacks;)V - -
 method public allocateFrameBuffer (I)Ltv/twitch/broadcast/FrameBuffer; - -
 method public memsetFrameBuffer (Ltv/twitch/broadcast/FrameBuffer;I)Ltv/twitch/ErrorCode; - -
 method public randomizeFrameBuffer (Ltv/twitch/broadcast/FrameBuffer;)Ltv/twitch/ErrorCode; - -
 method public requestAuthToken (Ltv/twitch/broadcast/AuthParams;Ljava/util/HashSet;)Ltv/twitch/ErrorCode; (Ltv/twitch/broadcast/AuthParams;Ljava/util/HashSet<Ltv/twitch/broadcast/AuthFlag;>;)Ltv/twitch/ErrorCode; -
 method public login (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public getIngestServers (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public getUserInfo (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public getStreamInfo (Ltv/twitch/AuthToken;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public setStreamInfo (Ltv/twitch/AuthToken;Ljava/lang/String;Ltv/twitch/broadcast/StreamInfoForSetting;)Ltv/twitch/ErrorCode; - -
 method public getArchivingState (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public runCommercial (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public setVolume (Ltv/twitch/broadcast/AudioDeviceType;F)Ltv/twitch/ErrorCode; - -
 method public getVolume (Ltv/twitch/broadcast/AudioDeviceType;)F - -
 method public getGameNameList (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public getDefaultParams (Ltv/twitch/broadcast/VideoParams;)Ltv/twitch/ErrorCode; - -
 method public getMaxResolution (IIFF)[I - -
 method public pollTasks ()Ltv/twitch/ErrorCode; - -
 method public pollStats ()Ltv/twitch/ErrorCode; - -
 method public sendActionMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public sendStartSpanMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;)J - -
 method public sendEndSpanMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public submitVideoFrame (Ltv/twitch/broadcast/FrameBuffer;)Ltv/twitch/ErrorCode; - -
 method public captureFrameBuffer_ReadPixels (Ltv/twitch/broadcast/FrameBuffer;)Ltv/twitch/ErrorCode; - -
 method public start (Ltv/twitch/broadcast/VideoParams;Ltv/twitch/broadcast/AudioParams;Ltv/twitch/broadcast/IngestServer;Ltv/twitch/broadcast/StartFlags;Z)Ltv/twitch/ErrorCode; - -
 method public stop (Z)Ltv/twitch/ErrorCode; - -
 method public pauseVideo ()Ltv/twitch/ErrorCode; - -
 method public getStreamTime ()J - -
in 90
class tv/twitch/broadcast/StreamAPI 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract setStreamCallbacks (Ltv/twitch/broadcast/IStreamCallbacks;)V - -
 method public,abstract getStreamCallbacks ()Ltv/twitch/broadcast/IStreamCallbacks; - -
 method public,abstract setStatCallbacks (Ltv/twitch/broadcast/IStatCallbacks;)V - -
 method public,abstract getStatCallbacks ()Ltv/twitch/broadcast/IStatCallbacks; - -
 method public,abstract requestAuthToken (Ltv/twitch/broadcast/AuthParams;Ljava/util/HashSet;)Ltv/twitch/ErrorCode; (Ltv/twitch/broadcast/AuthParams;Ljava/util/HashSet<Ltv/twitch/broadcast/AuthFlag;>;)Ltv/twitch/ErrorCode; -
 method public,abstract login (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public,abstract getIngestServers (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public,abstract getUserInfo (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public,abstract getStreamInfo (Ltv/twitch/AuthToken;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract setStreamInfo (Ltv/twitch/AuthToken;Ljava/lang/String;Ltv/twitch/broadcast/StreamInfoForSetting;)Ltv/twitch/ErrorCode; - -
 method public,abstract getArchivingState (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public,abstract runCommercial (Ltv/twitch/AuthToken;)Ltv/twitch/ErrorCode; - -
 method public,abstract setVolume (Ltv/twitch/broadcast/AudioDeviceType;F)Ltv/twitch/ErrorCode; - -
 method public,abstract getVolume (Ltv/twitch/broadcast/AudioDeviceType;)F - -
 method public,abstract getGameNameList (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract getDefaultParams (Ltv/twitch/broadcast/VideoParams;)Ltv/twitch/ErrorCode; - -
 method public,abstract getMaxResolution (IIFF)[I - -
 method public,abstract pollTasks ()Ltv/twitch/ErrorCode; - -
 method public,abstract pollStats ()Ltv/twitch/ErrorCode; - -
 method public,abstract sendActionMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract sendStartSpanMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;)J - -
 method public,abstract sendEndSpanMetaData (Ltv/twitch/AuthToken;Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract submitVideoFrame (J)Ltv/twitch/ErrorCode; - -
 method public,abstract start (Ltv/twitch/broadcast/VideoParams;Ltv/twitch/broadcast/AudioParams;Ltv/twitch/broadcast/IngestServer;IZ)Ltv/twitch/ErrorCode; - -
 method public,abstract stop (Z)Ltv/twitch/ErrorCode; - -
 method public,abstract pauseVideo ()Ltv/twitch/ErrorCode; - -
 method public,abstract allocateFrameBuffer (I)J - -
 method public,abstract freeFrameBuffer (J)Ltv/twitch/ErrorCode; - -
 method public,abstract memsetFrameBuffer (JII)Ltv/twitch/ErrorCode; - -
 method public,abstract randomizeFrameBuffer (JI)Ltv/twitch/ErrorCode; - -
 method public,abstract captureFrameBuffer_ReadPixels (J)Ltv/twitch/ErrorCode; - -
 method public,abstract getStreamTime ()J - -
in 90
class tv/twitch/broadcast/StreamInfo 50 public,super java/lang/Object - -
 field public viewers I -
 field public streamId J -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/StreamInfoForSetting 50 public,super java/lang/Object - -
 field public streamTitle Ljava/lang/String; -
 field public gameName Ljava/lang/String; -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/UserInfo 50 public,super java/lang/Object - -
 field public displayName Ljava/lang/String; -
 field public name Ljava/lang/String; -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/VideoFrame 50 public,super java/lang/Object - -
 field public frameBuffer [B -
 field public mTimeStamp J -
 method public <init> ()V - -
in 90
class tv/twitch/broadcast/VideoParams 50 public,super java/lang/Object - -
 field public outputWidth I -
 field public outputHeight I -
 field public pixelFormat Ltv/twitch/broadcast/PixelFormat; -
 field public maxKbps I -
 field public targetFps I -
 field public encodingCpuUsage Ltv/twitch/broadcast/EncodingCpuUsage; -
 field public disableAdaptiveBitrate Z -
 field public verticalFlip Z -
 method public <init> ()V - -
 method public clone ()Ltv/twitch/broadcast/VideoParams; - -
in 90
class tv/twitch/chat/Chat 50 public,super java/lang/Object - -
 method public,static getInstance ()Ltv/twitch/chat/Chat; - -
 method public <init> (Ltv/twitch/chat/ChatAPI;)V - -
 method public initialize (Ljava/util/HashSet;Ltv/twitch/chat/IChatAPIListener;)Ltv/twitch/ErrorCode; (Ljava/util/HashSet<Ltv/twitch/chat/ChatTokenizationOption;>;Ltv/twitch/chat/IChatAPIListener;)Ltv/twitch/ErrorCode; -
 method public shutdown ()Ltv/twitch/ErrorCode; - -
 method public connect (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ltv/twitch/chat/IChatChannelListener;)Ltv/twitch/ErrorCode; - -
 method public connectAnonymous (Ljava/lang/String;Ltv/twitch/chat/IChatChannelListener;)Ltv/twitch/ErrorCode; - -
 method public disconnect (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public sendMessage (Ljava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public flushEvents ()Ltv/twitch/ErrorCode; - -
 method public downloadEmoticonData ()Ltv/twitch/ErrorCode; - -
 method public getEmoticonData (Ltv/twitch/chat/ChatEmoticonData;)Ltv/twitch/ErrorCode; - -
 method public clearEmoticonData ()Ltv/twitch/ErrorCode; - -
 method public downloadBadgeData (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public getBadgeData (Ljava/lang/String;Ltv/twitch/chat/ChatBadgeData;)Ltv/twitch/ErrorCode; - -
 method public clearBadgeData (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public getMessageFlushInterval ()I - -
 method public setMessageFlushInterval (I)Ltv/twitch/ErrorCode; - -
 method public getUserChangeEventInterval ()I - -
 method public setUserChangeEventInterval (I)Ltv/twitch/ErrorCode; - -
in 90
class tv/twitch/chat/ChatAPI 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract initialize (Ljava/util/HashSet;Ltv/twitch/chat/IChatAPIListener;)Ltv/twitch/ErrorCode; (Ljava/util/HashSet<Ltv/twitch/chat/ChatTokenizationOption;>;Ltv/twitch/chat/IChatAPIListener;)Ltv/twitch/ErrorCode; -
 method public,abstract shutdown ()Ltv/twitch/ErrorCode; - -
 method public,abstract connect (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ltv/twitch/chat/IChatChannelListener;)Ltv/twitch/ErrorCode; - -
 method public,abstract connectAnonymous (Ljava/lang/String;Ltv/twitch/chat/IChatChannelListener;)Ltv/twitch/ErrorCode; - -
 method public,abstract disconnect (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract sendMessage (Ljava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract flushEvents ()Ltv/twitch/ErrorCode; - -
 method public,abstract downloadEmoticonData ()Ltv/twitch/ErrorCode; - -
 method public,abstract getEmoticonData (Ltv/twitch/chat/ChatEmoticonData;)Ltv/twitch/ErrorCode; - -
 method public,abstract clearEmoticonData ()Ltv/twitch/ErrorCode; - -
 method public,abstract downloadBadgeData (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract getBadgeData (Ljava/lang/String;Ltv/twitch/chat/ChatBadgeData;)Ltv/twitch/ErrorCode; - -
 method public,abstract clearBadgeData (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public,abstract getMessageFlushInterval ()I - -
 method public,abstract setMessageFlushInterval (I)Ltv/twitch/ErrorCode; - -
 method public,abstract getUserChangeEventInterval ()I - -
 method public,abstract setUserChangeEventInterval (I)Ltv/twitch/ErrorCode; - -
in 90
class tv/twitch/chat/ChatBadgeData 50 public,super java/lang/Object - -
 field public channelName Ljava/lang/String; -
 field public textures [Ltv/twitch/chat/ChatTextureSheet; -
 field public turboIcon Ltv/twitch/chat/ChatMessageToken; -
 field public channelSubscriberIcon Ltv/twitch/chat/ChatMessageToken; -
 field public broadcasterIcon Ltv/twitch/chat/ChatMessageToken; -
 field public staffIcon Ltv/twitch/chat/ChatMessageToken; -
 field public adminIcon Ltv/twitch/chat/ChatMessageToken; -
 field public moderatorIcon Ltv/twitch/chat/ChatMessageToken; -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatChannelInfo 50 public,super java/lang/Object - -
 field public name Ljava/lang/String; -
 field public broadcasterUserInfo Ltv/twitch/chat/ChatUserInfo; -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatEmoticonData 50 public,super java/lang/Object - -
 field public textures [Ltv/twitch/chat/ChatTextureSheet; -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatEvent 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/chat/ChatEvent;>;
 field public,static,final,enum TTV_CHAT_JOINED_CHANNEL Ltv/twitch/chat/ChatEvent; -
 field public,static,final,enum TTV_CHAT_LEFT_CHANNEL Ltv/twitch/chat/ChatEvent; -
 method public,static values ()[Ltv/twitch/chat/ChatEvent; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/chat/ChatEvent; - -
 method public,static lookupValue (I)Ltv/twitch/chat/ChatEvent; - -
 method public getValue ()I - -
in 90
class tv/twitch/chat/ChatMessageToken 50 public,super java/lang/Object - -
 field public type Ltv/twitch/chat/ChatMessageTokenType; -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatMessageTokenType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/chat/ChatMessageTokenType;>;
 field public,static,final,enum TTV_CHAT_MSGTOKEN_TEXT Ltv/twitch/chat/ChatMessageTokenType; -
 field public,static,final,enum TTV_CHAT_MSGTOKEN_TEXTURE_IMAGE Ltv/twitch/chat/ChatMessageTokenType; -
 field public,static,final,enum TTV_CHAT_MSGTOKEN_URL_IMAGE Ltv/twitch/chat/ChatMessageTokenType; -
 method public,static values ()[Ltv/twitch/chat/ChatMessageTokenType; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/chat/ChatMessageTokenType; - -
 method public,static lookupValue (I)Ltv/twitch/chat/ChatMessageTokenType; - -
 method public getValue ()I - -
in 90
class tv/twitch/chat/ChatRawMessage 50 public,super java/lang/Object - -
 field public userName Ljava/lang/String; -
 field public message Ljava/lang/String; -
 field public modes Ljava/util/HashSet; Ljava/util/HashSet<Ltv/twitch/chat/ChatUserMode;>;
 field public subscriptions Ljava/util/HashSet; Ljava/util/HashSet<Ltv/twitch/chat/ChatUserSubscription;>;
 field public nameColorARGB I -
 field public action Z -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatTextMessageToken 50 public,super tv/twitch/chat/ChatMessageToken - -
 field public text Ljava/lang/String; -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatTextureImageMessageToken 50 public,super tv/twitch/chat/ChatMessageToken - -
 field public sheetIndex I -
 field public x1 S -
 field public y1 S -
 field public x2 S -
 field public y2 S -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatTextureSheet 50 public,super java/lang/Object - -
 field public sheetIndex I -
 field public buffer [B -
 field public width I -
 field public height I -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatTokenizationOption 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/chat/ChatTokenizationOption;>;
 field public,static,final,enum TTV_CHAT_TOKENIZATION_OPTION_NONE Ltv/twitch/chat/ChatTokenizationOption; -
 field public,static,final,enum TTV_CHAT_TOKENIZATION_OPTION_EMOTICON_URLS Ltv/twitch/chat/ChatTokenizationOption; -
 field public,static,final,enum TTV_CHAT_TOKENIZATION_OPTION_EMOTICON_TEXTURES Ltv/twitch/chat/ChatTokenizationOption; -
 method public,static values ()[Ltv/twitch/chat/ChatTokenizationOption; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/chat/ChatTokenizationOption; - -
 method public,static lookupValue (I)Ltv/twitch/chat/ChatTokenizationOption; - -
 method public,static getNativeValue (Ljava/util/HashSet;)I (Ljava/util/HashSet<Ltv/twitch/chat/ChatTokenizationOption;>;)I -
 method public getValue ()I - -
in 90
class tv/twitch/chat/ChatTokenizedMessage 50 public,super java/lang/Object - -
 field public displayName Ljava/lang/String; -
 field public modes Ljava/util/HashSet; Ljava/util/HashSet<Ltv/twitch/chat/ChatUserMode;>;
 field public subscriptions Ljava/util/HashSet; Ljava/util/HashSet<Ltv/twitch/chat/ChatUserSubscription;>;
 field public nameColorARGB I -
 field public tokenList [Ltv/twitch/chat/ChatMessageToken; -
 field public action Z -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatUrlImageMessageToken 50 public,super tv/twitch/chat/ChatMessageToken - -
 field public url Ljava/lang/String; -
 field public width S -
 field public height S -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatUserInfo 50 public,super java/lang/Object - -
 field public displayName Ljava/lang/String; -
 field public modes Ljava/util/HashSet; Ljava/util/HashSet<Ltv/twitch/chat/ChatUserMode;>;
 field public subscriptions Ljava/util/HashSet; Ljava/util/HashSet<Ltv/twitch/chat/ChatUserSubscription;>;
 field public nameColorARGB I -
 field public ignore Z -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatUserList 50 public,super java/lang/Object - -
 field public userList [Ltv/twitch/chat/ChatUserInfo; -
 method public <init> ()V - -
in 90
class tv/twitch/chat/ChatUserMode 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/chat/ChatUserMode;>;
 field public,static,final,enum TTV_CHAT_USERMODE_VIEWER Ltv/twitch/chat/ChatUserMode; -
 field public,static,final,enum TTV_CHAT_USERMODE_MODERATOR Ltv/twitch/chat/ChatUserMode; -
 field public,static,final,enum TTV_CHAT_USERMODE_BROADCASTER Ltv/twitch/chat/ChatUserMode; -
 field public,static,final,enum TTV_CHAT_USERMODE_ADMINSTRATOR Ltv/twitch/chat/ChatUserMode; -
 field public,static,final,enum TTV_CHAT_USERMODE_STAFF Ltv/twitch/chat/ChatUserMode; -
 field public,static,final,enum TTV_CHAT_USERMODE_BANNED Ltv/twitch/chat/ChatUserMode; -
 method public,static values ()[Ltv/twitch/chat/ChatUserMode; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/chat/ChatUserMode; - -
 method public,static lookupValue (I)Ltv/twitch/chat/ChatUserMode; - -
 method public getValue ()I - -
in 90
class tv/twitch/chat/ChatUserSubscription 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ltv/twitch/chat/ChatUserSubscription;>;
 field public,static,final,enum TTV_CHAT_USERSUB_NONE Ltv/twitch/chat/ChatUserSubscription; -
 field public,static,final,enum TTV_CHAT_USERSUB_SUBSCRIBER Ltv/twitch/chat/ChatUserSubscription; -
 field public,static,final,enum TTV_CHAT_USERSUB_TURBO Ltv/twitch/chat/ChatUserSubscription; -
 method public,static values ()[Ltv/twitch/chat/ChatUserSubscription; - -
 method public,static valueOf (Ljava/lang/String;)Ltv/twitch/chat/ChatUserSubscription; - -
 method public,static lookupValue (I)Ltv/twitch/chat/ChatUserSubscription; - -
 method public getValue ()I - -
in 90
class tv/twitch/chat/IChatAPIListener 50 public,interface,abstract java/lang/Object - -
 method public,abstract chatInitializationCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract chatShutdownCallback (Ltv/twitch/ErrorCode;)V - -
 method public,abstract chatEmoticonDataDownloadCallback (Ltv/twitch/ErrorCode;)V - -
in 90
class tv/twitch/chat/IChatChannelListener 50 public,interface,abstract java/lang/Object - -
 method public,abstract chatStatusCallback (Ljava/lang/String;Ltv/twitch/ErrorCode;)V - -
 method public,abstract chatChannelMembershipCallback (Ljava/lang/String;Ltv/twitch/chat/ChatEvent;Ltv/twitch/chat/ChatChannelInfo;)V - -
 method public,abstract chatChannelUserChangeCallback (Ljava/lang/String;[Ltv/twitch/chat/ChatUserInfo;[Ltv/twitch/chat/ChatUserInfo;[Ltv/twitch/chat/ChatUserInfo;)V - -
 method public,abstract chatChannelRawMessageCallback (Ljava/lang/String;[Ltv/twitch/chat/ChatRawMessage;)V - -
 method public,abstract chatChannelTokenizedMessageCallback (Ljava/lang/String;[Ltv/twitch/chat/ChatTokenizedMessage;)V - -
 method public,abstract chatClearCallback (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,abstract chatBadgeDataDownloadCallback (Ljava/lang/String;Ltv/twitch/ErrorCode;)V - -
in 90
class tv/twitch/chat/StandardChatAPI 50 public,super tv/twitch/chat/ChatAPI - -
 method public <init> ()V - -
 method protected finalize ()V - -
 method public initialize (Ljava/util/HashSet;Ltv/twitch/chat/IChatAPIListener;)Ltv/twitch/ErrorCode; (Ljava/util/HashSet<Ltv/twitch/chat/ChatTokenizationOption;>;Ltv/twitch/chat/IChatAPIListener;)Ltv/twitch/ErrorCode; -
 method public shutdown ()Ltv/twitch/ErrorCode; - -
 method public connect (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ltv/twitch/chat/IChatChannelListener;)Ltv/twitch/ErrorCode; - -
 method public connectAnonymous (Ljava/lang/String;Ltv/twitch/chat/IChatChannelListener;)Ltv/twitch/ErrorCode; - -
 method public disconnect (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public sendMessage (Ljava/lang/String;Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public flushEvents ()Ltv/twitch/ErrorCode; - -
 method public downloadEmoticonData ()Ltv/twitch/ErrorCode; - -
 method public getEmoticonData (Ltv/twitch/chat/ChatEmoticonData;)Ltv/twitch/ErrorCode; - -
 method public clearEmoticonData ()Ltv/twitch/ErrorCode; - -
 method public downloadBadgeData (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public getBadgeData (Ljava/lang/String;Ltv/twitch/chat/ChatBadgeData;)Ltv/twitch/ErrorCode; - -
 method public clearBadgeData (Ljava/lang/String;)Ltv/twitch/ErrorCode; - -
 method public getMessageFlushInterval ()I - -
 method public setMessageFlushInterval (I)Ltv/twitch/ErrorCode; - -
 method public getUserChangeEventInterval ()I - -
 method public setUserChangeEventInterval (I)Ltv/twitch/ErrorCode; - -
