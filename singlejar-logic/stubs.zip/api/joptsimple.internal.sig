cg-stub-db 1
in 22
class joptsimple/internal/AbbreviationMap 51 public,super java/lang/Object joptsimple/internal/OptionNameMap <V:Ljava/lang/Object;>Ljava/lang/Object;Ljoptsimple/internal/OptionNameMap<TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public contains (Ljava/lang/String;)Z - -
 method public get (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method public put (Ljava/lang/String;Ljava/lang/Object;)V (Ljava/lang/String;TV;)V -
 method public putAll (Ljava/lang/Iterable;Ljava/lang/Object;)V (Ljava/lang/Iterable<Ljava/lang/String;>;TV;)V -
 method public remove (Ljava/lang/String;)V - -
 method public toJavaUtilMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;TV;>; -
in 22
class joptsimple/internal/Classes 51 public,final,super java/lang/Object - -
 method public,static shortNameOf (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static wrapperOf (Ljava/lang/Class;)Ljava/lang/Class; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Ljava/lang/Class<TT;>; -
in 22
class joptsimple/internal/Columns 51 super java/lang/Object - -
in 22
class joptsimple/internal/ConstructorInvokingValueConverter 51 super java/lang/Object joptsimple/ValueConverter <V:Ljava/lang/Object;>Ljava/lang/Object;Ljoptsimple/ValueConverter<TV;>;
 method public convert (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method public valueType ()Ljava/lang/Class; ()Ljava/lang/Class<TV;>; -
 method public valuePattern ()Ljava/lang/String; - -
in 22
class joptsimple/internal/Messages 51 public,super java/lang/Object - -
 method public,static,varargs message (Ljava/util/Locale;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; (Ljava/util/Locale;Ljava/lang/String;Ljava/lang/Class<*>;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; -
in 22
class joptsimple/internal/MethodInvokingValueConverter 51 super java/lang/Object joptsimple/ValueConverter <V:Ljava/lang/Object;>Ljava/lang/Object;Ljoptsimple/ValueConverter<TV;>;
 method public convert (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method public valueType ()Ljava/lang/Class; ()Ljava/lang/Class<TV;>; -
 method public valuePattern ()Ljava/lang/String; - -
in 22
class joptsimple/internal/OptionNameMap 51 public,interface,abstract java/lang/Object - <V:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract contains (Ljava/lang/String;)Z - -
 method public,abstract get (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method public,abstract put (Ljava/lang/String;Ljava/lang/Object;)V (Ljava/lang/String;TV;)V -
 method public,abstract putAll (Ljava/lang/Iterable;Ljava/lang/Object;)V (Ljava/lang/Iterable<Ljava/lang/String;>;TV;)V -
 method public,abstract remove (Ljava/lang/String;)V - -
 method public,abstract toJavaUtilMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;TV;>; -
in 22
class joptsimple/internal/Reflection 51 public,final,super java/lang/Object - -
 method public,static findConverter (Ljava/lang/Class;)Ljoptsimple/ValueConverter; <V:Ljava/lang/Object;>(Ljava/lang/Class<TV;>;)Ljoptsimple/ValueConverter<TV;>; -
 method public,static,varargs instantiate (Ljava/lang/reflect/Constructor;[Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/reflect/Constructor<TT;>;[Ljava/lang/Object;)TT; -
 method public,static,varargs invoke (Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static convertWith (Ljoptsimple/ValueConverter;Ljava/lang/String;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljoptsimple/ValueConverter<TV;>;Ljava/lang/String;)TV; -
in 22
class joptsimple/internal/ReflectionException 51 public,super java/lang/RuntimeException - -
in 22
class joptsimple/internal/Row 51 super java/lang/Object - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class joptsimple/internal/Rows 51 public,super java/lang/Object - -
 method public <init> (II)V - -
 method public add (Ljava/lang/String;Ljava/lang/String;)V - -
 method public reset ()V - -
 method public fitToWidth ()V - -
 method public render ()Ljava/lang/String; - -
in 22
class joptsimple/internal/SimpleOptionNameMap 51 public,super java/lang/Object joptsimple/internal/OptionNameMap <V:Ljava/lang/Object;>Ljava/lang/Object;Ljoptsimple/internal/OptionNameMap<TV;>;
 method public <init> ()V - -
 method public contains (Ljava/lang/String;)Z - -
 method public get (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method public put (Ljava/lang/String;Ljava/lang/Object;)V (Ljava/lang/String;TV;)V -
 method public putAll (Ljava/lang/Iterable;Ljava/lang/Object;)V (Ljava/lang/Iterable<Ljava/lang/String;>;TV;)V -
 method public remove (Ljava/lang/String;)V - -
 method public toJavaUtilMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;TV;>; -
in 22
class joptsimple/internal/Strings 51 public,final,super java/lang/Object - -
 field public,static,final EMPTY Ljava/lang/String; - ""
 field public,static,final LINE_SEPARATOR Ljava/lang/String; -
 method public,static repeat (CI)Ljava/lang/String; - -
 method public,static isNullOrEmpty (Ljava/lang/String;)Z - -
 method public,static surround (Ljava/lang/String;CC)Ljava/lang/String; - -
 method public,static join ([Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static join (Ljava/lang/Iterable;Ljava/lang/String;)Ljava/lang/String; (Ljava/lang/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
