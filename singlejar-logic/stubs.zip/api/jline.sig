cg-stub-db 1
in 24
class jline/AnsiWindowsTerminal 49 public,super jline/WindowsTerminal - -
 method public wrapOutIfNeeded (Ljava/io/OutputStream;)Ljava/io/OutputStream; - -
 method public <init> ()V - java/lang/Exception
 method public isAnsiSupported ()Z - -
 method public hasWeirdWrap ()Z - -
in 24
class jline/DefaultTerminal2 49 public,super java/lang/Object jline/Terminal2 -
 method public <init> (Ljline/Terminal;)V - -
 method public init ()V - java/lang/Exception
 method public restore ()V - java/lang/Exception
 method public reset ()V - java/lang/Exception
 method public isSupported ()Z - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public isAnsiSupported ()Z - -
 method public wrapOutIfNeeded (Ljava/io/OutputStream;)Ljava/io/OutputStream; - -
 method public wrapInIfNeeded (Ljava/io/InputStream;)Ljava/io/InputStream; - java/io/IOException
 method public hasWeirdWrap ()Z - -
 method public isEchoEnabled ()Z - -
 method public setEchoEnabled (Z)V - -
 method public getOutputEncoding ()Ljava/lang/String; - -
 method public getBooleanCapability (Ljava/lang/String;)Z - -
 method public getNumericCapability (Ljava/lang/String;)Ljava/lang/Integer; - -
 method public getStringCapability (Ljava/lang/String;)Ljava/lang/String; - -
in 24
class jline/NoInterruptUnixTerminal 49 public,super jline/UnixTerminal - -
 method public <init> ()V - java/lang/Exception
 method public init ()V - java/lang/Exception
 method public restore ()V - java/lang/Exception
in 24
class jline/OSvTerminal 49 public,super jline/TerminalSupport - -
 field public sttyClass Ljava/lang/Class; Ljava/lang/Class<*>;
 field public stty Ljava/lang/Object; -
 method public <init> ()V - -
 method public init ()V - java/lang/Exception
 method public restore ()V - java/lang/Exception
in 24
class jline/Terminal 49 public,interface,abstract java/lang/Object - -
 method public,abstract init ()V - java/lang/Exception
 method public,abstract restore ()V - java/lang/Exception
 method public,abstract reset ()V - java/lang/Exception
 method public,abstract isSupported ()Z - -
 method public,abstract getWidth ()I - -
 method public,abstract getHeight ()I - -
 method public,abstract isAnsiSupported ()Z - -
 method public,abstract wrapOutIfNeeded (Ljava/io/OutputStream;)Ljava/io/OutputStream; - -
 method public,abstract wrapInIfNeeded (Ljava/io/InputStream;)Ljava/io/InputStream; - java/io/IOException
 method public,abstract hasWeirdWrap ()Z - -
 method public,abstract isEchoEnabled ()Z - -
 method public,abstract setEchoEnabled (Z)V - -
 method public,abstract getOutputEncoding ()Ljava/lang/String; - -
in 24
class jline/Terminal2 49 public,interface,abstract java/lang/Object jline/Terminal -
 method public,abstract getBooleanCapability (Ljava/lang/String;)Z - -
 method public,abstract getNumericCapability (Ljava/lang/String;)Ljava/lang/Integer; - -
 method public,abstract getStringCapability (Ljava/lang/String;)Ljava/lang/String; - -
in 24
class jline/TerminalFactory 49 public,super java/lang/Object - -
 inner jline/TerminalFactory$Flavor jline/TerminalFactory Flavor public,static,final,enum
 inner jline/TerminalFactory$Type jline/TerminalFactory Type public,static,final,enum
 field public,static,final JLINE_TERMINAL Ljava/lang/String; - "jline.terminal"
 field public,static,final AUTO Ljava/lang/String; - "auto"
 field public,static,final UNIX Ljava/lang/String; - "unix"
 field public,static,final OSV Ljava/lang/String; - "osv"
 field public,static,final WIN Ljava/lang/String; - "win"
 field public,static,final WINDOWS Ljava/lang/String; - "windows"
 field public,static,final NONE Ljava/lang/String; - "none"
 field public,static,final OFF Ljava/lang/String; - "off"
 field public,static,final FALSE Ljava/lang/String; - "false"
 method public <init> ()V - -
 method public,static,synchronized create ()Ljline/Terminal; - -
 method public,static,synchronized create (Ljava/lang/String;)Ljline/Terminal; - -
 method public,static,synchronized reset ()V - -
 method public,static,synchronized resetIf (Ljline/Terminal;)V - -
 method public,static,synchronized configure (Ljava/lang/String;)V - -
 method public,static,synchronized configure (Ljline/TerminalFactory$Type;)V - -
 method public,static,synchronized get (Ljava/lang/String;)Ljline/Terminal; - -
 method public,static,synchronized get ()Ljline/Terminal; - -
 method public,static getFlavor (Ljline/TerminalFactory$Flavor;)Ljline/Terminal; - java/lang/Exception
 method public,static getFlavor (Ljline/TerminalFactory$Flavor;Ljava/lang/String;)Ljline/Terminal; - java/lang/Exception
 method public,static registerFlavor (Ljline/TerminalFactory$Flavor;Ljava/lang/Class;)V (Ljline/TerminalFactory$Flavor;Ljava/lang/Class<+Ljline/Terminal;>;)V -
in 24
class jline/TerminalFactory$Flavor 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljline/TerminalFactory$Flavor;>;
 inner jline/TerminalFactory$Flavor jline/TerminalFactory Flavor public,static,final,enum
 field public,static,final,enum WINDOWS Ljline/TerminalFactory$Flavor; -
 field public,static,final,enum UNIX Ljline/TerminalFactory$Flavor; -
 field public,static,final,enum OSV Ljline/TerminalFactory$Flavor; -
 method public,static values ()[Ljline/TerminalFactory$Flavor; - -
 method public,static valueOf (Ljava/lang/String;)Ljline/TerminalFactory$Flavor; - -
in 24
class jline/TerminalFactory$Type 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljline/TerminalFactory$Type;>;
 inner jline/TerminalFactory$Type jline/TerminalFactory Type public,static,final,enum
 field public,static,final,enum AUTO Ljline/TerminalFactory$Type; -
 field public,static,final,enum WINDOWS Ljline/TerminalFactory$Type; -
 field public,static,final,enum UNIX Ljline/TerminalFactory$Type; -
 field public,static,final,enum OSV Ljline/TerminalFactory$Type; -
 field public,static,final,enum NONE Ljline/TerminalFactory$Type; -
 method public,static values ()[Ljline/TerminalFactory$Type; - -
 method public,static valueOf (Ljava/lang/String;)Ljline/TerminalFactory$Type; - -
in 24
class jline/TerminalSupport 49 public,super,abstract java/lang/Object jline/Terminal -
 inner jline/internal/ShutdownHooks$Task jline/internal/ShutdownHooks Task public,static,interface,abstract
 field public,static,final DEFAULT_WIDTH I - I80
 field public,static,final DEFAULT_HEIGHT I - I24
 method protected <init> (Z)V - -
 method public init ()V - java/lang/Exception
 method public restore ()V - java/lang/Exception
 method public reset ()V - java/lang/Exception
 method public,final isSupported ()Z - -
 method public,synchronized isAnsiSupported ()Z - -
 method protected,synchronized setAnsiSupported (Z)V - -
 method public wrapOutIfNeeded (Ljava/io/OutputStream;)Ljava/io/OutputStream; - -
 method public hasWeirdWrap ()Z - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public,synchronized isEchoEnabled ()Z - -
 method public,synchronized setEchoEnabled (Z)V - -
 method public wrapInIfNeeded (Ljava/io/InputStream;)Ljava/io/InputStream; - java/io/IOException
 method public getOutputEncoding ()Ljava/lang/String; - -
in 24
class jline/UnixTerminal 49 public,super jline/TerminalSupport jline/Terminal2 -
 method public <init> ()V - java/lang/Exception
 method public <init> (Ljava/lang/String;)V - java/lang/Exception
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - java/lang/Exception
 method public getSettings ()Ljline/internal/TerminalLineSettings; - -
 method public init ()V - java/lang/Exception
 method public restore ()V - java/lang/Exception
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public hasWeirdWrap ()Z - -
 method public,synchronized setEchoEnabled (Z)V - -
 method public disableInterruptCharacter ()V - -
 method public enableInterruptCharacter ()V - -
 method public disableLitteralNextCharacter ()V - -
 method public enableLitteralNextCharacter ()V - -
 method public getBooleanCapability (Ljava/lang/String;)Z - -
 method public getNumericCapability (Ljava/lang/String;)Ljava/lang/Integer; - -
 method public getStringCapability (Ljava/lang/String;)Ljava/lang/String; - -
in 24
class jline/UnsupportedTerminal 49 public,super jline/TerminalSupport - -
 method public <init> ()V - -
in 24
class jline/WindowsTerminal 49 public,super jline/TerminalSupport - -
 inner jline/WindowsTerminal$ConsoleMode jline/WindowsTerminal ConsoleMode public,static,final,enum
 inner org/fusesource/jansi/internal/Kernel32$KEY_EVENT_RECORD org/fusesource/jansi/internal/Kernel32 KEY_EVENT_RECORD public,static
 inner org/fusesource/jansi/internal/Kernel32$INPUT_RECORD org/fusesource/jansi/internal/Kernel32 INPUT_RECORD public,static
 field public,static,final DIRECT_CONSOLE Ljava/lang/String; -
 field public,static,final ANSI Ljava/lang/String; -
 method public <init> ()V - java/lang/Exception
 method public init ()V - java/lang/Exception
 method public restore ()V - java/lang/Exception
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public setEchoEnabled (Z)V - -
 method public setDirectConsole (Z)V - -
 method public getDirectConsole ()Ljava/lang/Boolean; - -
 method public wrapInIfNeeded (Ljava/io/InputStream;)Ljava/io/InputStream; - java/io/IOException
 method protected isSystemIn (Ljava/io/InputStream;)Z - java/io/IOException
 method public getOutputEncoding ()Ljava/lang/String; - -
in 24
class jline/WindowsTerminal$ConsoleMode 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljline/WindowsTerminal$ConsoleMode;>;
 inner jline/WindowsTerminal$ConsoleMode jline/WindowsTerminal ConsoleMode public,static,final,enum
 field public,static,final,enum ENABLE_LINE_INPUT Ljline/WindowsTerminal$ConsoleMode; -
 field public,static,final,enum ENABLE_ECHO_INPUT Ljline/WindowsTerminal$ConsoleMode; -
 field public,static,final,enum ENABLE_PROCESSED_INPUT Ljline/WindowsTerminal$ConsoleMode; -
 field public,static,final,enum ENABLE_WINDOW_INPUT Ljline/WindowsTerminal$ConsoleMode; -
 field public,static,final,enum ENABLE_MOUSE_INPUT Ljline/WindowsTerminal$ConsoleMode; -
 field public,static,final,enum ENABLE_PROCESSED_OUTPUT Ljline/WindowsTerminal$ConsoleMode; -
 field public,static,final,enum ENABLE_WRAP_AT_EOL_OUTPUT Ljline/WindowsTerminal$ConsoleMode; -
 field public,final code I -
 method public,static values ()[Ljline/WindowsTerminal$ConsoleMode; - -
 method public,static valueOf (Ljava/lang/String;)Ljline/WindowsTerminal$ConsoleMode; - -
