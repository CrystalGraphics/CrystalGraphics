cg-stub-db 1
in 131
class paulscode/sound/Channel 49 public,super java/lang/Object - -
 field protected libraryType Ljava/lang/Class; -
 field public channelType I -
 field public attachedSource Lpaulscode/sound/Source; -
 field public buffersUnqueued I -
 method public <init> (I)V - -
 method public cleanup ()V - -
 method public preLoadBuffers (Ljava/util/LinkedList;)Z (Ljava/util/LinkedList<[B>;)Z -
 method public queueBuffer ([B)Z - -
 method public feedRawAudioData ([B)I - -
 method public buffersProcessed ()I - -
 method public millisecondsPlayed ()F - -
 method public processBuffer ()Z - -
 method public setAudioFormat (Ljavax/sound/sampled/AudioFormat;)V - -
 method public flush ()V - -
 method public close ()V - -
 method public play ()V - -
 method public pause ()V - -
 method public stop ()V - -
 method public rewind ()V - -
 method public playing ()Z - -
 method public getClassName ()Ljava/lang/String; - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 135
class paulscode/sound/Channel 52 public,super java/lang/Object - -
 field protected libraryType Ljava/lang/Class; -
 field public channelType I -
 field public attachedSource Lpaulscode/sound/Source; -
 field public buffersUnqueued I -
 method public <init> (I)V - -
 method public cleanup ()V - -
 method public preLoadBuffers (Ljava/util/LinkedList;)Z (Ljava/util/LinkedList<[B>;)Z -
 method public queueBuffer ([B)Z - -
 method public feedRawAudioData ([B)I - -
 method public buffersProcessed ()I - -
 method public millisecondsPlayed ()F - -
 method public processBuffer ()Z - -
 method public setAudioFormat (Ljavax/sound/sampled/AudioFormat;)V - -
 method public flush ()V - -
 method public close ()V - -
 method public play ()V - -
 method public pause ()V - -
 method public stop ()V - -
 method public rewind ()V - -
 method public playing ()Z - -
 method public getClassName ()Ljava/lang/String; - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 131
class paulscode/sound/CommandObject 49 public,super java/lang/Object - -
 field public,static,final INITIALIZE I - I1
 field public,static,final LOAD_SOUND I - I2
 field public,static,final LOAD_DATA I - I3
 field public,static,final UNLOAD_SOUND I - I4
 field public,static,final QUEUE_SOUND I - I5
 field public,static,final DEQUEUE_SOUND I - I6
 field public,static,final FADE_OUT I - I7
 field public,static,final FADE_OUT_IN I - I8
 field public,static,final CHECK_FADE_VOLUMES I - I9
 field public,static,final NEW_SOURCE I - I10
 field public,static,final RAW_DATA_STREAM I - I11
 field public,static,final QUICK_PLAY I - I12
 field public,static,final SET_POSITION I - I13
 field public,static,final SET_VOLUME I - I14
 field public,static,final SET_PITCH I - I15
 field public,static,final SET_PRIORITY I - I16
 field public,static,final SET_LOOPING I - I17
 field public,static,final SET_ATTENUATION I - I18
 field public,static,final SET_DIST_OR_ROLL I - I19
 field public,static,final CHANGE_DOPPLER_FACTOR I - I20
 field public,static,final CHANGE_DOPPLER_VELOCITY I - I21
 field public,static,final SET_VELOCITY I - I22
 field public,static,final SET_LISTENER_VELOCITY I - I23
 field public,static,final PLAY I - I24
 field public,static,final FEED_RAW_AUDIO_DATA I - I25
 field public,static,final PAUSE I - I26
 field public,static,final STOP I - I27
 field public,static,final REWIND I - I28
 field public,static,final FLUSH I - I29
 field public,static,final CULL I - I30
 field public,static,final ACTIVATE I - I31
 field public,static,final SET_TEMPORARY I - I32
 field public,static,final REMOVE_SOURCE I - I33
 field public,static,final MOVE_LISTENER I - I34
 field public,static,final SET_LISTENER_POSITION I - I35
 field public,static,final TURN_LISTENER I - I36
 field public,static,final SET_LISTENER_ANGLE I - I37
 field public,static,final SET_LISTENER_ORIENTATION I - I38
 field public,static,final SET_MASTER_VOLUME I - I39
 field public,static,final NEW_LIBRARY I - I40
 field public buffer [B -
 field public intArgs [I -
 field public floatArgs [F -
 field public longArgs [J -
 field public boolArgs [Z -
 field public stringArgs [Ljava/lang/String; -
 field public classArgs [Ljava/lang/Class; -
 field public objectArgs [Ljava/lang/Object; -
 field public Command I -
 method public <init> (I)V - -
 method public <init> (II)V - -
 method public <init> (ILjava/lang/Class;)V - -
 method public <init> (IF)V - -
 method public <init> (ILjava/lang/String;)V - -
 method public <init> (ILjava/lang/Object;)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/Object;)V - -
 method public <init> (ILjava/lang/String;[B)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/Object;J)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/Object;JJ)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/String;)V - -
 method public <init> (ILjava/lang/String;I)V - -
 method public <init> (ILjava/lang/String;F)V - -
 method public <init> (ILjava/lang/String;Z)V - -
 method public <init> (IFFF)V - -
 method public <init> (ILjava/lang/String;FFF)V - -
 method public <init> (IFFFFFF)V - -
 method public <init> (IZZZLjava/lang/String;Ljava/lang/Object;FFFIF)V - -
 method public <init> (IZZZLjava/lang/String;Ljava/lang/Object;FFFIFZ)V - -
 method public <init> (ILjava/lang/Object;ZLjava/lang/String;FFFIF)V - -
in 135
class paulscode/sound/CommandObject 52 public,super java/lang/Object - -
 field public,static,final INITIALIZE I - I1
 field public,static,final LOAD_SOUND I - I2
 field public,static,final LOAD_DATA I - I3
 field public,static,final UNLOAD_SOUND I - I4
 field public,static,final QUEUE_SOUND I - I5
 field public,static,final DEQUEUE_SOUND I - I6
 field public,static,final FADE_OUT I - I7
 field public,static,final FADE_OUT_IN I - I8
 field public,static,final CHECK_FADE_VOLUMES I - I9
 field public,static,final NEW_SOURCE I - I10
 field public,static,final RAW_DATA_STREAM I - I11
 field public,static,final QUICK_PLAY I - I12
 field public,static,final SET_POSITION I - I13
 field public,static,final SET_VOLUME I - I14
 field public,static,final SET_PITCH I - I15
 field public,static,final SET_PRIORITY I - I16
 field public,static,final SET_LOOPING I - I17
 field public,static,final SET_ATTENUATION I - I18
 field public,static,final SET_DIST_OR_ROLL I - I19
 field public,static,final CHANGE_DOPPLER_FACTOR I - I20
 field public,static,final CHANGE_DOPPLER_VELOCITY I - I21
 field public,static,final SET_VELOCITY I - I22
 field public,static,final SET_LISTENER_VELOCITY I - I23
 field public,static,final PLAY I - I24
 field public,static,final FEED_RAW_AUDIO_DATA I - I25
 field public,static,final PAUSE I - I26
 field public,static,final STOP I - I27
 field public,static,final REWIND I - I28
 field public,static,final FLUSH I - I29
 field public,static,final CULL I - I30
 field public,static,final ACTIVATE I - I31
 field public,static,final SET_TEMPORARY I - I32
 field public,static,final REMOVE_SOURCE I - I33
 field public,static,final MOVE_LISTENER I - I34
 field public,static,final SET_LISTENER_POSITION I - I35
 field public,static,final TURN_LISTENER I - I36
 field public,static,final SET_LISTENER_ANGLE I - I37
 field public,static,final SET_LISTENER_ORIENTATION I - I38
 field public,static,final SET_MASTER_VOLUME I - I39
 field public,static,final NEW_LIBRARY I - I40
 field public buffer [B -
 field public intArgs [I -
 field public floatArgs [F -
 field public longArgs [J -
 field public boolArgs [Z -
 field public stringArgs [Ljava/lang/String; -
 field public classArgs [Ljava/lang/Class; -
 field public objectArgs [Ljava/lang/Object; -
 field public Command I -
 method public <init> (I)V - -
 method public <init> (II)V - -
 method public <init> (ILjava/lang/Class;)V - -
 method public <init> (IF)V - -
 method public <init> (ILjava/lang/String;)V - -
 method public <init> (ILjava/lang/Object;)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/Object;)V - -
 method public <init> (ILjava/lang/String;[B)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/Object;J)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/Object;JJ)V - -
 method public <init> (ILjava/lang/String;Ljava/lang/String;)V - -
 method public <init> (ILjava/lang/String;I)V - -
 method public <init> (ILjava/lang/String;F)V - -
 method public <init> (ILjava/lang/String;Z)V - -
 method public <init> (IFFF)V - -
 method public <init> (ILjava/lang/String;FFF)V - -
 method public <init> (IFFFFFF)V - -
 method public <init> (IZZZLjava/lang/String;Ljava/lang/Object;FFFIF)V - -
 method public <init> (IZZZLjava/lang/String;Ljava/lang/Object;FFFIFZ)V - -
 method public <init> (ILjava/lang/Object;ZLjava/lang/String;FFFIF)V - -
in 131
class paulscode/sound/CommandThread 49 public,super paulscode/sound/SimpleThread - -
 field protected logger Lpaulscode/sound/SoundSystemLogger; -
 field protected className Ljava/lang/String; -
 method public <init> (Lpaulscode/sound/SoundSystem;)V - -
 method protected cleanup ()V - -
 method public run ()V - -
 method protected message (Ljava/lang/String;I)V - -
 method protected importantMessage (Ljava/lang/String;I)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;I)V - -
in 135
class paulscode/sound/CommandThread 52 public,super paulscode/sound/SimpleThread - -
 field protected logger Lpaulscode/sound/SoundSystemLogger; -
 field protected className Ljava/lang/String; -
 method public <init> (Lpaulscode/sound/SoundSystem;)V - -
 method protected cleanup ()V - -
 method public run ()V - -
 method protected message (Ljava/lang/String;I)V - -
 method protected importantMessage (Ljava/lang/String;I)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;I)V - -
in 131
class paulscode/sound/FilenameURL 49 public,super java/lang/Object - -
 method public <init> (Ljava/net/URL;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public getFilename ()Ljava/lang/String; - -
 method public getURL ()Ljava/net/URL; - -
in 135
class paulscode/sound/FilenameURL 52 public,super java/lang/Object - -
 method public <init> (Ljava/net/URL;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public getFilename ()Ljava/lang/String; - -
 method public getURL ()Ljava/net/URL; - -
in 131
class paulscode/sound/ICodec 49 public,interface,abstract java/lang/Object - -
 method public,abstract reverseByteOrder (Z)V - -
 method public,abstract initialize (Ljava/net/URL;)Z - -
 method public,abstract initialized ()Z - -
 method public,abstract read ()Lpaulscode/sound/SoundBuffer; - -
 method public,abstract readAll ()Lpaulscode/sound/SoundBuffer; - -
 method public,abstract endOfStream ()Z - -
 method public,abstract cleanup ()V - -
 method public,abstract getAudioFormat ()Ljavax/sound/sampled/AudioFormat; - -
in 135
class paulscode/sound/ICodec 52 public,interface,abstract java/lang/Object - -
 method public,abstract reverseByteOrder (Z)V - -
 method public,abstract initialize (Ljava/net/URL;)Z - -
 method public,abstract initialized ()Z - -
 method public,abstract read ()Lpaulscode/sound/SoundBuffer; - -
 method public,abstract readAll ()Lpaulscode/sound/SoundBuffer; - -
 method public,abstract endOfStream ()Z - -
 method public,abstract cleanup ()V - -
 method public,abstract getAudioFormat ()Ljavax/sound/sampled/AudioFormat; - -
in 131
class paulscode/sound/IStreamListener 49 public,interface,abstract java/lang/Object - -
 method public,abstract endOfStream (Ljava/lang/String;I)V - -
in 135
class paulscode/sound/IStreamListener 52 public,interface,abstract java/lang/Object - -
 method public,abstract endOfStream (Ljava/lang/String;I)V - -
in 131
class paulscode/sound/Library 49 public,super java/lang/Object - -
 field protected listener Lpaulscode/sound/ListenerData; -
 field protected bufferMap Ljava/util/HashMap; Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/SoundBuffer;>;
 field protected sourceMap Ljava/util/HashMap; Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>;
 field protected streamingChannels Ljava/util/List; Ljava/util/List<Lpaulscode/sound/Channel;>;
 field protected normalChannels Ljava/util/List; Ljava/util/List<Lpaulscode/sound/Channel;>;
 field protected streamThread Lpaulscode/sound/StreamThread; -
 field protected reverseByteOrder Z -
 method public <init> ()V - paulscode/sound/SoundSystemException
 method public cleanup ()V - -
 method public init ()V - paulscode/sound/SoundSystemException
 method public,static libraryCompatible ()Z - -
 method protected createChannel (I)Lpaulscode/sound/Channel; - -
 method public loadSound (Lpaulscode/sound/FilenameURL;)Z - -
 method public loadSound (Lpaulscode/sound/SoundBuffer;Ljava/lang/String;)Z - -
 method public getAllLoadedFilenames ()Ljava/util/LinkedList; ()Ljava/util/LinkedList<Ljava/lang/String;>; -
 method public getAllSourcenames ()Ljava/util/LinkedList; ()Ljava/util/LinkedList<Ljava/lang/String;>; -
 method public unloadSound (Ljava/lang/String;)V - -
 method public rawDataStream (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public newSource (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIF)V - -
 method public quickPlay (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIFZ)V - -
 method public setTemporary (Ljava/lang/String;Z)V - -
 method public setPosition (Ljava/lang/String;FFF)V - -
 method public setPriority (Ljava/lang/String;Z)V - -
 method public setLooping (Ljava/lang/String;Z)V - -
 method public setAttenuation (Ljava/lang/String;I)V - -
 method public setDistOrRoll (Ljava/lang/String;F)V - -
 method public setVelocity (Ljava/lang/String;FFF)V - -
 method public setListenerVelocity (FFF)V - -
 method public dopplerChanged ()V - -
 method public millisecondsPlayed (Ljava/lang/String;)F - -
 method public feedRawAudioData (Ljava/lang/String;[B)I - -
 method public feedRawAudioData (Lpaulscode/sound/Source;[B)I - -
 method public play (Ljava/lang/String;)V - -
 method public play (Lpaulscode/sound/Source;)V - -
 method public stop (Ljava/lang/String;)V - -
 method public pause (Ljava/lang/String;)V - -
 method public rewind (Ljava/lang/String;)V - -
 method public flush (Ljava/lang/String;)V - -
 method public cull (Ljava/lang/String;)V - -
 method public activate (Ljava/lang/String;)V - -
 method public setMasterVolume (F)V - -
 method public setVolume (Ljava/lang/String;F)V - -
 method public getVolume (Ljava/lang/String;)F - -
 method public setPitch (Ljava/lang/String;F)V - -
 method public getPitch (Ljava/lang/String;)F - -
 method public moveListener (FFF)V - -
 method public setListenerPosition (FFF)V - -
 method public turnListener (F)V - -
 method public setListenerAngle (F)V - -
 method public setListenerOrientation (FFFFFF)V - -
 method public setListenerData (Lpaulscode/sound/ListenerData;)V - -
 method public copySources (Ljava/util/HashMap;)V (Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>;)V -
 method public removeSource (Ljava/lang/String;)V - -
 method public removeTemporarySources ()V - -
 method public replaySources ()V - -
 method public queueSound (Ljava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public dequeueSound (Ljava/lang/String;Ljava/lang/String;)V - -
 method public fadeOut (Ljava/lang/String;Lpaulscode/sound/FilenameURL;J)V - -
 method public fadeOutIn (Ljava/lang/String;Lpaulscode/sound/FilenameURL;JJ)V - -
 method public checkFadeVolumes ()V - -
 method public loadMidi (ZLjava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public unloadMidi ()V - -
 method public midiSourcename (Ljava/lang/String;)Z - -
 method public getSource (Ljava/lang/String;)Lpaulscode/sound/Source; - -
 method public getMidiChannel ()Lpaulscode/sound/MidiChannel; - -
 method public setMidiChannel (Lpaulscode/sound/MidiChannel;)V - -
 method public listenerMoved ()V - -
 method public getSources ()Ljava/util/HashMap; ()Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>; -
 method public getListenerData ()Lpaulscode/sound/ListenerData; - -
 method public reverseByteOrder ()Z - -
 method public,static getTitle ()Ljava/lang/String; - -
 method public,static getDescription ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 135
class paulscode/sound/Library 52 public,super java/lang/Object - -
 field protected listener Lpaulscode/sound/ListenerData; -
 field protected bufferMap Ljava/util/HashMap; Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/SoundBuffer;>;
 field protected sourceMap Ljava/util/HashMap; Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>;
 field protected streamingChannels Ljava/util/List; Ljava/util/List<Lpaulscode/sound/Channel;>;
 field protected normalChannels Ljava/util/List; Ljava/util/List<Lpaulscode/sound/Channel;>;
 field protected streamThread Lpaulscode/sound/StreamThread; -
 field protected reverseByteOrder Z -
 method public <init> ()V - paulscode/sound/SoundSystemException
 method public cleanup ()V - -
 method public init ()V - paulscode/sound/SoundSystemException
 method public,static libraryCompatible ()Z - -
 method protected createChannel (I)Lpaulscode/sound/Channel; - -
 method public loadSound (Lpaulscode/sound/FilenameURL;)Z - -
 method public loadSound (Lpaulscode/sound/SoundBuffer;Ljava/lang/String;)Z - -
 method public getAllLoadedFilenames ()Ljava/util/LinkedList; ()Ljava/util/LinkedList<Ljava/lang/String;>; -
 method public getAllSourcenames ()Ljava/util/LinkedList; ()Ljava/util/LinkedList<Ljava/lang/String;>; -
 method public unloadSound (Ljava/lang/String;)V - -
 method public rawDataStream (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public newSource (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIF)V - -
 method public quickPlay (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIFZ)V - -
 method public setTemporary (Ljava/lang/String;Z)V - -
 method public setPosition (Ljava/lang/String;FFF)V - -
 method public setPriority (Ljava/lang/String;Z)V - -
 method public setLooping (Ljava/lang/String;Z)V - -
 method public setAttenuation (Ljava/lang/String;I)V - -
 method public setDistOrRoll (Ljava/lang/String;F)V - -
 method public setVelocity (Ljava/lang/String;FFF)V - -
 method public setListenerVelocity (FFF)V - -
 method public dopplerChanged ()V - -
 method public millisecondsPlayed (Ljava/lang/String;)F - -
 method public feedRawAudioData (Ljava/lang/String;[B)I - -
 method public feedRawAudioData (Lpaulscode/sound/Source;[B)I - -
 method public play (Ljava/lang/String;)V - -
 method public play (Lpaulscode/sound/Source;)V - -
 method public stop (Ljava/lang/String;)V - -
 method public pause (Ljava/lang/String;)V - -
 method public rewind (Ljava/lang/String;)V - -
 method public flush (Ljava/lang/String;)V - -
 method public cull (Ljava/lang/String;)V - -
 method public activate (Ljava/lang/String;)V - -
 method public setMasterVolume (F)V - -
 method public setVolume (Ljava/lang/String;F)V - -
 method public getVolume (Ljava/lang/String;)F - -
 method public setPitch (Ljava/lang/String;F)V - -
 method public getPitch (Ljava/lang/String;)F - -
 method public moveListener (FFF)V - -
 method public setListenerPosition (FFF)V - -
 method public turnListener (F)V - -
 method public setListenerAngle (F)V - -
 method public setListenerOrientation (FFFFFF)V - -
 method public setListenerData (Lpaulscode/sound/ListenerData;)V - -
 method public copySources (Ljava/util/HashMap;)V (Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>;)V -
 method public removeSource (Ljava/lang/String;)V - -
 method public removeTemporarySources ()V - -
 method public replaySources ()V - -
 method public queueSound (Ljava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public dequeueSound (Ljava/lang/String;Ljava/lang/String;)V - -
 method public fadeOut (Ljava/lang/String;Lpaulscode/sound/FilenameURL;J)V - -
 method public fadeOutIn (Ljava/lang/String;Lpaulscode/sound/FilenameURL;JJ)V - -
 method public checkFadeVolumes ()V - -
 method public loadMidi (ZLjava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public unloadMidi ()V - -
 method public midiSourcename (Ljava/lang/String;)Z - -
 method public getSource (Ljava/lang/String;)Lpaulscode/sound/Source; - -
 method public getMidiChannel ()Lpaulscode/sound/MidiChannel; - -
 method public setMidiChannel (Lpaulscode/sound/MidiChannel;)V - -
 method public listenerMoved ()V - -
 method public getSources ()Ljava/util/HashMap; ()Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>; -
 method public getListenerData ()Lpaulscode/sound/ListenerData; - -
 method public reverseByteOrder ()Z - -
 method public,static getTitle ()Ljava/lang/String; - -
 method public,static getDescription ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 131
class paulscode/sound/ListenerData 49 public,super java/lang/Object - -
 field public position Lpaulscode/sound/Vector3D; -
 field public lookAt Lpaulscode/sound/Vector3D; -
 field public up Lpaulscode/sound/Vector3D; -
 field public velocity Lpaulscode/sound/Vector3D; -
 field public angle F -
 method public <init> ()V - -
 method public <init> (FFFFFFFFFF)V - -
 method public <init> (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;F)V - -
 method public setData (FFFFFFFFFF)V - -
 method public setData (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;F)V - -
 method public setData (Lpaulscode/sound/ListenerData;)V - -
 method public setPosition (FFF)V - -
 method public setPosition (Lpaulscode/sound/Vector3D;)V - -
 method public setOrientation (FFFFFF)V - -
 method public setOrientation (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)V - -
 method public setVelocity (Lpaulscode/sound/Vector3D;)V - -
 method public setVelocity (FFF)V - -
 method public setAngle (F)V - -
in 135
class paulscode/sound/ListenerData 52 public,super java/lang/Object - -
 field public position Lpaulscode/sound/Vector3D; -
 field public lookAt Lpaulscode/sound/Vector3D; -
 field public up Lpaulscode/sound/Vector3D; -
 field public velocity Lpaulscode/sound/Vector3D; -
 field public angle F -
 method public <init> ()V - -
 method public <init> (FFFFFFFFFF)V - -
 method public <init> (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;F)V - -
 method public setData (FFFFFFFFFF)V - -
 method public setData (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;F)V - -
 method public setData (Lpaulscode/sound/ListenerData;)V - -
 method public setPosition (FFF)V - -
 method public setPosition (Lpaulscode/sound/Vector3D;)V - -
 method public setOrientation (FFFFFF)V - -
 method public setOrientation (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)V - -
 method public setVelocity (Lpaulscode/sound/Vector3D;)V - -
 method public setVelocity (FFF)V - -
 method public setAngle (F)V - -
in 131
class paulscode/sound/MidiChannel 49 public,super java/lang/Object javax/sound/midi/MetaEventListener -
 inner paulscode/sound/MidiChannel$FadeThread paulscode/sound/MidiChannel FadeThread private
 inner javax/sound/midi/MidiDevice$Info javax/sound/midi/MidiDevice Info public,static
 field protected fadeOutGain F -
 field protected fadeInGain F -
 field protected fadeOutMilis J -
 field protected fadeInMilis J -
 field protected lastFadeCheck J -
 method public <init> (ZLjava/lang/String;Ljava/lang/String;)V - -
 method public <init> (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;)V - -
 method public <init> (ZLjava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public cleanup ()V - -
 method public queueSound (Lpaulscode/sound/FilenameURL;)V - -
 method public dequeueSound (Ljava/lang/String;)V - -
 method public fadeOut (Lpaulscode/sound/FilenameURL;J)V - -
 method public fadeOutIn (Lpaulscode/sound/FilenameURL;JJ)V - -
 method public play ()V - -
 method public stop ()V - -
 method public pause ()V - -
 method public rewind ()V - -
 method public setVolume (F)V - -
 method public getVolume ()F - -
 method public switchSource (ZLjava/lang/String;Ljava/lang/String;)V - -
 method public switchSource (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;)V - -
 method public switchSource (ZLjava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public setLooping (Z)V - -
 method public getLooping ()Z - -
 method public loading ()Z - -
 method public setSourcename (Ljava/lang/String;)V - -
 method public getSourcename ()Ljava/lang/String; - -
 method public setFilenameURL (Lpaulscode/sound/FilenameURL;)V - -
 method public getFilename ()Ljava/lang/String; - -
 method public getFilenameURL ()Lpaulscode/sound/FilenameURL; - -
 method public meta (Ljavax/sound/midi/MetaMessage;)V - -
 method public resetGain ()V - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 135
class paulscode/sound/MidiChannel 52 public,super java/lang/Object javax/sound/midi/MetaEventListener -
 inner paulscode/sound/MidiChannel$FadeThread paulscode/sound/MidiChannel FadeThread private
 inner javax/sound/midi/MidiDevice$Info javax/sound/midi/MidiDevice Info public,static
 field protected fadeOutGain F -
 field protected fadeInGain F -
 field protected fadeOutMilis J -
 field protected fadeInMilis J -
 field protected lastFadeCheck J -
 method public <init> (ZLjava/lang/String;Ljava/lang/String;)V - -
 method public <init> (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;)V - -
 method public <init> (ZLjava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public cleanup ()V - -
 method public queueSound (Lpaulscode/sound/FilenameURL;)V - -
 method public dequeueSound (Ljava/lang/String;)V - -
 method public fadeOut (Lpaulscode/sound/FilenameURL;J)V - -
 method public fadeOutIn (Lpaulscode/sound/FilenameURL;JJ)V - -
 method public play ()V - -
 method public stop ()V - -
 method public pause ()V - -
 method public rewind ()V - -
 method public setVolume (F)V - -
 method public getVolume ()F - -
 method public switchSource (ZLjava/lang/String;Ljava/lang/String;)V - -
 method public switchSource (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;)V - -
 method public switchSource (ZLjava/lang/String;Lpaulscode/sound/FilenameURL;)V - -
 method public setLooping (Z)V - -
 method public getLooping ()Z - -
 method public loading ()Z - -
 method public setSourcename (Ljava/lang/String;)V - -
 method public getSourcename ()Ljava/lang/String; - -
 method public setFilenameURL (Lpaulscode/sound/FilenameURL;)V - -
 method public getFilename ()Ljava/lang/String; - -
 method public getFilenameURL ()Lpaulscode/sound/FilenameURL; - -
 method public meta (Ljavax/sound/midi/MetaMessage;)V - -
 method public resetGain ()V - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 131
class paulscode/sound/MidiChannel$FadeThread 49 super paulscode/sound/SimpleThread - -
 inner paulscode/sound/MidiChannel$FadeThread paulscode/sound/MidiChannel FadeThread private
 method public run ()V - -
in 135
class paulscode/sound/MidiChannel$FadeThread 52 super paulscode/sound/SimpleThread - -
 inner paulscode/sound/MidiChannel$FadeThread paulscode/sound/MidiChannel FadeThread private
 method public run ()V - -
in 131
class paulscode/sound/SimpleThread 49 public,super java/lang/Thread - -
 method public <init> ()V - -
 method protected cleanup ()V - -
 method public run ()V - -
 method public restart ()V - -
 method public alive ()Z - -
 method public kill ()V - -
 method protected dying ()Z - -
 method protected snooze (J)V - -
in 135
class paulscode/sound/SimpleThread 52 public,super java/lang/Thread - -
 method public <init> ()V - -
 method protected cleanup ()V - -
 method public run ()V - -
 method public restart ()V - -
 method public alive ()Z - -
 method public kill ()V - -
 method protected dying ()Z - -
 method protected snooze (J)V - -
in 131
class paulscode/sound/SoundBuffer 49 public,super java/lang/Object - -
 field public audioData [B -
 field public audioFormat Ljavax/sound/sampled/AudioFormat; -
 method public <init> ([BLjavax/sound/sampled/AudioFormat;)V - -
 method public cleanup ()V - -
 method public trimData (I)V - -
in 135
class paulscode/sound/SoundBuffer 52 public,super java/lang/Object - -
 field public audioData [B -
 field public audioFormat Ljavax/sound/sampled/AudioFormat; -
 method public <init> ([BLjavax/sound/sampled/AudioFormat;)V - -
 method public cleanup ()V - -
 method public trimData (I)V - -
in 131
class paulscode/sound/SoundSystem 49 public,super java/lang/Object - -
 field protected logger Lpaulscode/sound/SoundSystemLogger; -
 field protected soundLibrary Lpaulscode/sound/Library; -
 field protected commandQueue Ljava/util/List; Ljava/util/List<Lpaulscode/sound/CommandObject;>;
 field protected commandThread Lpaulscode/sound/CommandThread; -
 field public randomNumberGenerator Ljava/util/Random; -
 field protected className Ljava/lang/String; -
 method public <init> ()V - -
 method public <init> (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method protected linkDefaultLibrariesAndCodecs ()V - -
 method protected init (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public cleanup ()V - -
 method public interruptCommandThread ()V - -
 method public loadSound (Ljava/lang/String;)V - -
 method public loadSound (Ljava/net/URL;Ljava/lang/String;)V - -
 method public loadSound ([BLjavax/sound/sampled/AudioFormat;Ljava/lang/String;)V - -
 method public unloadSound (Ljava/lang/String;)V - -
 method public queueSound (Ljava/lang/String;Ljava/lang/String;)V - -
 method public queueSound (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;)V - -
 method public dequeueSound (Ljava/lang/String;Ljava/lang/String;)V - -
 method public fadeOut (Ljava/lang/String;Ljava/lang/String;J)V - -
 method public fadeOut (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;J)V - -
 method public fadeOutIn (Ljava/lang/String;Ljava/lang/String;JJ)V - -
 method public fadeOutIn (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;JJ)V - -
 method public checkFadeVolumes ()V - -
 method public backgroundMusic (Ljava/lang/String;Ljava/lang/String;Z)V - -
 method public backgroundMusic (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;Z)V - -
 method public newSource (ZLjava/lang/String;Ljava/lang/String;ZFFFIF)V - -
 method public newSource (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;ZFFFIF)V - -
 method public newStreamingSource (ZLjava/lang/String;Ljava/lang/String;ZFFFIF)V - -
 method public newStreamingSource (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;ZFFFIF)V - -
 method public rawDataStream (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public quickPlay (ZLjava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public quickPlay (ZLjava/net/URL;Ljava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public quickStream (ZLjava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public quickStream (ZLjava/net/URL;Ljava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public setPosition (Ljava/lang/String;FFF)V - -
 method public setVolume (Ljava/lang/String;F)V - -
 method public getVolume (Ljava/lang/String;)F - -
 method public setPitch (Ljava/lang/String;F)V - -
 method public getPitch (Ljava/lang/String;)F - -
 method public setPriority (Ljava/lang/String;Z)V - -
 method public setLooping (Ljava/lang/String;Z)V - -
 method public setAttenuation (Ljava/lang/String;I)V - -
 method public setDistOrRoll (Ljava/lang/String;F)V - -
 method public changeDopplerFactor (F)V - -
 method public changeDopplerVelocity (F)V - -
 method public setVelocity (Ljava/lang/String;FFF)V - -
 method public setListenerVelocity (FFF)V - -
 method public millisecondsPlayed (Ljava/lang/String;)F - -
 method public feedRawAudioData (Ljava/lang/String;[B)V - -
 method public play (Ljava/lang/String;)V - -
 method public pause (Ljava/lang/String;)V - -
 method public stop (Ljava/lang/String;)V - -
 method public rewind (Ljava/lang/String;)V - -
 method public flush (Ljava/lang/String;)V - -
 method public cull (Ljava/lang/String;)V - -
 method public activate (Ljava/lang/String;)V - -
 method public setTemporary (Ljava/lang/String;Z)V - -
 method public removeSource (Ljava/lang/String;)V - -
 method public moveListener (FFF)V - -
 method public setListenerPosition (FFF)V - -
 method public turnListener (F)V - -
 method public setListenerAngle (F)V - -
 method public setListenerOrientation (FFFFFF)V - -
 method public setMasterVolume (F)V - -
 method public getMasterVolume ()F - -
 method public getListenerData ()Lpaulscode/sound/ListenerData; - -
 method public switchLibrary (Ljava/lang/Class;)Z - paulscode/sound/SoundSystemException
 method public newLibrary (Ljava/lang/Class;)Z - paulscode/sound/SoundSystemException
 method protected ManageSources ()V - -
 method public CommandQueue (Lpaulscode/sound/CommandObject;)Z - -
 method public removeTemporarySources ()V - -
 method public playing (Ljava/lang/String;)Z - -
 method public playing ()Z - -
 method public,static libraryCompatible (Ljava/lang/Class;)Z - -
 method public,static currentLibrary ()Ljava/lang/Class; - -
 method public,static initialized ()Z - -
 method public,static getLastException ()Lpaulscode/sound/SoundSystemException; - -
 method public,static setException (Lpaulscode/sound/SoundSystemException;)V - -
 method protected,static snooze (J)V - -
 method protected message (Ljava/lang/String;I)V - -
 method protected importantMessage (Ljava/lang/String;I)V - -
 method protected errorCheck (ZLjava/lang/String;I)Z - -
 method protected errorMessage (Ljava/lang/String;I)V - -
in 135
class paulscode/sound/SoundSystem 52 public,super java/lang/Object - -
 field protected logger Lpaulscode/sound/SoundSystemLogger; -
 field protected soundLibrary Lpaulscode/sound/Library; -
 field protected commandQueue Ljava/util/List; Ljava/util/List<Lpaulscode/sound/CommandObject;>;
 field protected commandThread Lpaulscode/sound/CommandThread; -
 field public randomNumberGenerator Ljava/util/Random; -
 field protected className Ljava/lang/String; -
 method public <init> ()V - -
 method public <init> (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method protected linkDefaultLibrariesAndCodecs ()V - -
 method protected init (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public cleanup ()V - -
 method public interruptCommandThread ()V - -
 method public loadSound (Ljava/lang/String;)V - -
 method public loadSound (Ljava/net/URL;Ljava/lang/String;)V - -
 method public loadSound ([BLjavax/sound/sampled/AudioFormat;Ljava/lang/String;)V - -
 method public unloadSound (Ljava/lang/String;)V - -
 method public queueSound (Ljava/lang/String;Ljava/lang/String;)V - -
 method public queueSound (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;)V - -
 method public dequeueSound (Ljava/lang/String;Ljava/lang/String;)V - -
 method public fadeOut (Ljava/lang/String;Ljava/lang/String;J)V - -
 method public fadeOut (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;J)V - -
 method public fadeOutIn (Ljava/lang/String;Ljava/lang/String;JJ)V - -
 method public fadeOutIn (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;JJ)V - -
 method public checkFadeVolumes ()V - -
 method public backgroundMusic (Ljava/lang/String;Ljava/lang/String;Z)V - -
 method public backgroundMusic (Ljava/lang/String;Ljava/net/URL;Ljava/lang/String;Z)V - -
 method public newSource (ZLjava/lang/String;Ljava/lang/String;ZFFFIF)V - -
 method public newSource (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;ZFFFIF)V - -
 method public newStreamingSource (ZLjava/lang/String;Ljava/lang/String;ZFFFIF)V - -
 method public newStreamingSource (ZLjava/lang/String;Ljava/net/URL;Ljava/lang/String;ZFFFIF)V - -
 method public rawDataStream (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public quickPlay (ZLjava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public quickPlay (ZLjava/net/URL;Ljava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public quickStream (ZLjava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public quickStream (ZLjava/net/URL;Ljava/lang/String;ZFFFIF)Ljava/lang/String; - -
 method public setPosition (Ljava/lang/String;FFF)V - -
 method public setVolume (Ljava/lang/String;F)V - -
 method public getVolume (Ljava/lang/String;)F - -
 method public setPitch (Ljava/lang/String;F)V - -
 method public getPitch (Ljava/lang/String;)F - -
 method public setPriority (Ljava/lang/String;Z)V - -
 method public setLooping (Ljava/lang/String;Z)V - -
 method public setAttenuation (Ljava/lang/String;I)V - -
 method public setDistOrRoll (Ljava/lang/String;F)V - -
 method public changeDopplerFactor (F)V - -
 method public changeDopplerVelocity (F)V - -
 method public setVelocity (Ljava/lang/String;FFF)V - -
 method public setListenerVelocity (FFF)V - -
 method public millisecondsPlayed (Ljava/lang/String;)F - -
 method public feedRawAudioData (Ljava/lang/String;[B)V - -
 method public play (Ljava/lang/String;)V - -
 method public pause (Ljava/lang/String;)V - -
 method public stop (Ljava/lang/String;)V - -
 method public rewind (Ljava/lang/String;)V - -
 method public flush (Ljava/lang/String;)V - -
 method public cull (Ljava/lang/String;)V - -
 method public activate (Ljava/lang/String;)V - -
 method public setTemporary (Ljava/lang/String;Z)V - -
 method public removeSource (Ljava/lang/String;)V - -
 method public moveListener (FFF)V - -
 method public setListenerPosition (FFF)V - -
 method public turnListener (F)V - -
 method public setListenerAngle (F)V - -
 method public setListenerOrientation (FFFFFF)V - -
 method public setMasterVolume (F)V - -
 method public getMasterVolume ()F - -
 method public getListenerData ()Lpaulscode/sound/ListenerData; - -
 method public switchLibrary (Ljava/lang/Class;)Z - paulscode/sound/SoundSystemException
 method public newLibrary (Ljava/lang/Class;)Z - paulscode/sound/SoundSystemException
 method protected ManageSources ()V - -
 method public CommandQueue (Lpaulscode/sound/CommandObject;)Z - -
 method public removeTemporarySources ()V - -
 method public playing (Ljava/lang/String;)Z - -
 method public playing ()Z - -
 method public,static libraryCompatible (Ljava/lang/Class;)Z - -
 method public,static currentLibrary ()Ljava/lang/Class; - -
 method public,static initialized ()Z - -
 method public,static getLastException ()Lpaulscode/sound/SoundSystemException; - -
 method public,static setException (Lpaulscode/sound/SoundSystemException;)V - -
 method protected,static snooze (J)V - -
 method protected message (Ljava/lang/String;I)V - -
 method protected importantMessage (Ljava/lang/String;I)V - -
 method protected errorCheck (ZLjava/lang/String;I)Z - -
 method protected errorMessage (Ljava/lang/String;I)V - -
in 131
class paulscode/sound/SoundSystemConfig 49 public,super java/lang/Object - -
 inner paulscode/sound/SoundSystemConfig$Codec paulscode/sound/SoundSystemConfig Codec private,static
 field public,static,final THREAD_SYNC Ljava/lang/Object; -
 field public,static,final TYPE_NORMAL I - I0
 field public,static,final TYPE_STREAMING I - I1
 field public,static,final ATTENUATION_NONE I - I0
 field public,static,final ATTENUATION_ROLLOFF I - I1
 field public,static,final ATTENUATION_LINEAR I - I2
 field public,static EXTENSION_MIDI Ljava/lang/String; -
 field public,static PREFIX_URL Ljava/lang/String; -
 method public <init> ()V - -
 method public,static addLibrary (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public,static removeLibrary (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public,static getLibraries ()Ljava/util/LinkedList; ()Ljava/util/LinkedList<Ljava/lang/Class;>; -
 method public,static libraryCompatible (Ljava/lang/Class;)Z - -
 method public,static getLibraryTitle (Ljava/lang/Class;)Ljava/lang/String; - -
 method public,static getLibraryDescription (Ljava/lang/Class;)Ljava/lang/String; - -
 method public,static reverseByteOrder (Ljava/lang/Class;)Z - -
 method public,static setLogger (Lpaulscode/sound/SoundSystemLogger;)V - -
 method public,static getLogger ()Lpaulscode/sound/SoundSystemLogger; - -
 method public,static,synchronized setNumberNormalChannels (I)V - -
 method public,static,synchronized getNumberNormalChannels ()I - -
 method public,static,synchronized setNumberStreamingChannels (I)V - -
 method public,static,synchronized getNumberStreamingChannels ()I - -
 method public,static,synchronized setMasterGain (F)V - -
 method public,static,synchronized getMasterGain ()F - -
 method public,static,synchronized setDefaultAttenuation (I)V - -
 method public,static,synchronized getDefaultAttenuation ()I - -
 method public,static,synchronized setDefaultRolloff (F)V - -
 method public,static,synchronized getDopplerFactor ()F - -
 method public,static,synchronized setDopplerFactor (F)V - -
 method public,static,synchronized getDopplerVelocity ()F - -
 method public,static,synchronized setDopplerVelocity (F)V - -
 method public,static,synchronized getDefaultRolloff ()F - -
 method public,static,synchronized setDefaultFadeDistance (F)V - -
 method public,static,synchronized getDefaultFadeDistance ()F - -
 method public,static,synchronized setSoundFilesPackage (Ljava/lang/String;)V - -
 method public,static,synchronized getSoundFilesPackage ()Ljava/lang/String; - -
 method public,static,synchronized setStreamingBufferSize (I)V - -
 method public,static,synchronized getStreamingBufferSize ()I - -
 method public,static,synchronized setNumberStreamingBuffers (I)V - -
 method public,static,synchronized getNumberStreamingBuffers ()I - -
 method public,static,synchronized setStreamQueueFormatsMatch (Z)V - -
 method public,static,synchronized getStreamQueueFormatsMatch ()Z - -
 method public,static,synchronized setMaxFileSize (I)V - -
 method public,static,synchronized getMaxFileSize ()I - -
 method public,static,synchronized setFileChunkSize (I)V - -
 method public,static,synchronized getFileChunkSize ()I - -
 method public,static,synchronized getOverrideMIDISynthesizer ()Ljava/lang/String; - -
 method public,static,synchronized setOverrideMIDISynthesizer (Ljava/lang/String;)V - -
 method public,static,synchronized setCodec (Ljava/lang/String;Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public,static,synchronized getCodec (Ljava/lang/String;)Lpaulscode/sound/ICodec; - -
 method public,static midiCodec ()Z - -
 method public,static addStreamListener (Lpaulscode/sound/IStreamListener;)V - -
 method public,static removeStreamListener (Lpaulscode/sound/IStreamListener;)V - -
 method public,static notifyEOS (Ljava/lang/String;I)V - -
in 135
class paulscode/sound/SoundSystemConfig 52 public,super java/lang/Object - -
 inner paulscode/sound/SoundSystemConfig$Codec paulscode/sound/SoundSystemConfig Codec private,static
 field public,static,final THREAD_SYNC Ljava/lang/Object; -
 field public,static,final TYPE_NORMAL I - I0
 field public,static,final TYPE_STREAMING I - I1
 field public,static,final ATTENUATION_NONE I - I0
 field public,static,final ATTENUATION_ROLLOFF I - I1
 field public,static,final ATTENUATION_LINEAR I - I2
 field public,static EXTENSION_MIDI Ljava/lang/String; -
 field public,static PREFIX_URL Ljava/lang/String; -
 method public <init> ()V - -
 method public,static addLibrary (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public,static removeLibrary (Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public,static getLibraries ()Ljava/util/LinkedList; ()Ljava/util/LinkedList<Ljava/lang/Class;>; -
 method public,static libraryCompatible (Ljava/lang/Class;)Z - -
 method public,static getLibraryTitle (Ljava/lang/Class;)Ljava/lang/String; - -
 method public,static getLibraryDescription (Ljava/lang/Class;)Ljava/lang/String; - -
 method public,static reverseByteOrder (Ljava/lang/Class;)Z - -
 method public,static setLogger (Lpaulscode/sound/SoundSystemLogger;)V - -
 method public,static getLogger ()Lpaulscode/sound/SoundSystemLogger; - -
 method public,static,synchronized setNumberNormalChannels (I)V - -
 method public,static,synchronized getNumberNormalChannels ()I - -
 method public,static,synchronized setNumberStreamingChannels (I)V - -
 method public,static,synchronized getNumberStreamingChannels ()I - -
 method public,static,synchronized setMasterGain (F)V - -
 method public,static,synchronized getMasterGain ()F - -
 method public,static,synchronized setDefaultAttenuation (I)V - -
 method public,static,synchronized getDefaultAttenuation ()I - -
 method public,static,synchronized setDefaultRolloff (F)V - -
 method public,static,synchronized getDopplerFactor ()F - -
 method public,static,synchronized setDopplerFactor (F)V - -
 method public,static,synchronized getDopplerVelocity ()F - -
 method public,static,synchronized setDopplerVelocity (F)V - -
 method public,static,synchronized getDefaultRolloff ()F - -
 method public,static,synchronized setDefaultFadeDistance (F)V - -
 method public,static,synchronized getDefaultFadeDistance ()F - -
 method public,static,synchronized setSoundFilesPackage (Ljava/lang/String;)V - -
 method public,static,synchronized getSoundFilesPackage ()Ljava/lang/String; - -
 method public,static,synchronized setStreamingBufferSize (I)V - -
 method public,static,synchronized getStreamingBufferSize ()I - -
 method public,static,synchronized setNumberStreamingBuffers (I)V - -
 method public,static,synchronized getNumberStreamingBuffers ()I - -
 method public,static,synchronized setStreamQueueFormatsMatch (Z)V - -
 method public,static,synchronized getStreamQueueFormatsMatch ()Z - -
 method public,static,synchronized setMaxFileSize (I)V - -
 method public,static,synchronized getMaxFileSize ()I - -
 method public,static,synchronized setFileChunkSize (I)V - -
 method public,static,synchronized getFileChunkSize ()I - -
 method public,static,synchronized getOverrideMIDISynthesizer ()Ljava/lang/String; - -
 method public,static,synchronized setOverrideMIDISynthesizer (Ljava/lang/String;)V - -
 method public,static,synchronized setCodec (Ljava/lang/String;Ljava/lang/Class;)V - paulscode/sound/SoundSystemException
 method public,static,synchronized getCodec (Ljava/lang/String;)Lpaulscode/sound/ICodec; - -
 method public,static midiCodec ()Z - -
 method public,static addStreamListener (Lpaulscode/sound/IStreamListener;)V - -
 method public,static removeStreamListener (Lpaulscode/sound/IStreamListener;)V - -
 method public,static notifyEOS (Ljava/lang/String;I)V - -
in 131
class paulscode/sound/SoundSystemConfig$Codec 49 super java/lang/Object - -
 inner paulscode/sound/SoundSystemConfig$Codec paulscode/sound/SoundSystemConfig Codec private,static
 field public extensionRegX Ljava/lang/String; -
 field public iCodecClass Ljava/lang/Class; -
 method public <init> (Ljava/lang/String;Ljava/lang/Class;)V - -
 method public getInstance ()Lpaulscode/sound/ICodec; - -
in 135
class paulscode/sound/SoundSystemConfig$Codec 52 super java/lang/Object - -
 inner paulscode/sound/SoundSystemConfig$Codec paulscode/sound/SoundSystemConfig Codec private,static
 field public extensionRegX Ljava/lang/String; -
 field public iCodecClass Ljava/lang/Class; -
 method public <init> (Ljava/lang/String;Ljava/lang/Class;)V - -
 method public getInstance ()Lpaulscode/sound/ICodec; - -
in 131
class paulscode/sound/SoundSystemException 49 public,super java/lang/Exception - -
 field public,static,final ERROR_NONE I - I0
 field public,static,final UNKNOWN_ERROR I - I1
 field public,static,final NULL_PARAMETER I - I2
 field public,static,final CLASS_TYPE_MISMATCH I - I3
 field public,static,final LIBRARY_NULL I - I4
 field public,static,final LIBRARY_TYPE I - I5
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;I)V - -
 method public getType ()I - -
in 135
class paulscode/sound/SoundSystemException 52 public,super java/lang/Exception - -
 field public,static,final ERROR_NONE I - I0
 field public,static,final UNKNOWN_ERROR I - I1
 field public,static,final NULL_PARAMETER I - I2
 field public,static,final CLASS_TYPE_MISMATCH I - I3
 field public,static,final LIBRARY_NULL I - I4
 field public,static,final LIBRARY_TYPE I - I5
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;I)V - -
 method public getType ()I - -
in 131
class paulscode/sound/SoundSystemLogger 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public message (Ljava/lang/String;I)V - -
 method public importantMessage (Ljava/lang/String;I)V - -
 method public errorCheck (ZLjava/lang/String;Ljava/lang/String;I)Z - -
 method public errorMessage (Ljava/lang/String;Ljava/lang/String;I)V - -
 method public printStackTrace (Ljava/lang/Exception;I)V - -
 method public printExceptionMessage (Ljava/lang/Exception;I)V - -
in 135
class paulscode/sound/SoundSystemLogger 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public message (Ljava/lang/String;I)V - -
 method public importantMessage (Ljava/lang/String;I)V - -
 method public errorCheck (ZLjava/lang/String;Ljava/lang/String;I)Z - -
 method public errorMessage (Ljava/lang/String;Ljava/lang/String;I)V - -
 method public printStackTrace (Ljava/lang/Exception;I)V - -
 method public printExceptionMessage (Ljava/lang/Exception;I)V - -
in 131
class paulscode/sound/Source 49 public,super java/lang/Object - -
 field protected libraryType Ljava/lang/Class; -
 field public rawDataStream Z -
 field public rawDataFormat Ljavax/sound/sampled/AudioFormat; -
 field public temporary Z -
 field public priority Z -
 field public toStream Z -
 field public toLoop Z -
 field public toPlay Z -
 field public sourcename Ljava/lang/String; -
 field public filenameURL Lpaulscode/sound/FilenameURL; -
 field public position Lpaulscode/sound/Vector3D; -
 field public attModel I -
 field public distOrRoll F -
 field public velocity Lpaulscode/sound/Vector3D; -
 field public gain F -
 field public sourceVolume F -
 field protected pitch F -
 field public distanceFromListener F -
 field public channel Lpaulscode/sound/Channel; -
 field public soundBuffer Lpaulscode/sound/SoundBuffer; -
 field protected codec Lpaulscode/sound/ICodec; -
 field protected nextCodec Lpaulscode/sound/ICodec; -
 field protected nextBuffers Ljava/util/LinkedList; Ljava/util/LinkedList<Lpaulscode/sound/SoundBuffer;>;
 field protected soundSequenceQueue Ljava/util/LinkedList; Ljava/util/LinkedList<Lpaulscode/sound/FilenameURL;>;
 field protected,final soundSequenceLock Ljava/lang/Object; -
 field public preLoad Z -
 field protected fadeOutGain F -
 field protected fadeInGain F -
 field protected fadeOutMilis J -
 field protected fadeInMilis J -
 field protected lastFadeCheck J -
 method public <init> (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;Lpaulscode/sound/SoundBuffer;FFFIFZ)V - -
 method public <init> (Lpaulscode/sound/Source;Lpaulscode/sound/SoundBuffer;)V - -
 method public <init> (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public cleanup ()V - -
 method public queueSound (Lpaulscode/sound/FilenameURL;)V - -
 method public dequeueSound (Ljava/lang/String;)V - -
 method public fadeOut (Lpaulscode/sound/FilenameURL;J)V - -
 method public fadeOutIn (Lpaulscode/sound/FilenameURL;JJ)V - -
 method public checkFadeOut ()Z - -
 method public incrementSoundSequence ()Z - -
 method public readBuffersFromNextSoundInSequence ()Z - -
 method public getSoundSequenceQueueSize ()I - -
 method public setTemporary (Z)V - -
 method public listenerMoved ()V - -
 method public setPosition (FFF)V - -
 method public positionChanged ()V - -
 method public setPriority (Z)V - -
 method public setLooping (Z)V - -
 method public setAttenuation (I)V - -
 method public setDistOrRoll (F)V - -
 method public setVelocity (FFF)V - -
 method public getDistanceFromListener ()F - -
 method public setPitch (F)V - -
 method public getPitch ()F - -
 method public reverseByteOrder ()Z - -
 method public changeSource (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;Lpaulscode/sound/SoundBuffer;FFFIFZ)V - -
 method public feedRawAudioData (Lpaulscode/sound/Channel;[B)I - -
 method public play (Lpaulscode/sound/Channel;)V - -
 method public stream ()Z - -
 method public preLoad ()Z - -
 method public pause ()V - -
 method public stop ()V - -
 method public rewind ()V - -
 method public flush ()V - -
 method public cull ()V - -
 method public activate ()V - -
 method public active ()Z - -
 method public playing ()Z - -
 method public stopped ()Z - -
 method public paused ()Z - -
 method public millisecondsPlayed ()F - -
 method public getClassName ()Ljava/lang/String; - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 135
class paulscode/sound/Source 52 public,super java/lang/Object - -
 field protected libraryType Ljava/lang/Class; -
 field public rawDataStream Z -
 field public rawDataFormat Ljavax/sound/sampled/AudioFormat; -
 field public temporary Z -
 field public priority Z -
 field public toStream Z -
 field public toLoop Z -
 field public toPlay Z -
 field public sourcename Ljava/lang/String; -
 field public filenameURL Lpaulscode/sound/FilenameURL; -
 field public position Lpaulscode/sound/Vector3D; -
 field public attModel I -
 field public distOrRoll F -
 field public velocity Lpaulscode/sound/Vector3D; -
 field public gain F -
 field public sourceVolume F -
 field public removed Z -
 field protected pitch F -
 field public distanceFromListener F -
 field public channel Lpaulscode/sound/Channel; -
 field public soundBuffer Lpaulscode/sound/SoundBuffer; -
 field protected codec Lpaulscode/sound/ICodec; -
 field protected nextCodec Lpaulscode/sound/ICodec; -
 field protected nextBuffers Ljava/util/LinkedList; Ljava/util/LinkedList<Lpaulscode/sound/SoundBuffer;>;
 field protected soundSequenceQueue Ljava/util/LinkedList; Ljava/util/LinkedList<Lpaulscode/sound/FilenameURL;>;
 field protected,final soundSequenceLock Ljava/lang/Object; -
 field public preLoad Z -
 field protected fadeOutGain F -
 field protected fadeInGain F -
 field protected fadeOutMilis J -
 field protected fadeInMilis J -
 field protected lastFadeCheck J -
 method public <init> (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;Lpaulscode/sound/SoundBuffer;FFFIFZ)V - -
 method public <init> (Lpaulscode/sound/Source;Lpaulscode/sound/SoundBuffer;)V - -
 method public <init> (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public cleanup ()V - -
 method public queueSound (Lpaulscode/sound/FilenameURL;)V - -
 method public dequeueSound (Ljava/lang/String;)V - -
 method public fadeOut (Lpaulscode/sound/FilenameURL;J)V - -
 method public fadeOutIn (Lpaulscode/sound/FilenameURL;JJ)V - -
 method public checkFadeOut ()Z - -
 method public incrementSoundSequence ()Z - -
 method public readBuffersFromNextSoundInSequence ()Z - -
 method public getSoundSequenceQueueSize ()I - -
 method public setTemporary (Z)V - -
 method public listenerMoved ()V - -
 method public setPosition (FFF)V - -
 method public positionChanged ()V - -
 method public setPriority (Z)V - -
 method public setLooping (Z)V - -
 method public setAttenuation (I)V - -
 method public setDistOrRoll (F)V - -
 method public setVelocity (FFF)V - -
 method public getDistanceFromListener ()F - -
 method public setPitch (F)V - -
 method public getPitch ()F - -
 method public reverseByteOrder ()Z - -
 method public changeSource (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;Lpaulscode/sound/SoundBuffer;FFFIFZ)V - -
 method public feedRawAudioData (Lpaulscode/sound/Channel;[B)I - -
 method public play (Lpaulscode/sound/Channel;)V - -
 method public stream ()Z - -
 method public preLoad ()Z - -
 method public pause ()V - -
 method public stop ()V - -
 method public rewind ()V - -
 method public flush ()V - -
 method public cull ()V - -
 method public activate ()V - -
 method public active ()Z - -
 method public playing ()Z - -
 method public stopped ()Z - -
 method public paused ()Z - -
 method public millisecondsPlayed ()F - -
 method public getClassName ()Ljava/lang/String; - -
 method protected message (Ljava/lang/String;)V - -
 method protected importantMessage (Ljava/lang/String;)V - -
 method protected errorCheck (ZLjava/lang/String;)Z - -
 method protected errorMessage (Ljava/lang/String;)V - -
 method protected printStackTrace (Ljava/lang/Exception;)V - -
in 131
class paulscode/sound/StreamThread 49 public,super paulscode/sound/SimpleThread - -
 method public <init> ()V - -
 method protected cleanup ()V - -
 method public run ()V - -
 method public watch (Lpaulscode/sound/Source;)V - -
in 135
class paulscode/sound/StreamThread 52 public,super paulscode/sound/SimpleThread - -
 method public <init> ()V - -
 method protected cleanup ()V - -
 method public run ()V - -
 method public watch (Lpaulscode/sound/Source;)V - -
in 131
class paulscode/sound/Vector3D 49 public,super java/lang/Object - -
 field public x F -
 field public y F -
 field public z F -
 method public <init> ()V - -
 method public <init> (FFF)V - -
 method public clone ()Lpaulscode/sound/Vector3D; - -
 method public cross (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public cross (Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public dot (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)F - -
 method public dot (Lpaulscode/sound/Vector3D;)F - -
 method public add (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public add (Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public subtract (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public subtract (Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public length ()F - -
 method public normalize ()V - -
 method public toString ()Ljava/lang/String; - -
in 135
class paulscode/sound/Vector3D 52 public,super java/lang/Object - -
 field public x F -
 field public y F -
 field public z F -
 method public <init> ()V - -
 method public <init> (FFF)V - -
 method public clone ()Lpaulscode/sound/Vector3D; - -
 method public cross (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public cross (Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public dot (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)F - -
 method public dot (Lpaulscode/sound/Vector3D;)F - -
 method public add (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public add (Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public subtract (Lpaulscode/sound/Vector3D;Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public subtract (Lpaulscode/sound/Vector3D;)Lpaulscode/sound/Vector3D; - -
 method public length ()F - -
 method public normalize ()V - -
 method public toString ()Ljava/lang/String; - -
in 59
class paulscode/sound/codecs/CodecJOrbis 49 public,super java/lang/Object paulscode/sound/ICodec -
 method public <init> ()V - -
 method public reverseByteOrder (Z)V - -
 method public initialize (Ljava/net/URL;)Z - -
 method public initialized ()Z - -
 method public read ()Lpaulscode/sound/SoundBuffer; - -
 method public readAll ()Lpaulscode/sound/SoundBuffer; - -
 method public endOfStream ()Z - -
 method public cleanup ()V - -
 method public getAudioFormat ()Ljavax/sound/sampled/AudioFormat; - -
in 59
class paulscode/sound/codecs/CodecWav 49 public,super java/lang/Object paulscode/sound/ICodec -
 method public reverseByteOrder (Z)V - -
 method public <init> ()V - -
 method public initialize (Ljava/net/URL;)Z - -
 method public initialized ()Z - -
 method public read ()Lpaulscode/sound/SoundBuffer; - -
 method public readAll ()Lpaulscode/sound/SoundBuffer; - -
 method public endOfStream ()Z - -
 method public cleanup ()V - -
 method public getAudioFormat ()Ljavax/sound/sampled/AudioFormat; - -
in 59
class paulscode/sound/libraries/ChannelJavaSound 49 public,super paulscode/sound/Channel - -
 inner javax/sound/sampled/DataLine$Info javax/sound/sampled/DataLine Info public,static
 inner javax/sound/sampled/Line$Info javax/sound/sampled/Line Info public,static
 inner javax/sound/sampled/FloatControl$Type javax/sound/sampled/FloatControl Type public,static
 inner javax/sound/sampled/Control$Type javax/sound/sampled/Control Type public,static
 field public clip Ljavax/sound/sampled/Clip; -
 field public sourceDataLine Ljavax/sound/sampled/SourceDataLine; -
 method public <init> (ILjavax/sound/sampled/Mixer;)V - -
 method public cleanup ()V - -
 method public newMixer (Ljavax/sound/sampled/Mixer;)V - -
 method public attachBuffer (Lpaulscode/sound/SoundBuffer;)Z - -
 method public setAudioFormat (Ljavax/sound/sampled/AudioFormat;)V - -
 method public resetStream (Ljavax/sound/sampled/AudioFormat;)Z - -
 method public setLooping (Z)V - -
 method public setPan (F)V - -
 method public setGain (F)V - -
 method public setPitch (F)V - -
 method public preLoadBuffers (Ljava/util/LinkedList;)Z (Ljava/util/LinkedList<[B>;)Z -
 method public queueBuffer ([B)Z - -
 method public processBuffer ()Z - -
 method public feedRawAudioData ([B)I - -
 method public buffersProcessed ()I - -
 method public flush ()V - -
 method public close ()V - -
 method public play ()V - -
 method public pause ()V - -
 method public stop ()V - -
 method public rewind ()V - -
 method public millisecondsPlayed ()F - -
 method public playing ()Z - -
in 59
class paulscode/sound/libraries/LibraryJavaSound 49 public,super paulscode/sound/Library - -
 inner paulscode/sound/libraries/LibraryJavaSound$Exception paulscode/sound/libraries/LibraryJavaSound Exception public,static
 inner paulscode/sound/libraries/LibraryJavaSound$MixerRanking paulscode/sound/libraries/LibraryJavaSound MixerRanking public,static
 inner javax/sound/sampled/Mixer$Info javax/sound/sampled/Mixer Info public,static
 method public <init> ()V - paulscode/sound/SoundSystemException
 method public init ()V - paulscode/sound/SoundSystemException
 method public,static libraryCompatible ()Z - -
 method protected createChannel (I)Lpaulscode/sound/Channel; - -
 method public cleanup ()V - -
 method public loadSound (Lpaulscode/sound/FilenameURL;)Z - -
 method public loadSound (Lpaulscode/sound/SoundBuffer;Ljava/lang/String;)Z - -
 method public setMasterVolume (F)V - -
 method public newSource (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIF)V - -
 method public rawDataStream (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public quickPlay (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIFZ)V - -
 method public copySources (Ljava/util/HashMap;)V (Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>;)V -
 method public setListenerVelocity (FFF)V - -
 method public dopplerChanged ()V - -
 method public,static getMixer ()Ljavax/sound/sampled/Mixer; - -
 method public,static setMixer (Ljavax/sound/sampled/Mixer;)V - paulscode/sound/SoundSystemException
 method public,static getMixerRanking ()Lpaulscode/sound/libraries/LibraryJavaSound$MixerRanking; - -
 method public,static setMinSampleRate (I)V - -
 method public,static setMaxSampleRate (I)V - -
 method public,static setLineCount (I)V - -
 method public,static useGainControl (Z)V - -
 method public,static usePanControl (Z)V - -
 method public,static useSampleRateControl (Z)V - -
 method public,static getTitle ()Ljava/lang/String; - -
 method public,static getDescription ()Ljava/lang/String; - -
 method public getClassName ()Ljava/lang/String; - -
in 59
class paulscode/sound/libraries/LibraryJavaSound$Exception 49 public,super paulscode/sound/SoundSystemException - -
 inner paulscode/sound/libraries/LibraryJavaSound$MixerRanking paulscode/sound/libraries/LibraryJavaSound MixerRanking public,static
 inner paulscode/sound/libraries/LibraryJavaSound$Exception paulscode/sound/libraries/LibraryJavaSound Exception public,static
 field public,static,final MIXER_PROBLEM I - I101
 field public,static mixerRanking Lpaulscode/sound/libraries/LibraryJavaSound$MixerRanking; -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;I)V - -
 method public <init> (Ljava/lang/String;Lpaulscode/sound/libraries/LibraryJavaSound$MixerRanking;)V - -
in 59
class paulscode/sound/libraries/LibraryJavaSound$MixerRanking 49 public,super java/lang/Object - -
 inner javax/sound/sampled/Mixer$Info javax/sound/sampled/Mixer Info public,static
 inner paulscode/sound/libraries/LibraryJavaSound$MixerRanking paulscode/sound/libraries/LibraryJavaSound MixerRanking public,static
 inner javax/sound/sampled/DataLine$Info javax/sound/sampled/DataLine Info public,static
 inner paulscode/sound/libraries/LibraryJavaSound$Exception paulscode/sound/libraries/LibraryJavaSound Exception public,static
 inner javax/sound/sampled/Line$Info javax/sound/sampled/Line Info public,static
 inner javax/sound/sampled/FloatControl$Type javax/sound/sampled/FloatControl Type public,static
 inner javax/sound/sampled/Control$Type javax/sound/sampled/Control Type public,static
 field public,static,final HIGH I - I1
 field public,static,final MEDIUM I - I2
 field public,static,final LOW I - I3
 field public,static,final NONE I - I4
 field public,static MIXER_EXISTS_PRIORITY I -
 field public,static MIN_SAMPLE_RATE_PRIORITY I -
 field public,static MAX_SAMPLE_RATE_PRIORITY I -
 field public,static LINE_COUNT_PRIORITY I -
 field public,static GAIN_CONTROL_PRIORITY I -
 field public,static PAN_CONTROL_PRIORITY I -
 field public,static SAMPLE_RATE_CONTROL_PRIORITY I -
 field public mixerInfo Ljavax/sound/sampled/Mixer$Info; -
 field public rank I -
 field public mixerExists Z -
 field public minSampleRateOK Z -
 field public maxSampleRateOK Z -
 field public lineCountOK Z -
 field public gainControlOK Z -
 field public panControlOK Z -
 field public sampleRateControlOK Z -
 field public minSampleRatePossible I -
 field public maxSampleRatePossible I -
 field public maxLinesPossible I -
 method public <init> ()V - -
 method public <init> (Ljavax/sound/sampled/Mixer$Info;IZZZZZZZ)V - -
 method public rank (Ljavax/sound/sampled/Mixer$Info;)V - paulscode/sound/libraries/LibraryJavaSound$Exception
in 59
class paulscode/sound/libraries/SourceJavaSound 49 public,super paulscode/sound/Source - -
 field protected channelJavaSound Lpaulscode/sound/libraries/ChannelJavaSound; -
 field public listener Lpaulscode/sound/ListenerData; -
 method public <init> (Lpaulscode/sound/ListenerData;ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;Lpaulscode/sound/SoundBuffer;FFFIFZ)V - -
 method public <init> (Lpaulscode/sound/ListenerData;Lpaulscode/sound/Source;Lpaulscode/sound/SoundBuffer;)V - -
 method public <init> (Lpaulscode/sound/ListenerData;Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public cleanup ()V - -
 method public changeSource (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;Lpaulscode/sound/SoundBuffer;FFFIFZ)V - -
 method public listenerMoved ()V - -
 method public setVelocity (FFF)V - -
 method public setPosition (FFF)V - -
 method public positionChanged ()V - -
 method public setPitch (F)V - -
 method public setAttenuation (I)V - -
 method public setDistOrRoll (F)V - -
 method public play (Lpaulscode/sound/Channel;)V - -
 method public preLoad ()Z - -
 method public calculateGain ()V - -
 method public calculatePan ()V - -
 method public calculatePitch ()V - -
 method public min (FF)F - -
