cg-stub-db 1
in 24
class jline/internal/Ansi 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static stripAnsi (Ljava/lang/String;)Ljava/lang/String; - -
in 24
class jline/internal/Configuration 49 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field public,static,final JLINE_CONFIGURATION Ljava/lang/String; - "jline.configuration"
 field public,static,final JLINE_RC Ljava/lang/String; - ".jline.rc"
 method public <init> ()V - -
 method public,static reset ()V - -
 method public,static getProperties ()Ljava/util/Properties; - -
 method public,static getString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getBoolean (Ljava/lang/String;)Z - -
 method public,static getBoolean (Ljava/lang/String;Z)Z - -
 method public,static getInteger (Ljava/lang/String;I)I - -
 method public,static getLong (Ljava/lang/String;J)J - -
 method public,static getLineSeparator ()Ljava/lang/String; - -
 method public,static getUserHome ()Ljava/io/File; - -
 method public,static getOsName ()Ljava/lang/String; - -
 method public,static isWindows ()Z - -
 method public,static isHpux ()Z - -
 method public,static getFileEncoding ()Ljava/lang/String; - -
 method public,static getEncoding ()Ljava/lang/String; - -
in 24
class jline/internal/Curses 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static,varargs tputs (Ljava/io/Writer;Ljava/lang/String;[Ljava/lang/Object;)V - java/io/IOException
in 24
class jline/internal/InfoCmp 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getInfoCmp (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException,java/lang/InterruptedException
 method public,static getAnsiCaps ()Ljava/lang/String; - -
 method public,static parseInfoCmp (Ljava/lang/String;Ljava/util/Set;Ljava/util/Map;Ljava/util/Map;)V (Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,static getNames (Ljava/lang/String;)[Ljava/lang/String; - -
in 24
class jline/internal/InputStreamReader 49 public,super java/io/Reader - -
 method public <init> (Ljava/io/InputStream;)V - -
 method public <init> (Ljava/io/InputStream;Ljava/lang/String;)V - java/io/UnsupportedEncodingException
 method public <init> (Ljava/io/InputStream;Ljava/nio/charset/CharsetDecoder;)V - -
 method public <init> (Ljava/io/InputStream;Ljava/nio/charset/Charset;)V - -
 method public close ()V - java/io/IOException
 method public getEncoding ()Ljava/lang/String; - -
 method public read ()I - java/io/IOException
 method public read ([CII)I - java/io/IOException
 method public ready ()Z - java/io/IOException
in 24
class jline/internal/Log 49 public,final,super java/lang/Object - -
 inner jline/internal/Log$Level jline/internal/Log Level public,static,final,enum
 field public,static,final TRACE Z -
 field public,static,final DEBUG Z -
 method public <init> ()V - -
 method public,static getOutput ()Ljava/io/PrintStream; - -
 method public,static setOutput (Ljava/io/PrintStream;)V - -
 method public,static,varargs trace ([Ljava/lang/Object;)V - -
 method public,static,varargs debug ([Ljava/lang/Object;)V - -
 method public,static,varargs info ([Ljava/lang/Object;)V - -
 method public,static,varargs warn ([Ljava/lang/Object;)V - -
 method public,static,varargs error ([Ljava/lang/Object;)V - -
in 24
class jline/internal/Log$Level 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljline/internal/Log$Level;>;
 inner jline/internal/Log$Level jline/internal/Log Level public,static,final,enum
 field public,static,final,enum TRACE Ljline/internal/Log$Level; -
 field public,static,final,enum DEBUG Ljline/internal/Log$Level; -
 field public,static,final,enum INFO Ljline/internal/Log$Level; -
 field public,static,final,enum WARN Ljline/internal/Log$Level; -
 field public,static,final,enum ERROR Ljline/internal/Log$Level; -
 method public,static values ()[Ljline/internal/Log$Level; - -
 method public,static valueOf (Ljava/lang/String;)Ljline/internal/Log$Level; - -
in 24
class jline/internal/NonBlockingInputStream 49 public,super java/io/InputStream java/lang/Runnable -
 method public <init> (Ljava/io/InputStream;Z)V - -
 method public,synchronized shutdown ()V - -
 method public isNonBlockingEnabled ()Z - -
 method public close ()V - java/io/IOException
 method public read ()I - java/io/IOException
 method public peek (J)I - java/io/IOException
 method public read (J)I - java/io/IOException
 method public read ([BII)I - java/io/IOException
 method public run ()V - -
in 24
class jline/internal/Nullable 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE])
 method public,abstract value ()Ljava/lang/String; - - ""
in 24
class jline/internal/Preconditions 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static checkNotNull (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;)TT; -
in 24
class jline/internal/ShutdownHooks 49 public,super java/lang/Object - -
 inner jline/internal/ShutdownHooks$Task jline/internal/ShutdownHooks Task public,static,interface,abstract
 field public,static,final JLINE_SHUTDOWNHOOK Ljava/lang/String; - "jline.shutdownhook"
 method public <init> ()V - -
 method public,static,synchronized add (Ljline/internal/ShutdownHooks$Task;)Ljline/internal/ShutdownHooks$Task; <T::Ljline/internal/ShutdownHooks$Task;>(TT;)TT; -
 method public,static,synchronized remove (Ljline/internal/ShutdownHooks$Task;)V - -
in 24
class jline/internal/ShutdownHooks$Task 49 public,interface,abstract java/lang/Object - -
 inner jline/internal/ShutdownHooks$Task jline/internal/ShutdownHooks Task public,static,interface,abstract
 method public,abstract run ()V - java/lang/Exception
in 24
class jline/internal/TerminalLineSettings 49 public,final,super java/lang/Object - -
 field public,static,final JLINE_STTY Ljava/lang/String; - "jline.stty"
 field public,static,final DEFAULT_STTY Ljava/lang/String; - "stty"
 field public,static,final JLINE_SH Ljava/lang/String; - "jline.sh"
 field public,static,final DEFAULT_SH Ljava/lang/String; - "sh"
 field public,static,final DEFAULT_TTY Ljava/lang/String; - "/dev/tty"
 method public,deprecated <init> ()V - java/io/IOException,java/lang/InterruptedException
 method public,deprecated <init> (Ljava/lang/String;)V - java/io/IOException,java/lang/InterruptedException
 method public,static,synchronized getSettings (Ljava/lang/String;)Ljline/internal/TerminalLineSettings; - java/io/IOException,java/lang/InterruptedException
 method public getTtyDevice ()Ljava/lang/String; - -
 method public getConfig ()Ljava/lang/String; - -
 method public restore ()V - java/io/IOException,java/lang/InterruptedException
 method public get (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException,java/lang/InterruptedException
 method public set (Ljava/lang/String;)V - java/io/IOException,java/lang/InterruptedException
 method public,varargs set ([Ljava/lang/String;)V - java/io/IOException,java/lang/InterruptedException
 method public undef (Ljava/lang/String;)V - java/io/IOException,java/lang/InterruptedException
 method public getProperty (Ljava/lang/String;)I - -
 method public getPropertyAsString (Ljava/lang/String;)Ljava/lang/String; - -
 method protected,static getPropertyAsString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method protected,static getProperty (Ljava/lang/String;Ljava/lang/String;)I - -
 method public,static waitAndCapture (Ljava/lang/Process;)Ljava/lang/String; - java/io/IOException,java/lang/InterruptedException
in 24
class jline/internal/TestAccessible 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER])
 anno visible @Ljava/lang/annotation/Documented;()
in 24
class jline/internal/Urls 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static create (Ljava/lang/String;)Ljava/net/URL; - -
 method public,static create (Ljava/io/File;)Ljava/net/URL; - -
