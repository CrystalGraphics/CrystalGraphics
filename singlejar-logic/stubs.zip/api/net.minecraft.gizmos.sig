cg-stub-db 1
in 2
class net/minecraft/gizmos/ArrowGizmo 65 public,final,super java/lang/Record net/minecraft/gizmos/Gizmo -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_WIDTH F - F2.5
 method public <init> (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;IF)V - -
 method public emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public start ()Lnet/minecraft/world/phys/Vec3; - -
 method public end ()Lnet/minecraft/world/phys/Vec3; - -
 method public color ()I - -
 method public width ()F - -
in 2
class net/minecraft/gizmos/CircleGizmo 65 public,final,super java/lang/Record net/minecraft/gizmos/Gizmo -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/phys/Vec3;FLnet/minecraft/gizmos/GizmoStyle;)V - -
 method public emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public pos ()Lnet/minecraft/world/phys/Vec3; - -
 method public radius ()F - -
 method public style ()Lnet/minecraft/gizmos/GizmoStyle; - -
in 2
class net/minecraft/gizmos/CuboidGizmo 65 public,final,super java/lang/Record net/minecraft/gizmos/Gizmo -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/gizmos/GizmoStyle;Z)V - -
 method public emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public aabb ()Lnet/minecraft/world/phys/AABB; - -
 method public style ()Lnet/minecraft/gizmos/GizmoStyle; - -
 method public coloredCornerStroke ()Z - -
in 2
class net/minecraft/gizmos/Gizmo 65 public,interface,abstract java/lang/Object - -
 method public,abstract emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
in 2
class net/minecraft/gizmos/GizmoCollector 65 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final IGNORED Lnet/minecraft/gizmos/GizmoProperties; -
 field public,static,final NOOP Lnet/minecraft/gizmos/GizmoCollector; -
 method public,abstract add (Lnet/minecraft/gizmos/Gizmo;)Lnet/minecraft/gizmos/GizmoProperties; - -
in 2
class net/minecraft/gizmos/GizmoPrimitives 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gizmos/TextGizmo$Style net/minecraft/gizmos/TextGizmo Style public,static,final
 method public,abstract addPoint (Lnet/minecraft/world/phys/Vec3;IF)V - -
 method public,abstract addLine (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;IF)V - -
 method public,abstract addTriangleFan ([Lnet/minecraft/world/phys/Vec3;I)V - -
 method public,abstract addQuad (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;I)V - -
 method public,abstract addText (Lnet/minecraft/world/phys/Vec3;Ljava/lang/String;Lnet/minecraft/gizmos/TextGizmo$Style;)V - -
in 2
class net/minecraft/gizmos/GizmoProperties 65 public,interface,abstract java/lang/Object - -
 method public,abstract setAlwaysOnTop ()Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,abstract persistForMillis (I)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,abstract fadeOut ()Lnet/minecraft/gizmos/GizmoProperties; - -
in 2
class net/minecraft/gizmos/GizmoStyle 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (IFI)V - -
 method public,static stroke (I)Lnet/minecraft/gizmos/GizmoStyle; - -
 method public,static stroke (IF)Lnet/minecraft/gizmos/GizmoStyle; - -
 method public,static fill (I)Lnet/minecraft/gizmos/GizmoStyle; - -
 method public,static strokeAndFill (IFI)Lnet/minecraft/gizmos/GizmoStyle; - -
 method public hasFill ()Z - -
 method public hasStroke ()Z - -
 method public multipliedStroke (F)I - -
 method public multipliedFill (F)I - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public stroke ()I - -
 method public strokeWidth ()F - -
 method public fill ()I - -
in 2
class net/minecraft/gizmos/Gizmos 65 public,super java/lang/Object - -
 inner net/minecraft/gizmos/Gizmos$TemporaryCollection net/minecraft/gizmos/Gizmos TemporaryCollection public,static
 inner net/minecraft/gizmos/TextGizmo$Style net/minecraft/gizmos/TextGizmo Style public,static,final
 method public,static withCollector (Lnet/minecraft/gizmos/GizmoCollector;)Lnet/minecraft/gizmos/Gizmos$TemporaryCollection; - -
 method public,static addGizmo (Lnet/minecraft/gizmos/Gizmo;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static cuboid (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/gizmos/GizmoStyle;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static cuboid (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/gizmos/GizmoStyle;Z)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static cuboid (Lnet/minecraft/core/BlockPos;Lnet/minecraft/gizmos/GizmoStyle;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static cuboid (Lnet/minecraft/core/BlockPos;FLnet/minecraft/gizmos/GizmoStyle;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static circle (Lnet/minecraft/world/phys/Vec3;FLnet/minecraft/gizmos/GizmoStyle;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static line (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;I)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static line (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;IF)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static arrow (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;I)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static arrow (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;IF)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static rect (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/core/Direction;Lnet/minecraft/gizmos/GizmoStyle;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static rect (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/gizmos/GizmoStyle;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static point (Lnet/minecraft/world/phys/Vec3;IF)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static billboardTextOverBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;IIF)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static billboardTextOverMob (Lnet/minecraft/world/entity/Entity;ILjava/lang/String;IF)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public,static billboardText (Ljava/lang/String;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/gizmos/TextGizmo$Style;)Lnet/minecraft/gizmos/GizmoProperties; - -
in 2
class net/minecraft/gizmos/Gizmos$TemporaryCollection 65 public,super java/lang/Object java/lang/AutoCloseable -
 inner net/minecraft/gizmos/Gizmos$TemporaryCollection net/minecraft/gizmos/Gizmos TemporaryCollection public,static
 method public close ()V - -
in 2
class net/minecraft/gizmos/LineGizmo 65 public,final,super java/lang/Record net/minecraft/gizmos/Gizmo -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_WIDTH F - F3.0
 method public <init> (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;IF)V - -
 method public emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public start ()Lnet/minecraft/world/phys/Vec3; - -
 method public end ()Lnet/minecraft/world/phys/Vec3; - -
 method public color ()I - -
 method public width ()F - -
in 2
class net/minecraft/gizmos/PointGizmo 65 public,final,super java/lang/Record net/minecraft/gizmos/Gizmo -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/phys/Vec3;IF)V - -
 method public emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public pos ()Lnet/minecraft/world/phys/Vec3; - -
 method public color ()I - -
 method public size ()F - -
in 2
class net/minecraft/gizmos/RectGizmo 65 public,final,super java/lang/Record net/minecraft/gizmos/Gizmo -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/gizmos/GizmoStyle;)V - -
 method public,static fromCuboidFace (Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/core/Direction;Lnet/minecraft/gizmos/GizmoStyle;)Lnet/minecraft/gizmos/RectGizmo; - -
 method public emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public a ()Lnet/minecraft/world/phys/Vec3; - -
 method public b ()Lnet/minecraft/world/phys/Vec3; - -
 method public c ()Lnet/minecraft/world/phys/Vec3; - -
 method public d ()Lnet/minecraft/world/phys/Vec3; - -
 method public style ()Lnet/minecraft/gizmos/GizmoStyle; - -
in 2
class net/minecraft/gizmos/SimpleGizmoCollector 65 public,super java/lang/Object net/minecraft/gizmos/GizmoCollector -
 inner net/minecraft/gizmos/SimpleGizmoCollector$GizmoInstance net/minecraft/gizmos/SimpleGizmoCollector GizmoInstance public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public add (Lnet/minecraft/gizmos/Gizmo;)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public drainGizmos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gizmos/SimpleGizmoCollector$GizmoInstance;>; -
 method public getGizmos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gizmos/SimpleGizmoCollector$GizmoInstance;>; -
 method public addTemporaryGizmos (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/gizmos/SimpleGizmoCollector$GizmoInstance;>;)V -
in 2
class net/minecraft/gizmos/SimpleGizmoCollector$GizmoInstance 65 public,super java/lang/Object net/minecraft/gizmos/GizmoProperties -
 inner net/minecraft/gizmos/SimpleGizmoCollector$GizmoInstance net/minecraft/gizmos/SimpleGizmoCollector GizmoInstance public,static
 method public setAlwaysOnTop ()Lnet/minecraft/gizmos/GizmoProperties; - -
 method public persistForMillis (I)Lnet/minecraft/gizmos/GizmoProperties; - -
 method public fadeOut ()Lnet/minecraft/gizmos/GizmoProperties; - -
 method public getAlphaMultiplier (J)F - -
 method public isAlwaysOnTop ()Z - -
 method public getExpireTimeMillis ()J - -
 method public gizmo ()Lnet/minecraft/gizmos/Gizmo; - -
in 2
class net/minecraft/gizmos/TextGizmo 65 public,final,super java/lang/Record net/minecraft/gizmos/Gizmo -
 inner net/minecraft/gizmos/TextGizmo$Style net/minecraft/gizmos/TextGizmo Style public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/phys/Vec3;Ljava/lang/String;Lnet/minecraft/gizmos/TextGizmo$Style;)V - -
 method public emit (Lnet/minecraft/gizmos/GizmoPrimitives;F)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public pos ()Lnet/minecraft/world/phys/Vec3; - -
 method public text ()Ljava/lang/String; - -
 method public style ()Lnet/minecraft/gizmos/TextGizmo$Style; - -
in 2
class net/minecraft/gizmos/TextGizmo$Style 65 public,final,super java/lang/Record - -
 inner net/minecraft/gizmos/TextGizmo$Style net/minecraft/gizmos/TextGizmo Style public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_SCALE F - F0.32
 method public <init> (IFLjava/util/OptionalDouble;)V - -
 method public,static whiteAndCentered ()Lnet/minecraft/gizmos/TextGizmo$Style; - -
 method public,static forColorAndCentered (I)Lnet/minecraft/gizmos/TextGizmo$Style; - -
 method public,static forColor (I)Lnet/minecraft/gizmos/TextGizmo$Style; - -
 method public withScale (F)Lnet/minecraft/gizmos/TextGizmo$Style; - -
 method public withLeftAlignment (F)Lnet/minecraft/gizmos/TextGizmo$Style; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public color ()I - -
 method public scale ()F - -
 method public adjustLeft ()Ljava/util/OptionalDouble; - -
