cg-stub-db 1
in 326
class net/minecraft/command/AdvancementCommand 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/AdvancementCommand$Mode net/minecraft/command/AdvancementCommand Mode static,final,enum
 inner net/minecraft/command/AdvancementCommand$ActionType net/minecraft/command/AdvancementCommand ActionType static,abstract,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public,static findAdvancement (Lnet/minecraft/server/MinecraftServer;Ljava/lang/String;)Lnet/minecraft/advancements/Advancement; - net/minecraft/command/CommandException
in 326
class net/minecraft/command/AdvancementCommand$ActionType 52 super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/command/AdvancementCommand$ActionType;>;
 inner net/minecraft/command/AdvancementCommand$ActionType net/minecraft/command/AdvancementCommand ActionType static,abstract,enum
 field public,static,final,enum GRANT Lnet/minecraft/command/AdvancementCommand$ActionType; -
 field public,static,final,enum REVOKE Lnet/minecraft/command/AdvancementCommand$ActionType; -
 method public,static values ()[Lnet/minecraft/command/AdvancementCommand$ActionType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/command/AdvancementCommand$ActionType; - -
 method public perform (Lnet/minecraft/entity/player/EntityPlayerMP;Ljava/lang/Iterable;)I (Lnet/minecraft/entity/player/EntityPlayerMP;Ljava/lang/Iterable<Lnet/minecraft/advancements/Advancement;>;)I -
 method protected,abstract perform (Lnet/minecraft/entity/player/EntityPlayerMP;Lnet/minecraft/advancements/Advancement;)Z - -
 method protected,abstract performCriterion (Lnet/minecraft/entity/player/EntityPlayerMP;Lnet/minecraft/advancements/Advancement;Ljava/lang/String;)Z - -
in 326
class net/minecraft/command/AdvancementCommand$Mode 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/command/AdvancementCommand$Mode;>;
 inner net/minecraft/command/AdvancementCommand$Mode net/minecraft/command/AdvancementCommand Mode static,final,enum
 inner net/minecraft/command/AdvancementCommand$ActionType net/minecraft/command/AdvancementCommand ActionType static,abstract,enum
 field public,static,final,enum ONLY Lnet/minecraft/command/AdvancementCommand$Mode; -
 field public,static,final,enum THROUGH Lnet/minecraft/command/AdvancementCommand$Mode; -
 field public,static,final,enum FROM Lnet/minecraft/command/AdvancementCommand$Mode; -
 field public,static,final,enum UNTIL Lnet/minecraft/command/AdvancementCommand$Mode; -
 field public,static,final,enum EVERYTHING Lnet/minecraft/command/AdvancementCommand$Mode; -
 method public,static values ()[Lnet/minecraft/command/AdvancementCommand$Mode; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/command/AdvancementCommand$Mode; - -
in 90
class net/minecraft/command/CommandBase 50 public,super,abstract java/lang/Object net/minecraft/command/ICommand -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 method public <init> ()V - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static parseInt (Ljava/lang/String;)I - net/minecraft/command/NumberInvalidException
 method public,static parseInt (Ljava/lang/String;I)I - net/minecraft/command/NumberInvalidException
 method public,static parseInt (Ljava/lang/String;II)I - net/minecraft/command/NumberInvalidException
 method public,static parseLong (Ljava/lang/String;)J - net/minecraft/command/NumberInvalidException
 method public,static parseLong (Ljava/lang/String;JJ)J - net/minecraft/command/NumberInvalidException
 method public,static parseBlockPos (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;IZ)Lnet/minecraft/util/BlockPos; - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;D)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;DD)D - net/minecraft/command/NumberInvalidException
 method public,static parseBoolean (Ljava/lang/String;)Z - net/minecraft/command/CommandException
 method public,static getCommandSenderAsPlayer (Lnet/minecraft/command/ICommandSender;)Lnet/minecraft/entity/player/EntityPlayerMP; - net/minecraft/command/PlayerNotFoundException
 method public,static getPlayer (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayerMP; - net/minecraft/command/PlayerNotFoundException
 method public,static getEntity (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/Entity; - net/minecraft/command/EntityNotFoundException
 method public,static getEntity (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Lnet/minecraft/entity/Entity; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)TT; net/minecraft/command/EntityNotFoundException
 method public,static func_175763_c (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List<Lnet/minecraft/entity/Entity;>; net/minecraft/command/EntityNotFoundException
 method public,static getPlayerName (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/lang/String; - net/minecraft/command/PlayerNotFoundException
 method public,static getEntityName (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/lang/String; - net/minecraft/command/EntityNotFoundException
 method public,static getChatComponentFromNthArg (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)Lnet/minecraft/util/IChatComponent; - net/minecraft/command/CommandException,net/minecraft/command/PlayerNotFoundException
 method public,static getChatComponentFromNthArg (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;IZ)Lnet/minecraft/util/IChatComponent; - net/minecraft/command/PlayerNotFoundException
 method public,static buildString ([Ljava/lang/String;I)Ljava/lang/String; - -
 method public,static parseCoordinate (DLjava/lang/String;Z)Lnet/minecraft/command/CommandBase$CoordinateArg; - net/minecraft/command/NumberInvalidException
 method public,static parseCoordinate (DLjava/lang/String;IIZ)Lnet/minecraft/command/CommandBase$CoordinateArg; - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (DLjava/lang/String;Z)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (DLjava/lang/String;IIZ)D - net/minecraft/command/NumberInvalidException
 method public,static getItemByText (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/item/Item; - net/minecraft/command/NumberInvalidException
 method public,static getBlockByText (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/block/Block; - net/minecraft/command/NumberInvalidException
 method public,static joinNiceString ([Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static join (Ljava/util/List;)Lnet/minecraft/util/IChatComponent; (Ljava/util/List<Lnet/minecraft/util/IChatComponent;>;)Lnet/minecraft/util/IChatComponent; -
 method public,static joinNiceStringFromCollection (Ljava/util/Collection;)Ljava/lang/String; (Ljava/util/Collection<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,static func_175771_a ([Ljava/lang/String;ILnet/minecraft/util/BlockPos;)Ljava/util/List; ([Ljava/lang/String;ILnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static func_181043_b ([Ljava/lang/String;ILnet/minecraft/util/BlockPos;)Ljava/util/List; ([Ljava/lang/String;ILnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static doesStringStartWith (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static,varargs getListOfStringsMatchingLastWord ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List; ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getListOfStringsMatchingLastWord ([Ljava/lang/String;Ljava/util/Collection;)Ljava/util/List; ([Ljava/lang/String;Ljava/util/Collection<*>;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public,static,varargs notifyOperators (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs notifyOperators (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
 method public,static setAdminCommander (Lnet/minecraft/command/IAdminCommand;)V - -
 method public compareTo (Lnet/minecraft/command/ICommand;)I - -
in 91
class net/minecraft/command/CommandBase 50 public,super,abstract java/lang/Object net/minecraft/command/ICommand -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 method public <init> ()V - -
 method protected,static toSyntaxException (Lcom/google/gson/JsonParseException;)Lnet/minecraft/command/SyntaxErrorException; - -
 method protected,static entityToNBT (Lnet/minecraft/entity/Entity;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getRequiredPermissionLevel ()I - -
 method public getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static parseInt (Ljava/lang/String;)I - net/minecraft/command/NumberInvalidException
 method public,static parseInt (Ljava/lang/String;I)I - net/minecraft/command/NumberInvalidException
 method public,static parseInt (Ljava/lang/String;II)I - net/minecraft/command/NumberInvalidException
 method public,static parseLong (Ljava/lang/String;)J - net/minecraft/command/NumberInvalidException
 method public,static parseLong (Ljava/lang/String;JJ)J - net/minecraft/command/NumberInvalidException
 method public,static parseBlockPos (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;IZ)Lnet/minecraft/util/math/BlockPos; - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;D)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;DD)D - net/minecraft/command/NumberInvalidException
 method public,static parseBoolean (Ljava/lang/String;)Z - net/minecraft/command/CommandException
 method public,static getCommandSenderAsPlayer (Lnet/minecraft/command/ICommandSender;)Lnet/minecraft/entity/player/EntityPlayerMP; - net/minecraft/command/PlayerNotFoundException
 method public,static getPlayer (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayerMP; - net/minecraft/command/PlayerNotFoundException
 method public,static getEntity (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/Entity; - net/minecraft/command/EntityNotFoundException
 method public,static getEntity (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Lnet/minecraft/entity/Entity; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)TT; net/minecraft/command/EntityNotFoundException
 method public,static getEntityList (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List<Lnet/minecraft/entity/Entity;>; net/minecraft/command/EntityNotFoundException
 method public,static getPlayerName (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/lang/String; - net/minecraft/command/PlayerNotFoundException
 method public,static getEntityName (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/lang/String; - net/minecraft/command/EntityNotFoundException
 method public,static getChatComponentFromNthArg (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)Lnet/minecraft/util/text/ITextComponent; - net/minecraft/command/CommandException,net/minecraft/command/PlayerNotFoundException
 method public,static getChatComponentFromNthArg (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;IZ)Lnet/minecraft/util/text/ITextComponent; - net/minecraft/command/PlayerNotFoundException
 method public,static buildString ([Ljava/lang/String;I)Ljava/lang/String; - -
 method public,static parseCoordinate (DLjava/lang/String;Z)Lnet/minecraft/command/CommandBase$CoordinateArg; - net/minecraft/command/NumberInvalidException
 method public,static parseCoordinate (DLjava/lang/String;IIZ)Lnet/minecraft/command/CommandBase$CoordinateArg; - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (DLjava/lang/String;Z)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (DLjava/lang/String;IIZ)D - net/minecraft/command/NumberInvalidException
 method public,static getItemByText (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/item/Item; - net/minecraft/command/NumberInvalidException
 method public,static getBlockByText (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/block/Block; - net/minecraft/command/NumberInvalidException
 method public,static joinNiceString ([Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static join (Ljava/util/List;)Lnet/minecraft/util/text/ITextComponent; (Ljava/util/List<Lnet/minecraft/util/text/ITextComponent;>;)Lnet/minecraft/util/text/ITextComponent; -
 method public,static joinNiceStringFromCollection (Ljava/util/Collection;)Ljava/lang/String; (Ljava/util/Collection<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,static getTabCompletionCoordinate ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List; ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getTabCompletionCoordinateXZ ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List; ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static doesStringStartWith (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static,varargs getListOfStringsMatchingLastWord ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List; ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getListOfStringsMatchingLastWord ([Ljava/lang/String;Ljava/util/Collection;)Ljava/util/List; ([Ljava/lang/String;Ljava/util/Collection<*>;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public,static,varargs notifyCommandListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs notifyCommandListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
 method public,static setCommandListener (Lnet/minecraft/command/ICommandListener;)V - -
 method public compareTo (Lnet/minecraft/command/ICommand;)I - -
in 326
class net/minecraft/command/CommandBase 52 public,super,abstract java/lang/Object net/minecraft/command/ICommand -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method protected,static toSyntaxException (Lcom/google/gson/JsonParseException;)Lnet/minecraft/command/SyntaxErrorException; - -
 method public,static entityToNBT (Lnet/minecraft/entity/Entity;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getRequiredPermissionLevel ()I - -
 method public getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static parseInt (Ljava/lang/String;)I - net/minecraft/command/NumberInvalidException
 method public,static parseInt (Ljava/lang/String;I)I - net/minecraft/command/NumberInvalidException
 method public,static parseInt (Ljava/lang/String;II)I - net/minecraft/command/NumberInvalidException
 method public,static parseLong (Ljava/lang/String;)J - net/minecraft/command/NumberInvalidException
 method public,static parseLong (Ljava/lang/String;JJ)J - net/minecraft/command/NumberInvalidException
 method public,static parseBlockPos (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;IZ)Lnet/minecraft/util/math/BlockPos; - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;D)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (Ljava/lang/String;DD)D - net/minecraft/command/NumberInvalidException
 method public,static parseBoolean (Ljava/lang/String;)Z - net/minecraft/command/CommandException
 method public,static getCommandSenderAsPlayer (Lnet/minecraft/command/ICommandSender;)Lnet/minecraft/entity/player/EntityPlayerMP; - net/minecraft/command/PlayerNotFoundException
 method public,static getPlayers (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayerMP;>; net/minecraft/command/CommandException
 method public,static getPlayer (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayerMP; - net/minecraft/command/PlayerNotFoundException,net/minecraft/command/CommandException
 method public,static getEntity (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/Entity; - net/minecraft/command/EntityNotFoundException,net/minecraft/command/CommandException
 method public,static getEntity (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Lnet/minecraft/entity/Entity; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)TT; net/minecraft/command/EntityNotFoundException,net/minecraft/command/CommandException
 method public,static getEntityList (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List<Lnet/minecraft/entity/Entity;>; net/minecraft/command/EntityNotFoundException,net/minecraft/command/CommandException
 method public,static getPlayerName (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/lang/String; - net/minecraft/command/PlayerNotFoundException,net/minecraft/command/CommandException
 method public,static getEntityName (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/lang/String; - net/minecraft/command/EntityNotFoundException,net/minecraft/command/CommandException
 method public,static getChatComponentFromNthArg (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)Lnet/minecraft/util/text/ITextComponent; - net/minecraft/command/CommandException,net/minecraft/command/PlayerNotFoundException
 method public,static getChatComponentFromNthArg (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;IZ)Lnet/minecraft/util/text/ITextComponent; - net/minecraft/command/PlayerNotFoundException,net/minecraft/command/CommandException
 method public,static buildString ([Ljava/lang/String;I)Ljava/lang/String; - -
 method public,static parseCoordinate (DLjava/lang/String;Z)Lnet/minecraft/command/CommandBase$CoordinateArg; - net/minecraft/command/NumberInvalidException
 method public,static parseCoordinate (DLjava/lang/String;IIZ)Lnet/minecraft/command/CommandBase$CoordinateArg; - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (DLjava/lang/String;Z)D - net/minecraft/command/NumberInvalidException
 method public,static parseDouble (DLjava/lang/String;IIZ)D - net/minecraft/command/NumberInvalidException
 method public,static getItemByText (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/item/Item; - net/minecraft/command/NumberInvalidException
 method public,static getBlockByText (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/block/Block; - net/minecraft/command/NumberInvalidException
 method public,static convertArgToBlockState (Lnet/minecraft/block/Block;Ljava/lang/String;)Lnet/minecraft/block/state/IBlockState; - net/minecraft/command/NumberInvalidException,net/minecraft/command/InvalidBlockStateException
 method public,static convertArgToBlockStatePredicate (Lnet/minecraft/block/Block;Ljava/lang/String;)Lcom/google/common/base/Predicate; (Lnet/minecraft/block/Block;Ljava/lang/String;)Lcom/google/common/base/Predicate<Lnet/minecraft/block/state/IBlockState;>; net/minecraft/command/InvalidBlockStateException
 method public,static joinNiceString ([Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static join (Ljava/util/List;)Lnet/minecraft/util/text/ITextComponent; (Ljava/util/List<Lnet/minecraft/util/text/ITextComponent;>;)Lnet/minecraft/util/text/ITextComponent; -
 method public,static joinNiceStringFromCollection (Ljava/util/Collection;)Ljava/lang/String; (Ljava/util/Collection<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,static getTabCompletionCoordinate ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List; ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getTabCompletionCoordinateXZ ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List; ([Ljava/lang/String;ILnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static doesStringStartWith (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static,varargs getListOfStringsMatchingLastWord ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List; ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getListOfStringsMatchingLastWord ([Ljava/lang/String;Ljava/util/Collection;)Ljava/util/List; ([Ljava/lang/String;Ljava/util/Collection<*>;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public,static,varargs notifyCommandListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs notifyCommandListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
 method public,static setCommandListener (Lnet/minecraft/command/ICommandListener;)V - -
 method public compareTo (Lnet/minecraft/command/ICommand;)I - -
in 90
class net/minecraft/command/CommandBase$CoordinateArg 50 public,super java/lang/Object - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 method protected <init> (DDZ)V - -
 method public func_179628_a ()D - -
 method public func_179629_b ()D - -
 method public func_179630_c ()Z - -
in 91
class net/minecraft/command/CommandBase$CoordinateArg 50 public,super java/lang/Object - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 method protected <init> (DDZ)V - -
 method public getResult ()D - -
 method public getAmount ()D - -
 method public isRelative ()Z - -
in 326
class net/minecraft/command/CommandBase$CoordinateArg 52 public,super java/lang/Object - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 method protected <init> (DDZ)V - -
 method public getResult ()D - -
 method public getAmount ()D - -
 method public isRelative ()Z - -
in 90
class net/minecraft/command/CommandBlockData 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandBlockData 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandBlockData 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandClearInventory 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected func_147209_d ()[Ljava/lang/String; - -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandClearInventory 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandClearInventory 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandClone 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandClone$StaticCloneData net/minecraft/command/CommandClone StaticCloneData static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandClone 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandClone$StaticCloneData net/minecraft/command/CommandClone StaticCloneData static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandClone 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandClone$StaticCloneData net/minecraft/command/CommandClone StaticCloneData static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandClone$StaticCloneData 50 super java/lang/Object - -
 inner net/minecraft/command/CommandClone$StaticCloneData net/minecraft/command/CommandClone StaticCloneData static
 field public,final pos Lnet/minecraft/util/BlockPos; -
 field public,final blockState Lnet/minecraft/block/state/IBlockState; -
 field public,final compound Lnet/minecraft/nbt/NBTTagCompound; -
 method public <init> (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/command/CommandClone$StaticCloneData 50 super java/lang/Object - -
 inner net/minecraft/command/CommandClone$StaticCloneData net/minecraft/command/CommandClone StaticCloneData static
 field public,final pos Lnet/minecraft/util/math/BlockPos; -
 field public,final blockState Lnet/minecraft/block/state/IBlockState; -
 field public,final nbt Lnet/minecraft/nbt/NBTTagCompound; -
 method public <init> (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/command/CommandClone$StaticCloneData 52 super java/lang/Object - -
 inner net/minecraft/command/CommandClone$StaticCloneData net/minecraft/command/CommandClone StaticCloneData static
 field public,final pos Lnet/minecraft/util/math/BlockPos; -
 field public,final blockState Lnet/minecraft/block/state/IBlockState; -
 field public,final nbt Lnet/minecraft/nbt/NBTTagCompound; -
 method public <init> (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 90
class net/minecraft/command/CommandCompare 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/BlockPos$MutableBlockPos net/minecraft/util/BlockPos MutableBlockPos public,static,final
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandCompare 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandCompare 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandDebug 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandDebug 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandDebug 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandDefaultGameMode 50 public,super net/minecraft/command/CommandGameMode - -
 inner net/minecraft/world/WorldSettings$GameType net/minecraft/world/WorldSettings GameType public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected setGameType (Lnet/minecraft/world/WorldSettings$GameType;)V - -
in 91
class net/minecraft/command/CommandDefaultGameMode 50 public,super net/minecraft/command/CommandGameMode - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected setDefaultGameType (Lnet/minecraft/world/GameType;Lnet/minecraft/server/MinecraftServer;)V - -
in 326
class net/minecraft/command/CommandDefaultGameMode 52 public,super net/minecraft/command/CommandGameMode - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected setDefaultGameType (Lnet/minecraft/world/GameType;Lnet/minecraft/server/MinecraftServer;)V - -
in 90
class net/minecraft/command/CommandDifficulty 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getDifficultyFromCommand (Ljava/lang/String;)Lnet/minecraft/world/EnumDifficulty; - net/minecraft/command/NumberInvalidException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandDifficulty 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getDifficultyFromCommand (Ljava/lang/String;)Lnet/minecraft/world/EnumDifficulty; - net/minecraft/command/NumberInvalidException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandDifficulty 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getDifficultyFromCommand (Ljava/lang/String;)Lnet/minecraft/world/EnumDifficulty; - net/minecraft/command/NumberInvalidException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandEffect 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getAllUsernames ()[Ljava/lang/String; - -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandEffect 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandEffect 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandEnchant 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getListOfPlayers ()[Ljava/lang/String; - -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandEnchant 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandEnchant 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandEntityData 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandEntityData 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandEntityData 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 24
class net/minecraft/command/CommandException 50 public,super java/lang/Exception - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public getErrorObjects ()[Ljava/lang/Object; - -
in 326
class net/minecraft/command/CommandException 52 public,super java/lang/Exception - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public getErrorObjects ()[Ljava/lang/Object; - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 90
class net/minecraft/command/CommandExecuteAt 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandExecuteAt 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandExecuteAt 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandFill 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandFill 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandFill 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandFunction 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandGameMode 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/world/WorldSettings$GameType net/minecraft/world/WorldSettings GameType public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getGameModeFromCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/world/WorldSettings$GameType; - net/minecraft/command/NumberInvalidException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getListOfPlayerUsernames ()[Ljava/lang/String; - -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandGameMode 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getGameModeFromCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/world/GameType; - net/minecraft/command/NumberInvalidException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandGameMode 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getGameModeFromCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/world/GameType; - net/minecraft/command/NumberInvalidException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandGameRule 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraft/world/GameRules$ValueType net/minecraft/world/GameRules ValueType public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public,static func_175773_a (Lnet/minecraft/world/GameRules;Ljava/lang/String;)V - -
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandGameRule 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraft/world/GameRules$ValueType net/minecraft/world/GameRules ValueType public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public,static notifyGameRuleChange (Lnet/minecraft/world/GameRules;Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)V - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandGameRule 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraft/world/GameRules$ValueType net/minecraft/world/GameRules ValueType public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public,static notifyGameRuleChange (Lnet/minecraft/world/GameRules;Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)V - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandGive 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getPlayers ()[Ljava/lang/String; - -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandGive 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandGive 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandHandler 50 public,super java/lang/Object net/minecraft/command/ICommandManager -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public executeCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)I - -
 method protected tryExecute (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/command/ICommand;Ljava/lang/String;)Z - -
 method public registerCommand (Lnet/minecraft/command/ICommand;)Lnet/minecraft/command/ICommand; - -
 method public getTabCompletionOptions (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public getPossibleCommands (Lnet/minecraft/command/ICommandSender;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method public getCommands ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
in 91
class net/minecraft/command/CommandHandler 50 public,super,abstract java/lang/Object net/minecraft/command/ICommandManager -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public executeCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)I - -
 method protected tryExecute (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/command/ICommand;Ljava/lang/String;)Z - -
 method protected,abstract getServer ()Lnet/minecraft/server/MinecraftServer; - -
 method public registerCommand (Lnet/minecraft/command/ICommand;)Lnet/minecraft/command/ICommand; - -
 method public getTabCompletions (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public getPossibleCommands (Lnet/minecraft/command/ICommandSender;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method public getCommands ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
in 326
class net/minecraft/command/CommandHandler 52 public,super,abstract java/lang/Object net/minecraft/command/ICommandManager -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public executeCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)I - -
 method protected tryExecute (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/command/ICommand;Ljava/lang/String;)Z - -
 method protected,abstract getServer ()Lnet/minecraft/server/MinecraftServer; - -
 method public registerCommand (Lnet/minecraft/command/ICommand;)Lnet/minecraft/command/ICommand; - -
 method public getTabCompletions (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public getPossibleCommands (Lnet/minecraft/command/ICommandSender;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method public getCommands ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
in 90
class net/minecraft/command/CommandHelp 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/event/ClickEvent$Action net/minecraft/event/ClickEvent Action public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public getCommandAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getSortedPossibleCommands (Lnet/minecraft/command/ICommandSender;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method protected getCommands ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandHelp 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/text/event/ClickEvent$Action net/minecraft/util/text/event/ClickEvent Action public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getSortedPossibleCommands (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/server/MinecraftServer;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/server/MinecraftServer;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method protected getCommandMap (Lnet/minecraft/server/MinecraftServer;)Ljava/util/Map; (Lnet/minecraft/server/MinecraftServer;)Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandHelp 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/text/event/ClickEvent$Action net/minecraft/util/text/event/ClickEvent Action public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getSortedPossibleCommands (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/server/MinecraftServer;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/server/MinecraftServer;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method protected getCommandMap (Lnet/minecraft/server/MinecraftServer;)Ljava/util/Map; (Lnet/minecraft/server/MinecraftServer;)Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandKill 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandKill 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandKill 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandLocate 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 24
class net/minecraft/command/CommandNotFoundException 50 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 326
class net/minecraft/command/CommandNotFoundException 52 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 90
class net/minecraft/command/CommandParticle 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandParticle 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandParticle 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandPlaySound 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandPlaySound 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandPlaySound 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandReload 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/CommandReplaceItem 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getUsernames ()[Ljava/lang/String; - -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandReplaceItem 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandReplaceItem 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandResultStats 50 public,super java/lang/Object - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public setCommandStatScore (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public readStatsFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeStatsToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static setScoreBoardStat (Lnet/minecraft/command/CommandResultStats;Lnet/minecraft/command/CommandResultStats$Type;Ljava/lang/String;Ljava/lang/String;)V - -
 method public addAllStats (Lnet/minecraft/command/CommandResultStats;)V - -
in 91
class net/minecraft/command/CommandResultStats 50 public,super java/lang/Object - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public setCommandStatForSender (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public readStatsFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeStatsToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static setScoreBoardStat (Lnet/minecraft/command/CommandResultStats;Lnet/minecraft/command/CommandResultStats$Type;Ljava/lang/String;Ljava/lang/String;)V - -
 method public addAllStats (Lnet/minecraft/command/CommandResultStats;)V - -
in 326
class net/minecraft/command/CommandResultStats 52 public,super java/lang/Object - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public setCommandStatForSender (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public readStatsFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeStatsToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static setScoreBoardStat (Lnet/minecraft/command/CommandResultStats;Lnet/minecraft/command/CommandResultStats$Type;Ljava/lang/String;Ljava/lang/String;)V - -
 method public addAllStats (Lnet/minecraft/command/CommandResultStats;)V - -
in 24
class net/minecraft/command/CommandResultStats$Type 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/command/CommandResultStats$Type;>;
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 field public,static,final,enum SUCCESS_COUNT Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum AFFECTED_BLOCKS Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum AFFECTED_ENTITIES Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum AFFECTED_ITEMS Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum QUERY_RESULT Lnet/minecraft/command/CommandResultStats$Type; -
 method public,static values ()[Lnet/minecraft/command/CommandResultStats$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/command/CommandResultStats$Type; - -
 method public getTypeID ()I - -
 method public getTypeName ()Ljava/lang/String; - -
 method public,static getTypeNames ()[Ljava/lang/String; - -
 method public,static getTypeByName (Ljava/lang/String;)Lnet/minecraft/command/CommandResultStats$Type; - -
in 326
class net/minecraft/command/CommandResultStats$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/command/CommandResultStats$Type;>;
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 field public,static,final,enum SUCCESS_COUNT Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum AFFECTED_BLOCKS Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum AFFECTED_ENTITIES Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum AFFECTED_ITEMS Lnet/minecraft/command/CommandResultStats$Type; -
 field public,static,final,enum QUERY_RESULT Lnet/minecraft/command/CommandResultStats$Type; -
 method public,static values ()[Lnet/minecraft/command/CommandResultStats$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/command/CommandResultStats$Type; - -
 method public getTypeID ()I - -
 method public getTypeName ()Ljava/lang/String; - -
 method public,static getTypeNames ()[Ljava/lang/String; - -
 method public,static getTypeByName (Ljava/lang/String;)Lnet/minecraft/command/CommandResultStats$Type; - -
in 326
class net/minecraft/command/CommandSenderWrapper 52 public,super java/lang/Object net/minecraft/command/ICommandSender -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/BlockPos;Ljava/lang/Integer;Lnet/minecraft/entity/Entity;Ljava/lang/Boolean;)V - -
 method public,static create (Lnet/minecraft/command/ICommandSender;)Lnet/minecraft/command/CommandSenderWrapper; - -
 method public withEntity (Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/command/CommandSenderWrapper; - -
 method public withPermissionLevel (I)Lnet/minecraft/command/CommandSenderWrapper; - -
 method public withSendCommandFeedback (Z)Lnet/minecraft/command/CommandSenderWrapper; - -
 method public computePositionVector ()Lnet/minecraft/command/CommandSenderWrapper; - -
 method public getName ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public canUseCommand (ILjava/lang/String;)Z - -
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getPositionVector ()Lnet/minecraft/util/math/Vec3d; - -
 method public getEntityWorld ()Lnet/minecraft/world/World; - -
 method public getCommandSenderEntity ()Lnet/minecraft/entity/Entity; - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public getServer ()Lnet/minecraft/server/MinecraftServer; - -
in 90
class net/minecraft/command/CommandServerKick 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandServerKick 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandServerKick 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandSetPlayerTimeout 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/CommandSetPlayerTimeout 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/CommandSetPlayerTimeout 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/CommandSetSpawnpoint 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandSetSpawnpoint 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandSetSpawnpoint 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandShowSeed 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/CommandShowSeed 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/CommandShowSeed 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/CommandSpreadPlayers 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandSpreadPlayers$Position net/minecraft/command/CommandSpreadPlayers Position static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandSpreadPlayers 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandSpreadPlayers$Position net/minecraft/command/CommandSpreadPlayers Position static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandSpreadPlayers 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandSpreadPlayers$Position net/minecraft/command/CommandSpreadPlayers Position static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandSpreadPlayers$Position 50 super java/lang/Object - -
 inner net/minecraft/command/CommandSpreadPlayers$Position net/minecraft/command/CommandSpreadPlayers Position static
 method public func_111094_b (Lnet/minecraft/command/CommandSpreadPlayers$Position;)V - -
 method public func_111093_a (DDDD)Z - -
 method public func_111092_a (Lnet/minecraft/world/World;)I - -
 method public func_111098_b (Lnet/minecraft/world/World;)Z - -
 method public func_111097_a (Ljava/util/Random;DDDD)V - -
in 91
class net/minecraft/command/CommandSpreadPlayers$Position 50 super java/lang/Object - -
 inner net/minecraft/command/CommandSpreadPlayers$Position net/minecraft/command/CommandSpreadPlayers Position static
 method public moveAway (Lnet/minecraft/command/CommandSpreadPlayers$Position;)V - -
 method public clamp (DDDD)Z - -
 method public getSpawnY (Lnet/minecraft/world/World;)I - -
 method public isSafe (Lnet/minecraft/world/World;)Z - -
 method public randomize (Ljava/util/Random;DDDD)V - -
in 326
class net/minecraft/command/CommandSpreadPlayers$Position 52 super java/lang/Object - -
 inner net/minecraft/command/CommandSpreadPlayers$Position net/minecraft/command/CommandSpreadPlayers Position static
 method public moveAway (Lnet/minecraft/command/CommandSpreadPlayers$Position;)V - -
 method public clamp (DDDD)Z - -
 method public getSpawnY (Lnet/minecraft/world/World;)I - -
 method public isSafe (Lnet/minecraft/world/World;)Z - -
 method public randomize (Ljava/util/Random;DDDD)V - -
in 90
class net/minecraft/command/CommandStats 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected func_175776_d ()[Ljava/lang/String; - -
 method protected func_175777_e ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandStats 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getObjectiveNames (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandStats 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getObjectiveNames (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandStopSound 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandStopSound 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandTP 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 inner net/minecraft/network/play/server/SPacketPlayerPosLook$EnumFlags net/minecraft/network/play/server/SPacketPlayerPosLook EnumFlags public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandTP 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 inner net/minecraft/network/play/server/SPacketPlayerPosLook$EnumFlags net/minecraft/network/play/server/SPacketPlayerPosLook EnumFlags public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandTime 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected setTime (Lnet/minecraft/command/ICommandSender;I)V - -
 method protected addTime (Lnet/minecraft/command/ICommandSender;I)V - -
in 91
class net/minecraft/command/CommandTime 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected setAllWorldTimes (Lnet/minecraft/server/MinecraftServer;I)V - -
 method protected incrementAllWorldTimes (Lnet/minecraft/server/MinecraftServer;I)V - -
in 326
class net/minecraft/command/CommandTime 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected setAllWorldTimes (Lnet/minecraft/server/MinecraftServer;I)V - -
 method protected incrementAllWorldTimes (Lnet/minecraft/server/MinecraftServer;I)V - -
in 90
class net/minecraft/command/CommandTitle 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/network/play/server/S45PacketTitle$Type net/minecraft/network/play/server/S45PacketTitle Type public,static,final,enum
 inner net/minecraft/util/IChatComponent$Serializer net/minecraft/util/IChatComponent Serializer public,static
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandTitle 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/network/play/server/SPacketTitle$Type net/minecraft/network/play/server/SPacketTitle Type public,static,final,enum
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandTitle 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/network/play/server/SPacketTitle$Type net/minecraft/network/play/server/SPacketTitle Type public,static,final,enum
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/CommandToggleDownfall 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected toggleDownfall ()V - -
in 91
class net/minecraft/command/CommandToggleDownfall 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected toggleRainfall (Lnet/minecraft/server/MinecraftServer;)V - -
in 326
class net/minecraft/command/CommandToggleDownfall 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected toggleRainfall (Lnet/minecraft/server/MinecraftServer;)V - -
in 90
class net/minecraft/command/CommandTrigger 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandTrigger 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandTrigger 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandWeather 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandWeather 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandWeather 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandWorldBorder 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getWorldBorder ()Lnet/minecraft/world/border/WorldBorder; - -
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/CommandWorldBorder 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getWorldBorder (Lnet/minecraft/server/MinecraftServer;)Lnet/minecraft/world/border/WorldBorder; - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/CommandWorldBorder 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getWorldBorder (Lnet/minecraft/server/MinecraftServer;)Lnet/minecraft/world/border/WorldBorder; - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/CommandXP 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getAllUsernames ()[Ljava/lang/String; - -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/CommandXP 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/CommandXP 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 24
class net/minecraft/command/EntityNotFoundException 50 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 326
class net/minecraft/command/EntityNotFoundException 52 public,super net/minecraft/command/CommandException - -
 method public <init> (Ljava/lang/String;)V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 91
class net/minecraft/command/EntitySelector 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static matchOnePlayer (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayerMP; - -
 method public,static matchOneEntity (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Lnet/minecraft/entity/Entity; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)TT; -
 method public,static matchEntitiesToTextComponent (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/util/text/ITextComponent; - -
 method public,static matchEntities (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/List; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)Ljava/util/List<TT;>; -
 method public,static getScoreMap (Ljava/util/Map;)Ljava/util/Map; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>; -
 method public,static matchesMultiplePlayers (Ljava/lang/String;)Z - -
 method public,static hasArguments (Ljava/lang/String;)Z - -
in 326
class net/minecraft/command/EntitySelector 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static addArgument (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static matchOnePlayer (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayerMP; - net/minecraft/command/CommandException
 method public,static getPlayers (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayerMP;>; net/minecraft/command/CommandException
 method public,static matchOneEntity (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Lnet/minecraft/entity/Entity; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)TT; net/minecraft/command/CommandException
 method public,static matchEntitiesToTextComponent (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/util/text/ITextComponent; - net/minecraft/command/CommandException
 method public,static matchEntities (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/List; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)Ljava/util/List<TT;>; net/minecraft/command/CommandException
 method public,static matchEntitiesDefault (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/List; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)Ljava/util/List<TT;>; net/minecraft/command/CommandException
 method public,static getScoreMap (Ljava/util/Map;)Ljava/util/Map; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>; -
 method public,static matchesMultiplePlayers (Ljava/lang/String;)Z - net/minecraft/command/CommandException
 method public,static matchesMultiplePlayersDefault (Ljava/lang/String;)Z - net/minecraft/command/CommandException
 method public,static isSelector (Ljava/lang/String;)Z - -
 method public,static isSelectorDefault (Ljava/lang/String;)Z - -
in 326
class net/minecraft/command/FunctionObject 52 public,super java/lang/Object - -
 inner net/minecraft/command/FunctionObject$CacheableFunction net/minecraft/command/FunctionObject CacheableFunction public,static
 inner net/minecraft/command/FunctionObject$FunctionEntry net/minecraft/command/FunctionObject FunctionEntry public,static
 inner net/minecraft/command/FunctionObject$CommandEntry net/minecraft/command/FunctionObject CommandEntry public,static
 inner net/minecraft/command/FunctionObject$Entry net/minecraft/command/FunctionObject Entry public,static,interface,abstract
 method public <init> ([Lnet/minecraft/command/FunctionObject$Entry;)V - -
 method public getEntries ()[Lnet/minecraft/command/FunctionObject$Entry; - -
 method public,static create (Lnet/minecraft/advancements/FunctionManager;Ljava/util/List;)Lnet/minecraft/command/FunctionObject; (Lnet/minecraft/advancements/FunctionManager;Ljava/util/List<Ljava/lang/String;>;)Lnet/minecraft/command/FunctionObject; -
in 326
class net/minecraft/command/FunctionObject$CacheableFunction 52 public,super java/lang/Object - -
 inner net/minecraft/command/FunctionObject$CacheableFunction net/minecraft/command/FunctionObject CacheableFunction public,static
 field public,static,final EMPTY Lnet/minecraft/command/FunctionObject$CacheableFunction; -
 method public <init> (Lnet/minecraft/util/ResourceLocation;)V - -
 method public <init> (Lnet/minecraft/command/FunctionObject;)V - -
 method public get (Lnet/minecraft/advancements/FunctionManager;)Lnet/minecraft/command/FunctionObject; - -
 method public toString ()Ljava/lang/String; - -
in 326
class net/minecraft/command/FunctionObject$CommandEntry 52 public,super java/lang/Object net/minecraft/command/FunctionObject$Entry -
 inner net/minecraft/command/FunctionObject$CommandEntry net/minecraft/command/FunctionObject CommandEntry public,static
 inner net/minecraft/advancements/FunctionManager$QueuedCommand net/minecraft/advancements/FunctionManager QueuedCommand public,static
 inner net/minecraft/command/FunctionObject$Entry net/minecraft/command/FunctionObject Entry public,static,interface,abstract
 method public <init> (Ljava/lang/String;)V - -
 method public execute (Lnet/minecraft/advancements/FunctionManager;Lnet/minecraft/command/ICommandSender;Ljava/util/ArrayDeque;I)V (Lnet/minecraft/advancements/FunctionManager;Lnet/minecraft/command/ICommandSender;Ljava/util/ArrayDeque<Lnet/minecraft/advancements/FunctionManager$QueuedCommand;>;I)V -
 method public toString ()Ljava/lang/String; - -
in 326
class net/minecraft/command/FunctionObject$Entry 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/advancements/FunctionManager$QueuedCommand net/minecraft/advancements/FunctionManager QueuedCommand public,static
 inner net/minecraft/command/FunctionObject$Entry net/minecraft/command/FunctionObject Entry public,static,interface,abstract
 method public,abstract execute (Lnet/minecraft/advancements/FunctionManager;Lnet/minecraft/command/ICommandSender;Ljava/util/ArrayDeque;I)V (Lnet/minecraft/advancements/FunctionManager;Lnet/minecraft/command/ICommandSender;Ljava/util/ArrayDeque<Lnet/minecraft/advancements/FunctionManager$QueuedCommand;>;I)V -
in 326
class net/minecraft/command/FunctionObject$FunctionEntry 52 public,super java/lang/Object net/minecraft/command/FunctionObject$Entry -
 inner net/minecraft/command/FunctionObject$CacheableFunction net/minecraft/command/FunctionObject CacheableFunction public,static
 inner net/minecraft/command/FunctionObject$FunctionEntry net/minecraft/command/FunctionObject FunctionEntry public,static
 inner net/minecraft/command/FunctionObject$Entry net/minecraft/command/FunctionObject Entry public,static,interface,abstract
 inner net/minecraft/advancements/FunctionManager$QueuedCommand net/minecraft/advancements/FunctionManager QueuedCommand public,static
 method public <init> (Lnet/minecraft/command/FunctionObject;)V - -
 method public execute (Lnet/minecraft/advancements/FunctionManager;Lnet/minecraft/command/ICommandSender;Ljava/util/ArrayDeque;I)V (Lnet/minecraft/advancements/FunctionManager;Lnet/minecraft/command/ICommandSender;Ljava/util/ArrayDeque<Lnet/minecraft/advancements/FunctionManager$QueuedCommand;>;I)V -
 method public toString ()Ljava/lang/String; - -
in 90
class net/minecraft/command/IAdminCommand 50 public,interface,abstract java/lang/Object - -
 method public,varargs,abstract notifyOperators (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
in 90
class net/minecraft/command/ICommand 50 public,interface,abstract java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/command/ICommand;>;
 method public,abstract getCommandName ()Ljava/lang/String; - -
 method public,abstract getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public,abstract getCommandAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public,abstract canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public,abstract addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/ICommand 50 public,interface,abstract java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/command/ICommand;>;
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public,abstract getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public,abstract checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public,abstract getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/ICommand 52 public,interface,abstract java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/command/ICommand;>;
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public,abstract getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public,abstract checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public,abstract getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/ICommandListener 50 public,interface,abstract java/lang/Object - -
 method public,varargs,abstract notifyListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
in 326
class net/minecraft/command/ICommandListener 52 public,interface,abstract java/lang/Object - -
 method public,varargs,abstract notifyListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
in 90
class net/minecraft/command/ICommandManager 50 public,interface,abstract java/lang/Object - -
 method public,abstract executeCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)I - -
 method public,abstract getTabCompletionOptions (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract getPossibleCommands (Lnet/minecraft/command/ICommandSender;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method public,abstract getCommands ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
in 91
class net/minecraft/command/ICommandManager 50 public,interface,abstract java/lang/Object - -
 method public,abstract executeCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)I - -
 method public,abstract getTabCompletions (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract getPossibleCommands (Lnet/minecraft/command/ICommandSender;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method public,abstract getCommands ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
in 326
class net/minecraft/command/ICommandManager 52 public,interface,abstract java/lang/Object - -
 method public,abstract executeCommand (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)I - -
 method public,abstract getTabCompletions (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract getPossibleCommands (Lnet/minecraft/command/ICommandSender;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;)Ljava/util/List<Lnet/minecraft/command/ICommand;>; -
 method public,abstract getCommands ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/command/ICommand;>; -
in 90
class net/minecraft/command/ICommandSender 50 public,interface,abstract java/lang/Object - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public,abstract addChatMessage (Lnet/minecraft/util/IChatComponent;)V - -
 method public,abstract canCommandSenderUseCommand (ILjava/lang/String;)Z - -
 method public,abstract getPosition ()Lnet/minecraft/util/BlockPos; - -
 method public,abstract getPositionVector ()Lnet/minecraft/util/Vec3; - -
 method public,abstract getEntityWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getCommandSenderEntity ()Lnet/minecraft/entity/Entity; - -
 method public,abstract sendCommandFeedback ()Z - -
 method public,abstract setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
in 91
class net/minecraft/command/ICommandSender 50 public,interface,abstract java/lang/Object - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public,abstract sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public,abstract canUseCommand (ILjava/lang/String;)Z - -
 method public,abstract getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public,abstract getPositionVector ()Lnet/minecraft/util/math/Vec3d; - -
 method public,abstract getEntityWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getCommandSenderEntity ()Lnet/minecraft/entity/Entity; - -
 method public,abstract sendCommandFeedback ()Z - -
 method public,abstract setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public,abstract getServer ()Lnet/minecraft/server/MinecraftServer; - -
in 326
class net/minecraft/command/ICommandSender 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public,abstract canUseCommand (ILjava/lang/String;)Z - -
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getPositionVector ()Lnet/minecraft/util/math/Vec3d; - -
 method public,abstract getEntityWorld ()Lnet/minecraft/world/World; - -
 method public getCommandSenderEntity ()Lnet/minecraft/entity/Entity; - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public,abstract getServer ()Lnet/minecraft/server/MinecraftServer; - -
in 326
class net/minecraft/command/InvalidBlockStateException 52 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 24
class net/minecraft/command/NumberInvalidException 50 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 326
class net/minecraft/command/NumberInvalidException 52 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 24
class net/minecraft/command/PlayerNotFoundException 50 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 326
class net/minecraft/command/PlayerNotFoundException 52 public,super net/minecraft/command/CommandException - -
 method public <init> (Ljava/lang/String;)V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 90
class net/minecraft/command/PlayerSelector 50 public,super java/lang/Object - -
 inner net/minecraft/world/WorldSettings$GameType net/minecraft/world/WorldSettings GameType public,static,final,enum
 method public <init> ()V - -
 method public,static matchOnePlayer (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayerMP; - -
 method public,static matchOneEntity (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Lnet/minecraft/entity/Entity; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)TT; -
 method public,static matchEntitiesToChatComponent (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)Lnet/minecraft/util/IChatComponent; - -
 method public,static matchEntities (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class;)Ljava/util/List; <T:Lnet/minecraft/entity/Entity;>(Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/Class<+TT;>;)Ljava/util/List<TT;>; -
 method public,static func_179650_a (I)I - -
 method public,static func_96560_a (Ljava/util/Map;)Ljava/util/Map; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>; -
 method public,static matchesMultiplePlayers (Ljava/lang/String;)Z - -
 method public,static hasArguments (Ljava/lang/String;)Z - -
in 326
class net/minecraft/command/RecipeCommand 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/ServerCommand 50 public,super java/lang/Object - -
 field public,final command Ljava/lang/String; -
 field public,final sender Lnet/minecraft/command/ICommandSender; -
 method public <init> (Ljava/lang/String;Lnet/minecraft/command/ICommandSender;)V - -
in 90
class net/minecraft/command/ServerCommandManager 50 public,super net/minecraft/command/CommandHandler net/minecraft/command/IAdminCommand -
 method public <init> ()V - -
 method public,varargs notifyOperators (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
in 91
class net/minecraft/command/ServerCommandManager 50 public,super net/minecraft/command/CommandHandler net/minecraft/command/ICommandListener -
 method public <init> (Lnet/minecraft/server/MinecraftServer;)V - -
 method public,varargs notifyListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
 method protected getServer ()Lnet/minecraft/server/MinecraftServer; - -
in 326
class net/minecraft/command/ServerCommandManager 52 public,super net/minecraft/command/CommandHandler net/minecraft/command/ICommandListener -
 method public <init> (Lnet/minecraft/server/MinecraftServer;)V - -
 method public,varargs notifyListener (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/command/ICommand;ILjava/lang/String;[Ljava/lang/Object;)V - -
 method protected getServer ()Lnet/minecraft/server/MinecraftServer; - -
in 24
class net/minecraft/command/SyntaxErrorException 50 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 326
class net/minecraft/command/SyntaxErrorException 52 public,super net/minecraft/command/CommandException - -
 method public <init> ()V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 24
class net/minecraft/command/WrongUsageException 50 public,super net/minecraft/command/SyntaxErrorException - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 326
class net/minecraft/command/WrongUsageException 52 public,super net/minecraft/command/SyntaxErrorException - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,synchronized fillInStackTrace ()Ljava/lang/Throwable; - -
in 90
class net/minecraft/command/server/CommandAchievement 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/server/CommandAchievement 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/server/CommandBanIp 50 public,super net/minecraft/command/CommandBase - -
 field public,static,final field_147211_a Ljava/util/regex/Pattern; -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected func_147210_a (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/String;)V - -
in 91
class net/minecraft/command/server/CommandBanIp 50 public,super net/minecraft/command/CommandBase - -
 field public,static,final IP_PATTERN Ljava/util/regex/Pattern; -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected banIp (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/String;)V - -
in 326
class net/minecraft/command/server/CommandBanIp 52 public,super net/minecraft/command/CommandBase - -
 field public,static,final IP_PATTERN Ljava/util/regex/Pattern; -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected banIp (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Ljava/lang/String;)V - -
in 90
class net/minecraft/command/server/CommandBanPlayer 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandBanPlayer 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandBanPlayer 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandBlockLogic 50 public,super,abstract java/lang/Object net/minecraft/command/ICommandSender -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraft/util/IChatComponent$Serializer net/minecraft/util/IChatComponent Serializer public,static
 method public,abstract func_145751_f ()I - -
 method public,abstract func_145757_a (Lio/netty/buffer/ByteBuf;)V - -
 method public <init> ()V - -
 method public getSuccessCount ()I - -
 method public getLastOutput ()Lnet/minecraft/util/IChatComponent; - -
 method public writeDataToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readDataFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canCommandSenderUseCommand (ILjava/lang/String;)Z - -
 method public setCommand (Ljava/lang/String;)V - -
 method public getCommand ()Ljava/lang/String; - -
 method public trigger (Lnet/minecraft/world/World;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public setName (Ljava/lang/String;)V - -
 method public addChatMessage (Lnet/minecraft/util/IChatComponent;)V - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public,abstract updateCommand ()V - -
 method public setLastOutput (Lnet/minecraft/util/IChatComponent;)V - -
 method public setTrackOutput (Z)V - -
 method public shouldTrackOutput ()Z - -
 method public tryOpenEditCommandBlock (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getCommandResultStats ()Lnet/minecraft/command/CommandResultStats; - -
in 90
class net/minecraft/command/server/CommandBroadcast 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandBroadcast 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandBroadcast 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandDeOp 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandDeOp 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandDeOp 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandEmote 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandEmote 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandEmote 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandListBans 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandListBans 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandListBans 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandListPlayers 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/server/CommandListPlayers 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/server/CommandListPlayers 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/server/CommandMessage 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/server/CommandMessage 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/server/CommandMessage 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getAliases ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/server/CommandMessageRaw 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/IChatComponent$Serializer net/minecraft/util/IChatComponent Serializer public,static
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/server/CommandMessageRaw 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/server/CommandMessageRaw 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/server/CommandOp 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandOp 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandOp 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandPardonIp 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandPardonIp 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandPardonIp 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandPardonPlayer 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public canCommandSenderUseCommand (Lnet/minecraft/command/ICommandSender;)Z - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandPardonPlayer 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandPardonPlayer 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public checkPermission (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;)Z - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandPublishLocalServer 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/world/WorldSettings$GameType net/minecraft/world/WorldSettings GameType public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/server/CommandPublishLocalServer 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/server/CommandPublishLocalServer 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/server/CommandSaveAll 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/server/CommandSaveAll 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/server/CommandSaveAll 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandSaveOff 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/server/CommandSaveOff 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/server/CommandSaveOff 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/server/CommandSaveOn 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/server/CommandSaveOn 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/server/CommandSaveOn 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/server/CommandScoreboard 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method protected getObjective (Ljava/lang/String;Z)Lnet/minecraft/scoreboard/ScoreObjective; - net/minecraft/command/CommandException
 method protected getTeam (Ljava/lang/String;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - net/minecraft/command/CommandException
 method protected addObjective (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected addTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected setTeamOption (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected removeTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected listTeams (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected joinTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected leaveTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected emptyTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected removeObjective (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected listObjectives (Lnet/minecraft/command/ICommandSender;)V - net/minecraft/command/CommandException
 method protected setObjectiveDisplay (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected listPlayers (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected setPlayer (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected resetPlayers (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected func_175779_n (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected func_175781_o (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method protected func_175778_p (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected func_147184_a (Z)Ljava/util/List; (Z)Ljava/util/List<Ljava/lang/String;>; -
 method protected func_175782_e ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/server/CommandScoreboard 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getScoreboard (Lnet/minecraft/server/MinecraftServer;)Lnet/minecraft/scoreboard/Scoreboard; - -
 method protected convertToObjective (Ljava/lang/String;ZLnet/minecraft/server/MinecraftServer;)Lnet/minecraft/scoreboard/ScoreObjective; - net/minecraft/command/CommandException
 method protected convertToTeam (Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - net/minecraft/command/CommandException
 method protected addObjective (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected addTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected setTeamOption (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected removeTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected listTeams (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected joinTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected leaveTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected emptyTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected removeObjective (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected listObjectives (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected setDisplayObjective (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected listPlayers (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected addPlayerScore (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected resetPlayerScore (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected enablePlayerTrigger (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected testPlayerScore (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected applyPlayerOperation (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected applyPlayerTag (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getObjectiveNames (ZLnet/minecraft/server/MinecraftServer;)Ljava/util/List; (ZLnet/minecraft/server/MinecraftServer;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getTriggerNames (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/server/CommandScoreboard 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 inner net/minecraft/scoreboard/Team$CollisionRule net/minecraft/scoreboard/Team CollisionRule public,static,final,enum
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method protected getScoreboard (Lnet/minecraft/server/MinecraftServer;)Lnet/minecraft/scoreboard/Scoreboard; - -
 method protected convertToObjective (Ljava/lang/String;ZLnet/minecraft/server/MinecraftServer;)Lnet/minecraft/scoreboard/ScoreObjective; - net/minecraft/command/CommandException
 method protected convertToTeam (Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)Lnet/minecraft/scoreboard/ScorePlayerTeam; - net/minecraft/command/CommandException
 method protected addObjective (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected addTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected setTeamOption (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected removeTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected listTeams (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected joinTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected leaveTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected emptyTeam (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected removeObjective (Lnet/minecraft/command/ICommandSender;Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected listObjectives (Lnet/minecraft/command/ICommandSender;Lnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected setDisplayObjective (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected listPlayers (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected addPlayerScore (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected resetPlayerScore (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected enablePlayerTrigger (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected testPlayerScore (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected applyPlayerOperation (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;ILnet/minecraft/server/MinecraftServer;)V - net/minecraft/command/CommandException
 method protected applyPlayerTag (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;I)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getObjectiveNames (ZLnet/minecraft/server/MinecraftServer;)Ljava/util/List; (ZLnet/minecraft/server/MinecraftServer;)Ljava/util/List<Ljava/lang/String;>; -
 method protected getTriggerNames (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/server/CommandSetBlock 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandSetBlock 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandSetBlock 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandSetDefaultSpawnpoint 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandSetDefaultSpawnpoint 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandSetDefaultSpawnpoint 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandStop 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 91
class net/minecraft/command/server/CommandStop 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 326
class net/minecraft/command/server/CommandStop 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
in 90
class net/minecraft/command/server/CommandSummon 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandSummon 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandSummon 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandTeleport 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 inner net/minecraft/network/play/server/S08PacketPlayerPosLook$EnumFlags net/minecraft/network/play/server/S08PacketPlayerPosLook EnumFlags public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 91
class net/minecraft/command/server/CommandTeleport 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 inner net/minecraft/network/play/server/SPacketPlayerPosLook$EnumFlags net/minecraft/network/play/server/SPacketPlayerPosLook EnumFlags public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 326
class net/minecraft/command/server/CommandTeleport 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandBase$CoordinateArg net/minecraft/command/CommandBase CoordinateArg public,static
 inner net/minecraft/network/play/server/SPacketPlayerPosLook$EnumFlags net/minecraft/network/play/server/SPacketPlayerPosLook EnumFlags public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
in 90
class net/minecraft/command/server/CommandTestFor 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandTestFor 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandTestFor 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public isUsernameIndex ([Ljava/lang/String;I)Z - -
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandTestForBlock 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandTestForBlock 50 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandTestForBlock 52 public,super net/minecraft/command/CommandBase - -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 90
class net/minecraft/command/server/CommandWhitelist 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getCommandName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getCommandUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public processCommand (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public addTabCompletionOptions (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List; (Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 91
class net/minecraft/command/server/CommandWhitelist 50 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
in 326
class net/minecraft/command/server/CommandWhitelist 52 public,super net/minecraft/command/CommandBase - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getRequiredPermissionLevel ()I - -
 method public getUsage (Lnet/minecraft/command/ICommandSender;)Ljava/lang/String; - -
 method public execute (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;)V - net/minecraft/command/CommandException
 method public getTabCompletions (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List; (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/command/ICommandSender;[Ljava/lang/String;Lnet/minecraft/util/math/BlockPos;)Ljava/util/List<Ljava/lang/String;>; -
