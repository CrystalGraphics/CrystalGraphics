cg-stub-db 1
in 86
class net/minecraft/resources/DelegatingOps 52 public,super,abstract java/lang/Object com/mojang/serialization/DynamicOps <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<TT;>;
 field protected,final delegate Lcom/mojang/serialization/DynamicOps; Lcom/mojang/serialization/DynamicOps<TT;>;
 method protected <init> (Lcom/mojang/serialization/DynamicOps;)V (Lcom/mojang/serialization/DynamicOps<TT;>;)V -
 method public empty ()Ljava/lang/Object; ()TT; -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;TT;)TU; -
 method public getNumberValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Ljava/lang/Object; (Ljava/lang/Number;)TT; -
 method public createByte (B)Ljava/lang/Object; (B)TT; -
 method public createShort (S)Ljava/lang/Object; (S)TT; -
 method public createInt (I)Ljava/lang/Object; (I)TT; -
 method public createLong (J)Ljava/lang/Object; (J)TT; -
 method public createFloat (F)Ljava/lang/Object; (F)TT; -
 method public createDouble (D)Ljava/lang/Object; (D)TT; -
 method public getBooleanValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Boolean;>; -
 method public createBoolean (Z)Ljava/lang/Object; (Z)TT; -
 method public getStringValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TT; -
 method public mergeToList (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToList (Ljava/lang/Object;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (TT;Ljava/util/List<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (TT;Lcom/mojang/serialization/MapLike<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public getMapValues (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;>; -
 method public getMapEntries (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<TT;TT;>;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;)TT; -
 method public getMap (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<TT;>;>; -
 method public getStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<TT;>;>; -
 method public getList (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<TT;>;>;>; -
 method public createList (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<TT;>;)TT; -
 method public getByteBuffer (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Ljava/lang/Object; (Ljava/nio/ByteBuffer;)TT; -
 method public getIntStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Ljava/lang/Object; (Ljava/util/stream/IntStream;)TT; -
 method public getLongStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Ljava/lang/Object; (Ljava/util/stream/LongStream;)TT; -
 method public remove (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object; (TT;Ljava/lang/String;)TT; -
 method public compressMaps ()Z - -
 method public listBuilder ()Lcom/mojang/serialization/ListBuilder; ()Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<TT;>; -
in 82
class net/minecraft/resources/DelegatingOps 60 public,super,abstract java/lang/Object com/mojang/serialization/DynamicOps <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<TT;>;
 field protected,final delegate Lcom/mojang/serialization/DynamicOps; Lcom/mojang/serialization/DynamicOps<TT;>;
 method protected <init> (Lcom/mojang/serialization/DynamicOps;)V (Lcom/mojang/serialization/DynamicOps<TT;>;)V -
 method public empty ()Ljava/lang/Object; ()TT; -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;TT;)TU; -
 method public getNumberValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Ljava/lang/Object; (Ljava/lang/Number;)TT; -
 method public createByte (B)Ljava/lang/Object; (B)TT; -
 method public createShort (S)Ljava/lang/Object; (S)TT; -
 method public createInt (I)Ljava/lang/Object; (I)TT; -
 method public createLong (J)Ljava/lang/Object; (J)TT; -
 method public createFloat (F)Ljava/lang/Object; (F)TT; -
 method public createDouble (D)Ljava/lang/Object; (D)TT; -
 method public getBooleanValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Boolean;>; -
 method public createBoolean (Z)Ljava/lang/Object; (Z)TT; -
 method public getStringValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TT; -
 method public mergeToList (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToList (Ljava/lang/Object;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (TT;Ljava/util/List<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (TT;Lcom/mojang/serialization/MapLike<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public getMapValues (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;>; -
 method public getMapEntries (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<TT;TT;>;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;)TT; -
 method public getMap (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<TT;>;>; -
 method public getStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<TT;>;>; -
 method public getList (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<TT;>;>;>; -
 method public createList (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<TT;>;)TT; -
 method public getByteBuffer (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Ljava/lang/Object; (Ljava/nio/ByteBuffer;)TT; -
 method public getIntStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Ljava/lang/Object; (Ljava/util/stream/IntStream;)TT; -
 method public getLongStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Ljava/lang/Object; (Ljava/util/stream/LongStream;)TT; -
 method public remove (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object; (TT;Ljava/lang/String;)TT; -
 method public compressMaps ()Z - -
 method public listBuilder ()Lcom/mojang/serialization/ListBuilder; ()Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<TT;>; -
in 93
class net/minecraft/resources/DelegatingOps 61 public,super,abstract java/lang/Object com/mojang/serialization/DynamicOps <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<TT;>;
 inner com/mojang/serialization/ListBuilder$Builder com/mojang/serialization/ListBuilder Builder public,static,final
 inner com/mojang/serialization/RecordBuilder$MapBuilder com/mojang/serialization/RecordBuilder MapBuilder public,static,final
 field protected,final delegate Lcom/mojang/serialization/DynamicOps; Lcom/mojang/serialization/DynamicOps<TT;>;
 method protected <init> (Lcom/mojang/serialization/DynamicOps;)V (Lcom/mojang/serialization/DynamicOps<TT;>;)V -
 method public empty ()Ljava/lang/Object; ()TT; -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;TT;)TU; -
 method public getNumberValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Ljava/lang/Object; (Ljava/lang/Number;)TT; -
 method public createByte (B)Ljava/lang/Object; (B)TT; -
 method public createShort (S)Ljava/lang/Object; (S)TT; -
 method public createInt (I)Ljava/lang/Object; (I)TT; -
 method public createLong (J)Ljava/lang/Object; (J)TT; -
 method public createFloat (F)Ljava/lang/Object; (F)TT; -
 method public createDouble (D)Ljava/lang/Object; (D)TT; -
 method public getBooleanValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Boolean;>; -
 method public createBoolean (Z)Ljava/lang/Object; (Z)TT; -
 method public getStringValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TT; -
 method public mergeToList (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToList (Ljava/lang/Object;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (TT;Ljava/util/List<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (TT;Lcom/mojang/serialization/MapLike<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public getMapValues (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;>; -
 method public getMapEntries (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<TT;TT;>;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;)TT; -
 method public getMap (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<TT;>;>; -
 method public getStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<TT;>;>; -
 method public getList (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<TT;>;>;>; -
 method public createList (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<TT;>;)TT; -
 method public getByteBuffer (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Ljava/lang/Object; (Ljava/nio/ByteBuffer;)TT; -
 method public getIntStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Ljava/lang/Object; (Ljava/util/stream/IntStream;)TT; -
 method public getLongStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Ljava/lang/Object; (Ljava/util/stream/LongStream;)TT; -
 method public remove (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object; (TT;Ljava/lang/String;)TT; -
 method public compressMaps ()Z - -
 method public listBuilder ()Lcom/mojang/serialization/ListBuilder; ()Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<TT;>; -
in 128
class net/minecraft/resources/DelegatingOps 65 public,super,abstract java/lang/Object com/mojang/serialization/DynamicOps <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<TT;>;
 inner com/mojang/serialization/ListBuilder$Builder com/mojang/serialization/ListBuilder Builder public,static,final
 inner com/mojang/serialization/RecordBuilder$MapBuilder com/mojang/serialization/RecordBuilder MapBuilder public,static,final
 field protected,final delegate Lcom/mojang/serialization/DynamicOps; Lcom/mojang/serialization/DynamicOps<TT;>;
 method protected <init> (Lcom/mojang/serialization/DynamicOps;)V (Lcom/mojang/serialization/DynamicOps<TT;>;)V -
 method public empty ()Ljava/lang/Object; ()TT; -
 method public emptyMap ()Ljava/lang/Object; ()TT; -
 method public emptyList ()Ljava/lang/Object; ()TT; -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;TT;)TU; -
 method public getNumberValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Ljava/lang/Object; (Ljava/lang/Number;)TT; -
 method public createByte (B)Ljava/lang/Object; (B)TT; -
 method public createShort (S)Ljava/lang/Object; (S)TT; -
 method public createInt (I)Ljava/lang/Object; (I)TT; -
 method public createLong (J)Ljava/lang/Object; (J)TT; -
 method public createFloat (F)Ljava/lang/Object; (F)TT; -
 method public createDouble (D)Ljava/lang/Object; (D)TT; -
 method public getBooleanValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Boolean;>; -
 method public createBoolean (Z)Ljava/lang/Object; (Z)TT; -
 method public getStringValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TT; -
 method public mergeToList (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToList (Ljava/lang/Object;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (TT;Ljava/util/List<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (TT;Lcom/mojang/serialization/MapLike<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (TT;Ljava/util/Map<TT;TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToPrimitive (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public getMapValues (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;>; -
 method public getMapEntries (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<TT;TT;>;>;>; -
 method public createMap (Ljava/util/Map;)Ljava/lang/Object; (Ljava/util/Map<TT;TT;>;)TT; -
 method public createMap (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;)TT; -
 method public getMap (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<TT;>;>; -
 method public getStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<TT;>;>; -
 method public getList (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<TT;>;>;>; -
 method public createList (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<TT;>;)TT; -
 method public getByteBuffer (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Ljava/lang/Object; (Ljava/nio/ByteBuffer;)TT; -
 method public getIntStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Ljava/lang/Object; (Ljava/util/stream/IntStream;)TT; -
 method public getLongStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Ljava/lang/Object; (Ljava/util/stream/LongStream;)TT; -
 method public remove (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object; (TT;Ljava/lang/String;)TT; -
 method public compressMaps ()Z - -
 method public listBuilder ()Lcom/mojang/serialization/ListBuilder; ()Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<TT;>; -
in 96
class net/minecraft/resources/DelegatingOps 65 public,super,abstract java/lang/Object com/mojang/serialization/DynamicOps <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<TT;>;
 inner net/minecraft/resources/DelegatingOps$DelegateListBuilder net/minecraft/resources/DelegatingOps DelegateListBuilder protected
 inner net/minecraft/resources/DelegatingOps$DelegateRecordBuilder net/minecraft/resources/DelegatingOps DelegateRecordBuilder protected
 field protected,final delegate Lcom/mojang/serialization/DynamicOps; Lcom/mojang/serialization/DynamicOps<TT;>;
 method protected <init> (Lcom/mojang/serialization/DynamicOps;)V (Lcom/mojang/serialization/DynamicOps<TT;>;)V -
 method public empty ()Ljava/lang/Object; ()TT; -
 method public emptyMap ()Ljava/lang/Object; ()TT; -
 method public emptyList ()Ljava/lang/Object; ()TT; -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;TT;)TU; -
 method public getNumberValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Ljava/lang/Object; (Ljava/lang/Number;)TT; -
 method public createByte (B)Ljava/lang/Object; (B)TT; -
 method public createShort (S)Ljava/lang/Object; (S)TT; -
 method public createInt (I)Ljava/lang/Object; (I)TT; -
 method public createLong (J)Ljava/lang/Object; (J)TT; -
 method public createFloat (F)Ljava/lang/Object; (F)TT; -
 method public createDouble (D)Ljava/lang/Object; (D)TT; -
 method public getBooleanValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/Boolean;>; -
 method public createBoolean (Z)Ljava/lang/Object; (Z)TT; -
 method public getStringValue (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TT; -
 method public mergeToList (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToList (Ljava/lang/Object;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (TT;Ljava/util/List<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (TT;Lcom/mojang/serialization/MapLike<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToMap (Ljava/lang/Object;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (TT;Ljava/util/Map<TT;TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public mergeToPrimitive (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public getMapValues (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;>; -
 method public getMapEntries (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<TT;TT;>;>;>; -
 method public createMap (Ljava/util/Map;)Ljava/lang/Object; (Ljava/util/Map<TT;TT;>;)TT; -
 method public createMap (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<TT;TT;>;>;)TT; -
 method public getMap (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<TT;>;>; -
 method public getStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<TT;>;>; -
 method public getList (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<TT;>;>;>; -
 method public createList (Ljava/util/stream/Stream;)Ljava/lang/Object; (Ljava/util/stream/Stream<TT;>;)TT; -
 method public getByteBuffer (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Ljava/lang/Object; (Ljava/nio/ByteBuffer;)TT; -
 method public getIntStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Ljava/lang/Object; (Ljava/util/stream/IntStream;)TT; -
 method public getLongStream (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Ljava/lang/Object; (Ljava/util/stream/LongStream;)TT; -
 method public remove (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object; (TT;Ljava/lang/String;)TT; -
 method public compressMaps ()Z - -
 method public listBuilder ()Lcom/mojang/serialization/ListBuilder; ()Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<TT;>; -
in 96
class net/minecraft/resources/DelegatingOps$DelegateListBuilder 65 public,super java/lang/Object com/mojang/serialization/ListBuilder Ljava/lang/Object;Lcom/mojang/serialization/ListBuilder<TT;>;
 inner net/minecraft/resources/DelegatingOps$DelegateListBuilder net/minecraft/resources/DelegatingOps DelegateListBuilder protected
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/resources/DelegatingOps;Lcom/mojang/serialization/ListBuilder;)V (Lcom/mojang/serialization/ListBuilder<TT;>;)V -
 method public ops ()Lcom/mojang/serialization/DynamicOps; ()Lcom/mojang/serialization/DynamicOps<TT;>; -
 method public build (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public add (Ljava/lang/Object;)Lcom/mojang/serialization/ListBuilder; (TT;)Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public add (Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/ListBuilder; (Lcom/mojang/serialization/DataResult<TT;>;)Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public add (Ljava/lang/Object;Lcom/mojang/serialization/Encoder;)Lcom/mojang/serialization/ListBuilder; <E:Ljava/lang/Object;>(TE;Lcom/mojang/serialization/Encoder<TE;>;)Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public addAll (Ljava/lang/Iterable;Lcom/mojang/serialization/Encoder;)Lcom/mojang/serialization/ListBuilder; <E:Ljava/lang/Object;>(Ljava/lang/Iterable<TE;>;Lcom/mojang/serialization/Encoder<TE;>;)Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public withErrorsFrom (Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/ListBuilder; (Lcom/mojang/serialization/DataResult<*>;)Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public mapError (Ljava/util/function/UnaryOperator;)Lcom/mojang/serialization/ListBuilder; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lcom/mojang/serialization/ListBuilder<TT;>; -
 method public build (Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/DataResult; (Lcom/mojang/serialization/DataResult<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
in 96
class net/minecraft/resources/DelegatingOps$DelegateRecordBuilder 65 public,super java/lang/Object com/mojang/serialization/RecordBuilder Ljava/lang/Object;Lcom/mojang/serialization/RecordBuilder<TT;>;
 inner net/minecraft/resources/DelegatingOps$DelegateRecordBuilder net/minecraft/resources/DelegatingOps DelegateRecordBuilder protected
 method protected <init> (Lnet/minecraft/resources/DelegatingOps;Lcom/mojang/serialization/RecordBuilder;)V (Lcom/mojang/serialization/RecordBuilder<TT;>;)V -
 method public ops ()Lcom/mojang/serialization/DynamicOps; ()Lcom/mojang/serialization/DynamicOps<TT;>; -
 method public add (Ljava/lang/Object;Ljava/lang/Object;)Lcom/mojang/serialization/RecordBuilder; (TT;TT;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public add (Ljava/lang/Object;Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/RecordBuilder; (TT;Lcom/mojang/serialization/DataResult<TT;>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public add (Lcom/mojang/serialization/DataResult;Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/RecordBuilder; (Lcom/mojang/serialization/DataResult<TT;>;Lcom/mojang/serialization/DataResult<TT;>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public add (Ljava/lang/String;Ljava/lang/Object;)Lcom/mojang/serialization/RecordBuilder; (Ljava/lang/String;TT;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public add (Ljava/lang/String;Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/RecordBuilder; (Ljava/lang/String;Lcom/mojang/serialization/DataResult<TT;>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public add (Ljava/lang/String;Ljava/lang/Object;Lcom/mojang/serialization/Encoder;)Lcom/mojang/serialization/RecordBuilder; <E:Ljava/lang/Object;>(Ljava/lang/String;TE;Lcom/mojang/serialization/Encoder<TE;>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public withErrorsFrom (Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/RecordBuilder; (Lcom/mojang/serialization/DataResult<*>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public setLifecycle (Lcom/mojang/serialization/Lifecycle;)Lcom/mojang/serialization/RecordBuilder; (Lcom/mojang/serialization/Lifecycle;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public mapError (Ljava/util/function/UnaryOperator;)Lcom/mojang/serialization/RecordBuilder; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public build (Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; (TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public build (Lcom/mojang/serialization/DataResult;)Lcom/mojang/serialization/DataResult; (Lcom/mojang/serialization/DataResult<TT;>;)Lcom/mojang/serialization/DataResult<TT;>; -
in 69
class net/minecraft/resources/DependantName 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract get (Lnet/minecraft/resources/ResourceKey;)Ljava/lang/Object; (Lnet/minecraft/resources/ResourceKey<TT;>;)TV; -
 method public,static fixed (Ljava/lang/Object;)Lnet/minecraft/resources/DependantName; <T:Ljava/lang/Object;V:Ljava/lang/Object;>(TV;)Lnet/minecraft/resources/DependantName<TT;TV;>; -
in 220
class net/minecraft/resources/FileToIdConverter 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static json (Ljava/lang/String;)Lnet/minecraft/resources/FileToIdConverter; - -
 method public idToFile (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public fileToId (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public listMatchingResources (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacks (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
in 702
class net/minecraft/resources/FileToIdConverter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static json (Ljava/lang/String;)Lnet/minecraft/resources/FileToIdConverter; - -
 method public idToFile (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public fileToId (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public listMatchingResources (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacks (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
in 519
class net/minecraft/resources/FileToIdConverter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static json (Ljava/lang/String;)Lnet/minecraft/resources/FileToIdConverter; - -
 method public,static registry (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/FileToIdConverter; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Lnet/minecraft/resources/FileToIdConverter; -
 method public idToFile (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public fileToId (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public listMatchingResources (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacks (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
in 121
class net/minecraft/resources/FileToIdConverter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static json (Ljava/lang/String;)Lnet/minecraft/resources/FileToIdConverter; - -
 method public,static registry (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/FileToIdConverter; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Lnet/minecraft/resources/FileToIdConverter; -
 method public idToFile (Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/Identifier; - -
 method public fileToId (Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/Identifier; - -
 method public listMatchingResources (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/Identifier;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacks (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/Identifier;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
in 571
class net/minecraft/resources/FileToIdConverter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static json (Ljava/lang/String;)Lnet/minecraft/resources/FileToIdConverter; - -
 method public idToFile (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public fileToId (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public listMatchingResources (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacks (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
 method public listMatchingResourcesFromNamespace (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacksFromNamespace (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
in 515
class net/minecraft/resources/FileToIdConverter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static json (Ljava/lang/String;)Lnet/minecraft/resources/FileToIdConverter; - -
 method public,static registry (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/FileToIdConverter; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Lnet/minecraft/resources/FileToIdConverter; -
 method public idToFile (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public fileToId (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceLocation; - -
 method public listMatchingResources (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacks (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
 method public listMatchingResourcesFromNamespace (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacksFromNamespace (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
in 48
class net/minecraft/resources/FileToIdConverter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static json (Ljava/lang/String;)Lnet/minecraft/resources/FileToIdConverter; - -
 method public,static registry (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/FileToIdConverter; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Lnet/minecraft/resources/FileToIdConverter; -
 method public idToFile (Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/Identifier; - -
 method public fileToId (Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/Identifier; - -
 method public listMatchingResources (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/Identifier;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacks (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;)Ljava/util/Map<Lnet/minecraft/resources/Identifier;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
 method public listMatchingResourcesFromNamespace (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/resources/Identifier;Lnet/minecraft/server/packs/resources/Resource;>; -
 method public listMatchingResourceStacksFromNamespace (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/resources/Identifier;Ljava/util/List<Lnet/minecraft/server/packs/resources/Resource;>;>; -
in 617
class net/minecraft/resources/HolderSetCodec 61 public,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>;
 inner net/minecraft/core/Holder$Direct net/minecraft/core/Holder Direct public,static,final
 inner net/minecraft/core/HolderSet$Direct net/minecraft/core/HolderSet Direct public,static
 inner net/minecraft/core/Holder$Kind net/minecraft/core/Holder Kind public,static,final,enum
 inner net/minecraft/core/HolderSet$Named net/minecraft/core/HolderSet Named public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/Codec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;Z)Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/HolderSet<TE;>;TT;>;>; -
 method public encode (Lnet/minecraft/core/HolderSet;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/HolderSet<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
in 372
class net/minecraft/resources/HolderSetCodec 61 public,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>;
 inner net/minecraft/util/ExtraCodecs$EitherCodec net/minecraft/util/ExtraCodecs EitherCodec public,static,final
 inner net/minecraft/core/Holder$Direct net/minecraft/core/Holder Direct public,static,final
 inner net/minecraft/core/HolderSet$Direct net/minecraft/core/HolderSet Direct public,static
 inner net/minecraft/core/Holder$Kind net/minecraft/core/Holder Kind public,static,final,enum
 inner net/minecraft/core/HolderSet$Named net/minecraft/core/HolderSet Named public,static
 inner net/minecraft/core/HolderSet$ListBacked net/minecraft/core/HolderSet ListBacked public,static,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/Codec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;Z)Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/HolderSet<TE;>;TT;>;>; -
 method public encode (Lnet/minecraft/core/HolderSet;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/HolderSet<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
in 60
class net/minecraft/resources/HolderSetCodec 65 public,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>;
 inner net/minecraft/core/Holder$Direct net/minecraft/core/Holder Direct public,static,final
 inner net/minecraft/core/HolderSet$Direct net/minecraft/core/HolderSet Direct public,static,final
 inner net/minecraft/core/Holder$Kind net/minecraft/core/Holder Kind public,static,final,enum
 inner net/minecraft/core/HolderSet$Named net/minecraft/core/HolderSet Named public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/Codec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;Z)Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/HolderSet<TE;>;TT;>;>; -
 method public encode (Lnet/minecraft/core/HolderSet;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/HolderSet<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
in 113
class net/minecraft/resources/HolderSetCodec 61 public,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>;
 inner net/minecraft/core/Holder$Direct net/minecraft/core/Holder Direct public,static,final
 inner net/minecraft/core/HolderSet$Direct net/minecraft/core/HolderSet Direct public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 inner net/minecraft/core/Holder$Kind net/minecraft/core/Holder Kind public,static,final,enum
 inner net/minecraft/core/HolderSet$Named net/minecraft/core/HolderSet Named public,static
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/Codec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;Z)Lcom/mojang/serialization/Codec<Lnet/minecraft/core/HolderSet<TE;>;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/HolderSet<TE;>;TT;>;>; -
 method public encode (Lnet/minecraft/core/HolderSet;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/HolderSet<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
in 121
class net/minecraft/resources/Identifier 65 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/Identifier;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/Identifier;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/Identifier;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/Identifier; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/Identifier; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/Identifier;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/Identifier; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/Identifier; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/Identifier;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toShortString ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/Identifier; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/Identifier; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInIdentifier (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
in 48
class net/minecraft/resources/Identifier 65 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/Identifier;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/Identifier;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/Identifier;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/Identifier; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/Identifier; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/Identifier;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/Identifier; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/Identifier; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/Identifier; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/Identifier;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/Identifier;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toShortString ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/Identifier; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/Identifier; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInIdentifier (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
in 665
class net/minecraft/resources/RegistryDataLoader 61 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,interface,abstract
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 239
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Lnet/minecraft/resources/RegistryDataLoader$LoadingFunction;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/resources/RegistryDataLoader$LoadingFunction;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 240
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 566
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/resources/RegistryDataLoader$NetworkedRegistryData net/minecraft/resources/RegistryDataLoader NetworkedRegistryData public,static,final
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/tags/TagNetworkSerialization$NetworkPayload net/minecraft/tags/TagNetworkSerialization NetworkPayload public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List<Lnet/minecraft/core/HolderLookup$RegistryLookup<*>;>;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Lnet/minecraft/resources/RegistryDataLoader$NetworkedRegistryData;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Ljava/util/List<Lnet/minecraft/core/HolderLookup$RegistryLookup<*>;>;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 191
class net/minecraft/resources/RegistryDataLoader 61 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/neoforged/neoforge/common/conditions/ICondition$IContext net/neoforged/neoforge/common/conditions/ICondition IContext public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,interface,abstract
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 192
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/neoforged/neoforge/common/conditions/ICondition$IContext net/neoforged/neoforge/common/conditions/ICondition IContext public,static,interface,abstract
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Lnet/minecraft/resources/RegistryDataLoader$LoadingFunction;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/resources/RegistryDataLoader$LoadingFunction;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 193
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/neoforged/neoforge/common/conditions/ICondition$IContext net/neoforged/neoforge/common/conditions/ICondition IContext public,static,interface,abstract
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 488
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/neoforged/neoforge/common/conditions/ICondition$IContext net/neoforged/neoforge/common/conditions/ICondition IContext public,static,interface,abstract
 inner net/minecraft/resources/RegistryDataLoader$NetworkedRegistryData net/minecraft/resources/RegistryDataLoader NetworkedRegistryData public,static,final
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/tags/TagNetworkSerialization$NetworkPayload net/minecraft/tags/TagNetworkSerialization NetworkPayload public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List<Lnet/minecraft/core/HolderLookup$RegistryLookup<*>;>;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Lnet/minecraft/resources/RegistryDataLoader$NetworkedRegistryData;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Ljava/util/List<Lnet/minecraft/core/HolderLookup$RegistryLookup<*>;>;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 407
class net/minecraft/resources/RegistryDataLoader 61 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,interface,abstract
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 244
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction private,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,final
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Lnet/minecraft/resources/RegistryDataLoader$LoadingFunction;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/resources/RegistryDataLoader$LoadingFunction;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 245
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction private,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,final
 inner net/minecraft/core/RegistryAccess$RegistryEntry net/minecraft/core/RegistryAccess RegistryEntry public,static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/core/RegistryAccess;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 100
class net/minecraft/resources/RegistryDataLoader 65 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction private,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$ImmutableRegistryAccess net/minecraft/core/RegistryAccess ImmutableRegistryAccess public,static
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/resources/RegistryDataLoader$NetworkedRegistryData net/minecraft/resources/RegistryDataLoader NetworkedRegistryData public,static,final
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner net/minecraft/tags/TagNetworkSerialization$NetworkPayload net/minecraft/tags/TagNetworkSerialization NetworkPayload public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/world/level/levelgen/synth/NormalNoise$NoiseParameters net/minecraft/world/level/levelgen/synth/NormalNoise NoiseParameters public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final WORLDGEN_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final DIMENSION_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 field public,static,final SYNCHRONIZED_REGISTRIES Ljava/util/List; Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;
 method public <init> ()V - -
 method public,static load (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List<Lnet/minecraft/core/HolderLookup$RegistryLookup<*>;>;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
 method public,static load (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Ljava/util/List;Ljava/util/List;)Lnet/minecraft/core/RegistryAccess$Frozen; (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Lnet/minecraft/resources/RegistryDataLoader$NetworkedRegistryData;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Ljava/util/List<Lnet/minecraft/core/HolderLookup$RegistryLookup<*>;>;Ljava/util/List<Lnet/minecraft/resources/RegistryDataLoader$RegistryData<*>;>;)Lnet/minecraft/core/RegistryAccess$Frozen; -
in 220
class net/minecraft/resources/RegistryDataLoader$Loader 61 interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 method public,abstract load (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V - -
in 94
class net/minecraft/resources/RegistryDataLoader$Loader 65 final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public loadFromResources (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V - -
 method public loadFromNetwork (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public data ()Lnet/minecraft/resources/RegistryDataLoader$RegistryData; ()Lnet/minecraft/resources/RegistryDataLoader$RegistryData<TT;>; -
 method public registry ()Lnet/minecraft/core/WritableRegistry; ()Lnet/minecraft/core/WritableRegistry<TT;>; -
 method public loadingErrors ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<*>;Ljava/lang/Exception;>; -
in 69
class net/minecraft/resources/RegistryDataLoader$Loader 65 final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryDataLoader$NetworkedRegistryData net/minecraft/resources/RegistryDataLoader NetworkedRegistryData public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public loadFromResources (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V - -
 method public loadFromNetwork (Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V (Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;Lnet/minecraft/resources/RegistryDataLoader$NetworkedRegistryData;>;Lnet/minecraft/server/packs/resources/ResourceProvider;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public data ()Lnet/minecraft/resources/RegistryDataLoader$RegistryData; ()Lnet/minecraft/resources/RegistryDataLoader$RegistryData<TT;>; -
 method public registry ()Lnet/minecraft/core/WritableRegistry; ()Lnet/minecraft/core/WritableRegistry<TT;>; -
 method public loadingErrors ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<*>;Ljava/lang/Exception;>; -
in 107
class net/minecraft/resources/RegistryDataLoader$LoadingFunction 65 interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 method public,abstract apply (Lnet/minecraft/resources/RegistryDataLoader$Loader;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V (Lnet/minecraft/resources/RegistryDataLoader$Loader<*>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V -
in 111
class net/minecraft/resources/RegistryDataLoader$LoadingFunction 65 interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryDataLoader$LoadingFunction net/minecraft/resources/RegistryDataLoader LoadingFunction static,interface,abstract
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,final
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 method public,abstract apply (Lnet/minecraft/resources/RegistryDataLoader$Loader;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V (Lnet/minecraft/resources/RegistryDataLoader$Loader<*>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V -
in 69
class net/minecraft/resources/RegistryDataLoader$NetworkedRegistryData 65 public,final,super java/lang/Record - -
 inner net/minecraft/resources/RegistryDataLoader$NetworkedRegistryData net/minecraft/resources/RegistryDataLoader NetworkedRegistryData public,static,final
 inner net/minecraft/tags/TagNetworkSerialization$NetworkPayload net/minecraft/tags/TagNetworkSerialization NetworkPayload public,static,final
 inner net/minecraft/core/RegistrySynchronization$PackedRegistryEntry net/minecraft/core/RegistrySynchronization PackedRegistryEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/List;Lnet/minecraft/tags/TagNetworkSerialization$NetworkPayload;)V (Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>;Lnet/minecraft/tags/TagNetworkSerialization$NetworkPayload;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public elements ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/core/RegistrySynchronization$PackedRegistryEntry;>; -
 method public tags ()Lnet/minecraft/tags/TagNetworkSerialization$NetworkPayload; - -
in 655
class net/minecraft/resources/RegistryDataLoader$RegistryData 61 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
in 311
class net/minecraft/resources/RegistryDataLoader$RegistryData 61 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;)V -
 method public runWithArguments (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
in 286
class net/minecraft/resources/RegistryDataLoader$RegistryData 65 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;)V -
 method public runWithArguments (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
in 682
class net/minecraft/resources/RegistryDataLoader$RegistryData 65 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;Z)V -
 method public runWithArguments (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
 method public requiredNonEmpty ()Z - -
in 15
class net/minecraft/resources/RegistryDataLoader$RegistryData 65 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;Z)V -
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;ZLjava/util/function/Consumer;)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;ZLjava/util/function/Consumer<Lnet/neoforged/neoforge/registries/RegistryBuilder<TT;>;>;)V -
 method public runWithArguments (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
 method public requiredNonEmpty ()Z - -
 method public registryBuilderConsumer ()Ljava/util/function/Consumer; ()Ljava/util/function/Consumer<Lnet/neoforged/neoforge/registries/RegistryBuilder<TT;>;>; -
in 437
class net/minecraft/resources/RegistryDataLoader$RegistryData 61 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
in 316
class net/minecraft/resources/RegistryDataLoader$RegistryData 61 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;)V -
 method public runWithArguments (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
in 244
class net/minecraft/resources/RegistryDataLoader$RegistryData 65 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;)V -
 method public runWithArguments (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
in 288
class net/minecraft/resources/RegistryDataLoader$RegistryData 65 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryDataLoader$RegistryData net/minecraft/resources/RegistryDataLoader RegistryData public,static,final
 inner net/minecraft/resources/RegistryDataLoader$Loader net/minecraft/resources/RegistryDataLoader Loader private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)V (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;Z)V -
 method public runWithArguments (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lcom/mojang/serialization/Codec<TT;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>; -
 method public elementCodec ()Lcom/mojang/serialization/Codec; ()Lcom/mojang/serialization/Codec<TT;>; -
 method public requiredNonEmpty ()Z - -
in 86
class net/minecraft/resources/RegistryDataPackCodec 52 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/MappedRegistry<TE;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Lifecycle;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryDataPackCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Lifecycle;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryDataPackCodec<TE;>; -
 method public encode (Lnet/minecraft/core/MappedRegistry;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/MappedRegistry<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/MappedRegistry<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 82
class net/minecraft/resources/RegistryDataPackCodec 60 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/MappedRegistry<TE;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Lifecycle;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryDataPackCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Lifecycle;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryDataPackCodec<TE;>; -
 method public encode (Lnet/minecraft/core/MappedRegistry;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/MappedRegistry<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/MappedRegistry<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 86
class net/minecraft/resources/RegistryFileCodec 52 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Ljava/util/function/Supplier<TE;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public,static homogeneousList (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/Codec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/Codec<Ljava/util/List<Ljava/util/function/Supplier<TE;>;>;>; -
 method public encode (Ljava/util/function/Supplier;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Ljava/util/function/Supplier<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 82
class net/minecraft/resources/RegistryFileCodec 60 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Ljava/util/function/Supplier<TE;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public,static homogeneousList (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/Codec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/Codec<Ljava/util/List<Ljava/util/function/Supplier<TE;>;>;>; -
 method public encode (Ljava/util/function/Supplier;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Ljava/util/function/Supplier<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 84
class net/minecraft/resources/RegistryFileCodec 61 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Holder;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Holder<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/Holder<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 83
class net/minecraft/resources/RegistryFileCodec 61 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Z)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Holder;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Holder<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/Holder<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 220
class net/minecraft/resources/RegistryFileCodec 61 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Z)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Holder;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Holder<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/Holder<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 60
class net/minecraft/resources/RegistryFileCodec 65 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lnet/minecraft/resources/RegistryFileCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Z)Lnet/minecraft/resources/RegistryFileCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Holder;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Holder<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/Holder<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 34
class net/minecraft/resources/RegistryFixedCodec 61 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/RegistryFixedCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lnet/minecraft/resources/RegistryFixedCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Holder;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Holder<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/Holder<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 220
class net/minecraft/resources/RegistryFixedCodec 61 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/RegistryFixedCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lnet/minecraft/resources/RegistryFixedCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Holder;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Holder<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/Holder<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 60
class net/minecraft/resources/RegistryFixedCodec 65 public,final,super java/lang/Object com/mojang/serialization/Codec <E:Ljava/lang/Object;>Ljava/lang/Object;Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<TE;>;>;
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/RegistryFixedCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lnet/minecraft/resources/RegistryFixedCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Holder;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Holder<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;TT;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/core/Holder<TE;>;TT;>;>; -
 method public toString ()Ljava/lang/String; - -
in 105
class net/minecraft/resources/RegistryLoader 61 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryLoader$ReadCache net/minecraft/resources/RegistryLoader ReadCache static,final
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner net/minecraft/core/RegistryAccess$Writable net/minecraft/core/RegistryAccess Writable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public overrideRegistryFromResources (Lnet/minecraft/core/WritableRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/WritableRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;)Lcom/mojang/serialization/DataResult<+Lnet/minecraft/core/Registry<TE;>;>; -
 method public bind (Lnet/minecraft/core/RegistryAccess$Writable;)Lnet/minecraft/resources/RegistryLoader$Bound; - -
in 231
class net/minecraft/resources/RegistryLoader 61 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/resources/RegistryLoader$ReadCache net/minecraft/resources/RegistryLoader ReadCache static,final
 inner net/minecraft/resources/RegistryResourceAccess$EntryThunk net/minecraft/resources/RegistryResourceAccess EntryThunk public,static,interface,abstract
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner net/minecraft/core/RegistryAccess$Writable net/minecraft/core/RegistryAccess Writable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public overrideRegistryFromResources (Lnet/minecraft/core/WritableRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/WritableRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;)Lcom/mojang/serialization/DataResult<+Lnet/minecraft/core/Registry<TE;>;>; -
 method public bind (Lnet/minecraft/core/RegistryAccess$Writable;)Lnet/minecraft/resources/RegistryLoader$Bound; - -
in 109
class net/minecraft/resources/RegistryLoader 61 public,super java/lang/Object - -
 inner net/minecraft/resources/RegistryLoader$ReadCache net/minecraft/resources/RegistryLoader ReadCache private,static,final
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner net/minecraft/core/RegistryAccess$Writable net/minecraft/core/RegistryAccess Writable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public overrideRegistryFromResources (Lnet/minecraft/core/WritableRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/WritableRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;)Lcom/mojang/serialization/DataResult<+Lnet/minecraft/core/Registry<TE;>;>; -
 method public bind (Lnet/minecraft/core/RegistryAccess$Writable;)Lnet/minecraft/resources/RegistryLoader$Bound; - -
in 232
class net/minecraft/resources/RegistryLoader 61 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/resources/RegistryLoader$ReadCache net/minecraft/resources/RegistryLoader ReadCache private,static,final
 inner net/minecraft/resources/RegistryResourceAccess$EntryThunk net/minecraft/resources/RegistryResourceAccess EntryThunk public,static,interface,abstract
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner net/minecraft/core/RegistryAccess$Writable net/minecraft/core/RegistryAccess Writable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public overrideRegistryFromResources (Lnet/minecraft/core/WritableRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/WritableRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;)Lcom/mojang/serialization/DataResult<+Lnet/minecraft/core/Registry<TE;>;>; -
 method public bind (Lnet/minecraft/core/RegistryAccess$Writable;)Lnet/minecraft/resources/RegistryLoader$Bound; - -
in 34
class net/minecraft/resources/RegistryLoader$Bound 61 public,final,super java/lang/Record - -
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner net/minecraft/core/RegistryAccess$Writable net/minecraft/core/RegistryAccess Writable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/resources/RegistryLoader;)V - -
 method public overrideRegistryFromResources (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;)Lcom/mojang/serialization/DataResult<+Lnet/minecraft/core/Registry<TE;>;>; -
 method public overrideElementFromResources (Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/DynamicOps;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/Holder<TE;>;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public access ()Lnet/minecraft/core/RegistryAccess$Writable; - -
 method public loader ()Lnet/minecraft/resources/RegistryLoader; - -
in 34
class net/minecraft/resources/RegistryLoader$ReadCache 61 final,super java/lang/Object - <E:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/RegistryLoader$ReadCache net/minecraft/resources/RegistryLoader ReadCache static,final
in 86
class net/minecraft/resources/RegistryLookupCodec 52 public,final,super com/mojang/serialization/MapCodec - <E:Ljava/lang/Object;>Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/Registry<TE;>;>;
 method public,static create (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/RegistryLookupCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lnet/minecraft/resources/RegistryLookupCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Registry;Lcom/mojang/serialization/DynamicOps;Lcom/mojang/serialization/RecordBuilder;)Lcom/mojang/serialization/RecordBuilder; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;Lcom/mojang/serialization/RecordBuilder<TT;>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lcom/mojang/serialization/MapLike<TT;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/Registry<TE;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public keys (Lcom/mojang/serialization/DynamicOps;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;)Ljava/util/stream/Stream<TT;>; -
in 82
class net/minecraft/resources/RegistryLookupCodec 60 public,final,super com/mojang/serialization/MapCodec - <E:Ljava/lang/Object;>Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/Registry<TE;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/resources/RegistryLookupCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lnet/minecraft/resources/RegistryLookupCodec<TE;>; -
 method public encode (Lnet/minecraft/core/Registry;Lcom/mojang/serialization/DynamicOps;Lcom/mojang/serialization/RecordBuilder;)Lcom/mojang/serialization/RecordBuilder; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TE;>;Lcom/mojang/serialization/DynamicOps<TT;>;Lcom/mojang/serialization/RecordBuilder<TT;>;)Lcom/mojang/serialization/RecordBuilder<TT;>; -
 method public decode (Lcom/mojang/serialization/DynamicOps;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lcom/mojang/serialization/MapLike<TT;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/Registry<TE;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public keys (Lcom/mojang/serialization/DynamicOps;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;)Ljava/util/stream/Stream<TT;>; -
in 262
class net/minecraft/resources/RegistryOps 61 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/core/RegistryAccess$Writable net/minecraft/core/RegistryAccess Writable public,static,interface,abstract
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/resources/RegistryResourceAccess;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/resources/RegistryResourceAccess;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public registry (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<+Lnet/minecraft/core/Registry<TE;>;>; -
 method public registryLoader ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/resources/RegistryLoader$Bound;>; -
 method public getAsJson ()Lcom/mojang/serialization/DynamicOps; ()Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>; -
 method public,static retrieveRegistry (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/MapCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/Registry<TE;>;>; -
in 231
class net/minecraft/resources/RegistryOps 61 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/core/RegistryAccess$Writable net/minecraft/core/RegistryAccess Writable public,static,interface,abstract
 inner net/minecraft/resources/RegistryLoader$Bound net/minecraft/resources/RegistryLoader Bound public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final registryAccess Lnet/minecraft/core/RegistryAccess; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/resources/RegistryResourceAccess;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess$Writable;Lnet/minecraft/resources/RegistryResourceAccess;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public registry (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<+Lnet/minecraft/core/Registry<TE;>;>; -
 method public registryLoader ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/resources/RegistryLoader$Bound;>; -
 method public getAsJson ()Lcom/mojang/serialization/DynamicOps; ()Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>; -
 method public,static retrieveRegistry (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/MapCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/Registry<TE;>;>; -
in 45
class net/minecraft/resources/RegistryOps 61 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public owner (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderOwner<TE;>;>; -
 method public getter (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveGetter (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveRegistryLookup (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/MapCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/HolderLookup$RegistryLookup<TE;>;>; -
 method public,static retrieveElement (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/Holder$Reference<TE;>;>; -
in 270
class net/minecraft/resources/RegistryOps 61 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public owner (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderOwner<TE;>;>; -
 method public getter (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveGetter (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveElement (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/Holder$Reference<TE;>;>; -
in 506
class net/minecraft/resources/RegistryOps 65 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryOps$HolderLookupAdapter net/minecraft/resources/RegistryOps HolderLookupAdapter static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static injectRegistryContext (Lcom/mojang/serialization/Dynamic;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/Dynamic<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic<TT;>; -
 method public withParent (Lcom/mojang/serialization/DynamicOps;)Lnet/minecraft/resources/RegistryOps; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;)Lnet/minecraft/resources/RegistryOps<TU;>; -
 method public owner (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderOwner<TE;>;>; -
 method public getter (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static retrieveGetter (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveElement (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/Holder$Reference<TE;>;>; -
in 191
class net/minecraft/resources/RegistryOps 61 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method protected <init> (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V (Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V -
 method protected <init> (Lnet/minecraft/resources/RegistryOps;)V (Lnet/minecraft/resources/RegistryOps<TT;>;)V -
 method public owner (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderOwner<TE;>;>; -
 method public getter (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveGetter (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveRegistryLookup (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/MapCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/HolderLookup$RegistryLookup<TE;>;>; -
 method public,static retrieveElement (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/Holder$Reference<TE;>;>; -
in 703
class net/minecraft/resources/RegistryOps 65 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryOps$HolderLookupAdapter net/minecraft/resources/RegistryOps HolderLookupAdapter static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static injectRegistryContext (Lcom/mojang/serialization/Dynamic;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/Dynamic<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic<TT;>; -
 method protected <init> (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V (Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V -
 method protected <init> (Lnet/minecraft/resources/RegistryOps;)V (Lnet/minecraft/resources/RegistryOps<TT;>;)V -
 method public withParent (Lcom/mojang/serialization/DynamicOps;)Lnet/minecraft/resources/RegistryOps; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;)Lnet/minecraft/resources/RegistryOps<TU;>; -
 method public owner (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderOwner<TE;>;>; -
 method public getter (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static retrieveGetter (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveRegistryLookup (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/MapCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/HolderLookup$RegistryLookup<TE;>;>; -
 method public,static retrieveElement (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/Holder$Reference<TE;>;>; -
in 6
class net/minecraft/resources/RegistryOps 65 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryOps$HolderLookupAdapter net/minecraft/resources/RegistryOps HolderLookupAdapter public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final lookupProvider Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static injectRegistryContext (Lcom/mojang/serialization/Dynamic;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/Dynamic<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic<TT;>; -
 method protected <init> (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V (Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)V -
 method protected <init> (Lnet/minecraft/resources/RegistryOps;)V (Lnet/minecraft/resources/RegistryOps<TT;>;)V -
 method public withParent (Lcom/mojang/serialization/DynamicOps;)Lnet/minecraft/resources/RegistryOps; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;)Lnet/minecraft/resources/RegistryOps<TU;>; -
 method public owner (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderOwner<TE;>;>; -
 method public getter (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static retrieveGetter (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveRegistryLookup (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/MapCodec; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/core/HolderLookup$RegistryLookup<TE;>;>; -
 method public,static retrieveElement (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/Holder$Reference<TE;>;>; -
in 111
class net/minecraft/resources/RegistryOps 65 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryOps$HolderLookupAdapter net/minecraft/resources/RegistryOps HolderLookupAdapter private,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryOps$RegistryInfoLookup;)Lnet/minecraft/resources/RegistryOps<TT;>; -
 method public,static injectRegistryContext (Lcom/mojang/serialization/Dynamic;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/Dynamic<TT;>;Lnet/minecraft/core/HolderLookup$Provider;)Lcom/mojang/serialization/Dynamic<TT;>; -
 method public withParent (Lcom/mojang/serialization/DynamicOps;)Lnet/minecraft/resources/RegistryOps; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;)Lnet/minecraft/resources/RegistryOps<TU;>; -
 method public owner (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderOwner<TE;>;>; -
 method public getter (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static retrieveGetter (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/HolderGetter<TE;>;>; -
 method public,static retrieveElement (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/codecs/RecordCodecBuilder; <E:Ljava/lang/Object;O:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Lcom/mojang/serialization/codecs/RecordCodecBuilder<TO;Lnet/minecraft/core/Holder$Reference<TE;>;>; -
in 704
class net/minecraft/resources/RegistryOps$HolderLookupAdapter 65 final,super java/lang/Object net/minecraft/resources/RegistryOps$RegistryInfoLookup -
 inner net/minecraft/resources/RegistryOps$HolderLookupAdapter net/minecraft/resources/RegistryOps HolderLookupAdapter static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/HolderLookup$Provider;)V - -
 method public lookup (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryOps$RegistryInfo<TE;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 6
class net/minecraft/resources/RegistryOps$HolderLookupAdapter 65 public,final,super java/lang/Object net/minecraft/resources/RegistryOps$RegistryInfoLookup -
 inner net/minecraft/resources/RegistryOps$HolderLookupAdapter net/minecraft/resources/RegistryOps HolderLookupAdapter public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final lookupProvider Lnet/minecraft/core/HolderLookup$Provider; -
 method public <init> (Lnet/minecraft/core/HolderLookup$Provider;)V - -
 method public lookup (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryOps$RegistryInfo<TE;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 220
class net/minecraft/resources/RegistryOps$RegistryInfo 61 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/HolderOwner;Lnet/minecraft/core/HolderGetter;Lcom/mojang/serialization/Lifecycle;)V (Lnet/minecraft/core/HolderOwner<TT;>;Lnet/minecraft/core/HolderGetter<TT;>;Lcom/mojang/serialization/Lifecycle;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public owner ()Lnet/minecraft/core/HolderOwner; ()Lnet/minecraft/core/HolderOwner<TT;>; -
 method public getter ()Lnet/minecraft/core/HolderGetter; ()Lnet/minecraft/core/HolderGetter<TT;>; -
 method public elementsLifecycle ()Lcom/mojang/serialization/Lifecycle; - -
in 60
class net/minecraft/resources/RegistryOps$RegistryInfo 65 public,final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/HolderOwner;Lnet/minecraft/core/HolderGetter;Lcom/mojang/serialization/Lifecycle;)V (Lnet/minecraft/core/HolderOwner<TT;>;Lnet/minecraft/core/HolderGetter<TT;>;Lcom/mojang/serialization/Lifecycle;)V -
 method public,static fromRegistryLookup (Lnet/minecraft/core/HolderLookup$RegistryLookup;)Lnet/minecraft/resources/RegistryOps$RegistryInfo; <T:Ljava/lang/Object;>(Lnet/minecraft/core/HolderLookup$RegistryLookup<TT;>;)Lnet/minecraft/resources/RegistryOps$RegistryInfo<TT;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public owner ()Lnet/minecraft/core/HolderOwner; ()Lnet/minecraft/core/HolderOwner<TT;>; -
 method public getter ()Lnet/minecraft/core/HolderGetter; ()Lnet/minecraft/core/HolderGetter<TT;>; -
 method public elementsLifecycle ()Lcom/mojang/serialization/Lifecycle; - -
in 220
class net/minecraft/resources/RegistryOps$RegistryInfoLookup 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 method public,abstract lookup (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TT;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryOps$RegistryInfo<TT;>;>; -
in 60
class net/minecraft/resources/RegistryOps$RegistryInfoLookup 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryOps$RegistryInfoLookup net/minecraft/resources/RegistryOps RegistryInfoLookup public,static,interface,abstract
 inner net/minecraft/resources/RegistryOps$RegistryInfo net/minecraft/resources/RegistryOps RegistryInfo public,static,final
 method public,abstract lookup (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<+TT;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryOps$RegistryInfo<TT;>;>; -
in 181
class net/minecraft/resources/RegistryReadOps 52 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/resources/RegistryReadOps$ReadCache net/minecraft/resources/RegistryReadOps ReadCache static,final
 inner net/minecraft/core/RegistryAccess$RegistryHolder net/minecraft/core/RegistryAccess RegistryHolder public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method protected decodeElement (Ljava/lang/Object;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(TT;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Z)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Ljava/util/function/Supplier<TE;>;TT;>;>; -
 method public decodeElements (Lnet/minecraft/core/MappedRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/MappedRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/MappedRegistry<TE;>;>; -
 method protected registry (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/Registry<TE;>;>; -
in 104
class net/minecraft/resources/RegistryReadOps 60 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/resources/RegistryReadOps$ReadCache net/minecraft/resources/RegistryReadOps ReadCache static,final
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap net/minecraft/resources/RegistryReadOps$ResourceAccess MemoryMap public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final registryAccess Lnet/minecraft/core/RegistryAccess; -
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method protected decodeElement (Ljava/lang/Object;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(TT;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Z)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Ljava/util/function/Supplier<TE;>;TT;>;>; -
 method public decodeElements (Lnet/minecraft/core/MappedRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/MappedRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/MappedRegistry<TE;>;>; -
 method protected registry (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/Registry<TE;>;>; -
in 190
class net/minecraft/resources/RegistryReadOps 52 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryReadOps$ReadCache net/minecraft/resources/RegistryReadOps ReadCache static,final
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/core/RegistryAccess$RegistryHolder net/minecraft/core/RegistryAccess RegistryHolder public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method protected decodeElement (Ljava/lang/Object;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(TT;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Z)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Ljava/util/function/Supplier<TE;>;TT;>;>; -
 method public decodeElements (Lnet/minecraft/core/MappedRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/MappedRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/MappedRegistry<TE;>;>; -
 method protected registry (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/Registry<TE;>;>; -
in 108
class net/minecraft/resources/RegistryReadOps 60 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/resources/RegistryReadOps$ReadCache net/minecraft/resources/RegistryReadOps ReadCache private,static,final
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap net/minecraft/resources/RegistryReadOps$ResourceAccess MemoryMap public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static createAndLoad (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/resources/RegistryReadOps$ResourceAccess;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryReadOps<TT;>; -
 method protected decodeElement (Ljava/lang/Object;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;Z)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(TT;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;Z)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<Ljava/util/function/Supplier<TE;>;TT;>;>; -
 method public decodeElements (Lnet/minecraft/core/MappedRegistry;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/core/MappedRegistry<TE;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/MappedRegistry<TE;>;>; -
 method protected registry (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/core/Registry<TE;>;>; -
in 86
class net/minecraft/resources/RegistryReadOps$ReadCache 52 final,super java/lang/Object - <E:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/RegistryReadOps$ReadCache net/minecraft/resources/RegistryReadOps ReadCache static,final
in 82
class net/minecraft/resources/RegistryReadOps$ReadCache 60 final,super java/lang/Object - <E:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/RegistryReadOps$ReadCache net/minecraft/resources/RegistryReadOps ReadCache static,final
in 86
class net/minecraft/resources/RegistryReadOps$ResourceAccess 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap net/minecraft/resources/RegistryReadOps$ResourceAccess MemoryMap public,static,final
 method public,abstract listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceLocation;>; -
 method public,abstract parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<TE;Ljava/util/OptionalInt;>;>; -
 method public,static forResourceManager (Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryReadOps$ResourceAccess; - -
in 82
class net/minecraft/resources/RegistryReadOps$ResourceAccess 60 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap net/minecraft/resources/RegistryReadOps$ResourceAccess MemoryMap public,static,final
 method public,abstract listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceLocation;>; -
 method public,abstract parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Ljava/util/Optional<Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<TE;Ljava/util/OptionalInt;>;>;>; -
 method public,static forResourceManager (Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryReadOps$ResourceAccess; - -
in 86
class net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap 52 public,final,super java/lang/Object net/minecraft/resources/RegistryReadOps$ResourceAccess -
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap net/minecraft/resources/RegistryReadOps$ResourceAccess MemoryMap public,static,final
 inner net/minecraft/core/RegistryAccess$RegistryHolder net/minecraft/core/RegistryAccess RegistryHolder public,static,final
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public add (Lnet/minecraft/core/RegistryAccess$RegistryHolder;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Encoder;ILjava/lang/Object;Lcom/mojang/serialization/Lifecycle;)V <E:Ljava/lang/Object;>(Lnet/minecraft/core/RegistryAccess$RegistryHolder;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Encoder<TE;>;ITE;Lcom/mojang/serialization/Lifecycle;)V -
 method public listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceLocation;>; -
 method public parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<TE;Ljava/util/OptionalInt;>;>; -
in 82
class net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap 60 public,final,super java/lang/Object net/minecraft/resources/RegistryReadOps$ResourceAccess -
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess net/minecraft/resources/RegistryReadOps ResourceAccess public,static,interface,abstract
 inner net/minecraft/resources/RegistryReadOps$ResourceAccess$MemoryMap net/minecraft/resources/RegistryReadOps$ResourceAccess MemoryMap public,static,final
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner net/minecraft/core/RegistryAccess$RegistryHolder net/minecraft/core/RegistryAccess RegistryHolder public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public add (Lnet/minecraft/core/RegistryAccess$RegistryHolder;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Encoder;ILjava/lang/Object;Lcom/mojang/serialization/Lifecycle;)V <E:Ljava/lang/Object;>(Lnet/minecraft/core/RegistryAccess$RegistryHolder;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Encoder<TE;>;ITE;Lcom/mojang/serialization/Lifecycle;)V -
 method public listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceLocation;>; -
 method public parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Ljava/util/Optional<Lcom/mojang/serialization/DataResult<Lcom/mojang/datafixers/util/Pair<TE;Ljava/util/OptionalInt;>;>;>; -
in 105
class net/minecraft/resources/RegistryResourceAccess 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry static,final
 method public,abstract listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public,abstract parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Ljava/util/Optional<Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>;>;>; -
 method public,static forResourceManager (Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryResourceAccess; - -
in 231
class net/minecraft/resources/RegistryResourceAccess 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$EntryThunk net/minecraft/resources/RegistryResourceAccess EntryThunk public,static,interface,abstract
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry static,final
 method public,abstract listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Map; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<TE;>;Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
 method public,abstract getResource (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
 method public,static forResourceManager (Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryResourceAccess; - -
in 109
class net/minecraft/resources/RegistryResourceAccess 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry private,static,final
 method public,abstract listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public,abstract parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Ljava/util/Optional<Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>;>;>; -
 method public,static forResourceManager (Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryResourceAccess; - -
in 232
class net/minecraft/resources/RegistryResourceAccess 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$EntryThunk net/minecraft/resources/RegistryResourceAccess EntryThunk public,static,interface,abstract
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry private,static,final
 method public,abstract listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Map; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<TE;>;Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
 method public,abstract getResource (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
 method public,static forResourceManager (Lnet/minecraft/server/packs/resources/ResourceManager;)Lnet/minecraft/resources/RegistryResourceAccess; - -
in 83
class net/minecraft/resources/RegistryResourceAccess$EntryThunk 61 public,interface,abstract java/lang/Object - <E:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/RegistryResourceAccess$EntryThunk net/minecraft/resources/RegistryResourceAccess EntryThunk public,static,interface,abstract
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 method public,abstract parseElement (Lcom/mojang/serialization/DynamicOps;Lcom/mojang/serialization/Decoder;)Lcom/mojang/serialization/DataResult; (Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lcom/mojang/serialization/Decoder<TE;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>;>; -
in 105
class net/minecraft/resources/RegistryResourceAccess$InMemoryStorage 61 public,final,super java/lang/Object net/minecraft/resources/RegistryResourceAccess -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry static,final
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public add (Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Encoder;ILjava/lang/Object;Lcom/mojang/serialization/Lifecycle;)V <E:Ljava/lang/Object;>(Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Encoder<TE;>;ITE;Lcom/mojang/serialization/Lifecycle;)V -
 method public listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Ljava/util/Optional<Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>;>;>; -
in 231
class net/minecraft/resources/RegistryResourceAccess$InMemoryStorage 61 public,final,super java/lang/Object net/minecraft/resources/RegistryResourceAccess -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry static,final
 inner net/minecraft/resources/RegistryResourceAccess$EntryThunk net/minecraft/resources/RegistryResourceAccess EntryThunk public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public add (Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Encoder;ILjava/lang/Object;Lcom/mojang/serialization/Lifecycle;)V <E:Ljava/lang/Object;>(Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Encoder<TE;>;ITE;Lcom/mojang/serialization/Lifecycle;)V -
 method public listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Map; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<TE;>;Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
 method public getResource (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
in 109
class net/minecraft/resources/RegistryResourceAccess$InMemoryStorage 61 public,final,super java/lang/Object net/minecraft/resources/RegistryResourceAccess -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry private,static,final
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public add (Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Encoder;ILjava/lang/Object;Lcom/mojang/serialization/Lifecycle;)V <E:Ljava/lang/Object;>(Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Encoder<TE;>;ITE;Lcom/mojang/serialization/Lifecycle;)V -
 method public listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Collection; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Collection<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public parseElement (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Decoder;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Decoder<TE;>;)Ljava/util/Optional<Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>;>;>; -
in 232
class net/minecraft/resources/RegistryResourceAccess$InMemoryStorage 61 public,final,super java/lang/Object net/minecraft/resources/RegistryResourceAccess -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry private,static,final
 inner net/minecraft/resources/RegistryResourceAccess$EntryThunk net/minecraft/resources/RegistryResourceAccess EntryThunk public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public add (Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Encoder;ILjava/lang/Object;Lcom/mojang/serialization/Lifecycle;)V <E:Ljava/lang/Object;>(Lnet/minecraft/core/RegistryAccess;Lnet/minecraft/resources/ResourceKey<TE;>;Lcom/mojang/serialization/Encoder<TE;>;ITE;Lcom/mojang/serialization/Lifecycle;)V -
 method public listResources (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Map; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Map<Lnet/minecraft/resources/ResourceKey<TE;>;Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
 method public getResource (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<TE;>;)Ljava/util/Optional<Lnet/minecraft/resources/RegistryResourceAccess$EntryThunk<TE;>;>; -
in 84
class net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry 61 final,super java/lang/Record - -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public data ()Lcom/google/gson/JsonElement; - -
 method public id ()I - -
 method public lifecycle ()Lcom/mojang/serialization/Lifecycle; - -
in 83
class net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry 61 final,super java/lang/Record - -
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage net/minecraft/resources/RegistryResourceAccess InMemoryStorage public,static,final
 inner net/minecraft/resources/RegistryResourceAccess$InMemoryStorage$Entry net/minecraft/resources/RegistryResourceAccess$InMemoryStorage Entry static,final
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public parse (Lcom/mojang/serialization/DynamicOps;Lcom/mojang/serialization/Decoder;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<Lcom/google/gson/JsonElement;>;Lcom/mojang/serialization/Decoder<TE;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public data ()Lcom/google/gson/JsonElement; - -
 method public id ()I - -
 method public lifecycle ()Lcom/mojang/serialization/Lifecycle; - -
in 34
class net/minecraft/resources/RegistryResourceAccess$ParsedEntry 61 public,final,super java/lang/Record - <E:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/resources/RegistryResourceAccess$ParsedEntry net/minecraft/resources/RegistryResourceAccess ParsedEntry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/Object;Ljava/util/OptionalInt;)V (TE;Ljava/util/OptionalInt;)V -
 method public,static createWithoutId (Ljava/lang/Object;)Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry; <E:Ljava/lang/Object;>(TE;)Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>; -
 method public,static createWithId (Ljava/lang/Object;I)Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry; <E:Ljava/lang/Object;>(TE;I)Lnet/minecraft/resources/RegistryResourceAccess$ParsedEntry<TE;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()Ljava/lang/Object; ()TE; -
 method public fixedId ()Ljava/util/OptionalInt; - -
in 86
class net/minecraft/resources/RegistryWriteOps 52 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryWriteOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryWriteOps<TT;>; -
 method protected encode (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(TE;TT;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/DataResult<TT;>; -
in 82
class net/minecraft/resources/RegistryWriteOps 60 public,super net/minecraft/resources/DelegatingOps - <T:Ljava/lang/Object;>Lnet/minecraft/resources/DelegatingOps<TT;>;
 method public,static create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryWriteOps; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/core/RegistryAccess;)Lnet/minecraft/resources/RegistryWriteOps<TT;>; -
 method protected encode (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/resources/ResourceKey;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/DataResult; <E:Ljava/lang/Object;>(TE;TT;Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;Lcom/mojang/serialization/Codec<TE;>;)Lcom/mojang/serialization/DataResult<TT;>; -
in 181
class net/minecraft/resources/ResourceKey 52 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public,static elementKey (Lnet/minecraft/resources/ResourceKey;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
in 104
class net/minecraft/resources/ResourceKey 60 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public,static elementKey (Lnet/minecraft/resources/ResourceKey;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public getRegistryName ()Lnet/minecraft/resources/ResourceLocation; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 105
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public,static elementKey (Lnet/minecraft/resources/ResourceKey;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public getRegistryName ()Lnet/minecraft/resources/ResourceLocation; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 231
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 45
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 206
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
in 556
class net/minecraft/resources/ResourceKey 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static streamCodec (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/network/codec/StreamCodec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registryKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
in 145
class net/minecraft/resources/ResourceKey 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static streamCodec (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/network/codec/StreamCodec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public identifier ()Lnet/minecraft/resources/Identifier; - -
 method public registry ()Lnet/minecraft/resources/Identifier; - -
 method public registryKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
in 190
class net/minecraft/resources/ResourceKey 52 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public,static elementKey (Lnet/minecraft/resources/ResourceKey;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public getRegistryName ()Lnet/minecraft/resources/ResourceLocation; - -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 191
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 538
class net/minecraft/resources/ResourceKey 65 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static streamCodec (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/network/codec/StreamCodec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registryKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 48
class net/minecraft/resources/ResourceKey 65 public,super java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceKey<*>;>;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static streamCodec (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/network/codec/StreamCodec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public identifier ()Lnet/minecraft/resources/Identifier; - -
 method public registry ()Lnet/minecraft/resources/Identifier; - -
 method public registryKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public compareTo (Lnet/minecraft/resources/ResourceKey;)I (Lnet/minecraft/resources/ResourceKey<*>;)I -
in 108
class net/minecraft/resources/ResourceKey 60 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public,static elementKey (Lnet/minecraft/resources/ResourceKey;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
in 109
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public,static elementKey (Lnet/minecraft/resources/ResourceKey;)Ljava/util/function/Function; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
in 232
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
in 407
class net/minecraft/resources/ResourceKey 61 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
in 334
class net/minecraft/resources/ResourceKey 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static streamCodec (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/network/codec/StreamCodec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public registryKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
in 142
class net/minecraft/resources/ResourceKey 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static codec (Lnet/minecraft/resources/ResourceKey;)Lcom/mojang/serialization/Codec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static streamCodec (Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/network/codec/StreamCodec; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;)Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceKey<TT;>;>; -
 method public,static create (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TT;>;>;Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey<TT;>; -
 method public,static createRegistryKey (Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey; <T:Ljava/lang/Object;>(Lnet/minecraft/resources/Identifier;)Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
 method public toString ()Ljava/lang/String; - -
 method public isFor (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<*>;>;)Z -
 method public cast (Lnet/minecraft/resources/ResourceKey;)Ljava/util/Optional; <E:Ljava/lang/Object;>(Lnet/minecraft/resources/ResourceKey<+Lnet/minecraft/core/Registry<TE;>;>;)Ljava/util/Optional<Lnet/minecraft/resources/ResourceKey<TE;>;>; -
 method public identifier ()Lnet/minecraft/resources/Identifier; - -
 method public registry ()Lnet/minecraft/resources/Identifier; - -
 method public registryKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/core/Registry<TT;>;>; -
in 220
class net/minecraft/resources/ResourceKey$InternKey 61 final,super java/lang/Record - -
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
in 95
class net/minecraft/resources/ResourceKey$InternKey 65 final,super java/lang/Record - -
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public registry ()Lnet/minecraft/resources/ResourceLocation; - -
 method public location ()Lnet/minecraft/resources/ResourceLocation; - -
in 2
class net/minecraft/resources/ResourceKey$InternKey 65 final,super java/lang/Record - -
 inner net/minecraft/resources/ResourceKey$InternKey net/minecraft/resources/ResourceKey InternKey static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public registry ()Lnet/minecraft/resources/Identifier; - -
 method public identifier ()Lnet/minecraft/resources/Identifier; - -
in 59
class net/minecraft/resources/ResourceLocation 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public a (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
in 304
class net/minecraft/resources/ResourceLocation 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public a (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
in 219
class net/minecraft/resources/ResourceLocation 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 181
class net/minecraft/resources/ResourceLocation 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 104
class net/minecraft/resources/ResourceLocation 60 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 105
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$ForgeDummy net/minecraft/resources/ResourceLocation ForgeDummy private,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static,deprecated of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
in 231
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$ForgeDummy net/minecraft/resources/ResourceLocation ForgeDummy private,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static,deprecated of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 203
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 204
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public,deprecated <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public,static,deprecated of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
in 273
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 530
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 184
class net/minecraft/resources/ResourceLocation 65 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 285
class net/minecraft/resources/ResourceLocation 65 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
in 149
class net/minecraft/resources/ResourceLocation 65 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
in 391
class net/minecraft/resources/ResourceLocation 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public a (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 190
class net/minecraft/resources/ResourceLocation 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 192
class net/minecraft/resources/ResourceLocation 65 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 279
class net/minecraft/resources/ResourceLocation 65 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
in 150
class net/minecraft/resources/ResourceLocation 65 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final ERROR_INVALID Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method public,static fromNamespaceAndPath (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static parse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static withDefaultNamespace (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static bySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBySeparator (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public compareNamespaced (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static readNonEmpty (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static isValidPath (Ljava/lang/String;)Z - -
 method public,static isValidNamespace (Ljava/lang/String;)Z - -
 method public,static validPathChar (C)Z - -
 method public,static validNamespaceChar (C)Z - -
in 108
class net/minecraft/resources/ResourceLocation 60 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 109
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 232
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 field protected,final namespace Ljava/lang/String; -
 field protected,final path Ljava/lang/String; -
 method protected <init> ([Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 210
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 322
class net/minecraft/resources/ResourceLocation 61 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final NAMESPACE_SEPARATOR C - I58
 field public,static,final DEFAULT_NAMESPACE Ljava/lang/String; - "minecraft"
 field public,static,final REALMS_NAMESPACE Ljava/lang/String; - "realms"
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation$Dummy;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public,static of (Ljava/lang/String;C)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryParse (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static tryBuild (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected,static decompose (Ljava/lang/String;C)[Ljava/lang/String; - -
 method public,static read (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/resources/ResourceLocation;>; -
 method public getPath ()Ljava/lang/String; - -
 method public getNamespace ()Ljava/lang/String; - -
 method public withPath (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withPath (Ljava/util/function/UnaryOperator;)Lnet/minecraft/resources/ResourceLocation; (Ljava/util/function/UnaryOperator<Ljava/lang/String;>;)Lnet/minecraft/resources/ResourceLocation; -
 method public withPrefix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public withSuffix (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public compareTo (Lnet/minecraft/resources/ResourceLocation;)I - -
 method public toDebugFileName ()Ljava/lang/String; - -
 method public toLanguageKey ()Ljava/lang/String; - -
 method public toShortLanguageKey ()Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;)Ljava/lang/String; - -
 method public toLanguageKey (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static read (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/resources/ResourceLocation; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static isAllowedInResourceLocation (C)Z - -
 method public,static validPathChar (C)Z - -
 method public,static isValidResourceLocation (Ljava/lang/String;)Z - -
in 220
class net/minecraft/resources/ResourceLocation$Dummy 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
in 224
class net/minecraft/resources/ResourceLocation$Dummy 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/resources/ResourceLocation$Dummy net/minecraft/resources/ResourceLocation Dummy protected,static,interface,abstract
in 44
class net/minecraft/resources/ResourceLocation$ForgeDummy 61 interface,abstract java/lang/Object - -
 inner net/minecraft/resources/ResourceLocation$ForgeDummy net/minecraft/resources/ResourceLocation ForgeDummy private,static,interface,abstract
in 307
class net/minecraft/resources/ResourceLocation$Serializer 52 public,super java/lang/Object com/google/gson/JsonDeserializer,com/google/gson/JsonSerializer Ljava/lang/Object;Lcom/google/gson/JsonDeserializer<Lnet/minecraft/resources/ResourceLocation;>;Lcom/google/gson/JsonSerializer<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 method public <init> ()V - -
 method public a (Lcom/google/gson/JsonElement;Ljava/lang/reflect/Type;Lcom/google/gson/JsonDeserializationContext;)Lnet/minecraft/resources/ResourceLocation; - com/google/gson/JsonParseException
 method public a (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/reflect/Type;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; - -
in 197
class net/minecraft/resources/ResourceLocation$Serializer 52 public,super java/lang/Object com/google/gson/JsonDeserializer,com/google/gson/JsonSerializer Ljava/lang/Object;Lcom/google/gson/JsonDeserializer<Lnet/minecraft/resources/ResourceLocation;>;Lcom/google/gson/JsonSerializer<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 method public <init> ()V - -
 method public deserialize (Lcom/google/gson/JsonElement;Ljava/lang/reflect/Type;Lcom/google/gson/JsonDeserializationContext;)Lnet/minecraft/resources/ResourceLocation; - com/google/gson/JsonParseException
 method public serialize (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/reflect/Type;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; - -
in 82
class net/minecraft/resources/ResourceLocation$Serializer 60 public,super java/lang/Object com/google/gson/JsonDeserializer,com/google/gson/JsonSerializer Ljava/lang/Object;Lcom/google/gson/JsonDeserializer<Lnet/minecraft/resources/ResourceLocation;>;Lcom/google/gson/JsonSerializer<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 method public <init> ()V - -
 method public deserialize (Lcom/google/gson/JsonElement;Ljava/lang/reflect/Type;Lcom/google/gson/JsonDeserializationContext;)Lnet/minecraft/resources/ResourceLocation; - com/google/gson/JsonParseException
 method public serialize (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/reflect/Type;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; - -
in 93
class net/minecraft/resources/ResourceLocation$Serializer 61 public,super java/lang/Object com/google/gson/JsonDeserializer,com/google/gson/JsonSerializer Ljava/lang/Object;Lcom/google/gson/JsonDeserializer<Lnet/minecraft/resources/ResourceLocation;>;Lcom/google/gson/JsonSerializer<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 method public <init> ()V - -
 method public deserialize (Lcom/google/gson/JsonElement;Ljava/lang/reflect/Type;Lcom/google/gson/JsonDeserializationContext;)Lnet/minecraft/resources/ResourceLocation; - com/google/gson/JsonParseException
 method public serialize (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/reflect/Type;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; - -
in 128
class net/minecraft/resources/ResourceLocation$Serializer 65 public,super java/lang/Object com/google/gson/JsonDeserializer,com/google/gson/JsonSerializer Ljava/lang/Object;Lcom/google/gson/JsonDeserializer<Lnet/minecraft/resources/ResourceLocation;>;Lcom/google/gson/JsonSerializer<Lnet/minecraft/resources/ResourceLocation;>;
 inner net/minecraft/resources/ResourceLocation$Serializer net/minecraft/resources/ResourceLocation Serializer public,static
 method public <init> ()V - -
 method public deserialize (Lcom/google/gson/JsonElement;Ljava/lang/reflect/Type;Lcom/google/gson/JsonDeserializationContext;)Lnet/minecraft/resources/ResourceLocation; - com/google/gson/JsonParseException
 method public serialize (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/reflect/Type;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; - -
