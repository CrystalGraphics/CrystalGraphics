cg-stub-db 1
in 2
class com/azure/json/JsonOptions 52 public,final,super java/lang/Object - -
 method public <init> ()V - -
 method public isNonNumericNumbersSupported ()Z - -
 method public setNonNumericNumbersSupported (Z)Lcom/azure/json/JsonOptions; - -
 method public isJsoncSupported ()Z - -
 method public setJsoncSupported (Z)Lcom/azure/json/JsonOptions; - -
in 2
class com/azure/json/JsonProvider 52 public,interface,abstract java/lang/Object - -
 method public,abstract createReader ([BLcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,abstract createReader (Ljava/lang/String;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,abstract createReader (Ljava/io/InputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,abstract createReader (Ljava/io/Reader;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,abstract createWriter (Ljava/io/OutputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract createWriter (Ljava/io/Writer;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 2
class com/azure/json/JsonProviders 52 public,final,super java/lang/Object - -
 method public,static createReader ([B)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createReader ([BLcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createReader (Ljava/lang/String;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createReader (Ljava/lang/String;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createReader (Ljava/io/InputStream;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createReader (Ljava/io/InputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createReader (Ljava/io/Reader;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createReader (Ljava/io/Reader;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static createWriter (Ljava/io/OutputStream;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static createWriter (Ljava/io/OutputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static createWriter (Ljava/io/Writer;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static createWriter (Ljava/io/Writer;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 2
class com/azure/json/JsonReader 52 public,super,abstract java/lang/Object java/io/Closeable -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,abstract currentToken ()Lcom/azure/json/JsonToken; - -
 method public,abstract nextToken ()Lcom/azure/json/JsonToken; - java/io/IOException
 method public,abstract close ()V - java/io/IOException
 method public,final isStartArrayOrObject ()Z - -
 method public,final isEndArrayOrObject ()Z - -
 method public,abstract getBinary ()[B - java/io/IOException
 method public,abstract getBoolean ()Z - java/io/IOException
 method public,abstract getFloat ()F - java/io/IOException
 method public,abstract getDouble ()D - java/io/IOException
 method public,abstract getInt ()I - java/io/IOException
 method public,abstract getLong ()J - java/io/IOException
 method public,abstract getString ()Ljava/lang/String; - java/io/IOException
 method public,abstract getFieldName ()Ljava/lang/String; - java/io/IOException
 method public,final getNullable (Lcom/azure/json/ReadValueCallback;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/azure/json/ReadValueCallback<Lcom/azure/json/JsonReader;TT;>;)TT; java/io/IOException
 method public,abstract skipChildren ()V - java/io/IOException
 method public,abstract bufferObject ()Lcom/azure/json/JsonReader; - java/io/IOException
 method public,abstract isResetSupported ()Z - -
 method public,abstract reset ()Lcom/azure/json/JsonReader; - java/io/IOException
 method public,final readChildren ()Ljava/lang/String; - java/io/IOException
 method public,final readChildren (Ljava/lang/StringBuilder;)V - java/io/IOException
 method public,final readRemainingFieldsAsJsonObject ()Ljava/lang/String; - java/io/IOException
 method public,final readRemainingFieldsAsJsonObject (Ljava/lang/StringBuilder;)V - java/io/IOException
 method public,final readObject (Lcom/azure/json/ReadValueCallback;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/azure/json/ReadValueCallback<Lcom/azure/json/JsonReader;TT;>;)TT; java/io/IOException
 method public,final readArray (Lcom/azure/json/ReadValueCallback;)Ljava/util/List; <T:Ljava/lang/Object;>(Lcom/azure/json/ReadValueCallback<Lcom/azure/json/JsonReader;TT;>;)Ljava/util/List<TT;>; java/io/IOException
 method public,final readMap (Lcom/azure/json/ReadValueCallback;)Ljava/util/Map; <T:Ljava/lang/Object;>(Lcom/azure/json/ReadValueCallback<Lcom/azure/json/JsonReader;TT;>;)Ljava/util/Map<Ljava/lang/String;TT;>; java/io/IOException
 method public,final readUntyped ()Ljava/lang/Object; - java/io/IOException
 method public,final getText ()Ljava/lang/String; - java/io/IOException
 method public getRawText ()Ljava/lang/String; - java/io/IOException
in 2
class com/azure/json/JsonSerializable 52 public,interface,abstract java/lang/Object - <T::Lcom/azure/json/JsonSerializable<TT;>;>Ljava/lang/Object;
 method public,abstract toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public toJson (Ljava/io/OutputStream;)V - java/io/IOException
 method public toJson (Ljava/io/Writer;)V - java/io/IOException
 method public toJsonString ()Ljava/lang/String; - java/io/IOException
 method public toJsonBytes ()[B - java/io/IOException
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/azure/json/JsonSerializable; <T::Lcom/azure/json/JsonSerializable<TT;>;>(Lcom/azure/json/JsonReader;)TT; java/io/IOException
 method public,static fromJson (Ljava/lang/String;)Lcom/azure/json/JsonSerializable; <T::Lcom/azure/json/JsonSerializable<TT;>;>(Ljava/lang/String;)TT; java/io/IOException
 method public,static fromJson ([B)Lcom/azure/json/JsonSerializable; <T::Lcom/azure/json/JsonSerializable<TT;>;>([B)TT; java/io/IOException
 method public,static fromJson (Ljava/io/InputStream;)Lcom/azure/json/JsonSerializable; <T::Lcom/azure/json/JsonSerializable<TT;>;>(Ljava/io/InputStream;)TT; java/io/IOException
 method public,static fromJson (Ljava/io/Reader;)Lcom/azure/json/JsonSerializable; <T::Lcom/azure/json/JsonSerializable<TT;>;>(Ljava/io/Reader;)TT; java/io/IOException
in 2
class com/azure/json/JsonToken 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/JsonToken;>;
 field public,static,final,enum START_OBJECT Lcom/azure/json/JsonToken; -
 field public,static,final,enum END_OBJECT Lcom/azure/json/JsonToken; -
 field public,static,final,enum START_ARRAY Lcom/azure/json/JsonToken; -
 field public,static,final,enum END_ARRAY Lcom/azure/json/JsonToken; -
 field public,static,final,enum FIELD_NAME Lcom/azure/json/JsonToken; -
 field public,static,final,enum BOOLEAN Lcom/azure/json/JsonToken; -
 field public,static,final,enum NULL Lcom/azure/json/JsonToken; -
 field public,static,final,enum NUMBER Lcom/azure/json/JsonToken; -
 field public,static,final,enum STRING Lcom/azure/json/JsonToken; -
 field public,static,final,enum END_DOCUMENT Lcom/azure/json/JsonToken; -
 method public,static values ()[Lcom/azure/json/JsonToken; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/JsonToken; - -
in 2
class com/azure/json/JsonWriteContext 52 public,final,super java/lang/Object - -
 field public,static,final ROOT Lcom/azure/json/JsonWriteContext; -
 field public,static,final COMPLETED Lcom/azure/json/JsonWriteContext; -
 method public getParent ()Lcom/azure/json/JsonWriteContext; - -
 method public getWriteState ()Lcom/azure/json/JsonWriteState; - -
 method public validateToken (Lcom/azure/json/JsonToken;)V - -
 method public updateContext (Lcom/azure/json/JsonToken;)Lcom/azure/json/JsonWriteContext; - -
in 2
class com/azure/json/JsonWriteState 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/JsonWriteState;>;
 field public,static,final,enum ROOT Lcom/azure/json/JsonWriteState; -
 field public,static,final,enum OBJECT Lcom/azure/json/JsonWriteState; -
 field public,static,final,enum ARRAY Lcom/azure/json/JsonWriteState; -
 field public,static,final,enum FIELD Lcom/azure/json/JsonWriteState; -
 field public,static,final,enum COMPLETED Lcom/azure/json/JsonWriteState; -
 method public,static values ()[Lcom/azure/json/JsonWriteState; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/JsonWriteState; - -
in 2
class com/azure/json/JsonWriter 52 public,super,abstract java/lang/Object java/io/Closeable -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public,abstract getWriteContext ()Lcom/azure/json/JsonWriteContext; - -
 method public,abstract close ()V - java/io/IOException
 method public,abstract flush ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeStartObject ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeStartObject (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeEndObject ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeStartArray ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeStartArray (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeEndArray ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeFieldName (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeJson (Lcom/azure/json/JsonSerializable;)Lcom/azure/json/JsonWriter; (Lcom/azure/json/JsonSerializable<*>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeArray ([Ljava/lang/Object;Lcom/azure/json/WriteValueCallback;)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>([TT;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public writeArray ([Ljava/lang/Object;Lcom/azure/json/WriteValueCallback;Z)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>([TT;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;Z)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeArray (Ljava/lang/Iterable;Lcom/azure/json/WriteValueCallback;)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public writeArray (Ljava/lang/Iterable;Lcom/azure/json/WriteValueCallback;Z)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;Z)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeMap (Ljava/util/Map;Lcom/azure/json/WriteValueCallback;)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/util/Map<Ljava/lang/String;TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public writeMap (Ljava/util/Map;Lcom/azure/json/WriteValueCallback;Z)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/util/Map<Ljava/lang/String;TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;Z)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,abstract writeBinary ([B)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeBoolean (Z)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeBoolean (Ljava/lang/Boolean;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeDouble (D)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeFloat (F)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeInt (I)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeLong (J)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeNull ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeNumber (Ljava/lang/Number;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeString (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,abstract writeRawValue (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeNullableField (Ljava/lang/String;Ljava/lang/Object;Lcom/azure/json/WriteValueCallback;)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeJsonField (Ljava/lang/String;Lcom/azure/json/JsonSerializable;)Lcom/azure/json/JsonWriter; (Ljava/lang/String;Lcom/azure/json/JsonSerializable<*>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeArrayField (Ljava/lang/String;[Ljava/lang/Object;Lcom/azure/json/WriteValueCallback;)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/String;[TT;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public writeArrayField (Ljava/lang/String;[Ljava/lang/Object;Lcom/azure/json/WriteValueCallback;Z)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/String;[TT;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;Z)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeArrayField (Ljava/lang/String;Ljava/lang/Iterable;Lcom/azure/json/WriteValueCallback;)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Iterable<TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public writeArrayField (Ljava/lang/String;Ljava/lang/Iterable;Lcom/azure/json/WriteValueCallback;Z)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Iterable<TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;Z)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeMapField (Ljava/lang/String;Ljava/util/Map;Lcom/azure/json/WriteValueCallback;)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;)Lcom/azure/json/JsonWriter; java/io/IOException
 method public writeMapField (Ljava/lang/String;Ljava/util/Map;Lcom/azure/json/WriteValueCallback;Z)Lcom/azure/json/JsonWriter; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;TT;>;Lcom/azure/json/WriteValueCallback<Lcom/azure/json/JsonWriter;TT;>;Z)Lcom/azure/json/JsonWriter; java/io/IOException
 method public,final writeBinaryField (Ljava/lang/String;[B)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeBooleanField (Ljava/lang/String;Z)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeBooleanField (Ljava/lang/String;Ljava/lang/Boolean;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeDoubleField (Ljava/lang/String;D)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeFloatField (Ljava/lang/String;F)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeIntField (Ljava/lang/String;I)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeLongField (Ljava/lang/String;J)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeNullField (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeNumberField (Ljava/lang/String;Ljava/lang/Number;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeStringField (Ljava/lang/String;Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,final writeRawField (Ljava/lang/String;Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeUntypedField (Ljava/lang/String;Ljava/lang/Object;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeUntyped (Ljava/lang/Object;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 2
class com/azure/json/ReadValueCallback 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract read (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR; java/io/IOException
in 2
class com/azure/json/WriteValueCallback 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract write (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V java/io/IOException
in 2
class com/azure/json/implementation/DefaultJsonProvider 52 public,final,super java/lang/Object com/azure/json/JsonProvider -
 method public <init> ()V - -
 method public createReader ([BLcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public createReader (Ljava/lang/String;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public createReader (Ljava/io/InputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public createReader (Ljava/io/Reader;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public createWriter (Ljava/io/OutputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public createWriter (Ljava/io/Writer;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 2
class com/azure/json/implementation/DefaultJsonReader 52 public,final,super com/azure/json/JsonReader - -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 method public,static fromBytes ([BLcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static fromString (Ljava/lang/String;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static fromStream (Ljava/io/InputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public,static fromReader (Ljava/io/Reader;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonReader; - java/io/IOException
 method public currentToken ()Lcom/azure/json/JsonToken; - -
 method public nextToken ()Lcom/azure/json/JsonToken; - java/io/IOException
 method public getBinary ()[B - java/io/IOException
 method public getBoolean ()Z - java/io/IOException
 method public getDouble ()D - java/io/IOException
 method public getFloat ()F - java/io/IOException
 method public getInt ()I - java/io/IOException
 method public getLong ()J - java/io/IOException
 method public getString ()Ljava/lang/String; - java/io/IOException
 method public getFieldName ()Ljava/lang/String; - java/io/IOException
 method public skipChildren ()V - java/io/IOException
 method public bufferObject ()Lcom/azure/json/JsonReader; - java/io/IOException
 method public isResetSupported ()Z - -
 method public reset ()Lcom/azure/json/JsonReader; - java/io/IOException
 method public close ()V - java/io/IOException
in 2
class com/azure/json/implementation/DefaultJsonWriter 52 public,final,super com/azure/json/JsonWriter - -
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 method public,static toStream (Ljava/io/OutputStream;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static toWriter (Ljava/io/Writer;Lcom/azure/json/JsonOptions;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public flush ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeStartObject ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeEndObject ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeStartArray ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeEndArray ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeFieldName (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeBinary ([B)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeBoolean (Z)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeDouble (D)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeFloat (F)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeInt (I)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeLong (J)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeNull ()Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeString (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public writeRawValue (Ljava/lang/String;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public getWriteContext ()Lcom/azure/json/JsonWriteContext; - -
 method public close ()V - java/io/IOException
in 2
class com/azure/json/implementation/StringBuilderWriter 52 public,final,super java/io/Writer - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/StringBuilder;)V - -
 method public write (I)V - java/io/IOException
 method public write ([C)V - java/io/IOException
 method public write (Ljava/lang/String;)V - java/io/IOException
 method public write (Ljava/lang/String;II)V - java/io/IOException
 method public append (Ljava/lang/CharSequence;)Ljava/io/Writer; - java/io/IOException
 method public append (Ljava/lang/CharSequence;II)Ljava/io/Writer; - java/io/IOException
 method public append (C)Ljava/io/Writer; - java/io/IOException
 method public write ([CII)V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public close ()V - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/Base64Variant 52 public,final,super java/lang/Object java/io/Serializable -
 inner com/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour com/azure/json/implementation/jackson/core/Base64Variant PaddingReadBehaviour public,static,final,enum
 field public,static,final BASE64_VALUE_INVALID I - I-1
 field public,static,final BASE64_VALUE_PADDING I - I-2
 method public <init> (Ljava/lang/String;Ljava/lang/String;ZCI)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/lang/String;I)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/lang/String;ZCI)V - -
 method public withPaddingAllowed ()Lcom/azure/json/implementation/jackson/core/Base64Variant; - -
 method public withPaddingRequired ()Lcom/azure/json/implementation/jackson/core/Base64Variant; - -
 method public withPaddingForbidden ()Lcom/azure/json/implementation/jackson/core/Base64Variant; - -
 method public withReadPadding (Lcom/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour;)Lcom/azure/json/implementation/jackson/core/Base64Variant; - -
 method public withWritePadding (Z)Lcom/azure/json/implementation/jackson/core/Base64Variant; - -
 method public getName ()Ljava/lang/String; - -
 method public usesPadding ()Z - -
 method public requiresPaddingOnRead ()Z - -
 method public acceptsPaddingOnRead ()Z - -
 method public usesPaddingChar (C)Z - -
 method public usesPaddingChar (I)Z - -
 method public getPaddingChar ()C - -
 method public getMaxLineLength ()I - -
 method public decodeBase64Char (C)I - -
 method public decodeBase64Char (I)I - -
 method public encodeBase64Chunk (I[CI)I - -
 method public encodeBase64Partial (II[CI)I - -
 method public encodeBase64Chunk (I[BI)I - -
 method public encodeBase64Partial (II[BI)I - -
 method public decode (Ljava/lang/String;)[B - java/lang/IllegalArgumentException
 method public decode (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/util/ByteArrayBuilder;)V - java/lang/IllegalArgumentException
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public missingPaddingMessage ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour;>;
 inner com/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour com/azure/json/implementation/jackson/core/Base64Variant PaddingReadBehaviour public,static,final,enum
 field public,static,final,enum PADDING_FORBIDDEN Lcom/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour; -
 field public,static,final,enum PADDING_REQUIRED Lcom/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour; -
 field public,static,final,enum PADDING_ALLOWED Lcom/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/Base64Variant$PaddingReadBehaviour; - -
in 2
class com/azure/json/implementation/jackson/core/Base64Variants 52 public,final,super java/lang/Object - -
 field public,static,final MIME Lcom/azure/json/implementation/jackson/core/Base64Variant; -
 field public,static,final MIME_NO_LINEFEEDS Lcom/azure/json/implementation/jackson/core/Base64Variant; -
 field public,static,final PEM Lcom/azure/json/implementation/jackson/core/Base64Variant; -
 field public,static,final MODIFIED_FOR_URL Lcom/azure/json/implementation/jackson/core/Base64Variant; -
 method public <init> ()V - -
 method public,static getDefaultVariant ()Lcom/azure/json/implementation/jackson/core/Base64Variant; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/Base64Variant; - java/lang/IllegalArgumentException
in 2
class com/azure/json/implementation/jackson/core/FormatFeature 52 public,interface,abstract java/lang/Object com/azure/json/implementation/jackson/core/util/JacksonFeature -
 method public,abstract enabledByDefault ()Z - -
 method public,abstract getMask ()I - -
 method public,abstract enabledIn (I)Z - -
in 2
class com/azure/json/implementation/jackson/core/FormatSchema 52 public,interface,abstract java/lang/Object - -
 method public,abstract getSchemaType ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/JacksonException 52 public,super,abstract java/io/IOException - -
 method protected <init> (Ljava/lang/String;)V - -
 method protected <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,abstract getLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,abstract getProcessor ()Ljava/lang/Object; - -
in 2
class com/azure/json/implementation/jackson/core/JsonEncoding 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/JsonEncoding;>;
 field public,static,final,enum UTF8 Lcom/azure/json/implementation/jackson/core/JsonEncoding; -
 field public,static,final,enum UTF16_BE Lcom/azure/json/implementation/jackson/core/JsonEncoding; -
 field public,static,final,enum UTF16_LE Lcom/azure/json/implementation/jackson/core/JsonEncoding; -
 field public,static,final,enum UTF32_BE Lcom/azure/json/implementation/jackson/core/JsonEncoding; -
 field public,static,final,enum UTF32_LE Lcom/azure/json/implementation/jackson/core/JsonEncoding; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/JsonEncoding; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonEncoding; - -
 method public getJavaName ()Ljava/lang/String; - -
 method public isBigEndian ()Z - -
 method public bits ()I - -
in 2
class com/azure/json/implementation/jackson/core/JsonFactory 52 public,super com/azure/json/implementation/jackson/core/TokenStreamFactory com/azure/json/implementation/jackson/core/Versioned,java/io/Serializable -
 inner com/azure/json/implementation/jackson/core/JsonFactory$Feature com/azure/json/implementation/jackson/core/JsonFactory Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field public,static,final FORMAT_NAME_JSON Ljava/lang/String; - "JSON"
 field protected,static,final DEFAULT_FACTORY_FEATURE_FLAGS I -
 field protected,static,final DEFAULT_PARSER_FEATURE_FLAGS I -
 field protected,static,final DEFAULT_GENERATOR_FEATURE_FLAGS I -
 field public,static,final DEFAULT_ROOT_VALUE_SEPARATOR Lcom/azure/json/implementation/jackson/core/SerializableString; -
 field public,static,final DEFAULT_QUOTE_CHAR C - I34
 field protected,final,transient _rootCharSymbols Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer; -
 field protected,final,transient _byteSymbolCanonicalizer Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer; -
 field protected _factoryFeatures I -
 field protected _parserFeatures I -
 field protected _generatorFeatures I -
 field protected _objectCodec Lcom/azure/json/implementation/jackson/core/ObjectCodec; -
 field protected _characterEscapes Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes; -
 field protected _inputDecorator Lcom/azure/json/implementation/jackson/core/io/InputDecorator; -
 field protected _outputDecorator Lcom/azure/json/implementation/jackson/core/io/OutputDecorator; -
 field protected _rootValueSeparator Lcom/azure/json/implementation/jackson/core/SerializableString; -
 field protected _maximumNonEscapedChar I -
 field protected,final _quoteChar C -
 method public <init> ()V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/JsonFactory;Lcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder;)V - -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/TSFBuilder;Z)V (Lcom/azure/json/implementation/jackson/core/TSFBuilder<**>;Z)V -
 method public,static builder ()Lcom/azure/json/implementation/jackson/core/TSFBuilder; ()Lcom/azure/json/implementation/jackson/core/TSFBuilder<**>; -
 method public copy ()Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method protected _checkInvalidCopy (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method protected readResolve ()Ljava/lang/Object; - -
 method public canHandleBinaryNatively ()Z - -
 method public canUseCharArrays ()Z - -
 method public getFormatName ()Ljava/lang/String; - -
 method public version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public,final,deprecated configure (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;Z)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public,deprecated enable (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public,deprecated disable (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public,final isEnabled (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;)Z - -
 method public,final configure (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;Z)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public,final isEnabled (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Z - -
 method public,final isEnabled (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)Z - -
 method public,deprecated setInputDecorator (Lcom/azure/json/implementation/jackson/core/io/InputDecorator;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public,final configure (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;Z)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public,final isEnabled (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Z - -
 method public,final isEnabled (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)Z - -
 method public,deprecated setOutputDecorator (Lcom/azure/json/implementation/jackson/core/io/OutputDecorator;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public createParser (Ljava/io/File;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public createParser (Ljava/net/URL;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public createParser (Ljava/io/InputStream;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public createParser (Ljava/io/Reader;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public createParser ([B)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public createParser ([BII)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public createParser (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public createGenerator (Ljava/io/OutputStream;Lcom/azure/json/implementation/jackson/core/JsonEncoding;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method public createGenerator (Ljava/io/OutputStream;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method public createGenerator (Ljava/io/Writer;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method public,deprecated createJsonParser (Ljava/io/File;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,deprecated createJsonParser (Ljava/net/URL;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,deprecated createJsonParser (Ljava/io/InputStream;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,deprecated createJsonParser (Ljava/io/Reader;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,deprecated createJsonParser ([B)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,deprecated createJsonParser ([BII)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,deprecated createJsonParser (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,deprecated createJsonGenerator (Ljava/io/OutputStream;Lcom/azure/json/implementation/jackson/core/JsonEncoding;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method public,deprecated createJsonGenerator (Ljava/io/Writer;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method public,deprecated createJsonGenerator (Ljava/io/OutputStream;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method protected _createParser (Ljava/io/InputStream;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method protected _createParser (Ljava/io/Reader;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method protected _createParser ([CIILcom/azure/json/implementation/jackson/core/io/IOContext;Z)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method protected _createParser ([BIILcom/azure/json/implementation/jackson/core/io/IOContext;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method protected _createGenerator (Ljava/io/Writer;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method protected _createUTF8Generator (Ljava/io/OutputStream;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method protected _createWriter (Ljava/io/OutputStream;Lcom/azure/json/implementation/jackson/core/JsonEncoding;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Ljava/io/Writer; - java/io/IOException
 method protected,final _decorate (Ljava/io/InputStream;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Ljava/io/InputStream; - java/io/IOException
 method protected,final _decorate (Ljava/io/Reader;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Ljava/io/Reader; - java/io/IOException
 method protected,final _decorate (Ljava/io/OutputStream;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Ljava/io/OutputStream; - java/io/IOException
 method protected,final _decorate (Ljava/io/Writer;Lcom/azure/json/implementation/jackson/core/io/IOContext;)Ljava/io/Writer; - java/io/IOException
 method public _getBufferRecycler ()Lcom/azure/json/implementation/jackson/core/util/BufferRecycler; - -
 method protected _createContext (Lcom/azure/json/implementation/jackson/core/io/ContentReference;Z)Lcom/azure/json/implementation/jackson/core/io/IOContext; - -
 method protected,deprecated _createContext (Ljava/lang/Object;Z)Lcom/azure/json/implementation/jackson/core/io/IOContext; - -
 method protected _createContentReference (Ljava/lang/Object;)Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method protected _createContentReference (Ljava/lang/Object;II)Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
in 2
class com/azure/json/implementation/jackson/core/JsonFactory$Feature 52 public,final,super,enum java/lang/Enum com/azure/json/implementation/jackson/core/util/JacksonFeature Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;>;Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;
 inner com/azure/json/implementation/jackson/core/JsonFactory$Feature com/azure/json/implementation/jackson/core/JsonFactory Feature public,static,final,enum
 field public,static,final,enum INTERN_FIELD_NAMES Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature; -
 field public,static,final,enum CANONICALIZE_FIELD_NAMES Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature; -
 field public,static,final,enum FAIL_ON_SYMBOL_HASH_OVERFLOW Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature; -
 field public,static,final,enum USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature; - -
 method public,static collectDefaults ()I - -
 method public enabledByDefault ()Z - -
 method public enabledIn (I)Z - -
 method public getMask ()I - -
in 2
class com/azure/json/implementation/jackson/core/JsonFactoryBuilder 52 public,super com/azure/json/implementation/jackson/core/TSFBuilder - Lcom/azure/json/implementation/jackson/core/TSFBuilder<Lcom/azure/json/implementation/jackson/core/JsonFactory;Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder;>;
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field protected _characterEscapes Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes; -
 field protected _rootValueSeparator Lcom/azure/json/implementation/jackson/core/SerializableString; -
 field protected _maximumNonEscapedChar I -
 field protected _quoteChar C -
 method public <init> ()V - -
 method public enable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public,varargs enable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public,varargs disable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public configure (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;Z)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public enable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public,varargs enable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public,varargs disable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public configure (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;Z)Lcom/azure/json/implementation/jackson/core/JsonFactoryBuilder; - -
 method public build ()Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
in 2
class com/azure/json/implementation/jackson/core/JsonGenerationException 52 public,super com/azure/json/implementation/jackson/core/exc/StreamWriteException - -
 method public,deprecated <init> (Ljava/lang/Throwable;)V - -
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public,deprecated <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonGenerator;)V - -
 method public getProcessor ()Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
in 2
class com/azure/json/implementation/jackson/core/JsonGenerator 52 public,super,abstract java/lang/Object java/io/Closeable,java/io/Flushable,com/azure/json/implementation/jackson/core/Versioned -
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonParser$NumberType com/azure/json/implementation/jackson/core/JsonParser NumberType public,static,final,enum
 field protected,static,final DEFAULT_WRITE_CAPABILITIES Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamWriteCapability;>;
 field protected,static,final DEFAULT_TEXTUAL_WRITE_CAPABILITIES Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamWriteCapability;>;
 method protected <init> ()V - -
 method public,abstract setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public,abstract getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public,abstract version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public,abstract getOutputContext ()Lcom/azure/json/implementation/jackson/core/JsonStreamContext; - -
 method public getOutputTarget ()Ljava/lang/Object; - -
 method public currentValue ()Ljava/lang/Object; - -
 method public assignCurrentValue (Ljava/lang/Object;)V - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public,abstract enable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public,abstract disable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public,final configure (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;Z)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public,abstract isEnabled (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Z - -
 method public isEnabled (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)Z - -
 method public,abstract getFeatureMask ()I - -
 method public,abstract,deprecated setFeatureMask (I)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public overrideStdFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public overrideFormatFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public setSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)V - -
 method public getSchema ()Lcom/azure/json/implementation/jackson/core/FormatSchema; - -
 method public setHighestNonEscapedChar (I)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public getHighestEscapedChar ()I - -
 method public getCharacterEscapes ()Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes; - -
 method public setCharacterEscapes (Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public setRootValueSeparator (Lcom/azure/json/implementation/jackson/core/SerializableString;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public getOutputBuffered ()I - -
 method public canUseSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)Z - -
 method public canWriteObjectId ()Z - -
 method public canWriteTypeId ()Z - -
 method public canWriteBinaryNatively ()Z - -
 method public canOmitFields ()Z - -
 method public canWriteFormattedNumbers ()Z - -
 method public getWriteCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamWriteCapability;>; -
 method public,abstract writeStartArray ()V - java/io/IOException
 method public,deprecated writeStartArray (I)V - java/io/IOException
 method public writeStartArray (Ljava/lang/Object;)V - java/io/IOException
 method public writeStartArray (Ljava/lang/Object;I)V - java/io/IOException
 method public,abstract writeEndArray ()V - java/io/IOException
 method public,abstract writeStartObject ()V - java/io/IOException
 method public writeStartObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeStartObject (Ljava/lang/Object;I)V - java/io/IOException
 method public,abstract writeEndObject ()V - java/io/IOException
 method public,abstract writeFieldName (Ljava/lang/String;)V - java/io/IOException
 method public,abstract writeFieldName (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeFieldId (J)V - java/io/IOException
 method public writeArray ([III)V - java/io/IOException
 method public writeArray ([JII)V - java/io/IOException
 method public writeArray ([DII)V - java/io/IOException
 method public writeArray ([Ljava/lang/String;II)V - java/io/IOException
 method public,abstract writeString (Ljava/lang/String;)V - java/io/IOException
 method public writeString (Ljava/io/Reader;I)V - java/io/IOException
 method public,abstract writeString ([CII)V - java/io/IOException
 method public,abstract writeString (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public,abstract writeRawUTF8String ([BII)V - java/io/IOException
 method public,abstract writeUTF8String ([BII)V - java/io/IOException
 method public,abstract writeRaw (Ljava/lang/String;)V - java/io/IOException
 method public,abstract writeRaw (Ljava/lang/String;II)V - java/io/IOException
 method public,abstract writeRaw ([CII)V - java/io/IOException
 method public,abstract writeRaw (C)V - java/io/IOException
 method public writeRaw (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public,abstract writeRawValue (Ljava/lang/String;)V - java/io/IOException
 method public,abstract writeRawValue (Ljava/lang/String;II)V - java/io/IOException
 method public,abstract writeRawValue ([CII)V - java/io/IOException
 method public writeRawValue (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public,abstract writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;[BII)V - java/io/IOException
 method public writeBinary ([BII)V - java/io/IOException
 method public writeBinary ([B)V - java/io/IOException
 method public writeBinary (Ljava/io/InputStream;I)I - java/io/IOException
 method public,abstract writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;I)I - java/io/IOException
 method public writeNumber (S)V - java/io/IOException
 method public,abstract writeNumber (I)V - java/io/IOException
 method public,abstract writeNumber (J)V - java/io/IOException
 method public,abstract writeNumber (Ljava/math/BigInteger;)V - java/io/IOException
 method public,abstract writeNumber (D)V - java/io/IOException
 method public,abstract writeNumber (F)V - java/io/IOException
 method public,abstract writeNumber (Ljava/math/BigDecimal;)V - java/io/IOException
 method public,abstract writeNumber (Ljava/lang/String;)V - java/io/IOException
 method public writeNumber ([CII)V - java/io/IOException
 method public,abstract writeBoolean (Z)V - java/io/IOException
 method public,abstract writeNull ()V - java/io/IOException
 method public writeEmbeddedObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeObjectId (Ljava/lang/Object;)V - java/io/IOException
 method public writeObjectRef (Ljava/lang/Object;)V - java/io/IOException
 method public writeTypeId (Ljava/lang/Object;)V - java/io/IOException
 method public,abstract writeObject (Ljava/lang/Object;)V - java/io/IOException
 method public,abstract writeTree (Lcom/azure/json/implementation/jackson/core/TreeNode;)V - java/io/IOException
 method public writeBooleanField (Ljava/lang/String;Z)V - java/io/IOException
 method public writeStringField (Ljava/lang/String;Ljava/lang/String;)V - java/io/IOException
 method public writeOmittedField (Ljava/lang/String;)V - java/io/IOException
 method public copyCurrentEvent (Lcom/azure/json/implementation/jackson/core/JsonParser;)V - java/io/IOException
 method public copyCurrentStructure (Lcom/azure/json/implementation/jackson/core/JsonParser;)V - java/io/IOException
 method protected _copyCurrentContents (Lcom/azure/json/implementation/jackson/core/JsonParser;)V - java/io/IOException
 method public,abstract flush ()V - java/io/IOException
 method public,abstract isClosed ()Z - -
 method public,abstract close ()V - java/io/IOException
 method protected _reportError (Ljava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonGenerationException
 method protected _reportUnsupportedOperation ()V - -
 method protected,final _verifyOffsets (III)V - -
 method protected _writeSimpleObject (Ljava/lang/Object;)V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/JsonGenerator$Feature 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;>;
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field public,static,final,enum AUTO_CLOSE_TARGET Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum AUTO_CLOSE_JSON_CONTENT Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum FLUSH_PASSED_TO_STREAM Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum,deprecated QUOTE_FIELD_NAMES Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum,deprecated QUOTE_NON_NUMERIC_NUMBERS Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum,deprecated ESCAPE_NON_ASCII Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum,deprecated WRITE_NUMBERS_AS_STRINGS Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum WRITE_BIGDECIMAL_AS_PLAIN Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum STRICT_DUPLICATE_DETECTION Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 field public,static,final,enum IGNORE_UNKNOWN Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; - -
 method public,static collectDefaults ()I - -
 method public enabledByDefault ()Z - -
 method public enabledIn (I)Z - -
 method public getMask ()I - -
in 2
class com/azure/json/implementation/jackson/core/JsonLocation 52 public,super java/lang/Object java/io/Serializable -
 field public,static,final,deprecated MAX_CONTENT_SNIPPET I - I500
 field public,static,final NA Lcom/azure/json/implementation/jackson/core/JsonLocation; -
 field protected,final _totalBytes J -
 field protected,final _totalChars J -
 field protected,final _lineNr I -
 field protected,final _columnNr I -
 field protected,final _contentReference Lcom/azure/json/implementation/jackson/core/io/ContentReference; -
 field protected,transient _sourceDescription Ljava/lang/String; -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/ContentReference;JII)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/ContentReference;JJII)V - -
 method public,deprecated <init> (Ljava/lang/Object;JII)V - -
 method public,deprecated <init> (Ljava/lang/Object;JJII)V - -
 method protected,static _wrap (Ljava/lang/Object;)Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method public,deprecated getSourceRef ()Ljava/lang/Object; - -
 method public sourceDescription ()Ljava/lang/String; - -
 method public appendOffsetDescription (Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/JsonParseException 52 public,super com/azure/json/implementation/jackson/core/exc/StreamReadException - -
 method public,deprecated <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;)V - -
 method public,deprecated <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;Ljava/lang/Throwable;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;Ljava/lang/Throwable;)V - -
 method public withRequestPayload (Lcom/azure/json/implementation/jackson/core/util/RequestPayload;)Lcom/azure/json/implementation/jackson/core/JsonParseException; - -
 method public getProcessor ()Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public getRequestPayload ()Lcom/azure/json/implementation/jackson/core/util/RequestPayload; - -
 method public getRequestPayloadAsString ()Ljava/lang/String; - -
 method public getMessage ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/JsonParser 52 public,super,abstract java/lang/Object java/io/Closeable,com/azure/json/implementation/jackson/core/Versioned -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonParser$NumberType com/azure/json/implementation/jackson/core/JsonParser NumberType public,static,final,enum
 field protected,static,final DEFAULT_READ_CAPABILITIES Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>;
 field protected _features I -
 field protected,transient _requestPayload Lcom/azure/json/implementation/jackson/core/util/RequestPayload; -
 method protected <init> ()V - -
 method protected <init> (I)V - -
 method public,abstract getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public,abstract setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public getInputSource ()Ljava/lang/Object; - -
 method public setSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)V - -
 method public getSchema ()Lcom/azure/json/implementation/jackson/core/FormatSchema; - -
 method public canUseSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)Z - -
 method public requiresCustomCodec ()Z - -
 method public getReadCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>; -
 method public,abstract version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public,abstract close ()V - java/io/IOException
 method public,abstract isClosed ()Z - -
 method public,abstract getParsingContext ()Lcom/azure/json/implementation/jackson/core/JsonStreamContext; - -
 method public currentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public currentTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,abstract getCurrentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,abstract getTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public currentValue ()Ljava/lang/Object; - -
 method public assignCurrentValue (Ljava/lang/Object;)V - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public configure (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;Z)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public isEnabled (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Z - -
 method public isEnabled (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)Z - -
 method public getFeatureMask ()I - -
 method public,deprecated setFeatureMask (I)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public overrideStdFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public overrideFormatFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public,abstract nextToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public,abstract nextValue ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public,abstract skipChildren ()Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public finishToken ()V - java/io/IOException
 method public currentToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public currentTokenId ()I - -
 method public,abstract getCurrentToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public,abstract,deprecated getCurrentTokenId ()I - -
 method public,abstract hasCurrentToken ()Z - -
 method public,abstract hasTokenId (I)Z - -
 method public,abstract hasToken (Lcom/azure/json/implementation/jackson/core/JsonToken;)Z - -
 method public isExpectedStartArrayToken ()Z - -
 method public isExpectedStartObjectToken ()Z - -
 method public isExpectedNumberIntToken ()Z - -
 method public isNaN ()Z - java/io/IOException
 method public,abstract clearCurrentToken ()V - -
 method public,abstract getLastClearedToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public,abstract overrideCurrentName (Ljava/lang/String;)V - -
 method public,abstract getCurrentName ()Ljava/lang/String; - java/io/IOException
 method public currentName ()Ljava/lang/String; - java/io/IOException
 method public,abstract getText ()Ljava/lang/String; - java/io/IOException
 method public getText (Ljava/io/Writer;)I - java/io/IOException,java/lang/UnsupportedOperationException
 method public,abstract getTextCharacters ()[C - java/io/IOException
 method public,abstract getTextLength ()I - java/io/IOException
 method public,abstract getTextOffset ()I - java/io/IOException
 method public,abstract hasTextCharacters ()Z - -
 method public,abstract getNumberValue ()Ljava/lang/Number; - java/io/IOException
 method public getNumberValueExact ()Ljava/lang/Number; - java/io/IOException
 method public,abstract getNumberType ()Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; - java/io/IOException
 method public getByteValue ()B - java/io/IOException
 method public getShortValue ()S - java/io/IOException
 method public,abstract getIntValue ()I - java/io/IOException
 method public,abstract getLongValue ()J - java/io/IOException
 method public,abstract getBigIntegerValue ()Ljava/math/BigInteger; - java/io/IOException
 method public,abstract getFloatValue ()F - java/io/IOException
 method public,abstract getDoubleValue ()D - java/io/IOException
 method public,abstract getDecimalValue ()Ljava/math/BigDecimal; - java/io/IOException
 method public getBooleanValue ()Z - java/io/IOException
 method public getEmbeddedObject ()Ljava/lang/Object; - java/io/IOException
 method public,abstract getBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public getBinaryValue ()[B - java/io/IOException
 method public readBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/OutputStream;)I - java/io/IOException
 method public getValueAsInt ()I - java/io/IOException
 method public getValueAsInt (I)I - java/io/IOException
 method public getValueAsLong ()J - java/io/IOException
 method public getValueAsLong (J)J - java/io/IOException
 method public getValueAsDouble ()D - java/io/IOException
 method public getValueAsDouble (D)D - java/io/IOException
 method public getValueAsBoolean ()Z - java/io/IOException
 method public getValueAsBoolean (Z)Z - java/io/IOException
 method public getValueAsString ()Ljava/lang/String; - java/io/IOException
 method public,abstract getValueAsString (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public canReadObjectId ()Z - -
 method public canReadTypeId ()Z - -
 method public getObjectId ()Ljava/lang/Object; - java/io/IOException
 method public getTypeId ()Ljava/lang/Object; - java/io/IOException
 method public readValueAs (Ljava/lang/Class;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)TT; java/io/IOException
 method public readValueAs (Lcom/azure/json/implementation/jackson/core/type/TypeReference;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/azure/json/implementation/jackson/core/type/TypeReference<*>;)TT; java/io/IOException
 method protected _codec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method protected _constructError (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonParseException; - -
 method protected _reportUnsupportedOperation ()V - -
in 2
class com/azure/json/implementation/jackson/core/JsonParser$Feature 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;>;
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 field public,static,final,enum AUTO_CLOSE_SOURCE Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum ALLOW_COMMENTS Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum ALLOW_YAML_COMMENTS Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum ALLOW_UNQUOTED_FIELD_NAMES Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum ALLOW_SINGLE_QUOTES Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum,deprecated ALLOW_UNQUOTED_CONTROL_CHARS Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum,deprecated ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum,deprecated ALLOW_NUMERIC_LEADING_ZEROS Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum,deprecated ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum,deprecated ALLOW_NON_NUMERIC_NUMBERS Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum,deprecated ALLOW_MISSING_VALUES Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum,deprecated ALLOW_TRAILING_COMMA Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum STRICT_DUPLICATE_DETECTION Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum IGNORE_UNDEFINED Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 field public,static,final,enum INCLUDE_SOURCE_IN_LOCATION Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; - -
 method public,static collectDefaults ()I - -
 method public enabledByDefault ()Z - -
 method public enabledIn (I)Z - -
 method public getMask ()I - -
in 2
class com/azure/json/implementation/jackson/core/JsonParser$NumberType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType;>;
 inner com/azure/json/implementation/jackson/core/JsonParser$NumberType com/azure/json/implementation/jackson/core/JsonParser NumberType public,static,final,enum
 field public,static,final,enum INT Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; -
 field public,static,final,enum LONG Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; -
 field public,static,final,enum BIG_INTEGER Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; -
 field public,static,final,enum FLOAT Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; -
 field public,static,final,enum DOUBLE Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; -
 field public,static,final,enum BIG_DECIMAL Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; - -
in 2
class com/azure/json/implementation/jackson/core/JsonProcessingException 52 public,super com/azure/json/implementation/jackson/core/JacksonException - -
 field protected _location Lcom/azure/json/implementation/jackson/core/JsonLocation; -
 method protected <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;Ljava/lang/Throwable;)V - -
 method protected <init> (Ljava/lang/String;)V - -
 method protected <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;)V - -
 method protected <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method protected <init> (Ljava/lang/Throwable;)V - -
 method public getLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public getProcessor ()Ljava/lang/Object; - -
 method protected getMessageSuffix ()Ljava/lang/String; - -
 method public getMessage ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/JsonStreamContext 52 public,super,abstract java/lang/Object - -
 field public,static,final TYPE_ROOT I - I0
 field public,static,final TYPE_ARRAY I - I1
 field public,static,final TYPE_OBJECT I - I2
 field protected _type I -
 field protected _index I -
 method protected <init> ()V - -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/JsonStreamContext;)V - -
 method protected <init> (II)V - -
 method public,abstract getParent ()Lcom/azure/json/implementation/jackson/core/JsonStreamContext; - -
 method public,final inArray ()Z - -
 method public,final inRoot ()Z - -
 method public,final inObject ()Z - -
 method public,final,deprecated getTypeDesc ()Ljava/lang/String; - -
 method public typeDesc ()Ljava/lang/String; - -
 method public,final getCurrentIndex ()I - -
 method public,abstract getCurrentName ()Ljava/lang/String; - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public startLocation (Lcom/azure/json/implementation/jackson/core/io/ContentReference;)Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,deprecated getStartLocation (Ljava/lang/Object;)Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/JsonToken 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/JsonToken;>;
 field public,static,final,enum NOT_AVAILABLE Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum START_OBJECT Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum END_OBJECT Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum START_ARRAY Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum END_ARRAY Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum FIELD_NAME Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum VALUE_EMBEDDED_OBJECT Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum VALUE_STRING Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum VALUE_NUMBER_INT Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum VALUE_NUMBER_FLOAT Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum VALUE_TRUE Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum VALUE_FALSE Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public,static,final,enum VALUE_NULL Lcom/azure/json/implementation/jackson/core/JsonToken; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public,final id ()I - -
 method public,final asString ()Ljava/lang/String; - -
 method public,final asCharArray ()[C - -
 method public,final isNumeric ()Z - -
 method public,final isStructStart ()Z - -
 method public,final isStructEnd ()Z - -
 method public,final isScalarValue ()Z - -
 method public,final isBoolean ()Z - -
in 2
class com/azure/json/implementation/jackson/core/JsonTokenId 52 public,interface,abstract java/lang/Object - -
 field public,static,final ID_NOT_AVAILABLE I - I-1
 field public,static,final ID_NO_TOKEN I - I0
 field public,static,final ID_START_OBJECT I - I1
 field public,static,final ID_END_OBJECT I - I2
 field public,static,final ID_START_ARRAY I - I3
 field public,static,final ID_END_ARRAY I - I4
 field public,static,final ID_FIELD_NAME I - I5
 field public,static,final ID_STRING I - I6
 field public,static,final ID_NUMBER_INT I - I7
 field public,static,final ID_NUMBER_FLOAT I - I8
 field public,static,final ID_TRUE I - I9
 field public,static,final ID_FALSE I - I10
 field public,static,final ID_NULL I - I11
 field public,static,final ID_EMBEDDED_OBJECT I - I12
in 2
class com/azure/json/implementation/jackson/core/ObjectCodec 52 public,super,abstract com/azure/json/implementation/jackson/core/TreeCodec com/azure/json/implementation/jackson/core/Versioned -
 method protected <init> ()V - -
 method public,abstract version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public,abstract readValue (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/Class;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/Class<TT;>;)TT; java/io/IOException
 method public,abstract readValue (Lcom/azure/json/implementation/jackson/core/JsonParser;Lcom/azure/json/implementation/jackson/core/type/TypeReference;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/azure/json/implementation/jackson/core/JsonParser;Lcom/azure/json/implementation/jackson/core/type/TypeReference<TT;>;)TT; java/io/IOException
 method public,abstract writeValue (Lcom/azure/json/implementation/jackson/core/JsonGenerator;Ljava/lang/Object;)V - java/io/IOException
 method public,abstract writeTree (Lcom/azure/json/implementation/jackson/core/JsonGenerator;Lcom/azure/json/implementation/jackson/core/TreeNode;)V - java/io/IOException
 method public,deprecated getJsonFactory ()Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
 method public getFactory ()Lcom/azure/json/implementation/jackson/core/JsonFactory; - -
in 2
class com/azure/json/implementation/jackson/core/SerializableString 52 public,interface,abstract java/lang/Object - -
 method public,abstract getValue ()Ljava/lang/String; - -
 method public,abstract asQuotedChars ()[C - -
 method public,abstract asUnquotedUTF8 ()[B - -
 method public,abstract asQuotedUTF8 ()[B - -
 method public,abstract appendQuotedUTF8 ([BI)I - -
 method public,abstract appendQuoted ([CI)I - -
 method public,abstract appendUnquotedUTF8 ([BI)I - -
 method public,abstract appendUnquoted ([CI)I - -
in 2
class com/azure/json/implementation/jackson/core/StreamReadCapability 52 public,final,super,enum java/lang/Enum com/azure/json/implementation/jackson/core/util/JacksonFeature Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>;Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;
 field public,static,final,enum DUPLICATE_PROPERTIES Lcom/azure/json/implementation/jackson/core/StreamReadCapability; -
 field public,static,final,enum SCALARS_AS_OBJECTS Lcom/azure/json/implementation/jackson/core/StreamReadCapability; -
 field public,static,final,enum UNTYPED_SCALARS Lcom/azure/json/implementation/jackson/core/StreamReadCapability; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/StreamReadCapability; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/StreamReadCapability; - -
 method public enabledByDefault ()Z - -
 method public enabledIn (I)Z - -
 method public getMask ()I - -
in 2
class com/azure/json/implementation/jackson/core/StreamReadConstraints 52 public,super java/lang/Object java/io/Serializable -
 inner com/azure/json/implementation/jackson/core/StreamReadConstraints$Builder com/azure/json/implementation/jackson/core/StreamReadConstraints Builder public,static,final
 field public,static,final DEFAULT_MAX_DEPTH I - I1000
 field public,static,final DEFAULT_MAX_DOC_LEN J - J-1
 field public,static,final DEFAULT_MAX_NUM_LEN I - I1000
 field public,static,final DEFAULT_MAX_STRING_LEN I - I20000000
 field public,static,final DEFAULT_MAX_NAME_LEN I - I50000
 field protected,final _maxNestingDepth I -
 field protected,final _maxDocLen J -
 field protected,final _maxNumLen I -
 field protected,final _maxStringLen I -
 field protected,final _maxNameLen I -
 method protected,deprecated <init> (IJII)V - -
 method protected <init> (IJIII)V - -
 method public,static builder ()Lcom/azure/json/implementation/jackson/core/StreamReadConstraints$Builder; - -
in 2
class com/azure/json/implementation/jackson/core/StreamReadConstraints$Builder 52 public,final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/StreamReadConstraints$Builder com/azure/json/implementation/jackson/core/StreamReadConstraints Builder public,static,final
 method public build ()Lcom/azure/json/implementation/jackson/core/StreamReadConstraints; - -
in 2
class com/azure/json/implementation/jackson/core/StreamReadFeature 52 public,final,super,enum java/lang/Enum com/azure/json/implementation/jackson/core/util/JacksonFeature Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/StreamReadFeature;>;Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 field public,static,final,enum AUTO_CLOSE_SOURCE Lcom/azure/json/implementation/jackson/core/StreamReadFeature; -
 field public,static,final,enum STRICT_DUPLICATE_DETECTION Lcom/azure/json/implementation/jackson/core/StreamReadFeature; -
 field public,static,final,enum IGNORE_UNDEFINED Lcom/azure/json/implementation/jackson/core/StreamReadFeature; -
 field public,static,final,enum INCLUDE_SOURCE_IN_LOCATION Lcom/azure/json/implementation/jackson/core/StreamReadFeature; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/StreamReadFeature; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/StreamReadFeature; - -
 method public enabledByDefault ()Z - -
 method public enabledIn (I)Z - -
 method public getMask ()I - -
 method public mappedFeature ()Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; - -
in 2
class com/azure/json/implementation/jackson/core/StreamWriteCapability 52 public,final,super,enum java/lang/Enum com/azure/json/implementation/jackson/core/util/JacksonFeature Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/StreamWriteCapability;>;Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;
 field public,static,final,enum CAN_WRITE_BINARY_NATIVELY Lcom/azure/json/implementation/jackson/core/StreamWriteCapability; -
 field public,static,final,enum CAN_WRITE_FORMATTED_NUMBERS Lcom/azure/json/implementation/jackson/core/StreamWriteCapability; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/StreamWriteCapability; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/StreamWriteCapability; - -
 method public enabledByDefault ()Z - -
 method public enabledIn (I)Z - -
 method public getMask ()I - -
in 2
class com/azure/json/implementation/jackson/core/StreamWriteFeature 52 public,final,super,enum java/lang/Enum com/azure/json/implementation/jackson/core/util/JacksonFeature Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;>;Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field public,static,final,enum AUTO_CLOSE_TARGET Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; -
 field public,static,final,enum AUTO_CLOSE_CONTENT Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; -
 field public,static,final,enum FLUSH_PASSED_TO_STREAM Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; -
 field public,static,final,enum WRITE_BIGDECIMAL_AS_PLAIN Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; -
 field public,static,final,enum STRICT_DUPLICATE_DETECTION Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; -
 field public,static,final,enum IGNORE_UNKNOWN Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/StreamWriteFeature; - -
 method public enabledByDefault ()Z - -
 method public enabledIn (I)Z - -
 method public getMask ()I - -
 method public mappedFeature ()Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; - -
in 2
class com/azure/json/implementation/jackson/core/TSFBuilder 52 public,super,abstract java/lang/Object - <F:Lcom/azure/json/implementation/jackson/core/JsonFactory;B:Lcom/azure/json/implementation/jackson/core/TSFBuilder<TF;TB;>;>Ljava/lang/Object;
 inner com/azure/json/implementation/jackson/core/JsonFactory$Feature com/azure/json/implementation/jackson/core/JsonFactory Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field protected,static,final DEFAULT_FACTORY_FEATURE_FLAGS I -
 field protected,static,final DEFAULT_PARSER_FEATURE_FLAGS I -
 field protected,static,final DEFAULT_GENERATOR_FEATURE_FLAGS I -
 field protected _factoryFeatures I -
 field protected _streamReadFeatures I -
 field protected _streamWriteFeatures I -
 field protected _inputDecorator Lcom/azure/json/implementation/jackson/core/io/InputDecorator; -
 field protected _outputDecorator Lcom/azure/json/implementation/jackson/core/io/OutputDecorator; -
 method protected <init> ()V - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;)TB; -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;)TB; -
 method public configure (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;Z)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/JsonFactory$Feature;Z)TB; -
 method public enable (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)TB; -
 method public,varargs enable (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;[Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;[Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)TB; -
 method public disable (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)TB; -
 method public,varargs disable (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;[Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;[Lcom/azure/json/implementation/jackson/core/StreamReadFeature;)TB; -
 method public configure (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;Z)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamReadFeature;Z)TB; -
 method public enable (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)TB; -
 method public,varargs enable (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;[Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;[Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)TB; -
 method public disable (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)TB; -
 method public,varargs disable (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;[Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;[Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;)TB; -
 method public configure (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;Z)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/StreamWriteFeature;Z)TB; -
 method public enable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)TB; -
 method public,varargs enable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)TB; -
 method public disable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)TB; -
 method public,varargs disable (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;)TB; -
 method public configure (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;Z)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;Z)TB; -
 method public enable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)TB; -
 method public,varargs enable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)TB; -
 method public disable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)TB; -
 method public,varargs disable (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;[Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;)TB; -
 method public configure (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;Z)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;Z)TB; -
 method public inputDecorator (Lcom/azure/json/implementation/jackson/core/io/InputDecorator;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/io/InputDecorator;)TB; -
 method public outputDecorator (Lcom/azure/json/implementation/jackson/core/io/OutputDecorator;)Lcom/azure/json/implementation/jackson/core/TSFBuilder; (Lcom/azure/json/implementation/jackson/core/io/OutputDecorator;)TB; -
 method public,abstract build ()Lcom/azure/json/implementation/jackson/core/JsonFactory; ()TF; -
 method protected,final _this ()Lcom/azure/json/implementation/jackson/core/TSFBuilder; ()TB; -
 method protected _legacyEnable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)V - -
 method protected _legacyDisable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)V - -
 method protected _legacyEnable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)V - -
 method protected _legacyDisable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)V - -
in 2
class com/azure/json/implementation/jackson/core/TokenStreamFactory 52 public,super,abstract java/lang/Object com/azure/json/implementation/jackson/core/Versioned,java/io/Serializable -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 method public <init> ()V - -
 method public,abstract canHandleBinaryNatively ()Z - -
 method public,abstract getFormatName ()Ljava/lang/String; - -
 method public,abstract isEnabled (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Z - -
 method public,abstract isEnabled (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Z - -
 method public,abstract createParser ([B)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,abstract createParser ([BII)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,abstract createParser (Ljava/io/File;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,abstract createParser (Ljava/io/InputStream;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,abstract createParser (Ljava/io/Reader;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,abstract createParser (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,abstract createParser (Ljava/net/URL;)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public,abstract createGenerator (Ljava/io/OutputStream;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method public,abstract createGenerator (Ljava/io/OutputStream;Lcom/azure/json/implementation/jackson/core/JsonEncoding;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method public,abstract createGenerator (Ljava/io/Writer;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - java/io/IOException
 method protected _optimizedStreamFromURL (Ljava/net/URL;)Ljava/io/InputStream; - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/TreeCodec 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract writeTree (Lcom/azure/json/implementation/jackson/core/JsonGenerator;Lcom/azure/json/implementation/jackson/core/TreeNode;)V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/TreeNode 52 public,interface,abstract java/lang/Object - -
 method public,abstract size ()I - -
 method public,abstract isArray ()Z - -
 method public,abstract isObject ()Z - -
 method public,abstract get (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/TreeNode; - -
 method public,abstract get (I)Lcom/azure/json/implementation/jackson/core/TreeNode; - -
in 2
class com/azure/json/implementation/jackson/core/Version 52 public,super java/lang/Object java/lang/Comparable,java/io/Serializable Ljava/lang/Object;Ljava/lang/Comparable<Lcom/azure/json/implementation/jackson/core/Version;>;Ljava/io/Serializable;
 field protected,final _majorVersion I -
 field protected,final _minorVersion I -
 field protected,final _patchLevel I -
 field protected,final _groupId Ljava/lang/String; -
 field protected,final _artifactId Ljava/lang/String; -
 field protected,final _snapshotInfo Ljava/lang/String; -
 method public,deprecated <init> (IIILjava/lang/String;)V - -
 method public <init> (IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static unknownVersion ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public isUnknownVersion ()Z - -
 method public isSnapshot ()Z - -
 method public,deprecated isUknownVersion ()Z - -
 method public toString ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public compareTo (Lcom/azure/json/implementation/jackson/core/Version;)I - -
in 2
class com/azure/json/implementation/jackson/core/Versioned 52 public,interface,abstract java/lang/Object - -
 method public,abstract version ()Lcom/azure/json/implementation/jackson/core/Version; - -
in 2
class com/azure/json/implementation/jackson/core/base/GeneratorBase 52 public,super,abstract com/azure/json/implementation/jackson/core/JsonGenerator - -
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field public,static,final SURR1_FIRST I - I55296
 field public,static,final SURR1_LAST I - I56319
 field public,static,final SURR2_FIRST I - I56320
 field public,static,final SURR2_LAST I - I57343
 field protected,static,final DERIVED_FEATURES_MASK I -
 field protected,static,final WRITE_BINARY Ljava/lang/String; - "write a binary value"
 field protected,static,final WRITE_BOOLEAN Ljava/lang/String; - "write a boolean value"
 field protected,static,final WRITE_NULL Ljava/lang/String; - "write a null"
 field protected,static,final WRITE_NUMBER Ljava/lang/String; - "write a number"
 field protected,static,final WRITE_RAW Ljava/lang/String; - "write a raw (unencoded) value"
 field protected,static,final WRITE_STRING Ljava/lang/String; - "write a string"
 field protected,static,final MAX_BIG_DECIMAL_SCALE I - I9999
 field protected _objectCodec Lcom/azure/json/implementation/jackson/core/ObjectCodec; -
 field protected _features I -
 field protected _cfgNumbersAsStrings Z -
 field protected _writeContext Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; -
 field protected _closed Z -
 method protected <init> (ILcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public,final isEnabled (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Z - -
 method public getFeatureMask ()I - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public,deprecated setFeatureMask (I)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public overrideStdFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method protected _checkStdFeatureChanges (II)V - -
 method public setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public getOutputContext ()Lcom/azure/json/implementation/jackson/core/JsonStreamContext; - -
 method public writeStartObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeFieldName (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeString (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeRawValue (Ljava/lang/String;)V - java/io/IOException
 method public writeRawValue (Ljava/lang/String;II)V - java/io/IOException
 method public writeRawValue ([CII)V - java/io/IOException
 method public writeRawValue (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;I)I - java/io/IOException
 method public writeObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeTree (Lcom/azure/json/implementation/jackson/core/TreeNode;)V - java/io/IOException
 method public,abstract flush ()V - java/io/IOException
 method public close ()V - java/io/IOException
 method public isClosed ()Z - -
 method protected,abstract _releaseBuffers ()V - -
 method protected,abstract _verifyValueWrite (Ljava/lang/String;)V - java/io/IOException
 method protected _asString (Ljava/math/BigDecimal;)Ljava/lang/String; - java/io/IOException
 method protected,final _decodeSurrogate (II)I - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/base/ParserBase 52 public,super,abstract com/azure/json/implementation/jackson/core/base/ParserMinimalBase - -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonParser$NumberType com/azure/json/implementation/jackson/core/JsonParser NumberType public,static,final,enum
 field protected,static,final JSON_READ_CAPABILITIES Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>;
 field protected,final _ioContext Lcom/azure/json/implementation/jackson/core/io/IOContext; -
 field protected _closed Z -
 field protected _inputPtr I -
 field protected _inputEnd I -
 field protected _currInputProcessed J -
 field protected _currInputRow I -
 field protected _currInputRowStart I -
 field protected _tokenInputTotal J -
 field protected _tokenInputRow I -
 field protected _tokenInputCol I -
 field protected _parsingContext Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; -
 field protected _nextToken Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field protected,final _textBuffer Lcom/azure/json/implementation/jackson/core/util/TextBuffer; -
 field protected _nameCopyBuffer [C -
 field protected _nameCopied Z -
 field protected _byteArrayBuilder Lcom/azure/json/implementation/jackson/core/util/ByteArrayBuilder; -
 field protected _binaryValue [B -
 field protected _numTypesValid I -
 field protected _numberInt I -
 field protected _numberLong J -
 field protected _numberDouble D -
 field protected _numberBigInt Ljava/math/BigInteger; -
 field protected _numberBigDecimal Ljava/math/BigDecimal; -
 field protected _numberNegative Z -
 field protected _intLength I -
 field protected _fractLength I -
 field protected _expLength I -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;I)V - -
 method public version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public,deprecated setFeatureMask (I)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public overrideStdFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method protected _checkStdFeatureChanges (II)V - -
 method public getCurrentName ()Ljava/lang/String; - java/io/IOException
 method public overrideCurrentName (Ljava/lang/String;)V - -
 method public close ()V - java/io/IOException
 method public isClosed ()Z - -
 method public getParsingContext ()Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; - -
 method public getTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public getCurrentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public hasTextCharacters ()Z - -
 method public getBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public getTokenCharacterOffset ()J - -
 method public getTokenLineNr ()I - -
 method public getTokenColumnNr ()I - -
 method protected,abstract _closeInput ()V - java/io/IOException
 method protected _releaseBuffers ()V - java/io/IOException
 method protected _handleEOF ()V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,final _eofAsNextChar ()I - com/azure/json/implementation/jackson/core/JsonParseException
 method public _getByteArrayBuilder ()Lcom/azure/json/implementation/jackson/core/util/ByteArrayBuilder; - -
 method protected,final reset (ZIII)Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method protected,final resetInt (ZI)Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method protected,final resetFloat (ZIII)Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method protected,final resetAsNaN (Ljava/lang/String;D)Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public isNaN ()Z - -
 method public getNumberValue ()Ljava/lang/Number; - java/io/IOException
 method public getNumberValueExact ()Ljava/lang/Number; - java/io/IOException
 method public getNumberType ()Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; - java/io/IOException
 method public getIntValue ()I - java/io/IOException
 method public getLongValue ()J - java/io/IOException
 method public getBigIntegerValue ()Ljava/math/BigInteger; - java/io/IOException
 method public getFloatValue ()F - java/io/IOException
 method public getDoubleValue ()D - java/io/IOException
 method public getDecimalValue ()Ljava/math/BigDecimal; - java/io/IOException
 method protected _parseNumericValue (I)V - java/io/IOException
 method protected _parseIntValue ()I - java/io/IOException
 method protected _reportTooLongIntegral (ILjava/lang/String;)V - java/io/IOException
 method protected convertNumberToInt ()V - java/io/IOException
 method protected convertNumberToLong ()V - java/io/IOException
 method protected convertNumberToBigInteger ()V - -
 method protected convertNumberToDouble ()V - -
 method protected convertNumberToBigDecimal ()V - java/io/IOException
 method protected _reportMismatchedEndMarker (IC)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _handleUnrecognizedCharacterEscape (C)C - com/azure/json/implementation/jackson/core/JsonProcessingException
 method protected _throwUnquotedSpace (ILjava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _validJsonTokenList ()Ljava/lang/String; - -
 method protected _validJsonValueList ()Ljava/lang/String; - -
 method protected _decodeEscaped ()C - java/io/IOException
 method protected,final _decodeBase64Escape (Lcom/azure/json/implementation/jackson/core/Base64Variant;II)I - java/io/IOException
 method protected,final _decodeBase64Escape (Lcom/azure/json/implementation/jackson/core/Base64Variant;CI)I - java/io/IOException
 method protected reportInvalidBase64Char (Lcom/azure/json/implementation/jackson/core/Base64Variant;II)Ljava/lang/IllegalArgumentException; - java/lang/IllegalArgumentException
 method protected reportInvalidBase64Char (Lcom/azure/json/implementation/jackson/core/Base64Variant;IILjava/lang/String;)Ljava/lang/IllegalArgumentException; - java/lang/IllegalArgumentException
 method protected _handleBase64MissingPadding (Lcom/azure/json/implementation/jackson/core/Base64Variant;)V - java/io/IOException
 method protected,deprecated _getSourceReference ()Ljava/lang/Object; - -
 method protected _contentReference ()Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method protected,static growArrayBy ([II)[I - -
 method protected,deprecated loadMoreGuaranteed ()V - java/io/IOException
 method protected,deprecated loadMore ()Z - -
 method protected _finishString ()V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/base/ParserMinimalBase 52 public,super,abstract com/azure/json/implementation/jackson/core/JsonParser - -
 field protected,static,final INT_TAB I - I9
 field protected,static,final INT_LF I - I10
 field protected,static,final INT_CR I - I13
 field protected,static,final INT_SPACE I - I32
 field protected,static,final INT_RBRACKET I - I93
 field protected,static,final INT_RCURLY I - I125
 field protected,static,final INT_QUOTE I - I34
 field protected,static,final INT_APOS I - I39
 field protected,static,final INT_BACKSLASH I - I92
 field protected,static,final INT_SLASH I - I47
 field protected,static,final INT_ASTERISK I - I42
 field protected,static,final INT_COLON I - I58
 field protected,static,final INT_COMMA I - I44
 field protected,static,final INT_HASH I - I35
 field protected,static,final INT_0 I - I48
 field protected,static,final INT_9 I - I57
 field protected,static,final INT_MINUS I - I45
 field protected,static,final INT_PLUS I - I43
 field protected,static,final INT_PERIOD I - I46
 field protected,static,final INT_e I - I101
 field protected,static,final INT_E I - I69
 field protected,static,final CHAR_NULL C - I0
 field protected,static,final NO_BYTES [B -
 field protected,static,final NR_UNKNOWN I - I0
 field protected,static,final NR_INT I - I1
 field protected,static,final NR_LONG I - I2
 field protected,static,final NR_BIGINT I - I4
 field protected,static,final NR_DOUBLE I - I8
 field protected,static,final NR_BIGDECIMAL I - I16
 field protected,static,final NR_FLOAT I - I32
 field protected,static,final BI_MIN_INT Ljava/math/BigInteger; -
 field protected,static,final BI_MAX_INT Ljava/math/BigInteger; -
 field protected,static,final BI_MIN_LONG Ljava/math/BigInteger; -
 field protected,static,final BI_MAX_LONG Ljava/math/BigInteger; -
 field protected,static,final BD_MIN_LONG Ljava/math/BigDecimal; -
 field protected,static,final BD_MAX_LONG Ljava/math/BigDecimal; -
 field protected,static,final BD_MIN_INT Ljava/math/BigDecimal; -
 field protected,static,final BD_MAX_INT Ljava/math/BigDecimal; -
 field protected,static,final MIN_INT_L J - J-2147483648
 field protected,static,final MAX_INT_L J - J2147483647
 field protected,static,final MIN_LONG_D D - D-9.223372036854776E18
 field protected,static,final MAX_LONG_D D - D9.223372036854776E18
 field protected,static,final MIN_INT_D D - D-2.147483648E9
 field protected,static,final MAX_INT_D D - D2.147483647E9
 field protected,static,final MAX_ERROR_TOKEN_LENGTH I - I256
 field protected _currToken Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field protected _lastClearedToken Lcom/azure/json/implementation/jackson/core/JsonToken; -
 method protected <init> (I)V - -
 method public,abstract nextToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public currentToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public currentTokenId ()I - -
 method public getCurrentToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public,deprecated getCurrentTokenId ()I - -
 method public hasCurrentToken ()Z - -
 method public hasTokenId (I)Z - -
 method public hasToken (Lcom/azure/json/implementation/jackson/core/JsonToken;)Z - -
 method public isExpectedStartArrayToken ()Z - -
 method public isExpectedStartObjectToken ()Z - -
 method public isExpectedNumberIntToken ()Z - -
 method public nextValue ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public skipChildren ()Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method protected,abstract _handleEOF ()V - com/azure/json/implementation/jackson/core/JsonParseException
 method public,abstract getCurrentName ()Ljava/lang/String; - java/io/IOException
 method public,abstract close ()V - java/io/IOException
 method public,abstract isClosed ()Z - -
 method public,abstract getParsingContext ()Lcom/azure/json/implementation/jackson/core/JsonStreamContext; - -
 method public clearCurrentToken ()V - -
 method public getLastClearedToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public,abstract overrideCurrentName (Ljava/lang/String;)V - -
 method public,abstract getText ()Ljava/lang/String; - java/io/IOException
 method public,abstract getTextCharacters ()[C - java/io/IOException
 method public,abstract hasTextCharacters ()Z - -
 method public,abstract getTextLength ()I - java/io/IOException
 method public,abstract getTextOffset ()I - java/io/IOException
 method public,abstract getBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public getValueAsBoolean (Z)Z - java/io/IOException
 method public getValueAsInt ()I - java/io/IOException
 method public getValueAsInt (I)I - java/io/IOException
 method public getValueAsLong ()J - java/io/IOException
 method public getValueAsLong (J)J - java/io/IOException
 method public getValueAsDouble (D)D - java/io/IOException
 method public getValueAsString ()Ljava/lang/String; - java/io/IOException
 method public getValueAsString (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method protected _decodeBase64 (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/util/ByteArrayBuilder;Lcom/azure/json/implementation/jackson/core/Base64Variant;)V - java/io/IOException
 method protected _hasTextualNull (Ljava/lang/String;)Z - -
 method protected reportUnexpectedNumberChar (ILjava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected reportInvalidNumber (Ljava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected reportOverflowInt ()V - java/io/IOException
 method protected reportOverflowInt (Ljava/lang/String;)V - java/io/IOException
 method protected reportOverflowInt (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;)V - java/io/IOException
 method protected reportOverflowLong ()V - java/io/IOException
 method protected reportOverflowLong (Ljava/lang/String;)V - java/io/IOException
 method protected reportOverflowLong (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;)V - java/io/IOException
 method protected _reportInputCoercion (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;Ljava/lang/Class;)V (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;Ljava/lang/Class<*>;)V com/azure/json/implementation/jackson/core/exc/InputCoercionException
 method protected _longIntegerDesc (Ljava/lang/String;)Ljava/lang/String; - -
 method protected _longNumberDesc (Ljava/lang/String;)Ljava/lang/String; - -
 method protected _reportUnexpectedChar (ILjava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _reportInvalidEOF ()V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _reportInvalidEOFInValue (Lcom/azure/json/implementation/jackson/core/JsonToken;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _reportInvalidEOF (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,deprecated _reportInvalidEOFInValue ()V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,deprecated _reportInvalidEOF (Ljava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _reportMissingRootWS (I)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _throwInvalidSpace (I)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,static _getCharDesc (I)Ljava/lang/String; - -
 method protected,final _reportError (Ljava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,final _reportError (Ljava/lang/String;Ljava/lang/Object;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,final _reportError (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,final _wrapError (Ljava/lang/String;Ljava/lang/Throwable;)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,final _throwInternal ()V - -
 method protected,final _constructError (Ljava/lang/String;Ljava/lang/Throwable;)Lcom/azure/json/implementation/jackson/core/JsonParseException; - -
 method protected,static,deprecated _asciiBytes (Ljava/lang/String;)[B - -
 method protected,static,deprecated _ascii ([B)Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/exc/InputCoercionException 52 public,super com/azure/json/implementation/jackson/core/exc/StreamReadException - -
 field protected,final _inputType Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field protected,final _targetType Ljava/lang/Class; Ljava/lang/Class<*>;
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;Ljava/lang/Class;)V (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;Ljava/lang/Class<*>;)V -
 method public withRequestPayload (Lcom/azure/json/implementation/jackson/core/util/RequestPayload;)Lcom/azure/json/implementation/jackson/core/exc/InputCoercionException; - -
in 2
class com/azure/json/implementation/jackson/core/exc/StreamReadException 52 public,super,abstract com/azure/json/implementation/jackson/core/JsonProcessingException - -
 field protected,transient _processor Lcom/azure/json/implementation/jackson/core/JsonParser; -
 field protected _requestPayload Lcom/azure/json/implementation/jackson/core/util/RequestPayload; -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;)V - -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;)V - -
 method protected <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonLocation;Ljava/lang/Throwable;)V - -
 method public,abstract withRequestPayload (Lcom/azure/json/implementation/jackson/core/util/RequestPayload;)Lcom/azure/json/implementation/jackson/core/exc/StreamReadException; - -
 method public getProcessor ()Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public getRequestPayload ()Lcom/azure/json/implementation/jackson/core/util/RequestPayload; - -
 method public getRequestPayloadAsString ()Ljava/lang/String; - -
 method public getMessage ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/exc/StreamWriteException 52 public,super,abstract com/azure/json/implementation/jackson/core/JsonProcessingException - -
 field protected,transient _processor Lcom/azure/json/implementation/jackson/core/JsonGenerator; -
 method protected <init> (Ljava/lang/Throwable;Lcom/azure/json/implementation/jackson/core/JsonGenerator;)V - -
 method protected <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonGenerator;)V - -
 method protected <init> (Ljava/lang/String;Ljava/lang/Throwable;Lcom/azure/json/implementation/jackson/core/JsonGenerator;)V - -
 method public getProcessor ()Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
in 2
class com/azure/json/implementation/jackson/core/io/BigDecimalParser 52 public,final,super java/lang/Object - -
 method public,static parse (Ljava/lang/String;)Ljava/math/BigDecimal; - -
 method public,static parse ([CII)Ljava/math/BigDecimal; - -
 method public,static parse ([C)Ljava/math/BigDecimal; - -
in 2
class com/azure/json/implementation/jackson/core/io/CharTypes 52 public,final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/io/CharTypes$AltEscapes com/azure/json/implementation/jackson/core/io/CharTypes AltEscapes private,static
 method public <init> ()V - -
 method public,static getInputCodeLatin1 ()[I - -
 method public,static getInputCodeUtf8 ()[I - -
 method public,static getInputCodeLatin1JsNames ()[I - -
 method public,static getInputCodeUtf8JsNames ()[I - -
 method public,static getInputCodeComment ()[I - -
 method public,static get7BitOutputEscapes ()[I - -
 method public,static get7BitOutputEscapes (I)[I - -
 method public,static charToHex (I)I - -
 method public,static hexToChar (I)C - -
 method public,static appendQuoted (Ljava/lang/StringBuilder;Ljava/lang/String;)V - -
 method public,static copyHexChars ()[C - -
 method public,static copyHexBytes ()[B - -
in 2
class com/azure/json/implementation/jackson/core/io/CharTypes$AltEscapes 52 super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/io/CharTypes$AltEscapes com/azure/json/implementation/jackson/core/io/CharTypes AltEscapes private,static
 field public,static,final instance Lcom/azure/json/implementation/jackson/core/io/CharTypes$AltEscapes; -
 method public escapesFor (I)[I - -
in 2
class com/azure/json/implementation/jackson/core/io/CharacterEscapes 52 public,super,abstract java/lang/Object java/io/Serializable -
 field public,static,final ESCAPE_STANDARD I - I-1
 field public,static,final ESCAPE_CUSTOM I - I-2
 method public <init> ()V - -
 method public,abstract getEscapeCodesForAscii ()[I - -
 method public,abstract getEscapeSequence (I)Lcom/azure/json/implementation/jackson/core/SerializableString; - -
in 2
class com/azure/json/implementation/jackson/core/io/ContentReference 52 public,super java/lang/Object java/io/Serializable -
 field protected,static,final UNKNOWN_CONTENT Lcom/azure/json/implementation/jackson/core/io/ContentReference; -
 field public,static,final DEFAULT_MAX_CONTENT_SNIPPET I - I500
 field protected,final,transient _rawContent Ljava/lang/Object; -
 field protected,final _offset I -
 field protected,final _length I -
 field protected,final _isContentTextual Z -
 method protected <init> (ZLjava/lang/Object;)V - -
 method protected <init> (ZLjava/lang/Object;II)V - -
 method public,static unknown ()Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method public,static construct (ZLjava/lang/Object;)Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method public,static construct (ZLjava/lang/Object;II)Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method public,static rawReference (ZLjava/lang/Object;)Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method public,static rawReference (Ljava/lang/Object;)Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method protected readResolve ()Ljava/lang/Object; - -
 method public hasTextualContent ()Z - -
 method public getRawContent ()Ljava/lang/Object; - -
 method public contentOffset ()I - -
 method public contentLength ()I - -
 method protected maxContentSnippetLength ()I - -
 method public buildSourceDescription ()Ljava/lang/String; - -
 method public appendSourceDescription (Ljava/lang/StringBuilder;)Ljava/lang/StringBuilder; - -
 method protected _truncate (Ljava/lang/CharSequence;[II)Ljava/lang/String; - -
 method protected _truncate ([C[II)Ljava/lang/String; - -
 method protected _truncate ([B[II)Ljava/lang/String; - -
 method protected _truncateOffsets ([II)V - -
 method protected _append (Ljava/lang/StringBuilder;Ljava/lang/String;)I - -
 method protected _appendEscaped (Ljava/lang/StringBuilder;I)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 2
class com/azure/json/implementation/jackson/core/io/IOContext 52 public,super java/lang/Object - -
 field protected,final _contentReference Lcom/azure/json/implementation/jackson/core/io/ContentReference; -
 field protected,final,deprecated _sourceRef Ljava/lang/Object; -
 field protected _encoding Lcom/azure/json/implementation/jackson/core/JsonEncoding; -
 field protected,final _managedResource Z -
 field protected,final _bufferRecycler Lcom/azure/json/implementation/jackson/core/util/BufferRecycler; -
 field protected _readIOBuffer [B -
 field protected _writeEncodingBuffer [B -
 field protected _base64Buffer [B -
 field protected _tokenCBuffer [C -
 field protected _concatCBuffer [C -
 field protected _nameCopyBuffer [C -
 method public <init> (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;Lcom/azure/json/implementation/jackson/core/io/ContentReference;Z)V - -
 method public,deprecated <init> (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;Ljava/lang/Object;Z)V - -
 method public setEncoding (Lcom/azure/json/implementation/jackson/core/JsonEncoding;)V - -
 method public getEncoding ()Lcom/azure/json/implementation/jackson/core/JsonEncoding; - -
 method public isResourceManaged ()Z - -
 method public contentReference ()Lcom/azure/json/implementation/jackson/core/io/ContentReference; - -
 method public,deprecated getSourceReference ()Ljava/lang/Object; - -
 method public constructTextBuffer ()Lcom/azure/json/implementation/jackson/core/util/TextBuffer; - -
 method public allocReadIOBuffer ()[B - -
 method public allocWriteEncodingBuffer ()[B - -
 method public allocBase64Buffer ()[B - -
 method public allocTokenBuffer ()[C - -
 method public allocTokenBuffer (I)[C - -
 method public allocConcatBuffer ()[C - -
 method public allocNameCopyBuffer (I)[C - -
 method public releaseReadIOBuffer ([B)V - -
 method public releaseWriteEncodingBuffer ([B)V - -
 method public releaseBase64Buffer ([B)V - -
 method public releaseTokenBuffer ([C)V - -
 method public releaseConcatBuffer ([C)V - -
 method public releaseNameCopyBuffer ([C)V - -
 method protected,final _verifyAlloc (Ljava/lang/Object;)V - -
 method protected,final _verifyRelease ([B[B)V - -
 method protected,final _verifyRelease ([C[C)V - -
in 2
class com/azure/json/implementation/jackson/core/io/InputDecorator 52 public,super,abstract java/lang/Object java/io/Serializable -
 method public <init> ()V - -
 method public,abstract decorate (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/InputStream;)Ljava/io/InputStream; - java/io/IOException
 method public,abstract decorate (Lcom/azure/json/implementation/jackson/core/io/IOContext;[BII)Ljava/io/InputStream; - java/io/IOException
 method public,abstract decorate (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/Reader;)Ljava/io/Reader; - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/io/JsonEOFException 52 public,super com/azure/json/implementation/jackson/core/JsonParseException - -
 field protected,final _token Lcom/azure/json/implementation/jackson/core/JsonToken; -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;Lcom/azure/json/implementation/jackson/core/JsonToken;Ljava/lang/String;)V - -
in 2
class com/azure/json/implementation/jackson/core/io/JsonStringEncoder 52 public,final,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getInstance ()Lcom/azure/json/implementation/jackson/core/io/JsonStringEncoder; - -
 method public quoteAsString (Ljava/lang/String;)[C - -
 method public quoteAsString (Ljava/lang/CharSequence;Ljava/lang/StringBuilder;)V - -
 method public quoteAsUTF8 (Ljava/lang/String;)[B - -
 method public encodeAsUTF8 (Ljava/lang/String;)[B - -
in 2
class com/azure/json/implementation/jackson/core/io/MergedStream 52 public,final,super java/io/InputStream - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/InputStream;[BII)V - -
 method public available ()I - java/io/IOException
 method public close ()V - java/io/IOException
 method public,synchronized mark (I)V - -
 method public markSupported ()Z - -
 method public read ()I - java/io/IOException
 method public read ([B)I - java/io/IOException
 method public read ([BII)I - java/io/IOException
 method public,synchronized reset ()V - java/io/IOException
 method public skip (J)J - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/io/NumberInput 52 public,final,super java/lang/Object - -
 field public,static,final NASTY_SMALL_DOUBLE Ljava/lang/String; - "2.2250738585072012e-308"
 method public <init> ()V - -
 method public,static parseInt ([CII)I - -
 method public,static parseInt (Ljava/lang/String;)I - -
 method public,static parseLong ([CII)J - -
 method public,static parseLong (Ljava/lang/String;)J - -
 method public,static inLongRange ([CIIZ)Z - -
 method public,static parseAsInt (Ljava/lang/String;I)I - -
 method public,static parseAsLong (Ljava/lang/String;J)J - -
 method public,static parseAsDouble (Ljava/lang/String;D)D - -
 method public,static parseDouble (Ljava/lang/String;)D - java/lang/NumberFormatException
 method public,static parseBigDecimal (Ljava/lang/String;)Ljava/math/BigDecimal; - java/lang/NumberFormatException
 method public,static parseBigDecimal ([CII)Ljava/math/BigDecimal; - java/lang/NumberFormatException
 method public,static parseBigDecimal ([C)Ljava/math/BigDecimal; - java/lang/NumberFormatException
in 2
class com/azure/json/implementation/jackson/core/io/NumberOutput 52 public,final,super java/lang/Object - -
 method public <init> ()V - -
 method public,static outputInt (I[CI)I - -
 method public,static outputInt (I[BI)I - -
 method public,static outputLong (J[CI)I - -
 method public,static outputLong (J[BI)I - -
 method public,static toString (I)Ljava/lang/String; - -
 method public,static toString (J)Ljava/lang/String; - -
 method public,static toString (D)Ljava/lang/String; - -
 method public,static toString (F)Ljava/lang/String; - -
 method public,static notFinite (D)Z - -
 method public,static notFinite (F)Z - -
in 2
class com/azure/json/implementation/jackson/core/io/OutputDecorator 52 public,super,abstract java/lang/Object java/io/Serializable -
 method public <init> ()V - -
 method public,abstract decorate (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/OutputStream;)Ljava/io/OutputStream; - java/io/IOException
 method public,abstract decorate (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/Writer;)Ljava/io/Writer; - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/io/SegmentedStringWriter 52 public,final,super java/io/Writer - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;)V - -
 method public append (C)Ljava/io/Writer; - -
 method public append (Ljava/lang/CharSequence;)Ljava/io/Writer; - -
 method public append (Ljava/lang/CharSequence;II)Ljava/io/Writer; - -
 method public close ()V - -
 method public flush ()V - -
 method public write ([C)V - -
 method public write ([CII)V - -
 method public write (I)V - -
 method public write (Ljava/lang/String;)V - -
 method public write (Ljava/lang/String;II)V - -
in 2
class com/azure/json/implementation/jackson/core/io/SerializedString 52 public,super java/lang/Object com/azure/json/implementation/jackson/core/SerializableString,java/io/Serializable -
 field protected,final _value Ljava/lang/String; -
 field protected _quotedUTF8Ref [B -
 field protected _unquotedUTF8Ref [B -
 field protected _quotedChars [C -
 field protected,transient _jdkSerializeValue Ljava/lang/String; -
 method public <init> (Ljava/lang/String;)V - -
 method protected readResolve ()Ljava/lang/Object; - -
 method public,final getValue ()Ljava/lang/String; - -
 method public,final asQuotedChars ()[C - -
 method public,final asQuotedUTF8 ()[B - -
 method public,final asUnquotedUTF8 ()[B - -
 method public appendQuoted ([CI)I - -
 method public appendQuotedUTF8 ([BI)I - -
 method public appendUnquoted ([CI)I - -
 method public appendUnquotedUTF8 ([BI)I - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
in 2
class com/azure/json/implementation/jackson/core/io/UTF32Reader 52 public,super java/io/Reader - -
 field protected,static,final LAST_VALID_UNICODE_CHAR I - I1114111
 field protected,static,final NC C - I0
 field protected,final _context Lcom/azure/json/implementation/jackson/core/io/IOContext; -
 field protected _in Ljava/io/InputStream; -
 field protected _buffer [B -
 field protected _ptr I -
 field protected _length I -
 field protected,final _bigEndian Z -
 field protected _surrogate C -
 field protected _charCount I -
 field protected _byteCount I -
 field protected,final _managedBuffers Z -
 field protected _tmpBuf [C -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/InputStream;[BIIZ)V - -
 method public close ()V - java/io/IOException
 method public read ()I - java/io/IOException
 method public read ([CII)I - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/io/UTF8Writer 52 public,final,super java/io/Writer - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/OutputStream;)V - -
 method public append (C)Ljava/io/Writer; - java/io/IOException
 method public close ()V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public write ([C)V - java/io/IOException
 method public write ([CII)V - java/io/IOException
 method public write (I)V - java/io/IOException
 method public write (Ljava/lang/String;)V - java/io/IOException
 method public write (Ljava/lang/String;II)V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/json/ByteSourceJsonBootstrapper 52 public,final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/JsonFactory$Feature com/azure/json/implementation/jackson/core/JsonFactory Feature public,static,final,enum
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;Ljava/io/InputStream;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;[BII)V - -
 method public detectEncoding ()Lcom/azure/json/implementation/jackson/core/JsonEncoding; - java/io/IOException
 method public constructReader ()Ljava/io/Reader; - java/io/IOException
 method public constructParser (ILcom/azure/json/implementation/jackson/core/ObjectCodec;Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer;Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer;I)Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/json/DupDetector 52 public,super java/lang/Object - -
 field protected,final _source Ljava/lang/Object; -
 field protected _firstName Ljava/lang/String; -
 field protected _secondName Ljava/lang/String; -
 field protected _seen Ljava/util/HashSet; Ljava/util/HashSet<Ljava/lang/String;>;
 method public,static rootDetector (Lcom/azure/json/implementation/jackson/core/JsonParser;)Lcom/azure/json/implementation/jackson/core/json/DupDetector; - -
 method public,static rootDetector (Lcom/azure/json/implementation/jackson/core/JsonGenerator;)Lcom/azure/json/implementation/jackson/core/json/DupDetector; - -
 method public child ()Lcom/azure/json/implementation/jackson/core/json/DupDetector; - -
 method public reset ()V - -
 method public getSource ()Ljava/lang/Object; - -
 method public isDup (Ljava/lang/String;)Z - -
in 2
class com/azure/json/implementation/jackson/core/json/JsonGeneratorImpl 52 public,super,abstract com/azure/json/implementation/jackson/core/base/GeneratorBase - -
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field protected,static,final sOutputEscapes [I -
 field protected,static,final JSON_WRITE_CAPABILITIES Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamWriteCapability;>;
 field protected,final _ioContext Lcom/azure/json/implementation/jackson/core/io/IOContext; -
 field protected _outputEscapes [I -
 field protected _maximumNonEscapedChar I -
 field protected _characterEscapes Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes; -
 field protected _rootValueSeparator Lcom/azure/json/implementation/jackson/core/SerializableString; -
 field protected _cfgUnqNames Z -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method protected _checkStdFeatureChanges (II)V - -
 method public setHighestNonEscapedChar (I)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public getHighestEscapedChar ()I - -
 method public setCharacterEscapes (Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public getCharacterEscapes ()Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes; - -
 method public setRootValueSeparator (Lcom/azure/json/implementation/jackson/core/SerializableString;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public getWriteCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamWriteCapability;>; -
 method protected _reportCantWriteValueExpectName (Ljava/lang/String;)V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/json/JsonParserBase 52 public,super,abstract com/azure/json/implementation/jackson/core/base/ParserBase - -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 field protected,static,final FEAT_MASK_TRAILING_COMMA I -
 field protected,static,final FEAT_MASK_LEADING_ZEROS I -
 field protected,static,final FEAT_MASK_NON_NUM_NUMBERS I -
 field protected,static,final FEAT_MASK_ALLOW_MISSING I -
 field protected,static,final FEAT_MASK_ALLOW_SINGLE_QUOTES I -
 field protected,static,final FEAT_MASK_ALLOW_UNQUOTED_NAMES I -
 field protected,static,final FEAT_MASK_ALLOW_JAVA_COMMENTS I -
 field protected,static,final FEAT_MASK_ALLOW_YAML_COMMENTS I -
 field protected,static,final INPUT_CODES_LATIN1 [I -
 field protected,static,final INPUT_CODES_UTF8 [I -
 field protected _objectCodec Lcom/azure/json/implementation/jackson/core/ObjectCodec; -
 method protected <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public,final getReadCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>; -
 method public,abstract currentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,abstract currentTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,final,deprecated getCurrentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,final,deprecated getTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
in 2
class com/azure/json/implementation/jackson/core/json/JsonReadContext 52 public,final,super com/azure/json/implementation/jackson/core/JsonStreamContext - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/json/JsonReadContext;Lcom/azure/json/implementation/jackson/core/json/DupDetector;III)V - -
 method public reset (III)V - -
 method public withDupDetector (Lcom/azure/json/implementation/jackson/core/json/DupDetector;)Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public,static createRootContext (Lcom/azure/json/implementation/jackson/core/json/DupDetector;)Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; - -
 method public createChildArrayContext (II)Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; - -
 method public createChildObjectContext (II)Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; - -
 method public getCurrentName ()Ljava/lang/String; - -
 method public getParent ()Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; - -
 method public startLocation (Lcom/azure/json/implementation/jackson/core/io/ContentReference;)Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public,deprecated getStartLocation (Ljava/lang/Object;)Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public clearAndGetParent ()Lcom/azure/json/implementation/jackson/core/json/JsonReadContext; - -
 method public getDupDetector ()Lcom/azure/json/implementation/jackson/core/json/DupDetector; - -
 method public expectComma ()Z - -
 method public setCurrentName (Ljava/lang/String;)V - com/azure/json/implementation/jackson/core/JsonProcessingException
in 2
class com/azure/json/implementation/jackson/core/json/JsonReadFeature 52 public,final,super,enum java/lang/Enum com/azure/json/implementation/jackson/core/FormatFeature Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature;>;Lcom/azure/json/implementation/jackson/core/FormatFeature;
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 field public,static,final,enum ALLOW_JAVA_COMMENTS Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_YAML_COMMENTS Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_SINGLE_QUOTES Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_UNQUOTED_FIELD_NAMES Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_UNESCAPED_CONTROL_CHARS Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_LEADING_ZEROS_FOR_NUMBERS Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_NON_NUMERIC_NUMBERS Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_MISSING_VALUES Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 field public,static,final,enum ALLOW_TRAILING_COMMA Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/json/JsonReadFeature; - -
 method public enabledByDefault ()Z - -
 method public getMask ()I - -
 method public enabledIn (I)Z - -
 method public mappedFeature ()Lcom/azure/json/implementation/jackson/core/JsonParser$Feature; - -
in 2
class com/azure/json/implementation/jackson/core/json/JsonWriteContext 52 public,super com/azure/json/implementation/jackson/core/JsonStreamContext - -
 field public,static,final STATUS_OK_AS_IS I - I0
 field public,static,final STATUS_OK_AFTER_COMMA I - I1
 field public,static,final STATUS_OK_AFTER_COLON I - I2
 field public,static,final STATUS_OK_AFTER_SPACE I - I3
 field public,static,final STATUS_EXPECT_VALUE I - I4
 field public,static,final STATUS_EXPECT_NAME I - I5
 field protected,final _parent Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; -
 field protected _dups Lcom/azure/json/implementation/jackson/core/json/DupDetector; -
 field protected _child Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; -
 field protected _currentName Ljava/lang/String; -
 field protected _currentValue Ljava/lang/Object; -
 field protected _gotName Z -
 method protected <init> (ILcom/azure/json/implementation/jackson/core/json/JsonWriteContext;Lcom/azure/json/implementation/jackson/core/json/DupDetector;)V - -
 method protected <init> (ILcom/azure/json/implementation/jackson/core/json/JsonWriteContext;Lcom/azure/json/implementation/jackson/core/json/DupDetector;Ljava/lang/Object;)V - -
 method public reset (I)Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public reset (ILjava/lang/Object;)Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public withDupDetector (Lcom/azure/json/implementation/jackson/core/json/DupDetector;)Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public,static,deprecated createRootContext ()Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public,static createRootContext (Lcom/azure/json/implementation/jackson/core/json/DupDetector;)Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public createChildArrayContext ()Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public createChildArrayContext (Ljava/lang/Object;)Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public createChildObjectContext ()Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public createChildObjectContext (Ljava/lang/Object;)Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public,final getParent ()Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public,final getCurrentName ()Ljava/lang/String; - -
 method public clearAndGetParent ()Lcom/azure/json/implementation/jackson/core/json/JsonWriteContext; - -
 method public getDupDetector ()Lcom/azure/json/implementation/jackson/core/json/DupDetector; - -
 method public writeFieldName (Ljava/lang/String;)I - com/azure/json/implementation/jackson/core/JsonProcessingException
 method public writeValue ()I - -
in 2
class com/azure/json/implementation/jackson/core/json/JsonWriteFeature 52 public,final,super,enum java/lang/Enum com/azure/json/implementation/jackson/core/FormatFeature Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature;>;Lcom/azure/json/implementation/jackson/core/FormatFeature;
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field public,static,final,enum QUOTE_FIELD_NAMES Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature; -
 field public,static,final,enum WRITE_NAN_AS_STRINGS Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature; -
 field public,static,final,enum WRITE_NUMBERS_AS_STRINGS Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature; -
 field public,static,final,enum ESCAPE_NON_ASCII Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/json/JsonWriteFeature; - -
 method public enabledByDefault ()Z - -
 method public getMask ()I - -
 method public enabledIn (I)Z - -
 method public mappedFeature ()Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature; - -
in 2
class com/azure/json/implementation/jackson/core/json/PackageVersion 52 public,final,super java/lang/Object com/azure/json/implementation/jackson/core/Versioned -
 field public,static,final VERSION Lcom/azure/json/implementation/jackson/core/Version; -
 method public <init> ()V - -
 method public version ()Lcom/azure/json/implementation/jackson/core/Version; - -
in 2
class com/azure/json/implementation/jackson/core/json/ReaderBasedJsonParser 52 public,super com/azure/json/implementation/jackson/core/base/ParserBase - -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 field protected,static,final _icLatin1 [I -
 field protected _reader Ljava/io/Reader; -
 field protected _inputBuffer [C -
 field protected _bufferRecyclable Z -
 field protected _objectCodec Lcom/azure/json/implementation/jackson/core/ObjectCodec; -
 field protected,final _symbols Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer; -
 field protected,final _hashSeed I -
 field protected _tokenIncomplete Z -
 field protected _nameStartOffset J -
 field protected _nameStartRow I -
 field protected _nameStartCol I -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILjava/io/Reader;Lcom/azure/json/implementation/jackson/core/ObjectCodec;Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer;[CIIZ)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILjava/io/Reader;Lcom/azure/json/implementation/jackson/core/ObjectCodec;Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer;)V - -
 method public getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public getReadCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>; -
 method public getInputSource ()Ljava/lang/Object; - -
 method protected,deprecated getNextChar (Ljava/lang/String;)C - java/io/IOException
 method protected getNextChar (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/JsonToken;)C - java/io/IOException
 method protected _closeInput ()V - java/io/IOException
 method protected _releaseBuffers ()V - java/io/IOException
 method protected _loadMoreGuaranteed ()V - java/io/IOException
 method protected _loadMore ()Z - java/io/IOException
 method public,final getText ()Ljava/lang/String; - java/io/IOException
 method public getText (Ljava/io/Writer;)I - java/io/IOException
 method public,final getValueAsString ()Ljava/lang/String; - java/io/IOException
 method public,final getValueAsString (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method protected,final _getText2 (Lcom/azure/json/implementation/jackson/core/JsonToken;)Ljava/lang/String; - -
 method public,final getTextCharacters ()[C - java/io/IOException
 method public,final getTextLength ()I - java/io/IOException
 method public,final getTextOffset ()I - java/io/IOException
 method public getBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public readBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/OutputStream;)I - java/io/IOException
 method protected _readBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/OutputStream;[B)I - java/io/IOException
 method public,final nextToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public finishToken ()V - java/io/IOException
 method protected,final _parseFloatThatStartsWithPeriod ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected,final _parsePosNumber (I)Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected,final _parseNegNumber ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected _handleInvalidNumberStart (IZ)Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected,final _parseName ()Ljava/lang/String; - java/io/IOException
 method protected _handleOddName (I)Ljava/lang/String; - java/io/IOException
 method protected _parseAposName ()Ljava/lang/String; - java/io/IOException
 method protected _handleOddValue (I)Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected _handleApos ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected,final _finishString ()V - java/io/IOException
 method protected _finishString2 ()V - java/io/IOException
 method protected,final _skipString ()V - java/io/IOException
 method protected,final _skipCR ()V - java/io/IOException
 method protected _decodeEscaped ()C - java/io/IOException
 method protected,final _matchToken (Ljava/lang/String;I)V - java/io/IOException
 method protected _decodeBase64 (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public getTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method protected _reportInvalidToken (Ljava/lang/String;)V - java/io/IOException
 method protected _reportInvalidToken (Ljava/lang/String;Ljava/lang/String;)V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/json/UTF8JsonGenerator 52 public,super com/azure/json/implementation/jackson/core/json/JsonGeneratorImpl - -
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field protected,final _outputStream Ljava/io/OutputStream; -
 field protected _quoteChar B -
 field protected _outputBuffer [B -
 field protected _outputTail I -
 field protected,final _outputEnd I -
 field protected,final _outputMaxContiguous I -
 field protected _charBuffer [C -
 field protected,final _charBufferLength I -
 field protected _bufferRecyclable Z -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;Ljava/io/OutputStream;C)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;Ljava/io/OutputStream;C[BIZ)V - -
 method public,deprecated <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;Ljava/io/OutputStream;)V - -
 method public,deprecated <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;Ljava/io/OutputStream;[BIZ)V - -
 method public getOutputTarget ()Ljava/lang/Object; - -
 method public getOutputBuffered ()I - -
 method public writeFieldName (Ljava/lang/String;)V - java/io/IOException
 method public writeFieldName (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public,final writeStartArray ()V - java/io/IOException
 method public,final writeStartArray (Ljava/lang/Object;)V - java/io/IOException
 method public writeStartArray (Ljava/lang/Object;I)V - java/io/IOException
 method public,final writeEndArray ()V - java/io/IOException
 method public,final writeStartObject ()V - java/io/IOException
 method public writeStartObject (Ljava/lang/Object;)V - java/io/IOException
 method public,final writeEndObject ()V - java/io/IOException
 method public writeString (Ljava/lang/String;)V - java/io/IOException
 method public writeString (Ljava/io/Reader;I)V - java/io/IOException
 method public writeString ([CII)V - java/io/IOException
 method public,final writeString (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeRawUTF8String ([BII)V - java/io/IOException
 method public writeUTF8String ([BII)V - java/io/IOException
 method public writeRaw (Ljava/lang/String;)V - java/io/IOException
 method public writeRaw (Ljava/lang/String;II)V - java/io/IOException
 method public writeRaw (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeRawValue (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public,final writeRaw ([CII)V - java/io/IOException
 method public writeRaw (C)V - java/io/IOException
 method public writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;[BII)V - java/io/IOException
 method public writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;I)I - java/io/IOException
 method public writeNumber (S)V - java/io/IOException
 method public writeNumber (I)V - java/io/IOException
 method public writeNumber (J)V - java/io/IOException
 method public writeNumber (Ljava/math/BigInteger;)V - java/io/IOException
 method public writeNumber (D)V - java/io/IOException
 method public writeNumber (F)V - java/io/IOException
 method public writeNumber (Ljava/math/BigDecimal;)V - java/io/IOException
 method public writeNumber (Ljava/lang/String;)V - java/io/IOException
 method public writeNumber ([CII)V - java/io/IOException
 method public writeBoolean (Z)V - java/io/IOException
 method public writeNull ()V - java/io/IOException
 method protected,final _verifyValueWrite (Ljava/lang/String;)V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public close ()V - java/io/IOException
 method protected _releaseBuffers ()V - -
 method protected,final _writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;[BII)V - java/io/IOException
 method protected,final _writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;[BI)I - java/io/IOException
 method protected,final _writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;[B)I - java/io/IOException
 method protected,final _outputSurrogates (II)V - java/io/IOException
 method protected,final _flushBuffer ()V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/json/UTF8StreamJsonParser 52 public,super com/azure/json/implementation/jackson/core/base/ParserBase - -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 field protected,static,final _icLatin1 [I -
 field protected _objectCodec Lcom/azure/json/implementation/jackson/core/ObjectCodec; -
 field protected,final _symbols Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer; -
 field protected _quadBuffer [I -
 field protected _tokenIncomplete Z -
 field protected _nameStartOffset I -
 field protected _nameStartRow I -
 field protected _nameStartCol I -
 field protected _inputStream Ljava/io/InputStream; -
 field protected _inputBuffer [B -
 field protected _bufferRecyclable Z -
 method public,deprecated <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILjava/io/InputStream;Lcom/azure/json/implementation/jackson/core/ObjectCodec;Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer;[BIIZ)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILjava/io/InputStream;Lcom/azure/json/implementation/jackson/core/ObjectCodec;Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer;[BIIIZ)V - -
 method public getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public getReadCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>; -
 method public getInputSource ()Ljava/lang/Object; - -
 method protected,final _loadMore ()Z - java/io/IOException
 method protected _closeInput ()V - java/io/IOException
 method protected _releaseBuffers ()V - java/io/IOException
 method public getText ()Ljava/lang/String; - java/io/IOException
 method public getText (Ljava/io/Writer;)I - java/io/IOException
 method public getValueAsString ()Ljava/lang/String; - java/io/IOException
 method public getValueAsString (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public getValueAsInt ()I - java/io/IOException
 method public getValueAsInt (I)I - java/io/IOException
 method protected,final _getText2 (Lcom/azure/json/implementation/jackson/core/JsonToken;)Ljava/lang/String; - -
 method public getTextCharacters ()[C - java/io/IOException
 method public getTextLength ()I - java/io/IOException
 method public getTextOffset ()I - java/io/IOException
 method public getBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public readBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/OutputStream;)I - java/io/IOException
 method protected _readBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/OutputStream;[B)I - java/io/IOException
 method public nextToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public finishToken ()V - java/io/IOException
 method protected,final _parseFloatThatStartsWithPeriod ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected _parsePosNumber (I)Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected _parseNegNumber ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected,final _parseName (I)Ljava/lang/String; - java/io/IOException
 method protected,final parseMediumName (I)Ljava/lang/String; - java/io/IOException
 method protected,final parseMediumName2 (II)Ljava/lang/String; - java/io/IOException
 method protected,final parseLongName (III)Ljava/lang/String; - java/io/IOException
 method protected slowParseName ()Ljava/lang/String; - java/io/IOException
 method protected,final parseEscapedName ([IIIII)Ljava/lang/String; - java/io/IOException
 method protected _handleOddName (I)Ljava/lang/String; - java/io/IOException
 method protected _parseAposName ()Ljava/lang/String; - java/io/IOException
 method protected _loadMoreGuaranteed ()V - java/io/IOException
 method protected _finishString ()V - java/io/IOException
 method protected _finishAndReturnString ()Ljava/lang/String; - java/io/IOException
 method protected _skipString ()V - java/io/IOException
 method protected _handleUnexpectedValue (I)Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected _handleApos ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected _handleInvalidNumberStart (IZ)Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method protected,final _matchTrue ()V - java/io/IOException
 method protected,final _matchFalse ()V - java/io/IOException
 method protected,final _matchNull ()V - java/io/IOException
 method protected,final _matchToken (Ljava/lang/String;I)V - java/io/IOException
 method protected _decodeEscaped ()C - java/io/IOException
 method protected _decodeCharForError (I)I - java/io/IOException
 method protected,final _skipCR ()V - java/io/IOException
 method protected _reportInvalidToken (Ljava/lang/String;)V - java/io/IOException
 method protected _reportInvalidToken (Ljava/lang/String;Ljava/lang/String;)V - java/io/IOException
 method protected _reportInvalidChar (I)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _reportInvalidInitial (I)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _reportInvalidOther (I)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected _reportInvalidOther (II)V - com/azure/json/implementation/jackson/core/JsonParseException
 method protected,final _decodeBase64 (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public getTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public getCurrentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
in 2
class com/azure/json/implementation/jackson/core/json/WriterBasedJsonGenerator 52 public,super com/azure/json/implementation/jackson/core/json/JsonGeneratorImpl - -
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field protected,static,final SHORT_WRITE I - I32
 field protected,static,final HEX_CHARS [C -
 field protected,final _writer Ljava/io/Writer; -
 field protected _quoteChar C -
 field protected _outputBuffer [C -
 field protected _outputHead I -
 field protected _outputTail I -
 field protected _outputEnd I -
 field protected _entityBuffer [C -
 field protected _currentEscape Lcom/azure/json/implementation/jackson/core/SerializableString; -
 field protected _copyBuffer [C -
 method public,deprecated <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;Ljava/io/Writer;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/io/IOContext;ILcom/azure/json/implementation/jackson/core/ObjectCodec;Ljava/io/Writer;C)V - -
 method public getOutputTarget ()Ljava/lang/Object; - -
 method public getOutputBuffered ()I - -
 method public canWriteFormattedNumbers ()Z - -
 method public writeFieldName (Ljava/lang/String;)V - java/io/IOException
 method public writeFieldName (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method protected,final _writeFieldName (Ljava/lang/String;Z)V - java/io/IOException
 method protected,final _writeFieldName (Lcom/azure/json/implementation/jackson/core/SerializableString;Z)V - java/io/IOException
 method public writeStartArray ()V - java/io/IOException
 method public writeStartArray (Ljava/lang/Object;)V - java/io/IOException
 method public writeStartArray (Ljava/lang/Object;I)V - java/io/IOException
 method public writeEndArray ()V - java/io/IOException
 method public writeStartObject ()V - java/io/IOException
 method public writeStartObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeEndObject ()V - java/io/IOException
 method public writeString (Ljava/lang/String;)V - java/io/IOException
 method public writeString (Ljava/io/Reader;I)V - java/io/IOException
 method public writeString ([CII)V - java/io/IOException
 method public writeString (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeRawUTF8String ([BII)V - -
 method public writeUTF8String ([BII)V - -
 method public writeRaw (Ljava/lang/String;)V - java/io/IOException
 method public writeRaw (Ljava/lang/String;II)V - java/io/IOException
 method public writeRaw (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeRaw ([CII)V - java/io/IOException
 method public writeRaw (C)V - java/io/IOException
 method public writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;[BII)V - java/io/IOException
 method public writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;I)I - java/io/IOException
 method public writeNumber (S)V - java/io/IOException
 method public writeNumber (I)V - java/io/IOException
 method public writeNumber (J)V - java/io/IOException
 method public writeNumber (Ljava/math/BigInteger;)V - java/io/IOException
 method public writeNumber (D)V - java/io/IOException
 method public writeNumber (F)V - java/io/IOException
 method public writeNumber (Ljava/math/BigDecimal;)V - java/io/IOException
 method public writeNumber (Ljava/lang/String;)V - java/io/IOException
 method public writeNumber ([CII)V - java/io/IOException
 method public writeBoolean (Z)V - java/io/IOException
 method public writeNull ()V - java/io/IOException
 method protected,final _verifyValueWrite (Ljava/lang/String;)V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public close ()V - java/io/IOException
 method protected _releaseBuffers ()V - -
 method protected,final _writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;[BII)V - java/io/IOException
 method protected,final _writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;[BI)I - java/io/IOException
 method protected,final _writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;[B)I - java/io/IOException
 method protected _flushBuffer ()V - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer 52 public,final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer$TableInfo com/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer TableInfo private,static,final
 inner com/azure/json/implementation/jackson/core/JsonFactory$Feature com/azure/json/implementation/jackson/core/JsonFactory Feature public,static,final,enum
 method public,static createRoot ()Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer; - -
 method public makeChild (I)Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer; - -
 method public release ()V - -
 method public size ()I - -
 method public maybeDirty ()Z - -
 method public primaryCount ()I - -
 method public secondaryCount ()I - -
 method public tertiaryCount ()I - -
 method public spilloverCount ()I - -
 method public totalCount ()I - -
 method public toString ()Ljava/lang/String; - -
 method public findName (I)Ljava/lang/String; - -
 method public findName (II)Ljava/lang/String; - -
 method public findName (III)Ljava/lang/String; - -
 method public findName ([II)Ljava/lang/String; - -
 method public addName (Ljava/lang/String;[II)Ljava/lang/String; - -
 method public calcHash (I)I - -
 method public calcHash (II)I - -
 method public calcHash (III)I - -
 method public calcHash ([II)I - -
in 2
class com/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer$TableInfo 52 final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer$TableInfo com/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer TableInfo private,static,final
 field public,final size I -
 field public,final count I -
 field public,final tertiaryShift I -
 field public,final mainHash [I -
 field public,final names [Ljava/lang/String; -
 field public,final spilloverEnd I -
 field public,final longNameOffset I -
 method public <init> (III[I[Ljava/lang/String;II)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer;)V - -
 method public,static createInitial (I)Lcom/azure/json/implementation/jackson/core/sym/ByteQuadsCanonicalizer$TableInfo; - -
in 2
class com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer 52 public,final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$Bucket com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer Bucket static,final
 inner com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$TableInfo com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer TableInfo private,static,final
 inner com/azure/json/implementation/jackson/core/JsonFactory$Feature com/azure/json/implementation/jackson/core/JsonFactory Feature public,static,final,enum
 field public,static,final HASH_MULT I - I33
 method public,static createRoot ()Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer; - -
 method public makeChild (I)Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer; - -
 method public release ()V - -
 method public size ()I - -
 method public maybeDirty ()Z - -
 method public hashSeed ()I - -
 method public findSymbol ([CIII)Ljava/lang/String; - -
 method public _hashToIndex (I)I - -
 method public calcHash ([CII)I - -
 method public calcHash (Ljava/lang/String;)I - -
in 2
class com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$Bucket 52 final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$Bucket com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer Bucket static,final
 field public,final symbol Ljava/lang/String; -
 field public,final next Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$Bucket; -
 field public,final length I -
 method public <init> (Ljava/lang/String;Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$Bucket;)V - -
 method public has ([CII)Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$TableInfo 52 final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$TableInfo com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer TableInfo private,static,final
 inner com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$Bucket com/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer Bucket static,final
 method public <init> (II[Ljava/lang/String;[Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$Bucket;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer;)V - -
 method public,static createInitial (I)Lcom/azure/json/implementation/jackson/core/sym/CharsToNameCanonicalizer$TableInfo; - -
in 2
class com/azure/json/implementation/jackson/core/sym/Name 52 public,super,abstract java/lang/Object - -
 field protected,final _name Ljava/lang/String; -
 field protected,final _hashCode I -
 method protected <init> (Ljava/lang/String;I)V - -
 method public getName ()Ljava/lang/String; - -
 method public,abstract equals (I)Z - -
 method public,abstract equals (II)Z - -
 method public,abstract equals (III)Z - -
 method public,abstract equals ([II)Z - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 2
class com/azure/json/implementation/jackson/core/type/ResolvedType 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract isAbstract ()Z - -
 method public,abstract isThrowable ()Z - -
 method public,abstract isInterface ()Z - -
 method public,abstract isFinal ()Z - -
 method public,deprecated getParameterSource ()Ljava/lang/Class; ()Ljava/lang/Class<*>; -
in 2
class com/azure/json/implementation/jackson/core/type/TypeReference 52 public,super,abstract java/lang/Object java/lang/Comparable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Comparable<Lcom/azure/json/implementation/jackson/core/type/TypeReference<TT;>;>;
 field protected,final _type Ljava/lang/reflect/Type; -
 method protected <init> ()V - -
 method public getType ()Ljava/lang/reflect/Type; - -
 method public compareTo (Lcom/azure/json/implementation/jackson/core/type/TypeReference;)I (Lcom/azure/json/implementation/jackson/core/type/TypeReference<TT;>;)I -
in 2
class com/azure/json/implementation/jackson/core/type/WritableTypeId 52 public,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion com/azure/json/implementation/jackson/core/type/WritableTypeId Inclusion public,static,final,enum
 field public forValue Ljava/lang/Object; -
 field public id Ljava/lang/Object; -
 field public include Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion; -
 field public valueShape Lcom/azure/json/implementation/jackson/core/JsonToken; -
 field public extra Ljava/lang/Object; -
 method public <init> (Ljava/lang/Object;Lcom/azure/json/implementation/jackson/core/JsonToken;Ljava/lang/Object;)V - -
in 2
class com/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion;>;
 inner com/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion com/azure/json/implementation/jackson/core/type/WritableTypeId Inclusion public,static,final,enum
 field public,static,final,enum WRAPPER_ARRAY Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion; -
 field public,static,final,enum WRAPPER_OBJECT Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion; -
 field public,static,final,enum METADATA_PROPERTY Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion; -
 field public,static,final,enum PARENT_PROPERTY Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion; -
 method public,static values ()[Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/type/WritableTypeId$Inclusion; - -
in 2
class com/azure/json/implementation/jackson/core/util/BufferRecycler 52 public,super java/lang/Object - -
 field public,static,final BYTE_READ_IO_BUFFER I - I0
 field public,static,final BYTE_WRITE_ENCODING_BUFFER I - I1
 field public,static,final BYTE_WRITE_CONCAT_BUFFER I - I2
 field public,static,final BYTE_BASE64_CODEC_BUFFER I - I3
 field public,static,final CHAR_TOKEN_BUFFER I - I0
 field public,static,final CHAR_CONCAT_BUFFER I - I1
 field public,static,final CHAR_TEXT_BUFFER I - I2
 field public,static,final CHAR_NAME_COPY_BUFFER I - I3
 field protected,final _byteBuffers Ljava/util/concurrent/atomic/AtomicReferenceArray; Ljava/util/concurrent/atomic/AtomicReferenceArray<[B>;
 field protected,final _charBuffers Ljava/util/concurrent/atomic/AtomicReferenceArray; Ljava/util/concurrent/atomic/AtomicReferenceArray<[C>;
 method public <init> ()V - -
 method protected <init> (II)V - -
 method public,final allocByteBuffer (I)[B - -
 method public allocByteBuffer (II)[B - -
 method public releaseByteBuffer (I[B)V - -
 method public,final allocCharBuffer (I)[C - -
 method public allocCharBuffer (II)[C - -
 method public releaseCharBuffer (I[C)V - -
 method protected byteBufferLength (I)I - -
 method protected charBufferLength (I)I - -
 method protected balloc (I)[B - -
 method protected calloc (I)[C - -
in 2
class com/azure/json/implementation/jackson/core/util/BufferRecyclers 52 public,super java/lang/Object - -
 field public,static,final SYSTEM_PROPERTY_TRACK_REUSABLE_BUFFERS Ljava/lang/String; - "com.azure.json.implementation.jackson.core.util.BufferRecyclers.trackReusableBuffers"
 field protected,static,final _recyclerRef Ljava/lang/ThreadLocal; Ljava/lang/ThreadLocal<Ljava/lang/ref/SoftReference<Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;>;>;
 method public <init> ()V - -
 method public,static getBufferRecycler ()Lcom/azure/json/implementation/jackson/core/util/BufferRecycler; - -
 method public,static,deprecated getJsonStringEncoder ()Lcom/azure/json/implementation/jackson/core/io/JsonStringEncoder; - -
 method public,static,deprecated encodeAsUTF8 (Ljava/lang/String;)[B - -
 method public,static,deprecated quoteAsJsonText (Ljava/lang/String;)[C - -
 method public,static,deprecated quoteAsJsonText (Ljava/lang/CharSequence;Ljava/lang/StringBuilder;)V - -
 method public,static,deprecated quoteAsJsonUTF8 (Ljava/lang/String;)[B - -
in 2
class com/azure/json/implementation/jackson/core/util/ByteArrayBuilder 52 public,final,super java/io/OutputStream - -
 field public,static,final NO_BYTES [B -
 method public <init> ()V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;)V - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;I)V - -
 method public,static fromInitial ([BI)Lcom/azure/json/implementation/jackson/core/util/ByteArrayBuilder; - -
 method public reset ()V - -
 method public size ()I - -
 method public release ()V - -
 method public append (I)V - -
 method public appendTwoBytes (I)V - -
 method public appendThreeBytes (I)V - -
 method public toByteArray ()[B - -
 method public finishCurrentSegment ()[B - -
 method public completeAndCoalesce (I)[B - -
 method public getCurrentSegment ()[B - -
 method public setCurrentSegmentLength (I)V - -
 method public getCurrentSegmentLength ()I - -
 method public write ([B)V - -
 method public write ([BII)V - -
 method public write (I)V - -
 method public close ()V - -
 method public flush ()V - -
in 2
class com/azure/json/implementation/jackson/core/util/InternCache 52 public,final,super java/util/concurrent/ConcurrentHashMap - Ljava/util/concurrent/ConcurrentHashMap<Ljava/lang/String;Ljava/lang/String;>;
 field public,static,final instance Lcom/azure/json/implementation/jackson/core/util/InternCache; -
 method public intern (Ljava/lang/String;)Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/util/JacksonFeature 52 public,interface,abstract java/lang/Object - -
 method public,abstract enabledByDefault ()Z - -
 method public,abstract getMask ()I - -
 method public,abstract enabledIn (I)Z - -
in 2
class com/azure/json/implementation/jackson/core/util/JacksonFeatureSet 52 public,final,super java/lang/Object - <F::Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;>Ljava/lang/Object;
 method public,static fromDefaults ([Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;)Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; <F::Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;>([TF;)Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<TF;>; -
 method public with (Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;)Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; (TF;)Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<TF;>; -
 method public without (Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;)Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; (TF;)Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<TF;>; -
 method public isEnabled (Lcom/azure/json/implementation/jackson/core/util/JacksonFeature;)Z (TF;)Z -
in 2
class com/azure/json/implementation/jackson/core/util/JsonGeneratorDelegate 52 public,super com/azure/json/implementation/jackson/core/JsonGenerator - -
 inner com/azure/json/implementation/jackson/core/JsonGenerator$Feature com/azure/json/implementation/jackson/core/JsonGenerator Feature public,static,final,enum
 field protected delegate Lcom/azure/json/implementation/jackson/core/JsonGenerator; -
 field protected delegateCopyMethods Z -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonGenerator;Z)V - -
 method public getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public setSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)V - -
 method public getSchema ()Lcom/azure/json/implementation/jackson/core/FormatSchema; - -
 method public version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public getOutputTarget ()Ljava/lang/Object; - -
 method public getOutputBuffered ()I - -
 method public assignCurrentValue (Ljava/lang/Object;)V - -
 method public currentValue ()Ljava/lang/Object; - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public canUseSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)Z - -
 method public canWriteTypeId ()Z - -
 method public canWriteObjectId ()Z - -
 method public canWriteBinaryNatively ()Z - -
 method public canOmitFields ()Z - -
 method public canWriteFormattedNumbers ()Z - -
 method public getWriteCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamWriteCapability;>; -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public isEnabled (Lcom/azure/json/implementation/jackson/core/JsonGenerator$Feature;)Z - -
 method public getFeatureMask ()I - -
 method public,deprecated setFeatureMask (I)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public overrideStdFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public overrideFormatFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public setHighestNonEscapedChar (I)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public getHighestEscapedChar ()I - -
 method public getCharacterEscapes ()Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes; - -
 method public setCharacterEscapes (Lcom/azure/json/implementation/jackson/core/io/CharacterEscapes;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public setRootValueSeparator (Lcom/azure/json/implementation/jackson/core/SerializableString;)Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
 method public writeStartArray ()V - java/io/IOException
 method public writeStartArray (I)V - java/io/IOException
 method public writeStartArray (Ljava/lang/Object;)V - java/io/IOException
 method public writeStartArray (Ljava/lang/Object;I)V - java/io/IOException
 method public writeEndArray ()V - java/io/IOException
 method public writeStartObject ()V - java/io/IOException
 method public writeStartObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeStartObject (Ljava/lang/Object;I)V - java/io/IOException
 method public writeEndObject ()V - java/io/IOException
 method public writeFieldName (Ljava/lang/String;)V - java/io/IOException
 method public writeFieldName (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeFieldId (J)V - java/io/IOException
 method public writeArray ([III)V - java/io/IOException
 method public writeArray ([JII)V - java/io/IOException
 method public writeArray ([DII)V - java/io/IOException
 method public writeArray ([Ljava/lang/String;II)V - java/io/IOException
 method public writeString (Ljava/lang/String;)V - java/io/IOException
 method public writeString (Ljava/io/Reader;I)V - java/io/IOException
 method public writeString ([CII)V - java/io/IOException
 method public writeString (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeRawUTF8String ([BII)V - java/io/IOException
 method public writeUTF8String ([BII)V - java/io/IOException
 method public writeRaw (Ljava/lang/String;)V - java/io/IOException
 method public writeRaw (Ljava/lang/String;II)V - java/io/IOException
 method public writeRaw (Lcom/azure/json/implementation/jackson/core/SerializableString;)V - java/io/IOException
 method public writeRaw ([CII)V - java/io/IOException
 method public writeRaw (C)V - java/io/IOException
 method public writeRawValue (Ljava/lang/String;)V - java/io/IOException
 method public writeRawValue (Ljava/lang/String;II)V - java/io/IOException
 method public writeRawValue ([CII)V - java/io/IOException
 method public writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;[BII)V - java/io/IOException
 method public writeBinary (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/InputStream;I)I - java/io/IOException
 method public writeNumber (S)V - java/io/IOException
 method public writeNumber (I)V - java/io/IOException
 method public writeNumber (J)V - java/io/IOException
 method public writeNumber (Ljava/math/BigInteger;)V - java/io/IOException
 method public writeNumber (D)V - java/io/IOException
 method public writeNumber (F)V - java/io/IOException
 method public writeNumber (Ljava/math/BigDecimal;)V - java/io/IOException
 method public writeNumber (Ljava/lang/String;)V - java/io/IOException,java/lang/UnsupportedOperationException
 method public writeNumber ([CII)V - java/io/IOException,java/lang/UnsupportedOperationException
 method public writeBoolean (Z)V - java/io/IOException
 method public writeNull ()V - java/io/IOException
 method public writeOmittedField (Ljava/lang/String;)V - java/io/IOException
 method public writeObjectId (Ljava/lang/Object;)V - java/io/IOException
 method public writeObjectRef (Ljava/lang/Object;)V - java/io/IOException
 method public writeTypeId (Ljava/lang/Object;)V - java/io/IOException
 method public writeEmbeddedObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeObject (Ljava/lang/Object;)V - java/io/IOException
 method public writeTree (Lcom/azure/json/implementation/jackson/core/TreeNode;)V - java/io/IOException
 method public copyCurrentEvent (Lcom/azure/json/implementation/jackson/core/JsonParser;)V - java/io/IOException
 method public copyCurrentStructure (Lcom/azure/json/implementation/jackson/core/JsonParser;)V - java/io/IOException
 method public getOutputContext ()Lcom/azure/json/implementation/jackson/core/JsonStreamContext; - -
 method public flush ()V - java/io/IOException
 method public close ()V - java/io/IOException
 method public isClosed ()Z - -
 method public,deprecated getDelegate ()Lcom/azure/json/implementation/jackson/core/JsonGenerator; - -
in 2
class com/azure/json/implementation/jackson/core/util/JsonParserDelegate 52 public,super com/azure/json/implementation/jackson/core/JsonParser - -
 inner com/azure/json/implementation/jackson/core/JsonParser$Feature com/azure/json/implementation/jackson/core/JsonParser Feature public,static,final,enum
 inner com/azure/json/implementation/jackson/core/JsonParser$NumberType com/azure/json/implementation/jackson/core/JsonParser NumberType public,static,final,enum
 field protected delegate Lcom/azure/json/implementation/jackson/core/JsonParser; -
 method public <init> (Lcom/azure/json/implementation/jackson/core/JsonParser;)V - -
 method public setCodec (Lcom/azure/json/implementation/jackson/core/ObjectCodec;)V - -
 method public getCodec ()Lcom/azure/json/implementation/jackson/core/ObjectCodec; - -
 method public enable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public disable (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public isEnabled (Lcom/azure/json/implementation/jackson/core/JsonParser$Feature;)Z - -
 method public getFeatureMask ()I - -
 method public,deprecated setFeatureMask (I)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public overrideStdFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public overrideFormatFeatures (II)Lcom/azure/json/implementation/jackson/core/JsonParser; - -
 method public getSchema ()Lcom/azure/json/implementation/jackson/core/FormatSchema; - -
 method public setSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)V - -
 method public canUseSchema (Lcom/azure/json/implementation/jackson/core/FormatSchema;)Z - -
 method public version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public getInputSource ()Ljava/lang/Object; - -
 method public requiresCustomCodec ()Z - -
 method public getReadCapabilities ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet; ()Lcom/azure/json/implementation/jackson/core/util/JacksonFeatureSet<Lcom/azure/json/implementation/jackson/core/StreamReadCapability;>; -
 method public close ()V - java/io/IOException
 method public isClosed ()Z - -
 method public clearCurrentToken ()V - -
 method public getLastClearedToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public overrideCurrentName (Ljava/lang/String;)V - -
 method public assignCurrentValue (Ljava/lang/Object;)V - -
 method public setCurrentValue (Ljava/lang/Object;)V - -
 method public getParsingContext ()Lcom/azure/json/implementation/jackson/core/JsonStreamContext; - -
 method public currentToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public currentTokenId ()I - -
 method public currentName ()Ljava/lang/String; - java/io/IOException
 method public currentValue ()Ljava/lang/Object; - -
 method public currentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public currentTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public getCurrentToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - -
 method public,deprecated getCurrentTokenId ()I - -
 method public getCurrentName ()Ljava/lang/String; - java/io/IOException
 method public getCurrentValue ()Ljava/lang/Object; - -
 method public getCurrentLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public getTokenLocation ()Lcom/azure/json/implementation/jackson/core/JsonLocation; - -
 method public hasCurrentToken ()Z - -
 method public hasTokenId (I)Z - -
 method public hasToken (Lcom/azure/json/implementation/jackson/core/JsonToken;)Z - -
 method public isExpectedStartArrayToken ()Z - -
 method public isExpectedStartObjectToken ()Z - -
 method public isExpectedNumberIntToken ()Z - -
 method public isNaN ()Z - java/io/IOException
 method public getText ()Ljava/lang/String; - java/io/IOException
 method public hasTextCharacters ()Z - -
 method public getTextCharacters ()[C - java/io/IOException
 method public getTextLength ()I - java/io/IOException
 method public getTextOffset ()I - java/io/IOException
 method public getText (Ljava/io/Writer;)I - java/io/IOException,java/lang/UnsupportedOperationException
 method public getBigIntegerValue ()Ljava/math/BigInteger; - java/io/IOException
 method public getBooleanValue ()Z - java/io/IOException
 method public getByteValue ()B - java/io/IOException
 method public getShortValue ()S - java/io/IOException
 method public getDecimalValue ()Ljava/math/BigDecimal; - java/io/IOException
 method public getDoubleValue ()D - java/io/IOException
 method public getFloatValue ()F - java/io/IOException
 method public getIntValue ()I - java/io/IOException
 method public getLongValue ()J - java/io/IOException
 method public getNumberType ()Lcom/azure/json/implementation/jackson/core/JsonParser$NumberType; - java/io/IOException
 method public getNumberValue ()Ljava/lang/Number; - java/io/IOException
 method public getNumberValueExact ()Ljava/lang/Number; - java/io/IOException
 method public getValueAsInt ()I - java/io/IOException
 method public getValueAsInt (I)I - java/io/IOException
 method public getValueAsLong ()J - java/io/IOException
 method public getValueAsLong (J)J - java/io/IOException
 method public getValueAsDouble ()D - java/io/IOException
 method public getValueAsDouble (D)D - java/io/IOException
 method public getValueAsBoolean ()Z - java/io/IOException
 method public getValueAsBoolean (Z)Z - java/io/IOException
 method public getValueAsString ()Ljava/lang/String; - java/io/IOException
 method public getValueAsString (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public getEmbeddedObject ()Ljava/lang/Object; - java/io/IOException
 method public getBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;)[B - java/io/IOException
 method public readBinaryValue (Lcom/azure/json/implementation/jackson/core/Base64Variant;Ljava/io/OutputStream;)I - java/io/IOException
 method public nextToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public nextValue ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public finishToken ()V - java/io/IOException
 method public skipChildren ()Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method public canReadObjectId ()Z - -
 method public canReadTypeId ()Z - -
 method public getObjectId ()Ljava/lang/Object; - java/io/IOException
 method public getTypeId ()Ljava/lang/Object; - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/util/JsonParserSequence 52 public,super com/azure/json/implementation/jackson/core/util/JsonParserDelegate - -
 field protected,final _parsers [Lcom/azure/json/implementation/jackson/core/JsonParser; -
 field protected,final _checkForExistingToken Z -
 field protected _nextParserIndex I -
 field protected _hasToken Z -
 method protected,deprecated <init> ([Lcom/azure/json/implementation/jackson/core/JsonParser;)V - -
 method protected <init> (Z[Lcom/azure/json/implementation/jackson/core/JsonParser;)V - -
 method public,static createFlattened (ZLcom/azure/json/implementation/jackson/core/JsonParser;Lcom/azure/json/implementation/jackson/core/JsonParser;)Lcom/azure/json/implementation/jackson/core/util/JsonParserSequence; - -
 method public,static,deprecated createFlattened (Lcom/azure/json/implementation/jackson/core/JsonParser;Lcom/azure/json/implementation/jackson/core/JsonParser;)Lcom/azure/json/implementation/jackson/core/util/JsonParserSequence; - -
 method protected addFlattenedActiveParsers (Ljava/util/List;)V (Ljava/util/List<Lcom/azure/json/implementation/jackson/core/JsonParser;>;)V -
 method public close ()V - java/io/IOException
 method public nextToken ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
 method public skipChildren ()Lcom/azure/json/implementation/jackson/core/JsonParser; - java/io/IOException
 method protected switchToNext ()Z - -
 method protected switchAndReturnNext ()Lcom/azure/json/implementation/jackson/core/JsonToken; - java/io/IOException
in 2
class com/azure/json/implementation/jackson/core/util/RequestPayload 52 public,super java/lang/Object java/io/Serializable -
 field protected _payloadAsBytes [B -
 field protected _payloadAsText Ljava/lang/CharSequence; -
 field protected _charset Ljava/lang/String; -
 method public <init> (Ljava/lang/CharSequence;)V - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/util/TextBuffer 52 public,final,super java/lang/Object - -
 method public <init> (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;)V - -
 method public,static fromInitial ([C)Lcom/azure/json/implementation/jackson/core/util/TextBuffer; - -
 method public releaseBuffers ()V - -
 method public resetWithShared ([CII)V - -
 method public resetWithCopy ([CII)V - -
 method public resetWithString (Ljava/lang/String;)V - -
 method public size ()I - -
 method public getTextOffset ()I - -
 method public getTextBuffer ()[C - -
 method public contentsAsString ()Ljava/lang/String; - -
 method public contentsAsArray ()[C - -
 method public contentsAsDecimal ()Ljava/math/BigDecimal; - java/lang/NumberFormatException
 method public contentsAsDouble ()D - java/lang/NumberFormatException
 method public contentsAsInt (Z)I - -
 method public contentsAsLong (Z)J - -
 method public contentsToWriter (Ljava/io/Writer;)I - java/io/IOException
 method public append (C)V - -
 method public append ([CII)V - -
 method public append (Ljava/lang/String;II)V - -
 method public getCurrentSegment ()[C - -
 method public emptyAndGetCurrentSegment ()[C - -
 method public getCurrentSegmentSize ()I - -
 method public setCurrentLength (I)V - -
 method public setCurrentAndReturn (I)Ljava/lang/String; - -
 method public finishCurrentSegment ()[C - -
 method public expandCurrentSegment ()[C - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/azure/json/implementation/jackson/core/util/ThreadLocalBufferManager 52 super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/util/ThreadLocalBufferManager$ThreadLocalBufferManagerHolder com/azure/json/implementation/jackson/core/util/ThreadLocalBufferManager ThreadLocalBufferManagerHolder private,static,final
 method public,static instance ()Lcom/azure/json/implementation/jackson/core/util/ThreadLocalBufferManager; - -
 method public wrapAndTrack (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;)Ljava/lang/ref/SoftReference; (Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;)Ljava/lang/ref/SoftReference<Lcom/azure/json/implementation/jackson/core/util/BufferRecycler;>; -
in 2
class com/azure/json/implementation/jackson/core/util/ThreadLocalBufferManager$ThreadLocalBufferManagerHolder 52 final,super java/lang/Object - -
 inner com/azure/json/implementation/jackson/core/util/ThreadLocalBufferManager$ThreadLocalBufferManagerHolder com/azure/json/implementation/jackson/core/util/ThreadLocalBufferManager ThreadLocalBufferManagerHolder private,static,final
in 2
class com/azure/json/implementation/jackson/core/util/VersionUtil 52 public,super java/lang/Object - -
 method protected <init> ()V - -
 method public,deprecated version ()Lcom/azure/json/implementation/jackson/core/Version; - -
 method public,static versionFor (Ljava/lang/Class;)Lcom/azure/json/implementation/jackson/core/Version; (Ljava/lang/Class<*>;)Lcom/azure/json/implementation/jackson/core/Version; -
 method public,static,deprecated packageVersionFor (Ljava/lang/Class;)Lcom/azure/json/implementation/jackson/core/Version; (Ljava/lang/Class<*>;)Lcom/azure/json/implementation/jackson/core/Version; -
 method public,static,deprecated mavenVersionFor (Ljava/lang/ClassLoader;Ljava/lang/String;Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/Version; - -
 method public,static parseVersion (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lcom/azure/json/implementation/jackson/core/Version; - -
 method protected,static parseVersionPart (Ljava/lang/String;)I - -
 method public,static throwInternal ()V - -
in 2
class com/azure/json/models/JsonArray 52 public,final,super com/azure/json/models/JsonElement - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public addElement (Lcom/azure/json/models/JsonElement;)Lcom/azure/json/models/JsonArray; - -
 method public addElement (Z)Lcom/azure/json/models/JsonArray; - -
 method public addElement (Ljava/lang/Number;)Lcom/azure/json/models/JsonArray; - -
 method public addElement (Ljava/lang/String;)Lcom/azure/json/models/JsonArray; - -
 method public addElement (ILcom/azure/json/models/JsonElement;)Lcom/azure/json/models/JsonArray; - -
 method public addElement (IZ)Lcom/azure/json/models/JsonArray; - -
 method public addElement (ILjava/lang/Number;)Lcom/azure/json/models/JsonArray; - -
 method public addElement (ILjava/lang/String;)Lcom/azure/json/models/JsonArray; - -
 method public setElement (ILcom/azure/json/models/JsonElement;)Lcom/azure/json/models/JsonArray; - -
 method public setElement (IZ)Lcom/azure/json/models/JsonArray; - -
 method public setElement (ILjava/lang/Number;)Lcom/azure/json/models/JsonArray; - -
 method public setElement (ILjava/lang/String;)Lcom/azure/json/models/JsonArray; - -
 method public getElement (I)Lcom/azure/json/models/JsonElement; - java/lang/IndexOutOfBoundsException
 method public removeElement (I)Lcom/azure/json/models/JsonElement; - java/lang/IndexOutOfBoundsException
 method public size ()I - -
 method public isArray ()Z - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/azure/json/models/JsonArray; - java/io/IOException
 method public toJsonString ()Ljava/lang/String; - java/io/IOException
in 2
class com/azure/json/models/JsonBoolean 52 public,final,super com/azure/json/models/JsonElement - -
 method public,static getInstance (Z)Lcom/azure/json/models/JsonBoolean; - -
 method public getValue ()Z - -
 method public isBoolean ()Z - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/azure/json/models/JsonBoolean; - java/io/IOException
 method public toJsonString ()Ljava/lang/String; - java/io/IOException
in 2
class com/azure/json/models/JsonElement 52 public,super,abstract java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/azure/json/models/JsonElement;>;
 method public <init> ()V - -
 method public isArray ()Z - -
 method public asArray ()Lcom/azure/json/models/JsonArray; - -
 method public isObject ()Z - -
 method public asObject ()Lcom/azure/json/models/JsonObject; - -
 method public isBoolean ()Z - -
 method public asBoolean ()Lcom/azure/json/models/JsonBoolean; - -
 method public isNull ()Z - -
 method public asNull ()Lcom/azure/json/models/JsonNull; - -
 method public isNumber ()Z - -
 method public asNumber ()Lcom/azure/json/models/JsonNumber; - -
 method public isString ()Z - -
 method public asString ()Lcom/azure/json/models/JsonString; - -
in 2
class com/azure/json/models/JsonNull 52 public,final,super com/azure/json/models/JsonElement - -
 method public,static getInstance ()Lcom/azure/json/models/JsonNull; - -
 method public isNull ()Z - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/azure/json/models/JsonNull; - java/io/IOException
 method public toJsonString ()Ljava/lang/String; - java/io/IOException
in 2
class com/azure/json/models/JsonNumber 52 public,final,super com/azure/json/models/JsonElement - -
 method public <init> (Ljava/lang/Number;)V - -
 method public getValue ()Ljava/lang/Number; - -
 method public isNumber ()Z - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/azure/json/models/JsonNumber; - java/io/IOException
 method public toJsonString ()Ljava/lang/String; - java/io/IOException
in 2
class com/azure/json/models/JsonObject 52 public,final,super com/azure/json/models/JsonElement - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public hasProperty (Ljava/lang/String;)Z - -
 method public getProperty (Ljava/lang/String;)Lcom/azure/json/models/JsonElement; - -
 method public setProperty (Ljava/lang/String;Lcom/azure/json/models/JsonElement;)Lcom/azure/json/models/JsonObject; - -
 method public setProperty (Ljava/lang/String;Z)Lcom/azure/json/models/JsonObject; - -
 method public setProperty (Ljava/lang/String;Ljava/lang/Number;)Lcom/azure/json/models/JsonObject; - -
 method public setProperty (Ljava/lang/String;Ljava/lang/String;)Lcom/azure/json/models/JsonObject; - -
 method public removeProperty (Ljava/lang/String;)Lcom/azure/json/models/JsonElement; - -
 method public size ()I - -
 method public isObject ()Z - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/azure/json/models/JsonObject; - java/io/IOException
 method public toJsonString ()Ljava/lang/String; - java/io/IOException
in 2
class com/azure/json/models/JsonString 52 public,final,super com/azure/json/models/JsonElement - -
 method public <init> (Ljava/lang/String;)V - -
 method public getValue ()Ljava/lang/String; - -
 method public isString ()Z - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/azure/json/models/JsonString; - java/io/IOException
 method public toJsonString ()Ljava/lang/String; - java/io/IOException
