cg-stub-db 1
in 0
class akka/serialization/ByteArraySerializer 50 public,super java/lang/Object akka/serialization/Serializer -
 method public,final fromBinary ([B)Ljava/lang/Object; - -
 method public,final fromBinary ([BLjava/lang/Class;)Ljava/lang/Object; ([BLjava/lang/Class<*>;)Ljava/lang/Object; -
 method public includeManifest ()Z - -
 method public identifier ()I - -
 method public toBinary (Ljava/lang/Object;)[B - -
 method public fromBinary ([BLscala/Option;)Ljava/lang/Object; ([BLscala/Option<Ljava/lang/Class<*>;>;)Ljava/lang/Object; -
 method public <init> ()V - -
in 0
class akka/serialization/JSerializer 50 public,super,abstract java/lang/Object akka/serialization/Serializer -
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public,final fromBinary ([B)Ljava/lang/Object; - -
 method public,final fromBinary ([BLjava/lang/Class;)Ljava/lang/Object; ([BLjava/lang/Class<*>;)Ljava/lang/Object; -
 method public,final fromBinary ([BLscala/Option;)Ljava/lang/Object; ([BLscala/Option<Ljava/lang/Class<*>;>;)Ljava/lang/Object; -
 method public,abstract fromBinaryJava ([BLjava/lang/Class;)Ljava/lang/Object; ([BLjava/lang/Class<*>;)Ljava/lang/Object; -
 method public <init> ()V - -
in 0
class akka/serialization/JavaSerializer 50 public,super java/lang/Object akka/serialization/Serializer -
 inner akka/serialization/JavaSerializer$CurrentSystem akka/serialization/JavaSerializer CurrentSystem public,static,final
 method public,static currentSystem ()Lakka/serialization/JavaSerializer$CurrentSystem; - -
 method public,final fromBinary ([B)Ljava/lang/Object; - -
 method public,final fromBinary ([BLjava/lang/Class;)Ljava/lang/Object; ([BLjava/lang/Class<*>;)Ljava/lang/Object; -
 method public system ()Lakka/actor/ExtendedActorSystem; - -
 method public includeManifest ()Z - -
 method public identifier ()I - -
 method public toBinary (Ljava/lang/Object;)[B - -
 method public fromBinary ([BLscala/Option;)Ljava/lang/Object; ([BLscala/Option<Ljava/lang/Class<*>;>;)Ljava/lang/Object; -
 method public <init> (Lakka/actor/ExtendedActorSystem;)V - -
in 0
class akka/serialization/JavaSerializer$ 50 public,final,super java/lang/Object - -
 inner akka/serialization/JavaSerializer$CurrentSystem akka/serialization/JavaSerializer CurrentSystem public,static,final
 field public,static,final MODULE$ Lakka/serialization/JavaSerializer$; -
 method public,static <clinit> ()V - -
 method public currentSystem ()Lakka/serialization/JavaSerializer$CurrentSystem; - -
in 0
class akka/serialization/JavaSerializer$CurrentSystem 50 public,final,super scala/util/DynamicVariable - Lscala/util/DynamicVariable<Lakka/actor/ExtendedActorSystem;>;
 inner akka/serialization/JavaSerializer$CurrentSystem akka/serialization/JavaSerializer CurrentSystem public,static,final
 method public withValue (Lakka/actor/ExtendedActorSystem;Ljava/util/concurrent/Callable;)Ljava/lang/Object; <S:Ljava/lang/Object;>(Lakka/actor/ExtendedActorSystem;Ljava/util/concurrent/Callable<TS;>;)TS; -
 method public <init> ()V - -
in 0
class akka/serialization/NullSerializer 50 public,super java/lang/Object akka/serialization/Serializer -
 method public,final fromBinary ([B)Ljava/lang/Object; - -
 method public,final fromBinary ([BLjava/lang/Class;)Ljava/lang/Object; ([BLjava/lang/Class<*>;)Ljava/lang/Object; -
 method public nullAsBytes ()[B - -
 method public includeManifest ()Z - -
 method public identifier ()I - -
 method public toBinary (Ljava/lang/Object;)[B - -
 method public fromBinary ([BLscala/Option;)Ljava/lang/Object; ([BLscala/Option<Ljava/lang/Class<*>;>;)Ljava/lang/Object; -
 method public <init> ()V - -
in 0
class akka/serialization/NullSerializer$ 50 public,final,super akka/serialization/NullSerializer - -
 field public,static,final MODULE$ Lakka/serialization/NullSerializer$; -
 method public,static <clinit> ()V - -
in 0
class akka/serialization/Serialization 50 public,super java/lang/Object akka/actor/Extension -
 inner scala/Predef$ArrowAssoc$ scala/Predef ArrowAssoc$ public,static
 inner akka/actor/ActorSystem$Settings akka/actor/ActorSystem Settings public,static
 inner akka/serialization/Serialization$Settings akka/serialization/Serialization Settings public,static
 inner akka/serialization/Serialization$Information akka/serialization/Serialization Information public,static
 inner akka/serialization/Serialization$Information$ akka/serialization/Serialization Information$ public,static
 method public,static serializedActorPath (Lakka/actor/ActorRef;)Ljava/lang/String; - -
 method public system ()Lakka/actor/ExtendedActorSystem; - -
 method public settings ()Lakka/serialization/Serialization$Settings; - -
 method public log ()Lakka/event/LoggingAdapter; - -
 method public serialize (Ljava/lang/Object;)Lscala/util/Try; (Ljava/lang/Object;)Lscala/util/Try<[B>; -
 method public deserialize ([BILscala/Option;)Lscala/util/Try; <T:Ljava/lang/Object;>([BILscala/Option<Ljava/lang/Class<+TT;>;>;)Lscala/util/Try<TT;>; -
 method public deserialize ([BLjava/lang/Class;)Lscala/util/Try; <T:Ljava/lang/Object;>([BLjava/lang/Class<TT;>;)Lscala/util/Try<TT;>; -
 method public findSerializerFor (Ljava/lang/Object;)Lakka/serialization/Serializer; - -
 method public serializerFor (Ljava/lang/Class;)Lakka/serialization/Serializer; (Ljava/lang/Class<*>;)Lakka/serialization/Serializer; -
 method public serializerOf (Ljava/lang/String;)Lscala/util/Try; (Ljava/lang/String;)Lscala/util/Try<Lakka/serialization/Serializer;>; -
 method public akka$serialization$Serialization$$serializers ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Lakka/serialization/Serializer;>; -
 method public bindings ()Lscala/collection/immutable/Seq; ()Lscala/collection/immutable/Seq<Lscala/Tuple2<Ljava/lang/Class<*>;Lakka/serialization/Serializer;>;>; -
 method public serializerByIdentity ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/Object;Lakka/serialization/Serializer;>; -
 method public <init> (Lakka/actor/ExtendedActorSystem;)V - -
in 0
class akka/serialization/Serialization$ 50 public,final,super java/lang/Object - -
 inner akka/serialization/Serialization$Settings akka/serialization/Serialization Settings public,static
 inner akka/serialization/Serialization$Information akka/serialization/Serialization Information public,static
 inner akka/serialization/Serialization$Information$ akka/serialization/Serialization Information$ public,static
 field public,static,final MODULE$ Lakka/serialization/Serialization$; -
 method public,static <clinit> ()V - -
 method public currentTransportInformation ()Lscala/util/DynamicVariable; ()Lscala/util/DynamicVariable<Lakka/serialization/Serialization$Information;>; -
 method public serializedActorPath (Lakka/actor/ActorRef;)Ljava/lang/String; - -
in 0
class akka/serialization/Serialization$Information 50 public,super java/lang/Object scala/Product,scala/Serializable -
 inner akka/serialization/Serialization$Information akka/serialization/Serialization Information public,static
 method public address ()Lakka/actor/Address; - -
 method public system ()Lakka/actor/ActorSystem; - -
 method public copy (Lakka/actor/Address;Lakka/actor/ActorSystem;)Lakka/serialization/Serialization$Information; - -
 method public copy$default$1 ()Lakka/actor/Address; - -
 method public copy$default$2 ()Lakka/actor/ActorSystem; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/actor/Address;Lakka/actor/ActorSystem;)V - -
in 0
class akka/serialization/Serialization$Information$ 50 public,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lakka/actor/Address;Lakka/actor/ActorSystem;Lakka/serialization/Serialization$Information;>;Lscala/Serializable;
 inner akka/serialization/Serialization$Information$ akka/serialization/Serialization Information$ public,static
 inner akka/serialization/Serialization$Information akka/serialization/Serialization Information public,static
 field public,static,final MODULE$ Lakka/serialization/Serialization$Information$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/actor/Address;Lakka/actor/ActorSystem;)Lakka/serialization/Serialization$Information; - -
 method public unapply (Lakka/serialization/Serialization$Information;)Lscala/Option; (Lakka/serialization/Serialization$Information;)Lscala/Option<Lscala/Tuple2<Lakka/actor/Address;Lakka/actor/ActorSystem;>;>; -
 method public <init> ()V - -
in 0
class akka/serialization/Serialization$Settings 50 public,super java/lang/Object - -
 inner scala/collection/convert/Decorators$AsScala scala/collection/convert/Decorators AsScala public
 inner akka/serialization/Serialization$Settings akka/serialization/Serialization Settings public,static
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public config ()Lcom/typesafe/config/Config; - -
 method public Serializers ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public SerializationBindings ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public <init> (Lcom/typesafe/config/Config;)V - -
in 0
class akka/serialization/SerializationExtension 50 public,final,super java/lang/Object - -
 method public,static equals (Ljava/lang/Object;)Z - -
 method public,static hashCode ()I - -
 method public,static apply (Lakka/actor/ActorSystem;)Lakka/actor/Extension; - -
 method public,static createExtension (Lakka/actor/ExtendedActorSystem;)Lakka/serialization/Serialization; - -
 method public,static lookup ()Lakka/serialization/SerializationExtension$; - -
 method public,static get (Lakka/actor/ActorSystem;)Lakka/serialization/Serialization; - -
in 0
class akka/serialization/SerializationExtension$ 50 public,final,super java/lang/Object akka/actor/ExtensionId,akka/actor/ExtensionIdProvider Ljava/lang/Object;Lakka/actor/ExtensionId<Lakka/serialization/Serialization;>;Lakka/actor/ExtensionIdProvider;
 field public,static,final MODULE$ Lakka/serialization/SerializationExtension$; -
 method public,static <clinit> ()V - -
 method public apply (Lakka/actor/ActorSystem;)Lakka/actor/Extension; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public get (Lakka/actor/ActorSystem;)Lakka/serialization/Serialization; - -
 method public lookup ()Lakka/serialization/SerializationExtension$; - -
 method public createExtension (Lakka/actor/ExtendedActorSystem;)Lakka/serialization/Serialization; - -
in 0
class akka/serialization/Serializer 50 public,interface,abstract java/lang/Object - -
 method public,abstract identifier ()I - -
 method public,abstract toBinary (Ljava/lang/Object;)[B - -
 method public,abstract includeManifest ()Z - -
 method public,abstract fromBinary ([BLscala/Option;)Ljava/lang/Object; ([BLscala/Option<Ljava/lang/Class<*>;>;)Ljava/lang/Object; -
 method public,abstract fromBinary ([B)Ljava/lang/Object; - -
 method public,abstract fromBinary ([BLjava/lang/Class;)Ljava/lang/Object; ([BLjava/lang/Class<*>;)Ljava/lang/Object; -
in 0
class akka/serialization/Serializer$class 50 public,super,abstract java/lang/Object - -
 method public,static,final fromBinary (Lakka/serialization/Serializer;[B)Ljava/lang/Object; - -
 method public,static,final fromBinary (Lakka/serialization/Serializer;[BLjava/lang/Class;)Ljava/lang/Object; - -
 method public,static $init$ (Lakka/serialization/Serializer;)V - -
