cg-stub-db 1
in 326
class net/minecraft/pathfinding/FlyingNodeProcessor 52 public,super net/minecraft/pathfinding/WalkNodeProcessor - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> ()V - -
 method public init (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;)V - -
 method public postProcess ()V - -
 method public getStart ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointToCoords (DDD)Lnet/minecraft/pathfinding/PathPoint; - -
 method public findPathOptions ([Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;F)I - -
 method protected openPoint (III)Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/entity/EntityLiving;IIIZZ)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
in 91
class net/minecraft/pathfinding/NodeProcessor 50 public,super,abstract java/lang/Object - -
 field protected blockaccess Lnet/minecraft/world/IBlockAccess; -
 field protected entity Lnet/minecraft/entity/EntityLiving; -
 field protected,final pointMap Lnet/minecraft/util/IntHashMap; Lnet/minecraft/util/IntHashMap<Lnet/minecraft/pathfinding/PathPoint;>;
 field protected entitySizeX I -
 field protected entitySizeY I -
 field protected entitySizeZ I -
 field protected canEnterDoors Z -
 field protected canBreakDoors Z -
 field protected canSwim Z -
 method public <init> ()V - -
 method public initProcessor (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;)V - -
 method public postProcess ()V - -
 method protected openPoint (III)Lnet/minecraft/pathfinding/PathPoint; - -
 method public,abstract getStart ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public,abstract getPathPointToCoords (DDD)Lnet/minecraft/pathfinding/PathPoint; - -
 method public,abstract findPathOptions ([Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;F)I - -
 method public,abstract getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/entity/EntityLiving;IIIZZ)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public,abstract getPathNodeType (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public setCanEnterDoors (Z)V - -
 method public setCanBreakDoors (Z)V - -
 method public setCanSwim (Z)V - -
 method public getCanEnterDoors ()Z - -
 method public getCanBreakDoors ()Z - -
 method public getCanSwim ()Z - -
in 326
class net/minecraft/pathfinding/NodeProcessor 52 public,super,abstract java/lang/Object - -
 field protected blockaccess Lnet/minecraft/world/IBlockAccess; -
 field protected entity Lnet/minecraft/entity/EntityLiving; -
 field protected,final pointMap Lnet/minecraft/util/IntHashMap; Lnet/minecraft/util/IntHashMap<Lnet/minecraft/pathfinding/PathPoint;>;
 field protected entitySizeX I -
 field protected entitySizeY I -
 field protected entitySizeZ I -
 field protected canEnterDoors Z -
 field protected canOpenDoors Z -
 field protected canSwim Z -
 method public <init> ()V - -
 method public init (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;)V - -
 method public postProcess ()V - -
 method protected openPoint (III)Lnet/minecraft/pathfinding/PathPoint; - -
 method public,abstract getStart ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public,abstract getPathPointToCoords (DDD)Lnet/minecraft/pathfinding/PathPoint; - -
 method public,abstract findPathOptions ([Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;F)I - -
 method public,abstract getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/entity/EntityLiving;IIIZZ)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public,abstract getPathNodeType (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public setCanEnterDoors (Z)V - -
 method public setCanOpenDoors (Z)V - -
 method public setCanSwim (Z)V - -
 method public getCanEnterDoors ()Z - -
 method public getCanOpenDoors ()Z - -
 method public getCanSwim ()Z - -
in 90
class net/minecraft/pathfinding/Path 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addPoint (Lnet/minecraft/pathfinding/PathPoint;)Lnet/minecraft/pathfinding/PathPoint; - -
 method public clearPath ()V - -
 method public dequeue ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public changeDistance (Lnet/minecraft/pathfinding/PathPoint;F)V - -
 method public isPathEmpty ()Z - -
in 91
class net/minecraft/pathfinding/Path 50 public,super java/lang/Object - -
 method public getOpenSet ()[Lnet/minecraft/pathfinding/PathPoint; - -
 method public getClosedSet ()[Lnet/minecraft/pathfinding/PathPoint; - -
 method public getTarget ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public,static read (Lnet/minecraft/network/PacketBuffer;)Lnet/minecraft/pathfinding/Path; - -
 method public <init> ([Lnet/minecraft/pathfinding/PathPoint;)V - -
 method public incrementPathIndex ()V - -
 method public isFinished ()Z - -
 method public getFinalPathPoint ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointFromIndex (I)Lnet/minecraft/pathfinding/PathPoint; - -
 method public setPoint (ILnet/minecraft/pathfinding/PathPoint;)V - -
 method public getCurrentPathLength ()I - -
 method public setCurrentPathLength (I)V - -
 method public getCurrentPathIndex ()I - -
 method public setCurrentPathIndex (I)V - -
 method public getVectorFromIndex (Lnet/minecraft/entity/Entity;I)Lnet/minecraft/util/math/Vec3d; - -
 method public getPosition (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/Vec3d; - -
 method public getCurrentPos ()Lnet/minecraft/util/math/Vec3d; - -
 method public isSamePath (Lnet/minecraft/pathfinding/Path;)Z - -
in 326
class net/minecraft/pathfinding/Path 52 public,super java/lang/Object - -
 method public <init> ([Lnet/minecraft/pathfinding/PathPoint;)V - -
 method public incrementPathIndex ()V - -
 method public isFinished ()Z - -
 method public getFinalPathPoint ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointFromIndex (I)Lnet/minecraft/pathfinding/PathPoint; - -
 method public setPoint (ILnet/minecraft/pathfinding/PathPoint;)V - -
 method public getCurrentPathLength ()I - -
 method public setCurrentPathLength (I)V - -
 method public getCurrentPathIndex ()I - -
 method public setCurrentPathIndex (I)V - -
 method public getVectorFromIndex (Lnet/minecraft/entity/Entity;I)Lnet/minecraft/util/math/Vec3d; - -
 method public getPosition (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/Vec3d; - -
 method public getCurrentPos ()Lnet/minecraft/util/math/Vec3d; - -
 method public isSamePath (Lnet/minecraft/pathfinding/Path;)Z - -
 method public getOpenSet ()[Lnet/minecraft/pathfinding/PathPoint; - -
 method public getClosedSet ()[Lnet/minecraft/pathfinding/PathPoint; - -
 method public getTarget ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public,static read (Lnet/minecraft/network/PacketBuffer;)Lnet/minecraft/pathfinding/Path; - -
in 90
class net/minecraft/pathfinding/PathEntity 50 public,super java/lang/Object - -
 method public <init> ([Lnet/minecraft/pathfinding/PathPoint;)V - -
 method public incrementPathIndex ()V - -
 method public isFinished ()Z - -
 method public getFinalPathPoint ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointFromIndex (I)Lnet/minecraft/pathfinding/PathPoint; - -
 method public getCurrentPathLength ()I - -
 method public setCurrentPathLength (I)V - -
 method public getCurrentPathIndex ()I - -
 method public setCurrentPathIndex (I)V - -
 method public getVectorFromIndex (Lnet/minecraft/entity/Entity;I)Lnet/minecraft/util/Vec3; - -
 method public getPosition (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/Vec3; - -
 method public isSamePath (Lnet/minecraft/pathfinding/PathEntity;)Z - -
 method public isDestinationSame (Lnet/minecraft/util/Vec3;)Z - -
in 90
class net/minecraft/pathfinding/PathFinder 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/world/pathfinder/NodeProcessor;)V - -
 method public createEntityPathTo (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/Entity;F)Lnet/minecraft/pathfinding/PathEntity; - -
 method public createEntityPathTo (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/BlockPos;F)Lnet/minecraft/pathfinding/PathEntity; - -
in 91
class net/minecraft/pathfinding/PathFinder 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/pathfinding/NodeProcessor;)V - -
 method public findPath (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/entity/Entity;F)Lnet/minecraft/pathfinding/Path; - -
 method public findPath (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/util/math/BlockPos;F)Lnet/minecraft/pathfinding/Path; - -
in 326
class net/minecraft/pathfinding/PathFinder 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/pathfinding/NodeProcessor;)V - -
 method public findPath (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/entity/Entity;F)Lnet/minecraft/pathfinding/Path; - -
 method public findPath (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/util/math/BlockPos;F)Lnet/minecraft/pathfinding/Path; - -
in 91
class net/minecraft/pathfinding/PathHeap 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addPoint (Lnet/minecraft/pathfinding/PathPoint;)Lnet/minecraft/pathfinding/PathPoint; - -
 method public clearPath ()V - -
 method public dequeue ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public changeDistance (Lnet/minecraft/pathfinding/PathPoint;F)V - -
 method public isPathEmpty ()Z - -
in 326
class net/minecraft/pathfinding/PathHeap 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public addPoint (Lnet/minecraft/pathfinding/PathPoint;)Lnet/minecraft/pathfinding/PathPoint; - -
 method public clearPath ()V - -
 method public dequeue ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public changeDistance (Lnet/minecraft/pathfinding/PathPoint;F)V - -
 method public isPathEmpty ()Z - -
in 90
class net/minecraft/pathfinding/PathNavigate 50 public,super,abstract java/lang/Object - -
 field protected theEntity Lnet/minecraft/entity/EntityLiving; -
 field protected worldObj Lnet/minecraft/world/World; -
 field protected currentPath Lnet/minecraft/pathfinding/PathEntity; -
 field protected speed D -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected,abstract getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method public setSpeed (D)V - -
 method public getPathSearchRange ()F - -
 method public,final getPathToXYZ (DDD)Lnet/minecraft/pathfinding/PathEntity; - -
 method public getPathToPos (Lnet/minecraft/util/BlockPos;)Lnet/minecraft/pathfinding/PathEntity; - -
 method public tryMoveToXYZ (DDDD)Z - -
 method public setHeightRequirement (F)V - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/PathEntity; - -
 method public tryMoveToEntityLiving (Lnet/minecraft/entity/Entity;D)Z - -
 method public setPath (Lnet/minecraft/pathfinding/PathEntity;D)Z - -
 method public getPath ()Lnet/minecraft/pathfinding/PathEntity; - -
 method public onUpdateNavigation ()V - -
 method protected pathFollow ()V - -
 method protected checkForStuck (Lnet/minecraft/util/Vec3;)V - -
 method public noPath ()Z - -
 method public clearPathEntity ()V - -
 method protected,abstract getEntityPosition ()Lnet/minecraft/util/Vec3; - -
 method protected,abstract canNavigate ()Z - -
 method protected isInLiquid ()Z - -
 method protected removeSunnyPath ()V - -
 method protected,abstract isDirectPathBetweenPoints (Lnet/minecraft/util/Vec3;Lnet/minecraft/util/Vec3;III)Z - -
in 91
class net/minecraft/pathfinding/PathNavigate 50 public,super,abstract java/lang/Object - -
 field protected theEntity Lnet/minecraft/entity/EntityLiving; -
 field protected world Lnet/minecraft/world/World; -
 field protected currentPath Lnet/minecraft/pathfinding/Path; -
 field protected speed D -
 field protected nodeProcessor Lnet/minecraft/pathfinding/NodeProcessor; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected,abstract getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method public setSpeed (D)V - -
 method public getPathSearchRange ()F - -
 method public canUpdatePathOnTimeout ()Z - -
 method public updatePath ()V - -
 method public,final getPathToXYZ (DDD)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToPos (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/Path; - -
 method public tryMoveToXYZ (DDDD)Z - -
 method public tryMoveToEntityLiving (Lnet/minecraft/entity/Entity;D)Z - -
 method public setPath (Lnet/minecraft/pathfinding/Path;D)Z - -
 method public getPath ()Lnet/minecraft/pathfinding/Path; - -
 method public onUpdateNavigation ()V - -
 method protected pathFollow ()V - -
 method protected checkForStuck (Lnet/minecraft/util/math/Vec3d;)V - -
 method public noPath ()Z - -
 method public clearPathEntity ()V - -
 method protected,abstract getEntityPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method protected,abstract canNavigate ()Z - -
 method protected isInLiquid ()Z - -
 method protected removeSunnyPath ()V - -
 method protected,abstract isDirectPathBetweenPoints (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;III)Z - -
 method public canEntityStandOnPos (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public getNodeProcessor ()Lnet/minecraft/pathfinding/NodeProcessor; - -
in 326
class net/minecraft/pathfinding/PathNavigate 52 public,super,abstract java/lang/Object - -
 field protected entity Lnet/minecraft/entity/EntityLiving; -
 field protected world Lnet/minecraft/world/World; -
 field protected currentPath Lnet/minecraft/pathfinding/Path; -
 field protected speed D -
 field protected totalTicks I -
 field protected maxDistanceToWaypoint F -
 field protected tryUpdatePath Z -
 field protected nodeProcessor Lnet/minecraft/pathfinding/NodeProcessor; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected,abstract getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method public setSpeed (D)V - -
 method public getPathSearchRange ()F - -
 method public canUpdatePathOnTimeout ()Z - -
 method public updatePath ()V - -
 method public,final getPathToXYZ (DDD)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToPos (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/Path; - -
 method public tryMoveToXYZ (DDDD)Z - -
 method public tryMoveToEntityLiving (Lnet/minecraft/entity/Entity;D)Z - -
 method public setPath (Lnet/minecraft/pathfinding/Path;D)Z - -
 method public getPath ()Lnet/minecraft/pathfinding/Path; - -
 method public onUpdateNavigation ()V - -
 method protected debugPathFinding ()V - -
 method protected pathFollow ()V - -
 method protected checkForStuck (Lnet/minecraft/util/math/Vec3d;)V - -
 method public noPath ()Z - -
 method public clearPath ()V - -
 method protected,abstract getEntityPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method protected,abstract canNavigate ()Z - -
 method protected isInLiquid ()Z - -
 method protected removeSunnyPath ()V - -
 method protected,abstract isDirectPathBetweenPoints (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;III)Z - -
 method public canEntityStandOnPos (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public getNodeProcessor ()Lnet/minecraft/pathfinding/NodeProcessor; - -
in 90
class net/minecraft/pathfinding/PathNavigateClimber 50 public,super net/minecraft/pathfinding/PathNavigateGround - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method public getPathToPos (Lnet/minecraft/util/BlockPos;)Lnet/minecraft/pathfinding/PathEntity; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/PathEntity; - -
 method public tryMoveToEntityLiving (Lnet/minecraft/entity/Entity;D)Z - -
 method public onUpdateNavigation ()V - -
in 91
class net/minecraft/pathfinding/PathNavigateClimber 50 public,super net/minecraft/pathfinding/PathNavigateGround - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method public getPathToPos (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/Path; - -
 method public tryMoveToEntityLiving (Lnet/minecraft/entity/Entity;D)Z - -
 method public onUpdateNavigation ()V - -
in 326
class net/minecraft/pathfinding/PathNavigateClimber 52 public,super net/minecraft/pathfinding/PathNavigateGround - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method public getPathToPos (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/Path; - -
 method public tryMoveToEntityLiving (Lnet/minecraft/entity/Entity;D)Z - -
 method public onUpdateNavigation ()V - -
in 326
class net/minecraft/pathfinding/PathNavigateFlying 52 public,super net/minecraft/pathfinding/PathNavigate - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method protected canNavigate ()Z - -
 method protected getEntityPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/Path; - -
 method public onUpdateNavigation ()V - -
 method protected isDirectPathBetweenPoints (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;III)Z - -
 method public setCanOpenDoors (Z)V - -
 method public setCanEnterDoors (Z)V - -
 method public setCanFloat (Z)V - -
 method public canFloat ()Z - -
 method public canEntityStandOnPos (Lnet/minecraft/util/math/BlockPos;)Z - -
in 90
class net/minecraft/pathfinding/PathNavigateGround 50 public,super net/minecraft/pathfinding/PathNavigate - -
 field protected nodeProcessor Lnet/minecraft/world/pathfinder/WalkNodeProcessor; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method protected canNavigate ()Z - -
 method protected getEntityPosition ()Lnet/minecraft/util/Vec3; - -
 method protected removeSunnyPath ()V - -
 method protected isDirectPathBetweenPoints (Lnet/minecraft/util/Vec3;Lnet/minecraft/util/Vec3;III)Z - -
 method public setAvoidsWater (Z)V - -
 method public getAvoidsWater ()Z - -
 method public setBreakDoors (Z)V - -
 method public setEnterDoors (Z)V - -
 method public getEnterDoors ()Z - -
 method public setCanSwim (Z)V - -
 method public getCanSwim ()Z - -
 method public setAvoidSun (Z)V - -
in 91
class net/minecraft/pathfinding/PathNavigateGround 50 public,super net/minecraft/pathfinding/PathNavigate - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method protected canNavigate ()Z - -
 method protected getEntityPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPathToPos (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/Path; - -
 method protected removeSunnyPath ()V - -
 method protected isDirectPathBetweenPoints (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;III)Z - -
 method public setBreakDoors (Z)V - -
 method public setEnterDoors (Z)V - -
 method public getEnterDoors ()Z - -
 method public setCanSwim (Z)V - -
 method public getCanSwim ()Z - -
 method public setAvoidSun (Z)V - -
in 326
class net/minecraft/pathfinding/PathNavigateGround 52 public,super net/minecraft/pathfinding/PathNavigate - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method protected canNavigate ()Z - -
 method protected getEntityPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPathToPos (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/Path; - -
 method public getPathToEntityLiving (Lnet/minecraft/entity/Entity;)Lnet/minecraft/pathfinding/Path; - -
 method protected removeSunnyPath ()V - -
 method protected isDirectPathBetweenPoints (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;III)Z - -
 method public setBreakDoors (Z)V - -
 method public setEnterDoors (Z)V - -
 method public getEnterDoors ()Z - -
 method public setCanSwim (Z)V - -
 method public getCanSwim ()Z - -
 method public setAvoidSun (Z)V - -
in 90
class net/minecraft/pathfinding/PathNavigateSwimmer 50 public,super net/minecraft/pathfinding/PathNavigate - -
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method protected canNavigate ()Z - -
 method protected getEntityPosition ()Lnet/minecraft/util/Vec3; - -
 method protected pathFollow ()V - -
 method protected removeSunnyPath ()V - -
 method protected isDirectPathBetweenPoints (Lnet/minecraft/util/Vec3;Lnet/minecraft/util/Vec3;III)Z - -
in 91
class net/minecraft/pathfinding/PathNavigateSwimmer 50 public,super net/minecraft/pathfinding/PathNavigate - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method protected canNavigate ()Z - -
 method protected getEntityPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method protected pathFollow ()V - -
 method protected removeSunnyPath ()V - -
 method protected isDirectPathBetweenPoints (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;III)Z - -
 method public canEntityStandOnPos (Lnet/minecraft/util/math/BlockPos;)Z - -
in 326
class net/minecraft/pathfinding/PathNavigateSwimmer 52 public,super net/minecraft/pathfinding/PathNavigate - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/world/World;)V - -
 method protected getPathFinder ()Lnet/minecraft/pathfinding/PathFinder; - -
 method protected canNavigate ()Z - -
 method protected getEntityPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method protected pathFollow ()V - -
 method protected isDirectPathBetweenPoints (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;III)Z - -
 method public canEntityStandOnPos (Lnet/minecraft/util/math/BlockPos;)Z - -
in 91
class net/minecraft/pathfinding/PathNodeType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/pathfinding/PathNodeType;>;
 field public,static,final,enum BLOCKED Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum OPEN Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum WALKABLE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum TRAPDOOR Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum FENCE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum LAVA Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum WATER Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum RAIL Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DANGER_FIRE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DAMAGE_FIRE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DANGER_CACTUS Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DAMAGE_CACTUS Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DANGER_OTHER Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DAMAGE_OTHER Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DOOR_OPEN Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DOOR_WOOD_CLOSED Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DOOR_IRON_CLOSED Lnet/minecraft/pathfinding/PathNodeType; -
 method public,static values ()[Lnet/minecraft/pathfinding/PathNodeType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public getPriority ()F - -
in 326
class net/minecraft/pathfinding/PathNodeType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/pathfinding/PathNodeType;>;
 field public,static,final,enum BLOCKED Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum OPEN Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum WALKABLE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum TRAPDOOR Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum FENCE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum LAVA Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum WATER Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum RAIL Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DANGER_FIRE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DAMAGE_FIRE Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DANGER_CACTUS Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DAMAGE_CACTUS Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DANGER_OTHER Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DAMAGE_OTHER Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DOOR_OPEN Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DOOR_WOOD_CLOSED Lnet/minecraft/pathfinding/PathNodeType; -
 field public,static,final,enum DOOR_IRON_CLOSED Lnet/minecraft/pathfinding/PathNodeType; -
 method public,static values ()[Lnet/minecraft/pathfinding/PathNodeType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public getPriority ()F - -
in 90
class net/minecraft/pathfinding/PathPoint 50 public,super java/lang/Object - -
 field public,final xCoord I -
 field public,final yCoord I -
 field public,final zCoord I -
 field public visited Z -
 method public <init> (III)V - -
 method public,static makeHash (III)I - -
 method public distanceTo (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public distanceToSquared (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public isAssigned ()Z - -
 method public toString ()Ljava/lang/String; - -
in 91
class net/minecraft/pathfinding/PathPoint 50 public,super java/lang/Object - -
 field public,final xCoord I -
 field public,final yCoord I -
 field public,final zCoord I -
 field public index I -
 field public totalPathDistance F -
 field public distanceToNext F -
 field public distanceToTarget F -
 field public previous Lnet/minecraft/pathfinding/PathPoint; -
 field public visited Z -
 field public distanceFromOrigin F -
 field public cost F -
 field public costMalus F -
 field public nodeType Lnet/minecraft/pathfinding/PathNodeType; -
 method public,static createFromBuffer (Lnet/minecraft/network/PacketBuffer;)Lnet/minecraft/pathfinding/PathPoint; - -
 method public <init> (III)V - -
 method public cloneMove (III)Lnet/minecraft/pathfinding/PathPoint; - -
 method public,static makeHash (III)I - -
 method public distanceTo (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public distanceToSquared (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public distanceManhattan (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public isAssigned ()Z - -
 method public toString ()Ljava/lang/String; - -
in 326
class net/minecraft/pathfinding/PathPoint 52 public,super java/lang/Object - -
 field public,final x I -
 field public,final y I -
 field public,final z I -
 field public index I -
 field public totalPathDistance F -
 field public distanceToNext F -
 field public distanceToTarget F -
 field public previous Lnet/minecraft/pathfinding/PathPoint; -
 field public visited Z -
 field public distanceFromOrigin F -
 field public cost F -
 field public costMalus F -
 field public nodeType Lnet/minecraft/pathfinding/PathNodeType; -
 method public <init> (III)V - -
 method public cloneMove (III)Lnet/minecraft/pathfinding/PathPoint; - -
 method public,static makeHash (III)I - -
 method public distanceTo (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public distanceToSquared (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public distanceManhattan (Lnet/minecraft/pathfinding/PathPoint;)F - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public isAssigned ()Z - -
 method public toString ()Ljava/lang/String; - -
 method public,static createFromBuffer (Lnet/minecraft/network/PacketBuffer;)Lnet/minecraft/pathfinding/PathPoint; - -
in 91
class net/minecraft/pathfinding/PathWorldListener 50 public,super java/lang/Object net/minecraft/world/IWorldEventListener -
 method public <init> ()V - -
 method public notifyBlockUpdate (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/block/state/IBlockState;I)V - -
 method protected didBlockChange (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/block/state/IBlockState;)Z - -
 method public notifyLightSet (Lnet/minecraft/util/math/BlockPos;)V - -
 method public markBlockRangeForRenderUpdate (IIIIII)V - -
 method public playSoundToAllNearExcept (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/SoundEvent;Lnet/minecraft/util/SoundCategory;DDDFF)V - -
 method public,varargs spawnParticle (IZDDDDDD[I)V - -
 method public onEntityAdded (Lnet/minecraft/entity/Entity;)V - -
 method public onEntityRemoved (Lnet/minecraft/entity/Entity;)V - -
 method public playRecord (Lnet/minecraft/util/SoundEvent;Lnet/minecraft/util/math/BlockPos;)V - -
 method public broadcastSound (ILnet/minecraft/util/math/BlockPos;I)V - -
 method public playEvent (Lnet/minecraft/entity/player/EntityPlayer;ILnet/minecraft/util/math/BlockPos;I)V - -
 method public sendBlockBreakProgress (ILnet/minecraft/util/math/BlockPos;I)V - -
in 326
class net/minecraft/pathfinding/PathWorldListener 52 public,super java/lang/Object net/minecraft/world/IWorldEventListener -
 method public <init> ()V - -
 method public notifyBlockUpdate (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/block/state/IBlockState;I)V - -
 method protected didBlockChange (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/block/state/IBlockState;)Z - -
 method public notifyLightSet (Lnet/minecraft/util/math/BlockPos;)V - -
 method public markBlockRangeForRenderUpdate (IIIIII)V - -
 method public playSoundToAllNearExcept (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/SoundEvent;Lnet/minecraft/util/SoundCategory;DDDFF)V - -
 method public,varargs spawnParticle (IZDDDDDD[I)V - -
 method public,varargs spawnParticle (IZZDDDDDD[I)V - -
 method public onEntityAdded (Lnet/minecraft/entity/Entity;)V - -
 method public onEntityRemoved (Lnet/minecraft/entity/Entity;)V - -
 method public playRecord (Lnet/minecraft/util/SoundEvent;Lnet/minecraft/util/math/BlockPos;)V - -
 method public broadcastSound (ILnet/minecraft/util/math/BlockPos;I)V - -
 method public playEvent (Lnet/minecraft/entity/player/EntityPlayer;ILnet/minecraft/util/math/BlockPos;I)V - -
 method public sendBlockBreakProgress (ILnet/minecraft/util/math/BlockPos;I)V - -
in 91
class net/minecraft/pathfinding/SwimNodeProcessor 50 public,super net/minecraft/pathfinding/NodeProcessor - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> ()V - -
 method public getStart ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointToCoords (DDD)Lnet/minecraft/pathfinding/PathPoint; - -
 method public findPathOptions ([Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;F)I - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/entity/EntityLiving;IIIZZ)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
in 326
class net/minecraft/pathfinding/SwimNodeProcessor 52 public,super net/minecraft/pathfinding/NodeProcessor - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> ()V - -
 method public getStart ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointToCoords (DDD)Lnet/minecraft/pathfinding/PathPoint; - -
 method public findPathOptions ([Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;F)I - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/entity/EntityLiving;IIIZZ)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
in 91
class net/minecraft/pathfinding/WalkNodeProcessor 50 public,super net/minecraft/pathfinding/NodeProcessor - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 method public <init> ()V - -
 method public initProcessor (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;)V - -
 method public postProcess ()V - -
 method public getStart ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointToCoords (DDD)Lnet/minecraft/pathfinding/PathPoint; - -
 method public findPathOptions ([Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;F)I - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/entity/EntityLiving;IIIZZ)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
in 326
class net/minecraft/pathfinding/WalkNodeProcessor 52 public,super net/minecraft/pathfinding/NodeProcessor - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 field protected avoidsWater F -
 field protected currentEntity Lnet/minecraft/entity/EntityLiving; -
 method public <init> ()V - -
 method public init (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/entity/EntityLiving;)V - -
 method public postProcess ()V - -
 method public getStart ()Lnet/minecraft/pathfinding/PathPoint; - -
 method public getPathPointToCoords (DDD)Lnet/minecraft/pathfinding/PathPoint; - -
 method public findPathOptions ([Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;Lnet/minecraft/pathfinding/PathPoint;F)I - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/entity/EntityLiving;IIIZZ)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;IIIIIIZZLjava/util/EnumSet;Lnet/minecraft/pathfinding/PathNodeType;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/PathNodeType; (Lnet/minecraft/world/IBlockAccess;IIIIIIZZLjava/util/EnumSet<Lnet/minecraft/pathfinding/PathNodeType;>;Lnet/minecraft/pathfinding/PathNodeType;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/pathfinding/PathNodeType; -
 method public getPathNodeType (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
 method public checkNeighborBlocks (Lnet/minecraft/world/IBlockAccess;IIILnet/minecraft/pathfinding/PathNodeType;)Lnet/minecraft/pathfinding/PathNodeType; - -
 method protected getPathNodeTypeRaw (Lnet/minecraft/world/IBlockAccess;III)Lnet/minecraft/pathfinding/PathNodeType; - -
