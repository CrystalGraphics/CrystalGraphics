cg-stub-db 1
in 1110
class org/intellij/lang/annotations/Flow 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#METHOD])
 field public,static,final DEFAULT_SOURCE Ljava/lang/String; - "The method argument (if parameter was annotated) or this container (if instance method was annotated)"
 field public,static,final THIS_SOURCE Ljava/lang/String; - "this"
 field public,static,final DEFAULT_TARGET Ljava/lang/String; - "This container (if the parameter was annotated) or the return value (if instance method was annotated)"
 field public,static,final RETURN_METHOD_TARGET Ljava/lang/String; - "The return value of this method"
 field public,static,final THIS_TARGET Ljava/lang/String; - "this"
 method public,abstract source ()Ljava/lang/String; - - "The method argument (if parameter was annotated) or this container (if instance method was annotated)"
 method public,abstract sourceIsContainer ()Z - - Z0
 method public,abstract target ()Ljava/lang/String; - - "This container (if the parameter was annotated) or the return value (if instance method was annotated)"
 method public,abstract targetIsContainer ()Z - - Z0
in 1110
class org/intellij/lang/annotations/Identifier 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
in 1110
class org/intellij/lang/annotations/JdkConstants 52 public,final,super,deprecated java/lang/Object - -
 inner org/intellij/lang/annotations/JdkConstants$TabLayoutPolicy org/intellij/lang/annotations/JdkConstants TabLayoutPolicy public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$TabPlacement org/intellij/lang/annotations/JdkConstants TabPlacement public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$TitledBorderTitlePosition org/intellij/lang/annotations/JdkConstants TitledBorderTitlePosition public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$TitledBorderJustification org/intellij/lang/annotations/JdkConstants TitledBorderJustification public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$FontStyle org/intellij/lang/annotations/JdkConstants FontStyle public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$TreeSelectionMode org/intellij/lang/annotations/JdkConstants TreeSelectionMode public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$ListSelectionMode org/intellij/lang/annotations/JdkConstants ListSelectionMode public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$BoxLayoutAxis org/intellij/lang/annotations/JdkConstants BoxLayoutAxis public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$PatternFlags org/intellij/lang/annotations/JdkConstants PatternFlags public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$CalendarMonth org/intellij/lang/annotations/JdkConstants CalendarMonth public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$HorizontalScrollBarPolicy org/intellij/lang/annotations/JdkConstants HorizontalScrollBarPolicy public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$VerticalScrollBarPolicy org/intellij/lang/annotations/JdkConstants VerticalScrollBarPolicy public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$AdjustableOrientation org/intellij/lang/annotations/JdkConstants AdjustableOrientation public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$InputEventMask org/intellij/lang/annotations/JdkConstants InputEventMask public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$CursorType org/intellij/lang/annotations/JdkConstants CursorType public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$FlowLayoutAlignment org/intellij/lang/annotations/JdkConstants FlowLayoutAlignment public,static,interface,abstract,annotation
 inner org/intellij/lang/annotations/JdkConstants$HorizontalAlignment org/intellij/lang/annotations/JdkConstants HorizontalAlignment public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$AdjustableOrientation 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$AdjustableOrientation org/intellij/lang/annotations/JdkConstants AdjustableOrientation public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$BoxLayoutAxis 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$BoxLayoutAxis org/intellij/lang/annotations/JdkConstants BoxLayoutAxis public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$CalendarMonth 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$CalendarMonth org/intellij/lang/annotations/JdkConstants CalendarMonth public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$CursorType 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$CursorType org/intellij/lang/annotations/JdkConstants CursorType public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$FlowLayoutAlignment 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$FlowLayoutAlignment org/intellij/lang/annotations/JdkConstants FlowLayoutAlignment public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$FontStyle 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$FontStyle org/intellij/lang/annotations/JdkConstants FontStyle public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$HorizontalAlignment 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$HorizontalAlignment org/intellij/lang/annotations/JdkConstants HorizontalAlignment public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$HorizontalScrollBarPolicy 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$HorizontalScrollBarPolicy org/intellij/lang/annotations/JdkConstants HorizontalScrollBarPolicy public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$InputEventMask 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$InputEventMask org/intellij/lang/annotations/JdkConstants InputEventMask public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$ListSelectionMode 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$ListSelectionMode org/intellij/lang/annotations/JdkConstants ListSelectionMode public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$PatternFlags 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$PatternFlags org/intellij/lang/annotations/JdkConstants PatternFlags public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$TabLayoutPolicy 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$TabLayoutPolicy org/intellij/lang/annotations/JdkConstants TabLayoutPolicy public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$TabPlacement 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$TabPlacement org/intellij/lang/annotations/JdkConstants TabPlacement public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$TitledBorderJustification 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$TitledBorderJustification org/intellij/lang/annotations/JdkConstants TitledBorderJustification public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$TitledBorderTitlePosition 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$TitledBorderTitlePosition org/intellij/lang/annotations/JdkConstants TitledBorderTitlePosition public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$TreeSelectionMode 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$TreeSelectionMode org/intellij/lang/annotations/JdkConstants TreeSelectionMode public,static,interface,abstract,annotation
in 1110
class org/intellij/lang/annotations/JdkConstants$VerticalScrollBarPolicy 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner org/intellij/lang/annotations/JdkConstants$VerticalScrollBarPolicy org/intellij/lang/annotations/JdkConstants VerticalScrollBarPolicy public,static,interface,abstract,annotation
in 1111
class org/intellij/lang/annotations/Language 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()Ljava/lang/String; - -
 method public,abstract prefix ()Ljava/lang/String; - - ""
 method public,abstract suffix ()Ljava/lang/String; - - ""
in 350
class org/intellij/lang/annotations/Language 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()Ljava/lang/String; - -
 method public,abstract prefix ()Ljava/lang/String; - - ""
 method public,abstract suffix ()Ljava/lang/String; - - ""
in 1111
class org/intellij/lang/annotations/MagicConstant 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract intValues ()[J - - []
 method public,abstract stringValues ()[Ljava/lang/String; - - []
 method public,abstract flags ()[J - - []
 method public,abstract valuesFromClass ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
 method public,abstract flagsFromClass ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
in 350
class org/intellij/lang/annotations/MagicConstant 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#SOURCE)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE,ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract intValues ()[J - - []
 method public,abstract stringValues ()[Ljava/lang/String; - - []
 method public,abstract flags ()[J - - []
 method public,abstract valuesFromClass ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
 method public,abstract flagsFromClass ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TV
in 1111
class org/intellij/lang/annotations/Pattern 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()Ljava/lang/String; - -
in 350
class org/intellij/lang/annotations/Pattern 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract value ()Ljava/lang/String; - -
in 1111
class org/intellij/lang/annotations/PrintFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
in 350
class org/intellij/lang/annotations/PrintFormat 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
in 1110
class org/intellij/lang/annotations/PrintFormatPattern 52 super java/lang/Object - -
in 1111
class org/intellij/lang/annotations/RegExp 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract prefix ()Ljava/lang/String; - - ""
 method public,abstract suffix ()Ljava/lang/String; - - ""
in 350
class org/intellij/lang/annotations/RegExp 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#PARAMETER,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 method public,abstract prefix ()Ljava/lang/String; - - ""
 method public,abstract suffix ()Ljava/lang/String; - - ""
in 1110
class org/intellij/lang/annotations/Subst 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#LOCAL_VARIABLE,ELjava/lang/annotation/ElementType;#PARAMETER])
 method public,abstract value ()Ljava/lang/String; - -
