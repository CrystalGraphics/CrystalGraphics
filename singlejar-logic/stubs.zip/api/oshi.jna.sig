cg-stub-db 1
in 39
class oshi/jna/ByRef 52 public,interface,abstract java/lang/Object - -
 inner oshi/jna/ByRef$CloseablePROCESSENTRY32ByReference oshi/jna/ByRef CloseablePROCESSENTRY32ByReference public,static
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 inner oshi/jna/ByRef$CloseableULONGptrByReference oshi/jna/ByRef CloseableULONGptrByReference public,static
 inner oshi/jna/ByRef$CloseableLONGLONGByReference oshi/jna/ByRef CloseableLONGLONGByReference public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner oshi/jna/ByRef$CloseableNativeLongByReference oshi/jna/ByRef CloseableNativeLongByReference public,static
 inner oshi/jna/ByRef$CloseableLongByReference oshi/jna/ByRef CloseableLongByReference public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
in 39
class oshi/jna/ByRef$CloseableHANDLEByReference 52 public,super com/sun/jna/platform/win32/WinNT$HANDLEByReference java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseableIntByReference 52 public,super com/sun/jna/ptr/IntByReference java/lang/AutoCloseable -
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 method public <init> ()V - -
 method public <init> (I)V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseableLONGLONGByReference 52 public,super com/sun/jna/platform/win32/WinDef$LONGLONGByReference java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/WinDef$LONGLONGByReference com/sun/jna/platform/win32/WinDef LONGLONGByReference public,static
 inner oshi/jna/ByRef$CloseableLONGLONGByReference oshi/jna/ByRef CloseableLONGLONGByReference public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseableLongByReference 52 public,super com/sun/jna/ptr/LongByReference java/lang/AutoCloseable -
 inner oshi/jna/ByRef$CloseableLongByReference oshi/jna/ByRef CloseableLongByReference public,static
 method public <init> ()V - -
 method public <init> (J)V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseableNativeLongByReference 52 public,super com/sun/jna/ptr/NativeLongByReference java/lang/AutoCloseable -
 inner oshi/jna/ByRef$CloseableNativeLongByReference oshi/jna/ByRef CloseableNativeLongByReference public,static
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/NativeLong;)V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseablePROCESSENTRY32ByReference 52 public,super com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32$ByReference java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 com/sun/jna/platform/win32/Tlhelp32 PROCESSENTRY32 public,static
 inner com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32$ByReference com/sun/jna/platform/win32/Tlhelp32$PROCESSENTRY32 ByReference public,static
 inner oshi/jna/ByRef$CloseablePROCESSENTRY32ByReference oshi/jna/ByRef CloseablePROCESSENTRY32ByReference public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseablePointerByReference 52 public,super com/sun/jna/ptr/PointerByReference java/lang/AutoCloseable -
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseableSizeTByReference 52 public,super com/sun/jna/platform/unix/LibCAPI$size_t$ByReference java/lang/AutoCloseable -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 method public <init> ()V - -
 method public <init> (J)V - -
 method public close ()V - -
in 39
class oshi/jna/ByRef$CloseableULONGptrByReference 52 public,super com/sun/jna/platform/win32/BaseTSD$ULONG_PTRByReference java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTRByReference com/sun/jna/platform/win32/BaseTSD ULONG_PTRByReference public,static
 inner oshi/jna/ByRef$CloseableULONGptrByReference oshi/jna/ByRef CloseableULONGptrByReference public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct 52 public,interface,abstract java/lang/Object - -
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 inner oshi/jna/Struct$CloseableSpDevinfoData oshi/jna/Struct CloseableSpDevinfoData public,static
 inner oshi/jna/Struct$CloseableSpDeviceInterfaceData oshi/jna/Struct CloseableSpDeviceInterfaceData public,static
 inner oshi/jna/Struct$CloseablePerformanceInformation oshi/jna/Struct CloseablePerformanceInformation public,static
 inner oshi/jna/Struct$CloseablePdhRawCounter oshi/jna/Struct CloseablePdhRawCounter public,static
 inner oshi/jna/Struct$CloseableMibUdpStats oshi/jna/Struct CloseableMibUdpStats public,static
 inner oshi/jna/Struct$CloseableMibTcpStats oshi/jna/Struct CloseableMibTcpStats public,static
 inner oshi/jna/Struct$CloseableMibIfRow2 oshi/jna/Struct CloseableMibIfRow2 public,static
 inner oshi/jna/Struct$CloseableMibIfRow oshi/jna/Struct CloseableMibIfRow public,static
 inner oshi/jna/Struct$CloseableXswUsage oshi/jna/Struct CloseableXswUsage public,static
 inner oshi/jna/Struct$CloseableVnodePathInfo oshi/jna/Struct CloseableVnodePathInfo public,static
 inner oshi/jna/Struct$CloseableVMStatistics oshi/jna/Struct CloseableVMStatistics public,static
 inner oshi/jna/Struct$CloseableTimeval oshi/jna/Struct CloseableTimeval public,static
 inner oshi/jna/Struct$CloseableRUsageInfoV2 oshi/jna/Struct CloseableRUsageInfoV2 public,static
 inner oshi/jna/Struct$CloseableProcTaskAllInfo oshi/jna/Struct CloseableProcTaskAllInfo public,static
 inner oshi/jna/Struct$CloseableProcTaskInfo oshi/jna/Struct CloseableProcTaskInfo public,static
 inner oshi/jna/Struct$CloseableHostCpuLoadInfo oshi/jna/Struct CloseableHostCpuLoadInfo public,static
 inner oshi/jna/Struct$CloseableSysinfo oshi/jna/Struct CloseableSysinfo public,static
in 39
class oshi/jna/Struct$CloseableHostCpuLoadInfo 52 public,super com/sun/jna/platform/mac/SystemB$HostCpuLoadInfo java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$HostCpuLoadInfo com/sun/jna/platform/mac/SystemB HostCpuLoadInfo public,static
 inner oshi/jna/Struct$CloseableHostCpuLoadInfo oshi/jna/Struct CloseableHostCpuLoadInfo public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableMibIfRow 52 public,super com/sun/jna/platform/win32/IPHlpAPI$MIB_IFROW java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_IFROW com/sun/jna/platform/win32/IPHlpAPI MIB_IFROW public,static
 inner oshi/jna/Struct$CloseableMibIfRow oshi/jna/Struct CloseableMibIfRow public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableMibIfRow2 52 public,super com/sun/jna/platform/win32/IPHlpAPI$MIB_IF_ROW2 java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_IF_ROW2 com/sun/jna/platform/win32/IPHlpAPI MIB_IF_ROW2 public,static
 inner oshi/jna/Struct$CloseableMibIfRow2 oshi/jna/Struct CloseableMibIfRow2 public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableMibTcpStats 52 public,super com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPSTATS java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_TCPSTATS com/sun/jna/platform/win32/IPHlpAPI MIB_TCPSTATS public,static
 inner oshi/jna/Struct$CloseableMibTcpStats oshi/jna/Struct CloseableMibTcpStats public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableMibUdpStats 52 public,super com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPSTATS java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_UDPSTATS com/sun/jna/platform/win32/IPHlpAPI MIB_UDPSTATS public,static
 inner oshi/jna/Struct$CloseableMibUdpStats oshi/jna/Struct CloseableMibUdpStats public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseablePdhRawCounter 52 public,super com/sun/jna/platform/win32/Pdh$PDH_RAW_COUNTER java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/Pdh$PDH_RAW_COUNTER com/sun/jna/platform/win32/Pdh PDH_RAW_COUNTER public,static
 inner oshi/jna/Struct$CloseablePdhRawCounter oshi/jna/Struct CloseablePdhRawCounter public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseablePerformanceInformation 52 public,super com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner oshi/jna/Struct$CloseablePerformanceInformation oshi/jna/Struct CloseablePerformanceInformation public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableProcTaskAllInfo 52 public,super com/sun/jna/platform/mac/SystemB$ProcTaskAllInfo java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$ProcTaskAllInfo com/sun/jna/platform/mac/SystemB ProcTaskAllInfo public,static
 inner oshi/jna/Struct$CloseableProcTaskAllInfo oshi/jna/Struct CloseableProcTaskAllInfo public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableProcTaskInfo 52 public,super com/sun/jna/platform/mac/SystemB$ProcTaskInfo java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$ProcTaskInfo com/sun/jna/platform/mac/SystemB ProcTaskInfo public,static
 inner oshi/jna/Struct$CloseableProcTaskInfo oshi/jna/Struct CloseableProcTaskInfo public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableRUsageInfoV2 52 public,super com/sun/jna/platform/mac/SystemB$RUsageInfoV2 java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$RUsageInfoV2 com/sun/jna/platform/mac/SystemB RUsageInfoV2 public,static
 inner oshi/jna/Struct$CloseableRUsageInfoV2 oshi/jna/Struct CloseableRUsageInfoV2 public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableSpDeviceInterfaceData 52 public,super com/sun/jna/platform/win32/SetupApi$SP_DEVICE_INTERFACE_DATA java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVICE_INTERFACE_DATA com/sun/jna/platform/win32/SetupApi SP_DEVICE_INTERFACE_DATA public,static
 inner oshi/jna/Struct$CloseableSpDeviceInterfaceData oshi/jna/Struct CloseableSpDeviceInterfaceData public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableSpDevinfoData 52 public,super com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA com/sun/jna/platform/win32/SetupApi SP_DEVINFO_DATA public,static
 inner oshi/jna/Struct$CloseableSpDevinfoData oshi/jna/Struct CloseableSpDevinfoData public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableSysinfo 52 public,super com/sun/jna/platform/linux/LibC$Sysinfo java/lang/AutoCloseable -
 inner com/sun/jna/platform/linux/LibC$Sysinfo com/sun/jna/platform/linux/LibC Sysinfo public,static
 inner oshi/jna/Struct$CloseableSysinfo oshi/jna/Struct CloseableSysinfo public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableSystemInfo 52 public,super com/sun/jna/platform/win32/WinBase$SYSTEM_INFO java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableTimeval 52 public,super com/sun/jna/platform/mac/SystemB$Timeval java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$Timeval com/sun/jna/platform/mac/SystemB Timeval public,static
 inner oshi/jna/Struct$CloseableTimeval oshi/jna/Struct CloseableTimeval public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableVMStatistics 52 public,super com/sun/jna/platform/mac/SystemB$VMStatistics java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$VMStatistics com/sun/jna/platform/mac/SystemB VMStatistics public,static
 inner oshi/jna/Struct$CloseableVMStatistics oshi/jna/Struct CloseableVMStatistics public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableVnodePathInfo 52 public,super com/sun/jna/platform/mac/SystemB$VnodePathInfo java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$VnodePathInfo com/sun/jna/platform/mac/SystemB VnodePathInfo public,static
 inner oshi/jna/Struct$CloseableVnodePathInfo oshi/jna/Struct CloseableVnodePathInfo public,static
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/Struct$CloseableXswUsage 52 public,super com/sun/jna/platform/mac/SystemB$XswUsage java/lang/AutoCloseable -
 inner com/sun/jna/platform/mac/SystemB$XswUsage com/sun/jna/platform/mac/SystemB XswUsage public,static
 inner oshi/jna/Struct$CloseableXswUsage oshi/jna/Struct CloseableXswUsage public,static
 method public <init> ()V - -
 method public close ()V - -
in 371
class oshi/jna/platform/linux/LinuxLibc 52 public,interface,abstract java/lang/Object com/sun/jna/platform/linux/LibC,oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/linux/LinuxLibc$Ut_Tv oshi/jna/platform/linux/LinuxLibc Ut_Tv public,static
 inner oshi/jna/platform/linux/LinuxLibc$Exit_status oshi/jna/platform/linux/LinuxLibc Exit_status public,static
 inner oshi/jna/platform/linux/LinuxLibc$LinuxUtmpx oshi/jna/platform/linux/LinuxLibc LinuxUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/linux/LinuxLibc; -
 method public,abstract getutxent ()Loshi/jna/platform/linux/LinuxLibc$LinuxUtmpx; - -
in 23
class oshi/jna/platform/linux/LinuxLibc 52 public,interface,abstract java/lang/Object com/sun/jna/platform/linux/LibC,oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/linux/LinuxLibc$Ut_Tv oshi/jna/platform/linux/LinuxLibc Ut_Tv public,static
 inner oshi/jna/platform/linux/LinuxLibc$Exit_status oshi/jna/platform/linux/LinuxLibc Exit_status public,static
 inner oshi/jna/platform/linux/LinuxLibc$LinuxUtmpx oshi/jna/platform/linux/LinuxLibc LinuxUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/linux/LinuxLibc; -
 field public,static,final SYS_GETTID Lcom/sun/jna/NativeLong; -
 method public,abstract getutxent ()Loshi/jna/platform/linux/LinuxLibc$LinuxUtmpx; - -
 method public,abstract gettid ()I - -
 method public,varargs,abstract syscall (Lcom/sun/jna/NativeLong;[Ljava/lang/Object;)Lcom/sun/jna/NativeLong; - -
in 290
class oshi/jna/platform/linux/LinuxLibc$Exit_status 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/linux/LinuxLibc$Exit_status oshi/jna/platform/linux/LinuxLibc Exit_status public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public e_termination S -
 field public e_exit S -
 method public <init> ()V - -
in 290
class oshi/jna/platform/linux/LinuxLibc$LinuxUtmpx 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/linux/LinuxLibc$LinuxUtmpx oshi/jna/platform/linux/LinuxLibc LinuxUtmpx public,static
 inner oshi/jna/platform/linux/LinuxLibc$Exit_status oshi/jna/platform/linux/LinuxLibc Exit_status public,static
 inner oshi/jna/platform/linux/LinuxLibc$Ut_Tv oshi/jna/platform/linux/LinuxLibc Ut_Tv public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ut_type S -
 field public ut_pid I -
 field public ut_line [B -
 field public ut_id [B -
 field public ut_user [B -
 field public ut_host [B -
 field public ut_exit Loshi/jna/platform/linux/LinuxLibc$Exit_status; -
 field public ut_session I -
 field public ut_tv Loshi/jna/platform/linux/LinuxLibc$Ut_Tv; -
 field public ut_addr_v6 [I -
 field public reserved [B -
 method public <init> ()V - -
in 290
class oshi/jna/platform/linux/LinuxLibc$Ut_Tv 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/linux/LinuxLibc$Ut_Tv oshi/jna/platform/linux/LinuxLibc Ut_Tv public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tv_sec I -
 field public tv_usec I -
 method public <init> ()V - -
in 2
class oshi/jna/platform/mac/CoreFoundation 52 public,interface,abstract java/lang/Object com/sun/jna/platform/mac/CoreFoundation -
 inner oshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle oshi/jna/platform/mac/CoreFoundation CFDateFormatterStyle public,static,final,enum
 inner oshi/jna/platform/mac/CoreFoundation$CFDateFormatter oshi/jna/platform/mac/CoreFoundation CFDateFormatter public,static
 inner oshi/jna/platform/mac/CoreFoundation$CFLocale oshi/jna/platform/mac/CoreFoundation CFLocale public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef com/sun/jna/platform/mac/CoreFoundation CFAllocatorRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFIndex com/sun/jna/platform/mac/CoreFoundation CFIndex public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 field public,static,final INSTANCE Loshi/jna/platform/mac/CoreFoundation; -
 method public,abstract CFLocaleCopyCurrent ()Loshi/jna/platform/mac/CoreFoundation$CFLocale; - -
 method public,abstract CFDateFormatterCreate (Lcom/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef;Loshi/jna/platform/mac/CoreFoundation$CFLocale;Lcom/sun/jna/platform/mac/CoreFoundation$CFIndex;Lcom/sun/jna/platform/mac/CoreFoundation$CFIndex;)Loshi/jna/platform/mac/CoreFoundation$CFDateFormatter; - -
 method public,abstract CFDateFormatterGetFormat (Loshi/jna/platform/mac/CoreFoundation$CFDateFormatter;)Lcom/sun/jna/platform/mac/CoreFoundation$CFStringRef; - -
in 2
class oshi/jna/platform/mac/CoreFoundation$CFDateFormatter 52 public,super com/sun/jna/platform/mac/CoreFoundation$CFTypeRef - -
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner oshi/jna/platform/mac/CoreFoundation$CFDateFormatter oshi/jna/platform/mac/CoreFoundation CFDateFormatter public,static
 method public <init> ()V - -
in 2
class oshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle;>;
 inner oshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle oshi/jna/platform/mac/CoreFoundation CFDateFormatterStyle public,static,final,enum
 inner com/sun/jna/platform/mac/CoreFoundation$CFIndex com/sun/jna/platform/mac/CoreFoundation CFIndex public,static
 field public,static,final,enum kCFDateFormatterNoStyle Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle; -
 field public,static,final,enum kCFDateFormatterShortStyle Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle; -
 field public,static,final,enum kCFDateFormatterMediumStyle Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle; -
 field public,static,final,enum kCFDateFormatterLongStyle Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle; -
 field public,static,final,enum kCFDateFormatterFullStyle Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle; -
 method public,static values ()[Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/jna/platform/mac/CoreFoundation$CFDateFormatterStyle; - -
 method public index ()Lcom/sun/jna/platform/mac/CoreFoundation$CFIndex; - -
in 2
class oshi/jna/platform/mac/CoreFoundation$CFLocale 52 public,super com/sun/jna/platform/mac/CoreFoundation$CFTypeRef - -
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner oshi/jna/platform/mac/CoreFoundation$CFLocale oshi/jna/platform/mac/CoreFoundation CFLocale public,static
 method public <init> ()V - -
in 290
class oshi/jna/platform/mac/CoreGraphics 52 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner oshi/jna/platform/mac/CoreGraphics$CGRect oshi/jna/platform/mac/CoreGraphics CGRect public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGSize oshi/jna/platform/mac/CoreGraphics CGSize public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGPoint oshi/jna/platform/mac/CoreGraphics CGPoint public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFArrayRef com/sun/jna/platform/mac/CoreFoundation CFArrayRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 field public,static,final INSTANCE Loshi/jna/platform/mac/CoreGraphics; -
 field public,static,final kCGNullWindowID I - I0
 field public,static,final kCGWindowListOptionAll I - I0
 field public,static,final kCGWindowListOptionOnScreenOnly I - I1
 field public,static,final kCGWindowListOptionOnScreenAboveWindow I - I2
 field public,static,final kCGWindowListOptionOnScreenBelowWindow I - I4
 field public,static,final kCGWindowListOptionIncludingWindow I - I8
 field public,static,final kCGWindowListExcludeDesktopElements I - I16
 method public,abstract CGWindowListCopyWindowInfo (II)Lcom/sun/jna/platform/mac/CoreFoundation$CFArrayRef; - -
 method public,abstract CGRectMakeWithDictionaryRepresentation (Lcom/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef;Loshi/jna/platform/mac/CoreGraphics$CGRect;)Z - -
in 290
class oshi/jna/platform/mac/CoreGraphics$CGPoint 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/CoreGraphics$CGPoint oshi/jna/platform/mac/CoreGraphics CGPoint public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public x D -
 field public y D -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/mac/CoreGraphics$CGRect 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/CoreGraphics$CGRect oshi/jna/platform/mac/CoreGraphics CGRect public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGPoint oshi/jna/platform/mac/CoreGraphics CGPoint public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGSize oshi/jna/platform/mac/CoreGraphics CGSize public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public origin Loshi/jna/platform/mac/CoreGraphics$CGPoint; -
 field public size Loshi/jna/platform/mac/CoreGraphics$CGSize; -
 method public <init> ()V - -
in 39
class oshi/jna/platform/mac/CoreGraphics$CGRect 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/mac/CoreGraphics$CGRect oshi/jna/platform/mac/CoreGraphics CGRect public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGPoint oshi/jna/platform/mac/CoreGraphics CGPoint public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGSize oshi/jna/platform/mac/CoreGraphics CGSize public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public origin Loshi/jna/platform/mac/CoreGraphics$CGPoint; -
 field public size Loshi/jna/platform/mac/CoreGraphics$CGSize; -
 method public <init> ()V - -
 method public close ()V - -
in 290
class oshi/jna/platform/mac/CoreGraphics$CGSize 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/CoreGraphics$CGSize oshi/jna/platform/mac/CoreGraphics CGSize public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public width D -
 field public height D -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/mac/IOKit 52 public,interface,abstract java/lang/Object com/sun/jna/platform/mac/IOKit -
 inner com/sun/jna/platform/mac/IOKit$IOConnect com/sun/jna/platform/mac/IOKit IOConnect public,static
 field public,static,final INSTANCE Loshi/jna/platform/mac/IOKit; -
 method public,abstract IOConnectCallStructMethod (Lcom/sun/jna/platform/mac/IOKit$IOConnect;ILcom/sun/jna/Structure;Lcom/sun/jna/NativeLong;Lcom/sun/jna/Structure;Lcom/sun/jna/ptr/NativeLongByReference;)I - -
in 39
class oshi/jna/platform/mac/IOKit 52 public,interface,abstract java/lang/Object com/sun/jna/platform/mac/IOKit -
 inner oshi/jna/platform/mac/IOKit$SMCVal oshi/jna/platform/mac/IOKit SMCVal public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyData oshi/jna/platform/mac/IOKit SMCKeyData public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataKeyInfo oshi/jna/platform/mac/IOKit SMCKeyDataKeyInfo public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataPLimitData oshi/jna/platform/mac/IOKit SMCKeyDataPLimitData public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataVers oshi/jna/platform/mac/IOKit SMCKeyDataVers public,static
 inner com/sun/jna/platform/mac/IOKit$IOConnect com/sun/jna/platform/mac/IOKit IOConnect public,static
 field public,static,final INSTANCE Loshi/jna/platform/mac/IOKit; -
 method public,abstract IOConnectCallStructMethod (Lcom/sun/jna/platform/mac/IOKit$IOConnect;ILcom/sun/jna/Structure;Lcom/sun/jna/NativeLong;Lcom/sun/jna/Structure;Lcom/sun/jna/ptr/NativeLongByReference;)I - -
in 39
class oshi/jna/platform/mac/IOKit$SMCKeyData 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/mac/IOKit$SMCKeyData oshi/jna/platform/mac/IOKit SMCKeyData public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataVers oshi/jna/platform/mac/IOKit SMCKeyDataVers public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataPLimitData oshi/jna/platform/mac/IOKit SMCKeyDataPLimitData public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataKeyInfo oshi/jna/platform/mac/IOKit SMCKeyDataKeyInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public key I -
 field public vers Loshi/jna/platform/mac/IOKit$SMCKeyDataVers; -
 field public pLimitData Loshi/jna/platform/mac/IOKit$SMCKeyDataPLimitData; -
 field public keyInfo Loshi/jna/platform/mac/IOKit$SMCKeyDataKeyInfo; -
 field public result B -
 field public status B -
 field public data8 B -
 field public data32 I -
 field public bytes [B -
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/platform/mac/IOKit$SMCKeyDataKeyInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataKeyInfo oshi/jna/platform/mac/IOKit SMCKeyDataKeyInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public dataSize I -
 field public dataType I -
 field public dataAttributes B -
 method public <init> ()V - -
in 39
class oshi/jna/platform/mac/IOKit$SMCKeyDataPLimitData 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataPLimitData oshi/jna/platform/mac/IOKit SMCKeyDataPLimitData public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public version S -
 field public length S -
 field public cpuPLimit I -
 field public gpuPLimit I -
 field public memPLimit I -
 method public <init> ()V - -
in 39
class oshi/jna/platform/mac/IOKit$SMCKeyDataVers 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataVers oshi/jna/platform/mac/IOKit SMCKeyDataVers public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public major B -
 field public minor B -
 field public build B -
 field public reserved B -
 field public release S -
 method public <init> ()V - -
in 39
class oshi/jna/platform/mac/IOKit$SMCVal 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/mac/IOKit$SMCVal oshi/jna/platform/mac/IOKit SMCVal public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public key [B -
 field public dataSize I -
 field public dataType [B -
 field public bytes [B -
 method public <init> ()V - -
 method public close ()V - -
in 82
class oshi/jna/platform/mac/SystemB 52 public,interface,abstract java/lang/Object com/sun/jna/platform/mac/SystemB,oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/mac/SystemB$Pri oshi/jna/platform/mac/SystemB Pri public,static
 inner oshi/jna/platform/mac/SystemB$SocketFdInfo oshi/jna/platform/mac/SystemB SocketFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$ProcFileInfo oshi/jna/platform/mac/SystemB ProcFileInfo public,static
 inner oshi/jna/platform/mac/SystemB$SocketInfo oshi/jna/platform/mac/SystemB SocketInfo public,static
 inner oshi/jna/platform/mac/SystemB$TcpSockInfo oshi/jna/platform/mac/SystemB TcpSockInfo public,static
 inner oshi/jna/platform/mac/SystemB$InSockInfo oshi/jna/platform/mac/SystemB InSockInfo public,static
 inner oshi/jna/platform/mac/SystemB$ProcFdInfo oshi/jna/platform/mac/SystemB ProcFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$MacUtmpx oshi/jna/platform/mac/SystemB MacUtmpx public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 field public,static,final INSTANCE Loshi/jna/platform/mac/SystemB; -
 field public,static,final PROC_PIDLISTFDS I - I1
 field public,static,final PROX_FDTYPE_SOCKET I - I2
 field public,static,final PROC_PIDFDSOCKETINFO I - I3
 field public,static,final TSI_T_NTIMERS I - I4
 field public,static,final SOCKINFO_IN I - I1
 field public,static,final SOCKINFO_TCP I - I2
 field public,static,final UTX_USERSIZE I - I256
 field public,static,final UTX_LINESIZE I - I32
 field public,static,final UTX_IDSIZE I - I4
 field public,static,final UTX_HOSTSIZE I - I256
 field public,static,final AF_INET I - I2
 field public,static,final AF_INET6 I - I30
 method public,abstract getutxent ()Loshi/jna/platform/mac/SystemB$MacUtmpx; - -
 method public,abstract proc_pidfdinfo (IIILcom/sun/jna/Structure;I)I - -
 method public,abstract sysctl ([IILcom/sun/jna/Pointer;Loshi/jna/platform/unix/NativeSizeTByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;)I - -
 method public,abstract sysctlbyname (Ljava/lang/String;Lcom/sun/jna/Pointer;Loshi/jna/platform/unix/NativeSizeTByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;)I - -
 method public,abstract sysctlnametomib (Ljava/lang/String;Lcom/sun/jna/Pointer;Loshi/jna/platform/unix/NativeSizeTByReference;)I - -
in 30
class oshi/jna/platform/mac/SystemB 52 public,interface,abstract java/lang/Object com/sun/jna/platform/mac/SystemB,oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/mac/SystemB$Pri oshi/jna/platform/mac/SystemB Pri public,static
 inner oshi/jna/platform/mac/SystemB$SocketFdInfo oshi/jna/platform/mac/SystemB SocketFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$ProcFileInfo oshi/jna/platform/mac/SystemB ProcFileInfo public,static
 inner oshi/jna/platform/mac/SystemB$SocketInfo oshi/jna/platform/mac/SystemB SocketInfo public,static
 inner oshi/jna/platform/mac/SystemB$TcpSockInfo oshi/jna/platform/mac/SystemB TcpSockInfo public,static
 inner oshi/jna/platform/mac/SystemB$InSockInfo oshi/jna/platform/mac/SystemB InSockInfo public,static
 inner oshi/jna/platform/mac/SystemB$ProcFdInfo oshi/jna/platform/mac/SystemB ProcFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$MacUtmpx oshi/jna/platform/mac/SystemB MacUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/mac/SystemB; -
 field public,static,final PROC_PIDLISTFDS I - I1
 field public,static,final PROX_FDTYPE_SOCKET I - I2
 field public,static,final PROC_PIDFDSOCKETINFO I - I3
 field public,static,final TSI_T_NTIMERS I - I4
 field public,static,final SOCKINFO_IN I - I1
 field public,static,final SOCKINFO_TCP I - I2
 field public,static,final UTX_USERSIZE I - I256
 field public,static,final UTX_LINESIZE I - I32
 field public,static,final UTX_IDSIZE I - I4
 field public,static,final UTX_HOSTSIZE I - I256
 field public,static,final AF_INET I - I2
 field public,static,final AF_INET6 I - I30
 method public,abstract getutxent ()Loshi/jna/platform/mac/SystemB$MacUtmpx; - -
 method public,abstract proc_pidfdinfo (IIILcom/sun/jna/Structure;I)I - -
in 290
class oshi/jna/platform/mac/SystemB$InSockInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/SystemB$InSockInfo oshi/jna/platform/mac/SystemB InSockInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public insi_fport I -
 field public insi_lport I -
 field public insi_gencnt J -
 field public insi_flags I -
 field public insi_flow I -
 field public insi_vflag B -
 field public insi_ip_ttl B -
 field public rfu_1 I -
 field public insi_faddr [I -
 field public insi_laddr [I -
 field public insi_v4 B -
 field public insi_v6 [B -
 method public <init> ()V - -
in 290
class oshi/jna/platform/mac/SystemB$MacUtmpx 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/SystemB$MacUtmpx oshi/jna/platform/mac/SystemB MacUtmpx public,static
 inner com/sun/jna/platform/mac/SystemB$Timeval com/sun/jna/platform/mac/SystemB Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ut_user [B -
 field public ut_id [B -
 field public ut_line [B -
 field public ut_pid I -
 field public ut_type S -
 field public ut_tv Lcom/sun/jna/platform/mac/SystemB$Timeval; -
 field public ut_host [B -
 field public ut_pad [B -
 method public <init> ()V - -
in 290
class oshi/jna/platform/mac/SystemB$Pri 52 public,super com/sun/jna/Union - -
 inner oshi/jna/platform/mac/SystemB$Pri oshi/jna/platform/mac/SystemB Pri public,static
 inner oshi/jna/platform/mac/SystemB$InSockInfo oshi/jna/platform/mac/SystemB InSockInfo public,static
 inner oshi/jna/platform/mac/SystemB$TcpSockInfo oshi/jna/platform/mac/SystemB TcpSockInfo public,static
 field public pri_in Loshi/jna/platform/mac/SystemB$InSockInfo; -
 field public pri_tcp Loshi/jna/platform/mac/SystemB$TcpSockInfo; -
 field public max_size [B -
 method public <init> ()V - -
in 290
class oshi/jna/platform/mac/SystemB$ProcFdInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/SystemB$ProcFdInfo oshi/jna/platform/mac/SystemB ProcFdInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public proc_fd I -
 field public proc_fdtype I -
 method public <init> ()V - -
in 290
class oshi/jna/platform/mac/SystemB$ProcFileInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/SystemB$ProcFileInfo oshi/jna/platform/mac/SystemB ProcFileInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public fi_openflags I -
 field public fi_status I -
 field public fi_offset J -
 field public fi_type I -
 field public fi_guardflags I -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/mac/SystemB$SocketFdInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/SystemB$SocketFdInfo oshi/jna/platform/mac/SystemB SocketFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$ProcFileInfo oshi/jna/platform/mac/SystemB ProcFileInfo public,static
 inner oshi/jna/platform/mac/SystemB$SocketInfo oshi/jna/platform/mac/SystemB SocketInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public pfi Loshi/jna/platform/mac/SystemB$ProcFileInfo; -
 field public psi Loshi/jna/platform/mac/SystemB$SocketInfo; -
 method public <init> ()V - -
in 39
class oshi/jna/platform/mac/SystemB$SocketFdInfo 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/mac/SystemB$SocketFdInfo oshi/jna/platform/mac/SystemB SocketFdInfo public,static
 inner oshi/jna/platform/mac/SystemB$ProcFileInfo oshi/jna/platform/mac/SystemB ProcFileInfo public,static
 inner oshi/jna/platform/mac/SystemB$SocketInfo oshi/jna/platform/mac/SystemB SocketInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public pfi Loshi/jna/platform/mac/SystemB$ProcFileInfo; -
 field public psi Loshi/jna/platform/mac/SystemB$SocketInfo; -
 method public <init> ()V - -
 method public close ()V - -
in 290
class oshi/jna/platform/mac/SystemB$SocketInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/SystemB$SocketInfo oshi/jna/platform/mac/SystemB SocketInfo public,static
 inner oshi/jna/platform/mac/SystemB$Pri oshi/jna/platform/mac/SystemB Pri public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public soi_stat [J -
 field public soi_so J -
 field public soi_pcb J -
 field public soi_type I -
 field public soi_protocol I -
 field public soi_family I -
 field public soi_options S -
 field public soi_linger S -
 field public soi_state S -
 field public soi_qlen S -
 field public soi_incqlen S -
 field public soi_qlimit S -
 field public soi_timeo S -
 field public soi_error S -
 field public soi_oobmark I -
 field public soi_rcv [I -
 field public soi_snd [I -
 field public soi_kind I -
 field public rfu_1 I -
 field public soi_proto Loshi/jna/platform/mac/SystemB$Pri; -
 method public <init> ()V - -
in 290
class oshi/jna/platform/mac/SystemB$TcpSockInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/mac/SystemB$TcpSockInfo oshi/jna/platform/mac/SystemB TcpSockInfo public,static
 inner oshi/jna/platform/mac/SystemB$InSockInfo oshi/jna/platform/mac/SystemB InSockInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tcpsi_ini Loshi/jna/platform/mac/SystemB$InSockInfo; -
 field public tcpsi_state I -
 field public tcpsi_timer [I -
 field public tcpsi_mss I -
 field public tcpsi_flags I -
 field public rfu_1 I -
 field public tcpsi_tp J -
 method public <init> ()V - -
in 290
class oshi/jna/platform/mac/SystemConfiguration 52 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner oshi/jna/platform/mac/SystemConfiguration$SCNetworkInterfaceRef oshi/jna/platform/mac/SystemConfiguration SCNetworkInterfaceRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFArrayRef com/sun/jna/platform/mac/CoreFoundation CFArrayRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 field public,static,final INSTANCE Loshi/jna/platform/mac/SystemConfiguration; -
 method public,abstract SCNetworkInterfaceCopyAll ()Lcom/sun/jna/platform/mac/CoreFoundation$CFArrayRef; - -
 method public,abstract SCNetworkInterfaceGetBSDName (Loshi/jna/platform/mac/SystemConfiguration$SCNetworkInterfaceRef;)Lcom/sun/jna/platform/mac/CoreFoundation$CFStringRef; - -
 method public,abstract SCNetworkInterfaceGetLocalizedDisplayName (Loshi/jna/platform/mac/SystemConfiguration$SCNetworkInterfaceRef;)Lcom/sun/jna/platform/mac/CoreFoundation$CFStringRef; - -
in 290
class oshi/jna/platform/mac/SystemConfiguration$SCNetworkInterfaceRef 52 public,super com/sun/jna/platform/mac/CoreFoundation$CFTypeRef - -
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner oshi/jna/platform/mac/SystemConfiguration$SCNetworkInterfaceRef oshi/jna/platform/mac/SystemConfiguration SCNetworkInterfaceRef public,static
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
in 42
class oshi/jna/platform/unix/AixLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/AixLibc$Timestruc oshi/jna/platform/unix/AixLibc Timestruc public,static
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 inner oshi/jna/platform/unix/AixLibc$AixPsInfo oshi/jna/platform/unix/AixLibc AixPsInfo public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/AixLibc; -
 field public,static,final PRCLSZ I - I8
 field public,static,final PRFNSZ I - I16
 field public,static,final PRARGSZ I - I80
in 23
class oshi/jna/platform/unix/AixLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/AixLibc$Timestruc oshi/jna/platform/unix/AixLibc Timestruc public,static
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 inner oshi/jna/platform/unix/AixLibc$AixPsInfo oshi/jna/platform/unix/AixLibc AixPsInfo public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/AixLibc; -
 field public,static,final PRCLSZ I - I8
 field public,static,final PRFNSZ I - I16
 field public,static,final PRARGSZ I - I80
 method public,abstract thread_self ()I - -
in 39
class oshi/jna/platform/unix/AixLibc$AixLwpsInfo 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 field public pr_lwpid J -
 field public pr_addr J -
 field public pr_wchan J -
 field public pr_flag I -
 field public pr_wtype B -
 field public pr_state B -
 field public pr_sname B -
 field public pr_nice B -
 field public pr_pri I -
 field public pr_policy I -
 field public pr_clname [B -
 field public pr_onpro I -
 field public pr_bindpro I -
 method public <init> (Ljava/nio/ByteBuffer;)V - -
in 39
class oshi/jna/platform/unix/AixLibc$AixPsInfo 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/AixLibc$AixPsInfo oshi/jna/platform/unix/AixLibc AixPsInfo public,static
 inner oshi/jna/platform/unix/AixLibc$Timestruc oshi/jna/platform/unix/AixLibc Timestruc public,static
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 field public pr_flag I -
 field public pr_flag2 I -
 field public pr_nlwp I -
 field public pr__pad1 I -
 field public pr_uid J -
 field public pr_euid J -
 field public pr_gid J -
 field public pr_egid J -
 field public pr_pid J -
 field public pr_ppid J -
 field public pr_pgid J -
 field public pr_sid J -
 field public pr_ttydev J -
 field public pr_addr J -
 field public pr_size J -
 field public pr_rssize J -
 field public pr_start Loshi/jna/platform/unix/AixLibc$Timestruc; -
 field public pr_time Loshi/jna/platform/unix/AixLibc$Timestruc; -
 field public pr_cid S -
 field public pr__pad2 S -
 field public pr_argc I -
 field public pr_argv J -
 field public pr_envp J -
 field public pr_fname [B -
 field public pr_psargs [B -
 field public pr__pad [J -
 field public pr_lwp Loshi/jna/platform/unix/AixLibc$AixLwpsInfo; -
 method public <init> (Ljava/nio/ByteBuffer;)V - -
in 39
class oshi/jna/platform/unix/AixLibc$Timestruc 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/AixLibc$Timestruc oshi/jna/platform/unix/AixLibc Timestruc public,static
 field public tv_sec J -
 field public tv_nsec I -
 field public pad I -
 method public <init> (Ljava/nio/ByteBuffer;)V - -
in 82
class oshi/jna/platform/unix/CLibrary 52 public,interface,abstract java/lang/Object com/sun/jna/platform/unix/LibCAPI,com/sun/jna/Library -
 inner oshi/jna/platform/unix/CLibrary$BsdIp6stat oshi/jna/platform/unix/CLibrary BsdIp6stat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdIpstat oshi/jna/platform/unix/CLibrary BsdIpstat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdUdpstat oshi/jna/platform/unix/CLibrary BsdUdpstat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdTcpstat oshi/jna/platform/unix/CLibrary BsdTcpstat public,static
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr oshi/jna/platform/unix/CLibrary Sockaddr public,static
 field public,static,final AI_CANONNAME I - I2
 field public,static,final UT_LINESIZE I - I32
 field public,static,final UT_NAMESIZE I - I32
 field public,static,final UT_HOSTSIZE I - I256
 field public,static,final LOGIN_PROCESS I - I6
 field public,static,final USER_PROCESS I - I7
 method public,abstract getpid ()I - -
 method public,abstract getaddrinfo (Ljava/lang/String;Ljava/lang/String;Loshi/jna/platform/unix/CLibrary$Addrinfo;Lcom/sun/jna/ptr/PointerByReference;)I - -
 method public,abstract freeaddrinfo (Lcom/sun/jna/Pointer;)V - -
 method public,abstract gai_strerror (I)Ljava/lang/String; - -
 method public,abstract setutxent ()V - -
 method public,abstract endutxent ()V - -
in 30
class oshi/jna/platform/unix/CLibrary 52 public,interface,abstract java/lang/Object com/sun/jna/platform/unix/LibCAPI,com/sun/jna/Library -
 inner oshi/jna/platform/unix/CLibrary$BsdIp6stat oshi/jna/platform/unix/CLibrary BsdIp6stat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdIpstat oshi/jna/platform/unix/CLibrary BsdIpstat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdUdpstat oshi/jna/platform/unix/CLibrary BsdUdpstat public,static
 inner oshi/jna/platform/unix/CLibrary$BsdTcpstat oshi/jna/platform/unix/CLibrary BsdTcpstat public,static
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr oshi/jna/platform/unix/CLibrary Sockaddr public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$ssize_t com/sun/jna/platform/unix/LibCAPI ssize_t public,static
 field public,static,final AI_CANONNAME I - I2
 field public,static,final UT_LINESIZE I - I32
 field public,static,final UT_NAMESIZE I - I32
 field public,static,final UT_HOSTSIZE I - I256
 field public,static,final LOGIN_PROCESS I - I6
 field public,static,final USER_PROCESS I - I7
 method public,abstract getpid ()I - -
 method public,abstract getaddrinfo (Ljava/lang/String;Ljava/lang/String;Loshi/jna/platform/unix/CLibrary$Addrinfo;Lcom/sun/jna/ptr/PointerByReference;)I - -
 method public,abstract freeaddrinfo (Lcom/sun/jna/Pointer;)V - -
 method public,abstract gai_strerror (I)Ljava/lang/String; - -
 method public,abstract setutxent ()V - -
 method public,abstract endutxent ()V - -
 method public,abstract sysctl ([IILcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t$ByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;)I - -
 method public,abstract sysctlbyname (Ljava/lang/String;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t$ByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;)I - -
 method public,abstract sysctlnametomib (Ljava/lang/String;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t$ByReference;)I - -
 method public,abstract open (Ljava/lang/String;I)I - -
 method public,abstract pread (ILcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;Lcom/sun/jna/NativeLong;)Lcom/sun/jna/platform/unix/LibCAPI$ssize_t; - -
in 1183
class oshi/jna/platform/unix/CLibrary$Addrinfo 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/platform/unix/CLibrary$Addrinfo$ByReference oshi/jna/platform/unix/CLibrary$Addrinfo ByReference public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr oshi/jna/platform/unix/CLibrary Sockaddr public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr$ByReference oshi/jna/platform/unix/CLibrary$Sockaddr ByReference public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ai_flags I -
 field public ai_family I -
 field public ai_socktype I -
 field public ai_protocol I -
 field public ai_addrlen I -
 field public ai_addr Loshi/jna/platform/unix/CLibrary$Sockaddr$ByReference; -
 field public ai_canonname Ljava/lang/String; -
 field public ai_next Loshi/jna/platform/unix/CLibrary$Addrinfo$ByReference; -
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
in 39
class oshi/jna/platform/unix/CLibrary$Addrinfo 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/platform/unix/CLibrary$Addrinfo$ByReference oshi/jna/platform/unix/CLibrary$Addrinfo ByReference public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr oshi/jna/platform/unix/CLibrary Sockaddr public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr$ByReference oshi/jna/platform/unix/CLibrary$Sockaddr ByReference public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ai_flags I -
 field public ai_family I -
 field public ai_socktype I -
 field public ai_protocol I -
 field public ai_addrlen I -
 field public ai_addr Loshi/jna/platform/unix/CLibrary$Sockaddr$ByReference; -
 field public ai_canonname Ljava/lang/String; -
 field public ai_next Loshi/jna/platform/unix/CLibrary$Addrinfo$ByReference; -
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public close ()V - -
in 290
class oshi/jna/platform/unix/CLibrary$Addrinfo$ByReference 52 public,super oshi/jna/platform/unix/CLibrary$Addrinfo com/sun/jna/Structure$ByReference -
 inner oshi/jna/platform/unix/CLibrary$Addrinfo oshi/jna/platform/unix/CLibrary Addrinfo public,static
 inner oshi/jna/platform/unix/CLibrary$Addrinfo$ByReference oshi/jna/platform/unix/CLibrary$Addrinfo ByReference public,static
 inner com/sun/jna/Structure$ByReference com/sun/jna/Structure ByReference public,static,interface,abstract
 method public <init> ()V - -
in 290
class oshi/jna/platform/unix/CLibrary$BsdIp6stat 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/CLibrary$BsdIp6stat oshi/jna/platform/unix/CLibrary BsdIp6stat public,static
 field public ip6s_total J -
 field public ip6s_localout J -
 method public <init> ()V - -
in 290
class oshi/jna/platform/unix/CLibrary$BsdIpstat 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/CLibrary$BsdIpstat oshi/jna/platform/unix/CLibrary BsdIpstat public,static
 field public ips_total I -
 field public ips_badsum I -
 field public ips_tooshort I -
 field public ips_toosmall I -
 field public ips_badhlen I -
 field public ips_badlen I -
 field public ips_delivered I -
 method public <init> ()V - -
in 290
class oshi/jna/platform/unix/CLibrary$BsdTcpstat 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/CLibrary$BsdTcpstat oshi/jna/platform/unix/CLibrary BsdTcpstat public,static
 field public tcps_connattempt I -
 field public tcps_accepts I -
 field public tcps_drops I -
 field public tcps_conndrops I -
 field public tcps_sndpack I -
 field public tcps_sndrexmitpack I -
 field public tcps_rcvpack I -
 field public tcps_rcvbadsum I -
 field public tcps_rcvbadoff I -
 field public tcps_rcvmemdrop I -
 field public tcps_rcvshort I -
 method public <init> ()V - -
in 290
class oshi/jna/platform/unix/CLibrary$BsdUdpstat 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/CLibrary$BsdUdpstat oshi/jna/platform/unix/CLibrary BsdUdpstat public,static
 field public udps_ipackets I -
 field public udps_hdrops I -
 field public udps_badsum I -
 field public udps_badlen I -
 field public udps_opackets I -
 field public udps_noportmcast I -
 field public udps_rcv6_swcsum I -
 field public udps_snd6_swcsum I -
 method public <init> ()V - -
in 290
class oshi/jna/platform/unix/CLibrary$Sockaddr 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/CLibrary$Sockaddr oshi/jna/platform/unix/CLibrary Sockaddr public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr$ByReference oshi/jna/platform/unix/CLibrary$Sockaddr ByReference public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public sa_family S -
 field public sa_data [B -
 method public <init> ()V - -
in 290
class oshi/jna/platform/unix/CLibrary$Sockaddr$ByReference 52 public,super oshi/jna/platform/unix/CLibrary$Sockaddr com/sun/jna/Structure$ByReference -
 inner oshi/jna/platform/unix/CLibrary$Sockaddr oshi/jna/platform/unix/CLibrary Sockaddr public,static
 inner oshi/jna/platform/unix/CLibrary$Sockaddr$ByReference oshi/jna/platform/unix/CLibrary$Sockaddr ByReference public,static
 inner com/sun/jna/Structure$ByReference com/sun/jna/Structure ByReference public,static,interface,abstract
 method public <init> ()V - -
in 42
class oshi/jna/platform/unix/FreeBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/FreeBsdLibc$CpTime oshi/jna/platform/unix/FreeBsdLibc CpTime public,static
 inner oshi/jna/platform/unix/FreeBsdLibc$Timeval oshi/jna/platform/unix/FreeBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/FreeBsdLibc FreeBsdUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/FreeBsdLibc; -
 field public,static,final UTX_USERSIZE I - I32
 field public,static,final UTX_LINESIZE I - I16
 field public,static,final UTX_IDSIZE I - I8
 field public,static,final UTX_HOSTSIZE I - I128
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 method public,abstract getutxent ()Loshi/jna/platform/unix/FreeBsdLibc$FreeBsdUtmpx; - -
in 23
class oshi/jna/platform/unix/FreeBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/FreeBsdLibc$CpTime oshi/jna/platform/unix/FreeBsdLibc CpTime public,static
 inner oshi/jna/platform/unix/FreeBsdLibc$Timeval oshi/jna/platform/unix/FreeBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/FreeBsdLibc FreeBsdUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/FreeBsdLibc; -
 field public,static,final UTX_USERSIZE I - I32
 field public,static,final UTX_LINESIZE I - I16
 field public,static,final UTX_IDSIZE I - I8
 field public,static,final UTX_HOSTSIZE I - I128
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 method public,abstract getutxent ()Loshi/jna/platform/unix/FreeBsdLibc$FreeBsdUtmpx; - -
 method public,abstract thr_self (Lcom/sun/jna/ptr/NativeLongByReference;)I - -
in 39
class oshi/jna/platform/unix/FreeBsdLibc$CpTime 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/unix/FreeBsdLibc$CpTime oshi/jna/platform/unix/FreeBsdLibc CpTime public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public cpu_ticks [J -
 method public <init> ()V - -
 method public close ()V - -
in 39
class oshi/jna/platform/unix/FreeBsdLibc$FreeBsdUtmpx 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/FreeBsdLibc FreeBsdUtmpx public,static
 inner oshi/jna/platform/unix/FreeBsdLibc$Timeval oshi/jna/platform/unix/FreeBsdLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ut_type S -
 field public ut_tv Loshi/jna/platform/unix/FreeBsdLibc$Timeval; -
 field public ut_id [B -
 field public ut_pid I -
 field public ut_user [B -
 field public ut_line [B -
 field public ut_host [B -
 field public ut_spare [B -
 method public <init> ()V - -
in 39
class oshi/jna/platform/unix/FreeBsdLibc$Timeval 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/FreeBsdLibc$Timeval oshi/jna/platform/unix/FreeBsdLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tv_sec J -
 field public tv_usec J -
 method public <init> ()V - -
in 82
class oshi/jna/platform/unix/NativeSizeTByReference 52 public,super com/sun/jna/ptr/ByReference - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/platform/unix/LibCAPI$size_t;)V - -
 method public setValue (Lcom/sun/jna/platform/unix/LibCAPI$size_t;)V - -
 method public getValue ()Lcom/sun/jna/platform/unix/LibCAPI$size_t; - -
 method public toString ()Ljava/lang/String; - -
in 42
class oshi/jna/platform/unix/OpenBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/OpenBsdLibc$Timeval oshi/jna/platform/unix/OpenBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/OpenBsdLibc Bcachestats public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/OpenBsdLibc; -
 field public,static,final CTL_KERN I - I1
 field public,static,final CTL_VM I - I1
 field public,static,final CTL_HW I - I6
 field public,static,final CTL_MACHDEP I - I7
 field public,static,final CTL_VFS I - I10
 field public,static,final KERN_OSTYPE I - I1
 field public,static,final KERN_OSRELEASE I - I2
 field public,static,final KERN_OSREV I - I3
 field public,static,final KERN_VERSION I - I4
 field public,static,final KERN_MAXVNODES I - I5
 field public,static,final KERN_MAXPROC I - I6
 field public,static,final KERN_ARGMAX I - I8
 field public,static,final KERN_CPTIME I - I40
 field public,static,final KERN_CPTIME2 I - I71
 field public,static,final VM_UVMEXP I - I4
 field public,static,final HW_MACHINE I - I1
 field public,static,final HW_MODEL I - I2
 field public,static,final HW_PAGESIZE I - I7
 field public,static,final HW_CPUSPEED I - I12
 field public,static,final HW_NCPUFOUND I - I21
 field public,static,final HW_SMT I - I24
 field public,static,final HW_NCPUONLINE I - I25
 field public,static,final VFS_GENERIC I - I0
 field public,static,final VFS_BCACHESTAT I - I3
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
in 23
class oshi/jna/platform/unix/OpenBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/OpenBsdLibc$Timeval oshi/jna/platform/unix/OpenBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/OpenBsdLibc Bcachestats public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/OpenBsdLibc; -
 field public,static,final CTL_KERN I - I1
 field public,static,final CTL_VM I - I1
 field public,static,final CTL_HW I - I6
 field public,static,final CTL_MACHDEP I - I7
 field public,static,final CTL_VFS I - I10
 field public,static,final KERN_OSTYPE I - I1
 field public,static,final KERN_OSRELEASE I - I2
 field public,static,final KERN_OSREV I - I3
 field public,static,final KERN_VERSION I - I4
 field public,static,final KERN_MAXVNODES I - I5
 field public,static,final KERN_MAXPROC I - I6
 field public,static,final KERN_ARGMAX I - I8
 field public,static,final KERN_CPTIME I - I40
 field public,static,final KERN_CPTIME2 I - I71
 field public,static,final VM_UVMEXP I - I4
 field public,static,final HW_MACHINE I - I1
 field public,static,final HW_MODEL I - I2
 field public,static,final HW_PAGESIZE I - I7
 field public,static,final HW_CPUSPEED I - I12
 field public,static,final HW_NCPUFOUND I - I21
 field public,static,final HW_SMT I - I24
 field public,static,final HW_NCPUONLINE I - I25
 field public,static,final VFS_GENERIC I - I0
 field public,static,final VFS_BCACHESTAT I - I3
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
 method public,abstract getthrid ()I - -
in 39
class oshi/jna/platform/unix/OpenBsdLibc$Bcachestats 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/OpenBsdLibc Bcachestats public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public numbufs J -
 field public numbufpages J -
 field public numdirtypages J -
 field public numcleanpages J -
 field public pendingwrites J -
 field public pendingreads J -
 field public numwrites J -
 field public numreads J -
 field public cachehits J -
 field public busymapped J -
 field public dmapages J -
 field public highpages J -
 field public delwribufs J -
 field public kvaslots J -
 field public kvaslots_avail J -
 field public highflips J -
 field public highflops J -
 field public dmaflips J -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
in 39
class oshi/jna/platform/unix/OpenBsdLibc$Timeval 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/OpenBsdLibc$Timeval oshi/jna/platform/unix/OpenBsdLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tv_sec J -
 field public tv_usec J -
 method public <init> ()V - -
in 42
class oshi/jna/platform/unix/SolarisLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage oshi/jna/platform/unix/SolarisLibc SolarisPrUsage public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPsInfo oshi/jna/platform/unix/SolarisLibc SolarisPsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timeval oshi/jna/platform/unix/SolarisLibc Timeval public,static
 inner oshi/jna/platform/unix/SolarisLibc$Exit_status oshi/jna/platform/unix/SolarisLibc Exit_status public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisUtmpx oshi/jna/platform/unix/SolarisLibc SolarisUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/SolarisLibc; -
 field public,static,final UTX_USERSIZE I - I32
 field public,static,final UTX_LINESIZE I - I32
 field public,static,final UTX_IDSIZE I - I4
 field public,static,final UTX_HOSTSIZE I - I257
 field public,static,final PRCLSZ I - I8
 field public,static,final PRFNSZ I - I16
 field public,static,final PRLNSZ I - I32
 field public,static,final PRARGSZ I - I80
 method public,abstract getutxent ()Loshi/jna/platform/unix/SolarisLibc$SolarisUtmpx; - -
in 23
class oshi/jna/platform/unix/SolarisLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage oshi/jna/platform/unix/SolarisLibc SolarisPrUsage public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPsInfo oshi/jna/platform/unix/SolarisLibc SolarisPsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timeval oshi/jna/platform/unix/SolarisLibc Timeval public,static
 inner oshi/jna/platform/unix/SolarisLibc$Exit_status oshi/jna/platform/unix/SolarisLibc Exit_status public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisUtmpx oshi/jna/platform/unix/SolarisLibc SolarisUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/SolarisLibc; -
 field public,static,final UTX_USERSIZE I - I32
 field public,static,final UTX_LINESIZE I - I32
 field public,static,final UTX_IDSIZE I - I4
 field public,static,final UTX_HOSTSIZE I - I257
 field public,static,final PRCLSZ I - I8
 field public,static,final PRFNSZ I - I16
 field public,static,final PRLNSZ I - I32
 field public,static,final PRARGSZ I - I80
 method public,abstract getutxent ()Loshi/jna/platform/unix/SolarisLibc$SolarisUtmpx; - -
 method public,abstract thr_self ()I - -
in 39
class oshi/jna/platform/unix/SolarisLibc$Exit_status 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/SolarisLibc$Exit_status oshi/jna/platform/unix/SolarisLibc Exit_status public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public e_termination S -
 field public e_exit S -
 method public <init> ()V - -
in 39
class oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 field public pr_flag I -
 field public pr_lwpid I -
 field public pr_addr Lcom/sun/jna/Pointer; -
 field public pr_wchan Lcom/sun/jna/Pointer; -
 field public pr_stype B -
 field public pr_state B -
 field public pr_sname B -
 field public pr_nice B -
 field public pr_syscall S -
 field public pr_oldpri B -
 field public pr_cpu B -
 field public pr_pri I -
 field public pr_pctcpu S -
 field public pr_pad S -
 field public pr_start Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_time Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_clname [B -
 field public pr_oldname [B -
 field public pr_onpro I -
 field public pr_bindpro I -
 field public pr_bindpset I -
 field public pr_lgrp I -
 field public pr_last_onproc J -
 field public pr_name [B -
 method public <init> (Ljava/nio/ByteBuffer;)V - -
in 39
class oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage oshi/jna/platform/unix/SolarisLibc SolarisPrUsage public,static
 field public pr_lwpid I -
 field public pr_count I -
 field public pr_tstamp Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_create Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_term Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_rtime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_utime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_stime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_ttime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_tftime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_dftime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_kftime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_ltime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_slptime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_wtime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_stoptime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public filltime [Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_minf Lcom/sun/jna/NativeLong; -
 field public pr_majf Lcom/sun/jna/NativeLong; -
 field public pr_nswap Lcom/sun/jna/NativeLong; -
 field public pr_inblk Lcom/sun/jna/NativeLong; -
 field public pr_oublk Lcom/sun/jna/NativeLong; -
 field public pr_msnd Lcom/sun/jna/NativeLong; -
 field public pr_mrcv Lcom/sun/jna/NativeLong; -
 field public pr_sigs Lcom/sun/jna/NativeLong; -
 field public pr_vctx Lcom/sun/jna/NativeLong; -
 field public pr_ictx Lcom/sun/jna/NativeLong; -
 field public pr_sysc Lcom/sun/jna/NativeLong; -
 field public pr_ioch Lcom/sun/jna/NativeLong; -
 field public filler [Lcom/sun/jna/NativeLong; -
 method public <init> (Ljava/nio/ByteBuffer;)V - -
in 39
class oshi/jna/platform/unix/SolarisLibc$SolarisPsInfo 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPsInfo oshi/jna/platform/unix/SolarisLibc SolarisPsInfo public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 field public pr_flag I -
 field public pr_nlwp I -
 field public pr_pid I -
 field public pr_ppid I -
 field public pr_pgid I -
 field public pr_sid I -
 field public pr_uid I -
 field public pr_euid I -
 field public pr_gid I -
 field public pr_egid I -
 field public pr_addr Lcom/sun/jna/Pointer; -
 field public pr_size Lcom/sun/jna/platform/unix/LibCAPI$size_t; -
 field public pr_rssize Lcom/sun/jna/platform/unix/LibCAPI$size_t; -
 field public pr_rssizepriv Lcom/sun/jna/platform/unix/LibCAPI$size_t; -
 field public pr_ttydev Lcom/sun/jna/NativeLong; -
 field public pr_pctcpu S -
 field public pr_pctmem S -
 field public pr_start Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_time Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_ctime Loshi/jna/platform/unix/SolarisLibc$Timestruc; -
 field public pr_fname [B -
 field public pr_psargs [B -
 field public pr_wstat I -
 field public pr_argc I -
 field public pr_argv Lcom/sun/jna/Pointer; -
 field public pr_envp Lcom/sun/jna/Pointer; -
 field public pr_dmodel B -
 field public pr_pad2 [B -
 field public pr_taskid I -
 field public pr_projid I -
 field public pr_nzomb I -
 field public pr_poolid I -
 field public pr_zoneid I -
 field public pr_contract I -
 field public pr_filler I -
 field public pr_lwp Loshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo; -
 method public <init> (Ljava/nio/ByteBuffer;)V - -
in 39
class oshi/jna/platform/unix/SolarisLibc$SolarisUtmpx 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/SolarisLibc$SolarisUtmpx oshi/jna/platform/unix/SolarisLibc SolarisUtmpx public,static
 inner oshi/jna/platform/unix/SolarisLibc$Exit_status oshi/jna/platform/unix/SolarisLibc Exit_status public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timeval oshi/jna/platform/unix/SolarisLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ut_user [B -
 field public ut_id [B -
 field public ut_line [B -
 field public ut_pid I -
 field public ut_type S -
 field public ut_exit Loshi/jna/platform/unix/SolarisLibc$Exit_status; -
 field public ut_tv Loshi/jna/platform/unix/SolarisLibc$Timeval; -
 field public ut_session I -
 field public pad [I -
 field public ut_syslen S -
 field public ut_host [B -
 method public <init> ()V - -
in 39
class oshi/jna/platform/unix/SolarisLibc$Timestruc 52 public,super java/lang/Object - -
 inner oshi/jna/platform/unix/SolarisLibc$Timestruc oshi/jna/platform/unix/SolarisLibc Timestruc public,static
 field public tv_sec Lcom/sun/jna/NativeLong; -
 field public tv_nsec Lcom/sun/jna/NativeLong; -
 method public <init> (Ljava/nio/ByteBuffer;)V - -
in 39
class oshi/jna/platform/unix/SolarisLibc$Timeval 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/SolarisLibc$Timeval oshi/jna/platform/unix/SolarisLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tv_sec Lcom/sun/jna/NativeLong; -
 field public tv_usec Lcom/sun/jna/NativeLong; -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/unix/aix/AixLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 field public,static,final INSTANCE Loshi/jna/platform/unix/aix/AixLibc; -
in 82
class oshi/jna/platform/unix/freebsd/FreeBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$CpTime oshi/jna/platform/unix/freebsd/FreeBsdLibc CpTime public,static
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval oshi/jna/platform/unix/freebsd/FreeBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/freebsd/FreeBsdLibc FreeBsdUtmpx public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/freebsd/FreeBsdLibc; -
 field public,static,final UTX_USERSIZE I - I32
 field public,static,final UTX_LINESIZE I - I16
 field public,static,final UTX_IDSIZE I - I8
 field public,static,final UTX_HOSTSIZE I - I128
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 method public,abstract sysctl ([IILcom/sun/jna/Pointer;Loshi/jna/platform/unix/NativeSizeTByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;)I - -
 method public,abstract sysctlbyname (Ljava/lang/String;Lcom/sun/jna/Pointer;Loshi/jna/platform/unix/NativeSizeTByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;)I - -
 method public,abstract sysctlnametomib (Ljava/lang/String;Lcom/sun/jna/Pointer;Loshi/jna/platform/unix/NativeSizeTByReference;)I - -
 method public,abstract getutxent ()Loshi/jna/platform/unix/freebsd/FreeBsdLibc$FreeBsdUtmpx; - -
in 34
class oshi/jna/platform/unix/freebsd/FreeBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$CpTime oshi/jna/platform/unix/freebsd/FreeBsdLibc CpTime public,static
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval oshi/jna/platform/unix/freebsd/FreeBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/freebsd/FreeBsdLibc FreeBsdUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/freebsd/FreeBsdLibc; -
 field public,static,final UTX_USERSIZE I - I32
 field public,static,final UTX_LINESIZE I - I16
 field public,static,final UTX_IDSIZE I - I8
 field public,static,final UTX_HOSTSIZE I - I128
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 method public,abstract getutxent ()Loshi/jna/platform/unix/freebsd/FreeBsdLibc$FreeBsdUtmpx; - -
in 1183
class oshi/jna/platform/unix/freebsd/FreeBsdLibc$CpTime 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$CpTime oshi/jna/platform/unix/freebsd/FreeBsdLibc CpTime public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public cpu_ticks [J -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/unix/freebsd/FreeBsdLibc$FreeBsdUtmpx 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/freebsd/FreeBsdLibc FreeBsdUtmpx public,static
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval oshi/jna/platform/unix/freebsd/FreeBsdLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ut_type S -
 field public ut_tv Loshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval; -
 field public ut_id [B -
 field public ut_pid I -
 field public ut_user [B -
 field public ut_line [B -
 field public ut_host [B -
 field public ut_spare [B -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval oshi/jna/platform/unix/freebsd/FreeBsdLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tv_sec J -
 field public tv_usec J -
 method public <init> ()V - -
in 82
class oshi/jna/platform/unix/openbsd/OpenBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/openbsd/OpenBsdLibc$Timeval oshi/jna/platform/unix/openbsd/OpenBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/openbsd/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/openbsd/OpenBsdLibc Bcachestats public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/openbsd/OpenBsdLibc; -
 field public,static,final CTL_KERN I - I1
 field public,static,final CTL_VM I - I1
 field public,static,final CTL_HW I - I6
 field public,static,final CTL_MACHDEP I - I7
 field public,static,final CTL_VFS I - I10
 field public,static,final KERN_OSTYPE I - I1
 field public,static,final KERN_OSRELEASE I - I2
 field public,static,final KERN_OSREV I - I3
 field public,static,final KERN_VERSION I - I4
 field public,static,final KERN_MAXVNODES I - I5
 field public,static,final KERN_MAXPROC I - I6
 field public,static,final KERN_ARGMAX I - I8
 field public,static,final KERN_CPTIME I - I40
 field public,static,final KERN_CPTIME2 I - I71
 field public,static,final VM_UVMEXP I - I4
 field public,static,final HW_MACHINE I - I1
 field public,static,final HW_MODEL I - I2
 field public,static,final HW_PAGESIZE I - I7
 field public,static,final HW_CPUSPEED I - I12
 field public,static,final HW_NCPUFOUND I - I21
 field public,static,final HW_SMT I - I24
 field public,static,final HW_NCPUONLINE I - I25
 field public,static,final VFS_GENERIC I - I0
 field public,static,final VFS_BCACHESTAT I - I3
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
 method public,abstract sysctl ([IILcom/sun/jna/Pointer;Loshi/jna/platform/unix/NativeSizeTByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/platform/unix/LibCAPI$size_t;)I - -
in 34
class oshi/jna/platform/unix/openbsd/OpenBsdLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/openbsd/OpenBsdLibc$Timeval oshi/jna/platform/unix/openbsd/OpenBsdLibc Timeval public,static
 inner oshi/jna/platform/unix/openbsd/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/openbsd/OpenBsdLibc Bcachestats public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/openbsd/OpenBsdLibc; -
 field public,static,final CTL_KERN I - I1
 field public,static,final CTL_VM I - I1
 field public,static,final CTL_HW I - I6
 field public,static,final CTL_MACHDEP I - I7
 field public,static,final CTL_VFS I - I10
 field public,static,final KERN_OSTYPE I - I1
 field public,static,final KERN_OSRELEASE I - I2
 field public,static,final KERN_OSREV I - I3
 field public,static,final KERN_VERSION I - I4
 field public,static,final KERN_MAXVNODES I - I5
 field public,static,final KERN_MAXPROC I - I6
 field public,static,final KERN_ARGMAX I - I8
 field public,static,final KERN_CPTIME I - I40
 field public,static,final KERN_CPTIME2 I - I71
 field public,static,final VM_UVMEXP I - I4
 field public,static,final HW_MACHINE I - I1
 field public,static,final HW_MODEL I - I2
 field public,static,final HW_PAGESIZE I - I7
 field public,static,final HW_CPUSPEED I - I12
 field public,static,final HW_NCPUFOUND I - I21
 field public,static,final HW_SMT I - I24
 field public,static,final HW_NCPUONLINE I - I25
 field public,static,final VFS_GENERIC I - I0
 field public,static,final VFS_BCACHESTAT I - I3
 field public,static,final CPUSTATES I - I5
 field public,static,final CP_USER I - I0
 field public,static,final CP_NICE I - I1
 field public,static,final CP_SYS I - I2
 field public,static,final CP_INTR I - I3
 field public,static,final CP_IDLE I - I4
 field public,static,final UINT64_SIZE I -
 field public,static,final INT_SIZE I -
in 1183
class oshi/jna/platform/unix/openbsd/OpenBsdLibc$Bcachestats 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/openbsd/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/openbsd/OpenBsdLibc Bcachestats public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public numbufs J -
 field public numbufpages J -
 field public numdirtypages J -
 field public numcleanpages J -
 field public pendingwrites J -
 field public pendingreads J -
 field public numwrites J -
 field public numreads J -
 field public cachehits J -
 field public busymapped J -
 field public dmapages J -
 field public highpages J -
 field public delwribufs J -
 field public kvaslots J -
 field public kvaslots_avail J -
 field public highflips J -
 field public highflops J -
 field public dmaflips J -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
in 1183
class oshi/jna/platform/unix/openbsd/OpenBsdLibc$Timeval 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/openbsd/OpenBsdLibc$Timeval oshi/jna/platform/unix/openbsd/OpenBsdLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tv_sec J -
 field public tv_usec J -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/unix/solaris/SolarisLibc 52 public,interface,abstract java/lang/Object oshi/jna/platform/unix/CLibrary -
 inner oshi/jna/platform/unix/solaris/SolarisLibc$Timeval oshi/jna/platform/unix/solaris/SolarisLibc Timeval public,static
 inner oshi/jna/platform/unix/solaris/SolarisLibc$Exit_status oshi/jna/platform/unix/solaris/SolarisLibc Exit_status public,static
 inner oshi/jna/platform/unix/solaris/SolarisLibc$SolarisUtmpx oshi/jna/platform/unix/solaris/SolarisLibc SolarisUtmpx public,static
 field public,static,final INSTANCE Loshi/jna/platform/unix/solaris/SolarisLibc; -
 field public,static,final UTX_USERSIZE I - I32
 field public,static,final UTX_LINESIZE I - I32
 field public,static,final UTX_IDSIZE I - I4
 field public,static,final UTX_HOSTSIZE I - I257
 method public,abstract getutxent ()Loshi/jna/platform/unix/solaris/SolarisLibc$SolarisUtmpx; - -
in 1183
class oshi/jna/platform/unix/solaris/SolarisLibc$Exit_status 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/solaris/SolarisLibc$Exit_status oshi/jna/platform/unix/solaris/SolarisLibc Exit_status public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public e_termination S -
 field public e_exit S -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/unix/solaris/SolarisLibc$SolarisUtmpx 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/solaris/SolarisLibc$SolarisUtmpx oshi/jna/platform/unix/solaris/SolarisLibc SolarisUtmpx public,static
 inner oshi/jna/platform/unix/solaris/SolarisLibc$Timeval oshi/jna/platform/unix/solaris/SolarisLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public ut_user [B -
 field public ut_id [B -
 field public ut_line [B -
 field public ut_pid I -
 field public ut_type S -
 field public ut_tv Loshi/jna/platform/unix/solaris/SolarisLibc$Timeval; -
 field public ut_session I -
 field public ut_syslen S -
 field public ut_host [B -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/unix/solaris/SolarisLibc$Timeval 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/unix/solaris/SolarisLibc$Timeval oshi/jna/platform/unix/solaris/SolarisLibc Timeval public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public tv_sec Lcom/sun/jna/NativeLong; -
 field public tv_usec Lcom/sun/jna/NativeLong; -
 method public <init> ()V - -
in 82
class oshi/jna/platform/windows/Cfgmgr32 52 public,interface,abstract java/lang/Object com/sun/jna/platform/win32/Cfgmgr32 -
 field public,static,final INSTANCE Loshi/jna/platform/windows/Cfgmgr32; -
 field public,static,final CM_DRP_DEVICEDESC I - I1
 field public,static,final CM_DRP_SERVICE I - I5
 field public,static,final CM_DRP_CLASS I - I8
 field public,static,final CM_DRP_MFG I - I12
 field public,static,final CM_DRP_FRIENDLYNAME I - I13
 method public,abstract CM_Get_DevNode_Registry_Property (IILcom/sun/jna/ptr/IntByReference;Lcom/sun/jna/Pointer;Lcom/sun/jna/ptr/IntByReference;I)Z - -
in 28
class oshi/jna/platform/windows/Kernel32 52 public,interface,abstract java/lang/Object com/sun/jna/platform/win32/Kernel32 -
 inner oshi/jna/platform/windows/Kernel32$ProcessorFeature oshi/jna/platform/windows/Kernel32 ProcessorFeature public,static,final,enum
 field public,static,final INSTANCE Loshi/jna/platform/windows/Kernel32; -
in 28
class oshi/jna/platform/windows/Kernel32$ProcessorFeature 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/jna/platform/windows/Kernel32$ProcessorFeature;>;
 inner oshi/jna/platform/windows/Kernel32$ProcessorFeature oshi/jna/platform/windows/Kernel32 ProcessorFeature public,static,final,enum
 field public,static,final,enum PF_FLOATING_POINT_PRECISION_ERRATA Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_FLOATING_POINT_EMULATED Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_COMPARE_EXCHANGE_DOUBLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_MMX_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_PPC_MOVEMEM_64BIT_OK Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ALPHA_BYTE_INSTRUCTIONS Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_XMMI_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_3DNOW_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_RDTSC_INSTRUCTION_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_PAE_ENABLED Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_XMMI64_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_SSE_DAZ_MODE_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_NX_ENABLED Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_SSE3_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_COMPARE_EXCHANGE128 Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_COMPARE64_EXCHANGE128 Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_CHANNELS_ENABLED Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_XSAVE_ENABLED Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_VFP_32_REGISTERS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_NEON_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_SECOND_LEVEL_ADDRESS_TRANSLATION Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_VIRT_FIRMWARE_ENABLED Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_RDWRFSGSBASE_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_FASTFAIL_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_DIVIDE_INSTRUCTION_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_64BIT_LOADSTORE_ATOMIC Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_EXTERNAL_CACHE_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_FMAC_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_RDRAND_INSTRUCTION_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_V8_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_V8_CRYPTO_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_V8_CRC32_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_RDTSCP_INSTRUCTION_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_RDPID_INSTRUCTION_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_V81_ATOMIC_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_SSSE3_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_SSE4_1_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_SSE4_2_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_AVX_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_AVX2_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_AVX512F_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_V82_DP_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_V83_JSCVT_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 field public,static,final,enum PF_ARM_V83_LRCPC_INSTRUCTIONS_AVAILABLE Loshi/jna/platform/windows/Kernel32$ProcessorFeature; -
 method public,static values ()[Loshi/jna/platform/windows/Kernel32$ProcessorFeature; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/jna/platform/windows/Kernel32$ProcessorFeature; - -
 method public value ()I - -
in 30
class oshi/jna/platform/windows/NtDll 52 public,interface,abstract java/lang/Object com/sun/jna/platform/win32/NtDll -
 inner oshi/jna/platform/windows/NtDll$RTL_DRIVE_LETTER_CURDIR oshi/jna/platform/windows/NtDll RTL_DRIVE_LETTER_CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$CURDIR oshi/jna/platform/windows/NtDll CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$STRING oshi/jna/platform/windows/NtDll STRING public,static
 inner oshi/jna/platform/windows/NtDll$UNICODE_STRING oshi/jna/platform/windows/NtDll UNICODE_STRING public,static
 inner oshi/jna/platform/windows/NtDll$RTL_USER_PROCESS_PARAMETERS oshi/jna/platform/windows/NtDll RTL_USER_PROCESS_PARAMETERS public,static
 inner oshi/jna/platform/windows/NtDll$PEB oshi/jna/platform/windows/NtDll PEB public,static
 inner oshi/jna/platform/windows/NtDll$PROCESS_BASIC_INFORMATION oshi/jna/platform/windows/NtDll PROCESS_BASIC_INFORMATION public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 field public,static,final INSTANCE Loshi/jna/platform/windows/NtDll; -
 field public,static,final PROCESS_BASIC_INFORMATION I - I0
 method public,abstract NtQueryInformationProcess (Lcom/sun/jna/platform/win32/WinNT$HANDLE;ILcom/sun/jna/Pointer;ILcom/sun/jna/ptr/IntByReference;)I - -
in 30
class oshi/jna/platform/windows/NtDll$CURDIR 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/NtDll$CURDIR oshi/jna/platform/windows/NtDll CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$UNICODE_STRING oshi/jna/platform/windows/NtDll UNICODE_STRING public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public DosPath Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public Handle Lcom/sun/jna/Pointer; -
 method public <init> ()V - -
in 30
class oshi/jna/platform/windows/NtDll$PEB 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/NtDll$PEB oshi/jna/platform/windows/NtDll PEB public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public pad [B -
 field public pad2 [Lcom/sun/jna/Pointer; -
 field public ProcessParameters Lcom/sun/jna/Pointer; -
 method public <init> ()V - -
in 30
class oshi/jna/platform/windows/NtDll$PROCESS_BASIC_INFORMATION 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/NtDll$PROCESS_BASIC_INFORMATION oshi/jna/platform/windows/NtDll PROCESS_BASIC_INFORMATION public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Reserved1 Lcom/sun/jna/Pointer; -
 field public PebBaseAddress Lcom/sun/jna/Pointer; -
 field public Reserved2 [Lcom/sun/jna/Pointer; -
 method public <init> ()V - -
in 30
class oshi/jna/platform/windows/NtDll$RTL_DRIVE_LETTER_CURDIR 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/NtDll$RTL_DRIVE_LETTER_CURDIR oshi/jna/platform/windows/NtDll RTL_DRIVE_LETTER_CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$STRING oshi/jna/platform/windows/NtDll STRING public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Flags S -
 field public Length S -
 field public TimeStamp I -
 field public DosPath Loshi/jna/platform/windows/NtDll$STRING; -
 method public <init> ()V - -
in 30
class oshi/jna/platform/windows/NtDll$RTL_USER_PROCESS_PARAMETERS 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/NtDll$RTL_DRIVE_LETTER_CURDIR oshi/jna/platform/windows/NtDll RTL_DRIVE_LETTER_CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$RTL_USER_PROCESS_PARAMETERS oshi/jna/platform/windows/NtDll RTL_USER_PROCESS_PARAMETERS public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/platform/windows/NtDll$CURDIR oshi/jna/platform/windows/NtDll CURDIR public,static
 inner oshi/jna/platform/windows/NtDll$UNICODE_STRING oshi/jna/platform/windows/NtDll UNICODE_STRING public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public MaximumLength I -
 field public Length I -
 field public Flags I -
 field public DebugFlags I -
 field public ConsoleHandle Lcom/sun/jna/platform/win32/WinNT$HANDLE; -
 field public ConsoleFlags I -
 field public StandardInput Lcom/sun/jna/platform/win32/WinNT$HANDLE; -
 field public StandardOutput Lcom/sun/jna/platform/win32/WinNT$HANDLE; -
 field public StandardError Lcom/sun/jna/platform/win32/WinNT$HANDLE; -
 field public CurrentDirectory Loshi/jna/platform/windows/NtDll$CURDIR; -
 field public DllPath Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public ImagePathName Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public CommandLine Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public Environment Lcom/sun/jna/Pointer; -
 field public StartingX I -
 field public StartingY I -
 field public CountX I -
 field public CountY I -
 field public CountCharsX I -
 field public CountCharsY I -
 field public FillAttribute I -
 field public WindowFlags I -
 field public ShowWindowFlags I -
 field public WindowTitle Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public DesktopInfo Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public ShellInfo Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public RuntimeData Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public CurrentDirectories [Loshi/jna/platform/windows/NtDll$RTL_DRIVE_LETTER_CURDIR; -
 field public EnvironmentSize Lcom/sun/jna/platform/win32/BaseTSD$ULONG_PTR; -
 field public EnvironmentVersion Lcom/sun/jna/platform/win32/BaseTSD$ULONG_PTR; -
 field public PackageDependencyData Lcom/sun/jna/Pointer; -
 field public ProcessGroupId I -
 field public LoaderThreads I -
 field public RedirectionDllName Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public HeapPartitionName Loshi/jna/platform/windows/NtDll$UNICODE_STRING; -
 field public DefaultThreadpoolCpuSetMasks Lcom/sun/jna/platform/win32/BaseTSD$ULONG_PTR; -
 field public DefaultThreadpoolCpuSetMaskCount I -
 method public <init> ()V - -
in 30
class oshi/jna/platform/windows/NtDll$STRING 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/NtDll$STRING oshi/jna/platform/windows/NtDll STRING public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Length S -
 field public MaximumLength S -
 field public Buffer Lcom/sun/jna/Pointer; -
 method public <init> ()V - -
in 30
class oshi/jna/platform/windows/NtDll$UNICODE_STRING 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/NtDll$UNICODE_STRING oshi/jna/platform/windows/NtDll UNICODE_STRING public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Length S -
 field public MaximumLength S -
 field public Buffer Lcom/sun/jna/Pointer; -
 method public <init> ()V - -
in 290
class oshi/jna/platform/windows/PowrProf 52 public,interface,abstract java/lang/Object com/sun/jna/platform/win32/PowrProf -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_MANUFACTURE_DATE oshi/jna/platform/windows/PowrProf BATTERY_MANUFACTURE_DATE public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_STATUS oshi/jna/platform/windows/PowrProf BATTERY_STATUS public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_WAIT_STATUS oshi/jna/platform/windows/PowrProf BATTERY_WAIT_STATUS public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_INFORMATION public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION_LEVEL public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION public,static
 inner oshi/jna/platform/windows/PowrProf$ProcessorPowerInformation oshi/jna/platform/windows/PowrProf ProcessorPowerInformation public,static
 inner oshi/jna/platform/windows/PowrProf$SystemBatteryState oshi/jna/platform/windows/PowrProf SystemBatteryState public,static
 field public,static,final INSTANCE Loshi/jna/platform/windows/PowrProf; -
in 1183
class oshi/jna/platform/windows/PowrProf$BATTERY_INFORMATION 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_INFORMATION public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Capabilities I -
 field public Technology B -
 field public Reserved [B -
 field public Chemistry [B -
 field public DesignedCapacity I -
 field public FullChargedCapacity I -
 field public DefaultAlert1 I -
 field public DefaultAlert2 I -
 field public CriticalBias I -
 field public CycleCount I -
 method public <init> ()V - -
in 39
class oshi/jna/platform/windows/PowrProf$BATTERY_INFORMATION 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_INFORMATION public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Capabilities I -
 field public Technology B -
 field public Reserved [B -
 field public Chemistry [B -
 field public DesignedCapacity I -
 field public FullChargedCapacity I -
 field public DefaultAlert1 I -
 field public DefaultAlert2 I -
 field public CriticalBias I -
 field public CycleCount I -
 method public <init> ()V - -
 method public close ()V - -
in 1183
class oshi/jna/platform/windows/PowrProf$BATTERY_MANUFACTURE_DATE 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_MANUFACTURE_DATE oshi/jna/platform/windows/PowrProf BATTERY_MANUFACTURE_DATE public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Day B -
 field public Month B -
 field public Year S -
 method public <init> ()V - -
in 39
class oshi/jna/platform/windows/PowrProf$BATTERY_MANUFACTURE_DATE 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_MANUFACTURE_DATE oshi/jna/platform/windows/PowrProf BATTERY_MANUFACTURE_DATE public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public Day B -
 field public Month B -
 field public Year S -
 method public <init> ()V - -
 method public close ()V - -
in 1183
class oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public BatteryTag I -
 field public InformationLevel I -
 field public AtRate I -
 method public <init> ()V - -
in 39
class oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public BatteryTag I -
 field public InformationLevel I -
 field public AtRate I -
 method public <init> ()V - -
 method public close ()V - -
in 290
class oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL;>;
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION_LEVEL public,static,final,enum
 field public,static,final,enum BatteryInformation Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatteryGranularityInformation Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatteryTemperature Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatteryEstimatedTime Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatteryDeviceName Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatteryManufactureDate Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatteryManufactureName Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatteryUniqueID Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 field public,static,final,enum BatterySerialNumber Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; -
 method public,static values ()[Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL; - -
in 1183
class oshi/jna/platform/windows/PowrProf$BATTERY_STATUS 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_STATUS oshi/jna/platform/windows/PowrProf BATTERY_STATUS public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public PowerState I -
 field public Capacity I -
 field public Voltage I -
 field public Rate I -
 method public <init> ()V - -
in 39
class oshi/jna/platform/windows/PowrProf$BATTERY_STATUS 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_STATUS oshi/jna/platform/windows/PowrProf BATTERY_STATUS public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public PowerState I -
 field public Capacity I -
 field public Voltage I -
 field public Rate I -
 method public <init> ()V - -
 method public close ()V - -
in 1183
class oshi/jna/platform/windows/PowrProf$BATTERY_WAIT_STATUS 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_WAIT_STATUS oshi/jna/platform/windows/PowrProf BATTERY_WAIT_STATUS public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public BatteryTag I -
 field public Timeout I -
 field public PowerState I -
 field public LowCapacity I -
 field public HighCapacity I -
 method public <init> ()V - -
in 39
class oshi/jna/platform/windows/PowrProf$BATTERY_WAIT_STATUS 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/windows/PowrProf$BATTERY_WAIT_STATUS oshi/jna/platform/windows/PowrProf BATTERY_WAIT_STATUS public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public BatteryTag I -
 field public Timeout I -
 field public PowerState I -
 field public LowCapacity I -
 field public HighCapacity I -
 method public <init> ()V - -
 method public close ()V - -
in 290
class oshi/jna/platform/windows/PowrProf$ProcessorPowerInformation 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/PowrProf$ProcessorPowerInformation oshi/jna/platform/windows/PowrProf ProcessorPowerInformation public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public number I -
 field public maxMhz I -
 field public currentMhz I -
 field public mhzLimit I -
 field public maxIdleState I -
 field public currentIdleState I -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public <init> ()V - -
in 1183
class oshi/jna/platform/windows/PowrProf$SystemBatteryState 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/PowrProf$SystemBatteryState oshi/jna/platform/windows/PowrProf SystemBatteryState public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public acOnLine B -
 field public batteryPresent B -
 field public charging B -
 field public discharging B -
 field public spare1 [B -
 field public tag B -
 field public maxCapacity I -
 field public remainingCapacity I -
 field public rate I -
 field public estimatedTime I -
 field public defaultAlert1 I -
 field public defaultAlert2 I -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public <init> ()V - -
in 39
class oshi/jna/platform/windows/PowrProf$SystemBatteryState 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/windows/PowrProf$SystemBatteryState oshi/jna/platform/windows/PowrProf SystemBatteryState public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public acOnLine B -
 field public batteryPresent B -
 field public charging B -
 field public discharging B -
 field public spare1 [B -
 field public tag B -
 field public maxCapacity I -
 field public remainingCapacity I -
 field public rate I -
 field public estimatedTime I -
 field public defaultAlert1 I -
 field public defaultAlert2 I -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public <init> ()V - -
 method public close ()V - -
in 371
class oshi/jna/platform/windows/WinNT 52 public,interface,abstract java/lang/Object com/sun/jna/platform/win32/WinNT -
 inner oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION oshi/jna/platform/windows/WinNT TOKEN_ELEVATION public,static
in 1183
class oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION 52 public,super com/sun/jna/Structure - -
 inner oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION oshi/jna/platform/windows/WinNT TOKEN_ELEVATION public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public TokenIsElevated I -
 method public <init> ()V - -
in 42
class oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION 52 public,super com/sun/jna/Structure java/lang/AutoCloseable -
 inner oshi/jna/platform/windows/WinNT$TOKEN_ELEVATION oshi/jna/platform/windows/WinNT TOKEN_ELEVATION public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public TokenIsElevated I -
 method public <init> ()V - -
 method public close ()V - -
