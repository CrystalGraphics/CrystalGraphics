cg-stub-db 1
in 1117
class org/jspecify/annotations/NonNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 1117
class org/jspecify/annotations/NullMarked 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#MODULE,ELjava/lang/annotation/ElementType;#PACKAGE,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 1117
class org/jspecify/annotations/NullUnmarked 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#PACKAGE,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR])
in 1117
class org/jspecify/annotations/Nullable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE_USE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
