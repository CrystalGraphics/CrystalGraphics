cg-stub-db 1
in 403
class javax/annotation/CheckForNull 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/CheckForSigned 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/CheckReturnValue 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#TYPE,ELjava/lang/annotation/ElementType;#PACKAGE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract when ()Ljavax/annotation/meta/When; - - ELjavax/annotation/meta/When;#ALWAYS
in 403
class javax/annotation/Detainted 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/MatchesPattern 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner javax/annotation/MatchesPattern$Checker javax/annotation/MatchesPattern Checker public,static
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()Ljava/lang/String; - -
 method public,abstract flags ()I - - I0
in 403
class javax/annotation/MatchesPattern$Checker 49 public,super java/lang/Object javax/annotation/meta/TypeQualifierValidator Ljava/lang/Object;Ljavax/annotation/meta/TypeQualifierValidator<Ljavax/annotation/MatchesPattern;>;
 inner javax/annotation/MatchesPattern$Checker javax/annotation/MatchesPattern Checker public,static
 method public <init> ()V - -
 method public forConstantValue (Ljavax/annotation/MatchesPattern;Ljava/lang/Object;)Ljavax/annotation/meta/When; - -
in 403
class javax/annotation/Nonnegative 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner javax/annotation/Nonnegative$Checker javax/annotation/Nonnegative Checker public,static
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract when ()Ljavax/annotation/meta/When; - - ELjavax/annotation/meta/When;#ALWAYS
in 403
class javax/annotation/Nonnegative$Checker 49 public,super java/lang/Object javax/annotation/meta/TypeQualifierValidator Ljava/lang/Object;Ljavax/annotation/meta/TypeQualifierValidator<Ljavax/annotation/Nonnegative;>;
 inner javax/annotation/Nonnegative$Checker javax/annotation/Nonnegative Checker public,static
 method public <init> ()V - -
 method public forConstantValue (Ljavax/annotation/Nonnegative;Ljava/lang/Object;)Ljavax/annotation/meta/When; - -
in 403
class javax/annotation/Nonnull 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner javax/annotation/Nonnull$Checker javax/annotation/Nonnull Checker public,static
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract when ()Ljavax/annotation/meta/When; - - ELjavax/annotation/meta/When;#ALWAYS
in 403
class javax/annotation/Nonnull$Checker 49 public,super java/lang/Object javax/annotation/meta/TypeQualifierValidator Ljava/lang/Object;Ljavax/annotation/meta/TypeQualifierValidator<Ljavax/annotation/Nonnull;>;
 inner javax/annotation/Nonnull$Checker javax/annotation/Nonnull Checker public,static
 method public <init> ()V - -
 method public forConstantValue (Ljavax/annotation/Nonnull;Ljava/lang/Object;)Ljavax/annotation/meta/When; - -
in 403
class javax/annotation/Nullable 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/OverridingMethodsMustInvokeSuper 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/ParametersAreNonnullByDefault 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/ParametersAreNullableByDefault 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/PropertyKey 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract when ()Ljavax/annotation/meta/When; - - ELjavax/annotation/meta/When;#ALWAYS
in 403
class javax/annotation/RegEx 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner javax/annotation/RegEx$Checker javax/annotation/RegEx Checker public,static
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract when ()Ljavax/annotation/meta/When; - - ELjavax/annotation/meta/When;#ALWAYS
in 403
class javax/annotation/RegEx$Checker 49 public,super java/lang/Object javax/annotation/meta/TypeQualifierValidator Ljava/lang/Object;Ljavax/annotation/meta/TypeQualifierValidator<Ljavax/annotation/RegEx;>;
 inner javax/annotation/RegEx$Checker javax/annotation/RegEx Checker public,static
 method public <init> ()V - -
 method public forConstantValue (Ljavax/annotation/RegEx;Ljava/lang/Object;)Ljavax/annotation/meta/When; - -
in 403
class javax/annotation/Signed 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/Syntax 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()Ljava/lang/String; - -
 method public,abstract when ()Ljavax/annotation/meta/When; - - ELjavax/annotation/meta/When;#ALWAYS
in 403
class javax/annotation/Tainted 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/Untainted 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract when ()Ljavax/annotation/meta/When; - - ELjavax/annotation/meta/When;#ALWAYS
in 403
class javax/annotation/WillClose 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/WillCloseWhenClosed 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/WillNotClose 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/concurrent/GuardedBy 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()Ljava/lang/String; - -
in 403
class javax/annotation/concurrent/Immutable 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 403
class javax/annotation/concurrent/NotThreadSafe 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 403
class javax/annotation/concurrent/ThreadSafe 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 403
class javax/annotation/meta/Exclusive 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/meta/Exhaustive 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 403
class javax/annotation/meta/TypeQualifier 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract applicableTo ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
in 403
class javax/annotation/meta/TypeQualifierDefault 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()[Ljava/lang/annotation/ElementType; - - []
in 403
class javax/annotation/meta/TypeQualifierNickname 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#ANNOTATION_TYPE])
in 403
class javax/annotation/meta/TypeQualifierValidator 49 public,interface,abstract java/lang/Object - <A::Ljava/lang/annotation/Annotation;>Ljava/lang/Object;
 method public,abstract forConstantValue (Ljava/lang/annotation/Annotation;Ljava/lang/Object;)Ljavax/annotation/meta/When; (TA;Ljava/lang/Object;)Ljavax/annotation/meta/When; -
in 403
class javax/annotation/meta/When 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljavax/annotation/meta/When;>;
 field public,static,final,enum ALWAYS Ljavax/annotation/meta/When; -
 field public,static,final,enum UNKNOWN Ljavax/annotation/meta/When; -
 field public,static,final,enum MAYBE Ljavax/annotation/meta/When; -
 field public,static,final,enum NEVER Ljavax/annotation/meta/When; -
 method public,static values ()[Ljavax/annotation/meta/When; - -
 method public,static valueOf (Ljava/lang/String;)Ljavax/annotation/meta/When; - -
