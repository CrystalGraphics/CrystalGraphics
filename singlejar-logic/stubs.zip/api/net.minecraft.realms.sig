cg-stub-db 1
in 216
class net/minecraft/realms/AbstractRealmsButton 52 public,super,abstract java/lang/Object - <P:Lnet/minecraft/client/gui/components/AbstractWidget;:Lnet/minecraft/realms/RealmsAbstractButtonProxy<*>;>Ljava/lang/Object;
 method public <init> ()V - -
 method public,abstract getProxy ()Lnet/minecraft/client/gui/components/AbstractWidget; ()TP; -
 method public active ()Z - -
 method public active (Z)V - -
 method public isVisible ()Z - -
 method public setVisible (Z)V - -
 method public render (IIF)V - -
 method public blit (IIIIII)V - -
 method public tick ()V - -
in 51
class net/minecraft/realms/DisconnectedRealmsScreen 52 public,super net/minecraft/realms/RealmsScreen - -
 method public <init> (Lnet/minecraft/realms/RealmsScreen;Ljava/lang/String;Lnet/minecraft/network/chat/Component;)V - -
 method public init ()V - -
 method public keyPressed (III)Z - -
 method public render (IIF)V - -
in 86
class net/minecraft/realms/DisconnectedRealmsScreen 52 public,super net/minecraft/realms/RealmsScreen - -
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/Component;)V - -
 method public init ()V - -
 method public onClose ()V - -
 method public render (Lcom/mojang/blaze3d/vertex/PoseStack;IIF)V - -
in 82
class net/minecraft/realms/DisconnectedRealmsScreen 60 public,super net/minecraft/realms/RealmsScreen - -
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/Component;)V - -
 method public init ()V - -
 method public getNarrationMessage ()Lnet/minecraft/network/chat/Component; - -
 method public onClose ()V - -
 method public render (Lcom/mojang/blaze3d/vertex/PoseStack;IIF)V - -
in 34
class net/minecraft/realms/DisconnectedRealmsScreen 61 public,super net/minecraft/realms/RealmsScreen - -
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/Component;)V - -
 method public init ()V - -
 method public getNarrationMessage ()Lnet/minecraft/network/chat/Component; - -
 method public onClose ()V - -
 method public render (Lcom/mojang/blaze3d/vertex/PoseStack;IIF)V - -
in 75
class net/minecraft/realms/DisconnectedRealmsScreen 61 public,super net/minecraft/realms/RealmsScreen - -
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 inner net/minecraft/client/gui/components/Button$Builder net/minecraft/client/gui/components/Button Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/Component;)V - -
 method public init ()V - -
 method public getNarrationMessage ()Lnet/minecraft/network/chat/Component; - -
 method public onClose ()V - -
 method public render (Lcom/mojang/blaze3d/vertex/PoseStack;IIF)V - -
in 130
class net/minecraft/realms/DisconnectedRealmsScreen 61 public,super net/minecraft/realms/RealmsScreen - -
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 inner net/minecraft/client/gui/components/Button$Builder net/minecraft/client/gui/components/Button Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/Component;)V - -
 method public init ()V - -
 method public getNarrationMessage ()Lnet/minecraft/network/chat/Component; - -
 method public onClose ()V - -
 method public render (Lnet/minecraft/client/gui/GuiGraphics;IIF)V - -
in 221
class net/minecraft/realms/DisconnectedRealmsScreen 65 public,super net/minecraft/realms/RealmsScreen - -
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 inner net/minecraft/client/gui/components/Button$Builder net/minecraft/client/gui/components/Button Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/Component;)V - -
 method public init ()V - -
 method public getNarrationMessage ()Lnet/minecraft/network/chat/Component; - -
 method public onClose ()V - -
 method public render (Lnet/minecraft/client/gui/GuiGraphics;IIF)V - -
in 86
class net/minecraft/realms/NarrationHelper 52 public,super java/lang/Object - -
 method public,static now (Ljava/lang/String;)V - -
 method public,static,varargs now ([Ljava/lang/String;)V - -
 method public,static now (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
 method public,static join (Ljava/lang/Iterable;)Ljava/lang/String; (Ljava/lang/Iterable<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,static repeatedly (Ljava/lang/String;)V - -
in 216
class net/minecraft/realms/RealmListEntry 52 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList$Entry - Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<Lnet/minecraft/realms/RealmListEntry;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 method public <init> ()V - -
 method public,abstract render (IIIIIIIZF)V - -
 method public mouseClicked (DDI)Z - -
in 59
class net/minecraft/realms/Realms 52 public,super java/lang/Object - -
 inner net/minecraft/client/Options$a net/minecraft/client/Options a public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static isTouchScreen ()Z - -
 method public,static getProxy ()Ljava/net/Proxy; - -
 method public,static sessionId ()Ljava/lang/String; - -
 method public,static userName ()Ljava/lang/String; - -
 method public,static currentTimeMillis ()J - -
 method public,static getSessionId ()Ljava/lang/String; - -
 method public,static getUUID ()Ljava/lang/String; - -
 method public,static getName ()Ljava/lang/String; - -
 method public,static uuidToName (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static execute (Ljava/util/concurrent/Callable;)Lcom/google/common/util/concurrent/ListenableFuture; <V:Ljava/lang/Object;>(Ljava/util/concurrent/Callable<TV;>;)Lcom/google/common/util/concurrent/ListenableFuture<TV;>; -
 method public,static execute (Ljava/lang/Runnable;)V - -
 method public,static setScreen (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public,static setScreenDirect (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public,static getGameDirectoryPath ()Ljava/lang/String; - -
 method public,static survivalId ()I - -
 method public,static creativeId ()I - -
 method public,static adventureId ()I - -
 method public,static spectatorId ()I - -
 method public,static setConnectedToRealms (Z)V - -
 method public,static downloadResourcePack (Ljava/lang/String;Ljava/lang/String;)Lcom/google/common/util/concurrent/ListenableFuture; - -
 method public,static clearResourcePack ()V - -
 method public,static getRealmsNotificationsEnabled ()Z - -
 method public,static inTitleScreen ()Z - -
 method public,static deletePlayerTag (Ljava/io/File;)V - -
in 216
class net/minecraft/realms/Realms 52 public,super java/lang/Object - -
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static isTouchScreen ()Z - -
 method public,static getProxy ()Ljava/net/Proxy; - -
 method public,static sessionId ()Ljava/lang/String; - -
 method public,static userName ()Ljava/lang/String; - -
 method public,static currentTimeMillis ()J - -
 method public,static getSessionId ()Ljava/lang/String; - -
 method public,static getUUID ()Ljava/lang/String; - -
 method public,static getName ()Ljava/lang/String; - -
 method public,static uuidToName (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static execute (Ljava/util/function/Supplier;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/function/Supplier<TV;>;)Ljava/util/concurrent/CompletableFuture<TV;>; -
 method public,static execute (Ljava/lang/Runnable;)V - -
 method public,static setScreen (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public,static setScreenDirect (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public,static getGameDirectoryPath ()Ljava/lang/String; - -
 method public,static survivalId ()I - -
 method public,static creativeId ()I - -
 method public,static adventureId ()I - -
 method public,static spectatorId ()I - -
 method public,static setConnectedToRealms (Z)V - -
 method public,static downloadResourcePack (Ljava/lang/String;Ljava/lang/String;)Ljava/util/concurrent/CompletableFuture; (Ljava/lang/String;Ljava/lang/String;)Ljava/util/concurrent/CompletableFuture<*>; -
 method public,static clearResourcePack ()V - -
 method public,static getRealmsNotificationsEnabled ()Z - -
 method public,static inTitleScreen ()Z - -
 method public,static deletePlayerTag (Ljava/io/File;)V - -
 method public,static openUri (Ljava/lang/String;)V - -
 method public,static setClipboard (Ljava/lang/String;)V - -
 method public,static getMinecraftVersionString ()Ljava/lang/String; - -
 method public,static resourceLocation (Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation; - -
 method public,static,varargs getLocalizedString (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static bind (Ljava/lang/String;)V - -
 method public,static narrateNow (Ljava/lang/String;)V - -
 method public,static,varargs narrateNow ([Ljava/lang/String;)V - -
 method public,static narrateNow (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
 method public,static joinNarrations (Ljava/lang/Iterable;)Ljava/lang/String; (Ljava/lang/Iterable<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,static narrateRepeatedly (Ljava/lang/String;)V - -
in 216
class net/minecraft/realms/RealmsAbstractButtonProxy 52 public,interface,abstract java/lang/Object - <T:Lnet/minecraft/realms/AbstractRealmsButton<*>;>Ljava/lang/Object;
 method public,abstract getButton ()Lnet/minecraft/realms/AbstractRealmsButton; ()TT; -
 method public,abstract active ()Z - -
 method public,abstract active (Z)V - -
 method public,abstract isVisible ()Z - -
 method public,abstract setVisible (Z)V - -
in 59
class net/minecraft/realms/RealmsAnvilLevelStorageSource 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/world/level/storage/LevelStorageSource;)V - -
 method public getName ()Ljava/lang/String; - -
 method public levelExists (Ljava/lang/String;)Z - -
 method public convertLevel (Ljava/lang/String;Lnet/minecraft/util/ProgressListener;)Z - -
 method public requiresConversion (Ljava/lang/String;)Z - -
 method public isNewLevelIdAcceptable (Ljava/lang/String;)Z - -
 method public deleteLevel (Ljava/lang/String;)Z - -
 method public isConvertible (Ljava/lang/String;)Z - -
 method public renameLevel (Ljava/lang/String;Ljava/lang/String;)V - -
 method public clearAll ()V - -
 method public getLevelList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/RealmsLevelSummary;>; net/minecraft/world/level/storage/LevelStorageException
in 216
class net/minecraft/realms/RealmsAnvilLevelStorageSource 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/world/level/storage/LevelStorageSource;)V - -
 method public getName ()Ljava/lang/String; - -
 method public levelExists (Ljava/lang/String;)Z - -
 method public convertLevel (Ljava/lang/String;Lnet/minecraft/util/ProgressListener;)Z - -
 method public requiresConversion (Ljava/lang/String;)Z - -
 method public isNewLevelIdAcceptable (Ljava/lang/String;)Z - -
 method public deleteLevel (Ljava/lang/String;)Z - -
 method public renameLevel (Ljava/lang/String;Ljava/lang/String;)V - -
 method public getLevelList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/RealmsLevelSummary;>; net/minecraft/world/level/storage/LevelStorageException
in 59
class net/minecraft/realms/RealmsBridge 52 public,super net/minecraft/realms/RealmsScreen - -
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public switchToRealms (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public getNotificationScreen (Lnet/minecraft/client/gui/screens/Screen;)Lciz; - -
 method public init ()V - -
 method public,static openUri (Ljava/lang/String;)V - -
 method public,static setClipboard (Ljava/lang/String;)V - -
in 196
class net/minecraft/realms/RealmsBridge 52 public,super net/minecraft/realms/RealmsScreen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public switchToRealms (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public getNotificationScreen (Lnet/minecraft/client/gui/screens/Screen;)Lnet/minecraft/realms/RealmsScreenProxy; - -
 method public init ()V - -
in 219
class net/minecraft/realms/RealmsBridge 52 public,super net/minecraft/realms/RealmsScreen - -
 method public <init> ()V - -
 method public switchToRealms (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public getNotificationScreen (Lnet/minecraft/client/gui/screens/Screen;)Lnet/minecraft/realms/RealmsScreenProxy; - -
 method public init ()V - -
in 86
class net/minecraft/realms/RealmsBridge 52 public,super net/minecraft/realms/RealmsScreen - -
 method public <init> ()V - -
 method public switchToRealms (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public getNotificationScreen (Lnet/minecraft/client/gui/screens/Screen;)Lnet/minecraft/realms/RealmsScreen; - -
 method public init ()V - -
in 200
class net/minecraft/realms/RealmsBufferBuilder 52 public,super java/lang/Object - -
 inner com/mojang/blaze3d/vertex/BufferBuilder$State com/mojang/blaze3d/vertex/BufferBuilder State public
 method public <init> (Lcom/mojang/blaze3d/vertex/BufferBuilder;)V - -
 method public from (Lcom/mojang/blaze3d/vertex/BufferBuilder;)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public sortQuads (FFF)V - -
 method public fixupQuadColor (I)V - -
 method public getBuffer ()Ljava/nio/ByteBuffer; - -
 method public postNormal (FFF)V - -
 method public getDrawMode ()I - -
 method public offset (DDD)V - -
 method public restoreState (Lcom/mojang/blaze3d/vertex/BufferBuilder$State;)V - -
 method public endVertex ()V - -
 method public normal (FFF)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public end ()V - -
 method public begin (ILcom/mojang/blaze3d/vertex/VertexFormat;)V - -
 method public color (IIII)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public faceTex2 (IIII)V - -
 method public postProcessFacePosition (DDD)V - -
 method public fixupVertexColor (FFFI)V - -
 method public color (FFFF)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public getVertexFormat ()Lnet/minecraft/realms/RealmsVertexFormat; - -
 method public faceTint (FFFI)V - -
 method public tex2 (II)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public putBulkData ([I)V - -
 method public tex (DD)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public getVertexCount ()I - -
 method public clear ()V - -
 method public vertex (DDD)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public fixupQuadColor (FFF)V - -
 method public noColor ()V - -
in 59
class net/minecraft/realms/RealmsButton 52 public,super,abstract java/lang/Object - -
 field protected,static,final WIDGETS_LOCATION Lnet/minecraft/resources/ResourceLocation; -
 method public <init> (IIILjava/lang/String;)V - -
 method public <init> (IIIIILjava/lang/String;)V - -
 method public getProxy ()Lcgu; - -
 method public id ()I - -
 method public active ()Z - -
 method public active (Z)V - -
 method public msg (Ljava/lang/String;)V - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public y ()I - -
 method public render (IIF)V - -
 method public blit (IIIIII)V - -
 method public renderBg (II)V - -
 method public getYImage (Z)I - -
 method public,abstract onClick (DD)V - -
 method public onRelease (DD)V - -
in 216
class net/minecraft/realms/RealmsButton 52 public,super,abstract net/minecraft/realms/AbstractRealmsButton - Lnet/minecraft/realms/AbstractRealmsButton<Lnet/minecraft/realms/RealmsButtonProxy;>;
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final WIDGETS_LOCATION Lnet/minecraft/resources/ResourceLocation; -
 method public <init> (IIILjava/lang/String;)V - -
 method public <init> (IIIIILjava/lang/String;)V - -
 method public getProxy ()Lnet/minecraft/realms/RealmsButtonProxy; - -
 method public id ()I - -
 method public setMessage (Ljava/lang/String;)V - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public y ()I - -
 method public x ()I - -
 method public renderBg (II)V - -
 method public getYImage (Z)I - -
 method public,abstract onPress ()V - -
 method public onRelease (DD)V - -
 method public renderButton (IIF)V - -
 method public drawCenteredString (Ljava/lang/String;III)V - -
in 59
class net/minecraft/realms/RealmsButtonProxy 52 public,super cgu - -
 method public <init> (Lnet/minecraft/realms/RealmsButton;IIILjava/lang/String;)V - -
 method public <init> (Lnet/minecraft/realms/RealmsButton;IIILjava/lang/String;II)V - -
 method public c ()I - -
 method public active ()Z - -
 method public active (Z)V - -
 method public a (Ljava/lang/String;)V - -
 method public getWidth ()I - -
 method public y ()I - -
 method public onClick (DD)V - -
 method public onRelease (DD)V - -
 method public a (Lnet/minecraft/client/Minecraft;II)V - -
 method public f ()Lnet/minecraft/realms/RealmsButton; - -
 method public a (Z)I - -
 method public getYImage (Z)I - -
 method public getHeight ()I - -
in 216
class net/minecraft/realms/RealmsButtonProxy 52 public,super net/minecraft/client/gui/components/Button net/minecraft/realms/RealmsAbstractButtonProxy Lnet/minecraft/client/gui/components/Button;Lnet/minecraft/realms/RealmsAbstractButtonProxy<Lnet/minecraft/realms/RealmsButton;>;
 inner net/minecraft/client/gui/components/Button$OnPress net/minecraft/client/gui/components/Button OnPress public,static,interface,abstract
 method public <init> (Lnet/minecraft/realms/RealmsButton;IILjava/lang/String;IILnet/minecraft/client/gui/components/Button$OnPress;)V - -
 method public active ()Z - -
 method public active (Z)V - -
 method public isVisible ()Z - -
 method public setVisible (Z)V - -
 method public setMessage (Ljava/lang/String;)V - -
 method public getWidth ()I - -
 method public y ()I - -
 method public onClick (DD)V - -
 method public onRelease (DD)V - -
 method public renderBg (Lnet/minecraft/client/Minecraft;II)V - -
 method public renderButton (IIF)V - -
 method public superRenderButton (IIF)V - -
 method public getButton ()Lnet/minecraft/realms/RealmsButton; - -
 method public getYImage (Z)I - -
 method public getSuperYImage (Z)I - -
 method public getHeight ()I - -
 method public isHovered ()Z - -
in 51
class net/minecraft/realms/RealmsClickableScrolledSelectionList 52 public,super,abstract net/minecraft/realms/RealmsGuiEventListener - -
 method public <init> (IIIII)V - -
 method public render (IIF)V - -
 method public width ()I - -
 method protected renderItem (IIIILnet/minecraft/realms/Tezzelator;II)V - -
 method public renderItem (IIIIII)V - -
 method public getItemCount ()I - -
 method public selectItem (IIDD)Z - -
 method public isSelectedItem (I)Z - -
 method public renderBackground ()V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method public scroll (I)V - -
 method public getScroll ()I - -
 method protected renderList (IIII)V - -
 method public itemClicked (IIDDI)V - -
 method public renderSelected (IIILnet/minecraft/realms/Tezzelator;)V - -
 method public setLeftPos (I)V - -
 method public y0 ()I - -
 method public y1 ()I - -
 method public headerHeight ()I - -
 method public yo ()D - -
 method public itemHeight ()I - -
 method public isVisible ()Z - -
in 216
class net/minecraft/realms/RealmsClickableScrolledSelectionListProxy 52 public,super net/minecraft/client/gui/components/ScrolledSelectionList - -
 method public <init> (Lnet/minecraft/realms/RealmsClickableScrolledSelectionList;IIIII)V - -
 method public getItemCount ()I - -
 method public selectItem (IIDD)Z - -
 method public isSelectedItem (I)Z - -
 method public renderBackground ()V - -
 method public renderItem (IIIIIIF)V - -
 method public getWidth ()I - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public itemClicked (IIIII)V - -
 method public mouseScrolled (DDD)Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public renderSelected (IIILnet/minecraft/realms/Tezzelator;)V - -
 method public renderList (IIIIF)V - -
 method public y0 ()I - -
 method public y1 ()I - -
 method public headerHeight ()I - -
 method public yo ()D - -
 method public itemHeight ()I - -
in 216
class net/minecraft/realms/RealmsConfirmResultListener 52 public,interface,abstract java/lang/Object - -
 method public,abstract confirmResult (ZI)V - -
in 51
class net/minecraft/realms/RealmsConnect 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public connect (Ljava/lang/String;I)V - -
 method public abort ()V - -
 method public tick ()V - -
in 86
class net/minecraft/realms/RealmsConnect 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public connect (Lcom/mojang/realmsclient/dto/RealmsServer;Ljava/lang/String;I)V - -
 method public abort ()V - -
 method public tick ()V - -
in 82
class net/minecraft/realms/RealmsConnect 60 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public connect (Lcom/mojang/realmsclient/dto/RealmsServer;Lnet/minecraft/client/multiplayer/resolver/ServerAddress;)V - -
 method public abort ()V - -
 method public tick ()V - -
in 701
class net/minecraft/realms/RealmsConnect 61 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public connect (Lcom/mojang/realmsclient/dto/RealmsServer;Lnet/minecraft/client/multiplayer/resolver/ServerAddress;)V - -
 method public abort ()V - -
 method public tick ()V - -
in 83
class net/minecraft/realms/RealmsConnect 61 public,super java/lang/Object - -
 inner net/minecraft/world/entity/player/ProfilePublicKey$Data net/minecraft/world/entity/player/ProfilePublicKey Data public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public connect (Lcom/mojang/realmsclient/dto/RealmsServer;Lnet/minecraft/client/multiplayer/resolver/ServerAddress;)V - -
 method public abort ()V - -
 method public tick ()V - -
in 60
class net/minecraft/realms/RealmsConnect 65 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;)V - -
 method public connect (Lcom/mojang/realmsclient/dto/RealmsServer;Lnet/minecraft/client/multiplayer/resolver/ServerAddress;)V - -
 method public abort ()V - -
 method public tick ()V - -
in 200
class net/minecraft/realms/RealmsDefaultVertexFormat 52 public,super java/lang/Object - -
 inner com/mojang/blaze3d/vertex/VertexFormatElement$Type com/mojang/blaze3d/vertex/VertexFormatElement Type public,static,final,enum
 inner com/mojang/blaze3d/vertex/VertexFormatElement$Usage com/mojang/blaze3d/vertex/VertexFormatElement Usage public,static,final,enum
 field public,static,final BLOCK Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final BLOCK_NORMALS Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final ENTITY Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final PARTICLE Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_COLOR Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_TEX Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_NORMAL Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_TEX_COLOR Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_TEX_NORMAL Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_TEX2_COLOR Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_TEX_COLOR_NORMAL Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final ELEMENT_POSITION Lnet/minecraft/realms/RealmsVertexFormatElement; -
 field public,static,final ELEMENT_COLOR Lnet/minecraft/realms/RealmsVertexFormatElement; -
 field public,static,final ELEMENT_UV0 Lnet/minecraft/realms/RealmsVertexFormatElement; -
 field public,static,final ELEMENT_UV1 Lnet/minecraft/realms/RealmsVertexFormatElement; -
 field public,static,final ELEMENT_NORMAL Lnet/minecraft/realms/RealmsVertexFormatElement; -
 field public,static,final ELEMENT_PADDING Lnet/minecraft/realms/RealmsVertexFormatElement; -
 method public <init> ()V - -
in 115
class net/minecraft/realms/RealmsDefaultVertexFormat 52 public,super java/lang/Object - -
 field public,static,final POSITION_COLOR Lnet/minecraft/realms/RealmsVertexFormat; -
 field public,static,final POSITION_TEX_COLOR Lnet/minecraft/realms/RealmsVertexFormat; -
 method public <init> ()V - -
in 59
class net/minecraft/realms/RealmsEditBox 52 public,super net/minecraft/realms/RealmsGuiEventListener - -
 method public <init> (IIIII)V - -
 method public getValue ()Ljava/lang/String; - -
 method public tick ()V - -
 method public setValue (Ljava/lang/String;)V - -
 method public charTyped (CI)Z - -
 method public getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method public keyPressed (III)Z - -
 method public isFocused ()Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseScrolled (D)Z - -
 method public render (IIF)V - -
 method public setMaxLength (I)V - -
 method public setIsEditable (Z)V - -
in 216
class net/minecraft/realms/RealmsEditBox 52 public,super net/minecraft/realms/RealmsGuiEventListener - -
 method public <init> (IIIIILjava/lang/String;)V - -
 method public getValue ()Ljava/lang/String; - -
 method public tick ()V - -
 method public setValue (Ljava/lang/String;)V - -
 method public charTyped (CI)Z - -
 method public getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method public keyPressed (III)Z - -
 method public isFocused ()Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseScrolled (DDD)Z - -
 method public render (IIF)V - -
 method public setMaxLength (I)V - -
 method public setIsEditable (Z)V - -
in 59
class net/minecraft/realms/RealmsGuiEventListener 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseScrolled (D)Z - -
 method public keyPressed (III)Z - -
 method public keyReleased (III)Z - -
 method public charTyped (CI)Z - -
 method public,abstract getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
in 216
class net/minecraft/realms/RealmsGuiEventListener 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseScrolled (DDD)Z - -
 method public keyPressed (III)Z - -
 method public keyReleased (III)Z - -
 method public charTyped (CI)Z - -
 method public,abstract getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
in 216
class net/minecraft/realms/RealmsLabel 52 public,super net/minecraft/realms/RealmsGuiEventListener - -
 method public <init> (Ljava/lang/String;III)V - -
 method public render (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method public getText ()Ljava/lang/String; - -
in 86
class net/minecraft/realms/RealmsLabel 52 public,super java/lang/Object net/minecraft/client/gui/components/events/GuiEventListener -
 method public <init> (Lnet/minecraft/network/chat/Component;III)V - -
 method public render (Lnet/minecraft/client/gui/screens/Screen;Lcom/mojang/blaze3d/vertex/PoseStack;)V - -
 method public getText ()Ljava/lang/String; - -
in 82
class net/minecraft/realms/RealmsLabel 60 public,super java/lang/Object net/minecraft/client/gui/components/Widget -
 method public <init> (Lnet/minecraft/network/chat/Component;III)V - -
 method public render (Lcom/mojang/blaze3d/vertex/PoseStack;IIF)V - -
 method public getText ()Lnet/minecraft/network/chat/Component; - -
in 34
class net/minecraft/realms/RealmsLabel 61 public,super java/lang/Object net/minecraft/client/gui/components/Widget -
 method public <init> (Lnet/minecraft/network/chat/Component;III)V - -
 method public render (Lcom/mojang/blaze3d/vertex/PoseStack;IIF)V - -
 method public getText ()Lnet/minecraft/network/chat/Component; - -
in 75
class net/minecraft/realms/RealmsLabel 61 public,super java/lang/Object net/minecraft/client/gui/components/Renderable -
 method public <init> (Lnet/minecraft/network/chat/Component;III)V - -
 method public render (Lcom/mojang/blaze3d/vertex/PoseStack;IIF)V - -
 method public getText ()Lnet/minecraft/network/chat/Component; - -
in 130
class net/minecraft/realms/RealmsLabel 61 public,super java/lang/Object net/minecraft/client/gui/components/Renderable -
 method public <init> (Lnet/minecraft/network/chat/Component;III)V - -
 method public render (Lnet/minecraft/client/gui/GuiGraphics;IIF)V - -
 method public getText ()Lnet/minecraft/network/chat/Component; - -
in 60
class net/minecraft/realms/RealmsLabel 65 public,super java/lang/Object net/minecraft/client/gui/components/Renderable -
 method public <init> (Lnet/minecraft/network/chat/Component;III)V - -
 method public render (Lnet/minecraft/client/gui/GuiGraphics;IIF)V - -
 method public getText ()Lnet/minecraft/network/chat/Component; - -
in 216
class net/minecraft/realms/RealmsLabelProxy 52 public,super java/lang/Object net/minecraft/client/gui/components/events/GuiEventListener -
 method public <init> (Lnet/minecraft/realms/RealmsLabel;)V - -
 method public getLabel ()Lnet/minecraft/realms/RealmsLabel; - -
in 51
class net/minecraft/realms/RealmsLevelSummary 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/realms/RealmsLevelSummary;>;
 method public <init> (Lnet/minecraft/world/level/storage/LevelSummary;)V - -
 method public getGameMode ()I - -
 method public getLevelId ()Ljava/lang/String; - -
 method public hasCheats ()Z - -
 method public isHardcore ()Z - -
 method public isRequiresConversion ()Z - -
 method public getLevelName ()Ljava/lang/String; - -
 method public getLastPlayed ()J - -
 method public compareTo (Lnet/minecraft/world/level/storage/LevelSummary;)I - -
 method public getSizeOnDisk ()J - -
 method public compareTo (Lnet/minecraft/realms/RealmsLevelSummary;)I - -
in 51
class net/minecraft/realms/RealmsMth 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static sin (F)F - -
 method public,static nextDouble (Ljava/util/Random;DD)D - -
 method public,static ceil (F)I - -
 method public,static floor (D)I - -
 method public,static intFloorDiv (II)I - -
 method public,static abs (F)F - -
 method public,static clamp (III)I - -
 method public,static clampedLerp (DDD)D - -
 method public,static ceil (D)I - -
 method public,static isEmpty (Ljava/lang/String;)Z - -
 method public,static lfloor (D)J - -
 method public,static sqrt (D)F - -
 method public,static clamp (DDD)D - -
 method public,static getInt (Ljava/lang/String;I)I - -
 method public,static getDouble (Ljava/lang/String;D)D - -
 method public,static log2 (I)I - -
 method public,static absFloor (D)I - -
 method public,static smallestEncompassingPowerOfTwo (I)I - -
 method public,static sqrt (F)F - -
 method public,static cos (F)F - -
 method public,static getInt (Ljava/lang/String;II)I - -
 method public,static fastFloor (D)I - -
 method public,static absMax (DD)D - -
 method public,static nextFloat (Ljava/util/Random;FF)F - -
 method public,static wrapDegrees (D)D - -
 method public,static wrapDegrees (F)F - -
 method public,static clamp (FFF)F - -
 method public,static getDouble (Ljava/lang/String;DD)D - -
 method public,static roundUp (II)I - -
 method public,static average ([J)D - -
 method public,static floor (F)I - -
 method public,static abs (I)I - -
 method public,static nextInt (Ljava/util/Random;II)I - -
in 216
class net/minecraft/realms/RealmsObjectSelectionList 52 public,super,abstract net/minecraft/realms/RealmsGuiEventListener - <E:Lnet/minecraft/realms/RealmListEntry;>Lnet/minecraft/realms/RealmsGuiEventListener;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry public,static,abstract
 method public <init> (IIIII)V - -
 method public render (IIF)V - -
 method public addEntry (Lnet/minecraft/realms/RealmListEntry;)V (TE;)V -
 method public remove (I)V - -
 method public clear ()V - -
 method public removeEntry (Lnet/minecraft/realms/RealmListEntry;)Z (TE;)Z -
 method public width ()I - -
 method protected renderItem (IIIILnet/minecraft/realms/Tezzelator;II)V - -
 method public setLeftPos (I)V - -
 method public renderItem (IIIIII)V - -
 method public setSelected (I)V - -
 method public itemClicked (IIDDI)V - -
 method public getItemCount ()I - -
 method public renderBackground ()V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public y0 ()I - -
 method public y1 ()I - -
 method public headerHeight ()I - -
 method public itemHeight ()I - -
 method public scroll (I)V - -
 method public getScroll ()I - -
 method public getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method public getRowWidth ()I - -
 method public,abstract isFocused ()Z - -
 method public selectItem (I)V - -
 method public getSelected ()Lnet/minecraft/realms/RealmListEntry; ()TE; -
 method public children ()Ljava/util/List; ()Ljava/util/List<TE;>; -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
in 86
class net/minecraft/realms/RealmsObjectSelectionList 52 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry public,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public itemClicked (IIDDI)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 104
class net/minecraft/realms/RealmsObjectSelectionList 60 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry public,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public itemClicked (IIDDI)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 331
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry public,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public itemClicked (IIDDI)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 263
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry protected,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public itemClicked (IIDDII)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 310
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry protected,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 311
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry protected,static,abstract
 method protected <init> (IIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 94
class net/minecraft/realms/RealmsObjectSelectionList 65 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry protected,static,abstract
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 method protected <init> (IIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public getMaxPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 108
class net/minecraft/realms/RealmsObjectSelectionList 60 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public itemClicked (IIDDI)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 332
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public itemClicked (IIDDI)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 322
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry protected,static,abstract
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public itemClicked (IIDDII)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 315
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry protected,static,abstract
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 method protected <init> (IIIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 316
class net/minecraft/realms/RealmsObjectSelectionList 61 public,super,abstract net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry protected,static,abstract
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 method protected <init> (IIII)V - -
 method public setSelectedItem (I)V - -
 method public selectItem (I)V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getRowWidth ()I - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getItemCount ()I - -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
 method public addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public clear ()V - -
in 216
class net/minecraft/realms/RealmsObjectSelectionListProxy 52 public,super net/minecraft/client/gui/components/ObjectSelectionList - <E:Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry<TE;>;>Lnet/minecraft/client/gui/components/ObjectSelectionList<TE;>;
 inner net/minecraft/client/gui/components/ObjectSelectionList$Entry net/minecraft/client/gui/components/ObjectSelectionList Entry public,static,abstract
 inner net/minecraft/client/gui/components/AbstractSelectionList$Entry net/minecraft/client/gui/components/AbstractSelectionList Entry public,static,abstract
 method public <init> (Lnet/minecraft/realms/RealmsObjectSelectionList;IIIII)V - -
 method public getItemCount ()I - -
 method public clear ()V - -
 method public isFocused ()Z - -
 method protected setSelectedItem (I)V - -
 method public setSelected (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)V (TE;)V -
 method public renderBackground ()V - -
 method public getWidth ()I - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public mouseScrolled (DDD)Z - -
 method public getRowWidth ()I - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method protected,final addEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)I (TE;)I -
 method public remove (I)Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry; (I)TE; -
 method public removeEntry (Lnet/minecraft/client/gui/components/ObjectSelectionList$Entry;)Z (TE;)Z -
 method public setScrollAmount (D)V - -
 method public y0 ()I - -
 method public y1 ()I - -
 method public headerHeight ()I - -
 method public itemHeight ()I - -
 method public keyPressed (III)Z - -
 method public replaceEntries (Ljava/util/Collection;)V (Ljava/util/Collection<TE;>;)V -
 method public getRowTop (I)I - -
 method public getRowLeft ()I - -
in 59
class net/minecraft/realms/RealmsScreen 52 public,super,abstract net/minecraft/realms/RealmsGuiEventListener - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SKIN_HEAD_U I - I8
 field public,static,final SKIN_HEAD_V I - I8
 field public,static,final SKIN_HEAD_WIDTH I - I8
 field public,static,final SKIN_HEAD_HEIGHT I - I8
 field public,static,final SKIN_HAT_U I - I40
 field public,static,final SKIN_HAT_V I - I8
 field public,static,final SKIN_HAT_WIDTH I - I8
 field public,static,final SKIN_HAT_HEIGHT I - I8
 field public,static,final SKIN_TEX_WIDTH I - I64
 field public,static,final SKIN_TEX_HEIGHT I - I64
 field public width I -
 field public height I -
 method public <init> ()V - -
 method public getProxy ()Lciz; - -
 method public init ()V - -
 method public init (Lnet/minecraft/client/Minecraft;II)V - -
 method public drawCenteredString (Ljava/lang/String;III)V - -
 method public draw (Ljava/lang/String;IIIZ)I - -
 method public drawString (Ljava/lang/String;III)V - -
 method public drawString (Ljava/lang/String;IIIZ)V - -
 method public blit (IIIIII)V - -
 method public,static blit (IIFFIIIIFF)V - -
 method public,static blit (IIFFIIFF)V - -
 method public fillGradient (IIIIII)V - -
 method public renderBackground ()V - -
 method public isPauseScreen ()Z - -
 method public renderBackground (I)V - -
 method public render (IIF)V - -
 method public renderTooltip (Lnet/minecraft/world/item/ItemStack;II)V - -
 method public renderTooltip (Ljava/lang/String;II)V - -
 method public renderTooltip (Ljava/util/List;II)V (Ljava/util/List<Ljava/lang/String;>;II)V -
 method public,static bindFace (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,static bind (Ljava/lang/String;)V - -
 method public tick ()V - -
 method public width ()I - -
 method public height ()I - -
 method public threadSafeSetScreen (Lnet/minecraft/realms/RealmsScreen;)Lcom/google/common/util/concurrent/ListenableFuture; (Lnet/minecraft/realms/RealmsScreen;)Lcom/google/common/util/concurrent/ListenableFuture<Ljava/lang/Object;>; -
 method public fontLineHeight ()I - -
 method public fontWidth (Ljava/lang/String;)I - -
 method public fontDrawShadow (Ljava/lang/String;III)V - -
 method public fontSplit (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Ljava/lang/String;>; -
 method public childrenClear ()V - -
 method public addWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public removeWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public hasWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)Z - -
 method public buttonsAdd (Lnet/minecraft/realms/RealmsButton;)V - -
 method public buttons ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/RealmsButton;>; -
 method protected buttonsClear ()V - -
 method protected focusOn (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public focusNext ()V - -
 method public newEditBox (IIIII)Lnet/minecraft/realms/RealmsEditBox; - -
 method public confirmResult (ZI)V - -
 method public,static getLocalizedString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static,varargs getLocalizedString (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public getLocalizedStringWithLineWidth (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Ljava/lang/String;>; -
 method public getLevelStorageSource ()Lnet/minecraft/realms/RealmsAnvilLevelStorageSource; - -
 method public removed ()V - -
 method protected removeButton (Lnet/minecraft/realms/RealmsButton;)V - -
 method protected setKeyboardHandlerSendRepeatsToGui (Z)V - -
 method protected isKeyDown (I)Z - -
in 216
class net/minecraft/realms/RealmsScreen 52 public,super,abstract net/minecraft/realms/RealmsGuiEventListener net/minecraft/realms/RealmsConfirmResultListener -
 field public,static,final SKIN_HEAD_U I - I8
 field public,static,final SKIN_HEAD_V I - I8
 field public,static,final SKIN_HEAD_WIDTH I - I8
 field public,static,final SKIN_HEAD_HEIGHT I - I8
 field public,static,final SKIN_HAT_U I - I40
 field public,static,final SKIN_HAT_V I - I8
 field public,static,final SKIN_HAT_WIDTH I - I8
 field public,static,final SKIN_HAT_HEIGHT I - I8
 field public,static,final SKIN_TEX_WIDTH I - I64
 field public,static,final SKIN_TEX_HEIGHT I - I64
 field public width I -
 field public height I -
 method public <init> ()V - -
 method public getProxy ()Lnet/minecraft/realms/RealmsScreenProxy; - -
 method public init ()V - -
 method public init (Lnet/minecraft/client/Minecraft;II)V - -
 method public drawCenteredString (Ljava/lang/String;III)V - -
 method public draw (Ljava/lang/String;IIIZ)I - -
 method public drawString (Ljava/lang/String;III)V - -
 method public drawString (Ljava/lang/String;IIIZ)V - -
 method public blit (IIIIII)V - -
 method public,static blit (IIFFIIIIII)V - -
 method public,static blit (IIFFIIII)V - -
 method public fillGradient (IIIIII)V - -
 method public renderBackground ()V - -
 method public isPauseScreen ()Z - -
 method public renderBackground (I)V - -
 method public render (IIF)V - -
 method public renderTooltip (Lnet/minecraft/world/item/ItemStack;II)V - -
 method public renderTooltip (Ljava/lang/String;II)V - -
 method public renderTooltip (Ljava/util/List;II)V (Ljava/util/List<Ljava/lang/String;>;II)V -
 method public,static bind (Ljava/lang/String;)V - -
 method public tick ()V - -
 method protected tickButtons ()V - -
 method public width ()I - -
 method public height ()I - -
 method public fontLineHeight ()I - -
 method public fontWidth (Ljava/lang/String;)I - -
 method public fontDrawShadow (Ljava/lang/String;III)V - -
 method public fontSplit (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Ljava/lang/String;>; -
 method public childrenClear ()V - -
 method public addWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public removeWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public hasWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)Z - -
 method public buttonsAdd (Lnet/minecraft/realms/AbstractRealmsButton;)V (Lnet/minecraft/realms/AbstractRealmsButton<*>;)V -
 method public buttons ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/AbstractRealmsButton<*>;>; -
 method protected buttonsClear ()V - -
 method protected focusOn (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public newEditBox (IIIII)Lnet/minecraft/realms/RealmsEditBox; - -
 method public newEditBox (IIIIILjava/lang/String;)Lnet/minecraft/realms/RealmsEditBox; - -
 method public confirmResult (ZI)V - -
 method public,static getLocalizedString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static,varargs getLocalizedString (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public getLocalizedStringWithLineWidth (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Ljava/lang/String;>; -
 method public getLevelStorageSource ()Lnet/minecraft/realms/RealmsAnvilLevelStorageSource; - -
 method public removed ()V - -
 method protected removeButton (Lnet/minecraft/realms/RealmsButton;)V - -
 method protected setKeyboardHandlerSendRepeatsToGui (Z)V - -
 method protected isKeyDown (I)Z - -
 method protected narrateLabels ()V - -
 method public isFocused (Lnet/minecraft/realms/RealmsGuiEventListener;)Z - -
in 86
class net/minecraft/realms/RealmsScreen 52 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method protected,static row (I)I - -
 method public tick ()V - -
 method public narrateLabels ()V - -
in 82
class net/minecraft/realms/RealmsScreen 60 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final COMPONENT_HEIGHT I - I20
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field public,static,final COLOR_WHITE I - I16777215
 field public,static,final COLOR_GRAY I - I10526880
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_DARK_GREEN I - I6077788
 field protected,static,final COLOR_RED I - I16711680
 field protected,static,final COLOR_RED_FADE I - I15553363
 field protected,static,final COLOR_BLACK I - I-1073741824
 field protected,static,final COLOR_YELLOW I - I13413468
 field protected,static,final COLOR_BRIGHT_YELLOW I - I-256
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final COLOR_INFO I - I8226750
 field protected,static,final COLOR_BUTTON_YELLOW I - I16777120
 field protected,static,final UPDATE_BREAKS_ADVENTURE_URL Ljava/lang/String; - "https://www.minecraft.net/realms/adventure-maps-in-1-9"
 field protected,static,final SKIN_HEAD_U I - I8
 field protected,static,final SKIN_HEAD_V I - I8
 field protected,static,final SKIN_HEAD_WIDTH I - I8
 field protected,static,final SKIN_HEAD_HEIGHT I - I8
 field protected,static,final SKIN_HAT_U I - I40
 field protected,static,final SKIN_HAT_V I - I8
 field protected,static,final SKIN_HAT_WIDTH I - I8
 field protected,static,final SKIN_HAT_HEIGHT I - I8
 field protected,static,final SKIN_TEX_WIDTH I - I64
 field protected,static,final SKIN_TEX_HEIGHT I - I64
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 84
class net/minecraft/realms/RealmsScreen 61 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final COMPONENT_HEIGHT I - I20
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field public,static,final COLOR_WHITE I - I16777215
 field public,static,final COLOR_GRAY I - I10526880
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_DARK_GREEN I - I6077788
 field protected,static,final COLOR_RED I - I16711680
 field protected,static,final COLOR_RED_FADE I - I15553363
 field protected,static,final COLOR_BLACK I - I-1073741824
 field protected,static,final COLOR_YELLOW I - I13413468
 field protected,static,final COLOR_BRIGHT_YELLOW I - I-256
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final COLOR_INFO I - I8226750
 field protected,static,final COLOR_BUTTON_YELLOW I - I16777120
 field protected,static,final UPDATE_BREAKS_ADVENTURE_URL Ljava/lang/String; - "https://www.minecraft.net/realms/adventure-maps-in-1-9"
 field protected,static,final SKIN_HEAD_U I - I8
 field protected,static,final SKIN_HEAD_V I - I8
 field protected,static,final SKIN_HEAD_WIDTH I - I8
 field protected,static,final SKIN_HEAD_HEIGHT I - I8
 field protected,static,final SKIN_HAT_U I - I40
 field protected,static,final SKIN_HAT_V I - I8
 field protected,static,final SKIN_HAT_WIDTH I - I8
 field protected,static,final SKIN_HAT_HEIGHT I - I8
 field protected,static,final SKIN_TEX_WIDTH I - I64
 field protected,static,final SKIN_TEX_HEIGHT I - I64
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 340
class net/minecraft/realms/RealmsScreen 61 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final COMPONENT_HEIGHT I - I20
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field public,static,final COLOR_WHITE I - I16777215
 field public,static,final COLOR_GRAY I - I10526880
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_DARK_GREEN I - I6077788
 field protected,static,final COLOR_RED I - I16711680
 field protected,static,final COLOR_RED_FADE I - I15553363
 field protected,static,final COLOR_BLACK I - I-1073741824
 field protected,static,final COLOR_YELLOW I - I13413468
 field protected,static,final COLOR_BRIGHT_YELLOW I - I-256
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final COLOR_INFO I - I8226750
 field protected,static,final COLOR_BUTTON_YELLOW I - I16777120
 field protected,static,final UPDATE_BREAKS_ADVENTURE_URL Ljava/lang/String; - "https://www.minecraft.net/realms/adventure-maps-in-1-9"
 field protected,static,final SKIN_FACE_SIZE I - I8
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 72
class net/minecraft/realms/RealmsScreen 61 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_RED_FADE I - I15553363
 field protected,static,final COLOR_YELLOW I - I13413468
 field protected,static,final COLOR_BRIGHT_YELLOW I - I-256
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final COLOR_INFO I - I8226750
 field protected,static,final SKIN_FACE_SIZE I - I8
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 116
class net/minecraft/realms/RealmsScreen 61 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final COLOR_INFO I - I8226750
 field protected,static,final SKIN_FACE_SIZE I - I8
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 224
class net/minecraft/realms/RealmsScreen 65 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final COLOR_INFO I - I8226750
 field protected,static,final SKIN_FACE_SIZE I - I32
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 235
class net/minecraft/realms/RealmsScreen 65 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final SKIN_FACE_SIZE I - I32
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 118
class net/minecraft/realms/RealmsScreen 65 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field protected,static,final COLOR_DARK_GRAY I - I5000268
 field protected,static,final COLOR_MEDIUM_GRAY I - I7105644
 field protected,static,final COLOR_GREEN I - I8388479
 field protected,static,final COLOR_LINK I - I3368635
 field protected,static,final COLOR_LINK_HOVER I - I7107012
 field protected,static,final SKIN_FACE_SIZE I - I32
 field protected,static,final HARDCORE_HEART_SIZE I - I8
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
in 125
class net/minecraft/realms/RealmsScreen 65 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field protected,static,final COLOR_DARK_GRAY I - I-11776948
 field protected,static,final COLOR_MEDIUM_GRAY I - I-9671572
 field protected,static,final COLOR_GREEN I - I-8388737
 field protected,static,final COLOR_LINK I - I-13408581
 field protected,static,final COLOR_LINK_HOVER I - I-9670204
 field protected,static,final SKIN_FACE_SIZE I - I32
 field protected,static,final HARDCORE_HEART_SIZE I - I8
 field protected,static,final LOGO_LOCATION Lnet/minecraft/resources/ResourceLocation; -
 field protected,static,final LOGO_WIDTH I - I128
 field protected,static,final LOGO_HEIGHT I - I34
 field protected,static,final LOGO_TEXTURE_WIDTH I - I128
 field protected,static,final LOGO_TEXTURE_HEIGHT I - I64
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
 method protected,static realmsLogo ()Lnet/minecraft/client/gui/components/ImageWidget; - -
in 2
class net/minecraft/realms/RealmsScreen 65 public,super,abstract net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final TITLE_HEIGHT I - I17
 field protected,static,final EXPIRATION_NOTIFICATION_DAYS I - I7
 field protected,static,final SIZE_LIMIT J - J5368709120
 field protected,static,final COLOR_DARK_GRAY I - I-11776948
 field protected,static,final COLOR_MEDIUM_GRAY I - I-9671572
 field protected,static,final COLOR_GREEN I - I-8388737
 field protected,static,final COLOR_LINK I - I-13408581
 field protected,static,final COLOR_LINK_HOVER I - I-9670204
 field protected,static,final SKIN_FACE_SIZE I - I32
 field protected,static,final HARDCORE_HEART_SIZE I - I8
 field protected,static,final LOGO_LOCATION Lnet/minecraft/resources/Identifier; -
 field protected,static,final LOGO_WIDTH I - I128
 field protected,static,final LOGO_HEIGHT I - I34
 field protected,static,final LOGO_TEXTURE_WIDTH I - I128
 field protected,static,final LOGO_TEXTURE_HEIGHT I - I64
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method protected,static row (I)I - -
 method protected addLabel (Lnet/minecraft/realms/RealmsLabel;)Lnet/minecraft/realms/RealmsLabel; - -
 method public createLabelNarration ()Lnet/minecraft/network/chat/Component; - -
 method protected,static realmsLogo ()Lnet/minecraft/client/gui/components/ImageWidget; - -
in 216
class net/minecraft/realms/RealmsScreenProxy 52 public,super net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public getScreen ()Lnet/minecraft/realms/RealmsScreen; - -
 method public init (Lnet/minecraft/client/Minecraft;II)V - -
 method public init ()V - -
 method public drawCenteredString (Ljava/lang/String;III)V - -
 method public drawString (Ljava/lang/String;IIIZ)V - -
 method public blit (IIIIII)V - -
 method public,static blit (IIFFIIIIII)V - -
 method public,static blit (IIFFIIII)V - -
 method public fillGradient (IIIIII)V - -
 method public renderBackground ()V - -
 method public isPauseScreen ()Z - -
 method public renderBackground (I)V - -
 method public render (IIF)V - -
 method public renderTooltip (Lnet/minecraft/world/item/ItemStack;II)V - -
 method public renderTooltip (Ljava/lang/String;II)V - -
 method public renderTooltip (Ljava/util/List;II)V (Ljava/util/List<Ljava/lang/String;>;II)V -
 method public tick ()V - -
 method public width ()I - -
 method public height ()I - -
 method public fontLineHeight ()I - -
 method public fontWidth (Ljava/lang/String;)I - -
 method public fontDrawShadow (Ljava/lang/String;III)V - -
 method public fontSplit (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Ljava/lang/String;>; -
 method public childrenClear ()V - -
 method public addWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public narrateLabels ()V - -
 method public removeWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public hasWidget (Lnet/minecraft/realms/RealmsGuiEventListener;)Z - -
 method public buttonsAdd (Lnet/minecraft/realms/AbstractRealmsButton;)V (Lnet/minecraft/realms/AbstractRealmsButton<*>;)V -
 method public buttons ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/AbstractRealmsButton<*>;>; -
 method public buttonsClear ()V - -
 method public removeButton (Lnet/minecraft/realms/RealmsButton;)V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public keyPressed (III)Z - -
 method public charTyped (CI)Z - -
 method public removed ()V - -
 method public draw (Ljava/lang/String;IIIZ)I - -
 method public getFont ()Lnet/minecraft/client/gui/Font; - -
in 51
class net/minecraft/realms/RealmsScrolledSelectionList 52 public,super,abstract net/minecraft/realms/RealmsGuiEventListener - -
 method public <init> (IIIII)V - -
 method public render (IIF)V - -
 method public width ()I - -
 method protected renderItem (IIIILnet/minecraft/realms/Tezzelator;II)V - -
 method public renderItem (IIIIII)V - -
 method public getItemCount ()I - -
 method public selectItem (IIDD)Z - -
 method public isSelectedItem (I)Z - -
 method public renderBackground ()V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public scroll (I)V - -
 method public getScroll ()I - -
 method protected renderList (IIII)V - -
 method public getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
in 216
class net/minecraft/realms/RealmsScrolledSelectionListProxy 52 public,super net/minecraft/client/gui/components/ScrolledSelectionList - -
 method public <init> (Lnet/minecraft/realms/RealmsScrolledSelectionList;IIIII)V - -
 method public getItemCount ()I - -
 method public selectItem (IIDD)Z - -
 method public isSelectedItem (I)Z - -
 method public renderBackground ()V - -
 method public renderItem (IIIIIIF)V - -
 method public getWidth ()I - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public mouseScrolled (DDD)Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
in 126
class net/minecraft/realms/RealmsServerAddress 52 public,super java/lang/Object - -
 method protected <init> (Ljava/lang/String;I)V - -
 method public getHost ()Ljava/lang/String; - -
 method public getPort ()I - -
 method public,static parseString (Ljava/lang/String;)Lnet/minecraft/realms/RealmsServerAddress; - -
in 59
class net/minecraft/realms/RealmsSharedConstants 52 public,super java/lang/Object - -
 field public,static,final NETWORK_PROTOCOL_VERSION I - I404
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final VERSION_STRING Ljava/lang/String; - "1.13.2"
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public <init> ()V - -
in 216
class net/minecraft/realms/RealmsSharedConstants 52 public,super java/lang/Object - -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public <init> ()V - -
in 51
class net/minecraft/realms/RealmsSimpleScrolledSelectionList 52 public,super,abstract net/minecraft/realms/RealmsGuiEventListener - -
 method public <init> (IIIII)V - -
 method public render (IIF)V - -
 method public width ()I - -
 method protected renderItem (IIIILnet/minecraft/realms/Tezzelator;II)V - -
 method public renderItem (IIIIII)V - -
 method public getItemCount ()I - -
 method public selectItem (IIDD)Z - -
 method public isSelectedItem (I)Z - -
 method public renderBackground ()V - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public getProxy ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method public scroll (I)V - -
 method public getScroll ()I - -
 method protected renderList (IIII)V - -
in 216
class net/minecraft/realms/RealmsSimpleScrolledSelectionListProxy 52 public,super net/minecraft/client/gui/components/ScrolledSelectionList - -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$DestFactor com/mojang/blaze3d/platform/GlStateManager DestFactor public,static,final,enum
 method public <init> (Lnet/minecraft/realms/RealmsSimpleScrolledSelectionList;IIIII)V - -
 method public getItemCount ()I - -
 method public selectItem (IIDD)Z - -
 method public isSelectedItem (I)Z - -
 method public renderBackground ()V - -
 method public renderItem (IIIIIIF)V - -
 method public getWidth ()I - -
 method public getMaxPosition ()I - -
 method public getScrollbarPosition ()I - -
 method public render (IIF)V - -
 method public mouseScrolled (DDD)Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
in 59
class net/minecraft/realms/RealmsSliderButton 52 public,super,abstract net/minecraft/realms/RealmsButton - -
 field public value D -
 field public sliding Z -
 method public <init> (IIIIII)V - -
 method public <init> (IIIIIIDD)V - -
 method public getMessage ()Ljava/lang/String; - -
 method public toPct (D)D - -
 method public toValue (D)D - -
 method public clamp (D)D - -
 method protected clampSteps (D)D - -
 method public getYImage (Z)I - -
 method public renderBg (II)V - -
 method public onClick (DD)V - -
 method public clicked (D)V - -
 method public onRelease (DD)V - -
in 216
class net/minecraft/realms/RealmsSliderButton 52 public,super,abstract net/minecraft/realms/AbstractRealmsButton - Lnet/minecraft/realms/AbstractRealmsButton<Lnet/minecraft/realms/RealmsSliderButtonProxy;>;
 field protected,static,final WIDGETS_LOCATION Lnet/minecraft/resources/ResourceLocation; -
 method public <init> (IIIIIDD)V - -
 method public getMessage ()Ljava/lang/String; - -
 method public toPct (D)D - -
 method public toValue (D)D - -
 method public clamp (D)D - -
 method public getYImage (Z)I - -
 method public onClick (DD)V - -
 method public onRelease (DD)V - -
 method public getProxy ()Lnet/minecraft/realms/RealmsSliderButtonProxy; - -
 method public getValue ()D - -
 method public setValue (D)V - -
 method public id ()I - -
 method public setMessage (Ljava/lang/String;)V - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public y ()I - -
 method public,abstract applyValue ()V - -
 method public updateMessage ()V - -
in 216
class net/minecraft/realms/RealmsSliderButtonProxy 52 public,super net/minecraft/client/gui/components/AbstractSliderButton net/minecraft/realms/RealmsAbstractButtonProxy Lnet/minecraft/client/gui/components/AbstractSliderButton;Lnet/minecraft/realms/RealmsAbstractButtonProxy<Lnet/minecraft/realms/RealmsSliderButton;>;
 method public <init> (Lnet/minecraft/realms/RealmsSliderButton;IIIID)V - -
 method public active ()Z - -
 method public active (Z)V - -
 method public isVisible ()Z - -
 method public setVisible (Z)V - -
 method public setMessage (Ljava/lang/String;)V - -
 method public getWidth ()I - -
 method public y ()I - -
 method public onClick (DD)V - -
 method public onRelease (DD)V - -
 method public updateMessage ()V - -
 method public applyValue ()V - -
 method public getValue ()D - -
 method public setValue (D)V - -
 method public renderBg (Lnet/minecraft/client/Minecraft;II)V - -
 method public getButton ()Lnet/minecraft/realms/RealmsSliderButton; - -
 method public getYImage (Z)I - -
 method public getSuperYImage (Z)I - -
 method public getHeight ()I - -
in 200
class net/minecraft/realms/RealmsVertexFormat 52 public,super java/lang/Object - -
 method public <init> (Lcom/mojang/blaze3d/vertex/VertexFormat;)V - -
 method public from (Lcom/mojang/blaze3d/vertex/VertexFormat;)Lnet/minecraft/realms/RealmsVertexFormat; - -
 method public getVertexFormat ()Lcom/mojang/blaze3d/vertex/VertexFormat; - -
 method public clear ()V - -
 method public getUvOffset (I)I - -
 method public getElementCount ()I - -
 method public hasColor ()Z - -
 method public hasUv (I)Z - -
 method public getElement (I)Lnet/minecraft/realms/RealmsVertexFormatElement; - -
 method public addElement (Lnet/minecraft/realms/RealmsVertexFormatElement;)Lnet/minecraft/realms/RealmsVertexFormat; - -
 method public getColorOffset ()I - -
 method public getElements ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/RealmsVertexFormatElement;>; -
 method public hasNormal ()Z - -
 method public getVertexSize ()I - -
 method public getOffset (I)I - -
 method public getNormalOffset ()I - -
 method public getIntegerSize ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 115
class net/minecraft/realms/RealmsVertexFormat 52 public,super java/lang/Object - -
 method public <init> (Lcom/mojang/blaze3d/vertex/VertexFormat;)V - -
 method public getVertexFormat ()Lcom/mojang/blaze3d/vertex/VertexFormat; - -
 method public getElements ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/RealmsVertexFormatElement;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 51
class net/minecraft/realms/RealmsVertexFormatElement 52 public,super java/lang/Object - -
 method public <init> (Lcom/mojang/blaze3d/vertex/VertexFormatElement;)V - -
 method public getVertexFormatElement ()Lcom/mojang/blaze3d/vertex/VertexFormatElement; - -
 method public isPosition ()Z - -
 method public getIndex ()I - -
 method public getByteSize ()I - -
 method public getCount ()I - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 114
class net/minecraft/realms/RepeatedNarrator 52 super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Ljava/lang/String;)V - -
in 175
class net/minecraft/realms/RepeatedNarrator 52 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Ljava/lang/String;)V - -
in 104
class net/minecraft/realms/RepeatedNarrator 60 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/network/chat/Component;)V - -
in 105
class net/minecraft/realms/RepeatedNarrator 61 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/network/chat/Component;)V - -
in 106
class net/minecraft/realms/RepeatedNarrator 61 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/client/GameNarrator;Lnet/minecraft/network/chat/Component;)V - -
in 107
class net/minecraft/realms/RepeatedNarrator 65 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/client/GameNarrator;Lnet/minecraft/network/chat/Component;)V - -
in 108
class net/minecraft/realms/RepeatedNarrator 60 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/network/chat/Component;)V - -
in 109
class net/minecraft/realms/RepeatedNarrator 61 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/network/chat/Component;)V - -
in 110
class net/minecraft/realms/RepeatedNarrator 61 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/client/GameNarrator;Lnet/minecraft/network/chat/Component;)V - -
in 111
class net/minecraft/realms/RepeatedNarrator 65 public,super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/time/Duration;)V - -
 method public narrate (Lnet/minecraft/client/GameNarrator;Lnet/minecraft/network/chat/Component;)V - -
in 92
class net/minecraft/realms/RepeatedNarrator$Params 52 super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
in 82
class net/minecraft/realms/RepeatedNarrator$Params 60 super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
in 93
class net/minecraft/realms/RepeatedNarrator$Params 61 super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
in 60
class net/minecraft/realms/RepeatedNarrator$Params 65 super java/lang/Object - -
 inner net/minecraft/realms/RepeatedNarrator$Params net/minecraft/realms/RepeatedNarrator Params static
in 59
class net/minecraft/realms/Tezzelator 52 public,super java/lang/Object - -
 field public,static t Lcom/mojang/blaze3d/vertex/Tesselator; -
 field public,static,final instance Lnet/minecraft/realms/Tezzelator; -
 method public <init> ()V - -
 method public end ()V - -
 method public vertex (DDD)Lnet/minecraft/realms/Tezzelator; - -
 method public color (FFFF)V - -
 method public tex2 (SS)V - -
 method public normal (FFF)V - -
 method public begin (ILnet/minecraft/realms/RealmsVertexFormat;)V - -
 method public endVertex ()V - -
 method public offset (DDD)V - -
 method public color (IIII)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public tex (DD)Lnet/minecraft/realms/Tezzelator; - -
in 114
class net/minecraft/realms/Tezzelator 52 public,super java/lang/Object - -
 field public,static,final t Lcom/mojang/blaze3d/vertex/Tesselator; -
 field public,static,final instance Lnet/minecraft/realms/Tezzelator; -
 method public <init> ()V - -
 method public end ()V - -
 method public vertex (DDD)Lnet/minecraft/realms/Tezzelator; - -
 method public color (FFFF)V - -
 method public tex2 (SS)V - -
 method public normal (FFF)V - -
 method public begin (ILnet/minecraft/realms/RealmsVertexFormat;)V - -
 method public endVertex ()V - -
 method public offset (DDD)V - -
 method public color (IIII)Lnet/minecraft/realms/RealmsBufferBuilder; - -
 method public tex (DD)Lnet/minecraft/realms/Tezzelator; - -
in 115
class net/minecraft/realms/Tezzelator 52 public,super java/lang/Object - -
 field public,static,final t Lcom/mojang/blaze3d/vertex/Tesselator; -
 field public,static,final instance Lnet/minecraft/realms/Tezzelator; -
 method public <init> ()V - -
 method public end ()V - -
 method public vertex (DDD)Lnet/minecraft/realms/Tezzelator; - -
 method public begin (ILnet/minecraft/realms/RealmsVertexFormat;)V - -
 method public endVertex ()V - -
 method public color (IIII)Lnet/minecraft/realms/Tezzelator; - -
 method public tex (FF)Lnet/minecraft/realms/Tezzelator; - -
in 216
class net/minecraft/realms/pluginapi/LoadedRealmsPlugin 52 public,interface,abstract java/lang/Object - -
 method public,abstract getMainScreen (Lnet/minecraft/realms/RealmsScreen;)Lnet/minecraft/realms/RealmsScreen; - -
 method public,abstract getNotificationsScreen (Lnet/minecraft/realms/RealmsScreen;)Lnet/minecraft/realms/RealmsScreen; - -
in 216
class net/minecraft/realms/pluginapi/RealmsPlugin 52 public,interface,abstract java/lang/Object - -
 method public,abstract tryLoad (Ljava/lang/String;)Lcom/mojang/datafixers/util/Either; (Ljava/lang/String;)Lcom/mojang/datafixers/util/Either<Lnet/minecraft/realms/pluginapi/LoadedRealmsPlugin;Ljava/lang/String;>; -
