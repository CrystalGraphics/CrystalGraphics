cg-stub-db 1
in 53
class org/abego/treelayout/Configuration 49 public,interface,abstract java/lang/Object - <TreeNode:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/abego/treelayout/Configuration$AlignmentInLevel org/abego/treelayout/Configuration AlignmentInLevel public,static,final,enum
 inner org/abego/treelayout/Configuration$Location org/abego/treelayout/Configuration Location public,static,final,enum
 method public,abstract getRootLocation ()Lorg/abego/treelayout/Configuration$Location; - -
 method public,abstract getAlignmentInLevel ()Lorg/abego/treelayout/Configuration$AlignmentInLevel; - -
 method public,abstract getGapBetweenLevels (I)D - -
 method public,abstract getGapBetweenNodes (Ljava/lang/Object;Ljava/lang/Object;)D (TTreeNode;TTreeNode;)D -
in 53
class org/abego/treelayout/Configuration$AlignmentInLevel 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/abego/treelayout/Configuration$AlignmentInLevel;>;
 inner org/abego/treelayout/Configuration$AlignmentInLevel org/abego/treelayout/Configuration AlignmentInLevel public,static,final,enum
 field public,static,final,enum Center Lorg/abego/treelayout/Configuration$AlignmentInLevel; -
 field public,static,final,enum TowardsRoot Lorg/abego/treelayout/Configuration$AlignmentInLevel; -
 field public,static,final,enum AwayFromRoot Lorg/abego/treelayout/Configuration$AlignmentInLevel; -
 method public,static values ()[Lorg/abego/treelayout/Configuration$AlignmentInLevel; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/abego/treelayout/Configuration$AlignmentInLevel; - -
in 53
class org/abego/treelayout/Configuration$Location 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lorg/abego/treelayout/Configuration$Location;>;
 inner org/abego/treelayout/Configuration$Location org/abego/treelayout/Configuration Location public,static,final,enum
 field public,static,final,enum Top Lorg/abego/treelayout/Configuration$Location; -
 field public,static,final,enum Left Lorg/abego/treelayout/Configuration$Location; -
 field public,static,final,enum Bottom Lorg/abego/treelayout/Configuration$Location; -
 field public,static,final,enum Right Lorg/abego/treelayout/Configuration$Location; -
 method public,static values ()[Lorg/abego/treelayout/Configuration$Location; - -
 method public,static valueOf (Ljava/lang/String;)Lorg/abego/treelayout/Configuration$Location; - -
in 53
class org/abego/treelayout/NodeExtentProvider 49 public,interface,abstract java/lang/Object - <TreeNode:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract getWidth (Ljava/lang/Object;)D (TTreeNode;)D -
 method public,abstract getHeight (Ljava/lang/Object;)D (TTreeNode;)D -
in 53
class org/abego/treelayout/TreeForTreeLayout 49 public,interface,abstract java/lang/Object - <TreeNode:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract getRoot ()Ljava/lang/Object; ()TTreeNode; -
 method public,abstract isLeaf (Ljava/lang/Object;)Z (TTreeNode;)Z -
 method public,abstract isChildOfParent (Ljava/lang/Object;Ljava/lang/Object;)Z (TTreeNode;TTreeNode;)Z -
 method public,abstract getChildren (Ljava/lang/Object;)Ljava/lang/Iterable; (TTreeNode;)Ljava/lang/Iterable<TTreeNode;>; -
 method public,abstract getChildrenReverse (Ljava/lang/Object;)Ljava/lang/Iterable; (TTreeNode;)Ljava/lang/Iterable<TTreeNode;>; -
 method public,abstract getFirstChild (Ljava/lang/Object;)Ljava/lang/Object; (TTreeNode;)TTreeNode; -
 method public,abstract getLastChild (Ljava/lang/Object;)Ljava/lang/Object; (TTreeNode;)TTreeNode; -
in 53
class org/abego/treelayout/TreeLayout 49 public,super java/lang/Object - <TreeNode:Ljava/lang/Object;>Ljava/lang/Object;
 inner org/abego/treelayout/TreeLayout$DumpConfiguration org/abego/treelayout/TreeLayout DumpConfiguration public,static
 inner org/abego/treelayout/TreeLayout$NormalizedPosition org/abego/treelayout/TreeLayout NormalizedPosition private
 inner java/awt/geom/Rectangle2D$Double java/awt/geom/Rectangle2D Double public,static
 inner org/abego/treelayout/Configuration$Location org/abego/treelayout/Configuration Location public,static,final,enum
 inner org/abego/treelayout/Configuration$AlignmentInLevel org/abego/treelayout/Configuration AlignmentInLevel public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public getTree ()Lorg/abego/treelayout/TreeForTreeLayout; ()Lorg/abego/treelayout/TreeForTreeLayout<TTreeNode;>; -
 method public getNodeExtentProvider ()Lorg/abego/treelayout/NodeExtentProvider; ()Lorg/abego/treelayout/NodeExtentProvider<TTreeNode;>; -
 method public getConfiguration ()Lorg/abego/treelayout/Configuration; ()Lorg/abego/treelayout/Configuration<TTreeNode;>; -
 method public getBounds ()Ljava/awt/geom/Rectangle2D; - -
 method public getLevelCount ()I - -
 method public getSizeOfLevel (I)D - -
 method public getNodeBounds ()Ljava/util/Map; ()Ljava/util/Map<TTreeNode;Ljava/awt/geom/Rectangle2D$Double;>; -
 method public <init> (Lorg/abego/treelayout/TreeForTreeLayout;Lorg/abego/treelayout/NodeExtentProvider;Lorg/abego/treelayout/Configuration;Z)V (Lorg/abego/treelayout/TreeForTreeLayout<TTreeNode;>;Lorg/abego/treelayout/NodeExtentProvider<TTreeNode;>;Lorg/abego/treelayout/Configuration<TTreeNode;>;Z)V -
 method public <init> (Lorg/abego/treelayout/TreeForTreeLayout;Lorg/abego/treelayout/NodeExtentProvider;Lorg/abego/treelayout/Configuration;)V (Lorg/abego/treelayout/TreeForTreeLayout<TTreeNode;>;Lorg/abego/treelayout/NodeExtentProvider<TTreeNode;>;Lorg/abego/treelayout/Configuration<TTreeNode;>;)V -
 method public checkTree ()V - -
 method public dumpTree (Ljava/io/PrintStream;Lorg/abego/treelayout/TreeLayout$DumpConfiguration;)V - -
 method public dumpTree (Ljava/io/PrintStream;)V - -
in 53
class org/abego/treelayout/TreeLayout$DumpConfiguration 49 public,super java/lang/Object - -
 inner org/abego/treelayout/TreeLayout$DumpConfiguration org/abego/treelayout/TreeLayout DumpConfiguration public,static
 field public,final indent Ljava/lang/String; -
 field public,final includeNodeSize Z -
 field public,final includeObjectToString Z -
 method public <init> (Ljava/lang/String;ZZ)V - -
 method public <init> ()V - -
in 53
class org/abego/treelayout/TreeLayout$NormalizedPosition 49 super java/awt/geom/Point2D - -
 inner org/abego/treelayout/TreeLayout$NormalizedPosition org/abego/treelayout/TreeLayout NormalizedPosition private
 method public <init> (Lorg/abego/treelayout/TreeLayout;DD)V - -
 method public getX ()D - -
 method public getY ()D - -
 method public setLocation (DD)V - -
in 53
class org/abego/treelayout/internal/util/Contract 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static checkArg (ZLjava/lang/String;)V - -
 method public,static checkState (ZLjava/lang/String;)V - -
in 53
class org/abego/treelayout/internal/util/java/lang/IterableUtil 49 public,super java/lang/Object - -
 inner org/abego/treelayout/internal/util/java/lang/IterableUtil$ReverseIterable org/abego/treelayout/internal/util/java/lang/IterableUtil ReverseIterable private,static
 method public <init> ()V - -
 method public,static createReverseIterable (Ljava/util/List;)Ljava/lang/Iterable; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/lang/Iterable<TT;>; -
in 53
class org/abego/treelayout/internal/util/java/lang/IterableUtil$ReverseIterable 49 super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<TT;>;
 inner org/abego/treelayout/internal/util/java/lang/IterableUtil$ReverseIterable org/abego/treelayout/internal/util/java/lang/IterableUtil ReverseIterable private,static
 method public <init> (Ljava/util/List;)V (Ljava/util/List<TT;>;)V -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TT;>; -
in 53
class org/abego/treelayout/internal/util/java/lang/string/StringUtil 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static quote (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static quote (Ljava/lang/String;)Ljava/lang/String; - -
in 53
class org/abego/treelayout/internal/util/java/util/IteratorUtil 49 public,super java/lang/Object - -
 inner org/abego/treelayout/internal/util/java/util/IteratorUtil$ReverseIterator org/abego/treelayout/internal/util/java/util/IteratorUtil ReverseIterator private,static
 method public <init> ()V - -
 method public,static createReverseIterator (Ljava/util/List;)Ljava/util/Iterator; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/Iterator<TT;>; -
in 53
class org/abego/treelayout/internal/util/java/util/IteratorUtil$ReverseIterator 49 super java/lang/Object java/util/Iterator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TT;>;
 inner org/abego/treelayout/internal/util/java/util/IteratorUtil$ReverseIterator org/abego/treelayout/internal/util/java/util/IteratorUtil ReverseIterator private,static
 method public <init> (Ljava/util/List;)V (Ljava/util/List<TT;>;)V -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TT; -
 method public remove ()V - -
in 53
class org/abego/treelayout/internal/util/java/util/ListUtil 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getLast (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
in 53
class org/abego/treelayout/util/AbstractTreeForTreeLayout 49 public,super,abstract java/lang/Object org/abego/treelayout/TreeForTreeLayout <TreeNode:Ljava/lang/Object;>Ljava/lang/Object;Lorg/abego/treelayout/TreeForTreeLayout<TTreeNode;>;
 method public,abstract getParent (Ljava/lang/Object;)Ljava/lang/Object; (TTreeNode;)TTreeNode; -
 method public,abstract getChildrenList (Ljava/lang/Object;)Ljava/util/List; (TTreeNode;)Ljava/util/List<TTreeNode;>; -
 method public <init> (Ljava/lang/Object;)V (TTreeNode;)V -
 method public getRoot ()Ljava/lang/Object; ()TTreeNode; -
 method public isLeaf (Ljava/lang/Object;)Z (TTreeNode;)Z -
 method public isChildOfParent (Ljava/lang/Object;Ljava/lang/Object;)Z (TTreeNode;TTreeNode;)Z -
 method public getChildren (Ljava/lang/Object;)Ljava/lang/Iterable; (TTreeNode;)Ljava/lang/Iterable<TTreeNode;>; -
 method public getChildrenReverse (Ljava/lang/Object;)Ljava/lang/Iterable; (TTreeNode;)Ljava/lang/Iterable<TTreeNode;>; -
 method public getFirstChild (Ljava/lang/Object;)Ljava/lang/Object; (TTreeNode;)TTreeNode; -
 method public getLastChild (Ljava/lang/Object;)Ljava/lang/Object; (TTreeNode;)TTreeNode; -
in 53
class org/abego/treelayout/util/DefaultConfiguration 49 public,super java/lang/Object org/abego/treelayout/Configuration <TreeNode:Ljava/lang/Object;>Ljava/lang/Object;Lorg/abego/treelayout/Configuration<TTreeNode;>;
 inner org/abego/treelayout/Configuration$Location org/abego/treelayout/Configuration Location public,static,final,enum
 inner org/abego/treelayout/Configuration$AlignmentInLevel org/abego/treelayout/Configuration AlignmentInLevel public,static,final,enum
 method public <init> (DDLorg/abego/treelayout/Configuration$Location;Lorg/abego/treelayout/Configuration$AlignmentInLevel;)V - -
 method public <init> (DDLorg/abego/treelayout/Configuration$Location;)V - -
 method public <init> (DD)V - -
 method public getGapBetweenLevels (I)D - -
 method public getGapBetweenNodes (Ljava/lang/Object;Ljava/lang/Object;)D (TTreeNode;TTreeNode;)D -
 method public getRootLocation ()Lorg/abego/treelayout/Configuration$Location; - -
 method public getAlignmentInLevel ()Lorg/abego/treelayout/Configuration$AlignmentInLevel; - -
in 53
class org/abego/treelayout/util/DefaultTreeForTreeLayout 49 public,super org/abego/treelayout/util/AbstractTreeForTreeLayout - <TreeNode:Ljava/lang/Object;>Lorg/abego/treelayout/util/AbstractTreeForTreeLayout<TTreeNode;>;
 method public <init> (Ljava/lang/Object;)V (TTreeNode;)V -
 method public getParent (Ljava/lang/Object;)Ljava/lang/Object; (TTreeNode;)TTreeNode; -
 method public getChildrenList (Ljava/lang/Object;)Ljava/util/List; (TTreeNode;)Ljava/util/List<TTreeNode;>; -
 method public hasNode (Ljava/lang/Object;)Z (TTreeNode;)Z -
 method public addChild (Ljava/lang/Object;Ljava/lang/Object;)V (TTreeNode;TTreeNode;)V -
 method public,varargs addChildren (Ljava/lang/Object;[Ljava/lang/Object;)V (TTreeNode;[TTreeNode;)V -
in 53
class org/abego/treelayout/util/FixedNodeExtentProvider 49 public,super java/lang/Object org/abego/treelayout/NodeExtentProvider <T:Ljava/lang/Object;>Ljava/lang/Object;Lorg/abego/treelayout/NodeExtentProvider<TT;>;
 method public <init> (DD)V - -
 method public <init> ()V - -
 method public getWidth (Ljava/lang/Object;)D (TT;)D -
 method public getHeight (Ljava/lang/Object;)D (TT;)D -
