cg-stub-db 1
in 69
class com/microsoft/aad/msal4j/AADAuthority 52 super com/microsoft/aad/msal4j/Authority - -
in 69
class com/microsoft/aad/msal4j/ADFSAuthority 52 super com/microsoft/aad/msal4j/Authority - -
in 21
class com/microsoft/aad/msal4j/AadInstanceDiscoveryProvider 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry InstanceDiscoveryMetadataEntryBuilder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 2
class com/microsoft/aad/msal4j/AadInstanceDiscoveryProvider 52 super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 21
class com/microsoft/aad/msal4j/AadInstanceDiscoveryResponse 52 super java/lang/Object - -
in 2
class com/microsoft/aad/msal4j/AadInstanceDiscoveryResponse 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/AadInstanceDiscoveryResponse;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/AadInstanceDiscoveryResponse; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/AbstractApplicationBase 52 public,super,abstract java/lang/Object com/microsoft/aad/msal4j/IApplicationBase -
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 field protected log Lorg/slf4j/Logger; -
 field protected authenticationAuthority Lcom/microsoft/aad/msal4j/Authority; -
 field protected tokenCache Lcom/microsoft/aad/msal4j/TokenCache; -
 method public correlationId ()Ljava/lang/String; - -
 method public logPii ()Z - -
 method public proxy ()Ljava/net/Proxy; - -
 method public sslSocketFactory ()Ljavax/net/ssl/SSLSocketFactory; - -
 method public httpClient ()Lcom/microsoft/aad/msal4j/IHttpClient; - -
 method public connectTimeoutForDefaultHttpClient ()Ljava/lang/Integer; - -
 method public readTimeoutForDefaultHttpClient ()Ljava/lang/Integer; - -
in 21
class com/microsoft/aad/msal4j/AbstractApplicationBase$Builder 52 public,super,abstract java/lang/Object - <T:Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder<TT;>;>Ljava/lang/Object;
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public correlationId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public logPii (Z)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Z)TT; -
 method public executorService (Ljava/util/concurrent/ExecutorService;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/util/concurrent/ExecutorService;)TT; -
 method public proxy (Ljava/net/Proxy;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/net/Proxy;)TT; -
 method public httpClient (Lcom/microsoft/aad/msal4j/IHttpClient;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Lcom/microsoft/aad/msal4j/IHttpClient;)TT; -
 method public sslSocketFactory (Ljavax/net/ssl/SSLSocketFactory;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljavax/net/ssl/SSLSocketFactory;)TT; -
 method public connectTimeoutForDefaultHttpClient (Ljava/lang/Integer;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/lang/Integer;)TT; -
 method public readTimeoutForDefaultHttpClient (Ljava/lang/Integer;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/lang/Integer;)TT; -
in 2
class com/microsoft/aad/msal4j/AbstractApplicationBase$Builder 52 public,super,abstract java/lang/Object - <T:Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder<TT;>;>Ljava/lang/Object;
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public correlationId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public logPii (Z)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Z)TT; -
 method public executorService (Ljava/util/concurrent/ExecutorService;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/util/concurrent/ExecutorService;)TT; -
 method public proxy (Ljava/net/Proxy;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/net/Proxy;)TT; -
 method public httpClient (Lcom/microsoft/aad/msal4j/IHttpClient;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Lcom/microsoft/aad/msal4j/IHttpClient;)TT; -
 method public sslSocketFactory (Ljavax/net/ssl/SSLSocketFactory;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljavax/net/ssl/SSLSocketFactory;)TT; -
 method public connectTimeoutForDefaultHttpClient (Ljava/lang/Integer;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/lang/Integer;)TT; -
 method public readTimeoutForDefaultHttpClient (Ljava/lang/Integer;)Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; (Ljava/lang/Integer;)TT; -
 method public disableInternalRetries ()Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder; ()TT; -
in 21
class com/microsoft/aad/msal4j/AbstractClientApplicationBase 52 public,super,abstract com/microsoft/aad/msal4j/AbstractApplicationBase com/microsoft/aad/msal4j/IClientApplicationBase -
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 field protected azureRegion Ljava/lang/String; -
 method protected,abstract clientAuthentication ()Lcom/nimbusds/oauth2/sdk/auth/ClientAuthentication; - -
 method public tokenCache ()Lcom/microsoft/aad/msal4j/TokenCache; - -
 method public acquireToken (Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/RefreshTokenParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/RefreshTokenParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireTokenSilently (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/net/MalformedURLException
 method public getAccounts ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<Ljava/util/Set<Lcom/microsoft/aad/msal4j/IAccount;>;>; -
 method public removeAccount (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public getAuthorizationRequestUrl (Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters;)Ljava/net/URL; - -
 method public clientId ()Ljava/lang/String; - -
 method public authority ()Ljava/lang/String; - -
 method public validateAuthority ()Z - -
 method public applicationName ()Ljava/lang/String; - -
 method public applicationVersion ()Ljava/lang/String; - -
 method public aadAadInstanceDiscoveryResponse ()Lcom/microsoft/aad/msal4j/AadInstanceDiscoveryResponse; - -
 method public clientCapabilities ()Ljava/lang/String; - -
 method public autoDetectRegion ()Z - -
 method public azureRegion ()Ljava/lang/String; - -
 method public instanceDiscovery ()Z - -
in 2
class com/microsoft/aad/msal4j/AbstractClientApplicationBase 52 public,super,abstract com/microsoft/aad/msal4j/AbstractApplicationBase com/microsoft/aad/msal4j/IClientApplicationBase -
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 field protected azureRegion Ljava/lang/String; -
 method public tokenCache ()Lcom/microsoft/aad/msal4j/TokenCache; - -
 method public acquireToken (Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/RefreshTokenParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/RefreshTokenParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireTokenSilently (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/net/MalformedURLException
 method public getAccounts ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<Ljava/util/Set<Lcom/microsoft/aad/msal4j/IAccount;>;>; -
 method public removeAccount (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public getAuthorizationRequestUrl (Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters;)Ljava/net/URL; - -
 method public clientId ()Ljava/lang/String; - -
 method public authority ()Ljava/lang/String; - -
 method public validateAuthority ()Z - -
 method public applicationName ()Ljava/lang/String; - -
 method public applicationVersion ()Ljava/lang/String; - -
 method public aadAadInstanceDiscoveryResponse ()Lcom/microsoft/aad/msal4j/AadInstanceDiscoveryResponse; - -
 method public clientCapabilities ()Ljava/lang/String; - -
 method public autoDetectRegion ()Z - -
 method public azureRegion ()Ljava/lang/String; - -
 method public instanceDiscovery ()Z - -
in 70
class com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder 52 public,super,abstract com/microsoft/aad/msal4j/AbstractApplicationBase$Builder - <T:Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder<TT;>;>Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder<TT;>;
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 field protected isInstanceDiscoveryEnabled Z -
 method public <init> (Ljava/lang/String;)V - -
 method public authority (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; java/net/MalformedURLException
 method public b2cAuthority (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; java/net/MalformedURLException
 method public validateAuthority (Z)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Z)TT; -
 method public applicationName (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public applicationVersion (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public setTokenCacheAccessAspect (Lcom/microsoft/aad/msal4j/ITokenCacheAccessAspect;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Lcom/microsoft/aad/msal4j/ITokenCacheAccessAspect;)TT; -
 method public aadInstanceDiscoveryResponse (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public clientCapabilities (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/util/Set<Ljava/lang/String;>;)TT; -
 method public autoDetectRegion (Z)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Z)TT; -
 method public azureRegion (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public instanceDiscovery (Z)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Z)TT; -
in 28
class com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder 52 public,super,abstract com/microsoft/aad/msal4j/AbstractApplicationBase$Builder - <T:Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder<TT;>;>Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder<TT;>;
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 field protected isInstanceDiscoveryEnabled Z -
 method public <init> (Ljava/lang/String;)V - -
 method public authority (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; java/net/MalformedURLException
 method public b2cAuthority (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; java/net/MalformedURLException
 method public oidcAuthority (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; java/net/MalformedURLException
 method public validateAuthority (Z)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Z)TT; -
 method public applicationName (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public applicationVersion (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public setTokenCacheAccessAspect (Lcom/microsoft/aad/msal4j/ITokenCacheAccessAspect;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Lcom/microsoft/aad/msal4j/ITokenCacheAccessAspect;)TT; -
 method public aadInstanceDiscoveryResponse (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public clientCapabilities (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/util/Set<Ljava/lang/String;>;)TT; -
 method public autoDetectRegion (Z)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Z)TT; -
 method public azureRegion (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
 method public instanceDiscovery (Z)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Z)TT; -
 method public logPii (Z)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Z)TT; -
 method public connectTimeoutForDefaultHttpClient (Ljava/lang/Integer;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/Integer;)TT; -
 method public readTimeoutForDefaultHttpClient (Ljava/lang/Integer;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/Integer;)TT; -
 method public httpClient (Lcom/microsoft/aad/msal4j/IHttpClient;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Lcom/microsoft/aad/msal4j/IHttpClient;)TT; -
 method public sslSocketFactory (Ljavax/net/ssl/SSLSocketFactory;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljavax/net/ssl/SSLSocketFactory;)TT; -
 method public executorService (Ljava/util/concurrent/ExecutorService;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/util/concurrent/ExecutorService;)TT; -
 method public proxy (Ljava/net/Proxy;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/net/Proxy;)TT; -
 method public correlationId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder; (Ljava/lang/String;)TT; -
in 70
class com/microsoft/aad/msal4j/AbstractManagedIdentitySource 52 super,abstract java/lang/Object - -
 field protected,static,final TIMEOUT_ERROR Ljava/lang/String; - "[Managed Identity] Authentication unavailable. The request to the managed identity endpoint timed out."
 field protected,final managedIdentityRequest Lcom/microsoft/aad/msal4j/ManagedIdentityRequest; -
 field protected,final serviceBundle Lcom/microsoft/aad/msal4j/ServiceBundle; -
 method public <init> (Lcom/microsoft/aad/msal4j/MsalRequest;Lcom/microsoft/aad/msal4j/ServiceBundle;Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType;)V - -
 method public getManagedIdentityResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method public handleResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method public,abstract createManagedIdentityRequest (Ljava/lang/String;)V - -
 method protected getSuccessfulResponse (Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method protected getMessageFromErrorResponse (Lcom/microsoft/aad/msal4j/IHttpResponse;)Ljava/lang/String; - -
 method protected,static getEnvironmentVariables (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Lcom/microsoft/aad/msal4j/IEnvironmentVariables; - -
 method public isUserAssignedManagedIdentity ()Z - -
 method public setUserAssignedManagedIdentity (Z)V - -
 method public getManagedIdentityUserAssignedClientId ()Ljava/lang/String; - -
 method public setManagedIdentityUserAssignedClientId (Ljava/lang/String;)V - -
 method public getManagedIdentityUserAssignedResourceId ()Ljava/lang/String; - -
 method public setManagedIdentityUserAssignedResourceId (Ljava/lang/String;)V - -
in 26
class com/microsoft/aad/msal4j/AbstractManagedIdentitySource 52 super,abstract java/lang/Object - -
 field protected,final managedIdentityRequest Lcom/microsoft/aad/msal4j/ManagedIdentityRequest; -
 field protected,final serviceBundle Lcom/microsoft/aad/msal4j/ServiceBundle; -
 method public <init> (Lcom/microsoft/aad/msal4j/MsalRequest;Lcom/microsoft/aad/msal4j/ServiceBundle;Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType;)V - -
 method public getManagedIdentityResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method public handleResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method public,abstract createManagedIdentityRequest (Ljava/lang/String;)V - -
 method protected getSuccessfulResponse (Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method protected getMessageFromErrorResponse (Lcom/microsoft/aad/msal4j/IHttpResponse;)Ljava/lang/String; - -
 method protected,static getEnvironmentVariables ()Lcom/microsoft/aad/msal4j/IEnvironmentVariables; - -
 method public isUserAssignedManagedIdentity ()Z - -
 method public setUserAssignedManagedIdentity (Z)V - -
 method public getManagedIdentityUserAssignedClientId ()Ljava/lang/String; - -
 method public setManagedIdentityUserAssignedClientId (Ljava/lang/String;)V - -
 method public getManagedIdentityUserAssignedResourceId ()Ljava/lang/String; - -
 method public setManagedIdentityUserAssignedResourceId (Ljava/lang/String;)V - -
in 2
class com/microsoft/aad/msal4j/AbstractManagedIdentitySource 52 super,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final managedIdentityRequest Lcom/microsoft/aad/msal4j/ManagedIdentityRequest; -
 field protected,final serviceBundle Lcom/microsoft/aad/msal4j/ServiceBundle; -
 method public <init> (Lcom/microsoft/aad/msal4j/MsalRequest;Lcom/microsoft/aad/msal4j/ServiceBundle;Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType;)V - -
 method public getManagedIdentityResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method public handleResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method public,abstract createManagedIdentityRequest (Ljava/lang/String;)V - -
 method protected getSuccessfulResponse (Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
 method protected getMessageFromErrorResponse (Lcom/microsoft/aad/msal4j/IHttpResponse;)Ljava/lang/String; - -
 method protected,static getEnvironmentVariables ()Lcom/microsoft/aad/msal4j/IEnvironmentVariables; - -
 method public isUserAssignedManagedIdentity ()Z - -
 method public getManagedIdentityUserAssignedClientId ()Ljava/lang/String; - -
 method public getManagedIdentityUserAssignedResourceId ()Ljava/lang/String; - -
 method public setUserAssignedManagedIdentity (Z)V - -
 method public setManagedIdentityUserAssignedClientId (Ljava/lang/String;)V - -
 method public setManagedIdentityUserAssignedResourceId (Ljava/lang/String;)V - -
in 21
class com/microsoft/aad/msal4j/AbstractMsalAuthorizationGrant 52 super,abstract java/lang/Object - -
in 2
class com/microsoft/aad/msal4j/AbstractMsalAuthorizationGrant 52 super,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 21
class com/microsoft/aad/msal4j/AccessTokenCacheEntity 52 super com/microsoft/aad/msal4j/Credential - -
 field protected realm Ljava/lang/String; -
 method public credentialType ()Ljava/lang/String; - -
 method public realm ()Ljava/lang/String; - -
 method public target ()Ljava/lang/String; - -
 method public cachedAt ()Ljava/lang/String; - -
 method public expiresOn ()Ljava/lang/String; - -
 method public extExpiresOn ()Ljava/lang/String; - -
 method public refreshOn ()Ljava/lang/String; - -
 method public credentialType (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccessTokenCacheEntity; - -
 method public realm (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccessTokenCacheEntity; - -
 method public target (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccessTokenCacheEntity; - -
 method public cachedAt (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccessTokenCacheEntity; - -
 method public expiresOn (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccessTokenCacheEntity; - -
 method public extExpiresOn (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccessTokenCacheEntity; - -
 method public refreshOn (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccessTokenCacheEntity; - -
in 2
class com/microsoft/aad/msal4j/AccessTokenCacheEntity 52 super com/microsoft/aad/msal4j/Credential com/azure/json/JsonSerializable Lcom/microsoft/aad/msal4j/Credential;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/Credential;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected realm Ljava/lang/String; -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 21
class com/microsoft/aad/msal4j/Account 52 super java/lang/Object com/microsoft/aad/msal4j/IAccount -
 method public getTenantProfiles ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/ITenantProfile;>; -
 method public homeAccountId ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public username ()Ljava/lang/String; - -
 method public tenantProfiles ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/ITenantProfile;>; -
 method public homeAccountId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Account; - -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Account; - -
 method public username (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Account; - -
 method public tenantProfiles (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/Account; (Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/ITenantProfile;>;)Lcom/microsoft/aad/msal4j/Account; -
 method public equals (Ljava/lang/Object;)Z - -
 method protected canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/ITenantProfile;>;)V -
in 2
class com/microsoft/aad/msal4j/Account 52 super java/lang/Object com/microsoft/aad/msal4j/IAccount -
 method public getTenantProfiles ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/ITenantProfile;>; -
 method public homeAccountId ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public username ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 21
class com/microsoft/aad/msal4j/AccountCacheEntity 52 super java/lang/Object java/io/Serializable -
 field protected homeAccountId Ljava/lang/String; -
 field protected environment Ljava/lang/String; -
 field protected realm Ljava/lang/String; -
 field protected localAccountId Ljava/lang/String; -
 field protected username Ljava/lang/String; -
 field protected name Ljava/lang/String; -
 field protected clientInfoStr Ljava/lang/String; -
 field protected userAssertionHash Ljava/lang/String; -
 field protected authorityType Ljava/lang/String; -
 method public homeAccountId ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public realm ()Ljava/lang/String; - -
 method public localAccountId ()Ljava/lang/String; - -
 method public username ()Ljava/lang/String; - -
 method public name ()Ljava/lang/String; - -
 method public clientInfoStr ()Ljava/lang/String; - -
 method public userAssertionHash ()Ljava/lang/String; - -
 method public authorityType ()Ljava/lang/String; - -
 method public homeAccountId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public realm (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public localAccountId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public username (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public name (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public clientInfoStr (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public userAssertionHash (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public authorityType (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AccountCacheEntity; - -
 method public equals (Ljava/lang/Object;)Z - -
 method protected canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 2
class com/microsoft/aad/msal4j/AccountCacheEntity 52 super java/lang/Object com/azure/json/JsonSerializable,java/io/Serializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/AccountCacheEntity;>;Ljava/io/Serializable;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected homeAccountId Ljava/lang/String; -
 field protected environment Ljava/lang/String; -
 field protected realm Ljava/lang/String; -
 field protected localAccountId Ljava/lang/String; -
 field protected username Ljava/lang/String; -
 field protected name Ljava/lang/String; -
 field protected clientInfoStr Ljava/lang/String; -
 field protected userAssertionHash Ljava/lang/String; -
 field protected authorityType Ljava/lang/String; -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 69
class com/microsoft/aad/msal4j/AccountsSupplier 52 super java/lang/Object java/util/function/Supplier Ljava/lang/Object;Ljava/util/function/Supplier<Ljava/util/Set<Lcom/microsoft/aad/msal4j/IAccount;>;>;
 method public get ()Ljava/util/Set; ()Ljava/util/Set<Lcom/microsoft/aad/msal4j/IAccount;>; -
in 70
class com/microsoft/aad/msal4j/AcquireTokenByAppProviderSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 method public fetchTokenUsingAppTokenProvider (Lcom/microsoft/aad/msal4j/AppTokenProviderParameters;)Lcom/microsoft/aad/msal4j/AuthenticationResult; - java/util/concurrent/ExecutionException,java/lang/InterruptedException
in 26
class com/microsoft/aad/msal4j/AcquireTokenByAppProviderSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public fetchTokenUsingAppTokenProvider (Lcom/microsoft/aad/msal4j/AppTokenProviderParameters;)Lcom/microsoft/aad/msal4j/AuthenticationResult; - java/util/concurrent/ExecutionException,java/lang/InterruptedException
in 2
class com/microsoft/aad/msal4j/AcquireTokenByAppProviderSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public fetchTokenUsingAppTokenProvider (Lcom/microsoft/aad/msal4j/AppTokenProviderParameters;)Lcom/microsoft/aad/msal4j/AuthenticationResult; - java/util/concurrent/ExecutionException,java/lang/InterruptedException
in 69
class com/microsoft/aad/msal4j/AcquireTokenByAuthorizationGrantSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
in 69
class com/microsoft/aad/msal4j/AcquireTokenByClientCredentialSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
in 69
class com/microsoft/aad/msal4j/AcquireTokenByDeviceCodeFlowSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
in 69
class com/microsoft/aad/msal4j/AcquireTokenByInteractiveFlowSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner java/awt/Desktop$Action java/awt/Desktop Action public,static,final,enum
 inner com/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder com/microsoft/aad/msal4j/AuthorizationCodeParameters AuthorizationCodeParametersBuilder public,static
 field public,static,final LINUX_XDG_OPEN Ljava/lang/String; - "linux_xdg_open_failed"
 field public,static,final LINUX_OPEN_AS_SUDO_NOT_SUPPORTED Ljava/lang/String; - "Unable to open a web page using xdg-open, gnome-open, kfmclient or wslview tools in sudo mode. Please run the process as non-sudo user."
in 70
class com/microsoft/aad/msal4j/AcquireTokenByManagedIdentitySupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
in 26
class com/microsoft/aad/msal4j/AcquireTokenByManagedIdentitySupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
in 2
class com/microsoft/aad/msal4j/AcquireTokenByManagedIdentitySupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder static
in 69
class com/microsoft/aad/msal4j/AcquireTokenByOnBehalfOfSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
in 70
class com/microsoft/aad/msal4j/AcquireTokenSilentSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder com/microsoft/aad/msal4j/RefreshTokenParameters RefreshTokenParametersBuilder public,static
in 28
class com/microsoft/aad/msal4j/AcquireTokenSilentSupplier 52 super com/microsoft/aad/msal4j/AuthenticationResultSupplier - -
 inner com/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder com/microsoft/aad/msal4j/RefreshTokenParameters RefreshTokenParametersBuilder public,static
 field protected,static,final ACCESS_TOKEN_EXPIRE_BUFFER_IN_SEC I - I300
in 69
class com/microsoft/aad/msal4j/ApiEvent 52 super com/microsoft/aad/msal4j/Event - -
 method public <init> (Ljava/lang/Boolean;)V - -
 method public setApiId (I)V - -
 method public setAuthority (Ljava/net/URI;)V - -
 method public setAuthorityType (Ljava/lang/String;)V - -
 method public setTenantId (Ljava/lang/String;)V - -
 method public setAccountId (Ljava/lang/String;)V - -
 method public setWasSuccessful (Z)V - -
 method public getWasSuccessful ()Z - -
 method public setCorrelationId (Ljava/lang/String;)V - -
 method public setRequestId (Ljava/lang/String;)V - -
 method public setIsConfidentialClient (Z)V - -
 method public setApiErrorCode (Ljava/lang/String;)V - -
in 21
class com/microsoft/aad/msal4j/AppMetadataCacheEntity 52 super java/lang/Object - -
 field public,static,final APP_METADATA_CACHE_ENTITY_ID Ljava/lang/String; - "appmetadata"
 method public clientId ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public familyId ()Ljava/lang/String; - -
 method public clientId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AppMetadataCacheEntity; - -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AppMetadataCacheEntity; - -
 method public familyId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AppMetadataCacheEntity; - -
in 2
class com/microsoft/aad/msal4j/AppMetadataCacheEntity 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/AppMetadataCacheEntity;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final APP_METADATA_CACHE_ENTITY_ID Ljava/lang/String; - "appmetadata"
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/AppServiceManagedIdentitySource 52 super com/microsoft/aad/msal4j/AbstractManagedIdentitySource - -
 method public createManagedIdentityRequest (Ljava/lang/String;)V - -
in 21
class com/microsoft/aad/msal4j/AppTokenProviderParameters 52 public,super java/lang/Object - -
 field public scopes Ljava/util/Set; Ljava/util/Set<Ljava/lang/String;>;
 field public correlationId Ljava/lang/String; -
 field public claims Ljava/lang/String; -
 field public tenantId Ljava/lang/String; -
 method public getScopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getCorrelationId ()Ljava/lang/String; - -
 method public getClaims ()Ljava/lang/String; - -
 method public getTenantId ()Ljava/lang/String; - -
 method public setScopes (Ljava/util/Set;)V (Ljava/util/Set<Ljava/lang/String;>;)V -
 method public setCorrelationId (Ljava/lang/String;)V - -
 method public setClaims (Ljava/lang/String;)V - -
 method public setTenantId (Ljava/lang/String;)V - -
 method public <init> (Ljava/util/Set;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V (Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V -
in 2
class com/microsoft/aad/msal4j/AppTokenProviderParameters 52 public,super java/lang/Object - -
 field public scopes Ljava/util/Set; Ljava/util/Set<Ljava/lang/String;>;
 field public correlationId Ljava/lang/String; -
 field public claims Ljava/lang/String; -
 field public tenantId Ljava/lang/String; -
 method public <init> (Ljava/util/Set;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V (Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V -
 method public getScopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getCorrelationId ()Ljava/lang/String; - -
 method public getClaims ()Ljava/lang/String; - -
 method public getTenantId ()Ljava/lang/String; - -
 method public setScopes (Ljava/util/Set;)V (Ljava/util/Set<Ljava/lang/String;>;)V -
 method public setCorrelationId (Ljava/lang/String;)V - -
 method public setClaims (Ljava/lang/String;)V - -
 method public setTenantId (Ljava/lang/String;)V - -
in 21
class com/microsoft/aad/msal4j/AuthenticationErrorCode 52 public,super java/lang/Object - -
 field public,static,final AUTHORIZATION_PENDING Ljava/lang/String; - "authorization_pending"
 field public,static,final CODE_EXPIRED Ljava/lang/String; - "code_expired"
 field public,static,final INVALID_GRANT Ljava/lang/String; - "invalid_grant"
 field public,static,final WSTRUST_ENDPOINT_NOT_FOUND_IN_METADATA_DOCUMENT Ljava/lang/String; - "wstrust_endpoint_not_found"
 field public,static,final WSTRUST_INVALID_RESPONSE Ljava/lang/String; - "wstrust_invalid_response"
 field public,static,final WSTRUST_SERVICE_ERROR Ljava/lang/String; - "wstrust_service_error"
 field public,static,final PASSWORD_REQUIRED_FOR_MANAGED_USER Ljava/lang/String; - "password_required_for_managed_user"
 field public,static,final USER_REALM_DISCOVERY_FAILED Ljava/lang/String; - "user_realm_discovery_failed"
 field public,static,final CACHE_MISS Ljava/lang/String; - "cache_miss"
 field public,static,final INVALID_INSTANCE_DISCOVERY_METADATA Ljava/lang/String; - "invalid_instance_discovery_metadata"
 field public,static,final UNKNOWN Ljava/lang/String; - "unknown"
 field public,static,final LOOPBACK_REDIRECT_URI Ljava/lang/String; - "loopback_redirect_uri"
 field public,static,final UNABLE_TO_START_HTTP_LISTENER Ljava/lang/String; - "unable_to_start_http_listener"
 field public,static,final INVALID_AUTHORIZATION_RESULT Ljava/lang/String; - "invalid_authorization_result"
 field public,static,final INVALID_REDIRECT_URI Ljava/lang/String; - "invalid_redirect_uri"
 field public,static,final DESKTOP_BROWSER_NOT_SUPPORTED Ljava/lang/String; - "desktop_browser_not_supported"
 field public,static,final THROTTLED_REQUEST Ljava/lang/String; - "throttled_request"
 field public,static,final INVALID_JSON Ljava/lang/String; - "invalid_json"
 field public,static,final INVALID_JWT Ljava/lang/String; - "invalid_jwt"
 field public,static,final MISSING_BROKER Ljava/lang/String; - "missing_broker"
 field public,static,final HTTP_TIMEOUT Ljava/lang/String; - "http_timeout"
 field public,static,final MSALRUNTIME_INTEROP_ERROR Ljava/lang/String; - "interop_package_error"
 field public,static,final MSALJAVA_BROKERS_ERROR Ljava/lang/String; - "brokers_package_error"
 field public,static,final MANAGED_IDENTITY_REQUEST_FAILED Ljava/lang/String; - "managed_identity_request_failed"
 method public <init> ()V - -
in 2
class com/microsoft/aad/msal4j/AuthenticationErrorCode 52 public,super java/lang/Object - -
 field public,static,final AUTHORIZATION_PENDING Ljava/lang/String; - "authorization_pending"
 field public,static,final CODE_EXPIRED Ljava/lang/String; - "code_expired"
 field public,static,final INVALID_GRANT Ljava/lang/String; - "invalid_grant"
 field public,static,final WSTRUST_ENDPOINT_NOT_FOUND_IN_METADATA_DOCUMENT Ljava/lang/String; - "wstrust_endpoint_not_found"
 field public,static,final WSTRUST_INVALID_RESPONSE Ljava/lang/String; - "wstrust_invalid_response"
 field public,static,final WSTRUST_SERVICE_ERROR Ljava/lang/String; - "wstrust_service_error"
 field public,static,final PASSWORD_REQUIRED_FOR_MANAGED_USER Ljava/lang/String; - "password_required_for_managed_user"
 field public,static,final USER_REALM_DISCOVERY_FAILED Ljava/lang/String; - "user_realm_discovery_failed"
 field public,static,final CACHE_MISS Ljava/lang/String; - "cache_miss"
 field public,static,final INVALID_INSTANCE_DISCOVERY_METADATA Ljava/lang/String; - "invalid_instance_discovery_metadata"
 field public,static,final UNKNOWN Ljava/lang/String; - "unknown"
 field public,static,final LOOPBACK_REDIRECT_URI Ljava/lang/String; - "loopback_redirect_uri"
 field public,static,final UNABLE_TO_START_HTTP_LISTENER Ljava/lang/String; - "unable_to_start_http_listener"
 field public,static,final INVALID_AUTHORIZATION_RESULT Ljava/lang/String; - "invalid_authorization_result"
 field public,static,final INVALID_REDIRECT_URI Ljava/lang/String; - "invalid_redirect_uri"
 field public,static,final INVALID_ENDPOINT_URI Ljava/lang/String; - "invalid_endpoint_uri"
 field public,static,final DESKTOP_BROWSER_NOT_SUPPORTED Ljava/lang/String; - "desktop_browser_not_supported"
 field public,static,final THROTTLED_REQUEST Ljava/lang/String; - "throttled_request"
 field public,static,final INVALID_JSON Ljava/lang/String; - "invalid_json"
 field public,static,final INVALID_JWT Ljava/lang/String; - "invalid_jwt"
 field public,static,final MISSING_BROKER Ljava/lang/String; - "missing_broker"
 field public,static,final HTTP_TIMEOUT Ljava/lang/String; - "http_timeout"
 field public,static,final MSALRUNTIME_INTEROP_ERROR Ljava/lang/String; - "interop_package_error"
 field public,static,final MSALJAVA_BROKERS_ERROR Ljava/lang/String; - "brokers_package_error"
 field public,static,final MANAGED_IDENTITY_REQUEST_FAILED Ljava/lang/String; - "managed_identity_request_failed"
 field public,static,final CRYPTO_ERROR Ljava/lang/String; - "crypto_error"
 field public,static,final INVALID_TIMESTAMP_FORMAT Ljava/lang/String; - "invalid_timestamp_format"
 method public <init> ()V - -
in 69
class com/microsoft/aad/msal4j/AuthenticationErrorMessage 52 public,super java/lang/Object - -
 field public,static,final NO_TOKEN_IN_CACHE Ljava/lang/String; - "Token not found in the cache"
 method public <init> ()V - -
in 70
class com/microsoft/aad/msal4j/AuthenticationResult 52 final,super java/lang/Object com/microsoft/aad/msal4j/IAuthenticationResult -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 method public,static builder ()Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public accessToken ()Ljava/lang/String; - -
 method public refreshToken ()Ljava/lang/String; - -
 method public refreshOn ()Ljava/lang/Long; - -
 method public idToken ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public scopes ()Ljava/lang/String; - -
 method public metadata ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public tenantProfile ()Lcom/microsoft/aad/msal4j/ITenantProfile; - -
 method public expiresOnDate ()Ljava/util/Date; - -
in 26
class com/microsoft/aad/msal4j/AuthenticationResult 52 final,super java/lang/Object com/microsoft/aad/msal4j/IAuthenticationResult -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public,static builder ()Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public accessToken ()Ljava/lang/String; - -
 method public refreshToken ()Ljava/lang/String; - -
 method public refreshOn ()Ljava/lang/Long; - -
 method public idToken ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public scopes ()Ljava/lang/String; - -
 method public metadata ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public tenantProfile ()Lcom/microsoft/aad/msal4j/ITenantProfile; - -
 method public expiresOnDate ()Ljava/util/Date; - -
in 2
class com/microsoft/aad/msal4j/AuthenticationResult 52 final,super java/lang/Object com/microsoft/aad/msal4j/IAuthenticationResult -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public accessToken ()Ljava/lang/String; - -
 method public idToken ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public scopes ()Ljava/lang/String; - -
 method public metadata ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata; - -
 method public account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public tenantProfile ()Lcom/microsoft/aad/msal4j/ITenantProfile; - -
 method public expiresOnDate ()Ljava/util/Date; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 21
class com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 method public accessToken (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public expiresOn (J)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public extExpiresOn (J)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public refreshToken (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public refreshOn (Ljava/lang/Long;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public familyId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public idToken (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public accountCacheEntity (Lcom/microsoft/aad/msal4j/AccountCacheEntity;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public scopes (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public metadata (Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public isPopAuthorization (Ljava/lang/Boolean;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/AuthenticationResult; - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder static
 method public accessToken (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public expiresOn (J)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public extExpiresOn (J)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public refreshToken (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public refreshOn (Ljava/lang/Long;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public familyId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public idToken (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public accountCacheEntity (Lcom/microsoft/aad/msal4j/AccountCacheEntity;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public scopes (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public metadata (Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public isPopAuthorization (Ljava/lang/Boolean;)Lcom/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/AuthenticationResult; - -
 method public toString ()Ljava/lang/String; - -
in 70
class com/microsoft/aad/msal4j/AuthenticationResultMetadata 52 public,super java/lang/Object java/io/Serializable -
 method public tokenSource ()Lcom/microsoft/aad/msal4j/TokenSource; - -
in 26
class com/microsoft/aad/msal4j/AuthenticationResultMetadata 52 public,super java/lang/Object java/io/Serializable -
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public,static builder ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder; - -
 method public tokenSource ()Lcom/microsoft/aad/msal4j/TokenSource; - -
 method public refreshOn ()Ljava/lang/Long; - -
in 2
class com/microsoft/aad/msal4j/AuthenticationResultMetadata 52 public,super java/lang/Object java/io/Serializable -
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public,static builder ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder; - -
 method public tokenSource ()Lcom/microsoft/aad/msal4j/TokenSource; - -
 method public refreshOn ()Ljava/lang/Long; - -
 method public cacheRefreshReason ()Lcom/microsoft/aad/msal4j/CacheRefreshReason; - -
in 26
class com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public tokenSource (Lcom/microsoft/aad/msal4j/TokenSource;)Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder; - -
 method public refreshOn (Ljava/lang/Long;)Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata; - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public tokenSource (Lcom/microsoft/aad/msal4j/TokenSource;)Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder; - -
 method public refreshOn (Ljava/lang/Long;)Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder; - -
 method public cacheRefreshReason (Lcom/microsoft/aad/msal4j/CacheRefreshReason;)Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/AuthenticationResultSupplier 52 super,abstract java/lang/Object java/util/function/Supplier Ljava/lang/Object;Ljava/util/function/Supplier<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>;
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
 method public get ()Lcom/microsoft/aad/msal4j/IAuthenticationResult; - -
in 69
class com/microsoft/aad/msal4j/Authority 52 super,abstract java/lang/Object - -
 field protected,final authorityType Lcom/microsoft/aad/msal4j/AuthorityType; -
 method protected,static enforceTrailingSlash (Ljava/lang/String;)Ljava/lang/String; - -
in 70
class com/microsoft/aad/msal4j/AuthorityType 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/AuthorityType;>;
 field public,static,final,enum AAD Lcom/microsoft/aad/msal4j/AuthorityType; -
 field public,static,final,enum ADFS Lcom/microsoft/aad/msal4j/AuthorityType; -
 field public,static,final,enum B2C Lcom/microsoft/aad/msal4j/AuthorityType; -
 field public,static,final,enum CIAM Lcom/microsoft/aad/msal4j/AuthorityType; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/AuthorityType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorityType; - -
in 28
class com/microsoft/aad/msal4j/AuthorityType 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/AuthorityType;>;
 field public,static,final,enum AAD Lcom/microsoft/aad/msal4j/AuthorityType; -
 field public,static,final,enum ADFS Lcom/microsoft/aad/msal4j/AuthorityType; -
 field public,static,final,enum B2C Lcom/microsoft/aad/msal4j/AuthorityType; -
 field public,static,final,enum CIAM Lcom/microsoft/aad/msal4j/AuthorityType; -
 field public,static,final,enum OIDC Lcom/microsoft/aad/msal4j/AuthorityType; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/AuthorityType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorityType; - -
in 69
class com/microsoft/aad/msal4j/AuthorizationCodeParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder com/microsoft/aad/msal4j/AuthorizationCodeParameters AuthorizationCodeParametersBuilder public,static
 method public,static builder (Ljava/lang/String;Ljava/net/URI;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; - -
 method public authorizationCode ()Ljava/lang/String; - -
 method public redirectUri ()Ljava/net/URI; - -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public codeVerifier ()Ljava/lang/String; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder com/microsoft/aad/msal4j/AuthorizationCodeParameters AuthorizationCodeParametersBuilder public,static
 method public authorizationCode (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; - -
 method public redirectUri (Ljava/net/URI;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; - -
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; - -
 method public codeVerifier (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters$AuthorizationCodeParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/AuthorizationCodeRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 69
class com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static builder (Ljava/lang/String;Ljava/util/Set;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; (Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; -
 method public redirectUri ()Ljava/lang/String; - -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public codeChallenge ()Ljava/lang/String; - -
 method public codeChallengeMethod ()Ljava/lang/String; - -
 method public state ()Ljava/lang/String; - -
 method public nonce ()Ljava/lang/String; - -
 method public responseMode ()Lcom/microsoft/aad/msal4j/ResponseMode; - -
 method public loginHint ()Ljava/lang/String; - -
 method public domainHint ()Ljava/lang/String; - -
 method public prompt ()Lcom/microsoft/aad/msal4j/Prompt; - -
 method public correlationId ()Ljava/lang/String; - -
 method public instanceAware ()Z - -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public requestParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
 method public log ()Lorg/slf4j/Logger; - -
in 69
class com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters Builder public,static
 method public <init> ()V - -
 method public build ()Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters; - -
 method public redirectUri (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; -
 method public extraScopesToConsent (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; -
 method public claimsChallenge (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public codeChallenge (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public codeChallengeMethod (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public state (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public nonce (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public responseMode (Lcom/microsoft/aad/msal4j/ResponseMode;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public loginHint (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public domainHint (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public prompt (Lcom/microsoft/aad/msal4j/Prompt;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public correlationId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public instanceAware (Z)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; - -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder; -
in 21
class com/microsoft/aad/msal4j/AuthorizationResponseHandler 52 super java/lang/Object com/sun/net/httpserver/HttpHandler -
 inner com/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus com/microsoft/aad/msal4j/AuthorizationResult AuthorizationStatus static,final,enum
 method public handle (Lcom/sun/net/httpserver/HttpExchange;)V - java/io/IOException
 method public authorizationResultQueue ()Ljava/util/concurrent/BlockingQueue; ()Ljava/util/concurrent/BlockingQueue<Lcom/microsoft/aad/msal4j/AuthorizationResult;>; -
 method public systemBrowserOptions ()Lcom/microsoft/aad/msal4j/SystemBrowserOptions; - -
in 2
class com/microsoft/aad/msal4j/AuthorizationResponseHandler 52 super java/lang/Object com/sun/net/httpserver/HttpHandler -
 inner com/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus com/microsoft/aad/msal4j/AuthorizationResult AuthorizationStatus static,final,enum
 method public handle (Lcom/sun/net/httpserver/HttpExchange;)V - java/io/IOException
in 21
class com/microsoft/aad/msal4j/AuthorizationResult 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus com/microsoft/aad/msal4j/AuthorizationResult AuthorizationStatus static,final,enum
 method public code ()Ljava/lang/String; - -
 method public state ()Ljava/lang/String; - -
 method public status ()Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus; - -
 method public error ()Ljava/lang/String; - -
 method public errorDescription ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public code (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationResult; - -
 method public state (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationResult; - -
 method public status (Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus;)Lcom/microsoft/aad/msal4j/AuthorizationResult; - -
 method public error (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationResult; - -
 method public errorDescription (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationResult; - -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationResult; - -
in 2
class com/microsoft/aad/msal4j/AuthorizationResult 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus com/microsoft/aad/msal4j/AuthorizationResult AuthorizationStatus static,final,enum
in 69
class com/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus;>;
 inner com/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus com/microsoft/aad/msal4j/AuthorizationResult AuthorizationStatus static,final,enum
 field public,static,final,enum Success Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus; -
 field public,static,final,enum ProtocolError Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus; -
 field public,static,final,enum UnknownError Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AuthorizationResult$AuthorizationStatus; - -
in 21
class com/microsoft/aad/msal4j/AzureArcManagedIdentitySource 52 super com/microsoft/aad/msal4j/AbstractManagedIdentitySource - -
 method public createManagedIdentityRequest (Ljava/lang/String;)V - -
 method public handleResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
in 2
class com/microsoft/aad/msal4j/AzureArcManagedIdentitySource 52 super com/microsoft/aad/msal4j/AbstractManagedIdentitySource - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public createManagedIdentityRequest (Ljava/lang/String;)V - -
 method public handleResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
in 69
class com/microsoft/aad/msal4j/AzureCloudEndpoint 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/AzureCloudEndpoint;>;
 field public,static,final,enum AzurePublic Lcom/microsoft/aad/msal4j/AzureCloudEndpoint; -
 field public,static,final,enum AzureChina Lcom/microsoft/aad/msal4j/AzureCloudEndpoint; -
 field public,static,final,enum AzureGermany Lcom/microsoft/aad/msal4j/AzureCloudEndpoint; -
 field public,static,final,enum AzureUsGovernment Lcom/microsoft/aad/msal4j/AzureCloudEndpoint; -
 field public,final endpoint Ljava/lang/String; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/AzureCloudEndpoint; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/AzureCloudEndpoint; - -
in 69
class com/microsoft/aad/msal4j/B2CAuthority 52 super com/microsoft/aad/msal4j/Authority - -
in 69
class com/microsoft/aad/msal4j/BindingPolicy 52 super java/lang/Object - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Lcom/microsoft/aad/msal4j/WSTrustVersion;)V - -
 method public getValue ()Ljava/lang/String; - -
 method public setValue (Ljava/lang/String;)V - -
 method public getUrl ()Ljava/lang/String; - -
 method public setUrl (Ljava/lang/String;)V - -
 method public setVersion (Lcom/microsoft/aad/msal4j/WSTrustVersion;)V - -
 method public getVersion ()Lcom/microsoft/aad/msal4j/WSTrustVersion; - -
in 69
class com/microsoft/aad/msal4j/CIAMAuthority 52 public,super com/microsoft/aad/msal4j/Authority - -
 field public,static,final CIAM_HOST_SEGMENT Ljava/lang/String; - ".ciamlogin.com"
 method protected,static transformAuthority (Ljava/net/URL;)Ljava/net/URL; - java/net/MalformedURLException
in 2
class com/microsoft/aad/msal4j/CacheRefreshReason 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/CacheRefreshReason;>;
 field public,static,final,enum NOT_APPLICABLE Lcom/microsoft/aad/msal4j/CacheRefreshReason; -
 field public,static,final,enum FORCE_REFRESH Lcom/microsoft/aad/msal4j/CacheRefreshReason; -
 field public,static,final,enum CLAIMS Lcom/microsoft/aad/msal4j/CacheRefreshReason; -
 field public,static,final,enum NO_CACHED_ACCESS_TOKEN Lcom/microsoft/aad/msal4j/CacheRefreshReason; -
 field public,static,final,enum EXPIRED Lcom/microsoft/aad/msal4j/CacheRefreshReason; -
 field public,static,final,enum PROACTIVE_REFRESH Lcom/microsoft/aad/msal4j/CacheRefreshReason; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/CacheRefreshReason; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/CacheRefreshReason; - -
in 21
class com/microsoft/aad/msal4j/CacheTelemetry 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/CacheTelemetry;>;
 field public,static,final,enum REFRESH_CACHE_NOT_USED Lcom/microsoft/aad/msal4j/CacheTelemetry; -
 field public,static,final,enum REFRESH_FORCE_REFRESH Lcom/microsoft/aad/msal4j/CacheTelemetry; -
 field public,static,final,enum REFRESH_NO_ACCESS_TOKEN Lcom/microsoft/aad/msal4j/CacheTelemetry; -
 field public,static,final,enum REFRESH_ACCESS_TOKEN_EXPIRED Lcom/microsoft/aad/msal4j/CacheTelemetry; -
 field public,static,final,enum REFRESH_REFRESH_IN Lcom/microsoft/aad/msal4j/CacheTelemetry; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/CacheTelemetry; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/CacheTelemetry; - -
in 21
class com/microsoft/aad/msal4j/ClaimsRequest 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public requestClaimInIdToken (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
 method protected requestClaimInUserInfo (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
 method protected requestClaimInAccessToken (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
 method public formatAsJSONString ()Ljava/lang/String; - -
 method public,static formatAsClaimsRequest (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public getIdTokenRequestedClaims ()Ljava/util/List; ()Ljava/util/List<Lcom/microsoft/aad/msal4j/RequestedClaim;>; -
 method public setIdTokenRequestedClaims (Ljava/util/List;)V (Ljava/util/List<Lcom/microsoft/aad/msal4j/RequestedClaim;>;)V -
in 2
class com/microsoft/aad/msal4j/ClaimsRequest 52 public,super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/ClaimsRequest;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public requestClaimInIdToken (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
 method protected requestClaimInUserInfo (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
 method protected requestClaimInAccessToken (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
 method public formatAsJSONString ()Ljava/lang/String; - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public,static formatAsClaimsRequest (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public getIdTokenRequestedClaims ()Ljava/util/List; ()Ljava/util/List<Lcom/microsoft/aad/msal4j/RequestedClaim;>; -
 method public setIdTokenRequestedClaims (Ljava/util/List;)V (Ljava/util/List<Lcom/microsoft/aad/msal4j/RequestedClaim;>;)V -
in 69
class com/microsoft/aad/msal4j/ClientAssertion 52 final,super java/lang/Object com/microsoft/aad/msal4j/IClientAssertion -
 method public assertion ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 21
class com/microsoft/aad/msal4j/ClientAuthenticationPost 52 super com/nimbusds/oauth2/sdk/auth/ClientAuthentication - -
 inner com/nimbusds/oauth2/sdk/http/HTTPRequest$Method com/nimbusds/oauth2/sdk/http/HTTPRequest Method public,static,final,enum
 method protected <init> (Lcom/nimbusds/oauth2/sdk/auth/ClientAuthenticationMethod;Lcom/nimbusds/oauth2/sdk/id/ClientID;)V - -
 method public getFormParameterNames ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public applyTo (Lcom/nimbusds/oauth2/sdk/http/HTTPRequest;)V - com/nimbusds/oauth2/sdk/SerializeException
in 70
class com/microsoft/aad/msal4j/ClientCertificate 52 final,super java/lang/Object com/microsoft/aad/msal4j/IClientCertificate -
 inner java/security/KeyStore$PrivateKeyEntry java/security/KeyStore PrivateKeyEntry public,static,final
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
 field public,static,final DEFAULT_PKCS12_PASSWORD Ljava/lang/String; - ""
 method public publicCertificateHash ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public getEncodedPublicKeyCertificateChain ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; java/security/cert/CertificateEncodingException
 method public privateKey ()Ljava/security/PrivateKey; - -
in 26
class com/microsoft/aad/msal4j/ClientCertificate 52 final,super java/lang/Object com/microsoft/aad/msal4j/IClientCertificate -
 inner java/security/KeyStore$PrivateKeyEntry java/security/KeyStore PrivateKeyEntry public,static,final
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
 field public,static,final DEFAULT_PKCS12_PASSWORD Ljava/lang/String; - ""
 method public publicCertificateHash ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public publicCertificateHashSha1 ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public getEncodedPublicKeyCertificateChain ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; java/security/cert/CertificateEncodingException
 method public privateKey ()Ljava/security/PrivateKey; - -
in 2
class com/microsoft/aad/msal4j/ClientCertificate 52 final,super java/lang/Object com/microsoft/aad/msal4j/IClientCertificate -
 inner java/security/KeyStore$PrivateKeyEntry java/security/KeyStore PrivateKeyEntry public,static,final
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
 field public,static,final DEFAULT_PKCS12_PASSWORD Ljava/lang/String; - ""
 method public publicCertificateHash256 ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public publicCertificateHash ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public getEncodedPublicKeyCertificateChain ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; java/security/cert/CertificateEncodingException
 method public getAssertion (Lcom/microsoft/aad/msal4j/Authority;Ljava/lang/String;Z)Ljava/lang/String; - -
 method public privateKey ()Ljava/security/PrivateKey; - -
in 21
class com/microsoft/aad/msal4j/ClientCredentialFactory 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static createFromSecret (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IClientSecret; - -
 method public,static createFromCertificate (Ljava/io/InputStream;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IClientCertificate; - java/security/cert/CertificateException,java/security/UnrecoverableKeyException,java/security/NoSuchAlgorithmException,java/security/KeyStoreException,java/security/NoSuchProviderException,java/io/IOException
 method public,static createFromCertificate (Ljava/security/PrivateKey;Ljava/security/cert/X509Certificate;)Lcom/microsoft/aad/msal4j/IClientCertificate; - -
 method public,static createFromCertificateChain (Ljava/security/PrivateKey;Ljava/util/List;)Lcom/microsoft/aad/msal4j/IClientCertificate; (Ljava/security/PrivateKey;Ljava/util/List<Ljava/security/cert/X509Certificate;>;)Lcom/microsoft/aad/msal4j/IClientCertificate; -
 method public,static createFromClientAssertion (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IClientAssertion; - -
 method public,static createFromCallback (Ljava/util/concurrent/Callable;)Lcom/microsoft/aad/msal4j/IClientAssertion; (Ljava/util/concurrent/Callable<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/IClientAssertion; java/util/concurrent/ExecutionException,java/lang/InterruptedException
in 2
class com/microsoft/aad/msal4j/ClientCredentialFactory 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static createFromSecret (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IClientSecret; - -
 method public,static createFromCertificate (Ljava/io/InputStream;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IClientCertificate; - java/security/cert/CertificateException,java/security/UnrecoverableKeyException,java/security/NoSuchAlgorithmException,java/security/KeyStoreException,java/security/NoSuchProviderException,java/io/IOException
 method public,static createFromCertificate (Ljava/security/PrivateKey;Ljava/security/cert/X509Certificate;)Lcom/microsoft/aad/msal4j/IClientCertificate; - -
 method public,static createFromCertificateChain (Ljava/security/PrivateKey;Ljava/util/List;)Lcom/microsoft/aad/msal4j/IClientCertificate; (Ljava/security/PrivateKey;Ljava/util/List<Ljava/security/cert/X509Certificate;>;)Lcom/microsoft/aad/msal4j/IClientCertificate; -
 method public,static createFromClientAssertion (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IClientAssertion; - -
 method public,static createFromCallback (Ljava/util/concurrent/Callable;)Lcom/microsoft/aad/msal4j/IClientAssertion; (Ljava/util/concurrent/Callable<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/IClientAssertion; -
in 69
class com/microsoft/aad/msal4j/ClientCredentialParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder com/microsoft/aad/msal4j/ClientCredentialParameters ClientCredentialParametersBuilder public,static
 method public,static builder (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public skipCache ()Ljava/lang/Boolean; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public clientCredential ()Lcom/microsoft/aad/msal4j/IClientCredential; - -
in 69
class com/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder com/microsoft/aad/msal4j/ClientCredentialParameters ClientCredentialParametersBuilder public,static
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; -
 method public skipCache (Ljava/lang/Boolean;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; - -
 method public clientCredential (Lcom/microsoft/aad/msal4j/IClientCredential;)Lcom/microsoft/aad/msal4j/ClientCredentialParameters$ClientCredentialParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/ClientCredentialParameters; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/ClientCredentialRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 21
class com/microsoft/aad/msal4j/ClientInfo 52 super java/lang/Object - -
 inner java/util/Base64$Decoder java/util/Base64 Decoder public,static
 method public,static createFromJson (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ClientInfo; - -
in 2
class com/microsoft/aad/msal4j/ClientInfo 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/ClientInfo;>;
 inner java/util/Base64$Decoder java/util/Base64 Decoder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static createFromJson (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ClientInfo; - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 21
class com/microsoft/aad/msal4j/ClientSecret 52 final,super java/lang/Object com/microsoft/aad/msal4j/IClientSecret -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public clientSecret ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/ClientSecret 52 final,super java/lang/Object com/microsoft/aad/msal4j/IClientSecret -
 method public clientSecret ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 69
class com/microsoft/aad/msal4j/CloudShellManagedIdentitySource 52 super com/microsoft/aad/msal4j/AbstractManagedIdentitySource - -
 method public createManagedIdentityRequest (Ljava/lang/String;)V - -
in 21
class com/microsoft/aad/msal4j/ConfidentialClientApplication 52 public,super com/microsoft/aad/msal4j/AbstractClientApplicationBase com/microsoft/aad/msal4j/IConfidentialClientApplication -
 inner com/microsoft/aad/msal4j/ConfidentialClientApplication$Builder com/microsoft/aad/msal4j/ConfidentialClientApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 field public appTokenProvider Ljava/util/function/Function; Ljava/util/function/Function<Lcom/microsoft/aad/msal4j/AppTokenProviderParameters;Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/TokenProviderResult;>;>;
 method public acquireToken (Lcom/microsoft/aad/msal4j/ClientCredentialParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/ClientCredentialParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/OnBehalfOfParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/OnBehalfOfParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method protected clientAuthentication ()Lcom/nimbusds/oauth2/sdk/auth/ClientAuthentication; - -
 method protected createClientAuthFromClientAssertion (Lcom/microsoft/aad/msal4j/ClientAssertion;)Lcom/nimbusds/oauth2/sdk/auth/ClientAuthentication; - -
 method public,static builder (Ljava/lang/String;Lcom/microsoft/aad/msal4j/IClientCredential;)Lcom/microsoft/aad/msal4j/ConfidentialClientApplication$Builder; - -
 method public sendX5c ()Z - -
in 2
class com/microsoft/aad/msal4j/ConfidentialClientApplication 52 public,super com/microsoft/aad/msal4j/AbstractClientApplicationBase com/microsoft/aad/msal4j/IConfidentialClientApplication -
 inner com/microsoft/aad/msal4j/ConfidentialClientApplication$Builder com/microsoft/aad/msal4j/ConfidentialClientApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 field public appTokenProvider Ljava/util/function/Function; Ljava/util/function/Function<Lcom/microsoft/aad/msal4j/AppTokenProviderParameters;Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/TokenProviderResult;>;>;
 method public acquireToken (Lcom/microsoft/aad/msal4j/ClientCredentialParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/ClientCredentialParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/OnBehalfOfParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/OnBehalfOfParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public,static builder (Ljava/lang/String;Lcom/microsoft/aad/msal4j/IClientCredential;)Lcom/microsoft/aad/msal4j/ConfidentialClientApplication$Builder; - -
 method public sendX5c ()Z - -
in 69
class com/microsoft/aad/msal4j/ConfidentialClientApplication$Builder 52 public,super com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder - Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder<Lcom/microsoft/aad/msal4j/ConfidentialClientApplication$Builder;>;
 inner com/microsoft/aad/msal4j/ConfidentialClientApplication$Builder com/microsoft/aad/msal4j/ConfidentialClientApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public sendX5c (Z)Lcom/microsoft/aad/msal4j/ConfidentialClientApplication$Builder; - -
 method public appTokenProvider (Ljava/util/function/Function;)Lcom/microsoft/aad/msal4j/ConfidentialClientApplication$Builder; (Ljava/util/function/Function<Lcom/microsoft/aad/msal4j/AppTokenProviderParameters;Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/TokenProviderResult;>;>;)Lcom/microsoft/aad/msal4j/ConfidentialClientApplication$Builder; -
 method public build ()Lcom/microsoft/aad/msal4j/ConfidentialClientApplication; - -
 method protected self ()Lcom/microsoft/aad/msal4j/ConfidentialClientApplication$Builder; - -
in 70
class com/microsoft/aad/msal4j/Constants 52 final,super java/lang/Object - -
 field public,static,final MANAGED_IDENTITY_CLIENT_ID Ljava/lang/String; - "client_id"
 field public,static,final MANAGED_IDENTITY_RESOURCE_ID Ljava/lang/String; - "mi_res_id"
 field public,static,final MANAGED_IDENTITY_DEFAULT_TENTANT Ljava/lang/String; - "managed_identity"
 field public,static,final IDENTITY_ENDPOINT Ljava/lang/String; - "IDENTITY_ENDPOINT"
 field public,static,final IDENTITY_HEADER Ljava/lang/String; - "IDENTITY_HEADER"
 field public,static,final AZURE_POD_IDENTITY_AUTHORITY_HOST Ljava/lang/String; - "AZURE_POD_IDENTITY_AUTHORITY_HOST"
 field public,static,final IMDS_ENDPOINT Ljava/lang/String; - "IMDS_ENDPOINT"
 field public,static,final MSI_ENDPOINT Ljava/lang/String; - "MSI_ENDPOINT"
 field public,static,final IDENTITY_SERVER_THUMBPRINT Ljava/lang/String; - "IDENTITY_SERVER_THUMBPRINT"
in 26
class com/microsoft/aad/msal4j/Constants 52 final,super java/lang/Object - -
 field public,static,final MANAGED_IDENTITY_CLIENT_ID Ljava/lang/String; - "client_id"
 field public,static,final MANAGED_IDENTITY_RESOURCE_ID Ljava/lang/String; - "mi_res_id"
 field public,static,final MANAGED_IDENTITY_OBJECT_ID Ljava/lang/String; - "object_id"
 field public,static,final MANAGED_IDENTITY_DEFAULT_TENTANT Ljava/lang/String; - "managed_identity"
 field public,static,final IDENTITY_ENDPOINT Ljava/lang/String; - "IDENTITY_ENDPOINT"
 field public,static,final IDENTITY_HEADER Ljava/lang/String; - "IDENTITY_HEADER"
 field public,static,final AZURE_POD_IDENTITY_AUTHORITY_HOST Ljava/lang/String; - "AZURE_POD_IDENTITY_AUTHORITY_HOST"
 field public,static,final IMDS_ENDPOINT Ljava/lang/String; - "IMDS_ENDPOINT"
 field public,static,final MSI_ENDPOINT Ljava/lang/String; - "MSI_ENDPOINT"
 field public,static,final IDENTITY_SERVER_THUMBPRINT Ljava/lang/String; - "IDENTITY_SERVER_THUMBPRINT"
in 2
class com/microsoft/aad/msal4j/Constants 52 final,super java/lang/Object - -
 field public,static,final MANAGED_IDENTITY_CLIENT_ID Ljava/lang/String; - "client_id"
 field public,static,final MANAGED_IDENTITY_RESOURCE_ID Ljava/lang/String; - "mi_res_id"
 field public,static,final MANAGED_IDENTITY_RESOURCE_ID_IMDS Ljava/lang/String; - "msi_res_id"
 field public,static,final MANAGED_IDENTITY_OBJECT_ID Ljava/lang/String; - "object_id"
 field public,static,final MANAGED_IDENTITY_DEFAULT_TENTANT Ljava/lang/String; - "managed_identity"
 field public,static,final IDENTITY_ENDPOINT Ljava/lang/String; - "IDENTITY_ENDPOINT"
 field public,static,final IDENTITY_HEADER Ljava/lang/String; - "IDENTITY_HEADER"
 field public,static,final AZURE_POD_IDENTITY_AUTHORITY_HOST Ljava/lang/String; - "AZURE_POD_IDENTITY_AUTHORITY_HOST"
 field public,static,final IMDS_ENDPOINT Ljava/lang/String; - "IMDS_ENDPOINT"
 field public,static,final MSI_ENDPOINT Ljava/lang/String; - "MSI_ENDPOINT"
 field public,static,final IDENTITY_SERVER_THUMBPRINT Ljava/lang/String; - "IDENTITY_SERVER_THUMBPRINT"
 field public,static,final TOKEN_HASH_CLAIM Ljava/lang/String; - "token_sha256_to_refresh"
 field public,static,final CLIENT_CAPABILITY_REQUEST_PARAM Ljava/lang/String; - "xms_cc"
 field public,static,final TOKEN_REVOCATION_SUPPORTED_ENVIRONMENTS Ljava/util/Set; Ljava/util/Set<Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType;>;
in 21
class com/microsoft/aad/msal4j/Credential 52 super java/lang/Object - -
 field protected homeAccountId Ljava/lang/String; -
 field protected environment Ljava/lang/String; -
 field protected clientId Ljava/lang/String; -
 field protected secret Ljava/lang/String; -
 field protected userAssertionHash Ljava/lang/String; -
 method public homeAccountId ()Ljava/lang/String; - -
 method public environment ()Ljava/lang/String; - -
 method public clientId ()Ljava/lang/String; - -
 method public secret ()Ljava/lang/String; - -
 method public userAssertionHash ()Ljava/lang/String; - -
 method public homeAccountId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Credential; - -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Credential; - -
 method public clientId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Credential; - -
 method public secret (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Credential; - -
 method public userAssertionHash (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Credential; - -
in 2
class com/microsoft/aad/msal4j/Credential 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/Credential;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected homeAccountId Ljava/lang/String; -
 field protected environment Ljava/lang/String; -
 field protected clientId Ljava/lang/String; -
 field protected secret Ljava/lang/String; -
 field protected userAssertionHash Ljava/lang/String; -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 21
class com/microsoft/aad/msal4j/CredentialTypeEnum 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/CredentialTypeEnum;>;
 field public,static,final,enum ACCESS_TOKEN Lcom/microsoft/aad/msal4j/CredentialTypeEnum; -
 field public,static,final,enum REFRESH_TOKEN Lcom/microsoft/aad/msal4j/CredentialTypeEnum; -
 field public,static,final,enum ID_TOKEN Lcom/microsoft/aad/msal4j/CredentialTypeEnum; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/CredentialTypeEnum; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/CredentialTypeEnum; - -
 method public value ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/CredentialTypeEnum 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/CredentialTypeEnum;>;
 field public,static,final,enum ACCESS_TOKEN Lcom/microsoft/aad/msal4j/CredentialTypeEnum; -
 field public,static,final,enum REFRESH_TOKEN Lcom/microsoft/aad/msal4j/CredentialTypeEnum; -
 field public,static,final,enum ID_TOKEN Lcom/microsoft/aad/msal4j/CredentialTypeEnum; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/CredentialTypeEnum; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/CredentialTypeEnum; - -
in 21
class com/microsoft/aad/msal4j/CurrentRequest 52 super java/lang/Object - -
 method public publicApi ()Lcom/microsoft/aad/msal4j/PublicApi; - -
 method public cacheInfo ()I - -
 method public regionUsed ()Ljava/lang/String; - -
 method public regionSource ()I - -
 method public regionOutcome ()I - -
 method public cacheInfo (I)Lcom/microsoft/aad/msal4j/CurrentRequest; - -
 method public regionUsed (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/CurrentRequest; - -
 method public regionSource (I)Lcom/microsoft/aad/msal4j/CurrentRequest; - -
 method public regionOutcome (I)Lcom/microsoft/aad/msal4j/CurrentRequest; - -
in 2
class com/microsoft/aad/msal4j/CurrentRequest 52 super java/lang/Object - -
in 21
class com/microsoft/aad/msal4j/CustomJWTAuthentication 52 public,super com/nimbusds/oauth2/sdk/auth/ClientAuthentication - -
 inner com/nimbusds/oauth2/sdk/http/HTTPRequest$Method com/nimbusds/oauth2/sdk/http/HTTPRequest Method public,static,final,enum
 method protected <init> (Lcom/nimbusds/oauth2/sdk/auth/ClientAuthenticationMethod;Lcom/microsoft/aad/msal4j/ClientAssertion;Lcom/nimbusds/oauth2/sdk/id/ClientID;)V - -
 method public getFormParameterNames ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public applyTo (Lcom/nimbusds/oauth2/sdk/http/HTTPRequest;)V - -
 method public toParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
in 69
class com/microsoft/aad/msal4j/DefaultEvent 52 super com/microsoft/aad/msal4j/Event - -
 method public <init> (Ljava/lang/String;Ljava/util/Map;)V (Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>;)V -
in 69
class com/microsoft/aad/msal4j/DefaultHttpClient 52 super java/lang/Object com/microsoft/aad/msal4j/IHttpClient -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public send (Lcom/microsoft/aad/msal4j/HttpRequest;)Lcom/microsoft/aad/msal4j/IHttpResponse; - java/lang/Exception
in 69
class com/microsoft/aad/msal4j/DefaultHttpClientManagedIdentity 52 super com/microsoft/aad/msal4j/DefaultHttpClient - -
 field public,static,final ALL_HOSTS_ACCEPT_HOSTNAME_VERIFIER Ljavax/net/ssl/HostnameVerifier; -
 method public,static addTrustedCertificateThumbprint (Ljavax/net/ssl/HttpsURLConnection;Ljava/lang/String;)V - -
in 2
class com/microsoft/aad/msal4j/DefaultRetryPolicy 52 super java/lang/Object com/microsoft/aad/msal4j/IRetryPolicy -
 method public isRetryable (Lcom/microsoft/aad/msal4j/IHttpResponse;)Z - -
 method public getMaxRetryCount (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
 method public getRetryDelayMs (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
in 21
class com/microsoft/aad/msal4j/DeviceCode 52 public,final,super java/lang/Object - -
 method public <init> ()V - -
 method public userCode ()Ljava/lang/String; - -
 method public deviceCode ()Ljava/lang/String; - -
 method public verificationUri ()Ljava/lang/String; - -
 method public expiresIn ()J - -
 method public interval ()J - -
 method public message ()Ljava/lang/String; - -
 method protected correlationId ()Ljava/lang/String; - -
 method protected correlationId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/DeviceCode; - -
 method protected clientId ()Ljava/lang/String; - -
 method protected clientId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/DeviceCode; - -
 method protected scopes ()Ljava/lang/String; - -
 method protected scopes (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/DeviceCode; - -
in 2
class com/microsoft/aad/msal4j/DeviceCode 52 public,final,super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/DeviceCode;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/DeviceCode; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public userCode ()Ljava/lang/String; - -
 method public deviceCode ()Ljava/lang/String; - -
 method public verificationUri ()Ljava/lang/String; - -
 method public expiresIn ()J - -
 method public interval ()J - -
 method public message ()Ljava/lang/String; - -
 method protected correlationId ()Ljava/lang/String; - -
 method protected clientId ()Ljava/lang/String; - -
 method protected scopes ()Ljava/lang/String; - -
 method protected correlationId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/DeviceCode; - -
 method protected clientId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/DeviceCode; - -
 method protected scopes (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/DeviceCode; - -
in 21
class com/microsoft/aad/msal4j/DeviceCodeAuthorizationGrant 52 super com/microsoft/aad/msal4j/AbstractMsalAuthorizationGrant - -
 method public toParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
 method public getCorrelationId ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/DeviceCodeFlowParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder com/microsoft/aad/msal4j/DeviceCodeFlowParameters DeviceCodeFlowParametersBuilder public,static
 method public,static builder (Ljava/util/Set;Ljava/util/function/Consumer;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;Ljava/util/function/Consumer<Lcom/microsoft/aad/msal4j/DeviceCode;>;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public deviceCodeConsumer ()Ljava/util/function/Consumer; ()Ljava/util/function/Consumer<Lcom/microsoft/aad/msal4j/DeviceCode;>; -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder com/microsoft/aad/msal4j/DeviceCodeFlowParameters DeviceCodeFlowParametersBuilder public,static
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; -
 method public deviceCodeConsumer (Ljava/util/function/Consumer;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; (Ljava/util/function/Consumer<Lcom/microsoft/aad/msal4j/DeviceCode;>;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters$DeviceCodeFlowParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters; - -
 method public toString ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/DeviceCodeFlowRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 2
class com/microsoft/aad/msal4j/DeviceCodeFlowRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 69
class com/microsoft/aad/msal4j/EnvironmentVariables 52 super java/lang/Object com/microsoft/aad/msal4j/IEnvironmentVariables -
 method public getEnvironmentVariable (Ljava/lang/String;)Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/ErrorResponse 52 super java/lang/Object - -
 field protected error Ljava/lang/String; -
 field protected errorDescription Ljava/lang/String; -
 field protected errorCodes [J -
 field protected subError Ljava/lang/String; -
 field protected traceId Ljava/lang/String; -
 field protected timestamp Ljava/lang/String; -
 field protected correlation_id Ljava/lang/String; -
 method public statusCode ()Ljava/lang/Integer; - -
 method public statusMessage ()Ljava/lang/String; - -
 method public error ()Ljava/lang/String; - -
 method public errorDescription ()Ljava/lang/String; - -
 method public errorCodes ()[J - -
 method public subError ()Ljava/lang/String; - -
 method public traceId ()Ljava/lang/String; - -
 method public timestamp ()Ljava/lang/String; - -
 method public correlation_id ()Ljava/lang/String; - -
 method public claims ()Ljava/lang/String; - -
 method public statusCode (Ljava/lang/Integer;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public statusMessage (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public error (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public errorDescription (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public errorCodes ([J)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public subError (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public traceId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public timestamp (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public correlation_id (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
 method public claims (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ErrorResponse; - -
in 2
class com/microsoft/aad/msal4j/ErrorResponse 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/ErrorResponse;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected error Ljava/lang/String; -
 field protected errorDescription Ljava/lang/String; -
 field protected errorCodes [J -
 field protected subError Ljava/lang/String; -
 field protected traceId Ljava/lang/String; -
 field protected timestamp Ljava/lang/String; -
 field protected correlation_id Ljava/lang/String; -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/Event 52 super,abstract java/util/HashMap - Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;
in 69
class com/microsoft/aad/msal4j/EventKey 52 super java/lang/Object - -
 method public getRequestId ()Ljava/lang/String; - -
 method public getEventName ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 2
class com/microsoft/aad/msal4j/GrantConstants 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/HTTPContentType 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/HTTPContentType;>;
 field public,static,final,enum ApplicationURLEncoded Lcom/microsoft/aad/msal4j/HTTPContentType; -
 field public,static,final,enum ApplicationJSON Lcom/microsoft/aad/msal4j/HTTPContentType; -
 field public,final contentType Ljava/lang/String; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/HTTPContentType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/HTTPContentType; - -
in 69
class com/microsoft/aad/msal4j/HttpEvent 52 super com/microsoft/aad/msal4j/Event - -
in 69
class com/microsoft/aad/msal4j/HttpHeaders 52 final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public toString ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/HttpHelper 52 super java/lang/Object com/microsoft/aad/msal4j/IHttpHelper -
 field public,static,final RETRY_AFTER_HEADER Ljava/lang/String; - "Retry-After"
 field public,static,final RETRY_NUM I - I2
 field public,static,final RETRY_DELAY_MS I - I1000
 field public,static,final HTTP_STATUS_200 I - I200
 field public,static,final HTTP_STATUS_400 I - I400
 field public,static,final HTTP_STATUS_429 I - I429
 field public,static,final HTTP_STATUS_500 I - I500
 method public executeHttpRequest (Lcom/microsoft/aad/msal4j/HttpRequest;Lcom/microsoft/aad/msal4j/RequestContext;Lcom/microsoft/aad/msal4j/ServiceBundle;)Lcom/microsoft/aad/msal4j/IHttpResponse; - -
in 2
class com/microsoft/aad/msal4j/HttpHelper 52 super java/lang/Object com/microsoft/aad/msal4j/IHttpHelper -
 field public,static,final RETRY_AFTER_HEADER Ljava/lang/String; - "Retry-After"
 method public executeHttpRequest (Lcom/microsoft/aad/msal4j/HttpRequest;Lcom/microsoft/aad/msal4j/RequestContext;Lcom/microsoft/aad/msal4j/ServiceBundle;)Lcom/microsoft/aad/msal4j/IHttpResponse; - -
in 21
class com/microsoft/aad/msal4j/HttpHelperManagedIdentity 52 super com/microsoft/aad/msal4j/HttpHelper - -
in 69
class com/microsoft/aad/msal4j/HttpListener 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/HttpMethod 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/HttpMethod;>;
 field public,static,final,enum CONNECT Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,static,final,enum DELETE Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,static,final,enum GET Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,static,final,enum HEAD Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,static,final,enum OPTIONS Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,static,final,enum POST Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,static,final,enum PUT Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,static,final,enum TRACE Lcom/microsoft/aad/msal4j/HttpMethod; -
 field public,final methodName Ljava/lang/String; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/HttpMethod; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/HttpMethod; - -
in 69
class com/microsoft/aad/msal4j/HttpRequest 52 public,super java/lang/Object - -
 method public headerValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public httpMethod ()Lcom/microsoft/aad/msal4j/HttpMethod; - -
 method public url ()Ljava/net/URL; - -
 method public headers ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public body ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method protected canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 69
class com/microsoft/aad/msal4j/HttpResponse 52 public,super java/lang/Object com/microsoft/aad/msal4j/IHttpResponse -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public addHeaders (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;)V -
 method public statusCode ()I - -
 method public headers ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
 method public body ()Ljava/lang/String; - -
 method public statusCode (I)Lcom/microsoft/aad/msal4j/HttpResponse; - -
 method public body (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/HttpResponse; - -
in 2
class com/microsoft/aad/msal4j/HttpStatus 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/HttpUtils 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/IAccount 52 public,interface,abstract java/lang/Object java/io/Serializable -
 method public,abstract homeAccountId ()Ljava/lang/String; - -
 method public,abstract environment ()Ljava/lang/String; - -
 method public,abstract username ()Ljava/lang/String; - -
 method public,abstract getTenantProfiles ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/ITenantProfile;>; -
in 69
class com/microsoft/aad/msal4j/IAcquireTokenParameters 52 interface,abstract java/lang/Object - -
 method public,abstract scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public,abstract extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract tenant ()Ljava/lang/String; - -
 method public,abstract extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
in 69
class com/microsoft/aad/msal4j/IApplicationBase 52 interface,abstract java/lang/Object - -
 field public,static,final DEFAULT_AUTHORITY Ljava/lang/String; - "https://login.microsoftonline.com/common/"
 method public,abstract logPii ()Z - -
 method public,abstract correlationId ()Ljava/lang/String; - -
 method public,abstract httpClient ()Lcom/microsoft/aad/msal4j/IHttpClient; - -
 method public,abstract proxy ()Ljava/net/Proxy; - -
 method public,abstract sslSocketFactory ()Ljavax/net/ssl/SSLSocketFactory; - -
in 70
class com/microsoft/aad/msal4j/IAuthenticationResult 52 public,interface,abstract java/lang/Object java/io/Serializable -
 method public,abstract accessToken ()Ljava/lang/String; - -
 method public,abstract idToken ()Ljava/lang/String; - -
 method public,abstract account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public,abstract tenantProfile ()Lcom/microsoft/aad/msal4j/ITenantProfile; - -
 method public,abstract environment ()Ljava/lang/String; - -
 method public,abstract scopes ()Ljava/lang/String; - -
 method public,abstract expiresOnDate ()Ljava/util/Date; - -
 method public,abstract metadata ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata; - -
in 28
class com/microsoft/aad/msal4j/IAuthenticationResult 52 public,interface,abstract java/lang/Object java/io/Serializable -
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 method public,abstract accessToken ()Ljava/lang/String; - -
 method public,abstract idToken ()Ljava/lang/String; - -
 method public,abstract account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public,abstract tenantProfile ()Lcom/microsoft/aad/msal4j/ITenantProfile; - -
 method public,abstract environment ()Ljava/lang/String; - -
 method public,abstract scopes ()Ljava/lang/String; - -
 method public,abstract expiresOnDate ()Ljava/util/Date; - -
 method public metadata ()Lcom/microsoft/aad/msal4j/AuthenticationResultMetadata; - -
in 21
class com/microsoft/aad/msal4j/IBroker 52 public,interface,abstract java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 method public acquireToken (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public removeAccount (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/IAccount;)V - com/microsoft/aad/msal4j/MsalClientException
 method public isBrokerAvailable ()Z - -
 method public parseBrokerAuthResult (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JZ)Lcom/microsoft/aad/msal4j/IAuthenticationResult; - -
in 2
class com/microsoft/aad/msal4j/IBroker 52 public,interface,abstract java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder static
 method public acquireToken (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public removeAccount (Lcom/microsoft/aad/msal4j/PublicClientApplication;Lcom/microsoft/aad/msal4j/IAccount;)V - com/microsoft/aad/msal4j/MsalClientException
 method public isBrokerAvailable ()Z - -
 method public parseBrokerAuthResult (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JZ)Lcom/microsoft/aad/msal4j/IAuthenticationResult; - -
in 69
class com/microsoft/aad/msal4j/IClientApplicationBase 52 interface,abstract java/lang/Object com/microsoft/aad/msal4j/IApplicationBase -
 method public,abstract clientId ()Ljava/lang/String; - -
 method public,abstract authority ()Ljava/lang/String; - -
 method public,abstract validateAuthority ()Z - -
 method public,abstract getAuthorizationRequestUrl (Lcom/microsoft/aad/msal4j/AuthorizationRequestUrlParameters;)Ljava/net/URL; - -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/AuthorizationCodeParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/RefreshTokenParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/RefreshTokenParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public,abstract acquireTokenSilently (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/net/MalformedURLException
 method public,abstract getAccounts ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<Ljava/util/Set<Lcom/microsoft/aad/msal4j/IAccount;>;>; -
 method public,abstract removeAccount (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture; - -
in 69
class com/microsoft/aad/msal4j/IClientAssertion 52 public,interface,abstract java/lang/Object com/microsoft/aad/msal4j/IClientCredential -
 method public,abstract assertion ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/IClientCertificate 52 public,interface,abstract java/lang/Object com/microsoft/aad/msal4j/IClientCredential -
 method public,abstract privateKey ()Ljava/security/PrivateKey; - -
 method public,abstract publicCertificateHash ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public,abstract getEncodedPublicKeyCertificateChain ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; java/security/cert/CertificateEncodingException
in 2
class com/microsoft/aad/msal4j/IClientCertificate 52 public,interface,abstract java/lang/Object com/microsoft/aad/msal4j/IClientCredential -
 method public,abstract privateKey ()Ljava/security/PrivateKey; - -
 method public publicCertificateHash256 ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public,abstract publicCertificateHash ()Ljava/lang/String; - java/security/cert/CertificateEncodingException,java/security/NoSuchAlgorithmException
 method public,abstract getEncodedPublicKeyCertificateChain ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; java/security/cert/CertificateEncodingException
in 69
class com/microsoft/aad/msal4j/IClientCredential 52 public,interface,abstract java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/IClientSecret 52 public,interface,abstract java/lang/Object com/microsoft/aad/msal4j/IClientCredential -
 method public,abstract clientSecret ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/IConfidentialClientApplication 52 public,interface,abstract java/lang/Object com/microsoft/aad/msal4j/IClientApplicationBase -
 method public,abstract sendX5c ()Z - -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/ClientCredentialParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/ClientCredentialParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/OnBehalfOfParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/OnBehalfOfParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
in 69
class com/microsoft/aad/msal4j/IEnvironmentVariables 52 interface,abstract java/lang/Object - -
 method public,abstract getEnvironmentVariable (Ljava/lang/String;)Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/IHttpClient 52 public,interface,abstract java/lang/Object - -
 method public,abstract send (Lcom/microsoft/aad/msal4j/HttpRequest;)Lcom/microsoft/aad/msal4j/IHttpResponse; - java/lang/Exception
in 69
class com/microsoft/aad/msal4j/IHttpHelper 52 interface,abstract java/lang/Object - -
 method public,abstract executeHttpRequest (Lcom/microsoft/aad/msal4j/HttpRequest;Lcom/microsoft/aad/msal4j/RequestContext;Lcom/microsoft/aad/msal4j/ServiceBundle;)Lcom/microsoft/aad/msal4j/IHttpResponse; - -
in 69
class com/microsoft/aad/msal4j/IHttpResponse 52 public,interface,abstract java/lang/Object - -
 method public,abstract statusCode ()I - -
 method public,abstract headers ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
 method public,abstract body ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/IMDSManagedIdentitySource 52 super com/microsoft/aad/msal4j/AbstractManagedIdentitySource - -
 method public <init> (Lcom/microsoft/aad/msal4j/MsalRequest;Lcom/microsoft/aad/msal4j/ServiceBundle;)V - -
 method public createManagedIdentityRequest (Ljava/lang/String;)V - -
 method public handleResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;Lcom/microsoft/aad/msal4j/IHttpResponse;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
in 2
class com/microsoft/aad/msal4j/IMDSRetryPolicy 52 super com/microsoft/aad/msal4j/ManagedIdentityRetryPolicy - -
 method public isRetryable (Lcom/microsoft/aad/msal4j/IHttpResponse;)Z - -
 method public getMaxRetryCount (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
 method public getRetryDelayMs (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
in 69
class com/microsoft/aad/msal4j/IManagedIdentityApplication 52 public,interface,abstract java/lang/Object com/microsoft/aad/msal4j/IApplicationBase -
 method public,abstract acquireTokenForManagedIdentity (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/lang/Exception
in 69
class com/microsoft/aad/msal4j/IPublicClientApplication 52 public,interface,abstract java/lang/Object com/microsoft/aad/msal4j/IClientApplicationBase -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public,abstract acquireToken (Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
in 2
class com/microsoft/aad/msal4j/IRetryPolicy 52 interface,abstract java/lang/Object - -
 method public,abstract isRetryable (Lcom/microsoft/aad/msal4j/IHttpResponse;)Z - -
 method public,abstract getMaxRetryCount (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
 method public,abstract getRetryDelayMs (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
in 69
class com/microsoft/aad/msal4j/ITelemetry 52 interface,abstract java/lang/Object - -
 method public,abstract startEvent (Ljava/lang/String;Lcom/microsoft/aad/msal4j/Event;)V - -
 method public,abstract stopEvent (Ljava/lang/String;Lcom/microsoft/aad/msal4j/Event;)V - -
 method public,abstract flush (Ljava/lang/String;Ljava/lang/String;)V - -
in 69
class com/microsoft/aad/msal4j/ITelemetryManager 52 interface,abstract java/lang/Object - -
 method public,abstract generateRequestId ()Ljava/lang/String; - -
 method public,abstract createTelemetryHelper (Ljava/lang/String;Ljava/lang/String;Lcom/microsoft/aad/msal4j/Event;Ljava/lang/Boolean;)Lcom/microsoft/aad/msal4j/TelemetryHelper; - -
in 69
class com/microsoft/aad/msal4j/ITenantProfile 52 public,interface,abstract java/lang/Object java/io/Serializable -
 method public,abstract getClaims ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
 method public,abstract environment ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/ITokenCache 52 public,interface,abstract java/lang/Object - -
 method public,abstract deserialize (Ljava/lang/String;)V - -
 method public,abstract serialize ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/ITokenCacheAccessAspect 52 public,interface,abstract java/lang/Object - -
 method public,abstract beforeCacheAccess (Lcom/microsoft/aad/msal4j/ITokenCacheAccessContext;)V - -
 method public,abstract afterCacheAccess (Lcom/microsoft/aad/msal4j/ITokenCacheAccessContext;)V - -
in 69
class com/microsoft/aad/msal4j/ITokenCacheAccessContext 52 public,interface,abstract java/lang/Object - -
 method public,abstract tokenCache ()Lcom/microsoft/aad/msal4j/ITokenCache; - -
 method public,abstract clientId ()Ljava/lang/String; - -
 method public,abstract account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public,abstract hasCacheChanged ()Z - -
in 69
class com/microsoft/aad/msal4j/IUserAssertion 52 public,interface,abstract java/lang/Object - -
 method public,abstract getAssertion ()Ljava/lang/String; - -
 method public,abstract getAssertionHash ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/IdToken 52 super java/lang/Object java/io/Serializable -
 field protected issuer Ljava/lang/String; -
 field protected subject Ljava/lang/String; -
 field protected audience Ljava/lang/String; -
 field protected expirationTime Ljava/lang/Long; -
 field protected issuedAt Ljava/lang/Long; -
 field protected notBefore Ljava/lang/Long; -
 field protected name Ljava/lang/String; -
 field protected preferredUsername Ljava/lang/String; -
 field protected objectIdentifier Ljava/lang/String; -
 field protected tenantIdentifier Ljava/lang/String; -
 field protected upn Ljava/lang/String; -
 field protected uniqueName Ljava/lang/String; -
in 2
class com/microsoft/aad/msal4j/IdToken 52 super java/lang/Object java/io/Serializable,com/azure/json/JsonSerializable Ljava/lang/Object;Ljava/io/Serializable;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/IdToken;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected issuer Ljava/lang/String; -
 field protected subject Ljava/lang/String; -
 field protected audience Ljava/lang/String; -
 field protected expirationTime Ljava/lang/Long; -
 field protected issuedAt Ljava/lang/Long; -
 field protected notBefore Ljava/lang/Long; -
 field protected name Ljava/lang/String; -
 field protected preferredUsername Ljava/lang/String; -
 field protected objectIdentifier Ljava/lang/String; -
 field protected tenantIdentifier Ljava/lang/String; -
 field protected upn Ljava/lang/String; -
 field protected uniqueName Ljava/lang/String; -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 21
class com/microsoft/aad/msal4j/IdTokenCacheEntity 52 super com/microsoft/aad/msal4j/Credential - -
 field protected realm Ljava/lang/String; -
 method public credentialType ()Ljava/lang/String; - -
 method public realm ()Ljava/lang/String; - -
 method public credentialType (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IdTokenCacheEntity; - -
 method public realm (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IdTokenCacheEntity; - -
in 2
class com/microsoft/aad/msal4j/IdTokenCacheEntity 52 super com/microsoft/aad/msal4j/Credential - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected realm Ljava/lang/String; -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/IllegalArgumentExceptionMessages 52 super java/lang/Object - -
in 21
class com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry InstanceDiscoveryMetadataEntryBuilder public,static
 method public,static builder ()Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder; - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;)V (Ljava/lang/String;Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;)V -
in 2
class com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;)V (Ljava/lang/String;Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public <init> ()V - -
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 21
class com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder com/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry InstanceDiscoveryMetadataEntryBuilder public,static
 method public preferredNetwork (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder; - -
 method public preferredCache (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder; - -
 method public aliases (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry$InstanceDiscoveryMetadataEntryBuilder; -
 method public build ()Lcom/microsoft/aad/msal4j/InstanceDiscoveryMetadataEntry; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder com/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters IntegratedWindowsAuthenticationParametersBuilder public,static
 method public,static builder (Ljava/util/Set;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public username ()Ljava/lang/String; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder com/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters IntegratedWindowsAuthenticationParametersBuilder public,static
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; -
 method public username (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters$IntegratedWindowsAuthenticationParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/IntegratedWindowsAuthenticationRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 69
class com/microsoft/aad/msal4j/IntegratedWindowsAuthorizationGrant 52 super com/microsoft/aad/msal4j/AbstractMsalAuthorizationGrant - -
in 69
class com/microsoft/aad/msal4j/InteractionRequiredCache 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/InteractionRequiredCache$CachedEntity com/microsoft/aad/msal4j/InteractionRequiredCache CachedEntity private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 69
class com/microsoft/aad/msal4j/InteractionRequiredCache$CachedEntity 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/InteractionRequiredCache$CachedEntity com/microsoft/aad/msal4j/InteractionRequiredCache CachedEntity private,static
 method public <init> (Lcom/microsoft/aad/msal4j/MsalInteractionRequiredException;J)V - -
in 69
class com/microsoft/aad/msal4j/InteractionRequiredExceptionReason 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason;>;
 field public,static,final,enum NONE Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; -
 field public,static,final,enum MESSAGE_ONLY Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; -
 field public,static,final,enum BASIC_ACTION Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; -
 field public,static,final,enum ADDITIONAL_ACTION Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; -
 field public,static,final,enum CONSENT_REQUIRED Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; -
 field public,static,final,enum USER_PASSWORD_EXPIRED Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; - -
in 69
class com/microsoft/aad/msal4j/InteractiveRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
 inner com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters$Builder com/microsoft/aad/msal4j/AuthorizationRequestUrlParameters Builder public,static
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
in 69
class com/microsoft/aad/msal4j/InteractiveRequestParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder com/microsoft/aad/msal4j/InteractiveRequestParameters InteractiveRequestParametersBuilder public,static
 method public,static builder (Ljava/net/URI;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public redirectUri ()Ljava/net/URI; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public prompt ()Lcom/microsoft/aad/msal4j/Prompt; - -
 method public loginHint ()Ljava/lang/String; - -
 method public domainHint ()Ljava/lang/String; - -
 method public systemBrowserOptions ()Lcom/microsoft/aad/msal4j/SystemBrowserOptions; - -
 method public claimsChallenge ()Ljava/lang/String; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public httpPollingTimeoutInSeconds ()I - -
 method public instanceAware ()Z - -
 method public windowHandle ()J - -
 method public proofOfPossession ()Lcom/microsoft/aad/msal4j/PopParameters; - -
in 69
class com/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder com/microsoft/aad/msal4j/InteractiveRequestParameters InteractiveRequestParametersBuilder public,static
 method public proofOfPossession (Lcom/microsoft/aad/msal4j/HttpMethod;Ljava/net/URI;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public redirectUri (Ljava/net/URI;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; -
 method public prompt (Lcom/microsoft/aad/msal4j/Prompt;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public loginHint (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public domainHint (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public systemBrowserOptions (Lcom/microsoft/aad/msal4j/SystemBrowserOptions;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public claimsChallenge (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public httpPollingTimeoutInSeconds (I)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public instanceAware (Z)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public windowHandle (J)Lcom/microsoft/aad/msal4j/InteractiveRequestParameters$InteractiveRequestParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/InteractiveRequestParameters; - -
 method public toString ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/JsonHelper 52 super java/lang/Object - -
 inner com/fasterxml/jackson/core/JsonParser$Feature com/fasterxml/jackson/core/JsonParser Feature public,static,final,enum
 inner com/fasterxml/jackson/annotation/JsonInclude$Include com/fasterxml/jackson/annotation/JsonInclude Include public,static,final,enum
 method public,static formCapabilitiesJson (Ljava/util/Set;)Ljava/lang/String; (Ljava/util/Set<Ljava/lang/String;>;)Ljava/lang/String; -
in 2
class com/microsoft/aad/msal4j/JsonHelper 52 super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/util/Base64$Decoder java/util/Base64 Decoder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static formCapabilitiesJson (Ljava/util/Set;)Ljava/lang/String; (Ljava/util/Set<Ljava/lang/String;>;)Ljava/lang/String; -
in 21
class com/microsoft/aad/msal4j/JwtHelper 52 final,super java/lang/Object - -
 inner com/nimbusds/jose/JWSHeader$Builder com/nimbusds/jose/JWSHeader Builder public,static
 inner com/nimbusds/jwt/JWTClaimsSet$Builder com/nimbusds/jwt/JWTClaimsSet Builder public,static
in 2
class com/microsoft/aad/msal4j/JwtHelper 52 final,super java/lang/Object - -
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
in 69
class com/microsoft/aad/msal4j/LogHelper 52 final,super java/lang/Object - -
in 70
class com/microsoft/aad/msal4j/ManagedIdentityApplication 52 public,super com/microsoft/aad/msal4j/AbstractApplicationBase com/microsoft/aad/msal4j/IManagedIdentityApplication -
 inner com/microsoft/aad/msal4j/ManagedIdentityApplication$Builder com/microsoft/aad/msal4j/ManagedIdentityApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public acquireTokenForManagedIdentity (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/lang/Exception
 method public,static builder (Lcom/microsoft/aad/msal4j/ManagedIdentityId;)Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; - -
 method public getManagedIdentityId ()Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public,static getSharedTokenCache ()Lcom/microsoft/aad/msal4j/TokenCache; - -
in 26
class com/microsoft/aad/msal4j/ManagedIdentityApplication 52 public,super com/microsoft/aad/msal4j/AbstractApplicationBase com/microsoft/aad/msal4j/IManagedIdentityApplication -
 inner com/microsoft/aad/msal4j/ManagedIdentityApplication$Builder com/microsoft/aad/msal4j/ManagedIdentityApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public acquireTokenForManagedIdentity (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/lang/Exception
 method public,static builder (Lcom/microsoft/aad/msal4j/ManagedIdentityId;)Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; - -
 method public,static getManagedIdentitySource ()Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; - -
 method public getManagedIdentityId ()Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public,static getSharedTokenCache ()Lcom/microsoft/aad/msal4j/TokenCache; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityApplication 52 public,super com/microsoft/aad/msal4j/AbstractApplicationBase com/microsoft/aad/msal4j/IManagedIdentityApplication -
 inner com/microsoft/aad/msal4j/ManagedIdentityApplication$Builder com/microsoft/aad/msal4j/ManagedIdentityApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public,static getSharedTokenCache ()Lcom/microsoft/aad/msal4j/TokenCache; - -
 method public getManagedIdentityId ()Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public getClientCapabilities ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public acquireTokenForManagedIdentity (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/lang/Exception
 method public,static builder (Lcom/microsoft/aad/msal4j/ManagedIdentityId;)Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; - -
 method public,static getManagedIdentitySource ()Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; - -
in 21
class com/microsoft/aad/msal4j/ManagedIdentityApplication$Builder 52 public,super com/microsoft/aad/msal4j/AbstractApplicationBase$Builder - Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder<Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder;>;
 inner com/microsoft/aad/msal4j/ManagedIdentityApplication$Builder com/microsoft/aad/msal4j/ManagedIdentityApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public resource (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; - -
 method public build ()Lcom/microsoft/aad/msal4j/ManagedIdentityApplication; - -
 method protected self ()Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityApplication$Builder 52 public,super com/microsoft/aad/msal4j/AbstractApplicationBase$Builder - Lcom/microsoft/aad/msal4j/AbstractApplicationBase$Builder<Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder;>;
 inner com/microsoft/aad/msal4j/ManagedIdentityApplication$Builder com/microsoft/aad/msal4j/ManagedIdentityApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public resource (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; - -
 method public clientCapabilities (Ljava/util/List;)Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; (Ljava/util/List<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; -
 method public build ()Lcom/microsoft/aad/msal4j/ManagedIdentityApplication; - -
 method protected self ()Lcom/microsoft/aad/msal4j/ManagedIdentityApplication$Builder; - -
in 69
class com/microsoft/aad/msal4j/ManagedIdentityClient 52 super java/lang/Object - -
in 21
class com/microsoft/aad/msal4j/ManagedIdentityErrorResponse 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/ManagedIdentityErrorResponse$ErrorField com/microsoft/aad/msal4j/ManagedIdentityErrorResponse ErrorField private,static
 method public <init> ()V - -
 method public getMessage ()Ljava/lang/String; - -
 method public getCorrelationId ()Ljava/lang/String; - -
 method public getError ()Ljava/lang/String; - -
 method public getErrorDescription ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityErrorResponse 52 public,super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/ManagedIdentityErrorResponse;>;
 inner com/microsoft/aad/msal4j/ManagedIdentityErrorResponse$ErrorField com/microsoft/aad/msal4j/ManagedIdentityErrorResponse ErrorField private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/ManagedIdentityErrorResponse; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public getMessage ()Ljava/lang/String; - -
 method public getCorrelationId ()Ljava/lang/String; - -
 method public getError ()Ljava/lang/String; - -
 method public getErrorDescription ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/ManagedIdentityErrorResponse$ErrorField 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/ManagedIdentityErrorResponse$ErrorField com/microsoft/aad/msal4j/ManagedIdentityErrorResponse ErrorField private,static
 method public getCode ()Ljava/lang/String; - -
 method public getMessage ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityErrorResponse$ErrorField 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/ManagedIdentityErrorResponse$ErrorField com/microsoft/aad/msal4j/ManagedIdentityErrorResponse ErrorField private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 70
class com/microsoft/aad/msal4j/ManagedIdentityId 52 public,super java/lang/Object - -
 method public,static systemAssigned ()Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public,static userAssignedClientId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public,static userAssignedResourceId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public getUserAssignedId ()Ljava/lang/String; - -
 method public getIdType ()Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; - -
in 28
class com/microsoft/aad/msal4j/ManagedIdentityId 52 public,super java/lang/Object - -
 method public,static systemAssigned ()Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public,static userAssignedClientId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public,static userAssignedResourceId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public,static userAssignedObjectId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityId; - -
 method public getUserAssignedId ()Ljava/lang/String; - -
 method public getIdType ()Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; - -
in 70
class com/microsoft/aad/msal4j/ManagedIdentityIdType 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/ManagedIdentityIdType;>;
 field public,static,final,enum SYSTEM_ASSIGNED Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; -
 field public,static,final,enum CLIENT_ID Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; -
 field public,static,final,enum RESOURCE_ID Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; - -
in 28
class com/microsoft/aad/msal4j/ManagedIdentityIdType 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/ManagedIdentityIdType;>;
 field public,static,final,enum SYSTEM_ASSIGNED Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; -
 field public,static,final,enum CLIENT_ID Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; -
 field public,static,final,enum RESOURCE_ID Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; -
 field public,static,final,enum OBJECT_ID Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityIdType; - -
in 70
class com/microsoft/aad/msal4j/ManagedIdentityParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder com/microsoft/aad/msal4j/ManagedIdentityParameters ManagedIdentityParametersBuilder public,static
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static builder (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public forceRefresh ()Z - -
 method public environmentVariables ()Lcom/microsoft/aad/msal4j/IEnvironmentVariables; - -
 method public resource ()Ljava/lang/String; - -
in 26
class com/microsoft/aad/msal4j/ManagedIdentityParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder com/microsoft/aad/msal4j/ManagedIdentityParameters ManagedIdentityParametersBuilder public,static
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static builder (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public forceRefresh ()Z - -
 method public resource ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder com/microsoft/aad/msal4j/ManagedIdentityParameters ManagedIdentityParametersBuilder public,static
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static builder (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public forceRefresh ()Z - -
 method public resource ()Ljava/lang/String; - -
 method public revokedTokenHash ()Ljava/lang/String; - -
in 70
class com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder com/microsoft/aad/msal4j/ManagedIdentityParameters ManagedIdentityParametersBuilder public,static
 method public resource (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public forceRefresh (Z)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public environmentVariables (Lcom/microsoft/aad/msal4j/IEnvironmentVariables;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/ManagedIdentityParameters; - -
 method public toString ()Ljava/lang/String; - -
in 26
class com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder com/microsoft/aad/msal4j/ManagedIdentityParameters ManagedIdentityParametersBuilder public,static
 method public resource (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public forceRefresh (Z)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/ManagedIdentityParameters; - -
 method public toString ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder com/microsoft/aad/msal4j/ManagedIdentityParameters ManagedIdentityParametersBuilder public,static
 method public resource (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public forceRefresh (Z)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public claims (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentityParameters$ManagedIdentityParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/ManagedIdentityParameters; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/ManagedIdentityRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
 method public <init> (Lcom/microsoft/aad/msal4j/ManagedIdentityApplication;Lcom/microsoft/aad/msal4j/RequestContext;)V - -
 method public getBodyAsString ()Ljava/lang/String; - -
 method public computeURI ()Ljava/net/URL; - java/net/URISyntaxException
in 21
class com/microsoft/aad/msal4j/ManagedIdentityResponse 52 super java/lang/Object - -
 method public getTokenType ()Ljava/lang/String; - -
 method public getAccessToken ()Ljava/lang/String; - -
 method public getExpiresOn ()Ljava/lang/String; - -
 method public getResource ()Ljava/lang/String; - -
 method public getClientId ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityResponse 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/ManagedIdentityResponse;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public getTokenType ()Ljava/lang/String; - -
 method public getAccessToken ()Ljava/lang/String; - -
 method public getExpiresOn ()Ljava/lang/String; - -
 method public getResource ()Ljava/lang/String; - -
 method public getClientId ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/ManagedIdentityRetryPolicy 52 super java/lang/Object com/microsoft/aad/msal4j/IRetryPolicy -
 method public isRetryable (Lcom/microsoft/aad/msal4j/IHttpResponse;)Z - -
 method public getMaxRetryCount (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
 method public getRetryDelayMs (Lcom/microsoft/aad/msal4j/IHttpResponse;)I - -
in 70
class com/microsoft/aad/msal4j/ManagedIdentitySourceType 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType;>;
 field public,static,final,enum NONE Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum IMDS Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum APP_SERVICE Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum AZURE_ARC Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum CLOUD_SHELL Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum SERVICE_FABRIC Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; - -
in 28
class com/microsoft/aad/msal4j/ManagedIdentitySourceType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType;>;
 field public,static,final,enum NONE Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum IMDS Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum APP_SERVICE Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum AZURE_ARC Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum CLOUD_SHELL Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum SERVICE_FABRIC Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 field public,static,final,enum DEFAULT_TO_IMDS Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType; - -
in 69
class com/microsoft/aad/msal4j/MexParser 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/MexParser$WsTrustEndpointPolicySelector com/microsoft/aad/msal4j/MexParser WsTrustEndpointPolicySelector private,static
 inner com/microsoft/aad/msal4j/MexParser$NegotiateAuthenticationPolicySelector com/microsoft/aad/msal4j/MexParser NegotiateAuthenticationPolicySelector private,static
 inner com/microsoft/aad/msal4j/MexParser$PolicySelector com/microsoft/aad/msal4j/MexParser PolicySelector private,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
in 69
class com/microsoft/aad/msal4j/MexParser$NegotiateAuthenticationPolicySelector 52 super java/lang/Object com/microsoft/aad/msal4j/MexParser$PolicySelector -
 inner com/microsoft/aad/msal4j/MexParser$NegotiateAuthenticationPolicySelector com/microsoft/aad/msal4j/MexParser NegotiateAuthenticationPolicySelector private,static
 inner com/microsoft/aad/msal4j/MexParser$PolicySelector com/microsoft/aad/msal4j/MexParser PolicySelector private,static,interface,abstract
 method public selectPolicies (Lorg/w3c/dom/Document;Ljavax/xml/xpath/XPath;Z)Ljava/util/Map; (Lorg/w3c/dom/Document;Ljavax/xml/xpath/XPath;Z)Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/BindingPolicy;>; javax/xml/xpath/XPathExpressionException
in 69
class com/microsoft/aad/msal4j/MexParser$PolicySelector 52 interface,abstract java/lang/Object - -
 inner com/microsoft/aad/msal4j/MexParser$PolicySelector com/microsoft/aad/msal4j/MexParser PolicySelector private,static,interface,abstract
 method public,abstract selectPolicies (Lorg/w3c/dom/Document;Ljavax/xml/xpath/XPath;Z)Ljava/util/Map; (Lorg/w3c/dom/Document;Ljavax/xml/xpath/XPath;Z)Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/BindingPolicy;>; javax/xml/xpath/XPathExpressionException
in 69
class com/microsoft/aad/msal4j/MexParser$WsTrustEndpointPolicySelector 52 super java/lang/Object com/microsoft/aad/msal4j/MexParser$PolicySelector -
 inner com/microsoft/aad/msal4j/MexParser$WsTrustEndpointPolicySelector com/microsoft/aad/msal4j/MexParser WsTrustEndpointPolicySelector private,static
 inner com/microsoft/aad/msal4j/MexParser$PolicySelector com/microsoft/aad/msal4j/MexParser PolicySelector private,static,interface,abstract
 method public selectPolicies (Lorg/w3c/dom/Document;Ljavax/xml/xpath/XPath;Z)Ljava/util/Map; (Lorg/w3c/dom/Document;Ljavax/xml/xpath/XPath;Z)Ljava/util/Map<Ljava/lang/String;Lcom/microsoft/aad/msal4j/BindingPolicy;>; javax/xml/xpath/XPathExpressionException
in 69
class com/microsoft/aad/msal4j/MsalAzureSDKException 52 public,super com/microsoft/aad/msal4j/MsalException - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 69
class com/microsoft/aad/msal4j/MsalClientException 52 public,super com/microsoft/aad/msal4j/MsalException - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 21
class com/microsoft/aad/msal4j/MsalError 52 public,super java/lang/Object - -
 field public,static,final INVALID_MANAGED_IDENTITY_ENDPOINT Ljava/lang/String; - "invalid_managed_identity_endpoint"
 field public,static,final USER_ASSIGNED_MANAGED_IDENTITY_NOT_SUPPORTED Ljava/lang/String; - "user_assigned_managed_identity_not_supported"
 field public,static,final MANAGED_IDENTITY_REQUEST_FAILED Ljava/lang/String; - "managed_identity_request_failed"
 field public,static,final RESOURCE_REQUIRED_MANAGED_IDENTITY Ljava/lang/String; - "resource_required_managed_identity"
 field public,static,final MANAGED_IDENTITY_UNREACHABLE_NETWORK Ljava/lang/String; - "managed_identity_unreachable_network"
 field public,static,final MANAGED_IDENTITY_FILE_READ_ERROR Ljava/lang/String; - "managed_identity_file_read_error"
 method public <init> ()V - -
in 2
class com/microsoft/aad/msal4j/MsalError 52 public,super java/lang/Object - -
 field public,static,final INVALID_MANAGED_IDENTITY_ENDPOINT Ljava/lang/String; - "invalid_managed_identity_endpoint"
 field public,static,final USER_ASSIGNED_MANAGED_IDENTITY_NOT_SUPPORTED Ljava/lang/String; - "user_assigned_managed_identity_not_supported"
 field public,static,final MANAGED_IDENTITY_REQUEST_FAILED Ljava/lang/String; - "managed_identity_request_failed"
 field public,static,final RESOURCE_REQUIRED_MANAGED_IDENTITY Ljava/lang/String; - "resource_required_managed_identity"
 field public,static,final MANAGED_IDENTITY_UNREACHABLE_NETWORK Ljava/lang/String; - "managed_identity_unreachable_network"
 field public,static,final MANAGED_IDENTITY_FILE_READ_ERROR Ljava/lang/String; - "managed_identity_file_read_error"
 field public,static,final MANAGED_IDENTITY_RESPONSE_PARSE_FAILURE Ljava/lang/String; - "managed_identity_response_parse_failure"
 method public <init> ()V - -
in 70
class com/microsoft/aad/msal4j/MsalErrorMessage 52 super java/lang/Object - -
 field public,static,final MANAGED_IDENTITY_ENDPOINT_INVALID_URI_ERROR Ljava/lang/String; - "[Managed Identity] The environment variable %s contains an invalid Uri %s in %s managed identity source."
 field public,static,final MANAGED_IDENTITY_NO_CHALLENGE_ERROR Ljava/lang/String; - "[Managed Identity] Did not receive expected WWW-Authenticate header in the response from Azure Arc Managed Identity Endpoint."
 field public,static,final MANAGED_IDENTITY_INVALID_CHALLENGE Ljava/lang/String; - "[Managed Identity] The WWW-Authenticate header in the response from Azure Arc Managed Identity Endpoint did not match the expected format."
 field public,static,final MANAGED_IDENTITY_USER_ASSIGNED_NOT_CONFIGURABLE_AT_RUNTIME Ljava/lang/String; - "[Managed Identity] Service Fabric user assigned managed identity ClientId or ResourceId is not configurable at runtime."
 field public,static,final MANAGED_IDENTITY_USER_ASSIGNED_NOT_SUPPORTED Ljava/lang/String; - "[Managed Identity] User assigned identity is not supported by the %s Managed Identity. To authenticate with the system assigned identity use ManagedIdentityApplication.builder(ManagedIdentityId.systemAssigned()).build()."
 field public,static,final SCOPES_REQUIRED Ljava/lang/String; - "At least one scope needs to be requested for this authentication flow. "
 field public,static,final DEFAULT_MESSAGE Ljava/lang/String; - "[Managed Identity] Service request failed."
 field public,static,final IDENTITY_UNAVAILABLE_ERROR Ljava/lang/String; - "[Managed Identity] Authentication unavailable. The requested identity has not been assigned to this resource."
 field public,static,final GATEWAY_ERROR Ljava/lang/String; - "[Managed Identity] Authentication unavailable. The request failed due to a gateway error."
in 26
class com/microsoft/aad/msal4j/MsalErrorMessage 52 super java/lang/Object - -
 field public,static,final MANAGED_IDENTITY_ENDPOINT_INVALID_URI_ERROR Ljava/lang/String; - "[Managed Identity] The environment variable %s contains an invalid Uri %s in %s managed identity source."
 field public,static,final MANAGED_IDENTITY_NO_CHALLENGE_ERROR Ljava/lang/String; - "[Managed Identity] Did not receive expected WWW-Authenticate header in the response from Azure Arc Managed Identity Endpoint."
 field public,static,final MANAGED_IDENTITY_INVALID_CHALLENGE Ljava/lang/String; - "[Managed Identity] The WWW-Authenticate header in the response from Azure Arc Managed Identity Endpoint did not match the expected format."
 field public,static,final MANAGED_IDENTITY_PLATFORM_NOT_SUPPORTED Ljava/lang/String; - "[Managed Identity] This managed identity source is not available on this platform."
 field public,static,final MANAGED_IDENTITY_INVALID_FILEPATH Ljava/lang/String; - "[Managed Identity] The file on the file path in the WWW-Authenticate header is not secure or could not be found."
 field public,static,final MANAGED_IDENTITY_USER_ASSIGNED_NOT_CONFIGURABLE_AT_RUNTIME Ljava/lang/String; - "[Managed Identity] Service Fabric user assigned managed identity ClientId or ResourceId is not configurable at runtime."
 field public,static,final MANAGED_IDENTITY_USER_ASSIGNED_NOT_SUPPORTED Ljava/lang/String; - "[Managed Identity] User assigned identity is not supported by the %s Managed Identity. To authenticate with the system assigned identity use ManagedIdentityApplication.builder(ManagedIdentityId.systemAssigned()).build()."
 field public,static,final SCOPES_REQUIRED Ljava/lang/String; - "At least one scope needs to be requested for this authentication flow. "
 field public,static,final DEFAULT_MESSAGE Ljava/lang/String; - "[Managed Identity] Service request failed."
 field public,static,final IDENTITY_UNAVAILABLE_ERROR Ljava/lang/String; - "[Managed Identity] Authentication unavailable. The requested identity has not been assigned to this resource."
 field public,static,final GATEWAY_ERROR Ljava/lang/String; - "[Managed Identity] Authentication unavailable. The request failed due to a gateway error."
in 2
class com/microsoft/aad/msal4j/MsalErrorMessage 52 super java/lang/Object - -
 field public,static,final MANAGED_IDENTITY_ENDPOINT_INVALID_URI_ERROR Ljava/lang/String; - "[Managed Identity] The environment variable %s contains an invalid Uri %s in %s managed identity source."
 field public,static,final MANAGED_IDENTITY_NO_CHALLENGE_ERROR Ljava/lang/String; - "[Managed Identity] Did not receive expected WWW-Authenticate header in the response from Azure Arc Managed Identity Endpoint."
 field public,static,final MANAGED_IDENTITY_INVALID_CHALLENGE Ljava/lang/String; - "[Managed Identity] The WWW-Authenticate header in the response from Azure Arc Managed Identity Endpoint did not match the expected format."
 field public,static,final MANAGED_IDENTITY_PLATFORM_NOT_SUPPORTED Ljava/lang/String; - "[Managed Identity] This managed identity source is not available on this platform."
 field public,static,final MANAGED_IDENTITY_INVALID_FILEPATH Ljava/lang/String; - "[Managed Identity] The file on the file path in the WWW-Authenticate header is not secure or could not be found."
 field public,static,final MANAGED_IDENTITY_USER_ASSIGNED_NOT_CONFIGURABLE_AT_RUNTIME Ljava/lang/String; - "[Managed Identity] Service Fabric user assigned managed identity ClientId or ResourceId is not configurable at runtime."
 field public,static,final MANAGED_IDENTITY_USER_ASSIGNED_NOT_SUPPORTED Ljava/lang/String; - "[Managed Identity] User assigned identity is not supported by the %s Managed Identity. To authenticate with the system assigned identity use ManagedIdentityApplication.builder(ManagedIdentityId.systemAssigned()).build()."
 field public,static,final SCOPES_REQUIRED Ljava/lang/String; - "At least one scope needs to be requested for this authentication flow. "
 field public,static,final DEFAULT_MESSAGE Ljava/lang/String; - "[Managed Identity] Service request failed."
 field public,static,final IDENTITY_UNAVAILABLE_ERROR Ljava/lang/String; - "[Managed Identity] Authentication unavailable. The requested identity has not been assigned to this resource."
 field public,static,final GATEWAY_ERROR Ljava/lang/String; - "[Managed Identity] Authentication unavailable. The request failed due to a gateway error."
 field public,static,final MANAGED_IDENTITY_RESPONSE_PARSE_FAILURE Ljava/lang/String; - "[Managed Identity] MSI returned %s, but the response could not be parsed: %s"
in 69
class com/microsoft/aad/msal4j/MsalException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public errorCode ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/MsalInteractionRequiredException 52 public,super com/microsoft/aad/msal4j/MsalServiceException - -
 method public <init> (Lcom/microsoft/aad/msal4j/ErrorResponse;Ljava/util/Map;)V (Lcom/microsoft/aad/msal4j/ErrorResponse;Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;)V -
 method public reason ()Lcom/microsoft/aad/msal4j/InteractionRequiredExceptionReason; - -
in 2
class com/microsoft/aad/msal4j/MsalJsonParsingException 52 public,super com/microsoft/aad/msal4j/MsalServiceException - -
in 21
class com/microsoft/aad/msal4j/MsalRequest 52 super,abstract java/lang/Object - -
 method public <init> (Lcom/microsoft/aad/msal4j/AbstractMsalAuthorizationGrant;Lcom/microsoft/aad/msal4j/AbstractApplicationBase;Lcom/microsoft/aad/msal4j/RequestContext;)V - -
in 2
class com/microsoft/aad/msal4j/MsalRequest 52 super,abstract java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/MsalServiceException 52 public,super com/microsoft/aad/msal4j/MsalException - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> (Lcom/microsoft/aad/msal4j/ErrorResponse;Ljava/util/Map;)V (Lcom/microsoft/aad/msal4j/ErrorResponse;Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lcom/microsoft/aad/msal4j/ManagedIdentitySourceType;)V - -
 method public <init> (Lcom/microsoft/aad/msal4j/AadInstanceDiscoveryResponse;)V - -
 method public statusCode ()Ljava/lang/Integer; - -
 method public statusMessage ()Ljava/lang/String; - -
 method public correlationId ()Ljava/lang/String; - -
 method public claims ()Ljava/lang/String; - -
 method public headers ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
 method public managedIdentitySource ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/MsalServiceExceptionFactory 52 super java/lang/Object - -
in 2
class com/microsoft/aad/msal4j/MsalServiceExceptionFactory 52 super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 69
class com/microsoft/aad/msal4j/MsalThrottlingException 52 public,super com/microsoft/aad/msal4j/MsalServiceException - -
 method public <init> (J)V - -
 method public retryInMs ()J - -
in 69
class com/microsoft/aad/msal4j/NamespaceContextImpl 52 super java/lang/Object javax/xml/namespace/NamespaceContext -
 method public modifyNameSpace (Ljava/lang/String;Ljava/lang/String;)V - -
 method public getNamespaceURI (Ljava/lang/String;)Ljava/lang/String; - -
 method public getPrefix (Ljava/lang/String;)Ljava/lang/String; - -
 method public getPrefixes (Ljava/lang/String;)Ljava/util/Iterator; - -
in 21
class com/microsoft/aad/msal4j/OAuthAuthorizationGrant 52 super com/microsoft/aad/msal4j/AbstractMsalAuthorizationGrant - -
 method public toParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
in 2
class com/microsoft/aad/msal4j/OAuthAuthorizationGrant 52 super com/microsoft/aad/msal4j/AbstractMsalAuthorizationGrant - -
 method public toParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
in 21
class com/microsoft/aad/msal4j/OAuthHttpRequest 52 super com/nimbusds/oauth2/sdk/http/HTTPRequest - -
 inner com/nimbusds/oauth2/sdk/http/HTTPRequest$Method com/nimbusds/oauth2/sdk/http/HTTPRequest Method public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public send ()Lcom/nimbusds/oauth2/sdk/http/HTTPResponse; - java/io/IOException
in 2
class com/microsoft/aad/msal4j/OAuthHttpRequest 52 super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public send ()Lcom/microsoft/aad/msal4j/HttpResponse; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/OSHelper 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/OSHelper$OSType com/microsoft/aad/msal4j/OSHelper OSType static,final,enum
 method public <init> ()V - -
 method public,static getOs ()Ljava/lang/String; - -
 method public,static isMac ()Z - -
 method public,static isWindows ()Z - -
 method public,static isLinux ()Z - -
in 69
class com/microsoft/aad/msal4j/OSHelper$OSType 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/OSHelper$OSType;>;
 inner com/microsoft/aad/msal4j/OSHelper$OSType com/microsoft/aad/msal4j/OSHelper OSType static,final,enum
 field public,static,final,enum MAC Lcom/microsoft/aad/msal4j/OSHelper$OSType; -
 field public,static,final,enum WINDOWS Lcom/microsoft/aad/msal4j/OSHelper$OSType; -
 field public,static,final,enum LINUX Lcom/microsoft/aad/msal4j/OSHelper$OSType; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/OSHelper$OSType; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/OSHelper$OSType; - -
in 28
class com/microsoft/aad/msal4j/OidcAuthority 52 public,super com/microsoft/aad/msal4j/Authority - -
in 26
class com/microsoft/aad/msal4j/OidcDiscoveryProvider 52 super java/lang/Object - -
in 2
class com/microsoft/aad/msal4j/OidcDiscoveryProvider 52 super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 26
class com/microsoft/aad/msal4j/OidcDiscoveryResponse 52 super java/lang/Object - -
in 2
class com/microsoft/aad/msal4j/OidcDiscoveryResponse 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/OidcDiscoveryResponse;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/OidcDiscoveryResponse; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/OnBehalfOfParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder com/microsoft/aad/msal4j/OnBehalfOfParameters OnBehalfOfParametersBuilder public,static
 method public,static builder (Ljava/util/Set;Lcom/microsoft/aad/msal4j/UserAssertion;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;Lcom/microsoft/aad/msal4j/UserAssertion;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public skipCache ()Ljava/lang/Boolean; - -
 method public userAssertion ()Lcom/microsoft/aad/msal4j/IUserAssertion; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder com/microsoft/aad/msal4j/OnBehalfOfParameters OnBehalfOfParametersBuilder public,static
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; -
 method public skipCache (Ljava/lang/Boolean;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; - -
 method public userAssertion (Lcom/microsoft/aad/msal4j/IUserAssertion;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/OnBehalfOfParameters$OnBehalfOfParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/OnBehalfOfParameters; - -
 method public toString ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/OnBehalfOfRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
 method public parameters ()Lcom/microsoft/aad/msal4j/OnBehalfOfParameters; - -
in 2
class com/microsoft/aad/msal4j/OnBehalfOfRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 69
class com/microsoft/aad/msal4j/OpenBrowserAction 52 public,interface,abstract java/lang/Object - -
 method public,abstract openBrowser (Ljava/net/URL;)V - -
in 69
class com/microsoft/aad/msal4j/ParameterValidationUtils 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/PopParameters 52 public,super java/lang/Object - -
 method public getHttpMethod ()Lcom/microsoft/aad/msal4j/HttpMethod; - -
 method public getUri ()Ljava/net/URI; - -
 method public getNonce ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/Prompt 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/Prompt;>;
 field public,static,final,enum LOGIN Lcom/microsoft/aad/msal4j/Prompt; -
 field public,static,final,enum SELECT_ACCOUNT Lcom/microsoft/aad/msal4j/Prompt; -
 field public,static,final,enum CONSENT Lcom/microsoft/aad/msal4j/Prompt; -
 field public,static,final,enum ADMIN_CONSENT Lcom/microsoft/aad/msal4j/Prompt; -
 field public,static,final,enum NONE Lcom/microsoft/aad/msal4j/Prompt; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/Prompt; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/Prompt; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/PublicApi 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/PublicApi;>;
 field public,static,final,enum ACQUIRE_TOKEN_BY_REFRESH_TOKEN Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_INTERACTIVE Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_BY_USERNAME_PASSWORD Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_BY_INTEGRATED_WINDOWS_AUTH Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_ON_BEHALF_OF Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_BY_DEVICE_CODE_FLOW Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_FOR_CLIENT Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_BY_AUTHORIZATION_CODE Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_SILENTLY Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum GET_ACCOUNTS Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum REMOVE_ACCOUNTS Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_BY_SYSTEM_ASSIGNED_MANAGED_IDENTITY Lcom/microsoft/aad/msal4j/PublicApi; -
 field public,static,final,enum ACQUIRE_TOKEN_BY_USER_ASSIGNED_MANAGED_IDENTITY Lcom/microsoft/aad/msal4j/PublicApi; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/PublicApi; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/PublicApi; - -
in 21
class com/microsoft/aad/msal4j/PublicClientApplication 52 public,super com/microsoft/aad/msal4j/AbstractClientApplicationBase com/microsoft/aad/msal4j/IPublicClientApplication -
 inner com/microsoft/aad/msal4j/PublicClientApplication$Builder com/microsoft/aad/msal4j/PublicClientApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 method public acquireToken (Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireTokenSilently (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/net/MalformedURLException
 method public removeAccount (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method protected clientAuthentication ()Lcom/nimbusds/oauth2/sdk/auth/ClientAuthentication; - -
 method public,static builder (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/PublicClientApplication$Builder; - -
in 2
class com/microsoft/aad/msal4j/PublicClientApplication 52 public,super com/microsoft/aad/msal4j/AbstractClientApplicationBase com/microsoft/aad/msal4j/IPublicClientApplication -
 inner com/microsoft/aad/msal4j/PublicClientApplication$Builder com/microsoft/aad/msal4j/PublicClientApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 method public acquireToken (Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/UserNamePasswordParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/IntegratedWindowsAuthenticationParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/DeviceCodeFlowParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireToken (Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/InteractiveRequestParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; -
 method public acquireTokenSilently (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/SilentParameters;)Ljava/util/concurrent/CompletableFuture<Lcom/microsoft/aad/msal4j/IAuthenticationResult;>; java/net/MalformedURLException
 method public removeAccount (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture; (Lcom/microsoft/aad/msal4j/IAccount;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public,static builder (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/PublicClientApplication$Builder; - -
in 69
class com/microsoft/aad/msal4j/PublicClientApplication$Builder 52 public,super com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder - Lcom/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder<Lcom/microsoft/aad/msal4j/PublicClientApplication$Builder;>;
 inner com/microsoft/aad/msal4j/PublicClientApplication$Builder com/microsoft/aad/msal4j/PublicClientApplication Builder public,static
 inner com/microsoft/aad/msal4j/AbstractClientApplicationBase$Builder com/microsoft/aad/msal4j/AbstractClientApplicationBase Builder public,static,abstract
 inner com/microsoft/aad/msal4j/AbstractApplicationBase$Builder com/microsoft/aad/msal4j/AbstractApplicationBase Builder public,static,abstract
 method public broker (Lcom/microsoft/aad/msal4j/IBroker;)Lcom/microsoft/aad/msal4j/PublicClientApplication$Builder; - -
 method public build ()Lcom/microsoft/aad/msal4j/PublicClientApplication; - -
 method protected self ()Lcom/microsoft/aad/msal4j/PublicClientApplication$Builder; - -
in 21
class com/microsoft/aad/msal4j/RefreshTokenCacheEntity 52 super com/microsoft/aad/msal4j/Credential - -
 method public credentialType ()Ljava/lang/String; - -
 method public family_id ()Ljava/lang/String; - -
 method public credentialType (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/RefreshTokenCacheEntity; - -
 method public family_id (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/RefreshTokenCacheEntity; - -
in 2
class com/microsoft/aad/msal4j/RefreshTokenCacheEntity 52 super com/microsoft/aad/msal4j/Credential - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/RefreshTokenParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder com/microsoft/aad/msal4j/RefreshTokenParameters RefreshTokenParametersBuilder public,static
 method public,static builder (Ljava/util/Set;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public refreshToken ()Ljava/lang/String; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder com/microsoft/aad/msal4j/RefreshTokenParameters RefreshTokenParametersBuilder public,static
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; -
 method public refreshToken (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/RefreshTokenParameters$RefreshTokenParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/RefreshTokenParameters; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/RefreshTokenRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 69
class com/microsoft/aad/msal4j/RegionTelemetry 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/RegionTelemetry;>;
 field public,static,final,enum REGION_SOURCE_FAILED_AUTODETECT Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_SOURCE_CACHE Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_SOURCE_ENV_VARIABLE Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_SOURCE_IMDS Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_OUTCOME_DEVELOPER_AUTODETECT_MATCH Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_OUTCOME_DEVELOPER_AUTODETECT_FAILED Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_OUTCOME_DEVELOPER_AUTODETECT_MISMATCH Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_OUTCOME_AUTODETECT_SUCCESS Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 field public,static,final,enum REGION_OUTCOME_AUTODETECT_FAILED Lcom/microsoft/aad/msal4j/RegionTelemetry; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/RegionTelemetry; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/RegionTelemetry; - -
in 69
class com/microsoft/aad/msal4j/RemoveAccountRunnable 52 super java/lang/Object java/lang/Runnable -
 method public run ()V - -
in 69
class com/microsoft/aad/msal4j/RequestContext 52 super java/lang/Object - -
 method public <init> (Lcom/microsoft/aad/msal4j/AbstractApplicationBase;Lcom/microsoft/aad/msal4j/PublicApi;Lcom/microsoft/aad/msal4j/IAcquireTokenParameters;)V - -
 method public <init> (Lcom/microsoft/aad/msal4j/AbstractApplicationBase;Lcom/microsoft/aad/msal4j/PublicApi;Lcom/microsoft/aad/msal4j/IAcquireTokenParameters;Lcom/microsoft/aad/msal4j/UserIdentifier;)V - -
in 21
class com/microsoft/aad/msal4j/RequestedClaim 52 public,super java/lang/Object - -
 inner com/fasterxml/jackson/annotation/JsonInclude$Include com/fasterxml/jackson/annotation/JsonInclude Include public,static,final,enum
 field public name Ljava/lang/String; -
 method protected any ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public <init> (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
in 2
class com/microsoft/aad/msal4j/RequestedClaim 52 public,super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/RequestedClaim;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public name Ljava/lang/String; -
 method public <init> (Ljava/lang/String;Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;)V - -
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method protected any ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
in 21
class com/microsoft/aad/msal4j/RequestedClaimAdditionalInfo 52 public,super java/lang/Object - -
 inner com/fasterxml/jackson/annotation/JsonInclude$Include com/fasterxml/jackson/annotation/JsonInclude Include public,static,final,enum
 method public isEssential ()Z - -
 method public getValue ()Ljava/lang/String; - -
 method public getValues ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public setEssential (Z)V - -
 method public setValue (Ljava/lang/String;)V - -
 method public setValues (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/String;>;)V -
 method public <init> (ZLjava/lang/String;Ljava/util/List;)V (ZLjava/lang/String;Ljava/util/List<Ljava/lang/String;>;)V -
in 2
class com/microsoft/aad/msal4j/RequestedClaimAdditionalInfo 52 public,super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo;>;
 method public <init> (ZLjava/lang/String;Ljava/util/List;)V (ZLjava/lang/String;Ljava/util/List<Ljava/lang/String;>;)V -
 method public fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/RequestedClaimAdditionalInfo; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
 method public isEssential ()Z - -
 method public getValue ()Ljava/lang/String; - -
 method public getValues ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public setEssential (Z)V - -
 method public setValue (Ljava/lang/String;)V - -
 method public setValues (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/String;>;)V -
in 69
class com/microsoft/aad/msal4j/ResponseMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/ResponseMode;>;
 field public,static,final,enum FORM_POST Lcom/microsoft/aad/msal4j/ResponseMode; -
 field public,static,final,enum QUERY Lcom/microsoft/aad/msal4j/ResponseMode; -
 field public,static,final,enum FRAGMENT Lcom/microsoft/aad/msal4j/ResponseMode; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/ResponseMode; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/ResponseMode; - -
 method public toString ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/SAML11BearerGrant 52 super com/nimbusds/oauth2/sdk/SAML2BearerGrant - -
 field public,static grantType Lcom/nimbusds/oauth2/sdk/GrantType; -
 method public <init> (Lcom/nimbusds/jose/util/Base64URL;)V - -
 method public toParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;>; -
in 69
class com/microsoft/aad/msal4j/SafeDocumentBuilderFactory 52 final,super java/lang/Object - -
 method public,static createInstance ()Ljavax/xml/parsers/DocumentBuilderFactory; - javax/xml/parsers/ParserConfigurationException
in 69
class com/microsoft/aad/msal4j/ServerSideTelemetry 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/ServiceBundle 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/ServiceFabricManagedIdentitySource 52 super com/microsoft/aad/msal4j/AbstractManagedIdentitySource - -
 method public createManagedIdentityRequest (Ljava/lang/String;)V - -
 method public getManagedIdentityResponse (Lcom/microsoft/aad/msal4j/ManagedIdentityParameters;)Lcom/microsoft/aad/msal4j/ManagedIdentityResponse; - -
in 21
class com/microsoft/aad/msal4j/SilentParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
 method public,static builder (Ljava/util/Set;Lcom/microsoft/aad/msal4j/IAccount;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;Lcom/microsoft/aad/msal4j/IAccount;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; -
 method public,static,deprecated builder (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public authorityUrl ()Ljava/lang/String; - -
 method public forceRefresh ()Z - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public proofOfPossession ()Lcom/microsoft/aad/msal4j/PopParameters; - -
in 2
class com/microsoft/aad/msal4j/SilentParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
 method public,static builder (Ljava/util/Set;Lcom/microsoft/aad/msal4j/IAccount;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;Lcom/microsoft/aad/msal4j/IAccount;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; -
 method public,static builder (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public authorityUrl ()Ljava/lang/String; - -
 method public forceRefresh ()Z - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public proofOfPossession ()Lcom/microsoft/aad/msal4j/PopParameters; - -
in 69
class com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder com/microsoft/aad/msal4j/SilentParameters SilentParametersBuilder public,static
 method public proofOfPossession (Lcom/microsoft/aad/msal4j/HttpMethod;Ljava/net/URI;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; - -
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; -
 method public account (Lcom/microsoft/aad/msal4j/IAccount;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; - -
 method public authorityUrl (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; - -
 method public forceRefresh (Z)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/SilentParameters$SilentParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/SilentParameters; - -
 method public toString ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/SilentRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
 method public parameters ()Lcom/microsoft/aad/msal4j/SilentParameters; - -
 method public assertion ()Lcom/microsoft/aad/msal4j/IUserAssertion; - -
 method public requestAuthority ()Lcom/microsoft/aad/msal4j/Authority; - -
in 2
class com/microsoft/aad/msal4j/SilentRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 2
class com/microsoft/aad/msal4j/SilentRequestHelper 52 super java/lang/Object - -
in 21
class com/microsoft/aad/msal4j/StringHelper 52 final,super java/lang/Object - -
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
 method public,static isNullOrBlank (Ljava/lang/String;)Z - -
in 2
class com/microsoft/aad/msal4j/StringHelper 52 final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/util/Base64$Encoder java/util/Base64 Encoder public,static
in 69
class com/microsoft/aad/msal4j/SystemBrowserOptions 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder com/microsoft/aad/msal4j/SystemBrowserOptions SystemBrowserOptionsBuilder public,static
 method public,static builder ()Lcom/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder; - -
 method public htmlMessageSuccess ()Ljava/lang/String; - -
 method public htmlMessageError ()Ljava/lang/String; - -
 method public browserRedirectSuccess ()Ljava/net/URI; - -
 method public browserRedirectError ()Ljava/net/URI; - -
 method public openBrowserAction ()Lcom/microsoft/aad/msal4j/OpenBrowserAction; - -
in 69
class com/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder com/microsoft/aad/msal4j/SystemBrowserOptions SystemBrowserOptionsBuilder public,static
 method public htmlMessageSuccess (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder; - -
 method public htmlMessageError (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder; - -
 method public browserRedirectSuccess (Ljava/net/URI;)Lcom/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder; - -
 method public browserRedirectError (Ljava/net/URI;)Lcom/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder; - -
 method public openBrowserAction (Lcom/microsoft/aad/msal4j/OpenBrowserAction;)Lcom/microsoft/aad/msal4j/SystemBrowserOptions$SystemBrowserOptionsBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/SystemBrowserOptions; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/TelemetryConstants 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/TelemetryHelper 52 super java/lang/Object java/lang/AutoCloseable -
 method public close ()V - -
in 69
class com/microsoft/aad/msal4j/TelemetryManager 52 super java/lang/Object com/microsoft/aad/msal4j/ITelemetryManager,com/microsoft/aad/msal4j/ITelemetry -
 inner java/util/concurrent/ConcurrentHashMap$KeySetView java/util/concurrent/ConcurrentHashMap KeySetView public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/function/Consumer;Z)V (Ljava/util/function/Consumer<Ljava/util/List<Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;>;>;Z)V -
 method public createTelemetryHelper (Ljava/lang/String;Ljava/lang/String;Lcom/microsoft/aad/msal4j/Event;Ljava/lang/Boolean;)Lcom/microsoft/aad/msal4j/TelemetryHelper; - -
 method public generateRequestId ()Ljava/lang/String; - -
 method public startEvent (Ljava/lang/String;Lcom/microsoft/aad/msal4j/Event;)V - -
 method public stopEvent (Ljava/lang/String;Lcom/microsoft/aad/msal4j/Event;)V - -
 method public flush (Ljava/lang/String;Ljava/lang/String;)V - -
in 21
class com/microsoft/aad/msal4j/TenantProfile 52 super java/lang/Object com/microsoft/aad/msal4j/ITenantProfile -
 method public getClaims ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
 method public idTokenClaims ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
 method public environment ()Ljava/lang/String; - -
 method public idTokenClaims (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/TenantProfile; (Ljava/util/Map<Ljava/lang/String;*>;)Lcom/microsoft/aad/msal4j/TenantProfile; -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/TenantProfile; - -
 method public <init> (Ljava/util/Map;Ljava/lang/String;)V (Ljava/util/Map<Ljava/lang/String;*>;Ljava/lang/String;)V -
in 2
class com/microsoft/aad/msal4j/TenantProfile 52 super java/lang/Object com/microsoft/aad/msal4j/ITenantProfile -
 method public <init> (Ljava/util/Map;Ljava/lang/String;)V (Ljava/util/Map<Ljava/lang/String;*>;Ljava/lang/String;)V -
 method public getClaims ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
 method public idTokenClaims ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;*>; -
 method public environment ()Ljava/lang/String; - -
 method public idTokenClaims (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/TenantProfile; (Ljava/util/Map<Ljava/lang/String;*>;)Lcom/microsoft/aad/msal4j/TenantProfile; -
 method public environment (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/TenantProfile; - -
in 69
class com/microsoft/aad/msal4j/ThrottlingCache 52 super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 21
class com/microsoft/aad/msal4j/TokenCache 52 public,super java/lang/Object com/microsoft/aad/msal4j/ITokenCache -
 inner com/microsoft/aad/msal4j/TokenCache$CacheAspect com/microsoft/aad/msal4j/TokenCache CacheAspect private
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 inner com/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder com/microsoft/aad/msal4j/TokenCacheAccessContext TokenCacheAccessContextBuilder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final MIN_ACCESS_TOKEN_EXPIRE_IN_SEC I - I300
 method public <init> (Lcom/microsoft/aad/msal4j/ITokenCacheAccessAspect;)V - -
 method public <init> ()V - -
 method public deserialize (Ljava/lang/String;)V - -
 method public serialize ()Ljava/lang/String; - -
in 2
class com/microsoft/aad/msal4j/TokenCache 52 public,super java/lang/Object com/microsoft/aad/msal4j/ITokenCache -
 inner com/microsoft/aad/msal4j/TokenCache$CacheAspect com/microsoft/aad/msal4j/TokenCache CacheAspect private
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder static
 inner com/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder com/microsoft/aad/msal4j/TokenCacheAccessContext TokenCacheAccessContextBuilder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,static,final MIN_ACCESS_TOKEN_EXPIRE_IN_SEC I - I300
 method public <init> (Lcom/microsoft/aad/msal4j/ITokenCacheAccessAspect;)V - -
 method public <init> ()V - -
 method public deserialize (Ljava/lang/String;)V - -
 method public serialize ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/TokenCache$CacheAspect 52 super java/lang/Object java/lang/AutoCloseable -
 inner com/microsoft/aad/msal4j/TokenCache$CacheAspect com/microsoft/aad/msal4j/TokenCache CacheAspect private
 method public close ()V - -
in 69
class com/microsoft/aad/msal4j/TokenCacheAccessContext 52 public,super java/lang/Object com/microsoft/aad/msal4j/ITokenCacheAccessContext -
 inner com/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder com/microsoft/aad/msal4j/TokenCacheAccessContext TokenCacheAccessContextBuilder public,static
 method public,static builder ()Lcom/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder; - -
 method public tokenCache ()Lcom/microsoft/aad/msal4j/ITokenCache; - -
 method public clientId ()Ljava/lang/String; - -
 method public account ()Lcom/microsoft/aad/msal4j/IAccount; - -
 method public hasCacheChanged ()Z - -
in 69
class com/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder com/microsoft/aad/msal4j/TokenCacheAccessContext TokenCacheAccessContextBuilder public,static
 method public tokenCache (Lcom/microsoft/aad/msal4j/ITokenCache;)Lcom/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder; - -
 method public clientId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder; - -
 method public account (Lcom/microsoft/aad/msal4j/IAccount;)Lcom/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder; - -
 method public hasCacheChanged (Z)Lcom/microsoft/aad/msal4j/TokenCacheAccessContext$TokenCacheAccessContextBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/TokenCacheAccessContext; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/TokenProviderResult 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public getAccessToken ()Ljava/lang/String; - -
 method public getTenantId ()Ljava/lang/String; - -
 method public getExpiresInSeconds ()J - -
 method public getRefreshInSeconds ()J - -
 method public setAccessToken (Ljava/lang/String;)V - -
 method public setTenantId (Ljava/lang/String;)V - -
 method public setExpiresInSeconds (J)V - -
 method public setRefreshInSeconds (J)V - -
in 70
class com/microsoft/aad/msal4j/TokenRequestExecutor 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 inner com/nimbusds/oauth2/sdk/http/HTTPRequest$Method com/nimbusds/oauth2/sdk/http/HTTPRequest Method public,static,final,enum
in 26
class com/microsoft/aad/msal4j/TokenRequestExecutor 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder public,static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
 inner com/nimbusds/oauth2/sdk/http/HTTPRequest$Method com/nimbusds/oauth2/sdk/http/HTTPRequest Method public,static,final,enum
in 2
class com/microsoft/aad/msal4j/TokenRequestExecutor 52 super java/lang/Object - -
 inner com/microsoft/aad/msal4j/AuthenticationResult$AuthenticationResultBuilder com/microsoft/aad/msal4j/AuthenticationResult AuthenticationResultBuilder static
 inner com/microsoft/aad/msal4j/AuthenticationResultMetadata$AuthenticationResultMetadataBuilder com/microsoft/aad/msal4j/AuthenticationResultMetadata AuthenticationResultMetadataBuilder public,static
in 21
class com/microsoft/aad/msal4j/TokenResponse 52 super com/nimbusds/openid/connect/sdk/OIDCTokenResponse - -
in 2
class com/microsoft/aad/msal4j/TokenResponse 52 super java/lang/Object - -
 method public accessToken ()Ljava/lang/String; - -
 method public idToken ()Ljava/lang/String; - -
 method public refreshToken ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/TokenSource 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/TokenSource;>;
 field public,static,final,enum IDENTITY_PROVIDER Lcom/microsoft/aad/msal4j/TokenSource; -
 field public,static,final,enum CACHE Lcom/microsoft/aad/msal4j/TokenSource; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/TokenSource; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/TokenSource; - -
in 69
class com/microsoft/aad/msal4j/UserAssertion 52 public,super java/lang/Object com/microsoft/aad/msal4j/IUserAssertion -
 method public <init> (Ljava/lang/String;)V - -
 method public getAssertion ()Ljava/lang/String; - -
 method public getAssertionHash ()Ljava/lang/String; - -
in 21
class com/microsoft/aad/msal4j/UserDiscoveryRequest 52 super java/lang/Object - -
in 2
class com/microsoft/aad/msal4j/UserDiscoveryRequest 52 super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 21
class com/microsoft/aad/msal4j/UserDiscoveryResponse 52 super java/lang/Object - -
in 2
class com/microsoft/aad/msal4j/UserDiscoveryResponse 52 super java/lang/Object com/azure/json/JsonSerializable Ljava/lang/Object;Lcom/azure/json/JsonSerializable<Lcom/microsoft/aad/msal4j/UserDiscoveryResponse;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static fromJson (Lcom/azure/json/JsonReader;)Lcom/microsoft/aad/msal4j/UserDiscoveryResponse; - java/io/IOException
 method public toJson (Lcom/azure/json/JsonWriter;)Lcom/azure/json/JsonWriter; - java/io/IOException
in 69
class com/microsoft/aad/msal4j/UserIdentifier 52 public,super java/lang/Object - -
 method public,static fromUpn (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/UserIdentifier; - -
 method public,static fromHomeAccountId (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/UserIdentifier; - -
in 69
class com/microsoft/aad/msal4j/UserNamePasswordParameters 52 public,super java/lang/Object com/microsoft/aad/msal4j/IAcquireTokenParameters -
 inner com/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder com/microsoft/aad/msal4j/UserNamePasswordParameters UserNamePasswordParametersBuilder public,static
 method public password ()[C - -
 method public,static builder (Ljava/util/Set;Ljava/lang/String;[C)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;Ljava/lang/String;[C)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; -
 method public scopes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public username ()Ljava/lang/String; - -
 method public claims ()Lcom/microsoft/aad/msal4j/ClaimsRequest; - -
 method public extraHttpHeaders ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public extraQueryParameters ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public tenant ()Ljava/lang/String; - -
 method public proofOfPossession ()Lcom/microsoft/aad/msal4j/PopParameters; - -
in 69
class com/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder 52 public,super java/lang/Object - -
 inner com/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder com/microsoft/aad/msal4j/UserNamePasswordParameters UserNamePasswordParametersBuilder public,static
 method public password ([C)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; - -
 method public proofOfPossession (Lcom/microsoft/aad/msal4j/HttpMethod;Ljava/net/URI;Ljava/lang/String;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; - -
 method public scopes (Ljava/util/Set;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; (Ljava/util/Set<Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; -
 method public username (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; - -
 method public claims (Lcom/microsoft/aad/msal4j/ClaimsRequest;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; - -
 method public extraHttpHeaders (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; -
 method public extraQueryParameters (Ljava/util/Map;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; -
 method public tenant (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/UserNamePasswordParameters$UserNamePasswordParametersBuilder; - -
 method public build ()Lcom/microsoft/aad/msal4j/UserNamePasswordParameters; - -
 method public toString ()Ljava/lang/String; - -
in 69
class com/microsoft/aad/msal4j/UserNamePasswordRequest 52 super com/microsoft/aad/msal4j/MsalRequest - -
in 69
class com/microsoft/aad/msal4j/WSTrustRequest 52 super java/lang/Object - -
in 69
class com/microsoft/aad/msal4j/WSTrustResponse 52 super java/lang/Object - -
 field public,static,final SAML1_ASSERTION Ljava/lang/String; - "urn:oasis:names:tc:SAML:1.0:assertion"
in 69
class com/microsoft/aad/msal4j/WSTrustVersion 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/microsoft/aad/msal4j/WSTrustVersion;>;
 field public,static,final,enum WSTRUST13 Lcom/microsoft/aad/msal4j/WSTrustVersion; -
 field public,static,final,enum WSTRUST2005 Lcom/microsoft/aad/msal4j/WSTrustVersion; -
 field public,static,final,enum UNDEFINED Lcom/microsoft/aad/msal4j/WSTrustVersion; -
 method public,static values ()[Lcom/microsoft/aad/msal4j/WSTrustVersion; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/microsoft/aad/msal4j/WSTrustVersion; - -
in 69
class com/microsoft/aad/msal4j/XmsClientTelemetryInfo 52 super java/lang/Object - -
 method public getServerErrorCode ()Ljava/lang/String; - -
 method public getServerSubErrorCode ()Ljava/lang/String; - -
 method public getTokenAge ()Ljava/lang/String; - -
 method public getSpeInfo ()Ljava/lang/String; - -
