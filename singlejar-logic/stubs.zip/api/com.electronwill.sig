cg-stub-db 1
in 3
class com/electronwill/nightconfig/core/AbstractCommentedConfig 52 public,super,abstract com/electronwill/nightconfig/core/AbstractConfig com/electronwill/nightconfig/core/CommentedConfig -
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static getDefaultCommentMap (Z)Ljava/util/Map; (Z)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
 method public clear ()V - -
 method public clearComments ()V - -
in 4
class com/electronwill/nightconfig/core/AbstractCommentedConfig 52 public,super,abstract com/electronwill/nightconfig/core/AbstractConfig com/electronwill/nightconfig/core/CommentedConfig -
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static getDefaultCommentMap (Z)Ljava/util/Map; (Z)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
 method public clear ()V - -
 method public clearComments ()V - -
in 5
class com/electronwill/nightconfig/core/AbstractCommentedConfig 52 public,super,abstract com/electronwill/nightconfig/core/AbstractConfig com/electronwill/nightconfig/core/CommentedConfig -
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final commentMap Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;
 method public <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public <init> (Ljava/util/Map;Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static getDefaultCommentMap (Z)Ljava/util/Map; (Z)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
 method public clear ()V - -
 method public clearComments ()V - -
in 6
class com/electronwill/nightconfig/core/AbstractCommentedConfig 52 public,super,abstract com/electronwill/nightconfig/core/AbstractConfig com/electronwill/nightconfig/core/CommentedConfig -
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final commentMap Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;
 method public,deprecated <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public <init> (Ljava/util/Map;Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,deprecated <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public,deprecated <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static,deprecated getDefaultCommentMap (Z)Ljava/util/Map; (Z)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
 method public clear ()V - -
 method public clearComments ()V - -
in 7
class com/electronwill/nightconfig/core/AbstractCommentedConfig 52 public,super,abstract com/electronwill/nightconfig/core/AbstractConfig com/electronwill/nightconfig/core/CommentedConfig -
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final commentMap Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;
 method public,deprecated <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public <init> (Ljava/util/Map;Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;)V -
 method public,deprecated <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public,deprecated <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static,deprecated getDefaultCommentMap (Z)Ljava/util/Map; (Z)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
 method public clear ()V - -
 method public clearComments ()V - -
in 3
class com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper 52 public,super com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/CommentedConfig$Entry -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 method public <init> (Lcom/electronwill/nightconfig/core/AbstractCommentedConfig;Ljava/util/Map$Entry;)V (Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method protected getPath ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getComment ()Ljava/lang/String; - -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public removeComment ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 4
class com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper 52 public,super com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/CommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 method public <init> (Lcom/electronwill/nightconfig/core/AbstractCommentedConfig;Ljava/util/Map$Entry;)V (Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method protected getPath ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getComment ()Ljava/lang/String; - -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public removeComment ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 8
class com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper 52 public,super com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/CommentedConfig$Entry -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/AbstractCommentedConfig$CommentedEntryWrapper com/electronwill/nightconfig/core/AbstractCommentedConfig CommentedEntryWrapper protected
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 method public <init> (Lcom/electronwill/nightconfig/core/AbstractCommentedConfig;Ljava/util/Map$Entry;)V (Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method protected getPath ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getComment ()Ljava/lang/String; - -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public removeComment ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 9
class com/electronwill/nightconfig/core/AbstractConfig 52 public,super,abstract java/lang/Object com/electronwill/nightconfig/core/Config,java/lang/Cloneable -
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final mapCreator Ljava/util/function/Supplier; Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;
 method public <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method protected,static getWildcardMapCreator (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isNull (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public clear ()V - -
 method public size ()I - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractConfig; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 5
class com/electronwill/nightconfig/core/AbstractConfig 52 public,super,abstract java/lang/Object com/electronwill/nightconfig/core/Config,java/lang/Cloneable -
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final mapCreator Ljava/util/function/Supplier; Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;
 field protected,final map Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;
 method public <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method protected,static getWildcardMapCreator (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isNull (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public clear ()V - -
 method public size ()I - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractConfig; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 6
class com/electronwill/nightconfig/core/AbstractConfig 52 public,super,abstract java/lang/Object com/electronwill/nightconfig/core/Config,java/lang/Cloneable -
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final mapCreator Ljava/util/function/Supplier; Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;
 field protected,final map Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;
 method public,deprecated <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public,deprecated <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static,deprecated getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method protected,static getWildcardMapCreator (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isNull (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public clear ()V - -
 method public size ()I - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractConfig; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 7
class com/electronwill/nightconfig/core/AbstractConfig 52 public,super,abstract java/lang/Object com/electronwill/nightconfig/core/Config,java/lang/Cloneable -
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final mapCreator Ljava/util/function/Supplier; Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;
 field protected,final map Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;
 method public,deprecated <init> (Z)V - -
 method public <init> (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public,deprecated <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Z)V - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method protected,static,deprecated getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method protected,static getWildcardMapCreator (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isNull (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public clear ()V - -
 method public size ()I - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract clone ()Lcom/electronwill/nightconfig/core/AbstractConfig; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 10
class com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper 52 public,super java/lang/Object com/electronwill/nightconfig/core/Config$Entry -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 field protected,final mapEntry Ljava/util/Map$Entry; Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;
 method public <init> (Ljava/util/Map$Entry;)V (Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 4
class com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper 52 public,super java/lang/Object com/electronwill/nightconfig/core/Config$Entry -
 inner com/electronwill/nightconfig/core/AbstractConfig$EntryWrapper com/electronwill/nightconfig/core/AbstractConfig EntryWrapper protected,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 field protected,final mapEntry Ljava/util/Map$Entry; Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;
 method public <init> (Ljava/util/Map$Entry;)V (Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;)V -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 9
class com/electronwill/nightconfig/core/CheckedCommentedConfig 52 super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/CommentedConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/CommentedConfig;>;Lcom/electronwill/nightconfig/core/CommentedConfig;
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public checked ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/CheckedCommentedConfig 52 super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper - Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/CommentedConfig;>;
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public checked ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 11
class com/electronwill/nightconfig/core/CheckedConfig 52 super com/electronwill/nightconfig/core/utils/ConfigWrapper - Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<Lcom/electronwill/nightconfig/core/Config;>;
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public checked ()Lcom/electronwill/nightconfig/core/Config; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 3
class com/electronwill/nightconfig/core/CommentedConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig,com/electronwill/nightconfig/core/Config -
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 method public setComment (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,abstract clearComments ()V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,abstract commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static fake (Lcom/electronwill/nightconfig/core/Config;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 4
class com/electronwill/nightconfig/core/CommentedConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig,com/electronwill/nightconfig/core/Config -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 method public setComment (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,abstract clearComments ()V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,abstract commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static fake (Lcom/electronwill/nightconfig/core/Config;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 12
class com/electronwill/nightconfig/core/CommentedConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig,com/electronwill/nightconfig/core/Config -
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 method public setComment (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,abstract clearComments ()V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,abstract commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static,deprecated ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static,deprecated inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static fake (Lcom/electronwill/nightconfig/core/Config;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 6
class com/electronwill/nightconfig/core/CommentedConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig,com/electronwill/nightconfig/core/Config -
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 method public setComment (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public,abstract clearComments ()V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,abstract,deprecated commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static,deprecated ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static,deprecated inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static fake (Lcom/electronwill/nightconfig/core/Config;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 11
class com/electronwill/nightconfig/core/CommentedConfig$Entry 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/Config$Entry,com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 method public,abstract setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract removeComment ()Ljava/lang/String; - -
in 9
class com/electronwill/nightconfig/core/ConcurrentConfigSpec 52 public,super com/electronwill/nightconfig/core/ConfigSpec - -
 method public <init> ()V - -
in 8
class com/electronwill/nightconfig/core/ConcurrentConfigSpec 52 public,super,deprecated com/electronwill/nightconfig/core/ConfigSpec - -
 method public <init> ()V - -
in 3
class com/electronwill/nightconfig/core/Config 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig -
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public set (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Object;)TT; -
 method public,abstract set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public,abstract add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public add (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public addAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public remove (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,abstract remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public,abstract clear ()V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,abstract valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/Config; - -
 method public update (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public update (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryUniversal ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryUniversalConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static isInsertionOrderPreserved ()Z - -
 method public,static setInsertionOrderPreserved (Z)V - -
 method public,static getDefaultMapCreator (ZZ)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(ZZ)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public,static getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
in 4
class com/electronwill/nightconfig/core/Config 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig -
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public set (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Object;)TT; -
 method public,abstract set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public,abstract add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public add (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public addAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public remove (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,abstract remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public,abstract clear ()V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,abstract valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/Config; - -
 method public update (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public update (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryUniversal ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryUniversalConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static isInsertionOrderPreserved ()Z - -
 method public,static setInsertionOrderPreserved (Z)V - -
 method public,static getDefaultMapCreator (ZZ)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(ZZ)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public,static getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
in 12
class com/electronwill/nightconfig/core/Config 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig -
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public set (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Object;)TT; -
 method public,abstract set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public,abstract add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public add (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public addAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public remove (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,abstract remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public,abstract clear ()V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,abstract valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/Config; - -
 method public update (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public update (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static,deprecated ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryUniversal ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static,deprecated inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static,deprecated inMemoryUniversalConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static isInsertionOrderPreserved ()Z - -
 method public,static setInsertionOrderPreserved (Z)V - -
 method public,static,deprecated getDefaultMapCreator (ZZ)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(ZZ)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public,static,deprecated getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
in 6
class com/electronwill/nightconfig/core/Config 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig -
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public set (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Object;)TT; -
 method public,abstract set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public,abstract add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public add (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public addAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public remove (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,abstract remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public,abstract clear ()V - -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableConfig; - -
 method public checked ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,abstract,deprecated valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/Config; - -
 method public update (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public update (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public,static of (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static of (Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static,deprecated ofConcurrent (Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static inMemory ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static inMemoryUniversal ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static,deprecated inMemoryConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static,deprecated inMemoryUniversalConcurrent ()Lcom/electronwill/nightconfig/core/Config; - -
 method public,static wrap (Ljava/util/Map;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static copy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/Config; - -
 method public,static,deprecated concurrentCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public,static isInsertionOrderPreserved ()Z - -
 method public,static setInsertionOrderPreserved (Z)V - -
 method public,static,deprecated getDefaultMapCreator (ZZ)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(ZZ)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
 method public,static,deprecated getDefaultMapCreator (Z)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Z)Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;TT;>;>; -
in 11
class com/electronwill/nightconfig/core/Config$Entry 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig$Entry -
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 method public,abstract setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
in 13
class com/electronwill/nightconfig/core/ConfigCopier 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigCopier$Builder com/electronwill/nightconfig/core/ConfigCopier Builder private,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 method public <init> (Ljava/util/function/Function;Ljava/util/function/BiFunction;)V (Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/BiFunction<Ljava/util/Collection<*>;Lcom/electronwill/nightconfig/core/CommentedConfig;Ljava/util/Collection<Ljava/lang/Object;>;>;)V -
 method public deepCopy (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Lcom/electronwill/nightconfig/core/Config;>;)V -
in 13
class com/electronwill/nightconfig/core/ConfigCopier$Builder 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigCopier$Builder com/electronwill/nightconfig/core/ConfigCopier Builder private,static,final
in 9
class com/electronwill/nightconfig/core/ConfigFormat 52 public,interface,abstract java/lang/Object - <C::Lcom/electronwill/nightconfig/core/Config;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract createWriter ()Lcom/electronwill/nightconfig/core/io/ConfigWriter; - -
 method public,abstract createParser ()Lcom/electronwill/nightconfig/core/io/ConfigParser; ()Lcom/electronwill/nightconfig/core/io/ConfigParser<TC;>; -
 method public createConfig ()Lcom/electronwill/nightconfig/core/Config; ()TC; -
 method public createConcurrentConfig ()Lcom/electronwill/nightconfig/core/Config; ()TC; -
 method public,abstract createConfig (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)TC; -
 method public,abstract supportsComments ()Z - -
 method public supportsType (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public isInMemory ()Z - -
 method public initEmptyFile (Ljava/nio/file/Path;)V - java/io/IOException
 method public initEmptyFile (Ljava/io/File;)V - java/io/IOException
 method public initEmptyFile (Lcom/electronwill/nightconfig/core/utils/WriterSupplier;)V - java/io/IOException
in 8
class com/electronwill/nightconfig/core/ConfigFormat 52 public,interface,abstract java/lang/Object - <C::Lcom/electronwill/nightconfig/core/Config;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract createWriter ()Lcom/electronwill/nightconfig/core/io/ConfigWriter; - -
 method public,abstract createParser ()Lcom/electronwill/nightconfig/core/io/ConfigParser; ()Lcom/electronwill/nightconfig/core/io/ConfigParser<TC;>; -
 method public createConfig ()Lcom/electronwill/nightconfig/core/Config; ()TC; -
 method public createConcurrentConfig ()Lcom/electronwill/nightconfig/core/Config; ()TC; -
 method public,abstract createConfig (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)TC; -
 method public,abstract supportsComments ()Z - -
 method public supportsType (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public isInMemory ()Z - -
 method public initEmptyFile (Ljava/nio/file/Path;)V - java/io/IOException
 method public initEmptyFile (Ljava/io/File;)V - java/io/IOException
 method public initEmptyFile (Lcom/electronwill/nightconfig/core/utils/WriterSupplier;)V - java/io/IOException
 method public initEmptyFile (Ljava/io/Writer;)V - java/io/IOException
in 3
class com/electronwill/nightconfig/core/ConfigSpec 52 public,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigSpec$DumbSupplier com/electronwill/nightconfig/core/ConfigSpec DumbSupplier private,static,final
 inner com/electronwill/nightconfig/core/ConfigSpec$ValueSpec com/electronwill/nightconfig/core/ConfigSpec ValueSpec private,static,final
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionAction com/electronwill/nightconfig/core/ConfigSpec CorrectionAction public,static,final,enum
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionListener com/electronwill/nightconfig/core/ConfigSpec CorrectionListener public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final storage Lcom/electronwill/nightconfig/core/Config; -
 method public <init> ()V - -
 method public define (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public define (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public define (Ljava/lang/String;Ljava/lang/Object;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/lang/Object;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/function/Supplier<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/util/List;Ljava/lang/Object;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineOfClass (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/lang/String;TV;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/util/List;Ljava/lang/Object;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;TV;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/util/List;Ljava/util/function/Supplier;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TV;>;Ljava/lang/Class<-TV;>;)V -
 method public defineInList (Ljava/lang/String;Ljava/lang/Object;Ljava/util/Collection;)V (Ljava/lang/String;Ljava/lang/Object;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/Collection;)V (Ljava/lang/String;Ljava/util/function/Supplier<*>;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/util/List;Ljava/lang/Object;Ljava/util/Collection;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/Collection;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<*>;Ljava/util/Collection<*>;)V -
 method public defineInRange (Ljava/lang/String;Ljava/lang/Comparable;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/lang/String;TV;TV;TV;)V -
 method public defineInRange (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;TV;TV;)V -
 method public defineInRange (Ljava/util/List;Ljava/lang/Comparable;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/util/List<Ljava/lang/String;>;TV;TV;TV;)V -
 method public defineInRange (Ljava/util/List;Ljava/util/function/Supplier;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TV;>;TV;TV;)V -
 method public defineList (Ljava/lang/String;Ljava/util/List;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/List<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/function/Supplier<Ljava/util/List<*>;>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/util/List;Ljava/util/List;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/List<*>;>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineEnum (Ljava/lang/String;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineEnum (Ljava/util/List;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineEnum (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineEnum (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineRestrictedEnum (Ljava/lang/String;Ljava/lang/Enum;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineRestrictedEnum (Ljava/util/List;Ljava/lang/Enum;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineRestrictedEnum (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineRestrictedEnum (Ljava/util/List;Ljava/lang/Class;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public undefine (Ljava/lang/String;)V - -
 method public undefine (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/String;>;)V -
 method public isDefined (Ljava/lang/String;)Z - -
 method public isDefined (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isCorrect (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public isCorrect (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public isCorrect (Lcom/electronwill/nightconfig/core/Config;)Z - -
 method public correct (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public correct (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Ljava/lang/Object; -
 method public correct (Lcom/electronwill/nightconfig/core/Config;)I - -
 method public correct (Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionListener;)I - -
in 4
class com/electronwill/nightconfig/core/ConfigSpec 52 public,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigSpec$ValueSpec com/electronwill/nightconfig/core/ConfigSpec ValueSpec private,static,final
 inner com/electronwill/nightconfig/core/ConfigSpec$DumbSupplier com/electronwill/nightconfig/core/ConfigSpec DumbSupplier private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionListener com/electronwill/nightconfig/core/ConfigSpec CorrectionListener public,static,interface,abstract
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionAction com/electronwill/nightconfig/core/ConfigSpec CorrectionAction public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final storage Lcom/electronwill/nightconfig/core/Config; -
 method public <init> ()V - -
 method public define (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public define (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public define (Ljava/lang/String;Ljava/lang/Object;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/lang/Object;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/function/Supplier<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/util/List;Ljava/lang/Object;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineOfClass (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/lang/String;TV;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/util/List;Ljava/lang/Object;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;TV;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/util/List;Ljava/util/function/Supplier;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TV;>;Ljava/lang/Class<-TV;>;)V -
 method public defineInList (Ljava/lang/String;Ljava/lang/Object;Ljava/util/Collection;)V (Ljava/lang/String;Ljava/lang/Object;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/Collection;)V (Ljava/lang/String;Ljava/util/function/Supplier<*>;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/util/List;Ljava/lang/Object;Ljava/util/Collection;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/Collection;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<*>;Ljava/util/Collection<*>;)V -
 method public defineInRange (Ljava/lang/String;Ljava/lang/Comparable;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/lang/String;TV;TV;TV;)V -
 method public defineInRange (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;TV;TV;)V -
 method public defineInRange (Ljava/util/List;Ljava/lang/Comparable;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/util/List<Ljava/lang/String;>;TV;TV;TV;)V -
 method public defineInRange (Ljava/util/List;Ljava/util/function/Supplier;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TV;>;TV;TV;)V -
 method public defineList (Ljava/lang/String;Ljava/util/List;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/List<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/function/Supplier<Ljava/util/List<*>;>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/util/List;Ljava/util/List;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/List<*>;>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineEnum (Ljava/lang/String;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineEnum (Ljava/util/List;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineEnum (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineEnum (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineRestrictedEnum (Ljava/lang/String;Ljava/lang/Enum;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineRestrictedEnum (Ljava/util/List;Ljava/lang/Enum;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineRestrictedEnum (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineRestrictedEnum (Ljava/util/List;Ljava/lang/Class;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public undefine (Ljava/lang/String;)V - -
 method public undefine (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/String;>;)V -
 method public isDefined (Ljava/lang/String;)Z - -
 method public isDefined (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isCorrect (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public isCorrect (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public isCorrect (Lcom/electronwill/nightconfig/core/Config;)Z - -
 method public correct (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public correct (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Ljava/lang/Object; -
 method public correct (Lcom/electronwill/nightconfig/core/Config;)I - -
 method public correct (Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionListener;)I - -
in 8
class com/electronwill/nightconfig/core/ConfigSpec 52 public,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigSpec$DumbSupplier com/electronwill/nightconfig/core/ConfigSpec DumbSupplier private,static,final
 inner com/electronwill/nightconfig/core/ConfigSpec$ValueSpec com/electronwill/nightconfig/core/ConfigSpec ValueSpec private,static,final
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionAction com/electronwill/nightconfig/core/ConfigSpec CorrectionAction public,static,final,enum
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionListener com/electronwill/nightconfig/core/ConfigSpec CorrectionListener public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final storage Lcom/electronwill/nightconfig/core/Config; -
 method public <init> ()V - -
 method public <init> (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public define (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public define (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public define (Ljava/lang/String;Ljava/lang/Object;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/lang/Object;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/function/Supplier<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/util/List;Ljava/lang/Object;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public define (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineOfClass (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/lang/String;TV;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/util/List;Ljava/lang/Object;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;TV;Ljava/lang/Class<-TV;>;)V -
 method public defineOfClass (Ljava/util/List;Ljava/util/function/Supplier;Ljava/lang/Class;)V <V:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TV;>;Ljava/lang/Class<-TV;>;)V -
 method public defineInList (Ljava/lang/String;Ljava/lang/Object;Ljava/util/Collection;)V (Ljava/lang/String;Ljava/lang/Object;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/Collection;)V (Ljava/lang/String;Ljava/util/function/Supplier<*>;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/util/List;Ljava/lang/Object;Ljava/util/Collection;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/util/Collection<*>;)V -
 method public defineInList (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/Collection;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<*>;Ljava/util/Collection<*>;)V -
 method public defineInRange (Ljava/lang/String;Ljava/lang/Comparable;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/lang/String;TV;TV;TV;)V -
 method public defineInRange (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;TV;TV;)V -
 method public defineInRange (Ljava/util/List;Ljava/lang/Comparable;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/util/List<Ljava/lang/String;>;TV;TV;TV;)V -
 method public defineInRange (Ljava/util/List;Ljava/util/function/Supplier;Ljava/lang/Comparable;Ljava/lang/Comparable;)V <V::Ljava/lang/Comparable<-TV;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TV;>;TV;TV;)V -
 method public defineList (Ljava/lang/String;Ljava/util/List;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/List<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/lang/String;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/lang/String;Ljava/util/function/Supplier<Ljava/util/List<*>;>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/util/List;Ljava/util/List;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<*>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineList (Ljava/util/List;Ljava/util/function/Supplier;Ljava/util/function/Predicate;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<Ljava/util/List<*>;>;Ljava/util/function/Predicate<Ljava/lang/Object;>;)V -
 method public defineEnum (Ljava/lang/String;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineEnum (Ljava/util/List;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineEnum (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineEnum (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineRestrictedEnum (Ljava/lang/String;Ljava/lang/Enum;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineRestrictedEnum (Ljava/util/List;Ljava/lang/Enum;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)V -
 method public defineRestrictedEnum (Ljava/lang/String;Ljava/lang/Class;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public defineRestrictedEnum (Ljava/util/List;Ljava/lang/Class;Ljava/util/Collection;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)V <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Ljava/util/Collection<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)V -
 method public undefine (Ljava/lang/String;)V - -
 method public undefine (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/String;>;)V -
 method public isDefined (Ljava/lang/String;)Z - -
 method public isDefined (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isCorrect (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public isCorrect (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public isCorrect (Lcom/electronwill/nightconfig/core/Config;)Z - -
 method public correct (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public correct (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Ljava/lang/Object; -
 method public correct (Lcom/electronwill/nightconfig/core/Config;)I - -
 method public correct (Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionListener;)I - -
in 11
class com/electronwill/nightconfig/core/ConfigSpec$CorrectionAction 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction;>;
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionAction com/electronwill/nightconfig/core/ConfigSpec CorrectionAction public,static,final,enum
 field public,static,final,enum ADD Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction; -
 field public,static,final,enum REPLACE Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction; -
 field public,static,final,enum REMOVE Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction; - -
in 10
class com/electronwill/nightconfig/core/ConfigSpec$CorrectionListener 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionAction com/electronwill/nightconfig/core/ConfigSpec CorrectionAction public,static,final,enum
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionListener com/electronwill/nightconfig/core/ConfigSpec CorrectionListener public,static,interface,abstract
 method public,abstract onCorrect (Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction;Ljava/util/List;Ljava/lang/Object;Ljava/lang/Object;)V (Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/lang/Object;)V -
in 4
class com/electronwill/nightconfig/core/ConfigSpec$CorrectionListener 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionListener com/electronwill/nightconfig/core/ConfigSpec CorrectionListener public,static,interface,abstract
 inner com/electronwill/nightconfig/core/ConfigSpec$CorrectionAction com/electronwill/nightconfig/core/ConfigSpec CorrectionAction public,static,final,enum
 method public,abstract onCorrect (Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction;Ljava/util/List;Ljava/lang/Object;Ljava/lang/Object;)V (Lcom/electronwill/nightconfig/core/ConfigSpec$CorrectionAction;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;Ljava/lang/Object;)V -
in 11
class com/electronwill/nightconfig/core/ConfigSpec$DumbSupplier 52 final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<TT;>;
 inner com/electronwill/nightconfig/core/ConfigSpec$DumbSupplier com/electronwill/nightconfig/core/ConfigSpec DumbSupplier private,static,final
 method public get ()Ljava/lang/Object; ()TT; -
in 11
class com/electronwill/nightconfig/core/ConfigSpec$ValueSpec 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/ConfigSpec$ValueSpec com/electronwill/nightconfig/core/ConfigSpec ValueSpec private,static,final
 inner com/electronwill/nightconfig/core/ConfigSpec$DumbSupplier com/electronwill/nightconfig/core/ConfigSpec DumbSupplier private,static,final
in 11
class com/electronwill/nightconfig/core/EnumGetMethod 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/EnumGetMethod;>;
 field public,static,final,enum NAME Lcom/electronwill/nightconfig/core/EnumGetMethod; -
 field public,static,final,enum NAME_IGNORECASE Lcom/electronwill/nightconfig/core/EnumGetMethod; -
 field public,static,final,enum ORDINAL_OR_NAME Lcom/electronwill/nightconfig/core/EnumGetMethod; -
 field public,static,final,enum ORDINAL_OR_NAME_IGNORECASE Lcom/electronwill/nightconfig/core/EnumGetMethod; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/EnumGetMethod; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/EnumGetMethod; - -
 method public isCaseSensitive ()Z - -
 method public isOrdinalOk ()Z - -
 method public get (Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Object;Ljava/lang/Class<TT;>;)TT; -
 method public validate (Ljava/lang/Object;Ljava/lang/Class;)Z <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Object;Ljava/lang/Class<TT;>;)Z -
in 11
class com/electronwill/nightconfig/core/InMemoryCommentedFormat 52 public,super java/lang/Object com/electronwill/nightconfig/core/ConfigFormat Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat<Lcom/electronwill/nightconfig/core/CommentedConfig;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static defaultInstance ()Lcom/electronwill/nightconfig/core/InMemoryCommentedFormat; - -
 method public,static withSupport (Ljava/util/function/Predicate;)Lcom/electronwill/nightconfig/core/InMemoryCommentedFormat; (Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)Lcom/electronwill/nightconfig/core/InMemoryCommentedFormat; -
 method public,static withUniversalSupport ()Lcom/electronwill/nightconfig/core/InMemoryCommentedFormat; - -
 method public createWriter ()Lcom/electronwill/nightconfig/core/io/ConfigWriter; - -
 method public createParser ()Lcom/electronwill/nightconfig/core/io/ConfigParser; ()Lcom/electronwill/nightconfig/core/io/ConfigParser<Lcom/electronwill/nightconfig/core/CommentedConfig;>; -
 method public createConfig (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public supportsComments ()Z - -
 method public supportsType (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public isInMemory ()Z - -
in 11
class com/electronwill/nightconfig/core/InMemoryFormat 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/ConfigFormat Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat<Lcom/electronwill/nightconfig/core/Config;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static defaultInstance ()Lcom/electronwill/nightconfig/core/InMemoryFormat; - -
 method public,static withSupport (Ljava/util/function/Predicate;)Lcom/electronwill/nightconfig/core/InMemoryFormat; (Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)Lcom/electronwill/nightconfig/core/InMemoryFormat; -
 method public,static withUniversalSupport ()Lcom/electronwill/nightconfig/core/InMemoryFormat; - -
 method public createWriter ()Lcom/electronwill/nightconfig/core/io/ConfigWriter; - -
 method public createParser ()Lcom/electronwill/nightconfig/core/io/ConfigParser; ()Lcom/electronwill/nightconfig/core/io/ConfigParser<Lcom/electronwill/nightconfig/core/Config;>; -
 method public createConfig (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public supportsComments ()Z - -
 method public supportsType (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public isInMemory ()Z - -
in 8
class com/electronwill/nightconfig/core/IncompatibleIntermediaryLevelException 52 public,final,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 11
class com/electronwill/nightconfig/core/NullObject 52 public,final,super java/lang/Object - -
 field public,static,final NULL_OBJECT Lcom/electronwill/nightconfig/core/NullObject; -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 11
class com/electronwill/nightconfig/core/SimpleCommentedConfig 52 final,super com/electronwill/nightconfig/core/AbstractCommentedConfig - -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)V (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/ConfigFormat;)V (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)V -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/SimpleCommentedConfig; - -
 method public clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
in 11
class com/electronwill/nightconfig/core/SimpleConfig 52 final,super com/electronwill/nightconfig/core/AbstractConfig - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/SimpleConfig; - -
 method public clone ()Lcom/electronwill/nightconfig/core/SimpleConfig; - -
in 14
class com/electronwill/nightconfig/core/UnmodifiableCommentedConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig -
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 method public getComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public getOptionalComment (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getOptionalComment (Ljava/util/List;)Ljava/util/Optional; (Ljava/util/List<Ljava/lang/String;>;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public containsComment (Ljava/lang/String;)Z - -
 method public,abstract containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public,abstract commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public getComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry;>; -
 method public,static fake (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig; - -
in 6
class com/electronwill/nightconfig/core/UnmodifiableCommentedConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig -
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 method public getComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public getOptionalComment (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getOptionalComment (Ljava/util/List;)Ljava/util/Optional; (Ljava/util/List<Ljava/lang/String;>;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public containsComment (Ljava/lang/String;)Z - -
 method public,abstract containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public,abstract,deprecated commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public getComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry;>; -
 method public,static fake (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig; - -
in 11
class com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 method public <init> (Ljava/lang/String;Ljava/util/Map;)V (Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public getComment ()Ljava/lang/String; - -
 method public getChildren ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
in 11
class com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig$Entry -
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 method public,abstract getComment ()Ljava/lang/String; - -
in 14
class com/electronwill/nightconfig/core/UnmodifiableConfig 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 method public get (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public get (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public getRaw (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,abstract getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public getOptional (Ljava/lang/String;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;)Ljava/util/Optional<TT;>; -
 method public getOptional (Ljava/util/List;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)Ljava/util/Optional<TT;>; -
 method public getOrElse (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public getOrElse (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;TT;)TT; -
 method public getOrElse (Ljava/util/List;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getOrElse (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnum (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnum (Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;)TT; -
 method public getEnum (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnum (Ljava/util/List;Ljava/lang/Class;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;)TT; -
 method public getOptionalEnum (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional<TT;>; -
 method public getOptionalEnum (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;)Ljava/util/Optional<TT;>; -
 method public getOptionalEnum (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional<TT;>; -
 method public getOptionalEnum (Ljava/util/List;Ljava/lang/Class;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;)Ljava/util/Optional<TT;>; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Enum;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Enum;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;)TT; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Class;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Class;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getInt (Ljava/lang/String;)I - -
 method public getInt (Ljava/util/List;)I (Ljava/util/List<Ljava/lang/String;>;)I -
 method public getOptionalInt (Ljava/lang/String;)Ljava/util/OptionalInt; - -
 method public getOptionalInt (Ljava/util/List;)Ljava/util/OptionalInt; (Ljava/util/List<Ljava/lang/String;>;)Ljava/util/OptionalInt; -
 method public getIntOrElse (Ljava/lang/String;I)I - -
 method public getIntOrElse (Ljava/util/List;I)I (Ljava/util/List<Ljava/lang/String;>;I)I -
 method public getIntOrElse (Ljava/lang/String;Ljava/util/function/IntSupplier;)I - -
 method public getIntOrElse (Ljava/util/List;Ljava/util/function/IntSupplier;)I (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/IntSupplier;)I -
 method public getLong (Ljava/lang/String;)J - -
 method public getLong (Ljava/util/List;)J (Ljava/util/List<Ljava/lang/String;>;)J -
 method public getOptionalLong (Ljava/lang/String;)Ljava/util/OptionalLong; - -
 method public getOptionalLong (Ljava/util/List;)Ljava/util/OptionalLong; (Ljava/util/List<Ljava/lang/String;>;)Ljava/util/OptionalLong; -
 method public getLongOrElse (Ljava/lang/String;J)J - -
 method public getLongOrElse (Ljava/util/List;J)J (Ljava/util/List<Ljava/lang/String;>;J)J -
 method public getLongOrElse (Ljava/lang/String;Ljava/util/function/LongSupplier;)J - -
 method public getLongOrElse (Ljava/util/List;Ljava/util/function/LongSupplier;)J (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/LongSupplier;)J -
 method public getByte (Ljava/lang/String;)B - -
 method public getByte (Ljava/util/List;)B (Ljava/util/List<Ljava/lang/String;>;)B -
 method public getByteOrElse (Ljava/lang/String;B)B - -
 method public getByteOrElse (Ljava/util/List;B)B (Ljava/util/List<Ljava/lang/String;>;B)B -
 method public getShort (Ljava/lang/String;)S - -
 method public getShort (Ljava/util/List;)S (Ljava/util/List<Ljava/lang/String;>;)S -
 method public getShortOrElse (Ljava/lang/String;S)S - -
 method public getShortOrElse (Ljava/util/List;S)S (Ljava/util/List<Ljava/lang/String;>;S)S -
 method public getChar (Ljava/lang/String;)C - -
 method public getChar (Ljava/util/List;)C (Ljava/util/List<Ljava/lang/String;>;)C -
 method public getCharOrElse (Ljava/lang/String;C)C - -
 method public getCharOrElse (Ljava/util/List;C)C (Ljava/util/List<Ljava/lang/String;>;C)C -
 method public contains (Ljava/lang/String;)Z - -
 method public,abstract contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isNull (Ljava/lang/String;)Z - -
 method public isNull (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public,abstract size ()I - -
 method public isEmpty ()Z - -
 method public,abstract valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableConfig$Entry;>; -
 method public,abstract configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public apply (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public apply (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
in 6
class com/electronwill/nightconfig/core/UnmodifiableConfig 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 method public get (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public get (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public getRaw (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public,abstract getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public getOptional (Ljava/lang/String;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;)Ljava/util/Optional<TT;>; -
 method public getOptional (Ljava/util/List;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)Ljava/util/Optional<TT;>; -
 method public getOrElse (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public getOrElse (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;TT;)TT; -
 method public getOrElse (Ljava/util/List;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getOrElse (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnum (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnum (Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;)TT; -
 method public getEnum (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnum (Ljava/util/List;Ljava/lang/Class;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;)TT; -
 method public getOptionalEnum (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional<TT;>; -
 method public getOptionalEnum (Ljava/lang/String;Ljava/lang/Class;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;)Ljava/util/Optional<TT;>; -
 method public getOptionalEnum (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/util/Optional<TT;>; -
 method public getOptionalEnum (Ljava/util/List;Ljava/lang/Class;)Ljava/util/Optional; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;)Ljava/util/Optional<TT;>; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Enum;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;TT;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/EnumGetMethod;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;Lcom/electronwill/nightconfig/core/EnumGetMethod;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Enum;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;TT;)TT; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnumOrElse (Ljava/lang/String;Ljava/lang/Class;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/String;Ljava/lang/Class<TT;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Lcom/electronwill/nightconfig/core/EnumGetMethod;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getEnumOrElse (Ljava/util/List;Ljava/lang/Class;Ljava/util/function/Supplier;)Ljava/lang/Enum; <T:Ljava/lang/Enum<TT;>;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Class<TT;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public getInt (Ljava/lang/String;)I - -
 method public getInt (Ljava/util/List;)I (Ljava/util/List<Ljava/lang/String;>;)I -
 method public getOptionalInt (Ljava/lang/String;)Ljava/util/OptionalInt; - -
 method public getOptionalInt (Ljava/util/List;)Ljava/util/OptionalInt; (Ljava/util/List<Ljava/lang/String;>;)Ljava/util/OptionalInt; -
 method public getIntOrElse (Ljava/lang/String;I)I - -
 method public getIntOrElse (Ljava/util/List;I)I (Ljava/util/List<Ljava/lang/String;>;I)I -
 method public getIntOrElse (Ljava/lang/String;Ljava/util/function/IntSupplier;)I - -
 method public getIntOrElse (Ljava/util/List;Ljava/util/function/IntSupplier;)I (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/IntSupplier;)I -
 method public getLong (Ljava/lang/String;)J - -
 method public getLong (Ljava/util/List;)J (Ljava/util/List<Ljava/lang/String;>;)J -
 method public getOptionalLong (Ljava/lang/String;)Ljava/util/OptionalLong; - -
 method public getOptionalLong (Ljava/util/List;)Ljava/util/OptionalLong; (Ljava/util/List<Ljava/lang/String;>;)Ljava/util/OptionalLong; -
 method public getLongOrElse (Ljava/lang/String;J)J - -
 method public getLongOrElse (Ljava/util/List;J)J (Ljava/util/List<Ljava/lang/String;>;J)J -
 method public getLongOrElse (Ljava/lang/String;Ljava/util/function/LongSupplier;)J - -
 method public getLongOrElse (Ljava/util/List;Ljava/util/function/LongSupplier;)J (Ljava/util/List<Ljava/lang/String;>;Ljava/util/function/LongSupplier;)J -
 method public getByte (Ljava/lang/String;)B - -
 method public getByte (Ljava/util/List;)B (Ljava/util/List<Ljava/lang/String;>;)B -
 method public getByteOrElse (Ljava/lang/String;B)B - -
 method public getByteOrElse (Ljava/util/List;B)B (Ljava/util/List<Ljava/lang/String;>;B)B -
 method public getShort (Ljava/lang/String;)S - -
 method public getShort (Ljava/util/List;)S (Ljava/util/List<Ljava/lang/String;>;)S -
 method public getShortOrElse (Ljava/lang/String;S)S - -
 method public getShortOrElse (Ljava/util/List;S)S (Ljava/util/List<Ljava/lang/String;>;S)S -
 method public getChar (Ljava/lang/String;)C - -
 method public getChar (Ljava/util/List;)C (Ljava/util/List<Ljava/lang/String;>;)C -
 method public getCharOrElse (Ljava/lang/String;C)C - -
 method public getCharOrElse (Ljava/util/List;C)C (Ljava/util/List<Ljava/lang/String;>;C)C -
 method public contains (Ljava/lang/String;)Z - -
 method public,abstract contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public isNull (Ljava/lang/String;)Z - -
 method public isNull (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public,abstract size ()I - -
 method public isEmpty ()Z - -
 method public,abstract,deprecated valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,abstract entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableConfig$Entry;>; -
 method public,abstract configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public apply (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public apply (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
in 11
class com/electronwill/nightconfig/core/UnmodifiableConfig$Entry 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 method public,abstract getKey ()Ljava/lang/String; - -
 method public,abstract getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public getValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public isNull ()Z - -
 method public getOptional ()Ljava/util/Optional; <T:Ljava/lang/Object;>()Ljava/util/Optional<TT;>; -
 method public getOrElse (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;)TT; -
 method public getInt ()I - -
 method public getOptionalInt ()Ljava/util/OptionalInt; - -
 method public getIntOrElse (I)I - -
 method public getLong ()J - -
 method public getOptionalLong ()Ljava/util/OptionalLong; - -
 method public getLongOrElse (J)J - -
 method public getByte ()B - -
 method public getByteOrElse (B)B - -
 method public getShort ()S - -
 method public getShortOrElse (S)S - -
 method public getChar ()C - -
 method public getCharOrElse (C)C - -
in 8
class com/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/CommentedConfig,com/electronwill/nightconfig/core/concurrent/ConcurrentConfig -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract bulkCommentedRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;TR;>;)TR; -
 method public bulkCommentedRead (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;>;)V -
 method public,abstract bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/CommentedConfig;>;)V -
 method public bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig; - -
in 8
class com/electronwill/nightconfig/core/concurrent/ConcurrentConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/Config -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkRead (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>;)V -
 method public,abstract bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/Config;>;)V -
 method public,abstract createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/ConcurrentConfig; - -
in 12
class com/electronwill/nightconfig/core/concurrent/StampedConfig 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState com/electronwill/nightconfig/core/concurrent/StampedConfig ThreadConfigState private,static,final,enum
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig WritableLockedView private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$InLockLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig InLockLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LockingLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LockingLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LazyEntry private,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntryIterator com/electronwill/nightconfig/core/concurrent/StampedConfig EntryIterator private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntrySet com/electronwill/nightconfig/core/concurrent/StampedConfig EntrySet private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator com/electronwill/nightconfig/core/concurrent/StampedConfig Accumulator public,static,final
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Lcom/electronwill/nightconfig/core/ConfigFormat;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/ConfigFormat<*>;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public replaceContentBy (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;)V - -
 method public replaceContentBy (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator;)V - -
 method public newAccumulator ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator; - -
 method public newAccumulatorCopy ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator; - -
 method public size ()I - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig; - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public clear ()V - -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public clearComments ()V - -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public bulkCommentedRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
in 6
class com/electronwill/nightconfig/core/concurrent/StampedConfig 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ValueMap com/electronwill/nightconfig/core/concurrent/StampedConfig ValueMap private,static,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState com/electronwill/nightconfig/core/concurrent/StampedConfig ThreadConfigState private,static,final,enum
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig WritableLockedView private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$InLockLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig InLockLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LockingLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LockingLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LazyEntry private,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntryIterator com/electronwill/nightconfig/core/concurrent/StampedConfig EntryIterator private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntrySet com/electronwill/nightconfig/core/concurrent/StampedConfig EntrySet private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator com/electronwill/nightconfig/core/concurrent/StampedConfig Accumulator public,static,final
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Lcom/electronwill/nightconfig/core/ConfigFormat;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/ConfigFormat<*>;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public replaceContentBy (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;)V - -
 method public replaceContentBy (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator;)V - -
 method public newAccumulator ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator; - -
 method public newAccumulatorCopy ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator; - -
 method public size ()I - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig; - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public clear ()V - -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public clearComments ()V - -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public bulkCommentedRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator 52 public,final,super com/electronwill/nightconfig/core/AbstractCommentedConfig - -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator com/electronwill/nightconfig/core/concurrent/StampedConfig Accumulator public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$EntryIterator 52 super java/lang/Object java/util/Iterator Ljava/lang/Object;Ljava/util/Iterator<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry;>;
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LazyEntry private,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntryIterator com/electronwill/nightconfig/core/concurrent/StampedConfig EntryIterator private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$InLockLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig InLockLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState com/electronwill/nightconfig/core/concurrent/StampedConfig ThreadConfigState private,static,final,enum
 method public hasNext ()Z - -
 method public next ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry; - -
 method public remove ()V - -
 method public forEachRemaining (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry;>;)V -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$EntrySet 52 super java/util/AbstractCollection java/util/Set Ljava/util/AbstractCollection<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry;>;Ljava/util/Set<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry;>;
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntrySet com/electronwill/nightconfig/core/concurrent/StampedConfig EntrySet private
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LazyEntry private,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$InLockLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig InLockLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LockingLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LockingLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntryIterator com/electronwill/nightconfig/core/concurrent/StampedConfig EntryIterator private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState com/electronwill/nightconfig/core/concurrent/StampedConfig ThreadConfigState private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry;>; -
 method public size ()I - -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry;>;)V -
 method public add (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry;)Z - -
 method public clear ()V - -
 method public contains (Ljava/lang/Object;)Z - -
 method public isEmpty ()Z - -
 method public remove (Ljava/lang/Object;)Z - -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$InLockLazyEntry 52 final,super com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry - -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$InLockLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig InLockLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LazyEntry private,abstract
 method protected <init> (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;Ljava/lang/String;)V - -
 method public removeComment ()Ljava/lang/String; - -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public getComment ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry 52 super,abstract java/lang/Object com/electronwill/nightconfig/core/CommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LazyEntry private,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 field protected,final key Ljava/lang/String; -
 method protected <init> (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;Ljava/lang/String;)V - -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$LockingLazyEntry 52 final,super com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry - -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$EntrySet com/electronwill/nightconfig/core/concurrent/StampedConfig EntrySet private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LockingLazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LockingLazyEntry private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$LazyEntry com/electronwill/nightconfig/core/concurrent/StampedConfig LazyEntry private,abstract
 method protected <init> (Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;Ljava/lang/String;Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$EntrySet;)V - -
 method public removeComment ()Ljava/lang/String; - -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public getComment ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 12
class com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView 52 super java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView$Entry com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView Entry protected
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected checkValid ()V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry;>; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public size ()I - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
in 6
class com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView 52 super java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView$Entry com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView Entry protected
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig WritableLockedView private,final
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected checkValid ()V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry;>; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public size ()I - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView$Entry 52 public,super java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView$Entry com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView Entry protected
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 field protected,final mapEntry Ljava/util/Map$Entry; Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;
 method public getComment ()Ljava/lang/String; - -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState;>;
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState com/electronwill/nightconfig/core/concurrent/StampedConfig ThreadConfigState private,static,final,enum
 field public,static,final,enum NORMAL Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState; -
 field public,static,final,enum IN_BULK_OP Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState; -
 field public,static,final,enum IN_ITER_OP Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState; -
 field public,static,final,enum CONSUMED Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/concurrent/StampedConfig$ThreadConfigState; - -
in 6
class com/electronwill/nightconfig/core/concurrent/StampedConfig$ValueMap 52 final,super java/lang/Object java/util/Map Ljava/lang/Object;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ValueMap com/electronwill/nightconfig/core/concurrent/StampedConfig ValueMap private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public clear ()V - -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public isEmpty ()Z - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/Object;>; -
 method public put (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public putAll (Ljava/util/Map;)V (Ljava/util/Map<+Ljava/lang/String;+Ljava/lang/Object;>;)V -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public size ()I - -
in 12
class com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView 52 final,super com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/CommentedConfig -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig WritableLockedView private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView$Entry com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView Entry protected
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public clear ()V - -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public clearComments ()V - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig; - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
in 6
class com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView 52 final,super com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/CommentedConfig -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig WritableLockedView private,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView$Entry com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView Entry protected
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ValueMap com/electronwill/nightconfig/core/concurrent/StampedConfig ValueMap private,static,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public clear ()V - -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public clearComments ()V - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/StampedConfig; - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
in 8
class com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView$Entry 52 public,super com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView$Entry com/electronwill/nightconfig/core/CommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig WritableLockedView private,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView$Entry com/electronwill/nightconfig/core/concurrent/StampedConfig$WritableLockedView Entry protected
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView com/electronwill/nightconfig/core/concurrent/StampedConfig ReadOnlyLockedView private
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView$Entry com/electronwill/nightconfig/core/concurrent/StampedConfig$ReadOnlyLockedView Entry protected
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 method public removeComment ()Ljava/lang/String; - -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
in 8
class com/electronwill/nightconfig/core/concurrent/SynchronizedConfig 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig -
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedSet com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedSet private,static,final
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedIterator com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedIterator private,static,final
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedCollection com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedCollection private,static
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedMap com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedMap private,static,final
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$DataHolder com/electronwill/nightconfig/core/concurrent/SynchronizedConfig DataHolder private,static,final
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator com/electronwill/nightconfig/core/concurrent/StampedConfig Accumulator public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static convert (Lcom/electronwill/nightconfig/core/Config;)Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig; - -
 method public <init> ()V - -
 method public <init> (Lcom/electronwill/nightconfig/core/ConfigFormat;Ljava/util/function/Supplier;)V (Lcom/electronwill/nightconfig/core/ConfigFormat<*>;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/ConfigFormat;Ljava/util/function/Supplier;Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig;)V (Lcom/electronwill/nightconfig/core/ConfigFormat<*>;Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig;)V -
 method public replaceContentBy (Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig;)V - -
 method public replaceContentBy (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public bulkCommentedRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public clearComments ()V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public clear ()V - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig; - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public toString ()Ljava/lang/String; - -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public equals (Ljava/lang/Object;)Z - -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public hashCode ()I - -
 method public isEmpty ()Z - -
 method public size ()I - -
 method public,deprecated valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public add (Ljava/lang/String;Ljava/lang/Object;)Z - -
 method public addAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public remove (Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;)TT; -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public set (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/lang/Object;)TT; -
 method public unmodifiable ()Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig; - -
 method public update (Ljava/util/List;Ljava/lang/Object;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)V -
 method public apply (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public get (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public isNull (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public getComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
in 8
class com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$DataHolder 52 final,super com/electronwill/nightconfig/core/AbstractCommentedConfig - -
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$DataHolder com/electronwill/nightconfig/core/concurrent/SynchronizedConfig DataHolder private,static,final
 method public clone ()Lcom/electronwill/nightconfig/core/AbstractCommentedConfig; - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig; - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
in 8
class com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedCollection 52 super java/lang/Object java/util/Collection <E:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Collection<TE;>;
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedCollection com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedCollection private,static
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedIterator com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedIterator private,static,final
 method public add (Ljava/lang/Object;)Z (TE;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TE;>;)Z -
 method public clear ()V - -
 method public contains (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public isEmpty ()Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TE;>; -
 method public remove (Ljava/lang/Object;)Z - -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public size ()I - -
 method public toArray ()[Ljava/lang/Object; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TE;>;)Z -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TE;>;)V -
in 8
class com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedIterator 52 final,super java/lang/Object java/util/Iterator <E:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TE;>;
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedIterator com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedIterator private,static,final
 method public forEachRemaining (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TE;>;)V -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TE; -
 method public remove ()V - -
in 8
class com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedMap 52 final,super java/lang/Object java/util/Map <K:Ljava/lang/Object;V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Map<TK;TV;>;
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedMap com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedMap private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedSet com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedSet private,static,final
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public clear ()V - -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public isEmpty ()Z - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public putAll (Ljava/util/Map;)V (Ljava/util/Map<+TK;+TV;>;)V -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public size ()I - -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<TV;>; -
in 8
class com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedSet 52 final,super com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedCollection java/util/Set <E:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedCollection<TE;>;Ljava/util/Set<TE;>;
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedSet com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedSet private,static,final
 inner com/electronwill/nightconfig/core/concurrent/SynchronizedConfig$SynchronizedCollection com/electronwill/nightconfig/core/concurrent/SynchronizedConfig SynchronizedCollection private,static
in 10
class com/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig 52 super,abstract com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig com/electronwill/nightconfig/core/CommentedConfig <C::Lcom/electronwill/nightconfig/core/CommentedConfig;>Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedConfig<TC;>;Lcom/electronwill/nightconfig/core/CommentedConfig;
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/CommentedConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (TC;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public clearComments ()V - -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 4
class com/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig 52 super,abstract com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig com/electronwill/nightconfig/core/CommentedConfig <C::Lcom/electronwill/nightconfig/core/CommentedConfig;>Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedConfig<TC;>;Lcom/electronwill/nightconfig/core/CommentedConfig;
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/CommentedConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (TC;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public clearComments ()V - -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 9
class com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig 52 super,abstract com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/Config <C::Lcom/electronwill/nightconfig/core/Config;>Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/Config;
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public toString ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig 52 super,abstract com/electronwill/nightconfig/core/utils/ConfigWrapper - <C::Lcom/electronwill/nightconfig/core/Config;>Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<TC;>;
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public toString ()Ljava/lang/String; - -
in 9
class com/electronwill/nightconfig/core/conversion/AdvancedPath 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()[Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/conversion/AdvancedPath 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()[Ljava/lang/String; - -
in 11
class com/electronwill/nightconfig/core/conversion/AnnotationUtils 52 final,super java/lang/Object - -
in 9
class com/electronwill/nightconfig/core/conversion/Conversion 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Lcom/electronwill/nightconfig/core/conversion/Converter<**>;>; -
in 8
class com/electronwill/nightconfig/core/conversion/Conversion 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Lcom/electronwill/nightconfig/core/conversion/Converter<**>;>; -
in 11
class com/electronwill/nightconfig/core/conversion/ConversionTable 52 public,final,super java/lang/Object java/lang/Cloneable -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public put (Ljava/lang/Class;Ljava/util/function/Function;)V <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;Ljava/util/function/Function<-TT;Ljava/lang/Object;>;)V -
 method public remove (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public contains (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public convert (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public convertShallow (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public convertDeep (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public chainThen (Lcom/electronwill/nightconfig/core/conversion/ConversionTable;)Lcom/electronwill/nightconfig/core/conversion/ConversionTable; - -
 method public wrap (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Lcom/electronwill/nightconfig/core/UnmodifiableConfig; - -
 method public wrapRead (Lcom/electronwill/nightconfig/core/Config;)Lcom/electronwill/nightconfig/core/Config; - -
 method public wrapRead (Lcom/electronwill/nightconfig/core/CommentedConfig;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public wrapRead (Lcom/electronwill/nightconfig/core/file/FileConfig;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public wrapRead (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public wrapWrite (Lcom/electronwill/nightconfig/core/Config;Ljava/util/function/Predicate;)Lcom/electronwill/nightconfig/core/Config; (Lcom/electronwill/nightconfig/core/Config;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)Lcom/electronwill/nightconfig/core/Config; -
 method public wrapWrite (Lcom/electronwill/nightconfig/core/CommentedConfig;Ljava/util/function/Predicate;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Lcom/electronwill/nightconfig/core/CommentedConfig;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public wrapWrite (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Predicate;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public wrapWrite (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Predicate;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public clone ()Lcom/electronwill/nightconfig/core/conversion/ConversionTable; - -
 method public toString ()Ljava/lang/String; - -
in 11
class com/electronwill/nightconfig/core/conversion/ConvertedCommentedConfig 52 public,final,super com/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig - Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig<Lcom/electronwill/nightconfig/core/CommentedConfig;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/CommentedConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/CommentedConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/CommentedConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/CommentedConfig;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
in 9
class com/electronwill/nightconfig/core/conversion/ConvertedCommentedFileConfig 52 public,final,super com/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 5
class com/electronwill/nightconfig/core/conversion/ConvertedCommentedFileConfig 52 public,final,super com/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
in 15
class com/electronwill/nightconfig/core/conversion/ConvertedCommentedFileConfig 52 public,final,super com/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedCommentedConfig<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkCommentedRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig; - -
in 11
class com/electronwill/nightconfig/core/conversion/ConvertedConfig 52 public,final,super com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig - Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedConfig<Lcom/electronwill/nightconfig/core/Config;>;
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/Config;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/Config;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
in 9
class com/electronwill/nightconfig/core/conversion/ConvertedFileConfig 52 public,super com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig com/electronwill/nightconfig/core/file/FileConfig Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedConfig<Lcom/electronwill/nightconfig/core/file/FileConfig;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/file/FileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/FileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 5
class com/electronwill/nightconfig/core/conversion/ConvertedFileConfig 52 public,super com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig com/electronwill/nightconfig/core/file/FileConfig Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedConfig<Lcom/electronwill/nightconfig/core/file/FileConfig;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/file/FileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/FileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
in 15
class com/electronwill/nightconfig/core/conversion/ConvertedFileConfig 52 public,super com/electronwill/nightconfig/core/conversion/AbstractConvertedConfig com/electronwill/nightconfig/core/file/FileConfig Lcom/electronwill/nightconfig/core/conversion/AbstractConvertedConfig<Lcom/electronwill/nightconfig/core/file/FileConfig;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/file/FileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/FileConfig;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Lcom/electronwill/nightconfig/core/conversion/ConversionTable;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public <init> (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Predicate;)V (Lcom/electronwill/nightconfig/core/file/FileConfig;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/ConcurrentConfig; - -
in 11
class com/electronwill/nightconfig/core/conversion/ConvertedFormat 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/ConfigFormat <C::Lcom/electronwill/nightconfig/core/Config;F::Lcom/electronwill/nightconfig/core/ConfigFormat<TC;>;>Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat<TC;>;
 method public <init> (Lcom/electronwill/nightconfig/core/ConfigFormat;Ljava/util/function/Predicate;)V (TF;Ljava/util/function/Predicate<Ljava/lang/Class<*>;>;)V -
 method public createWriter ()Lcom/electronwill/nightconfig/core/io/ConfigWriter; - -
 method public createParser ()Lcom/electronwill/nightconfig/core/io/ConfigParser; ()Lcom/electronwill/nightconfig/core/io/ConfigParser<TC;>; -
 method public createConfig ()Lcom/electronwill/nightconfig/core/Config; ()TC; -
 method public createConcurrentConfig ()Lcom/electronwill/nightconfig/core/Config; ()TC; -
 method public createConfig (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)TC; -
 method public supportsComments ()Z - -
 method public supportsType (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
in 9
class com/electronwill/nightconfig/core/conversion/Converter 52 public,interface,abstract java/lang/Object - <FieldType:Ljava/lang/Object;ConfigValueType:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract convertToField (Ljava/lang/Object;)Ljava/lang/Object; (TConfigValueType;)TFieldType; -
 method public,abstract convertFromField (Ljava/lang/Object;)Ljava/lang/Object; (TFieldType;)TConfigValueType; -
in 8
class com/electronwill/nightconfig/core/conversion/Converter 52 public,interface,abstract,deprecated java/lang/Object - <FieldType:Ljava/lang/Object;ConfigValueType:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract convertToField (Ljava/lang/Object;)Ljava/lang/Object; (TConfigValueType;)TFieldType; -
 method public,abstract convertFromField (Ljava/lang/Object;)Ljava/lang/Object; (TFieldType;)TConfigValueType; -
in 9
class com/electronwill/nightconfig/core/conversion/ForceBreakdown 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 8
class com/electronwill/nightconfig/core/conversion/ForceBreakdown 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 9
class com/electronwill/nightconfig/core/conversion/InvalidValueException 52 public,final,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 8
class com/electronwill/nightconfig/core/conversion/InvalidValueException 52 public,final,super,deprecated java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,varargs <init> (Ljava/lang/String;[Ljava/lang/Object;)V - -
in 10
class com/electronwill/nightconfig/core/conversion/ObjectBinder 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$EnumValueConverter com/electronwill/nightconfig/core/conversion/ObjectBinder EnumValueConverter private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$NoOpConverter com/electronwill/nightconfig/core/conversion/ObjectBinder NoOpConverter private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos com/electronwill/nightconfig/core/conversion/ObjectBinder FieldInfos private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundSearchResult com/electronwill/nightconfig/core/conversion/ObjectBinder BoundSearchResult private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig com/electronwill/nightconfig/core/conversion/ObjectBinder BoundConfig private,static,final
 method public <init> (ZZ)V - -
 method public <init> ()V - -
 method public bind (Ljava/lang/Class;)Lcom/electronwill/nightconfig/core/Config; (Ljava/lang/Class<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public bind (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public bind (Ljava/lang/Object;)Lcom/electronwill/nightconfig/core/Config; - -
 method public bind (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
in 4
class com/electronwill/nightconfig/core/conversion/ObjectBinder 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig com/electronwill/nightconfig/core/conversion/ObjectBinder BoundConfig private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$EnumValueConverter com/electronwill/nightconfig/core/conversion/ObjectBinder EnumValueConverter private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$NoOpConverter com/electronwill/nightconfig/core/conversion/ObjectBinder NoOpConverter private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos com/electronwill/nightconfig/core/conversion/ObjectBinder FieldInfos private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundSearchResult com/electronwill/nightconfig/core/conversion/ObjectBinder BoundSearchResult private,static,final
 method public <init> (ZZ)V - -
 method public <init> ()V - -
 method public bind (Ljava/lang/Class;)Lcom/electronwill/nightconfig/core/Config; (Ljava/lang/Class<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public bind (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
 method public bind (Ljava/lang/Object;)Lcom/electronwill/nightconfig/core/Config; - -
 method public bind (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/Config; (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/Config; -
in 11
class com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig 52 final,super java/lang/Object com/electronwill/nightconfig/core/Config -
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig com/electronwill/nightconfig/core/conversion/ObjectBinder BoundConfig private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos com/electronwill/nightconfig/core/conversion/ObjectBinder FieldInfos private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundSearchResult com/electronwill/nightconfig/core/conversion/ObjectBinder BoundSearchResult private,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public clear ()V - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/Config; - -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public size ()I - -
 method public toString ()Ljava/lang/String; - -
in 10
class com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundSearchResult 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig com/electronwill/nightconfig/core/conversion/ObjectBinder BoundConfig private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos com/electronwill/nightconfig/core/conversion/ObjectBinder FieldInfos private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundSearchResult com/electronwill/nightconfig/core/conversion/ObjectBinder BoundSearchResult private,static,final
in 4
class com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundSearchResult 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundSearchResult com/electronwill/nightconfig/core/conversion/ObjectBinder BoundSearchResult private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig com/electronwill/nightconfig/core/conversion/ObjectBinder BoundConfig private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos com/electronwill/nightconfig/core/conversion/ObjectBinder FieldInfos private,static,final
in 11
class com/electronwill/nightconfig/core/conversion/ObjectBinder$EnumValueConverter 52 final,super java/lang/Object com/electronwill/nightconfig/core/conversion/Converter <T:Ljava/lang/Enum<TT;>;>Ljava/lang/Object;Lcom/electronwill/nightconfig/core/conversion/Converter<TT;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$EnumValueConverter com/electronwill/nightconfig/core/conversion/ObjectBinder EnumValueConverter private,static,final
 method public convertToField (Ljava/lang/Object;)Ljava/lang/Enum; (Ljava/lang/Object;)TT; -
 method public convertFromField (Ljava/lang/Enum;)Ljava/lang/String; (TT;)Ljava/lang/String; -
in 10
class com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig com/electronwill/nightconfig/core/conversion/ObjectBinder BoundConfig private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos com/electronwill/nightconfig/core/conversion/ObjectBinder FieldInfos private,static,final
 method public toString ()Ljava/lang/String; - -
in 4
class com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$FieldInfos com/electronwill/nightconfig/core/conversion/ObjectBinder FieldInfos private,static,final
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$BoundConfig com/electronwill/nightconfig/core/conversion/ObjectBinder BoundConfig private,static,final
 method public toString ()Ljava/lang/String; - -
in 11
class com/electronwill/nightconfig/core/conversion/ObjectBinder$NoOpConverter 52 final,super java/lang/Object com/electronwill/nightconfig/core/conversion/Converter Ljava/lang/Object;Lcom/electronwill/nightconfig/core/conversion/Converter<Ljava/lang/Object;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/conversion/ObjectBinder$NoOpConverter com/electronwill/nightconfig/core/conversion/ObjectBinder NoOpConverter private,static,final
 method public convertToField (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public convertFromField (Ljava/lang/Object;)Ljava/lang/Object; - -
in 9
class com/electronwill/nightconfig/core/conversion/ObjectConverter 52 public,final,super java/lang/Object - -
 method public <init> (ZZ)V - -
 method public <init> ()V - -
 method public toConfig (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/Config;)V - -
 method public toConfig (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/Config;)V (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/Config;)V -
 method public toConfig (Ljava/lang/Object;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; <C::Lcom/electronwill/nightconfig/core/Config;>(Ljava/lang/Object;Ljava/util/function/Supplier<TC;>;)TC; -
 method public toConfig (Ljava/lang/Class;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; <C::Lcom/electronwill/nightconfig/core/Config;>(Ljava/lang/Class<*>;Ljava/util/function/Supplier<TC;>;)TC; -
 method public toObject (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/lang/Object;)V - -
 method public toObject (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Ljava/lang/Object; <O:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<TO;>;)TO; -
in 8
class com/electronwill/nightconfig/core/conversion/ObjectConverter 52 public,final,super,deprecated java/lang/Object - -
 method public <init> (ZZ)V - -
 method public,deprecated <init> ()V - -
 method public toConfig (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/Config;)V - -
 method public toConfig (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/Config;)V (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/Config;)V -
 method public,deprecated toConfig (Ljava/lang/Object;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; <C::Lcom/electronwill/nightconfig/core/Config;>(Ljava/lang/Object;Ljava/util/function/Supplier<TC;>;)TC; -
 method public toConfig (Ljava/lang/Class;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; <C::Lcom/electronwill/nightconfig/core/Config;>(Ljava/lang/Class<*>;Ljava/util/function/Supplier<TC;>;)TC; -
 method public toObject (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/lang/Object;)V - -
 method public,deprecated toObject (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Ljava/lang/Object; <O:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<TO;>;)TO; -
in 9
class com/electronwill/nightconfig/core/conversion/Path 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/conversion/Path 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract value ()Ljava/lang/String; - -
in 9
class com/electronwill/nightconfig/core/conversion/PreserveNotNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
in 8
class com/electronwill/nightconfig/core/conversion/PreserveNotNull 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#TYPE])
in 9
class com/electronwill/nightconfig/core/conversion/ReflectionException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 8
class com/electronwill/nightconfig/core/conversion/ReflectionException 52 public,super,deprecated java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 9
class com/electronwill/nightconfig/core/conversion/SpecClassInArray 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; -
 method public,abstract strict ()Z - - Z0
in 8
class com/electronwill/nightconfig/core/conversion/SpecClassInArray 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Ljava/lang/Class; ()[Ljava/lang/Class<*>; -
 method public,abstract strict ()Z - - Z0
in 9
class com/electronwill/nightconfig/core/conversion/SpecDoubleInRange 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()D - -
 method public,abstract max ()D - -
in 8
class com/electronwill/nightconfig/core/conversion/SpecDoubleInRange 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()D - -
 method public,abstract max ()D - -
in 9
class com/electronwill/nightconfig/core/conversion/SpecEnum 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract method ()Lcom/electronwill/nightconfig/core/EnumGetMethod; - -
in 8
class com/electronwill/nightconfig/core/conversion/SpecEnum 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract method ()Lcom/electronwill/nightconfig/core/EnumGetMethod; - -
in 9
class com/electronwill/nightconfig/core/conversion/SpecFloatInRange 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()F - -
 method public,abstract max ()F - -
in 8
class com/electronwill/nightconfig/core/conversion/SpecFloatInRange 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()F - -
 method public,abstract max ()F - -
in 9
class com/electronwill/nightconfig/core/conversion/SpecIntInRange 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()I - -
 method public,abstract max ()I - -
in 8
class com/electronwill/nightconfig/core/conversion/SpecIntInRange 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()I - -
 method public,abstract max ()I - -
in 9
class com/electronwill/nightconfig/core/conversion/SpecLongInRange 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()J - -
 method public,abstract max ()J - -
in 8
class com/electronwill/nightconfig/core/conversion/SpecLongInRange 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()J - -
 method public,abstract max ()J - -
in 9
class com/electronwill/nightconfig/core/conversion/SpecNotNull 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 8
class com/electronwill/nightconfig/core/conversion/SpecNotNull 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
in 9
class com/electronwill/nightconfig/core/conversion/SpecStringInArray 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract ignoreCase ()Z - - Z0
in 8
class com/electronwill/nightconfig/core/conversion/SpecStringInArray 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Ljava/lang/String; - -
 method public,abstract ignoreCase ()Z - - Z0
in 9
class com/electronwill/nightconfig/core/conversion/SpecStringInRange 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()Ljava/lang/String; - -
 method public,abstract max ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/conversion/SpecStringInRange 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract min ()Ljava/lang/String; - -
 method public,abstract max ()Ljava/lang/String; - -
in 9
class com/electronwill/nightconfig/core/conversion/SpecValidator 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/util/function/Predicate<Ljava/lang/Object;>;>; -
in 8
class com/electronwill/nightconfig/core/conversion/SpecValidator 52 public,interface,abstract,annotation,deprecated java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()Ljava/lang/Class; ()Ljava/lang/Class<+Ljava/util/function/Predicate<Ljava/lang/Object;>;>; -
in 5
class com/electronwill/nightconfig/core/file/AsyncFileConfig 52 final,super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/file/AsyncFileConfig$LazyExecutorHolder com/electronwill/nightconfig/core/file/AsyncFileConfig LazyExecutorHolder private,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator com/electronwill/nightconfig/core/concurrent/StampedConfig Accumulator public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public asyncLoad ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
in 16
class com/electronwill/nightconfig/core/file/AsyncFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/file/AsyncFileConfig$LazyExecutorHolder com/electronwill/nightconfig/core/file/AsyncFileConfig LazyExecutorHolder private,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator com/electronwill/nightconfig/core/concurrent/StampedConfig Accumulator public,static,final
 inner com/electronwill/nightconfig/core/io/IoUtils$IoRunnable com/electronwill/nightconfig/core/io/IoUtils IoRunnable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public asyncLoad ()V - -
 method public load ()V - -
 method public close ()V - -
in 17
class com/electronwill/nightconfig/core/file/AsyncFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper<Lcom/electronwill/nightconfig/core/concurrent/StampedConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/file/AsyncFileConfig$LazyExecutorHolder com/electronwill/nightconfig/core/file/AsyncFileConfig LazyExecutorHolder private,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/concurrent/StampedConfig$Accumulator com/electronwill/nightconfig/core/concurrent/StampedConfig Accumulator public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public asyncLoad ()V - -
 method public load ()V - -
 method public close ()V - -
in 8
class com/electronwill/nightconfig/core/file/AsyncFileConfig$LazyExecutorHolder 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/AsyncFileConfig$LazyExecutorHolder com/electronwill/nightconfig/core/file/AsyncFileConfig LazyExecutorHolder private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 9
class com/electronwill/nightconfig/core/file/AutoreloadFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/file/FileConfig <C::Lcom/electronwill/nightconfig/core/file/FileConfig;>Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 5
class com/electronwill/nightconfig/core/file/AutoreloadFileConfig 52 final,super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig <C::Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
in 15
class com/electronwill/nightconfig/core/file/AutoreloadFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig <C::Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>Lcom/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 9
class com/electronwill/nightconfig/core/file/AutosaveCommentedFileConfig 52 final,super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/CommentedConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 5
class com/electronwill/nightconfig/core/file/AutosaveCommentedFileConfig 52 final,super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public save ()V - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public clear ()V - -
 method public clearComments ()V - -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
in 15
class com/electronwill/nightconfig/core/file/AutosaveCommentedFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public save ()V - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public removeAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public putAll (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public clear ()V - -
 method public clearComments ()V - -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
in 9
class com/electronwill/nightconfig/core/file/AutosaveFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/file/FileConfig <C::Lcom/electronwill/nightconfig/core/file/FileConfig;>Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 9
class com/electronwill/nightconfig/core/file/CheckedCommentedFileConfig 52 super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public getFile ()Ljava/io/File; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public checked ()Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 5
class com/electronwill/nightconfig/core/file/CheckedCommentedFileConfig 52 super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public getFile ()Ljava/io/File; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public checked ()Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 15
class com/electronwill/nightconfig/core/file/CheckedCommentedFileConfig 52 super com/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper<Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public getFile ()Ljava/io/File; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public checked ()Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 9
class com/electronwill/nightconfig/core/file/CheckedFileConfig 52 super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/file/FileConfig Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<Lcom/electronwill/nightconfig/core/file/FileConfig;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public getFile ()Ljava/io/File; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public checked ()Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 5
class com/electronwill/nightconfig/core/file/CheckedFileConfig 52 super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/file/FileConfig Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<Lcom/electronwill/nightconfig/core/file/FileConfig;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public getFile ()Ljava/io/File; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public checked ()Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public toString ()Ljava/lang/String; - -
in 15
class com/electronwill/nightconfig/core/file/CheckedFileConfig 52 super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/file/FileConfig Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<Lcom/electronwill/nightconfig/core/file/FileConfig;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public getFile ()Ljava/io/File; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public checked ()Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public toString ()Ljava/lang/String; - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/ConcurrentConfig; - -
in 9
class com/electronwill/nightconfig/core/file/CommentedFileConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/CommentedConfig,com/electronwill/nightconfig/core/file/FileConfig -
 method public checked ()Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static of (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static of (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static ofConcurrent (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static ofConcurrent (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static ofConcurrent (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static ofConcurrent (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static ofConcurrent (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static ofConcurrent (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static builder (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
 method public,static builder (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
 method public,static builder (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
in 5
class com/electronwill/nightconfig/core/file/CommentedFileConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/CommentedConfig,com/electronwill/nightconfig/core/file/FileConfig -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public checked ()Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,abstract bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/CommentedConfig;>;)V -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public,static of (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static of (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static of (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static builder (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
 method public,static builder (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
 method public,static builder (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
in 15
class com/electronwill/nightconfig/core/file/CommentedFileConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig,com/electronwill/nightconfig/core/file/FileConfig -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public checked ()Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,abstract bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/CommentedConfig;>;)V -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public,static of (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static of (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static of (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static of (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method public,static builder (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
 method public,static builder (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
 method public,static builder (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/CommentedConfig;>;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfigBuilder; -
in 9
class com/electronwill/nightconfig/core/file/CommentedFileConfigBuilder 52 public,final,super com/electronwill/nightconfig/core/file/GenericBuilder - Lcom/electronwill/nightconfig/core/file/GenericBuilder<Lcom/electronwill/nightconfig/core/CommentedConfig;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;
 method protected buildAutosave (Lcom/electronwill/nightconfig/core/file/FileConfig;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
 method protected buildNormal (Lcom/electronwill/nightconfig/core/file/FileConfig;)Lcom/electronwill/nightconfig/core/file/CommentedFileConfig; - -
in 8
class com/electronwill/nightconfig/core/file/CommentedFileConfigBuilder 52 public,final,super com/electronwill/nightconfig/core/file/GenericBuilder - Lcom/electronwill/nightconfig/core/file/GenericBuilder<Lcom/electronwill/nightconfig/core/CommentedConfig;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;>;
in 8
class com/electronwill/nightconfig/core/file/ConfigLoadFilter 52 public,interface,abstract java/lang/Object - -
 method public,abstract acceptNewVersion (Lcom/electronwill/nightconfig/core/CommentedConfig;)Z - -
in 8
class com/electronwill/nightconfig/core/file/DebouncedRunnable 52 final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/Runnable;Ljava/time/Duration;)V - -
 method public run (Ljava/util/concurrent/ScheduledExecutorService;)V - -
 method public andThen (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/DebouncedRunnable; - -
in 9
class com/electronwill/nightconfig/core/file/FileConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/Config,java/lang/AutoCloseable -
 method public,abstract getFile ()Ljava/io/File; - -
 method public,abstract getNioPath ()Ljava/nio/file/Path; - -
 method public,abstract save ()V - -
 method public,abstract load ()V - -
 method public,abstract close ()V - -
 method public checked ()Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static of (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static of (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static ofConcurrent (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static ofConcurrent (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static ofConcurrent (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static ofConcurrent (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static ofConcurrent (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static ofConcurrent (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static builder (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
 method public,static builder (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
 method public,static builder (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
in 5
class com/electronwill/nightconfig/core/file/FileConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/Config,java/lang/AutoCloseable -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getFile ()Ljava/io/File; - -
 method public,abstract getNioPath ()Ljava/nio/file/Path; - -
 method public,abstract save ()V - -
 method public,abstract load ()V - -
 method public,abstract close ()V - -
 method public checked ()Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,abstract bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/Config;>;)V -
 method public,static of (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static of (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static of (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static builder (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
 method public,static builder (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
 method public,static builder (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
in 15
class com/electronwill/nightconfig/core/file/FileConfig 52 public,interface,abstract java/lang/Object com/electronwill/nightconfig/core/concurrent/ConcurrentConfig,java/lang/AutoCloseable -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract getFile ()Ljava/io/File; - -
 method public,abstract getNioPath ()Ljava/nio/file/Path; - -
 method public,abstract save ()V - -
 method public,abstract load ()V - -
 method public,abstract close ()V - -
 method public checked ()Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,abstract bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/Config;>;)V -
 method public,static of (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static of (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<+Lcom/electronwill/nightconfig/core/Config;>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static of (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static of (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method public,static,deprecated ofConcurrent (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfig; -
 method public,static builder (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/io/File;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
 method public,static builder (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
 method public,static builder (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; - -
 method public,static builder (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Lcom/electronwill/nightconfig/core/file/FileConfigBuilder; -
in 9
class com/electronwill/nightconfig/core/file/FileConfigBuilder 52 public,super com/electronwill/nightconfig/core/file/GenericBuilder - Lcom/electronwill/nightconfig/core/file/GenericBuilder<Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/file/FileConfig;>;
 method protected buildAutosave (Lcom/electronwill/nightconfig/core/file/FileConfig;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
 method protected buildNormal (Lcom/electronwill/nightconfig/core/file/FileConfig;)Lcom/electronwill/nightconfig/core/file/FileConfig; - -
in 8
class com/electronwill/nightconfig/core/file/FileConfigBuilder 52 public,super com/electronwill/nightconfig/core/file/GenericBuilder - Lcom/electronwill/nightconfig/core/file/GenericBuilder<Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/file/FileConfig;>;
in 11
class com/electronwill/nightconfig/core/file/FileNotFoundAction 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CREATE_EMPTY Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; -
 field public,static,final READ_NOTHING Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; -
 field public,static,final THROW_ERROR Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; -
 method public,abstract run (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat;)Z (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)Z java/io/IOException
 method public,static copyData (Ljava/net/URL;)Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; - -
 method public,static copyData (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; - -
 method public,static copyData (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; - -
 method public,static copyData (Ljava/io/InputStream;)Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; - -
 method public,static copyResource (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; - -
in 3
class com/electronwill/nightconfig/core/file/FileWatcher 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile com/electronwill/nightconfig/core/file/FileWatcher WatchedFile private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir com/electronwill/nightconfig/core/file/FileWatcher WatchedDir private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatcherThread com/electronwill/nightconfig/core/file/FileWatcher WatcherThread private,final
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static,synchronized defaultInstance ()Lcom/electronwill/nightconfig/core/file/FileWatcher; - -
 method public <init> ()V - -
 method public <init> (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/Exception;>;)V -
 method public addWatch (Ljava/io/File;Ljava/lang/Runnable;)V - java/io/IOException
 method public addWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - java/io/IOException
 method public setWatch (Ljava/io/File;Ljava/lang/Runnable;)V - java/io/IOException
 method public setWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - java/io/IOException
 method public removeWatch (Ljava/io/File;)V - -
 method public removeWatch (Ljava/nio/file/Path;)V - -
 method public stop ()V - java/io/IOException
in 4
class com/electronwill/nightconfig/core/file/FileWatcher 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatcherThread com/electronwill/nightconfig/core/file/FileWatcher WatcherThread private,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir com/electronwill/nightconfig/core/file/FileWatcher WatchedDir private,static,final
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile com/electronwill/nightconfig/core/file/FileWatcher WatchedFile private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static,synchronized defaultInstance ()Lcom/electronwill/nightconfig/core/file/FileWatcher; - -
 method public <init> ()V - -
 method public <init> (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/Exception;>;)V -
 method public addWatch (Ljava/io/File;Ljava/lang/Runnable;)V - java/io/IOException
 method public addWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - java/io/IOException
 method public setWatch (Ljava/io/File;Ljava/lang/Runnable;)V - java/io/IOException
 method public setWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - java/io/IOException
 method public removeWatch (Ljava/io/File;)V - -
 method public removeWatch (Ljava/nio/file/Path;)V - -
 method public stop ()V - java/io/IOException
in 5
class com/electronwill/nightconfig/core/file/FileWatcher 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage com/electronwill/nightconfig/core/file/FileWatcher ControlMessage private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDirectory com/electronwill/nightconfig/core/file/FileWatcher WatchedDirectory private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$FsWatcher com/electronwill/nightconfig/core/file/FileWatcher FsWatcher private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchingException com/electronwill/nightconfig/core/file/FileWatcher WatchingException public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static,synchronized defaultInstance ()Lcom/electronwill/nightconfig/core/file/FileWatcher; - -
 method public <init> ()V - -
 method public <init> (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/Exception;>;)V -
 method public <init> (Ljava/time/Duration;)V - -
 method public <init> (Ljava/time/Duration;Ljava/util/function/Consumer;)V (Ljava/time/Duration;Ljava/util/function/Consumer<Ljava/lang/Throwable;>;)V -
 method public addWatch (Ljava/io/File;Ljava/lang/Runnable;)V - -
 method public addWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - -
 method public setWatch (Ljava/io/File;Ljava/lang/Runnable;)V - -
 method public setWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - -
 method public removeWatch (Ljava/io/File;)V - -
 method public removeWatch (Ljava/nio/file/Path;)V - -
 method public stop ()V - -
in 16
class com/electronwill/nightconfig/core/file/FileWatcher 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$NamedDaemonThreadFactory com/electronwill/nightconfig/core/file/FileWatcher NamedDaemonThreadFactory private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage com/electronwill/nightconfig/core/file/FileWatcher ControlMessage private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDirectory com/electronwill/nightconfig/core/file/FileWatcher WatchedDirectory private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$FsWatcher com/electronwill/nightconfig/core/file/FileWatcher FsWatcher private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchingException com/electronwill/nightconfig/core/file/FileWatcher WatchingException public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static,synchronized defaultInstance ()Lcom/electronwill/nightconfig/core/file/FileWatcher; - -
 method public <init> ()V - -
 method public <init> (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/Exception;>;)V -
 method public <init> (Ljava/time/Duration;)V - -
 method public <init> (Ljava/time/Duration;Ljava/util/function/Consumer;)V (Ljava/time/Duration;Ljava/util/function/Consumer<Ljava/lang/Throwable;>;)V -
 method public addWatch (Ljava/io/File;Ljava/lang/Runnable;)V - -
 method public addWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - -
 method public addWatchFuture (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture; (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public setWatch (Ljava/io/File;Ljava/lang/Runnable;)V - -
 method public setWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - -
 method public setWatchFuture (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture; (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public removeWatch (Ljava/io/File;)V - -
 method public removeWatch (Ljava/nio/file/Path;)V - -
 method public removeWatchFuture (Ljava/nio/file/Path;)Ljava/util/concurrent/CompletableFuture; (Ljava/nio/file/Path;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public stop ()V - -
 method public stopFuture ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
in 17
class com/electronwill/nightconfig/core/file/FileWatcher 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage com/electronwill/nightconfig/core/file/FileWatcher ControlMessage private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDirectory com/electronwill/nightconfig/core/file/FileWatcher WatchedDirectory private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$FsWatcher com/electronwill/nightconfig/core/file/FileWatcher FsWatcher private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchingException com/electronwill/nightconfig/core/file/FileWatcher WatchingException public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static,synchronized defaultInstance ()Lcom/electronwill/nightconfig/core/file/FileWatcher; - -
 method public <init> ()V - -
 method public <init> (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/Exception;>;)V -
 method public <init> (Ljava/time/Duration;)V - -
 method public <init> (Ljava/time/Duration;Ljava/util/function/Consumer;)V (Ljava/time/Duration;Ljava/util/function/Consumer<Ljava/lang/Throwable;>;)V -
 method public addWatch (Ljava/io/File;Ljava/lang/Runnable;)V - -
 method public addWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - -
 method public addWatchFuture (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture; (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public setWatch (Ljava/io/File;Ljava/lang/Runnable;)V - -
 method public setWatch (Ljava/nio/file/Path;Ljava/lang/Runnable;)V - -
 method public setWatchFuture (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture; (Ljava/nio/file/Path;Ljava/lang/Runnable;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public removeWatch (Ljava/io/File;)V - -
 method public removeWatch (Ljava/nio/file/Path;)V - -
 method public removeWatchFuture (Ljava/nio/file/Path;)Ljava/util/concurrent/CompletableFuture; (Ljava/nio/file/Path;)Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
 method public stop ()V - -
 method public stopFuture ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>; -
in 8
class com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath 52 super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchingException com/electronwill/nightconfig/core/file/FileWatcher WatchingException public,static
 field public,final parentDirectory Ljava/nio/file/Path; -
 field public,final fileName Ljava/nio/file/Path; -
 method public,static from (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath; - -
 method public toString ()Ljava/lang/String; - -
in 5
class com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage com/electronwill/nightconfig/core/file/FileWatcher ControlMessage private,static,final
in 15
class com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage com/electronwill/nightconfig/core/file/FileWatcher ControlMessage private,static,final
 method public toString ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind;>;
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 field public,static,final,enum PUT Lcom/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind; -
 field public,static,final,enum ADD Lcom/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind; -
 field public,static,final,enum REMOVE Lcom/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind; -
 field public,static,final,enum POISON Lcom/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind; - -
in 18
class com/electronwill/nightconfig/core/file/FileWatcher$FsWatcher 52 final,super java/lang/Object java/lang/Runnable -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDirectory com/electronwill/nightconfig/core/file/FileWatcher WatchedDirectory private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage com/electronwill/nightconfig/core/file/FileWatcher ControlMessage private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$FsWatcher com/electronwill/nightconfig/core/file/FileWatcher FsWatcher private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchingException com/electronwill/nightconfig/core/file/FileWatcher WatchingException public,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public run ()V - -
in 16
class com/electronwill/nightconfig/core/file/FileWatcher$FsWatcher 52 final,super java/lang/Object java/lang/Runnable -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDirectory com/electronwill/nightconfig/core/file/FileWatcher WatchedDirectory private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessage com/electronwill/nightconfig/core/file/FileWatcher ControlMessage private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$FsWatcher com/electronwill/nightconfig/core/file/FileWatcher FsWatcher private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$CanonicalPath com/electronwill/nightconfig/core/file/FileWatcher CanonicalPath private,static
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner com/electronwill/nightconfig/core/file/FileWatcher$NamedDaemonThreadFactory com/electronwill/nightconfig/core/file/FileWatcher NamedDaemonThreadFactory private,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchingException com/electronwill/nightconfig/core/file/FileWatcher WatchingException public,static
 inner com/electronwill/nightconfig/core/file/FileWatcher$ControlMessageKind com/electronwill/nightconfig/core/file/FileWatcher ControlMessageKind private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public run ()V - -
in 16
class com/electronwill/nightconfig/core/file/FileWatcher$NamedDaemonThreadFactory 52 super java/lang/Object java/util/concurrent/ThreadFactory -
 inner com/electronwill/nightconfig/core/file/FileWatcher$NamedDaemonThreadFactory com/electronwill/nightconfig/core/file/FileWatcher NamedDaemonThreadFactory private,static
 method public newThread (Ljava/lang/Runnable;)Ljava/lang/Thread; - -
in 9
class com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir com/electronwill/nightconfig/core/file/FileWatcher WatchedDir private,static,final
in 8
class com/electronwill/nightconfig/core/file/FileWatcher$WatchedDirectory 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDirectory com/electronwill/nightconfig/core/file/FileWatcher WatchedDirectory private,static,final
in 3
class com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir com/electronwill/nightconfig/core/file/FileWatcher WatchedDir private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile com/electronwill/nightconfig/core/file/FileWatcher WatchedFile private,static,final
in 4
class com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile com/electronwill/nightconfig/core/file/FileWatcher WatchedFile private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir com/electronwill/nightconfig/core/file/FileWatcher WatchedDir private,static,final
in 3
class com/electronwill/nightconfig/core/file/FileWatcher$WatcherThread 52 final,super java/lang/Thread - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatcherThread com/electronwill/nightconfig/core/file/FileWatcher WatcherThread private,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile com/electronwill/nightconfig/core/file/FileWatcher WatchedFile private,static,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir com/electronwill/nightconfig/core/file/FileWatcher WatchedDir private,static,final
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 method public run ()V - -
in 4
class com/electronwill/nightconfig/core/file/FileWatcher$WatcherThread 52 final,super java/lang/Thread - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatcherThread com/electronwill/nightconfig/core/file/FileWatcher WatcherThread private,final
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedDir com/electronwill/nightconfig/core/file/FileWatcher WatchedDir private,static,final
 inner java/nio/file/WatchEvent$Kind java/nio/file/WatchEvent Kind public,static,interface,abstract
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchedFile com/electronwill/nightconfig/core/file/FileWatcher WatchedFile private,static,final
 method public run ()V - -
in 8
class com/electronwill/nightconfig/core/file/FileWatcher$WatchingException 52 public,super java/lang/RuntimeException - -
 inner com/electronwill/nightconfig/core/file/FileWatcher$WatchingException com/electronwill/nightconfig/core/file/FileWatcher WatchingException public,static
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;)V - -
in 11
class com/electronwill/nightconfig/core/file/FormatDetector 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static registerExtension (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat;)V (Ljava/lang/String;Lcom/electronwill/nightconfig/core/ConfigFormat<*>;)V -
 method public,static registerExtension (Ljava/lang/String;Ljava/util/function/Supplier;)V (Ljava/lang/String;Ljava/util/function/Supplier<Lcom/electronwill/nightconfig/core/ConfigFormat<*>;>;)V -
 method public,static detect (Ljava/io/File;)Lcom/electronwill/nightconfig/core/ConfigFormat; (Ljava/io/File;)Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public,static detect (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/ConfigFormat; (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public,static detectByName (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/ConfigFormat; (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
in 9
class com/electronwill/nightconfig/core/file/GenericBuilder 52 public,super,abstract java/lang/Object - <Base::Lcom/electronwill/nightconfig/core/Config;Result::Lcom/electronwill/nightconfig/core/file/FileConfig;>Ljava/lang/Object;
 field protected,final file Ljava/nio/file/Path; -
 field protected,final format Lcom/electronwill/nightconfig/core/ConfigFormat; Lcom/electronwill/nightconfig/core/ConfigFormat<+TBase;>;
 field protected,final writer Lcom/electronwill/nightconfig/core/io/ConfigWriter; -
 field protected,final parser Lcom/electronwill/nightconfig/core/io/ConfigParser; Lcom/electronwill/nightconfig/core/io/ConfigParser<+TBase;>;
 field protected charset Ljava/nio/charset/Charset; -
 field protected writingMode Lcom/electronwill/nightconfig/core/io/WritingMode; -
 field protected parsingMode Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 field protected nefAction Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; -
 field protected sync Z -
 field protected autosave Z -
 field protected autoreload Z -
 field protected concurrent Z -
 field protected insertionOrder Z -
 field protected mapCreator Ljava/util/function/Supplier; Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;
 method public charset (Ljava/nio/charset/Charset;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/nio/charset/Charset;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public writingMode (Lcom/electronwill/nightconfig/core/io/WritingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/io/WritingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public parsingMode (Lcom/electronwill/nightconfig/core/io/ParsingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/io/ParsingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public onFileNotFound (Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultResource (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultData (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultData (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultData (Ljava/net/URL;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/net/URL;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public sync ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public autosave ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public autoreload ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public concurrent ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public preserveInsertionOrder ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public backingMapCreator (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public build ()Lcom/electronwill/nightconfig/core/file/FileConfig; ()TResult; -
 method protected,abstract buildAutosave (Lcom/electronwill/nightconfig/core/file/FileConfig;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Lcom/electronwill/nightconfig/core/file/FileConfig;)TResult; -
 method protected,abstract buildNormal (Lcom/electronwill/nightconfig/core/file/FileConfig;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Lcom/electronwill/nightconfig/core/file/FileConfig;)TResult; -
 method protected,final getConfig ()Lcom/electronwill/nightconfig/core/Config; ()TBase; -
in 8
class com/electronwill/nightconfig/core/file/GenericBuilder 52 public,super,abstract java/lang/Object - <Base::Lcom/electronwill/nightconfig/core/Config;Result::Lcom/electronwill/nightconfig/core/file/FileConfig;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final file Ljava/nio/file/Path; -
 field protected,final format Lcom/electronwill/nightconfig/core/ConfigFormat; Lcom/electronwill/nightconfig/core/ConfigFormat<+TBase;>;
 field protected,final writer Lcom/electronwill/nightconfig/core/io/ConfigWriter; -
 field protected,final parser Lcom/electronwill/nightconfig/core/io/ConfigParser; Lcom/electronwill/nightconfig/core/io/ConfigParser<+TBase;>;
 field protected charset Ljava/nio/charset/Charset; -
 field protected writingMode Lcom/electronwill/nightconfig/core/io/WritingMode; -
 field protected parsingMode Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 field protected nefAction Lcom/electronwill/nightconfig/core/file/FileNotFoundAction; -
 field protected sync Z -
 field protected autosave Z -
 field protected atomicMove Z -
 field protected autoreloadFileWatcher Lcom/electronwill/nightconfig/core/file/FileWatcher; -
 field protected preserveInsertionOrder Z -
 field protected mapCreator Ljava/util/function/Supplier; Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;
 field protected loadListener Ljava/lang/Runnable; -
 field protected saveListener Ljava/lang/Runnable; -
 field protected autoLoadListener Ljava/lang/Runnable; -
 field protected autoSaveListener Ljava/lang/Runnable; -
 method public charset (Ljava/nio/charset/Charset;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/nio/charset/Charset;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public writingMode (Lcom/electronwill/nightconfig/core/io/WritingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/io/WritingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public parsingMode (Lcom/electronwill/nightconfig/core/io/ParsingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/io/ParsingMode;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public onFileNotFound (Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultResource (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultData (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/io/File;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultData (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/nio/file/Path;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public defaultData (Ljava/net/URL;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/net/URL;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public sync ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public async ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public asyncWithDebouncing (Ljava/time/Duration;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/time/Duration;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public autosave ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public autoreload ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public autoreload (Lcom/electronwill/nightconfig/core/file/FileWatcher;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/file/FileWatcher;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public onAutoReload (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public onAutoSave (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public onLoad (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public onSave (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/lang/Runnable;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public onLoadFilter (Lcom/electronwill/nightconfig/core/file/ConfigLoadFilter;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Lcom/electronwill/nightconfig/core/file/ConfigLoadFilter;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public,deprecated concurrent ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public preserveInsertionOrder ()Lcom/electronwill/nightconfig/core/file/GenericBuilder; ()Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public backingMapCreator (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/file/GenericBuilder; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/file/GenericBuilder<TBase;TResult;>; -
 method public build ()Lcom/electronwill/nightconfig/core/file/FileConfig; ()TResult; -
 method protected buildAutosave (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;)TResult; -
 method protected buildNormal (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;)Lcom/electronwill/nightconfig/core/file/FileConfig; (Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;)TResult; -
in 11
class com/electronwill/nightconfig/core/file/NoFormatFoundException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 9
class com/electronwill/nightconfig/core/file/SimpleCommentedFileConfig 52 super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/CommentedConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 5
class com/electronwill/nightconfig/core/file/SyncFileConfig 52 final,super com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
in 15
class com/electronwill/nightconfig/core/file/SyncFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper com/electronwill/nightconfig/core/file/CommentedFileConfig Lcom/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper<Lcom/electronwill/nightconfig/core/concurrent/SynchronizedConfig;>;Lcom/electronwill/nightconfig/core/file/CommentedFileConfig;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 9
class com/electronwill/nightconfig/core/file/WriteAsyncFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/file/FileConfig <C::Lcom/electronwill/nightconfig/core/Config;>Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 inner com/electronwill/nightconfig/core/file/WriteAsyncFileConfig$WriteCompletedHandler com/electronwill/nightconfig/core/file/WriteAsyncFileConfig WriteCompletedHandler private,final
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public close ()V - -
 method public load ()V - -
in 9
class com/electronwill/nightconfig/core/file/WriteAsyncFileConfig$WriteCompletedHandler 52 final,super java/lang/Object java/nio/channels/CompletionHandler Ljava/lang/Object;Ljava/nio/channels/CompletionHandler<Ljava/lang/Integer;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/file/WriteAsyncFileConfig$WriteCompletedHandler com/electronwill/nightconfig/core/file/WriteAsyncFileConfig WriteCompletedHandler private,final
 method public completed (Ljava/lang/Integer;Ljava/lang/Object;)V - -
 method public failed (Ljava/lang/Throwable;Ljava/lang/Object;)V - -
in 9
class com/electronwill/nightconfig/core/file/WriteSyncFileConfig 52 final,super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/file/FileConfig <C::Lcom/electronwill/nightconfig/core/Config;>Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/file/FileConfig;
 method public getFile ()Ljava/io/File; - -
 method public getNioPath ()Ljava/nio/file/Path; - -
 method public save ()V - -
 method public load ()V - -
 method public close ()V - -
in 11
class com/electronwill/nightconfig/core/io/AbstractInput 52 public,super,abstract java/lang/Object com/electronwill/nightconfig/core/io/CharacterInput -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 field protected,final deque Lcom/electronwill/nightconfig/core/utils/IntDeque; -
 method public <init> ()V - -
 method protected,abstract directRead ()I - -
 method protected,abstract directReadChar ()C - -
 method public read ()I - -
 method public readChar ()C - -
 method public peek ()I - -
 method public peek (I)I - -
 method public peekChar ()C - -
 method public peekChar (I)C - -
 method public skipPeeks ()V - -
 method public pushBack (C)V - -
 method public readUntil ([C)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public readCharsUntil ([C)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method protected consumeDeque ([CIZ)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
in 8
class com/electronwill/nightconfig/core/io/AdditionalCharsets 52 public,final,super java/lang/Object - -
 field public,static,final UTF_8_BOM Ljava/nio/charset/Charset; -
 field public,static,final UTF_8_OR_16 Ljava/nio/charset/Charset; -
in 11
class com/electronwill/nightconfig/core/io/ArrayInput 52 public,final,super com/electronwill/nightconfig/core/io/AbstractInput - -
 method public <init> (Lcom/electronwill/nightconfig/core/io/CharsWrapper;)V - -
 method public <init> ([C)V - -
 method public <init> ([CII)V - -
 method protected directRead ()I - -
 method protected directReadChar ()C - com/electronwill/nightconfig/core/io/ParsingException
 method public read (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public readChars (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
in 11
class com/electronwill/nightconfig/core/io/CharacterInput 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 method public,abstract read ()I - -
 method public,abstract readChar ()C - -
 method public readAndSkip ([C)I - -
 method public readCharAndSkip ([C)C - -
 method public read (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public readChars (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public,abstract readUntil ([C)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public,abstract readCharsUntil ([C)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public,abstract peek ()I - -
 method public,abstract peek (I)I - -
 method public,abstract peekChar ()C - -
 method public,abstract peekChar (I)C - -
 method public,abstract skipPeeks ()V - -
 method public,abstract pushBack (C)V - -
in 11
class com/electronwill/nightconfig/core/io/CharacterOutput 52 public,interface,abstract java/lang/Object - -
 method public,abstract write (C)V - -
 method public,varargs write ([C)V - -
 method public,abstract write ([CII)V - -
 method public write (Ljava/lang/String;)V - -
 method public,abstract write (Ljava/lang/String;II)V - -
 method public write (Lcom/electronwill/nightconfig/core/io/CharsWrapper;)V - -
in 11
class com/electronwill/nightconfig/core/io/CharsWrapper 52 public,final,super java/lang/Object java/lang/CharSequence,java/lang/Cloneable,java/lang/Iterable Ljava/lang/Object;Ljava/lang/CharSequence;Ljava/lang/Cloneable;Ljava/lang/Iterable<Ljava/lang/Character;>;
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 method public,varargs <init> ([C)V - -
 method public <init> ([CII)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;II)V - -
 method public <init> (Ljava/lang/CharSequence;)V - -
 method public <init> (Ljava/lang/CharSequence;II)V - -
 method public isEmpty ()Z - -
 method public length ()I - -
 method public charAt (I)C - -
 method public get (I)C - -
 method public set (IC)V - -
 method public replaceAll (CC)V - -
 method public contains (C)Z - -
 method public indexOf (C)I - -
 method public,varargs indexOfFirst ([C)I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public equalsIgnoreCase (Ljava/lang/CharSequence;)Z - -
 method public contentEquals (Ljava/lang/CharSequence;)Z - -
 method public contentEquals ([C)Z - -
 method public startsWith (Ljava/lang/CharSequence;)Z - -
 method public subSequence (II)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public subView (II)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public subView (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public trimmedView ()Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public toString ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public clone ()Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Ljava/lang/Character;>; -
in 11
class com/electronwill/nightconfig/core/io/CharsWrapper$Builder 52 public,final,super java/io/Writer com/electronwill/nightconfig/core/io/CharacterOutput -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 method public <init> (I)V - -
 method public append (C)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public append (Ljava/lang/CharSequence;)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public append (Ljava/lang/CharSequence;II)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public,varargs append ([C)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public append ([CII)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public append (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public append (Ljava/lang/String;II)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public append (Lcom/electronwill/nightconfig/core/io/CharsWrapper;)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public append (Ljava/lang/Object;)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public,varargs append ([Ljava/lang/Object;)Lcom/electronwill/nightconfig/core/io/CharsWrapper$Builder; - -
 method public flush ()V - -
 method public close ()V - -
 method public write (I)V - -
 method public write (C)V - -
 method public,varargs write ([C)V - -
 method public write ([CII)V - -
 method public write (Ljava/lang/String;)V - -
 method public write (Ljava/lang/String;II)V - -
 method public write (Lcom/electronwill/nightconfig/core/io/CharsWrapper;)V - -
 method public length ()I - -
 method public getChars ()[C - -
 method public get (I)C - -
 method public set (IC)V - -
 method public compact ()V - -
 method public build ()Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public build (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public build (II)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public copyAndBuild ()Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public copyAndBuild (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public copyAndBuild (II)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public toString ()Ljava/lang/String; - -
 method public toString (I)Ljava/lang/String; - -
 method public toString (II)Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/io/CharsetUnicodeBom 52 super java/nio/charset/Charset - -
 inner com/electronwill/nightconfig/core/io/CharsetUnicodeBom$Encoder com/electronwill/nightconfig/core/io/CharsetUnicodeBom Encoder private,static,final
 inner com/electronwill/nightconfig/core/io/CharsetUnicodeBom$Decoder com/electronwill/nightconfig/core/io/CharsetUnicodeBom Decoder private,static,final
 method protected <init> (Z)V - -
 method public canEncode ()Z - -
 method public contains (Ljava/nio/charset/Charset;)Z - -
 method public newDecoder ()Ljava/nio/charset/CharsetDecoder; - -
 method public newEncoder ()Ljava/nio/charset/CharsetEncoder; - -
in 8
class com/electronwill/nightconfig/core/io/CharsetUnicodeBom$Decoder 52 final,super java/nio/charset/CharsetDecoder - -
 inner com/electronwill/nightconfig/core/io/CharsetUnicodeBom$Decoder com/electronwill/nightconfig/core/io/CharsetUnicodeBom Decoder private,static,final
 method public isAutoDetecting ()Z - -
 method public isCharsetDetected ()Z - -
 method public detectedCharset ()Ljava/nio/charset/Charset; - -
 method protected implFlush (Ljava/nio/CharBuffer;)Ljava/nio/charset/CoderResult; - -
 method protected implReset ()V - -
 method protected decodeLoop (Ljava/nio/ByteBuffer;Ljava/nio/CharBuffer;)Ljava/nio/charset/CoderResult; - -
in 8
class com/electronwill/nightconfig/core/io/CharsetUnicodeBom$Encoder 52 final,super java/nio/charset/CharsetEncoder - -
 inner com/electronwill/nightconfig/core/io/CharsetUnicodeBom$Encoder com/electronwill/nightconfig/core/io/CharsetUnicodeBom Encoder private,static,final
 method public canEncode (C)Z - -
 method public canEncode (Ljava/lang/CharSequence;)Z - -
 method public isLegalReplacement ([B)Z - -
 method protected implReset ()V - -
 method protected implFlush (Ljava/nio/ByteBuffer;)Ljava/nio/charset/CoderResult; - -
 method protected encodeLoop (Ljava/nio/CharBuffer;Ljava/nio/ByteBuffer;)Ljava/nio/charset/CoderResult; - -
in 11
class com/electronwill/nightconfig/core/io/ConfigParser 52 public,interface,abstract java/lang/Object - <C::Lcom/electronwill/nightconfig/core/Config;>Ljava/lang/Object;
 method public,abstract getFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<TC;>; -
 method public,abstract parse (Ljava/io/Reader;)Lcom/electronwill/nightconfig/core/Config; (Ljava/io/Reader;)TC; -
 method public,abstract parse (Ljava/io/Reader;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;)V - -
 method public parse (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/Config; (Ljava/lang/String;)TC; -
 method public parse (Ljava/lang/String;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;)V - -
 method public parse (Ljava/io/InputStream;)Lcom/electronwill/nightconfig/core/Config; (Ljava/io/InputStream;)TC; -
 method public parse (Ljava/io/InputStream;Ljava/nio/charset/Charset;)Lcom/electronwill/nightconfig/core/Config; (Ljava/io/InputStream;Ljava/nio/charset/Charset;)TC; -
 method public parse (Ljava/io/InputStream;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;)V - -
 method public parse (Ljava/io/InputStream;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;Ljava/nio/charset/Charset;)V - -
 method public parse (Ljava/io/File;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)Lcom/electronwill/nightconfig/core/Config; (Ljava/io/File;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)TC; -
 method public parse (Ljava/io/File;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;Ljava/nio/charset/Charset;)Lcom/electronwill/nightconfig/core/Config; (Ljava/io/File;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;Ljava/nio/charset/Charset;)TC; -
 method public parse (Ljava/io/File;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)V - -
 method public parse (Ljava/io/File;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;Ljava/nio/charset/Charset;)V - -
 method public parse (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)Lcom/electronwill/nightconfig/core/Config; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)TC; -
 method public parse (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;Ljava/nio/charset/Charset;)Lcom/electronwill/nightconfig/core/Config; (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;Ljava/nio/charset/Charset;)TC; -
 method public parse (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;)V - -
 method public parse (Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;Lcom/electronwill/nightconfig/core/file/FileNotFoundAction;Ljava/nio/charset/Charset;)V - -
 method public parse (Ljava/net/URL;)Lcom/electronwill/nightconfig/core/Config; (Ljava/net/URL;)TC; -
 method public parse (Ljava/net/URL;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;)V - -
in 19
class com/electronwill/nightconfig/core/io/ConfigWriter 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 method public,abstract write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/Writer;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/OutputStream;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/io/WritingMode;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/io/WritingMode;Ljava/nio/charset/Charset;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/File;Lcom/electronwill/nightconfig/core/io/WritingMode;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/File;Lcom/electronwill/nightconfig/core/io/WritingMode;Ljava/nio/charset/Charset;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/net/URL;)V - -
 method public writeToString (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Ljava/lang/String; - -
in 16
class com/electronwill/nightconfig/core/io/ConfigWriter 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 inner com/electronwill/nightconfig/core/io/IoUtils$IoRunnable com/electronwill/nightconfig/core/io/IoUtils IoRunnable public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/Writer;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/OutputStream;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/io/WritingMode;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/nio/file/Path;Lcom/electronwill/nightconfig/core/io/WritingMode;Ljava/nio/charset/Charset;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/File;Lcom/electronwill/nightconfig/core/io/WritingMode;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/File;Lcom/electronwill/nightconfig/core/io/WritingMode;Ljava/nio/charset/Charset;)V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/net/URL;)V - -
 method public writeToString (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)Ljava/lang/String; - -
in 3
class com/electronwill/nightconfig/core/io/IndentStyle 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/io/IndentStyle;>;
 field public,static,final,enum TABS Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,static,final,enum SPACES_2 Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,static,final,enum SPACES_4 Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,static,final,enum SPACES_8 Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,final chars [C -
 method public,static values ()[Lcom/electronwill/nightconfig/core/io/IndentStyle; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/IndentStyle; - -
in 20
class com/electronwill/nightconfig/core/io/IndentStyle 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/io/IndentStyle;>;
 field public,static,final,enum TABS Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,static,final,enum SPACES_2 Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,static,final,enum SPACES_4 Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,static,final,enum SPACES_8 Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,static,final,enum NONE Lcom/electronwill/nightconfig/core/io/IndentStyle; -
 field public,final chars [C -
 method public,static values ()[Lcom/electronwill/nightconfig/core/io/IndentStyle; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/IndentStyle; - -
in 16
class com/electronwill/nightconfig/core/io/IoUtils 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/IoUtils$OptionHolder com/electronwill/nightconfig/core/io/IoUtils OptionHolder static
 inner com/electronwill/nightconfig/core/io/IoUtils$RetryFailedException com/electronwill/nightconfig/core/io/IoUtils RetryFailedException public,static,final
 inner com/electronwill/nightconfig/core/io/IoUtils$IoRunnable com/electronwill/nightconfig/core/io/IoUtils IoRunnable public,static,interface,abstract
 method public <init> ()V - -
 method public,static tempConfigFileName (Ljava/nio/file/Path;)Ljava/lang/String; - -
 method public,static retryIfAccessDenied (Ljava/lang/String;Lcom/electronwill/nightconfig/core/io/IoUtils$IoRunnable;)V - java/io/IOException
 method public,static retryIfAccessDenied (Ljava/lang/String;Lcom/electronwill/nightconfig/core/io/IoUtils$IoRunnable;IJLjava/util/concurrent/TimeUnit;)V - java/io/IOException
in 16
class com/electronwill/nightconfig/core/io/IoUtils$IoRunnable 52 public,interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/IoUtils$IoRunnable com/electronwill/nightconfig/core/io/IoUtils IoRunnable public,static,interface,abstract
 method public,abstract run ()V - java/io/IOException
in 16
class com/electronwill/nightconfig/core/io/IoUtils$OptionHolder 52 super java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/IoUtils$OptionHolder com/electronwill/nightconfig/core/io/IoUtils OptionHolder static
in 16
class com/electronwill/nightconfig/core/io/IoUtils$RetryFailedException 52 public,final,super java/io/IOException - -
 inner com/electronwill/nightconfig/core/io/IoUtils$RetryFailedException com/electronwill/nightconfig/core/io/IoUtils RetryFailedException public,static,final
in 11
class com/electronwill/nightconfig/core/io/NewlineStyle 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/io/NewlineStyle;>;
 field public,static,final,enum UNIX Lcom/electronwill/nightconfig/core/io/NewlineStyle; -
 field public,static,final,enum WINDOWS Lcom/electronwill/nightconfig/core/io/NewlineStyle; -
 field public,final chars [C -
 method public,static values ()[Lcom/electronwill/nightconfig/core/io/NewlineStyle; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/NewlineStyle; - -
 method public,static system ()Lcom/electronwill/nightconfig/core/io/NewlineStyle; - -
in 11
class com/electronwill/nightconfig/core/io/ParsingException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static readFailed (Ljava/lang/Throwable;)Lcom/electronwill/nightconfig/core/io/ParsingException; - -
 method public,static notEnoughData ()Lcom/electronwill/nightconfig/core/io/ParsingException; - -
in 10
class com/electronwill/nightconfig/core/io/ParsingMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/io/ParsingMode;>;
 inner com/electronwill/nightconfig/core/io/ParsingMode$MapPutAction com/electronwill/nightconfig/core/io/ParsingMode MapPutAction private,static,interface,abstract
 inner com/electronwill/nightconfig/core/io/ParsingMode$PutAction com/electronwill/nightconfig/core/io/ParsingMode PutAction private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum REPLACE Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 field public,static,final,enum MERGE Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 field public,static,final,enum ADD Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/io/ParsingMode; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/ParsingMode; - -
 method public prepareParsing (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public put (Lcom/electronwill/nightconfig/core/Config;Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; (Lcom/electronwill/nightconfig/core/Config;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Ljava/lang/Object; -
 method public put (Lcom/electronwill/nightconfig/core/Config;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public put (Ljava/util/Map;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; -
in 4
class com/electronwill/nightconfig/core/io/ParsingMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/io/ParsingMode;>;
 inner com/electronwill/nightconfig/core/io/ParsingMode$PutAction com/electronwill/nightconfig/core/io/ParsingMode PutAction private,static,interface,abstract
 inner com/electronwill/nightconfig/core/io/ParsingMode$MapPutAction com/electronwill/nightconfig/core/io/ParsingMode MapPutAction private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum REPLACE Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 field public,static,final,enum MERGE Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 field public,static,final,enum ADD Lcom/electronwill/nightconfig/core/io/ParsingMode; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/io/ParsingMode; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/ParsingMode; - -
 method public prepareParsing (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public put (Lcom/electronwill/nightconfig/core/Config;Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; (Lcom/electronwill/nightconfig/core/Config;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Ljava/lang/Object; -
 method public put (Lcom/electronwill/nightconfig/core/Config;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public put (Ljava/util/Map;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; -
in 11
class com/electronwill/nightconfig/core/io/ParsingMode$MapPutAction 52 interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/ParsingMode$MapPutAction com/electronwill/nightconfig/core/io/ParsingMode MapPutAction private,static,interface,abstract
 method public,abstract put (Ljava/util/Map;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; -
in 11
class com/electronwill/nightconfig/core/io/ParsingMode$PutAction 52 interface,abstract java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/ParsingMode$PutAction com/electronwill/nightconfig/core/io/ParsingMode PutAction private,static,interface,abstract
 method public,abstract put (Lcom/electronwill/nightconfig/core/Config;Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; (Lcom/electronwill/nightconfig/core/Config;Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Ljava/lang/Object; -
 method public put (Lcom/electronwill/nightconfig/core/Config;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
in 11
class com/electronwill/nightconfig/core/io/ReaderInput 52 public,final,super com/electronwill/nightconfig/core/io/AbstractInput - -
 method public <init> (Ljava/io/Reader;)V - -
 method protected directRead ()I - -
 method protected directReadChar ()C - com/electronwill/nightconfig/core/io/ParsingException
 method public read (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
 method public readChars (I)Lcom/electronwill/nightconfig/core/io/CharsWrapper; - -
in 11
class com/electronwill/nightconfig/core/io/Utils 52 public,final,super java/lang/Object - -
 method public,static arrayContains ([CC)Z - -
 method public,static arrayIndexOf ([CC)I - -
 method public,static parseLong (Lcom/electronwill/nightconfig/core/io/CharsWrapper;I)J - -
 method public,static parseInt (Lcom/electronwill/nightconfig/core/io/CharsWrapper;I)I - -
 method public,static parseDouble (Lcom/electronwill/nightconfig/core/io/CharsWrapper;)D - -
in 11
class com/electronwill/nightconfig/core/io/WriterOutput 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/io/CharacterOutput -
 method public <init> (Ljava/io/Writer;)V - -
 method public write (C)V - -
 method public write ([CII)V - -
 method public write (Ljava/lang/String;II)V - -
in 11
class com/electronwill/nightconfig/core/io/WritingException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/Throwable;)V - -
in 9
class com/electronwill/nightconfig/core/io/WritingMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/io/WritingMode;>;
 field public,static,final,enum REPLACE Lcom/electronwill/nightconfig/core/io/WritingMode; -
 field public,static,final,enum APPEND Lcom/electronwill/nightconfig/core/io/WritingMode; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/io/WritingMode; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/WritingMode; - -
in 8
class com/electronwill/nightconfig/core/io/WritingMode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/io/WritingMode;>;
 field public,static,final,enum REPLACE Lcom/electronwill/nightconfig/core/io/WritingMode; -
 field public,static,final,enum REPLACE_ATOMIC Lcom/electronwill/nightconfig/core/io/WritingMode; -
 field public,static,final,enum APPEND Lcom/electronwill/nightconfig/core/io/WritingMode; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/io/WritingMode; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/io/WritingMode; - -
in 8
class com/electronwill/nightconfig/core/serde/AbstractObjectDeserializer 52 super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue com/electronwill/nightconfig/core/serde/annotations/SerdeDefault WhenValue public,static,final,enum
 inner com/electronwill/nightconfig/core/serde/TypeConstraint$ManuallyParameterized com/electronwill/nightconfig/core/serde/TypeConstraint ManuallyParameterized static,final
 field protected,final generalProviders Ljava/util/List; Ljava/util/List<Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider<**>;>;
 field protected defaultProvider Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider; Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider<**>;
 field protected,final applyTransientModifier Z -
 method protected <init> (Lcom/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder;)V - -
 method protected deserializeToCollection (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Class;)Ljava/util/Collection; <C::Ljava/util/Collection<TV;>;V:Ljava/lang/Object;>(Ljava/lang/Object;Ljava/lang/Class<TC;>;Ljava/lang/Class<TV;>;)TC; -
 method protected deserializeToMap (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Class;)Ljava/util/Map; <M::Ljava/util/Map<Ljava/lang/String;TV;>;V:Ljava/lang/Object;>(Ljava/lang/Object;Ljava/lang/Class<TM;>;Ljava/lang/Class<TV;>;)TM; -
 method protected deserializeFields (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/lang/Object;)V - -
 method protected deserializeFields (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<+TR;>;)TR; -
 method protected findValueDeserializer (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/TypeConstraint;)Lcom/electronwill/nightconfig/core/serde/ValueDeserializer; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Lcom/electronwill/nightconfig/core/serde/TypeConstraint;)Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<TT;TR;>; -
 method protected findDefaultValueSupplier (Ljava/lang/Object;Ljava/lang/reflect/Field;Ljava/lang/Object;)Ljava/util/function/Supplier; (Ljava/lang/Object;Ljava/lang/reflect/Field;Ljava/lang/Object;)Ljava/util/function/Supplier<*>; -
in 8
class com/electronwill/nightconfig/core/serde/AnnotationProcessor 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/AnnotationProcessor$SerdeAssertSanityCheck com/electronwill/nightconfig/core/serde/AnnotationProcessor SerdeAssertSanityCheck private,static
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat com/electronwill/nightconfig/core/serde/annotations/SerdeAssert AssertThat public,static,final,enum
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf SkipDeIf public,static,final,enum
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf SkipSerIf public,static,final,enum
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue com/electronwill/nightconfig/core/serde/annotations/SerdeDefault WhenValue public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 8
class com/electronwill/nightconfig/core/serde/AnnotationProcessor$SerdeAssertSanityCheck 52 super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/AnnotationProcessor$SerdeAssertSanityCheck com/electronwill/nightconfig/core/serde/AnnotationProcessor SerdeAssertSanityCheck private,static
in 8
class com/electronwill/nightconfig/core/serde/ConfigToPojoDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/lang/Object;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public deserialize (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Object; (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Object; -
in 8
class com/electronwill/nightconfig/core/serde/DeserializerContext 52 public,final,super java/lang/Object - -
 method public deserializeValue (Ljava/lang/Object;Ljava/util/Optional;)Ljava/lang/Object; (Ljava/lang/Object;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;)Ljava/lang/Object; -
 method public deserializeFields (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/lang/Object;)V - -
in 8
class com/electronwill/nightconfig/core/serde/ObjectDeserializer 52 public,final,super com/electronwill/nightconfig/core/serde/AbstractObjectDeserializer - -
 method public,static builder ()Lcom/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder; - -
 method public,static blankBuilder ()Lcom/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder; - -
 method public,static standard ()Lcom/electronwill/nightconfig/core/serde/ObjectDeserializer; - -
 method public deserializeToCollection (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Class;)Ljava/util/Collection; <C::Ljava/util/Collection<TV;>;V:Ljava/lang/Object;>(Ljava/lang/Object;Ljava/lang/Class<TC;>;Ljava/lang/Class<TV;>;)TC; -
 method public deserializeToMap (Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/Class;)Ljava/util/Map; <M::Ljava/util/Map<Ljava/lang/String;TV;>;V:Ljava/lang/Object;>(Ljava/lang/Object;Ljava/lang/Class<TM;>;Ljava/lang/Class<TV;>;)TM; -
 method public deserializeFields (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/lang/Object;)V - -
 method public deserializeFields (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/util/function/Supplier<+TR;>;)TR; -
in 8
class com/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder$NoProvider com/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder NoProvider static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$TrivialDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers TrivialDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$MapDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers MapDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers CollectionDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionToArrayDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers CollectionToArrayDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$EnumDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers EnumDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$UuidDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers UuidDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$RiskyNumberDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers RiskyNumberDeserializer static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public build ()Lcom/electronwill/nightconfig/core/serde/ObjectDeserializer; - -
 method public deserializeTransientFields ()V - -
 method public withDeserializerForClass (Ljava/lang/Class;Ljava/lang/Class;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer;)V <V:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/lang/Class<TV;>;Ljava/lang/Class<TR;>;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<-TV;+TR;>;)V -
 method public withDeserializerProvider (Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider;)V <V:Ljava/lang/Object;R:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider<TV;TR;>;)V -
 method public withDefaultDeserializerProvider (Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider;)V <V:Ljava/lang/Object;R:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider<TV;TR;>;)V -
 method public withDefaultDeserializerProvider ()V - -
in 8
class com/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder$NoProvider 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializerProvider Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializerProvider<Ljava/lang/Object;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder$NoProvider com/electronwill/nightconfig/core/serde/ObjectDeserializerBuilder NoProvider static,final
 method public provide (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/serde/TypeConstraint;)Lcom/electronwill/nightconfig/core/serde/ValueDeserializer; (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/serde/TypeConstraint;)Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/lang/Object;Ljava/lang/Object;>; -
in 8
class com/electronwill/nightconfig/core/serde/ObjectSerializer 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue com/electronwill/nightconfig/core/serde/annotations/SerdeDefault WhenValue public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static builder ()Lcom/electronwill/nightconfig/core/serde/ObjectSerializerBuilder; - -
 method public,static blankBuilder ()Lcom/electronwill/nightconfig/core/serde/ObjectSerializerBuilder; - -
 method public,static standard ()Lcom/electronwill/nightconfig/core/serde/ObjectSerializer; - -
 method public serialize (Ljava/lang/Object;Ljava/util/function/Supplier;)Ljava/lang/Object; (Ljava/lang/Object;Ljava/util/function/Supplier<+Lcom/electronwill/nightconfig/core/Config;>;)Ljava/lang/Object; -
 method public serializeFields (Ljava/lang/Object;Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/Config; <C::Lcom/electronwill/nightconfig/core/Config;>(Ljava/lang/Object;Ljava/util/function/Supplier<TC;>;)TC; -
 method public serializeFields (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/Config;)V - -
in 8
class com/electronwill/nightconfig/core/serde/ObjectSerializerBuilder 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/ObjectSerializerBuilder$NoProvider com/electronwill/nightconfig/core/serde/ObjectSerializerBuilder NoProvider static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$TrivialSerializer com/electronwill/nightconfig/core/serde/StandardSerializers TrivialSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$FieldsToConfigSerializer com/electronwill/nightconfig/core/serde/StandardSerializers FieldsToConfigSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$MapSerializer com/electronwill/nightconfig/core/serde/StandardSerializers MapSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$CollectionSerializer com/electronwill/nightconfig/core/serde/StandardSerializers CollectionSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$IterableSerializer com/electronwill/nightconfig/core/serde/StandardSerializers IterableSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$ArraySerializer com/electronwill/nightconfig/core/serde/StandardSerializers ArraySerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$EnumSerializer com/electronwill/nightconfig/core/serde/StandardSerializers EnumSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$UuidSerializer com/electronwill/nightconfig/core/serde/StandardSerializers UuidSerializer static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public build ()Lcom/electronwill/nightconfig/core/serde/ObjectSerializer; - -
 method public withSerializerForExactClass (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/serde/ValueSerializer;)V <V:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/lang/Class<TV;>;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<-TV;+TR;>;)V -
 method public withSerializerForClass (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/serde/ValueSerializer;)V <V:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/lang/Class<TV;>;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<-TV;+TR;>;)V -
 method public withSerializerProvider (Lcom/electronwill/nightconfig/core/serde/ValueSerializerProvider;)V <V:Ljava/lang/Object;R:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/serde/ValueSerializerProvider<TV;TR;>;)V -
 method public withDefaultSerializerProvider (Lcom/electronwill/nightconfig/core/serde/ValueSerializerProvider;)V <V:Ljava/lang/Object;R:Ljava/lang/Object;>(Lcom/electronwill/nightconfig/core/serde/ValueSerializerProvider<TV;TR;>;)V -
 method public withDefaultSerializerProvider ()V - -
 method public serializeTransientFields ()V - -
in 8
class com/electronwill/nightconfig/core/serde/ObjectSerializerBuilder$NoProvider 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializerProvider Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializerProvider<Ljava/lang/Object;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/serde/ObjectSerializerBuilder$NoProvider com/electronwill/nightconfig/core/serde/ObjectSerializerBuilder NoProvider static,final
 method public provide (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Lcom/electronwill/nightconfig/core/serde/ValueSerializer; (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/lang/Object;Ljava/lang/Object;>; -
in 8
class com/electronwill/nightconfig/core/serde/SerdeAssertException 52 public,final,super com/electronwill/nightconfig/core/serde/SerdeException - -
in 8
class com/electronwill/nightconfig/core/serde/SerdeException 52 public,super java/lang/RuntimeException - -
in 8
class com/electronwill/nightconfig/core/serde/SerializerContext 52 public,final,super java/lang/Object - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
 method public createConfig ()Lcom/electronwill/nightconfig/core/Config; - -
 method public createCommentedConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public serializeValue (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public serializeFields (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/Config;)V - -
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$RiskyNumberDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers RiskyNumberDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$UuidDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers UuidDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$EnumDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers EnumDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionToArrayDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers CollectionToArrayDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers CollectionDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$MapDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers MapDeserializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$TrivialDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers TrivialDeserializer static,final
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/util/Collection<*>;Ljava/util/Collection<*>;>;
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers CollectionDeserializer static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public deserialize (Ljava/util/Collection;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/util/Collection; (Ljava/util/Collection<*>;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/util/Collection<*>; -
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionToArrayDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/util/Collection<*>;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$CollectionToArrayDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers CollectionToArrayDeserializer static,final
 method public deserialize (Ljava/util/Collection;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Object; (Ljava/util/Collection<*>;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Object; -
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers$EnumDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/lang/String;Ljava/lang/Enum<*>;>;
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$EnumDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers EnumDeserializer static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public deserialize (Ljava/lang/String;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Enum; (Ljava/lang/String;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Enum<*>; -
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers$MapDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/lang/Object;Ljava/util/Map<Ljava/lang/String;*>;>;
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$MapDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers MapDeserializer static,final
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public deserialize (Ljava/lang/Object;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/util/Map; (Ljava/lang/Object;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/util/Map<Ljava/lang/String;*>; -
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers$RiskyNumberDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/lang/Number;Ljava/lang/Number;>;
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$RiskyNumberDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers RiskyNumberDeserializer static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static isNumberTypeSupported (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
 method public deserialize (Ljava/lang/Number;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Number; (Ljava/lang/Number;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Number; -
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers$TrivialDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/lang/Object;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$TrivialDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers TrivialDeserializer static,final
 method public deserialize (Ljava/lang/Object;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Object; (Ljava/lang/Object;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Object; -
in 8
class com/electronwill/nightconfig/core/serde/StandardDeserializers$UuidDeserializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueDeserializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<Ljava/lang/String;Ljava/util/UUID;>;
 inner com/electronwill/nightconfig/core/serde/StandardDeserializers$UuidDeserializer com/electronwill/nightconfig/core/serde/StandardDeserializers UuidDeserializer static,final
 method public deserialize (Ljava/lang/String;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/util/UUID; (Ljava/lang/String;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/util/UUID; -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$UuidSerializer com/electronwill/nightconfig/core/serde/StandardSerializers UuidSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$FieldsToConfigSerializer com/electronwill/nightconfig/core/serde/StandardSerializers FieldsToConfigSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$TrivialSerializer com/electronwill/nightconfig/core/serde/StandardSerializers TrivialSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$EnumSerializer com/electronwill/nightconfig/core/serde/StandardSerializers EnumSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$ArraySerializer com/electronwill/nightconfig/core/serde/StandardSerializers ArraySerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$IterableSerializer com/electronwill/nightconfig/core/serde/StandardSerializers IterableSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$CollectionSerializer com/electronwill/nightconfig/core/serde/StandardSerializers CollectionSerializer static,final
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$MapSerializer com/electronwill/nightconfig/core/serde/StandardSerializers MapSerializer static,final
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$ArraySerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/lang/Object;Ljava/util/List<*>;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$ArraySerializer com/electronwill/nightconfig/core/serde/StandardSerializers ArraySerializer static,final
 method public serialize (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/util/List; (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/util/List<*>; -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$CollectionSerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/util/Collection<*>;Ljava/util/List<*>;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$CollectionSerializer com/electronwill/nightconfig/core/serde/StandardSerializers CollectionSerializer static,final
 method public serialize (Ljava/util/Collection;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/util/List; (Ljava/util/Collection<*>;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/util/List<*>; -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$EnumSerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/lang/Enum<*>;Ljava/lang/String;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$EnumSerializer com/electronwill/nightconfig/core/serde/StandardSerializers EnumSerializer static,final
 method public serialize (Ljava/lang/Enum;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/lang/String; (Ljava/lang/Enum<*>;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/lang/String; -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$FieldsToConfigSerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/lang/Object;Lcom/electronwill/nightconfig/core/Config;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$FieldsToConfigSerializer com/electronwill/nightconfig/core/serde/StandardSerializers FieldsToConfigSerializer static,final
 method public serialize (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Lcom/electronwill/nightconfig/core/Config; - -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$IterableSerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/lang/Iterable<*>;Ljava/util/List<*>;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$IterableSerializer com/electronwill/nightconfig/core/serde/StandardSerializers IterableSerializer static,final
 method public serialize (Ljava/lang/Iterable;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/util/List; (Ljava/lang/Iterable<*>;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/util/List<*>; -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$MapSerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/util/Map<**>;Lcom/electronwill/nightconfig/core/Config;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$MapSerializer com/electronwill/nightconfig/core/serde/StandardSerializers MapSerializer static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public serialize (Ljava/util/Map;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Lcom/electronwill/nightconfig/core/Config; (Ljava/util/Map<**>;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Lcom/electronwill/nightconfig/core/Config; -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$TrivialSerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/lang/Object;Ljava/lang/Object;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$TrivialSerializer com/electronwill/nightconfig/core/serde/StandardSerializers TrivialSerializer static,final
 method public serialize (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/lang/Object; - -
in 8
class com/electronwill/nightconfig/core/serde/StandardSerializers$UuidSerializer 52 final,super java/lang/Object com/electronwill/nightconfig/core/serde/ValueSerializer Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/ValueSerializer<Ljava/util/UUID;Ljava/lang/String;>;
 inner com/electronwill/nightconfig/core/serde/StandardSerializers$UuidSerializer com/electronwill/nightconfig/core/serde/StandardSerializers UuidSerializer static,final
 method public serialize (Ljava/util/UUID;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/serde/TypeConstraint 52 public,final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/TypeConstraint$ManuallyParameterized com/electronwill/nightconfig/core/serde/TypeConstraint ManuallyParameterized static,final
 inner com/electronwill/nightconfig/core/serde/TypeConstraint$RefinedWildcard com/electronwill/nightconfig/core/serde/TypeConstraint RefinedWildcard static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/reflect/Type;)V - -
 method public getFullType ()Ljava/lang/reflect/Type; - -
 method public getSatisfyingRawType ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Class<*>;>; -
 method public resolveTypeArgumentsFor (Ljava/lang/Class;)Ljava/util/Optional; (Ljava/lang/Class<*>;)Ljava/util/Optional<[Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>; -
 method public toString ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/serde/TypeConstraint$ManuallyParameterized 52 final,super java/lang/Object java/lang/reflect/ParameterizedType -
 inner com/electronwill/nightconfig/core/serde/TypeConstraint$ManuallyParameterized com/electronwill/nightconfig/core/serde/TypeConstraint ManuallyParameterized static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,varargs <init> (Ljava/lang/reflect/Type;[Ljava/lang/reflect/Type;)V - -
 method public getActualTypeArguments ()[Ljava/lang/reflect/Type; - -
 method public getOwnerType ()Ljava/lang/reflect/Type; - -
 method public getRawType ()Ljava/lang/reflect/Type; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
in 8
class com/electronwill/nightconfig/core/serde/TypeConstraint$RefinedWildcard 52 final,super java/lang/Object java/lang/reflect/WildcardType -
 inner com/electronwill/nightconfig/core/serde/TypeConstraint$RefinedWildcard com/electronwill/nightconfig/core/serde/TypeConstraint RefinedWildcard static,final
 method public getLowerBounds ()[Ljava/lang/reflect/Type; - -
 method public getUpperBounds ()[Ljava/lang/reflect/Type; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 8
class com/electronwill/nightconfig/core/serde/Util 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/Util$TypeAndOrder com/electronwill/nightconfig/core/serde/Util TypeAndOrder private,static,final
 inner com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables com/electronwill/nightconfig/core/serde/Util AdditionalEmptyables private,static,final
 inner com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables$EmptyableClass com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables EmptyableClass private,static
in 8
class com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables com/electronwill/nightconfig/core/serde/Util AdditionalEmptyables private,static,final
 inner com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables$EmptyableClass com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables EmptyableClass private,static
in 8
class com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables$EmptyableClass 52 super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables com/electronwill/nightconfig/core/serde/Util AdditionalEmptyables private,static,final
 inner com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables$EmptyableClass com/electronwill/nightconfig/core/serde/Util$AdditionalEmptyables EmptyableClass private,static
in 8
class com/electronwill/nightconfig/core/serde/Util$TypeAndOrder 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/serde/Util$TypeAndOrder com/electronwill/nightconfig/core/serde/Util TypeAndOrder private,static,final
 method public toString ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/serde/ValueDeserializer 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract deserialize (Ljava/lang/Object;Ljava/util/Optional;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)Ljava/lang/Object; (TT;Ljava/util/Optional<Lcom/electronwill/nightconfig/core/serde/TypeConstraint;>;Lcom/electronwill/nightconfig/core/serde/DeserializerContext;)TR; -
in 8
class com/electronwill/nightconfig/core/serde/ValueDeserializerProvider 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract provide (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/serde/TypeConstraint;)Lcom/electronwill/nightconfig/core/serde/ValueDeserializer; (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/serde/TypeConstraint;)Lcom/electronwill/nightconfig/core/serde/ValueDeserializer<TT;TR;>; -
in 8
class com/electronwill/nightconfig/core/serde/ValueSerializer 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract serialize (Ljava/lang/Object;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Ljava/lang/Object; (TT;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)TR; -
in 8
class com/electronwill/nightconfig/core/serde/ValueSerializerProvider 52 public,interface,abstract java/lang/Object - <V:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract provide (Ljava/lang/Class;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Lcom/electronwill/nightconfig/core/serde/ValueSerializer; (Ljava/lang/Class<*>;Lcom/electronwill/nightconfig/core/serde/SerializerContext;)Lcom/electronwill/nightconfig/core/serde/ValueSerializer<TV;TR;>; -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeAssert 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat com/electronwill/nightconfig/core/serde/annotations/SerdeAssert AssertThat public,static,final,enum
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLcom/electronwill/nightconfig/core/serde/annotations/SerdeAssertsContainer;)
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat; - -
 method public,abstract customClass ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
 method public,abstract customCheck ()Ljava/lang/String; - - ""
 method public,abstract phase ()Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase; - - ELcom/electronwill/nightconfig/core/serde/annotations/SerdePhase;#BOTH
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat;>;
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat com/electronwill/nightconfig/core/serde/annotations/SerdeAssert AssertThat public,static,final,enum
 field public,static,final,enum NOT_NULL Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat; -
 field public,static,final,enum NOT_EMPTY Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat; -
 field public,static,final,enum CUSTOM Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert$AssertThat; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeAssertsContainer 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeAssert; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeComment 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLcom/electronwill/nightconfig/core/serde/annotations/SerdeCommentsContainer;)
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeCommentsContainer 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeComment; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeDefault 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue com/electronwill/nightconfig/core/serde/annotations/SerdeDefault WhenValue public,static,final,enum
 anno visible @Ljava/lang/annotation/Repeatable;(value=TLcom/electronwill/nightconfig/core/serde/annotations/SerdeDefaultsContainer;)
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract cls ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
 method public,abstract provider ()Ljava/lang/String; - -
 method public,abstract phase ()Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase; - - ELcom/electronwill/nightconfig/core/serde/annotations/SerdePhase;#BOTH
 method public,abstract whenValue ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue; - - [ELcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue;#IS_MISSING]
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue;>;
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue com/electronwill/nightconfig/core/serde/annotations/SerdeDefault WhenValue public,static,final,enum
 field public,static,final,enum IS_MISSING Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue; -
 field public,static,final,enum IS_NULL Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue; -
 field public,static,final,enum IS_EMPTY Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault$WhenValue; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeDefaultsContainer 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeDefault; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeKey 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()Ljava/lang/String; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdePhase 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase;>;
 field public,static,final,enum SERIALIZING Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase; -
 field public,static,final,enum DESERIALIZING Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase; -
 field public,static,final,enum BOTH Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/serde/annotations/SerdePhase; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf SkipDeIf public,static,final,enum
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf; - -
 method public,abstract customClass ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
 method public,abstract customCheck ()Ljava/lang/String; - - ""
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf;>;
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf com/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf SkipDeIf public,static,final,enum
 field public,static,final,enum IS_MISSING Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf; -
 field public,static,final,enum IS_NULL Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf; -
 field public,static,final,enum IS_EMPTY Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf; -
 field public,static,final,enum CUSTOM Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipDeserializingIf$SkipDeIf; - -
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf SkipSerIf public,static,final,enum
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD])
 method public,abstract value ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf; - -
 method public,abstract customClass ()Ljava/lang/Class; ()Ljava/lang/Class<*>; - TLjava/lang/Object;
 method public,abstract customCheck ()Ljava/lang/String; - - ""
in 8
class com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf;>;
 inner com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf com/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf SkipSerIf public,static,final,enum
 field public,static,final,enum IS_NULL Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf; -
 field public,static,final,enum IS_EMPTY Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf; -
 field public,static,final,enum CUSTOM Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf; -
 method public,static values ()[Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf; - -
 method public,static valueOf (Ljava/lang/String;)Lcom/electronwill/nightconfig/core/serde/annotations/SerdeSkipSerializingIf$SkipSerIf; - -
in 11
class com/electronwill/nightconfig/core/utils/AbstractObserved 52 super,abstract java/lang/Object - -
 field protected,final callback Ljava/lang/Runnable; -
 method protected <init> (Ljava/lang/Runnable;)V - -
in 11
class com/electronwill/nightconfig/core/utils/CommentedConfigWrapper 52 public,super,abstract com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/CommentedConfig <C::Lcom/electronwill/nightconfig/core/CommentedConfig;>Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/CommentedConfig;
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 method protected <init> (Lcom/electronwill/nightconfig/core/CommentedConfig;)V (TC;)V -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public clearComments ()V - -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public toString ()Ljava/lang/String; - -
in 15
class com/electronwill/nightconfig/core/utils/ConcurrentCommentedConfigWrapper 52 public,super,abstract com/electronwill/nightconfig/core/utils/CommentedConfigWrapper com/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig <C::Lcom/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig;>Lcom/electronwill/nightconfig/core/utils/CommentedConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig;
 method protected <init> (Lcom/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig;)V (TC;)V -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/concurrent/ConcurrentCommentedConfig; - -
 method public bulkRead (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>;)V -
 method public bulkRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableConfig;TR;>;)TR; -
 method public bulkCommentedRead (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;>;)V -
 method public bulkCommentedRead (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;TR;>;)TR; -
 method public bulkUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/Config;>;)V -
 method public bulkUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/Config;TR;>;)TR; -
 method public bulkCommentedUpdate (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-Lcom/electronwill/nightconfig/core/CommentedConfig;>;)V -
 method public bulkCommentedUpdate (Ljava/util/function/Function;)Ljava/lang/Object; <R:Ljava/lang/Object;>(Ljava/util/function/Function<-Lcom/electronwill/nightconfig/core/CommentedConfig;TR;>;)TR; -
in 11
class com/electronwill/nightconfig/core/utils/ConfigWrapper 52 public,super,abstract com/electronwill/nightconfig/core/utils/UnmodifiableConfigWrapper com/electronwill/nightconfig/core/Config <C::Lcom/electronwill/nightconfig/core/Config;>Lcom/electronwill/nightconfig/core/utils/UnmodifiableConfigWrapper<TC;>;Lcom/electronwill/nightconfig/core/Config;
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 method protected <init> (Lcom/electronwill/nightconfig/core/Config;)V (TC;)V -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/Config$Entry;>; -
 method public set (Ljava/util/List;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)TT; -
 method public add (Ljava/util/List;Ljava/lang/Object;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/Object;)Z -
 method public remove (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public clear ()V - -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/Config; - -
 method public toString ()Ljava/lang/String; - -
in 3
class com/electronwill/nightconfig/core/utils/FakeCommentedConfig 52 public,final,super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/CommentedConfig Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<Lcom/electronwill/nightconfig/core/Config;>;Lcom/electronwill/nightconfig/core/CommentedConfig;
 inner com/electronwill/nightconfig/core/utils/FakeCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public clearComments ()V - -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 4
class com/electronwill/nightconfig/core/utils/FakeCommentedConfig 52 public,final,super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/CommentedConfig Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<Lcom/electronwill/nightconfig/core/Config;>;Lcom/electronwill/nightconfig/core/CommentedConfig;
 inner com/electronwill/nightconfig/core/utils/FakeCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public clearComments ()V - -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 8
class com/electronwill/nightconfig/core/utils/FakeCommentedConfig 52 public,final,super com/electronwill/nightconfig/core/utils/ConfigWrapper com/electronwill/nightconfig/core/CommentedConfig Lcom/electronwill/nightconfig/core/utils/ConfigWrapper<Lcom/electronwill/nightconfig/core/Config;>;Lcom/electronwill/nightconfig/core/CommentedConfig;
 inner com/electronwill/nightconfig/core/utils/FakeCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/Config;)V - -
 method public unwrap ()Lcom/electronwill/nightconfig/core/Config; - -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public setComment (Ljava/util/List;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public removeComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public clearComments ()V - -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public putAllComments (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>;)V -
 method public putAllComments (Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;)V - -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/CommentedConfig$Entry;>; -
 method public createSubConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
in 10
class com/electronwill/nightconfig/core/utils/FakeCommentedConfig$FakeCommentedEntry 52 final,super java/lang/Object com/electronwill/nightconfig/core/CommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/utils/FakeCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 method public getComment ()Ljava/lang/String; - -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public removeComment ()Ljava/lang/String; - -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
in 4
class com/electronwill/nightconfig/core/utils/FakeCommentedConfig$FakeCommentedEntry 52 final,super java/lang/Object com/electronwill/nightconfig/core/CommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/utils/FakeCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/CommentedConfig$Entry com/electronwill/nightconfig/core/CommentedConfig Entry public,static,interface,abstract
 method public getComment ()Ljava/lang/String; - -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
 method public setComment (Ljava/lang/String;)Ljava/lang/String; - -
 method public removeComment ()Ljava/lang/String; - -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Object;)TT; -
in 10
class com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig 52 public,final,super com/electronwill/nightconfig/core/utils/UnmodifiableConfigWrapper com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Lcom/electronwill/nightconfig/core/utils/UnmodifiableConfigWrapper<Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;
 inner com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry;>; -
in 4
class com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig 52 public,final,super com/electronwill/nightconfig/core/utils/UnmodifiableConfigWrapper com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Lcom/electronwill/nightconfig/core/utils/UnmodifiableConfigWrapper<Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig;
 inner com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode com/electronwill/nightconfig/core/UnmodifiableCommentedConfig CommentNode public,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V - -
 method public getComment (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public containsComment (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public getComments ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$CommentNode;>; -
 method public commentMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry;>; -
in 10
class com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig$FakeCommentedEntry 52 final,super java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 method public getComment ()Ljava/lang/String; - -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
in 4
class com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig$FakeCommentedEntry 52 final,super java/lang/Object com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry -
 inner com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig$FakeCommentedEntry com/electronwill/nightconfig/core/utils/FakeUnmodifiableCommentedConfig FakeCommentedEntry private,static,final
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 method public getComment ()Ljava/lang/String; - -
 method public getKey ()Ljava/lang/String; - -
 method public getRawValue ()Ljava/lang/Object; <T:Ljava/lang/Object;>()TT; -
in 11
class com/electronwill/nightconfig/core/utils/FastStringReader 52 public,final,super java/io/Reader - -
 method public <init> (Ljava/lang/String;I)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public read ()I - -
 method public read ([CII)I - -
 method public skip (J)J - -
 method public markSupported ()Z - -
 method public mark (I)V - -
 method public reset ()V - -
 method public ready ()Z - -
 method public close ()V - -
in 11
class com/electronwill/nightconfig/core/utils/IntDeque 52 public,final,super java/lang/Object - -
 method public <init> ()V - -
 method public <init> (I)V - -
 method public clear ()V - -
 method public isEmpty ()Z - -
 method public size ()I - -
 method public compact ()V - -
 method public addFirst (I)V - -
 method public addLast (I)V - -
 method public get (I)I - -
 method public getFirst ()I - -
 method public getLast ()I - -
 method public removeFirst ()I - -
 method public removeLast ()I - -
in 11
class com/electronwill/nightconfig/core/utils/ObservedEntry 52 public,final,super com/electronwill/nightconfig/core/utils/AbstractObserved java/util/Map$Entry <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/utils/AbstractObserved;Ljava/util/Map$Entry<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method protected <init> (Ljava/util/Map$Entry;Ljava/lang/Runnable;)V (Ljava/util/Map$Entry<TK;TV;>;Ljava/lang/Runnable;)V -
 method public getKey ()Ljava/lang/Object; ()TK; -
 method public getValue ()Ljava/lang/Object; ()TV; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; (TV;)TV; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 11
class com/electronwill/nightconfig/core/utils/ObservedIterator 52 public,final,super com/electronwill/nightconfig/core/utils/AbstractObserved java/util/Iterator <E:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/utils/AbstractObserved;Ljava/util/Iterator<TE;>;
 method public <init> (Ljava/util/Iterator;Ljava/lang/Runnable;)V (Ljava/util/Iterator<TE;>;Ljava/lang/Runnable;)V -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TE; -
 method public remove ()V - -
 method public forEachRemaining (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TE;>;)V -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 11
class com/electronwill/nightconfig/core/utils/ObservedMap 52 public,final,super com/electronwill/nightconfig/core/utils/AbstractObserved java/util/Map <K:Ljava/lang/Object;V:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/utils/AbstractObserved;Ljava/util/Map<TK;TV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Map;Ljava/lang/Runnable;)V (Ljava/util/Map<TK;TV;>;Ljava/lang/Runnable;)V -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TV; -
 method public putAll (Ljava/util/Map;)V (Ljava/util/Map<+TK;+TV;>;)V -
 method public replaceAll (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<-TK;-TV;+TV;>;)V -
 method public putIfAbsent (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public remove (Ljava/lang/Object;Ljava/lang/Object;)Z - -
 method public replace (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z (TK;TV;TV;)Z -
 method public replace (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TV;)TV; -
 method public computeIfAbsent (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; (TK;Ljava/util/function/Function<-TK;+TV;>;)TV; -
 method public computeIfPresent (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;Ljava/util/function/BiFunction<-TK;-TV;+TV;>;)TV; -
 method public compute (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;Ljava/util/function/BiFunction<-TK;-TV;+TV;>;)TV; -
 method public merge (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;TV;Ljava/util/function/BiFunction<-TV;-TV;+TV;>;)TV; -
 method public clear ()V - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<TV;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;TV;>;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 11
class com/electronwill/nightconfig/core/utils/ObservedSet 52 public,final,super com/electronwill/nightconfig/core/utils/AbstractObserved java/util/Set <K:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/utils/AbstractObserved;Ljava/util/Set<TK;>;
 method public <init> (Ljava/util/Set;Ljava/lang/Runnable;)V (Ljava/util/Set<TK;>;Ljava/lang/Runnable;)V -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TK;>; -
 method public toArray ()[Ljava/lang/Object; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public add (Ljava/lang/Object;)Z (TK;)Z -
 method public remove (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TK;>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TK;>;)Z -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 15
class com/electronwill/nightconfig/core/utils/ObservedSet2 52 public,final,super com/electronwill/nightconfig/core/utils/AbstractObserved java/util/Set <K:Ljava/lang/Object;KImpl:TK;>Lcom/electronwill/nightconfig/core/utils/AbstractObserved;Ljava/util/Set<TK;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/Runnable;Ljava/util/Set;Ljava/util/function/Function;)V (Ljava/lang/Runnable;Ljava/util/Set<TKImpl;>;Ljava/util/function/Function<TK;TKImpl;>;)V -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TK;>; -
 method public toArray ()[Ljava/lang/Object; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public add (Ljava/lang/Object;)Z (TK;)Z -
 method public remove (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TK;>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TK;>;)Z -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 11
class com/electronwill/nightconfig/core/utils/StringUtils 52 public,final,super java/lang/Object - -
 method public,static split (Ljava/lang/String;C)Ljava/util/List; (Ljava/lang/String;C)Ljava/util/List<Ljava/lang/String;>; -
 method public,static split (Ljava/lang/String;CLjava/util/List;)V (Ljava/lang/String;CLjava/util/List<Ljava/lang/String;>;)V -
 method public,static splitLines (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static splitLines (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;)V -
in 3
class com/electronwill/nightconfig/core/utils/TransformingCollection 52 public,super java/lang/Object java/util/Collection <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Collection<TExternalV;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Collection;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/Collection<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;)V -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TExternalV;>; -
 method public toArray ()[Ljava/lang/Object; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public add (Ljava/lang/Object;)Z (TExternalV;)Z -
 method public remove (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TExternalV;>;)Z -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TExternalV;>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TExternalV;>; -
 method public stream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<TExternalV;>; -
 method public parallelStream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<TExternalV;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TExternalV;>;)V -
in 20
class com/electronwill/nightconfig/core/utils/TransformingCollection 52 public,super java/lang/Object java/util/Collection <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Collection<TExternalV;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final readTransformation Ljava/util/function/Function; Ljava/util/function/Function<-TInternalV;+TExternalV;>;
 field protected,final writeTransformation Ljava/util/function/Function; Ljava/util/function/Function<-TExternalV;+TInternalV;>;
 field protected,final searchTransformation Ljava/util/function/Function; Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;
 field protected,final internalCollection Ljava/util/Collection; Ljava/util/Collection<TInternalV;>;
 method public <init> (Ljava/util/Collection;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/Collection<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;)V -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public contains (Ljava/lang/Object;)Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TExternalV;>; -
 method public toArray ()[Ljava/lang/Object; - -
 method public toArray ([Ljava/lang/Object;)[Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;)[TT; -
 method public add (Ljava/lang/Object;)Z (TExternalV;)Z -
 method public remove (Ljava/lang/Object;)Z - -
 method public containsAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public addAll (Ljava/util/Collection;)Z (Ljava/util/Collection<+TExternalV;>;)Z -
 method public removeAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public removeIf (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<-TExternalV;>;)Z -
 method public retainAll (Ljava/util/Collection;)Z (Ljava/util/Collection<*>;)Z -
 method public clear ()V - -
 method public spliterator ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TExternalV;>; -
 method public stream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<TExternalV;>; -
 method public parallelStream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<TExternalV;>; -
 method public forEach (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TExternalV;>;)V -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 3
class com/electronwill/nightconfig/core/utils/TransformingIterator 52 public,final,super java/lang/Object java/util/Iterator <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TExternalV;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Iterator;Ljava/util/function/Function;)V (Ljava/util/Iterator<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;)V -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TExternalV; -
 method public remove ()V - -
 method public forEachRemaining (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TExternalV;>;)V -
in 20
class com/electronwill/nightconfig/core/utils/TransformingIterator 52 public,super java/lang/Object java/util/Iterator <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Iterator<TExternalV;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final readTransformation Ljava/util/function/Function; Ljava/util/function/Function<-TInternalV;+TExternalV;>;
 field protected,final internalIterator Ljava/util/Iterator; Ljava/util/Iterator<TInternalV;>;
 method public <init> (Ljava/util/Iterator;Ljava/util/function/Function;)V (Ljava/util/Iterator<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;)V -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; ()TExternalV; -
 method public remove ()V - -
 method public forEachRemaining (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TExternalV;>;)V -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 20
class com/electronwill/nightconfig/core/utils/TransformingList 52 public,final,super com/electronwill/nightconfig/core/utils/TransformingCollection java/util/List <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/utils/TransformingCollection<TInternalV;TExternalV;>;Ljava/util/List<TExternalV;>;
 method public <init> (Ljava/util/List;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/List<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;)V -
 method public addAll (ILjava/util/Collection;)Z (ILjava/util/Collection<+TExternalV;>;)Z -
 method public get (I)Ljava/lang/Object; (I)TExternalV; -
 method public set (ILjava/lang/Object;)Ljava/lang/Object; (ITExternalV;)TExternalV; -
 method public add (ILjava/lang/Object;)V (ITExternalV;)V -
 method public remove (I)Ljava/lang/Object; (I)TExternalV; -
 method public indexOf (Ljava/lang/Object;)I - -
 method public lastIndexOf (Ljava/lang/Object;)I - -
 method public listIterator ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<TExternalV;>; -
 method public listIterator (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<TExternalV;>; -
 method public subList (II)Ljava/util/List; (II)Ljava/util/List<TExternalV;>; -
in 20
class com/electronwill/nightconfig/core/utils/TransformingListIterator 52 public,final,super com/electronwill/nightconfig/core/utils/TransformingIterator java/util/ListIterator <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/utils/TransformingIterator<TInternalV;TExternalV;>;Ljava/util/ListIterator<TExternalV;>;
 method public <init> (Ljava/util/ListIterator;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/ListIterator<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;)V -
 method public hasPrevious ()Z - -
 method public previous ()Ljava/lang/Object; ()TExternalV; -
 method public nextIndex ()I - -
 method public previousIndex ()I - -
 method public set (Ljava/lang/Object;)V (TExternalV;)V -
 method public add (Ljava/lang/Object;)V (TExternalV;)V -
in 11
class com/electronwill/nightconfig/core/utils/TransformingMap 52 public,final,super java/util/AbstractMap - <K:Ljava/lang/Object;InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/util/AbstractMap<TK;TExternalV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Map;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/Map<TK;TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;)V -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public containsKey (Ljava/lang/Object;)Z - -
 method public containsValue (Ljava/lang/Object;)Z - -
 method public get (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TExternalV; -
 method public put (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TExternalV;)TExternalV; -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TExternalV; -
 method public putAll (Ljava/util/Map;)V (Ljava/util/Map<+TK;+TExternalV;>;)V -
 method public clear ()V - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<TK;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<TExternalV;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<TK;TExternalV;>;>; -
 method public getOrDefault (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;TExternalV;)TExternalV; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<-TK;-TExternalV;>;)V -
 method public replaceAll (Ljava/util/function/BiFunction;)V (Ljava/util/function/BiFunction<-TK;-TExternalV;+TExternalV;>;)V -
 method public putIfAbsent (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TExternalV;)TExternalV; -
 method public remove (Ljava/lang/Object;Ljava/lang/Object;)Z - -
 method public replace (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z (TK;TExternalV;TExternalV;)Z -
 method public replace (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TK;TExternalV;)TExternalV; -
 method public computeIfAbsent (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; (TK;Ljava/util/function/Function<-TK;+TExternalV;>;)TExternalV; -
 method public computeIfPresent (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;Ljava/util/function/BiFunction<-TK;-TExternalV;+TExternalV;>;)TExternalV; -
 method public compute (Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;Ljava/util/function/BiFunction<-TK;-TExternalV;+TExternalV;>;)TExternalV; -
 method public merge (Ljava/lang/Object;Ljava/lang/Object;Ljava/util/function/BiFunction;)Ljava/lang/Object; (TK;TExternalV;Ljava/util/function/BiFunction<-TExternalV;-TExternalV;+TExternalV;>;)TExternalV; -
in 11
class com/electronwill/nightconfig/core/utils/TransformingMapEntry 52 final,super java/lang/Object java/util/Map$Entry <K:Ljava/lang/Object;InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Map$Entry<TK;TExternalV;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public getKey ()Ljava/lang/Object; ()TK; -
 method public getValue ()Ljava/lang/Object; ()TExternalV; -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; (TExternalV;)TExternalV; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 11
class com/electronwill/nightconfig/core/utils/TransformingSet 52 public,final,super com/electronwill/nightconfig/core/utils/TransformingCollection java/util/Set <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Lcom/electronwill/nightconfig/core/utils/TransformingCollection<TInternalV;TExternalV;>;Ljava/util/Set<TExternalV;>;
 method public <init> (Ljava/util/Set;Ljava/util/function/Function;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/Set<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;Ljava/util/function/Function<Ljava/lang/Object;Ljava/lang/Object;>;)V -
in 3
class com/electronwill/nightconfig/core/utils/TransformingSpliterator 52 public,final,super java/lang/Object java/util/Spliterator <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Spliterator<TExternalV;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Spliterator;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/Spliterator<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;)V -
 method public tryAdvance (Ljava/util/function/Consumer;)Z (Ljava/util/function/Consumer<-TExternalV;>;)Z -
 method public forEachRemaining (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TExternalV;>;)V -
 method public trySplit ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TExternalV;>; -
 method public estimateSize ()J - -
 method public getExactSizeIfKnown ()J - -
 method public characteristics ()I - -
 method public hasCharacteristics (I)Z - -
 method public getComparator ()Ljava/util/Comparator; ()Ljava/util/Comparator<-TExternalV;>; -
in 20
class com/electronwill/nightconfig/core/utils/TransformingSpliterator 52 public,final,super java/lang/Object java/util/Spliterator <InternalV:Ljava/lang/Object;ExternalV:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Spliterator<TExternalV;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Spliterator;Ljava/util/function/Function;Ljava/util/function/Function;)V (Ljava/util/Spliterator<TInternalV;>;Ljava/util/function/Function<-TInternalV;+TExternalV;>;Ljava/util/function/Function<-TExternalV;+TInternalV;>;)V -
 method public tryAdvance (Ljava/util/function/Consumer;)Z (Ljava/util/function/Consumer<-TExternalV;>;)Z -
 method public forEachRemaining (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<-TExternalV;>;)V -
 method public trySplit ()Ljava/util/Spliterator; ()Ljava/util/Spliterator<TExternalV;>; -
 method public estimateSize ()J - -
 method public getExactSizeIfKnown ()J - -
 method public characteristics ()I - -
 method public hasCharacteristics (I)Z - -
 method public getComparator ()Ljava/util/Comparator; ()Ljava/util/Comparator<-TExternalV;>; -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
in 11
class com/electronwill/nightconfig/core/utils/UnmodifiableConfigWrapper 52 public,super,abstract java/lang/Object com/electronwill/nightconfig/core/UnmodifiableConfig <C::Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>Ljava/lang/Object;Lcom/electronwill/nightconfig/core/UnmodifiableConfig;
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 field protected,final config Lcom/electronwill/nightconfig/core/UnmodifiableConfig; TC;
 method protected <init> (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;)V (TC;)V -
 method public getRaw (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/String;>;)TT; -
 method public valueMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<+Lcom/electronwill/nightconfig/core/UnmodifiableConfig$Entry;>; -
 method public contains (Ljava/util/List;)Z (Ljava/util/List<Ljava/lang/String;>;)Z -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public configFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<*>; -
in 11
class com/electronwill/nightconfig/core/utils/WriterSupplier 52 public,interface,abstract java/lang/Object - -
 method public,abstract get ()Ljava/io/Writer; - java/io/IOException
in 11
class com/electronwill/nightconfig/toml/ArrayParser 52 final,super java/lang/Object - -
in 11
class com/electronwill/nightconfig/toml/ArrayWriter 52 final,super java/lang/Object - -
in 9
class com/electronwill/nightconfig/toml/StringParser 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
in 8
class com/electronwill/nightconfig/toml/StringParser 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 9
class com/electronwill/nightconfig/toml/StringWriter 52 final,super java/lang/Object - -
in 8
class com/electronwill/nightconfig/toml/StringWriter 52 final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 11
class com/electronwill/nightconfig/toml/TableParser 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
in 3
class com/electronwill/nightconfig/toml/TableWriter 52 final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
in 4
class com/electronwill/nightconfig/toml/TableWriter 52 final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 8
class com/electronwill/nightconfig/toml/TableWriter 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/toml/TableWriter$OrganizedTable com/electronwill/nightconfig/toml/TableWriter OrganizedTable static
 inner com/electronwill/nightconfig/core/UnmodifiableConfig$Entry com/electronwill/nightconfig/core/UnmodifiableConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 8
class com/electronwill/nightconfig/toml/TableWriter$OrganizedTable 52 super java/lang/Object - -
 inner com/electronwill/nightconfig/core/UnmodifiableCommentedConfig$Entry com/electronwill/nightconfig/core/UnmodifiableCommentedConfig Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/toml/TableWriter$OrganizedTable com/electronwill/nightconfig/toml/TableWriter OrganizedTable static
 method public toString ()Ljava/lang/String; - -
in 11
class com/electronwill/nightconfig/toml/TemporalParser 52 final,super java/lang/Object - -
in 11
class com/electronwill/nightconfig/toml/TemporalWriter 52 final,super java/lang/Object - -
in 11
class com/electronwill/nightconfig/toml/Toml 52 final,super java/lang/Object - -
in 11
class com/electronwill/nightconfig/toml/TomlFormat 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/ConfigFormat Ljava/lang/Object;Lcom/electronwill/nightconfig/core/ConfigFormat<Lcom/electronwill/nightconfig/core/CommentedConfig;>;
 method public,static instance ()Lcom/electronwill/nightconfig/toml/TomlFormat; - -
 method public,static newConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public,static newConfig (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public,static newConcurrentConfig ()Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public createWriter ()Lcom/electronwill/nightconfig/toml/TomlWriter; - -
 method public createParser ()Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public createConfig (Ljava/util/function/Supplier;)Lcom/electronwill/nightconfig/core/CommentedConfig; (Ljava/util/function/Supplier<Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;>;)Lcom/electronwill/nightconfig/core/CommentedConfig; -
 method public supportsComments ()Z - -
 method public supportsType (Ljava/lang/Class;)Z (Ljava/lang/Class<*>;)Z -
in 3
class com/electronwill/nightconfig/toml/TomlParser 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/io/ConfigParser Ljava/lang/Object;Lcom/electronwill/nightconfig/core/io/ConfigParser<Lcom/electronwill/nightconfig/core/CommentedConfig;>;
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 method public <init> ()V - -
 method public parse (Ljava/io/Reader;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public parse (Ljava/io/Reader;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;)V - -
 method public isLenientWithSeparators ()Z - -
 method public setLenientWithSeparators (Z)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public isLenientWithBareKeys ()Z - -
 method public setLenientWithBareKeys (Z)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public setInitialStringBuilderCapacity (I)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public setInitialListCapacity (I)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public getFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<Lcom/electronwill/nightconfig/core/CommentedConfig;>; -
in 4
class com/electronwill/nightconfig/toml/TomlParser 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/io/ConfigParser Ljava/lang/Object;Lcom/electronwill/nightconfig/core/io/ConfigParser<Lcom/electronwill/nightconfig/core/CommentedConfig;>;
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Ljava/io/Reader;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public parse (Ljava/io/Reader;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;)V - -
 method public isLenientWithSeparators ()Z - -
 method public setLenientWithSeparators (Z)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public isLenientWithBareKeys ()Z - -
 method public setLenientWithBareKeys (Z)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public setInitialStringBuilderCapacity (I)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public setInitialListCapacity (I)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public getFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<Lcom/electronwill/nightconfig/core/CommentedConfig;>; -
in 8
class com/electronwill/nightconfig/toml/TomlParser 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/io/ConfigParser Ljava/lang/Object;Lcom/electronwill/nightconfig/core/io/ConfigParser<Lcom/electronwill/nightconfig/core/CommentedConfig;>;
 inner com/electronwill/nightconfig/core/Config$Entry com/electronwill/nightconfig/core/Config Entry public,static,interface,abstract
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Ljava/io/Reader;)Lcom/electronwill/nightconfig/core/CommentedConfig; - -
 method public parse (Ljava/io/Reader;Lcom/electronwill/nightconfig/core/Config;Lcom/electronwill/nightconfig/core/io/ParsingMode;)V - -
 method public isLenientWithSeparators ()Z - -
 method public setLenientWithSeparators (Z)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public isLenientWithBareKeys ()Z - -
 method public setLenientWithBareKeys (Z)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public setInitialStringBuilderCapacity (I)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public setInitialListCapacity (I)Lcom/electronwill/nightconfig/toml/TomlParser; - -
 method public getFormat ()Lcom/electronwill/nightconfig/core/ConfigFormat; ()Lcom/electronwill/nightconfig/core/ConfigFormat<Lcom/electronwill/nightconfig/core/CommentedConfig;>; -
in 3
class com/electronwill/nightconfig/toml/TomlWriter 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/io/ConfigWriter -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/Writer;)V - -
 method public isLenientWithBareKeys ()Z - -
 method public setLenientWithBareKeys (Z)V - -
 method public setWriteTableInlinePredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>;)V -
 method public setWriteStringLiteralPredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
 method public setIndentArrayElementsPredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/util/List<*>;>;)V -
 method public setIndent (Lcom/electronwill/nightconfig/core/io/IndentStyle;)V - -
 method public setIndent (Ljava/lang/String;)V - -
 method public setNewline (Lcom/electronwill/nightconfig/core/io/NewlineStyle;)V - -
 method public setNewline (Ljava/lang/String;)V - -
in 4
class com/electronwill/nightconfig/toml/TomlWriter 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/io/ConfigWriter -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/Writer;)V - -
 method public isLenientWithBareKeys ()Z - -
 method public setLenientWithBareKeys (Z)V - -
 method public isOmitIntermediateLevels ()Z - -
 method public setOmitIntermediateLevels (Z)V - -
 method public setWriteTableInlinePredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>;)V -
 method public setWriteStringLiteralPredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
 method public setIndentArrayElementsPredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/util/List<*>;>;)V -
 method public setIndent (Lcom/electronwill/nightconfig/core/io/IndentStyle;)V - -
 method public setIndent (Ljava/lang/String;)V - -
 method public setNewline (Lcom/electronwill/nightconfig/core/io/NewlineStyle;)V - -
 method public setNewline (Ljava/lang/String;)V - -
in 8
class com/electronwill/nightconfig/toml/TomlWriter 52 public,final,super java/lang/Object com/electronwill/nightconfig/core/io/ConfigWriter -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public write (Lcom/electronwill/nightconfig/core/UnmodifiableConfig;Ljava/io/Writer;)V - -
 method public isHidingRedundantLevels ()Z - -
 method public setHideRedundantLevels (Z)V - -
 method public isOmitIntermediateLevels ()Z - -
 method public setOmitIntermediateLevels (Z)V - -
 method public isLenientWithBareKeys ()Z - -
 method public setLenientWithBareKeys (Z)V - -
 method public setWriteTableInlinePredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Lcom/electronwill/nightconfig/core/UnmodifiableConfig;>;)V -
 method public setWriteStringLiteralPredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
 method public setWriteStringMultilinePredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/lang/String;>;)V -
 method public setIndentArrayElementsPredicate (Ljava/util/function/Predicate;)V (Ljava/util/function/Predicate<Ljava/util/List<*>;>;)V -
 method public setIndent (Lcom/electronwill/nightconfig/core/io/IndentStyle;)V - -
 method public setIndent (Ljava/lang/String;)V - -
 method public setNewline (Lcom/electronwill/nightconfig/core/io/NewlineStyle;)V - -
 method public setNewline (Ljava/lang/String;)V - -
in 11
class com/electronwill/nightconfig/toml/ValueParser 52 final,super java/lang/Object - -
 inner com/electronwill/nightconfig/core/io/CharsWrapper$Builder com/electronwill/nightconfig/core/io/CharsWrapper Builder public,static,final
in 10
class com/electronwill/nightconfig/toml/ValueWriter 52 final,super java/lang/Object - -
in 4
class com/electronwill/nightconfig/toml/ValueWriter 52 final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
