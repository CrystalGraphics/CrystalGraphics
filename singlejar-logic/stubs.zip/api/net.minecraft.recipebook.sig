cg-stub-db 1
in 59
class net/minecraft/recipebook/PlaceRecipe 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public placeRecipe (IIILnet/minecraft/world/item/crafting/Recipe;Ljava/util/Iterator;I)V (IIILnet/minecraft/world/item/crafting/Recipe;Ljava/util/Iterator<TT;>;I)V -
 method public,abstract addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<TT;>;IIII)V -
in 92
class net/minecraft/recipebook/PlaceRecipe 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public placeRecipe (IIILnet/minecraft/world/item/crafting/Recipe;Ljava/util/Iterator;I)V (IIILnet/minecraft/world/item/crafting/Recipe<*>;Ljava/util/Iterator<TT;>;I)V -
 method public,abstract addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<TT;>;IIII)V -
in 82
class net/minecraft/recipebook/PlaceRecipe 60 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public placeRecipe (IIILnet/minecraft/world/item/crafting/Recipe;Ljava/util/Iterator;I)V (IIILnet/minecraft/world/item/crafting/Recipe<*>;Ljava/util/Iterator<TT;>;I)V -
 method public,abstract addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<TT;>;IIII)V -
in 36
class net/minecraft/recipebook/PlaceRecipe 61 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public placeRecipe (IIILnet/minecraft/world/item/crafting/Recipe;Ljava/util/Iterator;I)V (IIILnet/minecraft/world/item/crafting/Recipe<*>;Ljava/util/Iterator<TT;>;I)V -
 method public,abstract addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<TT;>;IIII)V -
in 234
class net/minecraft/recipebook/PlaceRecipe 61 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public placeRecipe (IIILnet/minecraft/world/item/crafting/RecipeHolder;Ljava/util/Iterator;I)V (IIILnet/minecraft/world/item/crafting/RecipeHolder<*>;Ljava/util/Iterator<TT;>;I)V -
 method public,abstract addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<TT;>;IIII)V -
in 224
class net/minecraft/recipebook/PlaceRecipe 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public placeRecipe (IIILnet/minecraft/world/item/crafting/RecipeHolder;Ljava/util/Iterator;I)V (IIILnet/minecraft/world/item/crafting/RecipeHolder<*>;Ljava/util/Iterator<TT;>;I)V -
 method public,abstract addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<TT;>;IIII)V -
in 235
class net/minecraft/recipebook/PlaceRecipe 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public placeRecipe (IIILnet/minecraft/world/item/crafting/RecipeHolder;Ljava/util/Iterator;I)V (IIILnet/minecraft/world/item/crafting/RecipeHolder<*>;Ljava/util/Iterator<TT;>;I)V -
 method public,abstract addItemToSlot (Ljava/lang/Object;IIII)V (TT;IIII)V -
in 69
class net/minecraft/recipebook/PlaceRecipeHelper 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/recipebook/PlaceRecipeHelper$Output net/minecraft/recipebook/PlaceRecipeHelper Output public,static,interface,abstract
 method public,static placeRecipe (IILnet/minecraft/world/item/crafting/Recipe;Ljava/lang/Iterable;Lnet/minecraft/recipebook/PlaceRecipeHelper$Output;)V <T:Ljava/lang/Object;>(IILnet/minecraft/world/item/crafting/Recipe<*>;Ljava/lang/Iterable<TT;>;Lnet/minecraft/recipebook/PlaceRecipeHelper$Output<TT;>;)V -
 method public,static placeRecipe (IIIILjava/lang/Iterable;Lnet/minecraft/recipebook/PlaceRecipeHelper$Output;)V <T:Ljava/lang/Object;>(IIIILjava/lang/Iterable<TT;>;Lnet/minecraft/recipebook/PlaceRecipeHelper$Output<TT;>;)V -
in 69
class net/minecraft/recipebook/PlaceRecipeHelper$Output 65 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/recipebook/PlaceRecipeHelper$Output net/minecraft/recipebook/PlaceRecipeHelper Output public,static,interface,abstract
 method public,abstract addItemToSlot (Ljava/lang/Object;III)V (TT;III)V -
in 59
class net/minecraft/recipebook/ServerPlaceRecipe 52 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,static,final LOGGER Lorg/apache/logging/log4j/Logger; -
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Laqr; -
 method public <init> ()V - -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe;Z)V - -
 method protected clearGrid ()V - -
 method protected moveItemToInventory (I)V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/Recipe;Z)V - -
 method public addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<Ljava/lang/Integer;>;IIII)V -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;)V - -
in 92
class net/minecraft/recipebook/ServerPlaceRecipe 52 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe <C::Lnet/minecraft/world/Container;>Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,static,final LOGGER Lorg/apache/logging/log4j/Logger; -
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Lnet/minecraft/world/inventory/RecipeBookMenu; Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;)V -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method protected clearGrid ()V - -
 method protected moveItemToInventory (I)V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method public addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<Ljava/lang/Integer;>;IIII)V -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;)V - -
in 82
class net/minecraft/recipebook/ServerPlaceRecipe 60 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe <C::Lnet/minecraft/world/Container;>Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,static,final LOGGER Lorg/apache/logging/log4j/Logger; -
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Lnet/minecraft/world/inventory/RecipeBookMenu; Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;)V -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method protected clearGrid (Z)V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method public addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<Ljava/lang/Integer;>;IIII)V -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;)V - -
in 218
class net/minecraft/recipebook/ServerPlaceRecipe 61 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe <C::Lnet/minecraft/world/Container;>Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Lnet/minecraft/world/inventory/RecipeBookMenu; Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;)V -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method protected clearGrid (Z)V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method public addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<Ljava/lang/Integer;>;IIII)V -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;)V - -
in 91
class net/minecraft/recipebook/ServerPlaceRecipe 61 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe <C::Lnet/minecraft/world/Container;>Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Lnet/minecraft/world/inventory/RecipeBookMenu; Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;)V -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method protected clearGrid ()V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method public addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<Ljava/lang/Integer;>;IIII)V -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;)V - -
in 234
class net/minecraft/recipebook/ServerPlaceRecipe 61 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe <C::Lnet/minecraft/world/Container;>Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Lnet/minecraft/world/inventory/RecipeBookMenu; Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;)V -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/RecipeHolder;Z)V (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/RecipeHolder<+Lnet/minecraft/world/item/crafting/Recipe<TC;>;>;Z)V -
 method protected clearGrid ()V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/RecipeHolder;Z)V (Lnet/minecraft/world/item/crafting/RecipeHolder<+Lnet/minecraft/world/item/crafting/Recipe<TC;>;>;Z)V -
 method public addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<Ljava/lang/Integer;>;IIII)V -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;)V - -
in 224
class net/minecraft/recipebook/ServerPlaceRecipe 65 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe <C::Lnet/minecraft/world/Container;>Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Lnet/minecraft/world/inventory/RecipeBookMenu; Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;)V -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/RecipeHolder;Z)V (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/RecipeHolder<+Lnet/minecraft/world/item/crafting/Recipe<TC;>;>;Z)V -
 method protected clearGrid ()V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/RecipeHolder;Z)V (Lnet/minecraft/world/item/crafting/RecipeHolder<+Lnet/minecraft/world/item/crafting/Recipe<TC;>;>;Z)V -
 method public addItemToSlot (Ljava/util/Iterator;IIII)V (Ljava/util/Iterator<Ljava/lang/Integer;>;IIII)V -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;)V - -
in 235
class net/minecraft/recipebook/ServerPlaceRecipe 65 public,super java/lang/Object net/minecraft/recipebook/PlaceRecipe <I::Lnet/minecraft/world/item/crafting/RecipeInput;R::Lnet/minecraft/world/item/crafting/Recipe<TI;>;>Ljava/lang/Object;Lnet/minecraft/recipebook/PlaceRecipe<Ljava/lang/Integer;>;
 field protected,final stackedContents Lnet/minecraft/world/entity/player/StackedContents; -
 field protected inventory Lnet/minecraft/world/entity/player/Inventory; -
 field protected menu Lnet/minecraft/world/inventory/RecipeBookMenu; Lnet/minecraft/world/inventory/RecipeBookMenu<TI;TR;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TI;TR;>;)V -
 method public recipeClicked (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/RecipeHolder;Z)V (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/RecipeHolder<TR;>;Z)V -
 method protected clearGrid ()V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/RecipeHolder;Z)V (Lnet/minecraft/world/item/crafting/RecipeHolder<TR;>;Z)V -
 method public addItemToSlot (Ljava/lang/Integer;IIII)V - -
 method protected getStackSize (ZIZ)I - -
 method protected moveItemToGrid (Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/item/ItemStack;I)I - -
in 70
class net/minecraft/recipebook/ServerPlaceRecipe 65 public,super java/lang/Object - <R::Lnet/minecraft/world/item/crafting/Recipe<*>;>Ljava/lang/Object;
 inner net/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess net/minecraft/recipebook/ServerPlaceRecipe CraftingMenuAccess public,static,interface,abstract
 inner net/minecraft/world/inventory/RecipeBookMenu$PostPlaceAction net/minecraft/world/inventory/RecipeBookMenu PostPlaceAction public,static,final,enum
 inner net/minecraft/world/entity/player/StackedContents$Output net/minecraft/world/entity/player/StackedContents Output public,static,interface,abstract
 inner net/minecraft/recipebook/PlaceRecipeHelper$Output net/minecraft/recipebook/PlaceRecipeHelper Output public,static,interface,abstract
 inner net/minecraft/world/item/crafting/PlacementInfo$SlotInfo net/minecraft/world/item/crafting/PlacementInfo SlotInfo public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static placeRecipe (Lnet/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess;IILjava/util/List;Ljava/util/List;Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/item/crafting/RecipeHolder;ZZ)Lnet/minecraft/world/inventory/RecipeBookMenu$PostPlaceAction; <I::Lnet/minecraft/world/item/crafting/RecipeInput;R::Lnet/minecraft/world/item/crafting/Recipe<TI;>;>(Lnet/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess<TR;>;IILjava/util/List<Lnet/minecraft/world/inventory/Slot;>;Ljava/util/List<Lnet/minecraft/world/inventory/Slot;>;Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/item/crafting/RecipeHolder<TR;>;ZZ)Lnet/minecraft/world/inventory/RecipeBookMenu$PostPlaceAction; -
in 28
class net/minecraft/recipebook/ServerPlaceRecipe 65 public,super java/lang/Object - <R::Lnet/minecraft/world/item/crafting/Recipe<*>;>Ljava/lang/Object;
 inner net/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess net/minecraft/recipebook/ServerPlaceRecipe CraftingMenuAccess public,static,interface,abstract
 inner net/minecraft/world/inventory/RecipeBookMenu$PostPlaceAction net/minecraft/world/inventory/RecipeBookMenu PostPlaceAction public,static,final,enum
 inner net/minecraft/world/entity/player/StackedContents$Output net/minecraft/world/entity/player/StackedContents Output public,static,interface,abstract
 inner net/minecraft/recipebook/PlaceRecipeHelper$Output net/minecraft/recipebook/PlaceRecipeHelper Output public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static placeRecipe (Lnet/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess;IILjava/util/List;Ljava/util/List;Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/item/crafting/RecipeHolder;ZZ)Lnet/minecraft/world/inventory/RecipeBookMenu$PostPlaceAction; <I::Lnet/minecraft/world/item/crafting/RecipeInput;R::Lnet/minecraft/world/item/crafting/Recipe<TI;>;>(Lnet/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess<TR;>;IILjava/util/List<Lnet/minecraft/world/inventory/Slot;>;Ljava/util/List<Lnet/minecraft/world/inventory/Slot;>;Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/item/crafting/RecipeHolder<TR;>;ZZ)Lnet/minecraft/world/inventory/RecipeBookMenu$PostPlaceAction; -
in 69
class net/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess 65 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/world/item/crafting/Recipe<*>;>Ljava/lang/Object;
 inner net/minecraft/recipebook/ServerPlaceRecipe$CraftingMenuAccess net/minecraft/recipebook/ServerPlaceRecipe CraftingMenuAccess public,static,interface,abstract
 method public,abstract fillCraftSlotsStackedContents (Lnet/minecraft/world/entity/player/StackedItemContents;)V - -
 method public,abstract clearCraftingContent ()V - -
 method public,abstract recipeMatches (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<TT;>;)Z -
in 59
class net/minecraft/recipebook/ServerPlaceSmeltingRecipe 52 public,super net/minecraft/recipebook/ServerPlaceRecipe - -
 method public <init> ()V - -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/Recipe;Z)V - -
 method protected clearGrid ()V - -
 method protected placeRecipe (ILit/unimi/dsi/fastutil/ints/IntList;)V - -
in 92
class net/minecraft/recipebook/ServerPlaceSmeltingRecipe 52 public,super net/minecraft/recipebook/ServerPlaceRecipe - <C::Lnet/minecraft/world/Container;>Lnet/minecraft/recipebook/ServerPlaceRecipe<TC;>;
 method public <init> (Lnet/minecraft/world/inventory/RecipeBookMenu;)V (Lnet/minecraft/world/inventory/RecipeBookMenu<TC;>;)V -
 method protected handleRecipeClicked (Lnet/minecraft/world/item/crafting/Recipe;Z)V (Lnet/minecraft/world/item/crafting/Recipe<TC;>;Z)V -
 method protected clearGrid ()V - -
 method protected placeRecipe (ILit/unimi/dsi/fastutil/ints/IntList;)V - -
