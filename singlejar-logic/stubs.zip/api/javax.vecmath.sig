cg-stub-db 1
in 256
class javax/vecmath/AxisAngle4d 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x D -
 field public y D -
 field public z D -
 field public angle D -
 method public <init> (DDDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/AxisAngle4d;)V - -
 method public <init> (Ljavax/vecmath/AxisAngle4f;)V - -
 method public <init> (Ljavax/vecmath/Vector3d;D)V - -
 method public <init> ()V - -
 method public,final set (DDDD)V - -
 method public,final set ([D)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/Vector3d;D)V - -
 method public,final get ([D)V - -
 method public,final set (Ljavax/vecmath/Matrix4f;)V - -
 method public,final set (Ljavax/vecmath/Matrix4d;)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set (Ljavax/vecmath/Quat4f;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljavax/vecmath/AxisAngle4d;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/AxisAngle4d;D)Z - -
 method public hashCode ()I - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getAngle ()D - -
 method public,final setAngle (D)V - -
 method public getX ()D - -
 method public,final setX (D)V - -
 method public,final getY ()D - -
 method public,final setY (D)V - -
 method public getZ ()D - -
 method public,final setZ (D)V - -
in 256
class javax/vecmath/AxisAngle4f 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x F -
 field public y F -
 field public z F -
 field public angle F -
 method public <init> (FFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/AxisAngle4f;)V - -
 method public <init> (Ljavax/vecmath/AxisAngle4d;)V - -
 method public <init> (Ljavax/vecmath/Vector3f;F)V - -
 method public <init> ()V - -
 method public,final set (FFFF)V - -
 method public,final set ([F)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final set (Ljavax/vecmath/Vector3f;F)V - -
 method public,final get ([F)V - -
 method public,final set (Ljavax/vecmath/Quat4f;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;)V - -
 method public,final set (Ljavax/vecmath/Matrix4f;)V - -
 method public,final set (Ljavax/vecmath/Matrix4d;)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljavax/vecmath/AxisAngle4f;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/AxisAngle4f;F)Z - -
 method public hashCode ()I - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getAngle ()F - -
 method public,final setAngle (F)V - -
 method public,final getX ()F - -
 method public,final setX (F)V - -
 method public,final getY ()F - -
 method public,final setY (F)V - -
 method public,final getZ ()F - -
 method public,final setZ (F)V - -
in 256
class javax/vecmath/Color3b 49 public,super javax/vecmath/Tuple3b java/io/Serializable -
 method public <init> (BBB)V - -
 method public <init> ([B)V - -
 method public <init> (Ljavax/vecmath/Color3b;)V - -
 method public <init> (Ljavax/vecmath/Tuple3b;)V - -
 method public <init> (Ljava/awt/Color;)V - -
 method public <init> ()V - -
 method public,final set (Ljava/awt/Color;)V - -
 method public,final get ()Ljava/awt/Color; - -
in 256
class javax/vecmath/Color3f 49 public,super javax/vecmath/Tuple3f java/io/Serializable -
 method public <init> (FFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Color3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> (Ljava/awt/Color;)V - -
 method public <init> ()V - -
 method public,final set (Ljava/awt/Color;)V - -
 method public,final get ()Ljava/awt/Color; - -
in 256
class javax/vecmath/Color4b 49 public,super javax/vecmath/Tuple4b java/io/Serializable -
 method public <init> (BBBB)V - -
 method public <init> ([B)V - -
 method public <init> (Ljavax/vecmath/Color4b;)V - -
 method public <init> (Ljavax/vecmath/Tuple4b;)V - -
 method public <init> (Ljava/awt/Color;)V - -
 method public <init> ()V - -
 method public,final set (Ljava/awt/Color;)V - -
 method public,final get ()Ljava/awt/Color; - -
in 256
class javax/vecmath/Color4f 49 public,super javax/vecmath/Tuple4f java/io/Serializable -
 method public <init> (FFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Color4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> (Ljava/awt/Color;)V - -
 method public <init> ()V - -
 method public,final set (Ljava/awt/Color;)V - -
 method public,final get ()Ljava/awt/Color; - -
in 256
class javax/vecmath/GMatrix 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 method public <init> (II)V - -
 method public <init> (II[D)V - -
 method public <init> (Ljavax/vecmath/GMatrix;)V - -
 method public,final mul (Ljavax/vecmath/GMatrix;)V - -
 method public,final mul (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;)V - -
 method public,final mul (Ljavax/vecmath/GVector;Ljavax/vecmath/GVector;)V - -
 method public,final add (Ljavax/vecmath/GMatrix;)V - -
 method public,final add (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;)V - -
 method public,final sub (Ljavax/vecmath/GMatrix;)V - -
 method public,final sub (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;)V - -
 method public,final negate ()V - -
 method public,final negate (Ljavax/vecmath/GMatrix;)V - -
 method public,final setIdentity ()V - -
 method public,final setZero ()V - -
 method public,final identityMinus ()V - -
 method public,final invert ()V - -
 method public,final invert (Ljavax/vecmath/GMatrix;)V - -
 method public,final copySubMatrix (IIIIIILjavax/vecmath/GMatrix;)V - -
 method public,final setSize (II)V - -
 method public,final set ([D)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set (Ljavax/vecmath/Matrix4f;)V - -
 method public,final set (Ljavax/vecmath/Matrix4d;)V - -
 method public,final set (Ljavax/vecmath/GMatrix;)V - -
 method public,final getNumRow ()I - -
 method public,final getNumCol ()I - -
 method public,final getElement (II)D - -
 method public,final setElement (IID)V - -
 method public,final getRow (I[D)V - -
 method public,final getRow (ILjavax/vecmath/GVector;)V - -
 method public,final getColumn (I[D)V - -
 method public,final getColumn (ILjavax/vecmath/GVector;)V - -
 method public,final get (Ljavax/vecmath/Matrix3d;)V - -
 method public,final get (Ljavax/vecmath/Matrix3f;)V - -
 method public,final get (Ljavax/vecmath/Matrix4d;)V - -
 method public,final get (Ljavax/vecmath/Matrix4f;)V - -
 method public,final get (Ljavax/vecmath/GMatrix;)V - -
 method public,final setRow (I[D)V - -
 method public,final setRow (ILjavax/vecmath/GVector;)V - -
 method public,final setColumn (I[D)V - -
 method public,final setColumn (ILjavax/vecmath/GVector;)V - -
 method public,final mulTransposeBoth (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;)V - -
 method public,final mulTransposeRight (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;)V - -
 method public,final mulTransposeLeft (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;)V - -
 method public,final transpose ()V - -
 method public,final transpose (Ljavax/vecmath/GMatrix;)V - -
 method public toString ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljavax/vecmath/GMatrix;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public,deprecated epsilonEquals (Ljavax/vecmath/GMatrix;F)Z - -
 method public epsilonEquals (Ljavax/vecmath/GMatrix;D)Z - -
 method public,final trace ()D - -
 method public,final SVD (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;)I - -
 method public,final LUD (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GVector;)I - -
 method public,final setScale (D)V - -
 method public clone ()Ljava/lang/Object; - -
in 256
class javax/vecmath/GVector 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 method public <init> (I)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/GVector;)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> ([DI)V - -
 method public,final norm ()D - -
 method public,final normSquared ()D - -
 method public,final normalize (Ljavax/vecmath/GVector;)V - -
 method public,final normalize ()V - -
 method public,final scale (DLjavax/vecmath/GVector;)V - -
 method public,final scale (D)V - -
 method public,final scaleAdd (DLjavax/vecmath/GVector;Ljavax/vecmath/GVector;)V - -
 method public,final add (Ljavax/vecmath/GVector;)V - -
 method public,final add (Ljavax/vecmath/GVector;Ljavax/vecmath/GVector;)V - -
 method public,final sub (Ljavax/vecmath/GVector;)V - -
 method public,final sub (Ljavax/vecmath/GVector;Ljavax/vecmath/GVector;)V - -
 method public,final mul (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GVector;)V - -
 method public,final mul (Ljavax/vecmath/GVector;Ljavax/vecmath/GMatrix;)V - -
 method public,final negate ()V - -
 method public,final zero ()V - -
 method public,final setSize (I)V - -
 method public,final set ([D)V - -
 method public,final set (Ljavax/vecmath/GVector;)V - -
 method public,final set (Ljavax/vecmath/Tuple2f;)V - -
 method public,final set (Ljavax/vecmath/Tuple3f;)V - -
 method public,final set (Ljavax/vecmath/Tuple3d;)V - -
 method public,final set (Ljavax/vecmath/Tuple4f;)V - -
 method public,final set (Ljavax/vecmath/Tuple4d;)V - -
 method public,final getSize ()I - -
 method public,final getElement (I)D - -
 method public,final setElement (ID)V - -
 method public toString ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljavax/vecmath/GVector;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/GVector;D)Z - -
 method public,final dot (Ljavax/vecmath/GVector;)D - -
 method public,final SVDBackSolve (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;Ljavax/vecmath/GMatrix;Ljavax/vecmath/GVector;)V - -
 method public,final LUDBackSolve (Ljavax/vecmath/GMatrix;Ljavax/vecmath/GVector;Ljavax/vecmath/GVector;)V - -
 method public,final angle (Ljavax/vecmath/GVector;)D - -
 method public,final,deprecated interpolate (Ljavax/vecmath/GVector;Ljavax/vecmath/GVector;F)V - -
 method public,final,deprecated interpolate (Ljavax/vecmath/GVector;F)V - -
 method public,final interpolate (Ljavax/vecmath/GVector;Ljavax/vecmath/GVector;D)V - -
 method public,final interpolate (Ljavax/vecmath/GVector;D)V - -
 method public clone ()Ljava/lang/Object; - -
in 256
class javax/vecmath/Matrix3d 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public m00 D -
 field public m01 D -
 field public m02 D -
 field public m10 D -
 field public m11 D -
 field public m12 D -
 field public m20 D -
 field public m21 D -
 field public m22 D -
 method public <init> (DDDDDDDDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Matrix3d;)V - -
 method public <init> (Ljavax/vecmath/Matrix3f;)V - -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final setIdentity ()V - -
 method public,final setScale (D)V - -
 method public,final setElement (IID)V - -
 method public,final getElement (II)D - -
 method public,final getRow (ILjavax/vecmath/Vector3d;)V - -
 method public,final getRow (I[D)V - -
 method public,final getColumn (ILjavax/vecmath/Vector3d;)V - -
 method public,final getColumn (I[D)V - -
 method public,final setRow (IDDD)V - -
 method public,final setRow (ILjavax/vecmath/Vector3d;)V - -
 method public,final setRow (I[D)V - -
 method public,final setColumn (IDDD)V - -
 method public,final setColumn (ILjavax/vecmath/Vector3d;)V - -
 method public,final setColumn (I[D)V - -
 method public,final getScale ()D - -
 method public,final add (D)V - -
 method public,final add (DLjavax/vecmath/Matrix3d;)V - -
 method public,final add (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Matrix3d;)V - -
 method public,final add (Ljavax/vecmath/Matrix3d;)V - -
 method public,final sub (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Matrix3d;)V - -
 method public,final sub (Ljavax/vecmath/Matrix3d;)V - -
 method public,final transpose ()V - -
 method public,final transpose (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final set (Ljavax/vecmath/Quat4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set ([D)V - -
 method public,final invert (Ljavax/vecmath/Matrix3d;)V - -
 method public,final invert ()V - -
 method public,final determinant ()D - -
 method public,final set (D)V - -
 method public,final rotX (D)V - -
 method public,final rotY (D)V - -
 method public,final rotZ (D)V - -
 method public,final mul (D)V - -
 method public,final mul (DLjavax/vecmath/Matrix3d;)V - -
 method public,final mul (Ljavax/vecmath/Matrix3d;)V - -
 method public,final mul (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Matrix3d;)V - -
 method public,final mulNormalize (Ljavax/vecmath/Matrix3d;)V - -
 method public,final mulNormalize (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Matrix3d;)V - -
 method public,final mulTransposeBoth (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Matrix3d;)V - -
 method public,final mulTransposeRight (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Matrix3d;)V - -
 method public,final mulTransposeLeft (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Matrix3d;)V - -
 method public,final normalize ()V - -
 method public,final normalize (Ljavax/vecmath/Matrix3d;)V - -
 method public,final normalizeCP ()V - -
 method public,final normalizeCP (Ljavax/vecmath/Matrix3d;)V - -
 method public equals (Ljavax/vecmath/Matrix3d;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Matrix3d;D)Z - -
 method public hashCode ()I - -
 method public,final setZero ()V - -
 method public,final negate ()V - -
 method public,final negate (Ljavax/vecmath/Matrix3d;)V - -
 method public,final transform (Ljavax/vecmath/Tuple3d;)V - -
 method public,final transform (Ljavax/vecmath/Tuple3d;Ljavax/vecmath/Tuple3d;)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getM00 ()D - -
 method public,final setM00 (D)V - -
 method public,final getM01 ()D - -
 method public,final setM01 (D)V - -
 method public,final getM02 ()D - -
 method public,final setM02 (D)V - -
 method public,final getM10 ()D - -
 method public,final setM10 (D)V - -
 method public,final getM11 ()D - -
 method public,final setM11 (D)V - -
 method public,final getM12 ()D - -
 method public,final setM12 (D)V - -
 method public,final getM20 ()D - -
 method public,final setM20 (D)V - -
 method public,final getM21 ()D - -
 method public,final setM21 (D)V - -
 method public,final getM22 ()D - -
 method public,final setM22 (D)V - -
in 256
class javax/vecmath/Matrix3f 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public m00 F -
 field public m01 F -
 field public m02 F -
 field public m10 F -
 field public m11 F -
 field public m12 F -
 field public m20 F -
 field public m21 F -
 field public m22 F -
 method public <init> (FFFFFFFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Matrix3d;)V - -
 method public <init> (Ljavax/vecmath/Matrix3f;)V - -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final setIdentity ()V - -
 method public,final setScale (F)V - -
 method public,final setElement (IIF)V - -
 method public,final getRow (ILjavax/vecmath/Vector3f;)V - -
 method public,final getRow (I[F)V - -
 method public,final getColumn (ILjavax/vecmath/Vector3f;)V - -
 method public,final getColumn (I[F)V - -
 method public,final getElement (II)F - -
 method public,final setRow (IFFF)V - -
 method public,final setRow (ILjavax/vecmath/Vector3f;)V - -
 method public,final setRow (I[F)V - -
 method public,final setColumn (IFFF)V - -
 method public,final setColumn (ILjavax/vecmath/Vector3f;)V - -
 method public,final setColumn (I[F)V - -
 method public,final getScale ()F - -
 method public,final add (F)V - -
 method public,final add (FLjavax/vecmath/Matrix3f;)V - -
 method public,final add (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Matrix3f;)V - -
 method public,final add (Ljavax/vecmath/Matrix3f;)V - -
 method public,final sub (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Matrix3f;)V - -
 method public,final sub (Ljavax/vecmath/Matrix3f;)V - -
 method public,final transpose ()V - -
 method public,final transpose (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Quat4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;)V - -
 method public,final set ([F)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final invert (Ljavax/vecmath/Matrix3f;)V - -
 method public,final invert ()V - -
 method public,final determinant ()F - -
 method public,final set (F)V - -
 method public,final rotX (F)V - -
 method public,final rotY (F)V - -
 method public,final rotZ (F)V - -
 method public,final mul (F)V - -
 method public,final mul (FLjavax/vecmath/Matrix3f;)V - -
 method public,final mul (Ljavax/vecmath/Matrix3f;)V - -
 method public,final mul (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Matrix3f;)V - -
 method public,final mulNormalize (Ljavax/vecmath/Matrix3f;)V - -
 method public,final mulNormalize (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Matrix3f;)V - -
 method public,final mulTransposeBoth (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Matrix3f;)V - -
 method public,final mulTransposeRight (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Matrix3f;)V - -
 method public,final mulTransposeLeft (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Matrix3f;)V - -
 method public,final normalize ()V - -
 method public,final normalize (Ljavax/vecmath/Matrix3f;)V - -
 method public,final normalizeCP ()V - -
 method public,final normalizeCP (Ljavax/vecmath/Matrix3f;)V - -
 method public equals (Ljavax/vecmath/Matrix3f;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Matrix3f;F)Z - -
 method public hashCode ()I - -
 method public,final setZero ()V - -
 method public,final negate ()V - -
 method public,final negate (Ljavax/vecmath/Matrix3f;)V - -
 method public,final transform (Ljavax/vecmath/Tuple3f;)V - -
 method public,final transform (Ljavax/vecmath/Tuple3f;Ljavax/vecmath/Tuple3f;)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getM00 ()F - -
 method public,final setM00 (F)V - -
 method public,final getM01 ()F - -
 method public,final setM01 (F)V - -
 method public,final getM02 ()F - -
 method public,final setM02 (F)V - -
 method public,final getM10 ()F - -
 method public,final setM10 (F)V - -
 method public,final getM11 ()F - -
 method public,final setM11 (F)V - -
 method public,final getM12 ()F - -
 method public,final setM12 (F)V - -
 method public,final getM20 ()F - -
 method public,final setM20 (F)V - -
 method public,final getM21 ()F - -
 method public,final setM21 (F)V - -
 method public,final getM22 ()F - -
 method public,final setM22 (F)V - -
in 256
class javax/vecmath/Matrix4d 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public m00 D -
 field public m01 D -
 field public m02 D -
 field public m03 D -
 field public m10 D -
 field public m11 D -
 field public m12 D -
 field public m13 D -
 field public m20 D -
 field public m21 D -
 field public m22 D -
 field public m23 D -
 field public m30 D -
 field public m31 D -
 field public m32 D -
 field public m33 D -
 method public <init> (DDDDDDDDDDDDDDDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Quat4d;Ljavax/vecmath/Vector3d;D)V - -
 method public <init> (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Vector3d;D)V - -
 method public <init> (Ljavax/vecmath/Matrix4d;)V - -
 method public <init> (Ljavax/vecmath/Matrix4f;)V - -
 method public <init> (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Vector3d;D)V - -
 method public <init> (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Vector3d;D)V - -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final setIdentity ()V - -
 method public,final setElement (IID)V - -
 method public,final getElement (II)D - -
 method public,final getRow (ILjavax/vecmath/Vector4d;)V - -
 method public,final getRow (I[D)V - -
 method public,final getColumn (ILjavax/vecmath/Vector4d;)V - -
 method public,final getColumn (I[D)V - -
 method public,final get (Ljavax/vecmath/Matrix3d;)V - -
 method public,final get (Ljavax/vecmath/Matrix3f;)V - -
 method public,final get (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Vector3d;)D - -
 method public,final get (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Vector3d;)D - -
 method public,final get (Ljavax/vecmath/Quat4f;)V - -
 method public,final get (Ljavax/vecmath/Quat4d;)V - -
 method public,final get (Ljavax/vecmath/Vector3d;)V - -
 method public,final getRotationScale (Ljavax/vecmath/Matrix3f;)V - -
 method public,final getRotationScale (Ljavax/vecmath/Matrix3d;)V - -
 method public,final getScale ()D - -
 method public,final setRotationScale (Ljavax/vecmath/Matrix3d;)V - -
 method public,final setRotationScale (Ljavax/vecmath/Matrix3f;)V - -
 method public,final setScale (D)V - -
 method public,final setRow (IDDDD)V - -
 method public,final setRow (ILjavax/vecmath/Vector4d;)V - -
 method public,final setRow (I[D)V - -
 method public,final setColumn (IDDDD)V - -
 method public,final setColumn (ILjavax/vecmath/Vector4d;)V - -
 method public,final setColumn (I[D)V - -
 method public,final add (D)V - -
 method public,final add (DLjavax/vecmath/Matrix4d;)V - -
 method public,final add (Ljavax/vecmath/Matrix4d;Ljavax/vecmath/Matrix4d;)V - -
 method public,final add (Ljavax/vecmath/Matrix4d;)V - -
 method public,final sub (Ljavax/vecmath/Matrix4d;Ljavax/vecmath/Matrix4d;)V - -
 method public,final sub (Ljavax/vecmath/Matrix4d;)V - -
 method public,final transpose ()V - -
 method public,final transpose (Ljavax/vecmath/Matrix4d;)V - -
 method public,final set ([D)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final set (Ljavax/vecmath/Quat4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;Ljavax/vecmath/Vector3d;D)V - -
 method public,final set (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Vector3d;D)V - -
 method public,final set (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Vector3f;F)V - -
 method public,final set (Ljavax/vecmath/Matrix4f;)V - -
 method public,final set (Ljavax/vecmath/Matrix4d;)V - -
 method public,final invert (Ljavax/vecmath/Matrix4d;)V - -
 method public,final invert ()V - -
 method public,final determinant ()D - -
 method public,final set (D)V - -
 method public,final set (Ljavax/vecmath/Vector3d;)V - -
 method public,final set (DLjavax/vecmath/Vector3d;)V - -
 method public,final set (Ljavax/vecmath/Vector3d;D)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Vector3f;F)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Vector3d;D)V - -
 method public,final setTranslation (Ljavax/vecmath/Vector3d;)V - -
 method public,final rotX (D)V - -
 method public,final rotY (D)V - -
 method public,final rotZ (D)V - -
 method public,final mul (D)V - -
 method public,final mul (DLjavax/vecmath/Matrix4d;)V - -
 method public,final mul (Ljavax/vecmath/Matrix4d;)V - -
 method public,final mul (Ljavax/vecmath/Matrix4d;Ljavax/vecmath/Matrix4d;)V - -
 method public,final mulTransposeBoth (Ljavax/vecmath/Matrix4d;Ljavax/vecmath/Matrix4d;)V - -
 method public,final mulTransposeRight (Ljavax/vecmath/Matrix4d;Ljavax/vecmath/Matrix4d;)V - -
 method public,final mulTransposeLeft (Ljavax/vecmath/Matrix4d;Ljavax/vecmath/Matrix4d;)V - -
 method public equals (Ljavax/vecmath/Matrix4d;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public,deprecated epsilonEquals (Ljavax/vecmath/Matrix4d;F)Z - -
 method public epsilonEquals (Ljavax/vecmath/Matrix4d;D)Z - -
 method public hashCode ()I - -
 method public,final transform (Ljavax/vecmath/Tuple4d;Ljavax/vecmath/Tuple4d;)V - -
 method public,final transform (Ljavax/vecmath/Tuple4d;)V - -
 method public,final transform (Ljavax/vecmath/Tuple4f;Ljavax/vecmath/Tuple4f;)V - -
 method public,final transform (Ljavax/vecmath/Tuple4f;)V - -
 method public,final transform (Ljavax/vecmath/Point3d;Ljavax/vecmath/Point3d;)V - -
 method public,final transform (Ljavax/vecmath/Point3d;)V - -
 method public,final transform (Ljavax/vecmath/Point3f;Ljavax/vecmath/Point3f;)V - -
 method public,final transform (Ljavax/vecmath/Point3f;)V - -
 method public,final transform (Ljavax/vecmath/Vector3d;Ljavax/vecmath/Vector3d;)V - -
 method public,final transform (Ljavax/vecmath/Vector3d;)V - -
 method public,final transform (Ljavax/vecmath/Vector3f;Ljavax/vecmath/Vector3f;)V - -
 method public,final transform (Ljavax/vecmath/Vector3f;)V - -
 method public,final setRotation (Ljavax/vecmath/Matrix3d;)V - -
 method public,final setRotation (Ljavax/vecmath/Matrix3f;)V - -
 method public,final setRotation (Ljavax/vecmath/Quat4f;)V - -
 method public,final setRotation (Ljavax/vecmath/Quat4d;)V - -
 method public,final setRotation (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final setZero ()V - -
 method public,final negate ()V - -
 method public,final negate (Ljavax/vecmath/Matrix4d;)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getM00 ()D - -
 method public,final setM00 (D)V - -
 method public,final getM01 ()D - -
 method public,final setM01 (D)V - -
 method public,final getM02 ()D - -
 method public,final setM02 (D)V - -
 method public,final getM10 ()D - -
 method public,final setM10 (D)V - -
 method public,final getM11 ()D - -
 method public,final setM11 (D)V - -
 method public,final getM12 ()D - -
 method public,final setM12 (D)V - -
 method public,final getM20 ()D - -
 method public,final setM20 (D)V - -
 method public,final getM21 ()D - -
 method public,final setM21 (D)V - -
 method public,final getM22 ()D - -
 method public,final setM22 (D)V - -
 method public,final getM03 ()D - -
 method public,final setM03 (D)V - -
 method public,final getM13 ()D - -
 method public,final setM13 (D)V - -
 method public,final getM23 ()D - -
 method public,final setM23 (D)V - -
 method public,final getM30 ()D - -
 method public,final setM30 (D)V - -
 method public,final getM31 ()D - -
 method public,final setM31 (D)V - -
 method public,final getM32 ()D - -
 method public,final setM32 (D)V - -
 method public,final getM33 ()D - -
 method public,final setM33 (D)V - -
in 256
class javax/vecmath/Matrix4f 49 public,super java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public m00 F -
 field public m01 F -
 field public m02 F -
 field public m03 F -
 field public m10 F -
 field public m11 F -
 field public m12 F -
 field public m13 F -
 field public m20 F -
 field public m21 F -
 field public m22 F -
 field public m23 F -
 field public m30 F -
 field public m31 F -
 field public m32 F -
 field public m33 F -
 method public <init> (FFFFFFFFFFFFFFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Vector3f;F)V - -
 method public <init> (Ljavax/vecmath/Matrix4d;)V - -
 method public <init> (Ljavax/vecmath/Matrix4f;)V - -
 method public <init> (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Vector3f;F)V - -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final setIdentity ()V - -
 method public,final setElement (IIF)V - -
 method public,final getElement (II)F - -
 method public,final getRow (ILjavax/vecmath/Vector4f;)V - -
 method public,final getRow (I[F)V - -
 method public,final getColumn (ILjavax/vecmath/Vector4f;)V - -
 method public,final getColumn (I[F)V - -
 method public,final setScale (F)V - -
 method public,final get (Ljavax/vecmath/Matrix3d;)V - -
 method public,final get (Ljavax/vecmath/Matrix3f;)V - -
 method public,final get (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Vector3f;)F - -
 method public,final get (Ljavax/vecmath/Quat4f;)V - -
 method public,final get (Ljavax/vecmath/Vector3f;)V - -
 method public,final getRotationScale (Ljavax/vecmath/Matrix3f;)V - -
 method public,final getScale ()F - -
 method public,final setRotationScale (Ljavax/vecmath/Matrix3f;)V - -
 method public,final setRow (IFFFF)V - -
 method public,final setRow (ILjavax/vecmath/Vector4f;)V - -
 method public,final setRow (I[F)V - -
 method public,final setColumn (IFFFF)V - -
 method public,final setColumn (ILjavax/vecmath/Vector4f;)V - -
 method public,final setColumn (I[F)V - -
 method public,final add (F)V - -
 method public,final add (FLjavax/vecmath/Matrix4f;)V - -
 method public,final add (Ljavax/vecmath/Matrix4f;Ljavax/vecmath/Matrix4f;)V - -
 method public,final add (Ljavax/vecmath/Matrix4f;)V - -
 method public,final sub (Ljavax/vecmath/Matrix4f;Ljavax/vecmath/Matrix4f;)V - -
 method public,final sub (Ljavax/vecmath/Matrix4f;)V - -
 method public,final transpose ()V - -
 method public,final transpose (Ljavax/vecmath/Matrix4f;)V - -
 method public,final set (Ljavax/vecmath/Quat4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final set (Ljavax/vecmath/Quat4d;Ljavax/vecmath/Vector3d;D)V - -
 method public,final set (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Vector3f;F)V - -
 method public,final set (Ljavax/vecmath/Matrix4d;)V - -
 method public,final set (Ljavax/vecmath/Matrix4f;)V - -
 method public,final invert (Ljavax/vecmath/Matrix4f;)V - -
 method public,final invert ()V - -
 method public,final determinant ()F - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set (F)V - -
 method public,final set ([F)V - -
 method public,final set (Ljavax/vecmath/Vector3f;)V - -
 method public,final set (FLjavax/vecmath/Vector3f;)V - -
 method public,final set (Ljavax/vecmath/Vector3f;F)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;Ljavax/vecmath/Vector3f;F)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;Ljavax/vecmath/Vector3d;D)V - -
 method public,final setTranslation (Ljavax/vecmath/Vector3f;)V - -
 method public,final rotX (F)V - -
 method public,final rotY (F)V - -
 method public,final rotZ (F)V - -
 method public,final mul (F)V - -
 method public,final mul (FLjavax/vecmath/Matrix4f;)V - -
 method public,final mul (Ljavax/vecmath/Matrix4f;)V - -
 method public,final mul (Ljavax/vecmath/Matrix4f;Ljavax/vecmath/Matrix4f;)V - -
 method public,final mulTransposeBoth (Ljavax/vecmath/Matrix4f;Ljavax/vecmath/Matrix4f;)V - -
 method public,final mulTransposeRight (Ljavax/vecmath/Matrix4f;Ljavax/vecmath/Matrix4f;)V - -
 method public,final mulTransposeLeft (Ljavax/vecmath/Matrix4f;Ljavax/vecmath/Matrix4f;)V - -
 method public equals (Ljavax/vecmath/Matrix4f;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Matrix4f;F)Z - -
 method public hashCode ()I - -
 method public,final transform (Ljavax/vecmath/Tuple4f;Ljavax/vecmath/Tuple4f;)V - -
 method public,final transform (Ljavax/vecmath/Tuple4f;)V - -
 method public,final transform (Ljavax/vecmath/Point3f;Ljavax/vecmath/Point3f;)V - -
 method public,final transform (Ljavax/vecmath/Point3f;)V - -
 method public,final transform (Ljavax/vecmath/Vector3f;Ljavax/vecmath/Vector3f;)V - -
 method public,final transform (Ljavax/vecmath/Vector3f;)V - -
 method public,final setRotation (Ljavax/vecmath/Matrix3d;)V - -
 method public,final setRotation (Ljavax/vecmath/Matrix3f;)V - -
 method public,final setRotation (Ljavax/vecmath/Quat4f;)V - -
 method public,final setRotation (Ljavax/vecmath/Quat4d;)V - -
 method public,final setRotation (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final setZero ()V - -
 method public,final negate ()V - -
 method public,final negate (Ljavax/vecmath/Matrix4f;)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getM00 ()F - -
 method public,final setM00 (F)V - -
 method public,final getM01 ()F - -
 method public,final setM01 (F)V - -
 method public,final getM02 ()F - -
 method public,final setM02 (F)V - -
 method public,final getM10 ()F - -
 method public,final setM10 (F)V - -
 method public,final getM11 ()F - -
 method public,final setM11 (F)V - -
 method public,final getM12 ()F - -
 method public,final setM12 (F)V - -
 method public,final getM20 ()F - -
 method public,final setM20 (F)V - -
 method public,final getM21 ()F - -
 method public,final setM21 (F)V - -
 method public,final getM22 ()F - -
 method public,final setM22 (F)V - -
 method public,final getM03 ()F - -
 method public,final setM03 (F)V - -
 method public,final getM13 ()F - -
 method public,final setM13 (F)V - -
 method public,final getM23 ()F - -
 method public,final setM23 (F)V - -
 method public,final getM30 ()F - -
 method public,final setM30 (F)V - -
 method public,final getM31 ()F - -
 method public,final setM31 (F)V - -
 method public,final getM32 ()F - -
 method public,final setM32 (F)V - -
 method public,final getM33 ()F - -
 method public,final setM33 (F)V - -
in 256
class javax/vecmath/MismatchedSizeException 49 public,super java/lang/RuntimeException - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
in 256
class javax/vecmath/Point2d 49 public,super javax/vecmath/Tuple2d java/io/Serializable -
 method public <init> (DD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Point2d;)V - -
 method public <init> (Ljavax/vecmath/Point2f;)V - -
 method public <init> (Ljavax/vecmath/Tuple2d;)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> ()V - -
 method public,final distanceSquared (Ljavax/vecmath/Point2d;)D - -
 method public,final distance (Ljavax/vecmath/Point2d;)D - -
 method public,final distanceL1 (Ljavax/vecmath/Point2d;)D - -
 method public,final distanceLinf (Ljavax/vecmath/Point2d;)D - -
in 256
class javax/vecmath/Point2f 49 public,super javax/vecmath/Tuple2f java/io/Serializable -
 method public <init> (FF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Point2f;)V - -
 method public <init> (Ljavax/vecmath/Point2d;)V - -
 method public <init> (Ljavax/vecmath/Tuple2d;)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> ()V - -
 method public,final distanceSquared (Ljavax/vecmath/Point2f;)F - -
 method public,final distance (Ljavax/vecmath/Point2f;)F - -
 method public,final distanceL1 (Ljavax/vecmath/Point2f;)F - -
 method public,final distanceLinf (Ljavax/vecmath/Point2f;)F - -
in 256
class javax/vecmath/Point2i 49 public,super javax/vecmath/Tuple2i java/io/Serializable -
 method public <init> (II)V - -
 method public <init> ([I)V - -
 method public <init> (Ljavax/vecmath/Tuple2i;)V - -
 method public <init> ()V - -
in 256
class javax/vecmath/Point3d 49 public,super javax/vecmath/Tuple3d java/io/Serializable -
 method public <init> (DDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Point3d;)V - -
 method public <init> (Ljavax/vecmath/Point3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
 method public,final distanceSquared (Ljavax/vecmath/Point3d;)D - -
 method public,final distance (Ljavax/vecmath/Point3d;)D - -
 method public,final distanceL1 (Ljavax/vecmath/Point3d;)D - -
 method public,final distanceLinf (Ljavax/vecmath/Point3d;)D - -
 method public,final project (Ljavax/vecmath/Point4d;)V - -
in 256
class javax/vecmath/Point3f 49 public,super javax/vecmath/Tuple3f java/io/Serializable -
 method public <init> (FFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Point3f;)V - -
 method public <init> (Ljavax/vecmath/Point3d;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
 method public,final distanceSquared (Ljavax/vecmath/Point3f;)F - -
 method public,final distance (Ljavax/vecmath/Point3f;)F - -
 method public,final distanceL1 (Ljavax/vecmath/Point3f;)F - -
 method public,final distanceLinf (Ljavax/vecmath/Point3f;)F - -
 method public,final project (Ljavax/vecmath/Point4f;)V - -
in 256
class javax/vecmath/Point3i 49 public,super javax/vecmath/Tuple3i java/io/Serializable -
 method public <init> (III)V - -
 method public <init> ([I)V - -
 method public <init> (Ljavax/vecmath/Tuple3i;)V - -
 method public <init> ()V - -
in 256
class javax/vecmath/Point4d 49 public,super javax/vecmath/Tuple4d java/io/Serializable -
 method public <init> (DDDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Point4d;)V - -
 method public <init> (Ljavax/vecmath/Point4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
 method public,final set (Ljavax/vecmath/Tuple3d;)V - -
 method public,final distanceSquared (Ljavax/vecmath/Point4d;)D - -
 method public,final distance (Ljavax/vecmath/Point4d;)D - -
 method public,final distanceL1 (Ljavax/vecmath/Point4d;)D - -
 method public,final distanceLinf (Ljavax/vecmath/Point4d;)D - -
 method public,final project (Ljavax/vecmath/Point4d;)V - -
in 256
class javax/vecmath/Point4f 49 public,super javax/vecmath/Tuple4f java/io/Serializable -
 method public <init> (FFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Point4f;)V - -
 method public <init> (Ljavax/vecmath/Point4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> ()V - -
 method public,final set (Ljavax/vecmath/Tuple3f;)V - -
 method public,final distanceSquared (Ljavax/vecmath/Point4f;)F - -
 method public,final distance (Ljavax/vecmath/Point4f;)F - -
 method public,final distanceL1 (Ljavax/vecmath/Point4f;)F - -
 method public,final distanceLinf (Ljavax/vecmath/Point4f;)F - -
 method public,final project (Ljavax/vecmath/Point4f;)V - -
in 256
class javax/vecmath/Point4i 49 public,super javax/vecmath/Tuple4i java/io/Serializable -
 method public <init> (IIII)V - -
 method public <init> ([I)V - -
 method public <init> (Ljavax/vecmath/Tuple4i;)V - -
 method public <init> ()V - -
in 256
class javax/vecmath/Quat4d 49 public,super javax/vecmath/Tuple4d java/io/Serializable -
 method public <init> (DDDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Quat4d;)V - -
 method public <init> (Ljavax/vecmath/Quat4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> ()V - -
 method public,final conjugate (Ljavax/vecmath/Quat4d;)V - -
 method public,final conjugate ()V - -
 method public,final mul (Ljavax/vecmath/Quat4d;Ljavax/vecmath/Quat4d;)V - -
 method public,final mul (Ljavax/vecmath/Quat4d;)V - -
 method public,final mulInverse (Ljavax/vecmath/Quat4d;Ljavax/vecmath/Quat4d;)V - -
 method public,final mulInverse (Ljavax/vecmath/Quat4d;)V - -
 method public,final inverse (Ljavax/vecmath/Quat4d;)V - -
 method public,final inverse ()V - -
 method public,final normalize (Ljavax/vecmath/Quat4d;)V - -
 method public,final normalize ()V - -
 method public,final set (Ljavax/vecmath/Matrix4f;)V - -
 method public,final set (Ljavax/vecmath/Matrix4d;)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final interpolate (Ljavax/vecmath/Quat4d;D)V - -
 method public,final interpolate (Ljavax/vecmath/Quat4d;Ljavax/vecmath/Quat4d;D)V - -
in 256
class javax/vecmath/Quat4f 49 public,super javax/vecmath/Tuple4f java/io/Serializable -
 method public <init> (FFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Quat4f;)V - -
 method public <init> (Ljavax/vecmath/Quat4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> ()V - -
 method public,final conjugate (Ljavax/vecmath/Quat4f;)V - -
 method public,final conjugate ()V - -
 method public,final mul (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Quat4f;)V - -
 method public,final mul (Ljavax/vecmath/Quat4f;)V - -
 method public,final mulInverse (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Quat4f;)V - -
 method public,final mulInverse (Ljavax/vecmath/Quat4f;)V - -
 method public,final inverse (Ljavax/vecmath/Quat4f;)V - -
 method public,final inverse ()V - -
 method public,final normalize (Ljavax/vecmath/Quat4f;)V - -
 method public,final normalize ()V - -
 method public,final set (Ljavax/vecmath/Matrix4f;)V - -
 method public,final set (Ljavax/vecmath/Matrix4d;)V - -
 method public,final set (Ljavax/vecmath/Matrix3f;)V - -
 method public,final set (Ljavax/vecmath/Matrix3d;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4f;)V - -
 method public,final set (Ljavax/vecmath/AxisAngle4d;)V - -
 method public,final interpolate (Ljavax/vecmath/Quat4f;F)V - -
 method public,final interpolate (Ljavax/vecmath/Quat4f;Ljavax/vecmath/Quat4f;F)V - -
in 256
class javax/vecmath/SingularMatrixException 49 public,super java/lang/RuntimeException - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
in 256
class javax/vecmath/TexCoord2f 49 public,super javax/vecmath/Tuple2f java/io/Serializable -
 method public <init> (FF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/TexCoord2f;)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> ()V - -
in 256
class javax/vecmath/TexCoord3f 49 public,super javax/vecmath/Tuple3f java/io/Serializable -
 method public <init> (FFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/TexCoord3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
in 256
class javax/vecmath/TexCoord4f 49 public,super javax/vecmath/Tuple4f java/io/Serializable -
 method public <init> (FFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/TexCoord4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> ()V - -
in 256
class javax/vecmath/Tuple2d 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x D -
 field public y D -
 method public <init> (DD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Tuple2d;)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> ()V - -
 method public,final set (DD)V - -
 method public,final set ([D)V - -
 method public,final set (Ljavax/vecmath/Tuple2d;)V - -
 method public,final set (Ljavax/vecmath/Tuple2f;)V - -
 method public,final get ([D)V - -
 method public,final add (Ljavax/vecmath/Tuple2d;Ljavax/vecmath/Tuple2d;)V - -
 method public,final add (Ljavax/vecmath/Tuple2d;)V - -
 method public,final sub (Ljavax/vecmath/Tuple2d;Ljavax/vecmath/Tuple2d;)V - -
 method public,final sub (Ljavax/vecmath/Tuple2d;)V - -
 method public,final negate (Ljavax/vecmath/Tuple2d;)V - -
 method public,final negate ()V - -
 method public,final scale (DLjavax/vecmath/Tuple2d;)V - -
 method public,final scale (D)V - -
 method public,final scaleAdd (DLjavax/vecmath/Tuple2d;Ljavax/vecmath/Tuple2d;)V - -
 method public,final scaleAdd (DLjavax/vecmath/Tuple2d;)V - -
 method public hashCode ()I - -
 method public equals (Ljavax/vecmath/Tuple2d;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Tuple2d;D)Z - -
 method public toString ()Ljava/lang/String; - -
 method public,final clamp (DDLjavax/vecmath/Tuple2d;)V - -
 method public,final clampMin (DLjavax/vecmath/Tuple2d;)V - -
 method public,final clampMax (DLjavax/vecmath/Tuple2d;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple2d;)V - -
 method public,final clamp (DD)V - -
 method public,final clampMin (D)V - -
 method public,final clampMax (D)V - -
 method public,final absolute ()V - -
 method public,final interpolate (Ljavax/vecmath/Tuple2d;Ljavax/vecmath/Tuple2d;D)V - -
 method public,final interpolate (Ljavax/vecmath/Tuple2d;D)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()D - -
 method public,final setX (D)V - -
 method public,final getY ()D - -
 method public,final setY (D)V - -
in 256
class javax/vecmath/Tuple2f 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x F -
 field public y F -
 method public <init> (FF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> (Ljavax/vecmath/Tuple2d;)V - -
 method public <init> ()V - -
 method public,final set (FF)V - -
 method public,final set ([F)V - -
 method public,final set (Ljavax/vecmath/Tuple2f;)V - -
 method public,final set (Ljavax/vecmath/Tuple2d;)V - -
 method public,final get ([F)V - -
 method public,final add (Ljavax/vecmath/Tuple2f;Ljavax/vecmath/Tuple2f;)V - -
 method public,final add (Ljavax/vecmath/Tuple2f;)V - -
 method public,final sub (Ljavax/vecmath/Tuple2f;Ljavax/vecmath/Tuple2f;)V - -
 method public,final sub (Ljavax/vecmath/Tuple2f;)V - -
 method public,final negate (Ljavax/vecmath/Tuple2f;)V - -
 method public,final negate ()V - -
 method public,final scale (FLjavax/vecmath/Tuple2f;)V - -
 method public,final scale (F)V - -
 method public,final scaleAdd (FLjavax/vecmath/Tuple2f;Ljavax/vecmath/Tuple2f;)V - -
 method public,final scaleAdd (FLjavax/vecmath/Tuple2f;)V - -
 method public hashCode ()I - -
 method public equals (Ljavax/vecmath/Tuple2f;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Tuple2f;F)Z - -
 method public toString ()Ljava/lang/String; - -
 method public,final clamp (FFLjavax/vecmath/Tuple2f;)V - -
 method public,final clampMin (FLjavax/vecmath/Tuple2f;)V - -
 method public,final clampMax (FLjavax/vecmath/Tuple2f;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple2f;)V - -
 method public,final clamp (FF)V - -
 method public,final clampMin (F)V - -
 method public,final clampMax (F)V - -
 method public,final absolute ()V - -
 method public,final interpolate (Ljavax/vecmath/Tuple2f;Ljavax/vecmath/Tuple2f;F)V - -
 method public,final interpolate (Ljavax/vecmath/Tuple2f;F)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()F - -
 method public,final setX (F)V - -
 method public,final getY ()F - -
 method public,final setY (F)V - -
in 256
class javax/vecmath/Tuple2i 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x I -
 field public y I -
 method public <init> (II)V - -
 method public <init> ([I)V - -
 method public <init> (Ljavax/vecmath/Tuple2i;)V - -
 method public <init> ()V - -
 method public,final set (II)V - -
 method public,final set ([I)V - -
 method public,final set (Ljavax/vecmath/Tuple2i;)V - -
 method public,final get ([I)V - -
 method public,final get (Ljavax/vecmath/Tuple2i;)V - -
 method public,final add (Ljavax/vecmath/Tuple2i;Ljavax/vecmath/Tuple2i;)V - -
 method public,final add (Ljavax/vecmath/Tuple2i;)V - -
 method public,final sub (Ljavax/vecmath/Tuple2i;Ljavax/vecmath/Tuple2i;)V - -
 method public,final sub (Ljavax/vecmath/Tuple2i;)V - -
 method public,final negate (Ljavax/vecmath/Tuple2i;)V - -
 method public,final negate ()V - -
 method public,final scale (ILjavax/vecmath/Tuple2i;)V - -
 method public,final scale (I)V - -
 method public,final scaleAdd (ILjavax/vecmath/Tuple2i;Ljavax/vecmath/Tuple2i;)V - -
 method public,final scaleAdd (ILjavax/vecmath/Tuple2i;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,final clamp (IILjavax/vecmath/Tuple2i;)V - -
 method public,final clampMin (ILjavax/vecmath/Tuple2i;)V - -
 method public,final clampMax (ILjavax/vecmath/Tuple2i;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple2i;)V - -
 method public,final clamp (II)V - -
 method public,final clampMin (I)V - -
 method public,final clampMax (I)V - -
 method public,final absolute ()V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()I - -
 method public,final setX (I)V - -
 method public,final getY ()I - -
 method public,final setY (I)V - -
in 256
class javax/vecmath/Tuple3b 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x B -
 field public y B -
 field public z B -
 method public <init> (BBB)V - -
 method public <init> ([B)V - -
 method public <init> (Ljavax/vecmath/Tuple3b;)V - -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final get ([B)V - -
 method public,final get (Ljavax/vecmath/Tuple3b;)V - -
 method public,final set (Ljavax/vecmath/Tuple3b;)V - -
 method public,final set ([B)V - -
 method public equals (Ljavax/vecmath/Tuple3b;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()B - -
 method public,final setX (B)V - -
 method public,final getY ()B - -
 method public,final setY (B)V - -
 method public,final getZ ()B - -
 method public,final setZ (B)V - -
in 256
class javax/vecmath/Tuple3d 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x D -
 field public y D -
 field public z D -
 method public <init> (DDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> ()V - -
 method public,final set (DDD)V - -
 method public,final set ([D)V - -
 method public,final set (Ljavax/vecmath/Tuple3d;)V - -
 method public,final set (Ljavax/vecmath/Tuple3f;)V - -
 method public,final get ([D)V - -
 method public,final get (Ljavax/vecmath/Tuple3d;)V - -
 method public,final add (Ljavax/vecmath/Tuple3d;Ljavax/vecmath/Tuple3d;)V - -
 method public,final add (Ljavax/vecmath/Tuple3d;)V - -
 method public,final sub (Ljavax/vecmath/Tuple3d;Ljavax/vecmath/Tuple3d;)V - -
 method public,final sub (Ljavax/vecmath/Tuple3d;)V - -
 method public,final negate (Ljavax/vecmath/Tuple3d;)V - -
 method public,final negate ()V - -
 method public,final scale (DLjavax/vecmath/Tuple3d;)V - -
 method public,final scale (D)V - -
 method public,final scaleAdd (DLjavax/vecmath/Tuple3d;Ljavax/vecmath/Tuple3d;)V - -
 method public,final,deprecated scaleAdd (DLjavax/vecmath/Tuple3f;)V - -
 method public,final scaleAdd (DLjavax/vecmath/Tuple3d;)V - -
 method public toString ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public equals (Ljavax/vecmath/Tuple3d;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Tuple3d;D)Z - -
 method public,final,deprecated clamp (FFLjavax/vecmath/Tuple3d;)V - -
 method public,final clamp (DDLjavax/vecmath/Tuple3d;)V - -
 method public,final,deprecated clampMin (FLjavax/vecmath/Tuple3d;)V - -
 method public,final clampMin (DLjavax/vecmath/Tuple3d;)V - -
 method public,final,deprecated clampMax (FLjavax/vecmath/Tuple3d;)V - -
 method public,final clampMax (DLjavax/vecmath/Tuple3d;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple3d;)V - -
 method public,final,deprecated clamp (FF)V - -
 method public,final clamp (DD)V - -
 method public,final,deprecated clampMin (F)V - -
 method public,final clampMin (D)V - -
 method public,final,deprecated clampMax (F)V - -
 method public,final clampMax (D)V - -
 method public,final absolute ()V - -
 method public,final,deprecated interpolate (Ljavax/vecmath/Tuple3d;Ljavax/vecmath/Tuple3d;F)V - -
 method public,final interpolate (Ljavax/vecmath/Tuple3d;Ljavax/vecmath/Tuple3d;D)V - -
 method public,final,deprecated interpolate (Ljavax/vecmath/Tuple3d;F)V - -
 method public,final interpolate (Ljavax/vecmath/Tuple3d;D)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()D - -
 method public,final setX (D)V - -
 method public,final getY ()D - -
 method public,final setY (D)V - -
 method public,final getZ ()D - -
 method public,final setZ (D)V - -
in 256
class javax/vecmath/Tuple3f 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x F -
 field public y F -
 field public z F -
 method public <init> (FFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final set (FFF)V - -
 method public,final set ([F)V - -
 method public,final set (Ljavax/vecmath/Tuple3f;)V - -
 method public,final set (Ljavax/vecmath/Tuple3d;)V - -
 method public,final get ([F)V - -
 method public,final get (Ljavax/vecmath/Tuple3f;)V - -
 method public,final add (Ljavax/vecmath/Tuple3f;Ljavax/vecmath/Tuple3f;)V - -
 method public,final add (Ljavax/vecmath/Tuple3f;)V - -
 method public,final sub (Ljavax/vecmath/Tuple3f;Ljavax/vecmath/Tuple3f;)V - -
 method public,final sub (Ljavax/vecmath/Tuple3f;)V - -
 method public,final negate (Ljavax/vecmath/Tuple3f;)V - -
 method public,final negate ()V - -
 method public,final scale (FLjavax/vecmath/Tuple3f;)V - -
 method public,final scale (F)V - -
 method public,final scaleAdd (FLjavax/vecmath/Tuple3f;Ljavax/vecmath/Tuple3f;)V - -
 method public,final scaleAdd (FLjavax/vecmath/Tuple3f;)V - -
 method public equals (Ljavax/vecmath/Tuple3f;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Tuple3f;F)Z - -
 method public hashCode ()I - -
 method public,final clamp (FFLjavax/vecmath/Tuple3f;)V - -
 method public,final clampMin (FLjavax/vecmath/Tuple3f;)V - -
 method public,final clampMax (FLjavax/vecmath/Tuple3f;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple3f;)V - -
 method public,final clamp (FF)V - -
 method public,final clampMin (F)V - -
 method public,final clampMax (F)V - -
 method public,final absolute ()V - -
 method public,final interpolate (Ljavax/vecmath/Tuple3f;Ljavax/vecmath/Tuple3f;F)V - -
 method public,final interpolate (Ljavax/vecmath/Tuple3f;F)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()F - -
 method public,final setX (F)V - -
 method public,final getY ()F - -
 method public,final setY (F)V - -
 method public,final getZ ()F - -
 method public,final setZ (F)V - -
in 256
class javax/vecmath/Tuple3i 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x I -
 field public y I -
 field public z I -
 method public <init> (III)V - -
 method public <init> ([I)V - -
 method public <init> (Ljavax/vecmath/Tuple3i;)V - -
 method public <init> ()V - -
 method public,final set (III)V - -
 method public,final set ([I)V - -
 method public,final set (Ljavax/vecmath/Tuple3i;)V - -
 method public,final get ([I)V - -
 method public,final get (Ljavax/vecmath/Tuple3i;)V - -
 method public,final add (Ljavax/vecmath/Tuple3i;Ljavax/vecmath/Tuple3i;)V - -
 method public,final add (Ljavax/vecmath/Tuple3i;)V - -
 method public,final sub (Ljavax/vecmath/Tuple3i;Ljavax/vecmath/Tuple3i;)V - -
 method public,final sub (Ljavax/vecmath/Tuple3i;)V - -
 method public,final negate (Ljavax/vecmath/Tuple3i;)V - -
 method public,final negate ()V - -
 method public,final scale (ILjavax/vecmath/Tuple3i;)V - -
 method public,final scale (I)V - -
 method public,final scaleAdd (ILjavax/vecmath/Tuple3i;Ljavax/vecmath/Tuple3i;)V - -
 method public,final scaleAdd (ILjavax/vecmath/Tuple3i;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,final clamp (IILjavax/vecmath/Tuple3i;)V - -
 method public,final clampMin (ILjavax/vecmath/Tuple3i;)V - -
 method public,final clampMax (ILjavax/vecmath/Tuple3i;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple3i;)V - -
 method public,final clamp (II)V - -
 method public,final clampMin (I)V - -
 method public,final clampMax (I)V - -
 method public,final absolute ()V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()I - -
 method public,final setX (I)V - -
 method public,final getY ()I - -
 method public,final setY (I)V - -
 method public,final getZ ()I - -
 method public,final setZ (I)V - -
in 256
class javax/vecmath/Tuple4b 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x B -
 field public y B -
 field public z B -
 field public w B -
 method public <init> (BBBB)V - -
 method public <init> ([B)V - -
 method public <init> (Ljavax/vecmath/Tuple4b;)V - -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final get ([B)V - -
 method public,final get (Ljavax/vecmath/Tuple4b;)V - -
 method public,final set (Ljavax/vecmath/Tuple4b;)V - -
 method public,final set ([B)V - -
 method public equals (Ljavax/vecmath/Tuple4b;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()B - -
 method public,final setX (B)V - -
 method public,final getY ()B - -
 method public,final setY (B)V - -
 method public,final getZ ()B - -
 method public,final setZ (B)V - -
 method public,final getW ()B - -
 method public,final setW (B)V - -
in 256
class javax/vecmath/Tuple4d 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x D -
 field public y D -
 field public z D -
 field public w D -
 method public <init> (DDDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> ()V - -
 method public,final set (DDDD)V - -
 method public,final set ([D)V - -
 method public,final set (Ljavax/vecmath/Tuple4d;)V - -
 method public,final set (Ljavax/vecmath/Tuple4f;)V - -
 method public,final get ([D)V - -
 method public,final get (Ljavax/vecmath/Tuple4d;)V - -
 method public,final add (Ljavax/vecmath/Tuple4d;Ljavax/vecmath/Tuple4d;)V - -
 method public,final add (Ljavax/vecmath/Tuple4d;)V - -
 method public,final sub (Ljavax/vecmath/Tuple4d;Ljavax/vecmath/Tuple4d;)V - -
 method public,final sub (Ljavax/vecmath/Tuple4d;)V - -
 method public,final negate (Ljavax/vecmath/Tuple4d;)V - -
 method public,final negate ()V - -
 method public,final scale (DLjavax/vecmath/Tuple4d;)V - -
 method public,final scale (D)V - -
 method public,final scaleAdd (DLjavax/vecmath/Tuple4d;Ljavax/vecmath/Tuple4d;)V - -
 method public,final,deprecated scaleAdd (FLjavax/vecmath/Tuple4d;)V - -
 method public,final scaleAdd (DLjavax/vecmath/Tuple4d;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljavax/vecmath/Tuple4d;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Tuple4d;D)Z - -
 method public hashCode ()I - -
 method public,final,deprecated clamp (FFLjavax/vecmath/Tuple4d;)V - -
 method public,final clamp (DDLjavax/vecmath/Tuple4d;)V - -
 method public,final,deprecated clampMin (FLjavax/vecmath/Tuple4d;)V - -
 method public,final clampMin (DLjavax/vecmath/Tuple4d;)V - -
 method public,final,deprecated clampMax (FLjavax/vecmath/Tuple4d;)V - -
 method public,final clampMax (DLjavax/vecmath/Tuple4d;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple4d;)V - -
 method public,final,deprecated clamp (FF)V - -
 method public,final clamp (DD)V - -
 method public,final,deprecated clampMin (F)V - -
 method public,final clampMin (D)V - -
 method public,final,deprecated clampMax (F)V - -
 method public,final clampMax (D)V - -
 method public,final absolute ()V - -
 method public,deprecated interpolate (Ljavax/vecmath/Tuple4d;Ljavax/vecmath/Tuple4d;F)V - -
 method public interpolate (Ljavax/vecmath/Tuple4d;Ljavax/vecmath/Tuple4d;D)V - -
 method public,deprecated interpolate (Ljavax/vecmath/Tuple4d;F)V - -
 method public interpolate (Ljavax/vecmath/Tuple4d;D)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()D - -
 method public,final setX (D)V - -
 method public,final getY ()D - -
 method public,final setY (D)V - -
 method public,final getZ ()D - -
 method public,final setZ (D)V - -
 method public,final getW ()D - -
 method public,final setW (D)V - -
in 256
class javax/vecmath/Tuple4f 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x F -
 field public y F -
 field public z F -
 field public w F -
 method public <init> (FFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> ()V - -
 method public,final set (FFFF)V - -
 method public,final set ([F)V - -
 method public,final set (Ljavax/vecmath/Tuple4f;)V - -
 method public,final set (Ljavax/vecmath/Tuple4d;)V - -
 method public,final get ([F)V - -
 method public,final get (Ljavax/vecmath/Tuple4f;)V - -
 method public,final add (Ljavax/vecmath/Tuple4f;Ljavax/vecmath/Tuple4f;)V - -
 method public,final add (Ljavax/vecmath/Tuple4f;)V - -
 method public,final sub (Ljavax/vecmath/Tuple4f;Ljavax/vecmath/Tuple4f;)V - -
 method public,final sub (Ljavax/vecmath/Tuple4f;)V - -
 method public,final negate (Ljavax/vecmath/Tuple4f;)V - -
 method public,final negate ()V - -
 method public,final scale (FLjavax/vecmath/Tuple4f;)V - -
 method public,final scale (F)V - -
 method public,final scaleAdd (FLjavax/vecmath/Tuple4f;Ljavax/vecmath/Tuple4f;)V - -
 method public,final scaleAdd (FLjavax/vecmath/Tuple4f;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljavax/vecmath/Tuple4f;)Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public epsilonEquals (Ljavax/vecmath/Tuple4f;F)Z - -
 method public hashCode ()I - -
 method public,final clamp (FFLjavax/vecmath/Tuple4f;)V - -
 method public,final clampMin (FLjavax/vecmath/Tuple4f;)V - -
 method public,final clampMax (FLjavax/vecmath/Tuple4f;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple4f;)V - -
 method public,final clamp (FF)V - -
 method public,final clampMin (F)V - -
 method public,final clampMax (F)V - -
 method public,final absolute ()V - -
 method public interpolate (Ljavax/vecmath/Tuple4f;Ljavax/vecmath/Tuple4f;F)V - -
 method public interpolate (Ljavax/vecmath/Tuple4f;F)V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()F - -
 method public,final setX (F)V - -
 method public,final getY ()F - -
 method public,final setY (F)V - -
 method public,final getZ ()F - -
 method public,final setZ (F)V - -
 method public,final getW ()F - -
 method public,final setW (F)V - -
in 256
class javax/vecmath/Tuple4i 49 public,super,abstract java/lang/Object java/io/Serializable,java/lang/Cloneable -
 field public x I -
 field public y I -
 field public z I -
 field public w I -
 method public <init> (IIII)V - -
 method public <init> ([I)V - -
 method public <init> (Ljavax/vecmath/Tuple4i;)V - -
 method public <init> ()V - -
 method public,final set (IIII)V - -
 method public,final set ([I)V - -
 method public,final set (Ljavax/vecmath/Tuple4i;)V - -
 method public,final get ([I)V - -
 method public,final get (Ljavax/vecmath/Tuple4i;)V - -
 method public,final add (Ljavax/vecmath/Tuple4i;Ljavax/vecmath/Tuple4i;)V - -
 method public,final add (Ljavax/vecmath/Tuple4i;)V - -
 method public,final sub (Ljavax/vecmath/Tuple4i;Ljavax/vecmath/Tuple4i;)V - -
 method public,final sub (Ljavax/vecmath/Tuple4i;)V - -
 method public,final negate (Ljavax/vecmath/Tuple4i;)V - -
 method public,final negate ()V - -
 method public,final scale (ILjavax/vecmath/Tuple4i;)V - -
 method public,final scale (I)V - -
 method public,final scaleAdd (ILjavax/vecmath/Tuple4i;Ljavax/vecmath/Tuple4i;)V - -
 method public,final scaleAdd (ILjavax/vecmath/Tuple4i;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,final clamp (IILjavax/vecmath/Tuple4i;)V - -
 method public,final clampMin (ILjavax/vecmath/Tuple4i;)V - -
 method public,final clampMax (ILjavax/vecmath/Tuple4i;)V - -
 method public,final absolute (Ljavax/vecmath/Tuple4i;)V - -
 method public,final clamp (II)V - -
 method public,final clampMin (I)V - -
 method public,final clampMax (I)V - -
 method public,final absolute ()V - -
 method public clone ()Ljava/lang/Object; - -
 method public,final getX ()I - -
 method public,final setX (I)V - -
 method public,final getY ()I - -
 method public,final setY (I)V - -
 method public,final getZ ()I - -
 method public,final setZ (I)V - -
 method public,final getW ()I - -
 method public,final setW (I)V - -
in 256
class javax/vecmath/VecMathI18N 49 super java/lang/Object - -
in 256
class javax/vecmath/VecMathUtil 49 super java/lang/Object - -
in 256
class javax/vecmath/Vector2d 49 public,super javax/vecmath/Tuple2d java/io/Serializable -
 method public <init> (DD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Vector2d;)V - -
 method public <init> (Ljavax/vecmath/Vector2f;)V - -
 method public <init> (Ljavax/vecmath/Tuple2d;)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> ()V - -
 method public,final dot (Ljavax/vecmath/Vector2d;)D - -
 method public,final length ()D - -
 method public,final lengthSquared ()D - -
 method public,final normalize (Ljavax/vecmath/Vector2d;)V - -
 method public,final normalize ()V - -
 method public,final angle (Ljavax/vecmath/Vector2d;)D - -
in 256
class javax/vecmath/Vector2f 49 public,super javax/vecmath/Tuple2f java/io/Serializable -
 method public <init> (FF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Vector2f;)V - -
 method public <init> (Ljavax/vecmath/Vector2d;)V - -
 method public <init> (Ljavax/vecmath/Tuple2f;)V - -
 method public <init> (Ljavax/vecmath/Tuple2d;)V - -
 method public <init> ()V - -
 method public,final dot (Ljavax/vecmath/Vector2f;)F - -
 method public,final length ()F - -
 method public,final lengthSquared ()F - -
 method public,final normalize (Ljavax/vecmath/Vector2f;)V - -
 method public,final normalize ()V - -
 method public,final angle (Ljavax/vecmath/Vector2f;)F - -
in 256
class javax/vecmath/Vector3d 49 public,super javax/vecmath/Tuple3d java/io/Serializable -
 method public <init> (DDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Vector3d;)V - -
 method public <init> (Ljavax/vecmath/Vector3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
 method public,final cross (Ljavax/vecmath/Vector3d;Ljavax/vecmath/Vector3d;)V - -
 method public,final normalize (Ljavax/vecmath/Vector3d;)V - -
 method public,final normalize ()V - -
 method public,final dot (Ljavax/vecmath/Vector3d;)D - -
 method public,final lengthSquared ()D - -
 method public,final length ()D - -
 method public,final angle (Ljavax/vecmath/Vector3d;)D - -
in 256
class javax/vecmath/Vector3f 49 public,super javax/vecmath/Tuple3f java/io/Serializable -
 method public <init> (FFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Vector3f;)V - -
 method public <init> (Ljavax/vecmath/Vector3d;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
 method public,final lengthSquared ()F - -
 method public,final length ()F - -
 method public,final cross (Ljavax/vecmath/Vector3f;Ljavax/vecmath/Vector3f;)V - -
 method public,final dot (Ljavax/vecmath/Vector3f;)F - -
 method public,final normalize (Ljavax/vecmath/Vector3f;)V - -
 method public,final normalize ()V - -
 method public,final angle (Ljavax/vecmath/Vector3f;)F - -
in 256
class javax/vecmath/Vector4d 49 public,super javax/vecmath/Tuple4d java/io/Serializable -
 method public <init> (DDDD)V - -
 method public <init> ([D)V - -
 method public <init> (Ljavax/vecmath/Vector4d;)V - -
 method public <init> (Ljavax/vecmath/Vector4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple3d;)V - -
 method public <init> ()V - -
 method public,final set (Ljavax/vecmath/Tuple3d;)V - -
 method public,final length ()D - -
 method public,final lengthSquared ()D - -
 method public,final dot (Ljavax/vecmath/Vector4d;)D - -
 method public,final normalize (Ljavax/vecmath/Vector4d;)V - -
 method public,final normalize ()V - -
 method public,final angle (Ljavax/vecmath/Vector4d;)D - -
in 256
class javax/vecmath/Vector4f 49 public,super javax/vecmath/Tuple4f java/io/Serializable -
 method public <init> (FFFF)V - -
 method public <init> ([F)V - -
 method public <init> (Ljavax/vecmath/Vector4f;)V - -
 method public <init> (Ljavax/vecmath/Vector4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple4f;)V - -
 method public <init> (Ljavax/vecmath/Tuple4d;)V - -
 method public <init> (Ljavax/vecmath/Tuple3f;)V - -
 method public <init> ()V - -
 method public,final set (Ljavax/vecmath/Tuple3f;)V - -
 method public,final length ()F - -
 method public,final lengthSquared ()F - -
 method public,final dot (Ljavax/vecmath/Vector4f;)F - -
 method public,final normalize (Ljavax/vecmath/Vector4f;)V - -
 method public,final normalize ()V - -
 method public,final angle (Ljavax/vecmath/Vector4f;)F - -
