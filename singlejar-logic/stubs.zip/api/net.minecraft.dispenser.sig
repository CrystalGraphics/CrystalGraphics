cg-stub-db 1
in 24
class net/minecraft/dispenser/BehaviorDefaultDispenseItem 50 public,super java/lang/Object net/minecraft/dispenser/IBehaviorDispenseItem -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> ()V - -
 method public,final dispense (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method protected dispenseStack (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public,static doDispense (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;ILnet/minecraft/util/EnumFacing;Lnet/minecraft/dispenser/IPosition;)V - -
 method protected playDispenseSound (Lnet/minecraft/dispenser/IBlockSource;)V - -
 method protected spawnDispenseParticles (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/util/EnumFacing;)V - -
in 326
class net/minecraft/dispenser/BehaviorDefaultDispenseItem 52 public,super java/lang/Object net/minecraft/dispenser/IBehaviorDispenseItem -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> ()V - -
 method public,final dispense (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method protected dispenseStack (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public,static doDispense (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;ILnet/minecraft/util/EnumFacing;Lnet/minecraft/dispenser/IPosition;)V - -
 method protected playDispenseSound (Lnet/minecraft/dispenser/IBlockSource;)V - -
 method protected spawnDispenseParticles (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/util/EnumFacing;)V - -
in 90
class net/minecraft/dispenser/BehaviorProjectileDispense 50 public,super,abstract net/minecraft/dispenser/BehaviorDefaultDispenseItem - -
 method public <init> ()V - -
 method public dispenseStack (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method protected playDispenseSound (Lnet/minecraft/dispenser/IBlockSource;)V - -
 method protected,abstract getProjectileEntity (Lnet/minecraft/world/World;Lnet/minecraft/dispenser/IPosition;)Lnet/minecraft/entity/IProjectile; - -
 method protected func_82498_a ()F - -
 method protected func_82500_b ()F - -
in 91
class net/minecraft/dispenser/BehaviorProjectileDispense 50 public,super,abstract net/minecraft/dispenser/BehaviorDefaultDispenseItem - -
 method public <init> ()V - -
 method public dispenseStack (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method protected playDispenseSound (Lnet/minecraft/dispenser/IBlockSource;)V - -
 method protected,abstract getProjectileEntity (Lnet/minecraft/world/World;Lnet/minecraft/dispenser/IPosition;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/IProjectile; - -
 method protected getProjectileInaccuracy ()F - -
 method protected getProjectileVelocity ()F - -
in 326
class net/minecraft/dispenser/BehaviorProjectileDispense 52 public,super,abstract net/minecraft/dispenser/BehaviorDefaultDispenseItem - -
 method public <init> ()V - -
 method public dispenseStack (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method protected playDispenseSound (Lnet/minecraft/dispenser/IBlockSource;)V - -
 method protected,abstract getProjectileEntity (Lnet/minecraft/world/World;Lnet/minecraft/dispenser/IPosition;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/IProjectile; - -
 method protected getProjectileInaccuracy ()F - -
 method protected getProjectileVelocity ()F - -
in 90
class net/minecraft/dispenser/IBehaviorDispenseItem 50 public,interface,abstract java/lang/Object - -
 field public,static,final itemDispenseBehaviorProvider Lnet/minecraft/dispenser/IBehaviorDispenseItem; -
 method public,abstract dispense (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/dispenser/IBehaviorDispenseItem 50 public,interface,abstract java/lang/Object - -
 field public,static,final DEFAULT_BEHAVIOR Lnet/minecraft/dispenser/IBehaviorDispenseItem; -
 method public,abstract dispense (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/dispenser/IBehaviorDispenseItem 52 public,interface,abstract java/lang/Object - -
 field public,static,final DEFAULT_BEHAVIOR Lnet/minecraft/dispenser/IBehaviorDispenseItem; -
 method public,abstract dispense (Lnet/minecraft/dispenser/IBlockSource;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/dispenser/IBlockSource 50 public,interface,abstract java/lang/Object net/minecraft/dispenser/ILocatableSource -
 method public,abstract getX ()D - -
 method public,abstract getY ()D - -
 method public,abstract getZ ()D - -
 method public,abstract getBlockPos ()Lnet/minecraft/util/BlockPos; - -
 method public,abstract getBlockMetadata ()I - -
 method public,abstract getBlockTileEntity ()Lnet/minecraft/tileentity/TileEntity; <T:Lnet/minecraft/tileentity/TileEntity;>()TT; -
in 91
class net/minecraft/dispenser/IBlockSource 50 public,interface,abstract java/lang/Object net/minecraft/dispenser/ILocatableSource -
 method public,abstract getX ()D - -
 method public,abstract getY ()D - -
 method public,abstract getZ ()D - -
 method public,abstract getBlockPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public,abstract getBlockState ()Lnet/minecraft/block/state/IBlockState; - -
 method public,abstract getBlockTileEntity ()Lnet/minecraft/tileentity/TileEntity; <T:Lnet/minecraft/tileentity/TileEntity;>()TT; -
in 326
class net/minecraft/dispenser/IBlockSource 52 public,interface,abstract java/lang/Object net/minecraft/dispenser/ILocatableSource -
 method public,abstract getX ()D - -
 method public,abstract getY ()D - -
 method public,abstract getZ ()D - -
 method public,abstract getBlockPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public,abstract getBlockState ()Lnet/minecraft/block/state/IBlockState; - -
 method public,abstract getBlockTileEntity ()Lnet/minecraft/tileentity/TileEntity; <T:Lnet/minecraft/tileentity/TileEntity;>()TT; -
in 24
class net/minecraft/dispenser/ILocatableSource 50 public,interface,abstract java/lang/Object net/minecraft/dispenser/ILocation -
in 326
class net/minecraft/dispenser/ILocatableSource 52 public,interface,abstract java/lang/Object net/minecraft/dispenser/ILocation -
in 24
class net/minecraft/dispenser/ILocation 50 public,interface,abstract java/lang/Object net/minecraft/dispenser/IPosition -
 method public,abstract getWorld ()Lnet/minecraft/world/World; - -
in 326
class net/minecraft/dispenser/ILocation 52 public,interface,abstract java/lang/Object net/minecraft/dispenser/IPosition -
 method public,abstract getWorld ()Lnet/minecraft/world/World; - -
in 24
class net/minecraft/dispenser/IPosition 50 public,interface,abstract java/lang/Object - -
 method public,abstract getX ()D - -
 method public,abstract getY ()D - -
 method public,abstract getZ ()D - -
in 326
class net/minecraft/dispenser/IPosition 52 public,interface,abstract java/lang/Object - -
 method public,abstract getX ()D - -
 method public,abstract getY ()D - -
 method public,abstract getZ ()D - -
in 24
class net/minecraft/dispenser/PositionImpl 50 public,super java/lang/Object net/minecraft/dispenser/IPosition -
 field protected,final x D -
 field protected,final y D -
 field protected,final z D -
 method public <init> (DDD)V - -
 method public getX ()D - -
 method public getY ()D - -
 method public getZ ()D - -
in 326
class net/minecraft/dispenser/PositionImpl 52 public,super java/lang/Object net/minecraft/dispenser/IPosition -
 field protected,final x D -
 field protected,final y D -
 field protected,final z D -
 method public <init> (DDD)V - -
 method public getX ()D - -
 method public getY ()D - -
 method public getZ ()D - -
