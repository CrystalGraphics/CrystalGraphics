cg-stub-db 1
in 60
class oshi/annotation/SuppressForbidden 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract reason ()Ljava/lang/String; - -
in 290
class oshi/annotation/concurrent/GuardedBy 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 method public,abstract value ()Ljava/lang/String; - -
in 290
class oshi/annotation/concurrent/Immutable 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
in 290
class oshi/annotation/concurrent/NotThreadSafe 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
in 290
class oshi/annotation/concurrent/ThreadSafe 52 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
