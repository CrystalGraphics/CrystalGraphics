cg-stub-db 1
in 24
class ibxm/Channel 50 public,super java/lang/Object - -
 field public pattern_loop_row I -
 method public <init> (Libxm/Module;I[I)V - -
 method public reset ()V - -
 method public resample ([IIII)V - -
 method public update_sample_idx (I)V - -
 method public set_volume (I)V - -
 method public set_panning (I)V - -
 method public row (IIIII)V - -
 method public tick ()V - -
in 326
class ibxm/Channel 52 public,super java/lang/Object - -
 field public pattern_loop_row I -
 method public <init> (Libxm/Module;I[I)V - -
 method public reset ()V - -
 method public resample ([IIII)V - -
 method public update_sample_idx (I)V - -
 method public set_volume (I)V - -
 method public set_panning (I)V - -
 method public row (IIIII)V - -
 method public tick ()V - -
in 24
class ibxm/Envelope 50 public,super java/lang/Object - -
 field public sustain Z -
 field public looped Z -
 method public <init> ()V - -
 method public set_num_points (I)V - -
 method public set_point (IIIZ)V - -
 method public set_sustain_point (I)V - -
 method public set_loop_points (II)V - -
 method public next_tick (IZ)I - -
 method public calculate_ampl (I)I - -
 method public dump ()V - -
in 326
class ibxm/Envelope 52 public,super java/lang/Object - -
 field public sustain Z -
 field public looped Z -
 method public <init> ()V - -
 method public set_num_points (I)V - -
 method public set_point (IIIZ)V - -
 method public set_sustain_point (I)V - -
 method public set_loop_points (II)V - -
 method public next_tick (IZ)I - -
 method public calculate_ampl (I)I - -
 method public dump ()V - -
in 24
class ibxm/FastTracker2 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static is_xm ([B)Z - -
 method public,static load_xm ([BLjava/io/DataInput;)Libxm/Module; - java/io/IOException
in 326
class ibxm/FastTracker2 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static is_xm ([B)Z - -
 method public,static load_xm ([BLjava/io/DataInput;)Libxm/Module; - java/io/IOException
in 24
class ibxm/IBXM 50 public,super java/lang/Object - -
 field public,static,final VERSION Ljava/lang/String; - "ibxm alpha 51 (c)2008 mumart@gmail.com"
 field public,static,final FP_SHIFT I - I15
 field public,static,final FP_ONE I - I32768
 field public,static,final FP_MASK I - I32767
 method public <init> (I)V - -
 method public set_module (Libxm/Module;)V - -
 method public set_resampling_quality (I)V - -
 method public calculate_song_duration ()I - -
 method public set_sequence_index (II)V - -
 method public seek (I)V - -
 method public get_audio ([BI)V - -
in 326
class ibxm/IBXM 52 public,super java/lang/Object - -
 field public,static,final VERSION Ljava/lang/String; - "ibxm alpha 51 (c)2008 mumart@gmail.com"
 field public,static,final FP_SHIFT I - I15
 field public,static,final FP_ONE I - I32768
 field public,static,final FP_MASK I - I32767
 method public <init> (I)V - -
 method public set_module (Libxm/Module;)V - -
 method public set_resampling_quality (I)V - -
 method public calculate_song_duration ()I - -
 method public set_sequence_index (II)V - -
 method public seek (I)V - -
 method public get_audio ([BI)V - -
in 24
class ibxm/Instrument 50 public,super java/lang/Object - -
 field public name Ljava/lang/String; -
 field public vibrato_type I -
 field public vibrato_sweep I -
 field public vibrato_depth I -
 field public vibrato_rate I -
 field public volume_envelope_active Z -
 field public panning_envelope_active Z -
 field public volume_fade_out I -
 method public <init> ()V - -
 method public get_volume_envelope ()Libxm/Envelope; - -
 method public set_volume_envelope (Libxm/Envelope;)V - -
 method public get_panning_envelope ()Libxm/Envelope; - -
 method public set_panning_envelope (Libxm/Envelope;)V - -
 method public get_sample_from_key (I)Libxm/Sample; - -
 method public set_key_to_sample (II)V - -
 method public get_num_samples ()I - -
 method public set_num_samples (I)V - -
 method public get_sample (I)Libxm/Sample; - -
 method public set_sample (ILibxm/Sample;)V - -
in 326
class ibxm/Instrument 52 public,super java/lang/Object - -
 field public name Ljava/lang/String; -
 field public vibrato_type I -
 field public vibrato_sweep I -
 field public vibrato_depth I -
 field public vibrato_rate I -
 field public volume_envelope_active Z -
 field public panning_envelope_active Z -
 field public volume_fade_out I -
 method public <init> ()V - -
 method public get_volume_envelope ()Libxm/Envelope; - -
 method public set_volume_envelope (Libxm/Envelope;)V - -
 method public get_panning_envelope ()Libxm/Envelope; - -
 method public set_panning_envelope (Libxm/Envelope;)V - -
 method public get_sample_from_key (I)Libxm/Sample; - -
 method public set_key_to_sample (II)V - -
 method public get_num_samples ()I - -
 method public set_num_samples (I)V - -
 method public get_sample (I)Libxm/Sample; - -
 method public set_sample (ILibxm/Sample;)V - -
in 24
class ibxm/LogTable 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static log_2 (I)I - -
 method public,static raise_2 (I)I - -
in 326
class ibxm/LogTable 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static log_2 (I)I - -
 method public,static raise_2 (I)I - -
in 24
class ibxm/Module 50 public,super java/lang/Object - -
 field public song_title Ljava/lang/String; -
 field public linear_periods Z -
 field public fast_volume_slides Z -
 field public pal Z -
 field public global_volume I -
 field public channel_gain I -
 field public default_speed I -
 field public default_tempo I -
 field public restart_sequence_index I -
 method public <init> ()V - -
 method public get_num_channels ()I - -
 method public set_num_channels (I)V - -
 method public get_initial_panning (I)I - -
 method public set_initial_panning (II)V - -
 method public get_sequence_length ()I - -
 method public set_sequence_length (I)V - -
 method public set_sequence (II)V - -
 method public get_num_patterns ()I - -
 method public set_num_patterns (I)V - -
 method public get_pattern_from_sequence (I)Libxm/Pattern; - -
 method public get_pattern (I)Libxm/Pattern; - -
 method public set_pattern (ILibxm/Pattern;)V - -
 method public get_num_instruments ()I - -
 method public set_num_instruments (I)V - -
 method public get_instrument (I)Libxm/Instrument; - -
 method public set_instrument (ILibxm/Instrument;)V - -
in 326
class ibxm/Module 52 public,super java/lang/Object - -
 field public song_title Ljava/lang/String; -
 field public linear_periods Z -
 field public fast_volume_slides Z -
 field public pal Z -
 field public global_volume I -
 field public channel_gain I -
 field public default_speed I -
 field public default_tempo I -
 field public restart_sequence_index I -
 method public <init> ()V - -
 method public get_num_channels ()I - -
 method public set_num_channels (I)V - -
 method public get_initial_panning (I)I - -
 method public set_initial_panning (II)V - -
 method public get_sequence_length ()I - -
 method public set_sequence_length (I)V - -
 method public set_sequence (II)V - -
 method public get_num_patterns ()I - -
 method public set_num_patterns (I)V - -
 method public get_pattern_from_sequence (I)Libxm/Pattern; - -
 method public get_pattern (I)Libxm/Pattern; - -
 method public set_pattern (ILibxm/Pattern;)V - -
 method public get_num_instruments ()I - -
 method public set_num_instruments (I)V - -
 method public get_instrument (I)Libxm/Instrument; - -
 method public set_instrument (ILibxm/Instrument;)V - -
in 24
class ibxm/Pattern 50 public,super java/lang/Object - -
 field public num_rows I -
 method public <init> ()V - -
 method public set_pattern_data ([B)V - -
 method public get_note ([II)V - -
 method public next_note (I[I)I - -
in 326
class ibxm/Pattern 52 public,super java/lang/Object - -
 field public num_rows I -
 method public <init> ()V - -
 method public set_pattern_data ([B)V - -
 method public get_note ([II)V - -
 method public next_note (I[I)I - -
in 24
class ibxm/Player 50 public,super java/lang/Object - -
 inner ibxm/Player$Driver ibxm/Player Driver private
 method public,static main ([Ljava/lang/String;)V - java/lang/Exception
 method public,static load_module (Ljava/io/InputStream;)Libxm/Module; - java/lang/IllegalArgumentException,java/io/IOException
 method public <init> ()V - javax/sound/sampled/LineUnavailableException
 method public set_module (Libxm/Module;)V - -
 method public set_loop (Z)V - -
 method public play ()V - -
 method public stop ()V - -
in 326
class ibxm/Player 52 public,super java/lang/Object - -
 inner ibxm/Player$Driver ibxm/Player Driver private
 method public,static main ([Ljava/lang/String;)V - java/lang/Exception
 method public,static load_module (Ljava/io/InputStream;)Libxm/Module; - java/lang/IllegalArgumentException,java/io/IOException
 method public <init> ()V - javax/sound/sampled/LineUnavailableException
 method public set_module (Libxm/Module;)V - -
 method public set_loop (Z)V - -
 method public play ()V - -
 method public stop ()V - -
in 24
class ibxm/Player$Driver 50 super java/lang/Object java/lang/Runnable -
 inner ibxm/Player$Driver ibxm/Player Driver private
 method public run ()V - -
in 326
class ibxm/Player$Driver 52 super java/lang/Object java/lang/Runnable -
 inner ibxm/Player$Driver ibxm/Player Driver private
 method public run ()V - -
in 24
class ibxm/ProTracker 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static is_mod ([B)Z - -
 method public,static load_mod ([BLjava/io/DataInput;)Libxm/Module; - java/io/IOException
in 326
class ibxm/ProTracker 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static is_mod ([B)Z - -
 method public,static load_mod ([BLjava/io/DataInput;)Libxm/Module; - java/io/IOException
in 24
class ibxm/Sample 50 public,super java/lang/Object - -
 field public name Ljava/lang/String; -
 field public set_panning Z -
 field public volume I -
 field public panning I -
 field public transpose I -
 method public <init> ()V - -
 method public set_sample_data ([SIIZ)V - -
 method public resample_nearest (IIIII[III)V - -
 method public resample_linear (IIIII[III)V - -
 method public resample_sinc (IIIII[III)V - -
 method public has_finished (I)Z - -
in 326
class ibxm/Sample 52 public,super java/lang/Object - -
 field public name Ljava/lang/String; -
 field public set_panning Z -
 field public volume I -
 field public panning I -
 field public transpose I -
 method public <init> ()V - -
 method public set_sample_data ([SIIZ)V - -
 method public resample_nearest (IIIII[III)V - -
 method public resample_linear (IIIII[III)V - -
 method public resample_sinc (IIIII[III)V - -
 method public has_finished (I)Z - -
in 24
class ibxm/ScreamTracker3 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static is_s3m ([B)Z - -
 method public,static load_s3m ([BLjava/io/DataInput;)Libxm/Module; - java/io/IOException
in 326
class ibxm/ScreamTracker3 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static is_s3m ([B)Z - -
 method public,static load_s3m ([BLjava/io/DataInput;)Libxm/Module; - java/io/IOException
