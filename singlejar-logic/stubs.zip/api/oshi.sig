cg-stub-db 1
in 126
class oshi/PlatformEnum 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/PlatformEnum;>;
 field public,static,final,enum WINDOWS Loshi/PlatformEnum; -
 field public,static,final,enum LINUX Loshi/PlatformEnum; -
 field public,static,final,enum MACOSX Loshi/PlatformEnum; -
 field public,static,final,enum UNKNOWN Loshi/PlatformEnum; -
 method public,static values ()[Loshi/PlatformEnum; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/PlatformEnum; - -
in 82
class oshi/PlatformEnum 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/PlatformEnum;>;
 field public,static,final,enum WINDOWS Loshi/PlatformEnum; -
 field public,static,final,enum LINUX Loshi/PlatformEnum; -
 field public,static,final,enum MACOS Loshi/PlatformEnum; -
 field public,static,final,enum,deprecated MACOSX Loshi/PlatformEnum; -
 field public,static,final,enum SOLARIS Loshi/PlatformEnum; -
 field public,static,final,enum FREEBSD Loshi/PlatformEnum; -
 field public,static,final,enum AIX Loshi/PlatformEnum; -
 field public,static,final,enum OPENBSD Loshi/PlatformEnum; -
 field public,static,final,enum UNKNOWN Loshi/PlatformEnum; -
 method public,static values ()[Loshi/PlatformEnum; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/PlatformEnum; - -
in 34
class oshi/PlatformEnum 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/PlatformEnum;>;
 field public,static,final,enum MACOS Loshi/PlatformEnum; -
 field public,static,final,enum LINUX Loshi/PlatformEnum; -
 field public,static,final,enum WINDOWS Loshi/PlatformEnum; -
 field public,static,final,enum SOLARIS Loshi/PlatformEnum; -
 field public,static,final,enum FREEBSD Loshi/PlatformEnum; -
 field public,static,final,enum OPENBSD Loshi/PlatformEnum; -
 field public,static,final,enum WINDOWSCE Loshi/PlatformEnum; -
 field public,static,final,enum AIX Loshi/PlatformEnum; -
 field public,static,final,enum ANDROID Loshi/PlatformEnum; -
 field public,static,final,enum GNU Loshi/PlatformEnum; -
 field public,static,final,enum KFREEBSD Loshi/PlatformEnum; -
 field public,static,final,enum NETBSD Loshi/PlatformEnum; -
 field public,static,final,enum UNKNOWN Loshi/PlatformEnum; -
 field public,static,final,enum,deprecated MACOSX Loshi/PlatformEnum; -
 method public,static values ()[Loshi/PlatformEnum; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/PlatformEnum; - -
 method public getName ()Ljava/lang/String; - -
 method public,static getName (I)Ljava/lang/String; - -
 method public,static getValue (I)Loshi/PlatformEnum; - -
in 39
class oshi/PlatformEnum 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/PlatformEnum;>;
 field public,static,final,enum MACOS Loshi/PlatformEnum; -
 field public,static,final,enum LINUX Loshi/PlatformEnum; -
 field public,static,final,enum WINDOWS Loshi/PlatformEnum; -
 field public,static,final,enum SOLARIS Loshi/PlatformEnum; -
 field public,static,final,enum FREEBSD Loshi/PlatformEnum; -
 field public,static,final,enum OPENBSD Loshi/PlatformEnum; -
 field public,static,final,enum WINDOWSCE Loshi/PlatformEnum; -
 field public,static,final,enum AIX Loshi/PlatformEnum; -
 field public,static,final,enum ANDROID Loshi/PlatformEnum; -
 field public,static,final,enum GNU Loshi/PlatformEnum; -
 field public,static,final,enum KFREEBSD Loshi/PlatformEnum; -
 field public,static,final,enum NETBSD Loshi/PlatformEnum; -
 field public,static,final,enum UNKNOWN Loshi/PlatformEnum; -
 method public,static values ()[Loshi/PlatformEnum; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/PlatformEnum; - -
 method public getName ()Ljava/lang/String; - -
 method public,static getName (I)Ljava/lang/String; - -
 method public,static getValue (I)Loshi/PlatformEnum; - -
in 126
class oshi/SystemInfo 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public getOperatingSystem ()Loshi/software/os/OperatingSystem; - -
 method public getHardware ()Loshi/hardware/HardwareAbstractionLayer; - -
in 1183
class oshi/SystemInfo 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getCurrentPlatform ()Loshi/PlatformEnum; - -
 method public,static,deprecated getCurrentPlatformEnum ()Loshi/PlatformEnum; - -
 method public getOperatingSystem ()Loshi/software/os/OperatingSystem; - -
 method public getHardware ()Loshi/hardware/HardwareAbstractionLayer; - -
in 39
class oshi/SystemInfo 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static getCurrentPlatform ()Loshi/PlatformEnum; - -
 method public getOperatingSystem ()Loshi/software/os/OperatingSystem; - -
 method public getHardware ()Loshi/hardware/HardwareAbstractionLayer; - -
