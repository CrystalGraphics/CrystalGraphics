cg-stub-db 1
in 21
class net/jcip/annotations/GuardedBy 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract value ()Ljava/lang/String; - -
in 21
class net/jcip/annotations/Immutable 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 21
class net/jcip/annotations/NotThreadSafe 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 21
class net/jcip/annotations/ThreadSafe 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Documented;()
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#TYPE])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
