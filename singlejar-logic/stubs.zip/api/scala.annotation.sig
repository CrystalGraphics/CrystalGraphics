cg-stub-db 1
in 0
class scala/annotation/Annotation 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
in 0
class scala/annotation/ClassfileAnnotation 50 public,interface,abstract java/lang/Object scala/annotation/StaticAnnotation -
in 0
class scala/annotation/StaticAnnotation 50 public,interface,abstract java/lang/Object - -
in 0
class scala/annotation/TypeConstraint 50 public,interface,abstract java/lang/Object - -
in 0
class scala/annotation/bridge 50 public,super,deprecated scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/compileTimeOnly 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/annotation/elidable 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public,static byName ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,static ASSERTION ()I - -
 method public,static MINIMUM ()I - -
 method public,static MAXIMUM ()I - -
 method public,static OFF ()I - -
 method public,static SEVERE ()I - -
 method public,static WARNING ()I - -
 method public,static INFO ()I - -
 method public,static CONFIG ()I - -
 method public,static FINE ()I - -
 method public,static FINER ()I - -
 method public,static FINEST ()I - -
 method public,static ALL ()I - -
 method public,final level ()I - -
 method public <init> (I)V - -
in 0
class scala/annotation/elidable$ 50 public,final,super java/lang/Object - -
 inner scala/Predef$ArrowAssoc$ scala/Predef ArrowAssoc$ public,static
 field public,static,final MODULE$ Lscala/annotation/elidable$; -
 method public,static <clinit> ()V - -
 method public,final ALL ()I - -
 method public,final FINEST ()I - -
 method public,final FINER ()I - -
 method public,final FINE ()I - -
 method public,final CONFIG ()I - -
 method public,final INFO ()I - -
 method public,final WARNING ()I - -
 method public,final SEVERE ()I - -
 method public,final OFF ()I - -
 method public,final MAXIMUM ()I - -
 method public,final MINIMUM ()I - -
 method public,final ASSERTION ()I - -
 method public byName ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/Object;>; -
in 0
class scala/annotation/implicitNotFound 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/annotation/meta/beanGetter 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/beanSetter 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/companionClass 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/companionMethod 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/companionObject 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/field 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/getter 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/languageFeature 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> (Ljava/lang/String;Z)V - -
in 0
class scala/annotation/meta/package 50 public,final,super java/lang/Object - -
in 0
class scala/annotation/meta/package$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/annotation/meta/package$; -
 method public,static <clinit> ()V - -
in 0
class scala/annotation/meta/param 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/meta/setter 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/migration 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 0
class scala/annotation/strictfp 50 public,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/switch 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/tailrec 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/unchecked/uncheckedStable 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/unchecked/uncheckedVariance 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/unspecialized 50 public,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/annotation/varargs 50 public,final,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
