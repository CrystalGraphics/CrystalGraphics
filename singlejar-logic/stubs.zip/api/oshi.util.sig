cg-stub-db 1
in 1183
class oshi/util/Constants 52 public,final,super java/lang/Object - -
 field public,static,final UNKNOWN Ljava/lang/String; - "unknown"
 field public,static,final SYSFS_SERIAL_PATH Ljava/lang/String; - "/sys/devices/virtual/dmi/id/"
 field public,static,final UNIX_EPOCH Ljava/time/OffsetDateTime; -
in 35
class oshi/util/Constants 52 public,final,super java/lang/Object - -
 field public,static,final UNKNOWN Ljava/lang/String; - "unknown"
 field public,static,final SYSFS_SERIAL_PATH Ljava/lang/String; - "/sys/devices/virtual/dmi/id/"
 field public,static,final UNIX_EPOCH Ljava/time/OffsetDateTime; -
 field public,static,final DIGITS Ljava/util/regex/Pattern; -
in 28
class oshi/util/Constants 52 public,final,super java/lang/Object - -
 field public,static,final UNKNOWN Ljava/lang/String; - "unknown"
 field public,static,final UNIX_EPOCH Ljava/time/OffsetDateTime; -
 field public,static,final DIGITS Ljava/util/regex/Pattern; -
in 1186
class oshi/util/EdidUtil 52 public,final,super java/lang/Object - -
 method public,static getManufacturerID ([B)Ljava/lang/String; - -
 method public,static getProductID ([B)Ljava/lang/String; - -
 method public,static getSerialNo ([B)Ljava/lang/String; - -
 method public,static getWeek ([B)B - -
 method public,static getYear ([B)I - -
 method public,static getVersion ([B)Ljava/lang/String; - -
 method public,static isDigital ([B)Z - -
 method public,static getHcm ([B)I - -
 method public,static getVcm ([B)I - -
 method public,static getDescriptors ([B)[[B - -
 method public,static getDescriptorType ([B)I - -
 method public,static getTimingDescriptor ([B)Ljava/lang/String; - -
 method public,static getDescriptorRangeLimits ([B)Ljava/lang/String; - -
 method public,static getDescriptorText ([B)Ljava/lang/String; - -
 method public,static toString ([B)Ljava/lang/String; - -
in 2
class oshi/util/EdidUtil 52 public,final,super java/lang/Object - -
 method public,static getManufacturerID ([B)Ljava/lang/String; - -
 method public,static getProductID ([B)Ljava/lang/String; - -
 method public,static getSerialNo ([B)Ljava/lang/String; - -
 method public,static getWeek ([B)B - -
 method public,static getYear ([B)I - -
 method public,static getVersion ([B)Ljava/lang/String; - -
 method public,static isDigital ([B)Z - -
 method public,static getHcm ([B)I - -
 method public,static getVcm ([B)I - -
 method public,static getDescriptors ([B)[[B - -
 method public,static getDescriptorType ([B)I - -
 method public,static getTimingDescriptor ([B)Ljava/lang/String; - -
 method public,static getDescriptorRangeLimits ([B)Ljava/lang/String; - -
 method public,static getDescriptorText ([B)Ljava/lang/String; - -
 method public,static getPreferredResolution ([B)Ljava/lang/String; - -
 method public,static getModel ([B)Ljava/lang/String; - -
 method public,static toString ([B)Ljava/lang/String; - -
in 126
class oshi/util/ExecutingCommand 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static runNative (Ljava/lang/String;)Ljava/util/ArrayList; (Ljava/lang/String;)Ljava/util/ArrayList<Ljava/lang/String;>; -
 method public,static getFirstAnswer (Ljava/lang/String;)Ljava/lang/String; - -
in 290
class oshi/util/ExecutingCommand 52 public,final,super java/lang/Object - -
 method public,static runNative (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static runNative ([Ljava/lang/String;)Ljava/util/List; ([Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static runNative ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List; ([Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getFirstAnswer (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getAnswerAt (Ljava/lang/String;I)Ljava/lang/String; - -
in 290
class oshi/util/FileSystemUtil 52 public,final,super java/lang/Object - -
 method public,static isFileStoreExcluded (Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)Z (Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Ljava/nio/file/PathMatcher;>;Ljava/util/List<Ljava/nio/file/PathMatcher;>;Ljava/util/List<Ljava/nio/file/PathMatcher;>;Ljava/util/List<Ljava/nio/file/PathMatcher;>;)Z -
 method public,static loadAndParseFileSystemConfig (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/nio/file/PathMatcher;>; -
 method public,static parseFileSystemConfig (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/nio/file/PathMatcher;>; -
 method public,static matches (Ljava/nio/file/Path;Ljava/util/List;)Z (Ljava/nio/file/Path;Ljava/util/List<Ljava/nio/file/PathMatcher;>;)Z -
in 82
class oshi/util/FileUtil 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static readFile (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readFile (Ljava/lang/String;Z)Ljava/util/List; (Ljava/lang/String;Z)Ljava/util/List<Ljava/lang/String;>; -
 method public,static getLongFromFile (Ljava/lang/String;)J - -
 method public,static getUnsignedLongFromFile (Ljava/lang/String;)J - -
 method public,static getIntFromFile (Ljava/lang/String;)I - -
 method public,static getStringFromFile (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getKeyValueMapFromFile (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static readPropertiesFromFilename (Ljava/lang/String;)Ljava/util/Properties; - -
 method public,static readSymlinkTarget (Ljava/io/File;)Ljava/lang/String; - -
in 34
class oshi/util/FileUtil 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static readFile (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readFile (Ljava/lang/String;Z)Ljava/util/List; (Ljava/lang/String;Z)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readAllBytes (Ljava/lang/String;)[B - -
 method public,static readAllBytes (Ljava/lang/String;Z)[B - -
 method public,static getLongFromFile (Ljava/lang/String;)J - -
 method public,static getUnsignedLongFromFile (Ljava/lang/String;)J - -
 method public,static getIntFromFile (Ljava/lang/String;)I - -
 method public,static getStringFromFile (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getKeyValueMapFromFile (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static readPropertiesFromFilename (Ljava/lang/String;)Ljava/util/Properties; - -
 method public,static readSymlinkTarget (Ljava/io/File;)Ljava/lang/String; - -
in 35
class oshi/util/FileUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static readFile (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readFile (Ljava/lang/String;Z)Ljava/util/List; (Ljava/lang/String;Z)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readAllBytes (Ljava/lang/String;)[B - -
 method public,static readAllBytes (Ljava/lang/String;Z)[B - -
 method public,static readAllBytesAsBuffer (Ljava/lang/String;)Ljava/nio/ByteBuffer; - -
 method public,static readByteFromBuffer (Ljava/nio/ByteBuffer;)B - -
 method public,static readShortFromBuffer (Ljava/nio/ByteBuffer;)S - -
 method public,static readIntFromBuffer (Ljava/nio/ByteBuffer;)I - -
 method public,static readLongFromBuffer (Ljava/nio/ByteBuffer;)J - -
 method public,static readNativeLongFromBuffer (Ljava/nio/ByteBuffer;)Lcom/sun/jna/NativeLong; - -
 method public,static readSizeTFromBuffer (Ljava/nio/ByteBuffer;)Lcom/sun/jna/platform/unix/LibCAPI$size_t; - -
 method public,static readByteArrayFromBuffer (Ljava/nio/ByteBuffer;[B)V - -
 method public,static readPointerFromBuffer (Ljava/nio/ByteBuffer;)Lcom/sun/jna/Pointer; - -
 method public,static getLongFromFile (Ljava/lang/String;)J - -
 method public,static getUnsignedLongFromFile (Ljava/lang/String;)J - -
 method public,static getIntFromFile (Ljava/lang/String;)I - -
 method public,static getStringFromFile (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getKeyValueMapFromFile (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static readPropertiesFromFilename (Ljava/lang/String;)Ljava/util/Properties; - -
 method public,static readSymlinkTarget (Ljava/io/File;)Ljava/lang/String; - -
in 28
class oshi/util/FileUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static readFile (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readFile (Ljava/lang/String;Z)Ljava/util/List; (Ljava/lang/String;Z)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readLines (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readLines (Ljava/lang/String;IZ)Ljava/util/List; (Ljava/lang/String;IZ)Ljava/util/List<Ljava/lang/String;>; -
 method public,static readAllBytes (Ljava/lang/String;Z)[B - -
 method public,static readAllBytesAsBuffer (Ljava/lang/String;)Ljava/nio/ByteBuffer; - -
 method public,static readByteFromBuffer (Ljava/nio/ByteBuffer;)B - -
 method public,static readShortFromBuffer (Ljava/nio/ByteBuffer;)S - -
 method public,static readIntFromBuffer (Ljava/nio/ByteBuffer;)I - -
 method public,static readLongFromBuffer (Ljava/nio/ByteBuffer;)J - -
 method public,static readNativeLongFromBuffer (Ljava/nio/ByteBuffer;)Lcom/sun/jna/NativeLong; - -
 method public,static readSizeTFromBuffer (Ljava/nio/ByteBuffer;)Lcom/sun/jna/platform/unix/LibCAPI$size_t; - -
 method public,static readByteArrayFromBuffer (Ljava/nio/ByteBuffer;[B)V - -
 method public,static readPointerFromBuffer (Ljava/nio/ByteBuffer;)Lcom/sun/jna/Pointer; - -
 method public,static getLongFromFile (Ljava/lang/String;)J - -
 method public,static getUnsignedLongFromFile (Ljava/lang/String;)J - -
 method public,static getIntFromFile (Ljava/lang/String;)I - -
 method public,static getStringFromFile (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getKeyValueMapFromFile (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static readPropertiesFromFilename (Ljava/lang/String;)Ljava/util/Properties; - -
 method public,static readFileAsBytes (Ljava/net/URL;)[B - java/io/IOException
 method public,static readSymlinkTarget (Ljava/io/File;)Ljava/lang/String; - -
in 126
class oshi/util/FormatUtil 49 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,static formatBytes (J)Ljava/lang/String; - -
 method public,static round (FI)F - -
in 290
class oshi/util/FormatUtil 52 public,final,super java/lang/Object - -
 field public,static,final HEX_ERROR Ljava/lang/String; - "0x%08X"
 method public,static formatBytes (J)Ljava/lang/String; - -
 method public,static formatBytesDecimal (J)Ljava/lang/String; - -
 method public,static formatHertz (J)Ljava/lang/String; - -
 method public,static formatValue (JLjava/lang/String;)Ljava/lang/String; - -
 method public,static formatElapsedSecs (J)Ljava/lang/String; - -
 method public,static getUnsignedInt (I)J - -
 method public,static toUnsignedString (I)Ljava/lang/String; - -
 method public,static toUnsignedString (J)Ljava/lang/String; - -
 method public,static formatError (I)Ljava/lang/String; - -
 method public,static roundToInt (D)I - -
in 1183
class oshi/util/GlobalConfig 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 method public,static get (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;I)I - -
 method public,static get (Ljava/lang/String;D)D - -
 method public,static get (Ljava/lang/String;Z)Z - -
 method public,static set (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,static remove (Ljava/lang/String;)V - -
 method public,static clear ()V - -
 method public,static load (Ljava/util/Properties;)V - -
in 42
class oshi/util/GlobalConfig 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final OSHI_UTIL_MEMOIZER_EXPIRATION Ljava/lang/String; - "oshi.util.memoizer.expiration"
 field public,static,final OSHI_UTIL_WMI_TIMEOUT Ljava/lang/String; - "oshi.util.wmi.timeout"
 field public,static,final OSHI_UTIL_PROC_PATH Ljava/lang/String; - "oshi.util.proc.path"
 field public,static,final OSHI_PSEUDO_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.pseudo.filesystem.types"
 field public,static,final OSHI_NETWORK_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.network.filesystem.types"
 field public,static,final OSHI_OS_WINDOWS_EVENTLOG Ljava/lang/String; - "oshi.os.windows.eventlog"
 field public,static,final OSHI_OS_WINDOWS_PROCSTATE_SUSPENDED Ljava/lang/String; - "oshi.os.windows.procstate.suspended"
 field public,static,final OSHI_OS_WINDOWS_COMMANDLINE_BATCH Ljava/lang/String; - "oshi.os.windows.commandline.batch"
 field public,static,final OSHI_OS_WINDOWS_HKEYPERFDATA Ljava/lang/String; - "oshi.os.windows.hkeyperfdata"
 field public,static,final OSHI_OS_WINDOWS_LOADAVERAGE Ljava/lang/String; - "oshi.os.windows.loadaverage"
 field public,static,final OSHI_OS_WINDOWS_CPU_UTILITY Ljava/lang/String; - "oshi.os.windows.cpu.utility"
 field public,static,final OSHI_OS_WINDOWS_PERFDISK_DIABLED Ljava/lang/String; - "oshi.os.windows.perfdisk.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFOS_DIABLED Ljava/lang/String; - "oshi.os.windows.perfos.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFPROC_DIABLED Ljava/lang/String; - "oshi.os.windows.perfproc.disabled"
 field public,static,final OSHI_OS_UNIX_WHOCOMMAND Ljava/lang/String; - "oshi.os.unix.whoCommand"
 method public,static get (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;I)I - -
 method public,static get (Ljava/lang/String;D)D - -
 method public,static get (Ljava/lang/String;Z)Z - -
 method public,static set (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,static remove (Ljava/lang/String;)V - -
 method public,static clear ()V - -
 method public,static load (Ljava/util/Properties;)V - -
in 37
class oshi/util/GlobalConfig 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final OSHI_UTIL_MEMOIZER_EXPIRATION Ljava/lang/String; - "oshi.util.memoizer.expiration"
 field public,static,final OSHI_UTIL_WMI_TIMEOUT Ljava/lang/String; - "oshi.util.wmi.timeout"
 field public,static,final OSHI_UTIL_PROC_PATH Ljava/lang/String; - "oshi.util.proc.path"
 field public,static,final OSHI_PSEUDO_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.pseudo.filesystem.types"
 field public,static,final OSHI_NETWORK_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.network.filesystem.types"
 field public,static,final OSHI_OS_LINUX_PROCFS_LOGWARNING Ljava/lang/String; - "oshi.os.linux.procfs.logwarning"
 field public,static,final OSHI_OS_MAC_SYSCTL_LOGWARNING Ljava/lang/String; - "oshi.os.mac.sysctl.logwarning"
 field public,static,final OSHI_OS_WINDOWS_EVENTLOG Ljava/lang/String; - "oshi.os.windows.eventlog"
 field public,static,final OSHI_OS_WINDOWS_PROCSTATE_SUSPENDED Ljava/lang/String; - "oshi.os.windows.procstate.suspended"
 field public,static,final OSHI_OS_WINDOWS_COMMANDLINE_BATCH Ljava/lang/String; - "oshi.os.windows.commandline.batch"
 field public,static,final OSHI_OS_WINDOWS_HKEYPERFDATA Ljava/lang/String; - "oshi.os.windows.hkeyperfdata"
 field public,static,final OSHI_OS_WINDOWS_LOADAVERAGE Ljava/lang/String; - "oshi.os.windows.loadaverage"
 field public,static,final OSHI_OS_WINDOWS_CPU_UTILITY Ljava/lang/String; - "oshi.os.windows.cpu.utility"
 field public,static,final OSHI_OS_WINDOWS_PERFDISK_DIABLED Ljava/lang/String; - "oshi.os.windows.perfdisk.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFOS_DIABLED Ljava/lang/String; - "oshi.os.windows.perfos.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFPROC_DIABLED Ljava/lang/String; - "oshi.os.windows.perfproc.disabled"
 field public,static,final OSHI_OS_UNIX_WHOCOMMAND Ljava/lang/String; - "oshi.os.unix.whoCommand"
 field public,static,final OSHI_OS_SOLARIS_ALLOWKSTAT2 Ljava/lang/String; - "oshi.os.solaris.allowKstat2"
 method public,static get (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;I)I - -
 method public,static get (Ljava/lang/String;D)D - -
 method public,static get (Ljava/lang/String;Z)Z - -
 method public,static set (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,static remove (Ljava/lang/String;)V - -
 method public,static clear ()V - -
 method public,static load (Ljava/util/Properties;)V - -
in 26
class oshi/util/GlobalConfig 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final OSHI_UTIL_MEMOIZER_EXPIRATION Ljava/lang/String; - "oshi.util.memoizer.expiration"
 field public,static,final OSHI_UTIL_WMI_TIMEOUT Ljava/lang/String; - "oshi.util.wmi.timeout"
 field public,static,final OSHI_UTIL_PROC_PATH Ljava/lang/String; - "oshi.util.proc.path"
 field public,static,final OSHI_UTIL_SYS_PATH Ljava/lang/String; - "oshi.util.sys.path"
 field public,static,final OSHI_UTIL_DEV_PATH Ljava/lang/String; - "oshi.util.dev.path"
 field public,static,final OSHI_PSEUDO_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.pseudo.filesystem.types"
 field public,static,final OSHI_NETWORK_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.network.filesystem.types"
 field public,static,final OSHI_OS_LINUX_ALLOWUDEV Ljava/lang/String; - "oshi.os.linux.allowudev"
 field public,static,final OSHI_OS_LINUX_PROCFS_LOGWARNING Ljava/lang/String; - "oshi.os.linux.procfs.logwarning"
 field public,static,final OSHI_OS_MAC_SYSCTL_LOGWARNING Ljava/lang/String; - "oshi.os.mac.sysctl.logwarning"
 field public,static,final OSHI_OS_WINDOWS_EVENTLOG Ljava/lang/String; - "oshi.os.windows.eventlog"
 field public,static,final OSHI_OS_WINDOWS_PROCSTATE_SUSPENDED Ljava/lang/String; - "oshi.os.windows.procstate.suspended"
 field public,static,final OSHI_OS_WINDOWS_COMMANDLINE_BATCH Ljava/lang/String; - "oshi.os.windows.commandline.batch"
 field public,static,final OSHI_OS_WINDOWS_HKEYPERFDATA Ljava/lang/String; - "oshi.os.windows.hkeyperfdata"
 field public,static,final OSHI_OS_WINDOWS_LEGACY_SYSTEM_COUNTERS Ljava/lang/String; - "oshi.os.windows.legacy.system.counters"
 field public,static,final OSHI_OS_WINDOWS_LOADAVERAGE Ljava/lang/String; - "oshi.os.windows.loadaverage"
 field public,static,final OSHI_OS_WINDOWS_CPU_UTILITY Ljava/lang/String; - "oshi.os.windows.cpu.utility"
 field public,static,final OSHI_OS_WINDOWS_PERFDISK_DIABLED Ljava/lang/String; - "oshi.os.windows.perfdisk.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFOS_DIABLED Ljava/lang/String; - "oshi.os.windows.perfos.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFPROC_DIABLED Ljava/lang/String; - "oshi.os.windows.perfproc.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERF_DISABLE_ALL_ON_FAILURE Ljava/lang/String; - "oshi.os.windows.perf.disable.all.on.failure"
 field public,static,final OSHI_OS_UNIX_WHOCOMMAND Ljava/lang/String; - "oshi.os.unix.whoCommand"
 field public,static,final OSHI_OS_SOLARIS_ALLOWKSTAT2 Ljava/lang/String; - "oshi.os.solaris.allowKstat2"
 method public,static get (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;I)I - -
 method public,static get (Ljava/lang/String;D)D - -
 method public,static get (Ljava/lang/String;Z)Z - -
 method public,static set (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,static remove (Ljava/lang/String;)V - -
 method public,static clear ()V - -
 method public,static load (Ljava/util/Properties;)V - -
in 2
class oshi/util/GlobalConfig 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_UTIL_MEMOIZER_EXPIRATION Ljava/lang/String; - "oshi.util.memoizer.expiration"
 field public,static,final OSHI_UTIL_WMI_TIMEOUT Ljava/lang/String; - "oshi.util.wmi.timeout"
 field public,static,final OSHI_UTIL_PROC_PATH Ljava/lang/String; - "oshi.util.proc.path"
 field public,static,final OSHI_UTIL_SYS_PATH Ljava/lang/String; - "oshi.util.sys.path"
 field public,static,final OSHI_UTIL_DEV_PATH Ljava/lang/String; - "oshi.util.dev.path"
 field public,static,final OSHI_PSEUDO_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.pseudo.filesystem.types"
 field public,static,final OSHI_NETWORK_FILESYSTEM_TYPES Ljava/lang/String; - "oshi.network.filesystem.types"
 field public,static,final OSHI_OS_LINUX_ALLOWUDEV Ljava/lang/String; - "oshi.os.linux.allowudev"
 field public,static,final OSHI_OS_LINUX_PROCFS_LOGWARNING Ljava/lang/String; - "oshi.os.linux.procfs.logwarning"
 field public,static,final OSHI_OS_MAC_SYSCTL_LOGWARNING Ljava/lang/String; - "oshi.os.mac.sysctl.logwarning"
 field public,static,final OSHI_OS_WINDOWS_EVENTLOG Ljava/lang/String; - "oshi.os.windows.eventlog"
 field public,static,final OSHI_OS_WINDOWS_PROCSTATE_SUSPENDED Ljava/lang/String; - "oshi.os.windows.procstate.suspended"
 field public,static,final OSHI_OS_WINDOWS_COMMANDLINE_BATCH Ljava/lang/String; - "oshi.os.windows.commandline.batch"
 field public,static,final OSHI_OS_WINDOWS_HKEYPERFDATA Ljava/lang/String; - "oshi.os.windows.hkeyperfdata"
 field public,static,final OSHI_OS_WINDOWS_LEGACY_SYSTEM_COUNTERS Ljava/lang/String; - "oshi.os.windows.legacy.system.counters"
 field public,static,final OSHI_OS_WINDOWS_LOADAVERAGE Ljava/lang/String; - "oshi.os.windows.loadaverage"
 field public,static,final OSHI_OS_WINDOWS_CPU_UTILITY Ljava/lang/String; - "oshi.os.windows.cpu.utility"
 field public,static,final OSHI_OS_WINDOWS_PERFDISK_DIABLED Ljava/lang/String; - "oshi.os.windows.perfdisk.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFOS_DIABLED Ljava/lang/String; - "oshi.os.windows.perfos.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERFPROC_DIABLED Ljava/lang/String; - "oshi.os.windows.perfproc.disabled"
 field public,static,final OSHI_OS_WINDOWS_PERF_DISABLE_ALL_ON_FAILURE Ljava/lang/String; - "oshi.os.windows.perf.disable.all.on.failure"
 field public,static,final OSHI_OS_UNIX_WHOCOMMAND Ljava/lang/String; - "oshi.os.unix.whoCommand"
 field public,static,final OSHI_OS_SOLARIS_ALLOWKSTAT2 Ljava/lang/String; - "oshi.os.solaris.allowKstat2"
 method public,static get (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static get (Ljava/lang/String;I)I - -
 method public,static get (Ljava/lang/String;D)D - -
 method public,static get (Ljava/lang/String;Z)Z - -
 method public,static set (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public,static remove (Ljava/lang/String;)V - -
 method public,static clear ()V - -
 method public,static load (Ljava/util/Properties;)V - -
in 290
class oshi/util/GlobalConfig$PropertyException 52 public,super java/lang/RuntimeException - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 1183
class oshi/util/LsofUtil 52 public,final,super java/lang/Object - -
 method public,static getCwdMap (I)Ljava/util/Map; (I)Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>; -
 method public,static getCwd (I)Ljava/lang/String; - -
 method public,static getOpenFiles (I)J - -
in 1186
class oshi/util/Memoizer 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static defaultExpiration ()J - -
 method public,static memoize (Ljava/util/function/Supplier;J)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;J)Ljava/util/function/Supplier<TT;>; -
 method public,static memoize (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)Ljava/util/function/Supplier<TT;>; -
in 2
class oshi/util/Memoizer 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static installedAppsExpiration ()J - -
 method public,static defaultExpiration ()J - -
 method public,static memoize (Ljava/util/function/Supplier;J)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;J)Ljava/util/function/Supplier<TT;>; -
 method public,static memoize (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)Ljava/util/function/Supplier<TT;>; -
in 82
class oshi/util/ParseUtil 52 public,final,super java/lang/Object - -
 field public,static,final whitespacesColonWhitespace Ljava/util/regex/Pattern; -
 field public,static,final whitespaces Ljava/util/regex/Pattern; -
 field public,static,final notDigits Ljava/util/regex/Pattern; -
 field public,static,final startWithNotDigits Ljava/util/regex/Pattern; -
 field public,static,final slash Ljava/util/regex/Pattern; -
 method public,static parseHertz (Ljava/lang/String;)J - -
 method public,static parseLastInt (Ljava/lang/String;I)I - -
 method public,static parseLastLong (Ljava/lang/String;J)J - -
 method public,static parseLastDouble (Ljava/lang/String;D)D - -
 method public,static parseLastString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static byteArrayToHexString ([B)Ljava/lang/String; - -
 method public,static hexStringToByteArray (Ljava/lang/String;)[B - -
 method public,static asciiStringToByteArray (Ljava/lang/String;I)[B - -
 method public,static longToByteArray (JII)[B - -
 method public,static strToLong (Ljava/lang/String;I)J - -
 method public,static byteArrayToLong ([BI)J - -
 method public,static byteArrayToLong ([BIZ)J - -
 method public,static byteArrayToFloat ([BII)F - -
 method public,static unsignedIntToLong (I)J - -
 method public,static unsignedLongToSignedLong (J)J - -
 method public,static hexStringToString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseIntOrDefault (Ljava/lang/String;I)I - -
 method public,static parseLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUnsignedLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseDoubleOrDefault (Ljava/lang/String;D)D - -
 method public,static parseDHMSOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUuidOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getSingleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getDoubleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getStringBetween (Ljava/lang/String;C)Ljava/lang/String; - -
 method public,static getFirstIntValue (Ljava/lang/String;)I - -
 method public,static getNthIntValue (Ljava/lang/String;I)I - -
 method public,static removeMatchingString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseStringToLongArray (Ljava/lang/String;[IIC)[J - -
 method public,static countStringToLongArray (Ljava/lang/String;C)I - -
 method public,static getTextBetweenStrings (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filetimeToUtcMs (JZ)J - -
 method public,static parseMmDdYyyyToYyyyMmDD (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseCimDateTimeToOffset (Ljava/lang/String;)Ljava/time/OffsetDateTime; - -
 method public,static filePathStartsWith (Ljava/util/List;Ljava/lang/String;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Z -
 method public,static parseMultipliedToLongs (Ljava/lang/String;)J - -
 method public,static parseDecimalMemorySizeToBinary (Ljava/lang/String;)J - -
 method public,static parseDeviceIdToVendorProductSerial (Ljava/lang/String;)Loshi/util/tuples/Triplet; (Ljava/lang/String;)Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLshwResourceString (Ljava/lang/String;)J - -
 method public,static parseLspciMachineReadable (Ljava/lang/String;)Loshi/util/tuples/Pair; (Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLspciMemorySize (Ljava/lang/String;)J - -
 method public,static parseHyphenatedIntList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/Integer;>; -
 method public,static parseIntToIP (I)[B - -
 method public,static parseIntArrayToIP ([I)[B - -
 method public,static bigEndian16ToLittleEndian (I)I - -
 method public,static parseUtAddrV6toIP ([I)Ljava/lang/String; - -
 method public,static hexStringToInt (Ljava/lang/String;I)I - -
 method public,static hexStringToLong (Ljava/lang/String;J)J - -
 method public,static removeLeadingDots (Ljava/lang/String;)Ljava/lang/String; - -
in 36
class oshi/util/ParseUtil 52 public,final,super java/lang/Object - -
 field public,static,final whitespacesColonWhitespace Ljava/util/regex/Pattern; -
 field public,static,final whitespaces Ljava/util/regex/Pattern; -
 field public,static,final notDigits Ljava/util/regex/Pattern; -
 field public,static,final startWithNotDigits Ljava/util/regex/Pattern; -
 field public,static,final slash Ljava/util/regex/Pattern; -
 method public,static parseHertz (Ljava/lang/String;)J - -
 method public,static parseLastInt (Ljava/lang/String;I)I - -
 method public,static parseLastLong (Ljava/lang/String;J)J - -
 method public,static parseLastDouble (Ljava/lang/String;D)D - -
 method public,static parseLastString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static byteArrayToHexString ([B)Ljava/lang/String; - -
 method public,static hexStringToByteArray (Ljava/lang/String;)[B - -
 method public,static asciiStringToByteArray (Ljava/lang/String;I)[B - -
 method public,static longToByteArray (JII)[B - -
 method public,static strToLong (Ljava/lang/String;I)J - -
 method public,static byteArrayToLong ([BI)J - -
 method public,static byteArrayToLong ([BIZ)J - -
 method public,static byteArrayToFloat ([BII)F - -
 method public,static unsignedIntToLong (I)J - -
 method public,static unsignedLongToSignedLong (J)J - -
 method public,static hexStringToString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseIntOrDefault (Ljava/lang/String;I)I - -
 method public,static parseLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUnsignedLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseDoubleOrDefault (Ljava/lang/String;D)D - -
 method public,static parseDHMSOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUuidOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getSingleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getDoubleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getStringBetween (Ljava/lang/String;C)Ljava/lang/String; - -
 method public,static getFirstIntValue (Ljava/lang/String;)I - -
 method public,static getNthIntValue (Ljava/lang/String;I)I - -
 method public,static removeMatchingString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseStringToLongArray (Ljava/lang/String;[IIC)[J - -
 method public,static countStringToLongArray (Ljava/lang/String;C)I - -
 method public,static getTextBetweenStrings (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filetimeToUtcMs (JZ)J - -
 method public,static parseMmDdYyyyToYyyyMmDD (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseCimDateTimeToOffset (Ljava/lang/String;)Ljava/time/OffsetDateTime; - -
 method public,static filePathStartsWith (Ljava/util/List;Ljava/lang/String;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Z -
 method public,static parseMultipliedToLongs (Ljava/lang/String;)J - -
 method public,static parseDecimalMemorySizeToBinary (Ljava/lang/String;)J - -
 method public,static parseDeviceIdToVendorProductSerial (Ljava/lang/String;)Loshi/util/tuples/Triplet; (Ljava/lang/String;)Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLshwResourceString (Ljava/lang/String;)J - -
 method public,static parseLspciMachineReadable (Ljava/lang/String;)Loshi/util/tuples/Pair; (Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLspciMemorySize (Ljava/lang/String;)J - -
 method public,static parseHyphenatedIntList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/Integer;>; -
 method public,static parseIntToIP (I)[B - -
 method public,static parseIntArrayToIP ([I)[B - -
 method public,static bigEndian16ToLittleEndian (I)I - -
 method public,static parseUtAddrV6toIP ([I)Ljava/lang/String; - -
 method public,static hexStringToInt (Ljava/lang/String;I)I - -
 method public,static hexStringToLong (Ljava/lang/String;J)J - -
 method public,static removeLeadingDots (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseByteArrayToStrings ([B)Ljava/util/List; ([B)Ljava/util/List<Ljava/lang/String;>; -
 method public,static parseByteArrayToStringMap ([B)Ljava/util/Map; ([B)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseCharArrayToStringMap ([C)Ljava/util/Map; ([C)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static stringToEnumMap (Ljava/lang/Class;Ljava/lang/String;C)Ljava/util/Map; <K:Ljava/lang/Enum<TK;>;>(Ljava/lang/Class<TK;>;Ljava/lang/String;C)Ljava/util/Map<TK;Ljava/lang/String;>; -
in 33
class oshi/util/ParseUtil 52 public,final,super java/lang/Object - -
 field public,static,final whitespacesColonWhitespace Ljava/util/regex/Pattern; -
 field public,static,final whitespaces Ljava/util/regex/Pattern; -
 field public,static,final notDigits Ljava/util/regex/Pattern; -
 field public,static,final startWithNotDigits Ljava/util/regex/Pattern; -
 field public,static,final slash Ljava/util/regex/Pattern; -
 method public,static parseHertz (Ljava/lang/String;)J - -
 method public,static parseLastInt (Ljava/lang/String;I)I - -
 method public,static parseLastLong (Ljava/lang/String;J)J - -
 method public,static parseLastDouble (Ljava/lang/String;D)D - -
 method public,static parseLastString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static byteArrayToHexString ([B)Ljava/lang/String; - -
 method public,static hexStringToByteArray (Ljava/lang/String;)[B - -
 method public,static asciiStringToByteArray (Ljava/lang/String;I)[B - -
 method public,static longToByteArray (JII)[B - -
 method public,static strToLong (Ljava/lang/String;I)J - -
 method public,static byteArrayToLong ([BI)J - -
 method public,static byteArrayToLong ([BIZ)J - -
 method public,static byteArrayToFloat ([BII)F - -
 method public,static unsignedIntToLong (I)J - -
 method public,static unsignedLongToSignedLong (J)J - -
 method public,static hexStringToString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseIntOrDefault (Ljava/lang/String;I)I - -
 method public,static parseLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUnsignedLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseDoubleOrDefault (Ljava/lang/String;D)D - -
 method public,static parseDHMSOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUuidOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getSingleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getDoubleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getStringBetween (Ljava/lang/String;C)Ljava/lang/String; - -
 method public,static getFirstIntValue (Ljava/lang/String;)I - -
 method public,static getNthIntValue (Ljava/lang/String;I)I - -
 method public,static removeMatchingString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseStringToLongArray (Ljava/lang/String;[IIC)[J - -
 method public,static countStringToLongArray (Ljava/lang/String;C)I - -
 method public,static getTextBetweenStrings (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filetimeToUtcMs (JZ)J - -
 method public,static parseMmDdYyyyToYyyyMmDD (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseCimDateTimeToOffset (Ljava/lang/String;)Ljava/time/OffsetDateTime; - -
 method public,static filePathStartsWith (Ljava/util/List;Ljava/lang/String;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Z -
 method public,static parseMultipliedToLongs (Ljava/lang/String;)J - -
 method public,static parseDecimalMemorySizeToBinary (Ljava/lang/String;)J - -
 method public,static parseDeviceIdToVendorProductSerial (Ljava/lang/String;)Loshi/util/tuples/Triplet; (Ljava/lang/String;)Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLshwResourceString (Ljava/lang/String;)J - -
 method public,static parseLspciMachineReadable (Ljava/lang/String;)Loshi/util/tuples/Pair; (Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLspciMemorySize (Ljava/lang/String;)J - -
 method public,static parseHyphenatedIntList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/Integer;>; -
 method public,static parseIntToIP (I)[B - -
 method public,static parseIntArrayToIP ([I)[B - -
 method public,static bigEndian16ToLittleEndian (I)I - -
 method public,static parseUtAddrV6toIP ([I)Ljava/lang/String; - -
 method public,static hexStringToInt (Ljava/lang/String;I)I - -
 method public,static hexStringToLong (Ljava/lang/String;J)J - -
 method public,static removeLeadingDots (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseByteArrayToStrings ([B)Ljava/util/List; ([B)Ljava/util/List<Ljava/lang/String;>; -
 method public,static parseByteArrayToStringMap ([B)Ljava/util/Map; ([B)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseCharArrayToStringMap ([C)Ljava/util/Map; ([C)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static stringToEnumMap (Ljava/lang/Class;Ljava/lang/String;C)Ljava/util/Map; <K:Ljava/lang/Enum<TK;>;>(Ljava/lang/Class<TK;>;Ljava/lang/String;C)Ljava/util/Map<TK;Ljava/lang/String;>; -
 method public,static getValueOrUnknown (Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
in 2
class oshi/util/ParseUtil 52 public,final,super java/lang/Object - -
 field public,static,final whitespacesColonWhitespace Ljava/util/regex/Pattern; -
 field public,static,final whitespaces Ljava/util/regex/Pattern; -
 field public,static,final notDigits Ljava/util/regex/Pattern; -
 field public,static,final startWithNotDigits Ljava/util/regex/Pattern; -
 field public,static,final slash Ljava/util/regex/Pattern; -
 method public,static parseSpeed (Ljava/lang/String;)J - -
 method public,static parseHertz (Ljava/lang/String;)J - -
 method public,static parseLastInt (Ljava/lang/String;I)I - -
 method public,static parseLastLong (Ljava/lang/String;J)J - -
 method public,static parseLastDouble (Ljava/lang/String;D)D - -
 method public,static parseLastString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static byteArrayToHexString ([B)Ljava/lang/String; - -
 method public,static hexStringToByteArray (Ljava/lang/String;)[B - -
 method public,static asciiStringToByteArray (Ljava/lang/String;I)[B - -
 method public,static longToByteArray (JII)[B - -
 method public,static strToLong (Ljava/lang/String;I)J - -
 method public,static byteArrayToLong ([BI)J - -
 method public,static byteArrayToLong ([BIZ)J - -
 method public,static byteArrayToFloat ([BII)F - -
 method public,static unsignedIntToLong (I)J - -
 method public,static unsignedLongToSignedLong (J)J - -
 method public,static hexStringToString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseIntOrDefault (Ljava/lang/String;I)I - -
 method public,static parseLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUnsignedLongOrDefault (Ljava/lang/String;J)J - -
 method public,static parseDoubleOrDefault (Ljava/lang/String;D)D - -
 method public,static parseDHMSOrDefault (Ljava/lang/String;J)J - -
 method public,static parseUuidOrDefault (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getSingleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getDoubleQuoteStringValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getStringBetween (Ljava/lang/String;C)Ljava/lang/String; - -
 method public,static getFirstIntValue (Ljava/lang/String;)I - -
 method public,static getNthIntValue (Ljava/lang/String;I)I - -
 method public,static removeMatchingString (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseStringToLongArray (Ljava/lang/String;[IIC)[J - -
 method public,static countStringToLongArray (Ljava/lang/String;C)I - -
 method public,static getTextBetweenStrings (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filetimeToUtcMs (JZ)J - -
 method public,static parseMmDdYyyyToYyyyMmDD (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseCimDateTimeToOffset (Ljava/lang/String;)Ljava/time/OffsetDateTime; - -
 method public,static filePathStartsWith (Ljava/util/List;Ljava/lang/String;)Z (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Z -
 method public,static parseMultipliedToLongs (Ljava/lang/String;)J - -
 method public,static parseDecimalMemorySizeToBinary (Ljava/lang/String;)J - -
 method public,static parseDeviceIdToVendorProductSerial (Ljava/lang/String;)Loshi/util/tuples/Triplet; (Ljava/lang/String;)Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLshwResourceString (Ljava/lang/String;)J - -
 method public,static parseLspciMachineReadable (Ljava/lang/String;)Loshi/util/tuples/Pair; (Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseLspciMemorySize (Ljava/lang/String;)J - -
 method public,static parseHyphenatedIntList (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Ljava/lang/Integer;>; -
 method public,static parseIntToIP (I)[B - -
 method public,static parseIntArrayToIP ([I)[B - -
 method public,static bigEndian16ToLittleEndian (I)I - -
 method public,static parseUtAddrV6toIP ([I)Ljava/lang/String; - -
 method public,static hexStringToInt (Ljava/lang/String;I)I - -
 method public,static hexStringToLong (Ljava/lang/String;J)J - -
 method public,static removeLeadingDots (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseByteArrayToStrings ([B)Ljava/util/List; ([B)Ljava/util/List<Ljava/lang/String;>; -
 method public,static parseByteArrayToStringMap ([B)Ljava/util/Map; ([B)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static parseCharArrayToStringMap ([C)Ljava/util/Map; ([C)Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static stringToEnumMap (Ljava/lang/Class;Ljava/lang/String;C)Ljava/util/Map; <K:Ljava/lang/Enum<TK;>;>(Ljava/lang/Class<TK;>;Ljava/lang/String;C)Ljava/util/Map<TK;Ljava/lang/String;>; -
 method public,static getValueOrUnknown (Ljava/util/Map;Ljava/lang/String;)Ljava/lang/String; (Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;Ljava/lang/String;)Ljava/lang/String; -
 method public,static getValueOrUnknown (Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/String; (Ljava/util/Map<*Ljava/lang/String;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static getStringValueOrUnknown (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static parseDateToEpoch (Ljava/lang/String;Ljava/lang/String;)J - -
in 2
class oshi/util/ProcUtil 52 public,final,super java/lang/Object - -
 method public,static,varargs parseNestedStatistics (Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;[Ljava/lang/String;)Ljava/util/Map<Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Ljava/lang/Long;>;>; -
 method public,static parseStatistics (Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/Map; (Ljava/lang/String;Ljava/util/regex/Pattern;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Long;>; -
 method public,static parseStatistics (Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/Long;>; -
in 42
class oshi/util/UserGroupInfo 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getUser (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getGroupName (Ljava/lang/String;)Ljava/lang/String; - -
in 23
class oshi/util/UserGroupInfo 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static isElevated ()Z - -
 method public,static getUser (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getGroupName (Ljava/lang/String;)Ljava/lang/String; - -
in 1183
class oshi/util/Util 52 public,final,super java/lang/Object - -
 method public,static sleep (J)V - -
 method public,static wildcardMatch (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
 method public,static isBlankOrUnknown (Ljava/lang/String;)Z - -
in 42
class oshi/util/Util 52 public,final,super java/lang/Object - -
 method public,static sleep (J)V - -
 method public,static wildcardMatch (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
 method public,static isBlankOrUnknown (Ljava/lang/String;)Z - -
 method public,static freeMemory (Lcom/sun/jna/Pointer;)V - -
in 23
class oshi/util/Util 52 public,final,super java/lang/Object - -
 method public,static sleep (J)V - -
 method public,static wildcardMatch (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
 method public,static isBlankOrUnknown (Ljava/lang/String;)Z - -
 method public,static freeMemory (Lcom/sun/jna/Pointer;)V - -
 method public,static isSessionValid (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;)Z - -
in 28
class oshi/util/platform/linux/DevPath 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final DEV Ljava/lang/String; -
 field public,static,final DISK_BY_UUID Ljava/lang/String; -
 field public,static,final DM Ljava/lang/String; -
 field public,static,final LOOP Ljava/lang/String; -
 field public,static,final MAPPER Ljava/lang/String; -
 field public,static,final RAM Ljava/lang/String; -
in 82
class oshi/util/platform/linux/ProcPath 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final PROC Ljava/lang/String; -
 field public,static,final ASOUND Ljava/lang/String; -
 field public,static,final CPUINFO Ljava/lang/String; -
 field public,static,final DISKSTATS Ljava/lang/String; -
 field public,static,final MEMINFO Ljava/lang/String; -
 field public,static,final MOUNTS Ljava/lang/String; -
 field public,static,final NET Ljava/lang/String; -
 field public,static,final PID_CMDLINE Ljava/lang/String; -
 field public,static,final PID_CWD Ljava/lang/String; -
 field public,static,final PID_EXE Ljava/lang/String; -
 field public,static,final PID_FD Ljava/lang/String; -
 field public,static,final PID_IO Ljava/lang/String; -
 field public,static,final PID_STAT Ljava/lang/String; -
 field public,static,final PID_STATM Ljava/lang/String; -
 field public,static,final PID_STATUS Ljava/lang/String; -
 field public,static,final SELF_STAT Ljava/lang/String; -
 field public,static,final STAT Ljava/lang/String; -
 field public,static,final SYS_FS_FILE_NR Ljava/lang/String; -
 field public,static,final TASK_PATH Ljava/lang/String; -
 field public,static,final TASK_COMM Ljava/lang/String; -
 field public,static,final TASK_STATUS Ljava/lang/String; -
 field public,static,final TASK_STAT Ljava/lang/String; -
 field public,static,final UPTIME Ljava/lang/String; -
 field public,static,final VERSION Ljava/lang/String; -
 field public,static,final VMSTAT Ljava/lang/String; -
in 34
class oshi/util/platform/linux/ProcPath 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final PROC Ljava/lang/String; -
 field public,static,final ASOUND Ljava/lang/String; -
 field public,static,final CPUINFO Ljava/lang/String; -
 field public,static,final DISKSTATS Ljava/lang/String; -
 field public,static,final MEMINFO Ljava/lang/String; -
 field public,static,final MOUNTS Ljava/lang/String; -
 field public,static,final NET Ljava/lang/String; -
 field public,static,final PID_CMDLINE Ljava/lang/String; -
 field public,static,final PID_CWD Ljava/lang/String; -
 field public,static,final PID_EXE Ljava/lang/String; -
 field public,static,final PID_ENVIRON Ljava/lang/String; -
 field public,static,final PID_FD Ljava/lang/String; -
 field public,static,final PID_IO Ljava/lang/String; -
 field public,static,final PID_STAT Ljava/lang/String; -
 field public,static,final PID_STATM Ljava/lang/String; -
 field public,static,final PID_STATUS Ljava/lang/String; -
 field public,static,final SELF_STAT Ljava/lang/String; -
 field public,static,final STAT Ljava/lang/String; -
 field public,static,final SYS_FS_FILE_NR Ljava/lang/String; -
 field public,static,final TASK_PATH Ljava/lang/String; -
 field public,static,final TASK_COMM Ljava/lang/String; -
 field public,static,final TASK_STATUS Ljava/lang/String; -
 field public,static,final TASK_STAT Ljava/lang/String; -
 field public,static,final UPTIME Ljava/lang/String; -
 field public,static,final VERSION Ljava/lang/String; -
 field public,static,final VMSTAT Ljava/lang/String; -
in 42
class oshi/util/platform/linux/ProcPath 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final PROC Ljava/lang/String; -
 field public,static,final ASOUND Ljava/lang/String; -
 field public,static,final AUXV Ljava/lang/String; -
 field public,static,final CPUINFO Ljava/lang/String; -
 field public,static,final DISKSTATS Ljava/lang/String; -
 field public,static,final MEMINFO Ljava/lang/String; -
 field public,static,final MOUNTS Ljava/lang/String; -
 field public,static,final NET Ljava/lang/String; -
 field public,static,final PID_CMDLINE Ljava/lang/String; -
 field public,static,final PID_CWD Ljava/lang/String; -
 field public,static,final PID_EXE Ljava/lang/String; -
 field public,static,final PID_ENVIRON Ljava/lang/String; -
 field public,static,final PID_FD Ljava/lang/String; -
 field public,static,final PID_IO Ljava/lang/String; -
 field public,static,final PID_STAT Ljava/lang/String; -
 field public,static,final PID_STATM Ljava/lang/String; -
 field public,static,final PID_STATUS Ljava/lang/String; -
 field public,static,final SELF_STAT Ljava/lang/String; -
 field public,static,final STAT Ljava/lang/String; -
 field public,static,final SYS_FS_FILE_NR Ljava/lang/String; -
 field public,static,final TASK_PATH Ljava/lang/String; -
 field public,static,final TASK_COMM Ljava/lang/String; -
 field public,static,final TASK_STATUS Ljava/lang/String; -
 field public,static,final TASK_STAT Ljava/lang/String; -
 field public,static,final UPTIME Ljava/lang/String; -
 field public,static,final VERSION Ljava/lang/String; -
 field public,static,final VMSTAT Ljava/lang/String; -
in 33
class oshi/util/platform/linux/ProcPath 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final PROC Ljava/lang/String; -
 field public,static,final ASOUND Ljava/lang/String; -
 field public,static,final AUXV Ljava/lang/String; -
 field public,static,final CPUINFO Ljava/lang/String; -
 field public,static,final DISKSTATS Ljava/lang/String; -
 field public,static,final MEMINFO Ljava/lang/String; -
 field public,static,final MODEL Ljava/lang/String; -
 field public,static,final MOUNTS Ljava/lang/String; -
 field public,static,final NET Ljava/lang/String; -
 field public,static,final PID_CMDLINE Ljava/lang/String; -
 field public,static,final PID_CWD Ljava/lang/String; -
 field public,static,final PID_EXE Ljava/lang/String; -
 field public,static,final PID_ENVIRON Ljava/lang/String; -
 field public,static,final PID_FD Ljava/lang/String; -
 field public,static,final PID_IO Ljava/lang/String; -
 field public,static,final PID_STAT Ljava/lang/String; -
 field public,static,final PID_STATM Ljava/lang/String; -
 field public,static,final PID_STATUS Ljava/lang/String; -
 field public,static,final SELF_STAT Ljava/lang/String; -
 field public,static,final STAT Ljava/lang/String; -
 field public,static,final SYS_FS_FILE_NR Ljava/lang/String; -
 field public,static,final SYS_FS_FILE_MAX Ljava/lang/String; -
 field public,static,final TASK_PATH Ljava/lang/String; -
 field public,static,final TASK_COMM Ljava/lang/String; -
 field public,static,final TASK_STATUS Ljava/lang/String; -
 field public,static,final TASK_STAT Ljava/lang/String; -
 field public,static,final THREAD_SELF Ljava/lang/String; -
 field public,static,final UPTIME Ljava/lang/String; -
 field public,static,final VERSION Ljava/lang/String; -
 field public,static,final VMSTAT Ljava/lang/String; -
in 2
class oshi/util/platform/linux/ProcPath 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final PROC Ljava/lang/String; -
 field public,static,final ASOUND Ljava/lang/String; -
 field public,static,final AUXV Ljava/lang/String; -
 field public,static,final CPUINFO Ljava/lang/String; -
 field public,static,final DISKSTATS Ljava/lang/String; -
 field public,static,final MEMINFO Ljava/lang/String; -
 field public,static,final MODEL Ljava/lang/String; -
 field public,static,final MOUNTS Ljava/lang/String; -
 field public,static,final NET Ljava/lang/String; -
 field public,static,final PID_CMDLINE Ljava/lang/String; -
 field public,static,final PID_CWD Ljava/lang/String; -
 field public,static,final PID_EXE Ljava/lang/String; -
 field public,static,final PID_ENVIRON Ljava/lang/String; -
 field public,static,final PID_FD Ljava/lang/String; -
 field public,static,final PID_IO Ljava/lang/String; -
 field public,static,final PID_STAT Ljava/lang/String; -
 field public,static,final PID_STATM Ljava/lang/String; -
 field public,static,final PID_STATUS Ljava/lang/String; -
 field public,static,final SELF_STAT Ljava/lang/String; -
 field public,static,final SNMP Ljava/lang/String; -
 field public,static,final SNMP6 Ljava/lang/String; -
 field public,static,final STAT Ljava/lang/String; -
 field public,static,final SYS_FS_FILE_NR Ljava/lang/String; -
 field public,static,final SYS_FS_FILE_MAX Ljava/lang/String; -
 field public,static,final TASK_PATH Ljava/lang/String; -
 field public,static,final TASK_COMM Ljava/lang/String; -
 field public,static,final TASK_STATUS Ljava/lang/String; -
 field public,static,final TASK_STAT Ljava/lang/String; -
 field public,static,final THREAD_SELF Ljava/lang/String; -
 field public,static,final UPTIME Ljava/lang/String; -
 field public,static,final VERSION Ljava/lang/String; -
 field public,static,final VMSTAT Ljava/lang/String; -
in 28
class oshi/util/platform/linux/SysPath 52 public,final,super java/lang/Object - -
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field public,static,final SYS Ljava/lang/String; -
 field public,static,final CPU Ljava/lang/String; -
 field public,static,final DMI_ID Ljava/lang/String; -
 field public,static,final NET Ljava/lang/String; -
 field public,static,final MODEL Ljava/lang/String; -
 field public,static,final POWER_SUPPLY Ljava/lang/String; -
 field public,static,final HWMON Ljava/lang/String; -
 field public,static,final THERMAL Ljava/lang/String; -
in 290
class oshi/util/platform/mac/CFUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 method public,static cfPointerToString (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,static cfPointerToString (Lcom/sun/jna/Pointer;Z)Ljava/lang/String; - -
in 1183
class oshi/util/platform/mac/SmcUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IOConnect com/sun/jna/platform/mac/IOKit IOConnect public,static
 inner oshi/util/platform/mac/SmcUtil$SMCVal oshi/util/platform/mac/SmcUtil SMCVal public,static
 inner oshi/util/platform/mac/SmcUtil$SMCKeyData oshi/util/platform/mac/SmcUtil SMCKeyData public,static
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataKeyInfo oshi/util/platform/mac/SmcUtil SMCKeyDataKeyInfo public,static
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataPLimitData oshi/util/platform/mac/SmcUtil SMCKeyDataPLimitData public,static
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataVers oshi/util/platform/mac/SmcUtil SMCKeyDataVers public,static
 field public,static,final SMC_KEY_FAN_NUM Ljava/lang/String; - "FNum"
 field public,static,final SMC_KEY_FAN_SPEED Ljava/lang/String; - "F%dAc"
 field public,static,final SMC_KEY_CPU_TEMP Ljava/lang/String; - "TC0P"
 field public,static,final SMC_KEY_CPU_VOLTAGE Ljava/lang/String; - "VC0C"
 field public,static,final SMC_CMD_READ_BYTES B - I5
 field public,static,final SMC_CMD_READ_KEYINFO B - I9
 field public,static,final KERNEL_INDEX_SMC I - I2
 method public,static smcOpen ()Lcom/sun/jna/platform/mac/IOKit$IOConnect; - -
 method public,static smcClose (Lcom/sun/jna/platform/mac/IOKit$IOConnect;)I - -
 method public,static smcGetFloat (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Ljava/lang/String;)D - -
 method public,static smcGetLong (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Ljava/lang/String;)J - -
 method public,static smcGetKeyInfo (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Loshi/util/platform/mac/SmcUtil$SMCKeyData;Loshi/util/platform/mac/SmcUtil$SMCKeyData;)I - -
 method public,static smcReadKey (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Ljava/lang/String;Loshi/util/platform/mac/SmcUtil$SMCVal;)I - -
 method public,static smcCall (Lcom/sun/jna/platform/mac/IOKit$IOConnect;ILoshi/util/platform/mac/SmcUtil$SMCKeyData;Loshi/util/platform/mac/SmcUtil$SMCKeyData;)I - -
in 39
class oshi/util/platform/mac/SmcUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner com/sun/jna/platform/mac/IOKit$IOConnect com/sun/jna/platform/mac/IOKit IOConnect public,static
 inner oshi/jna/platform/mac/IOKit$SMCVal oshi/jna/platform/mac/IOKit SMCVal public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyData oshi/jna/platform/mac/IOKit SMCKeyData public,static
 inner oshi/jna/platform/mac/IOKit$SMCKeyDataKeyInfo oshi/jna/platform/mac/IOKit SMCKeyDataKeyInfo public,static
 inner oshi/jna/ByRef$CloseableNativeLongByReference oshi/jna/ByRef CloseableNativeLongByReference public,static
 field public,static,final SMC_KEY_FAN_NUM Ljava/lang/String; - "FNum"
 field public,static,final SMC_KEY_FAN_SPEED Ljava/lang/String; - "F%dAc"
 field public,static,final SMC_KEY_CPU_TEMP Ljava/lang/String; - "TC0P"
 field public,static,final SMC_KEY_CPU_VOLTAGE Ljava/lang/String; - "VC0C"
 field public,static,final SMC_CMD_READ_BYTES B - I5
 field public,static,final SMC_CMD_READ_KEYINFO B - I9
 field public,static,final KERNEL_INDEX_SMC I - I2
 method public,static smcOpen ()Lcom/sun/jna/platform/mac/IOKit$IOConnect; - -
 method public,static smcClose (Lcom/sun/jna/platform/mac/IOKit$IOConnect;)I - -
 method public,static smcGetFloat (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Ljava/lang/String;)D - -
 method public,static smcGetLong (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Ljava/lang/String;)J - -
 method public,static smcGetKeyInfo (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Loshi/jna/platform/mac/IOKit$SMCKeyData;Loshi/jna/platform/mac/IOKit$SMCKeyData;)I - -
 method public,static smcReadKey (Lcom/sun/jna/platform/mac/IOKit$IOConnect;Ljava/lang/String;Loshi/jna/platform/mac/IOKit$SMCVal;)I - -
 method public,static smcCall (Lcom/sun/jna/platform/mac/IOKit$IOConnect;ILoshi/jna/platform/mac/IOKit$SMCKeyData;Loshi/jna/platform/mac/IOKit$SMCKeyData;)I - -
in 1183
class oshi/util/platform/mac/SmcUtil$SMCKeyData 52 public,super com/sun/jna/Structure - -
 inner oshi/util/platform/mac/SmcUtil$SMCKeyData oshi/util/platform/mac/SmcUtil SMCKeyData public,static
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataVers oshi/util/platform/mac/SmcUtil SMCKeyDataVers public,static
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataPLimitData oshi/util/platform/mac/SmcUtil SMCKeyDataPLimitData public,static
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataKeyInfo oshi/util/platform/mac/SmcUtil SMCKeyDataKeyInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public key I -
 field public vers Loshi/util/platform/mac/SmcUtil$SMCKeyDataVers; -
 field public pLimitData Loshi/util/platform/mac/SmcUtil$SMCKeyDataPLimitData; -
 field public keyInfo Loshi/util/platform/mac/SmcUtil$SMCKeyDataKeyInfo; -
 field public result B -
 field public status B -
 field public data8 B -
 field public data32 I -
 field public bytes [B -
 method public <init> ()V - -
in 1183
class oshi/util/platform/mac/SmcUtil$SMCKeyDataKeyInfo 52 public,super com/sun/jna/Structure - -
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataKeyInfo oshi/util/platform/mac/SmcUtil SMCKeyDataKeyInfo public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public dataSize I -
 field public dataType I -
 field public dataAttributes B -
 method public <init> ()V - -
in 1183
class oshi/util/platform/mac/SmcUtil$SMCKeyDataPLimitData 52 public,super com/sun/jna/Structure - -
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataPLimitData oshi/util/platform/mac/SmcUtil SMCKeyDataPLimitData public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public version S -
 field public length S -
 field public cpuPLimit I -
 field public gpuPLimit I -
 field public memPLimit I -
 method public <init> ()V - -
in 1183
class oshi/util/platform/mac/SmcUtil$SMCKeyDataVers 52 public,super com/sun/jna/Structure - -
 inner oshi/util/platform/mac/SmcUtil$SMCKeyDataVers oshi/util/platform/mac/SmcUtil SMCKeyDataVers public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public major B -
 field public minor B -
 field public build B -
 field public reserved B -
 field public release S -
 method public <init> ()V - -
in 1183
class oshi/util/platform/mac/SmcUtil$SMCVal 52 public,super com/sun/jna/Structure - -
 inner oshi/util/platform/mac/SmcUtil$SMCVal oshi/util/platform/mac/SmcUtil SMCVal public,static
 inner com/sun/jna/Structure$FieldOrder com/sun/jna/Structure FieldOrder public,static,interface,abstract,annotation
 field public key [B -
 field public dataSize I -
 field public dataType [B -
 field public bytes [B -
 method public <init> ()V - -
in 82
class oshi/util/platform/mac/SysctlUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 34
class oshi/util/platform/mac/SysctlUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 42
class oshi/util/platform/mac/SysctlUtil 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 37
class oshi/util/platform/mac/SysctlUtil 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;IZ)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 28
class oshi/util/platform/mac/SysctlUtil 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;IZ)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 82
class oshi/util/platform/unix/freebsd/BsdSysctlUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 34
class oshi/util/platform/unix/freebsd/BsdSysctlUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 39
class oshi/util/platform/unix/freebsd/BsdSysctlUtil 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl (Ljava/lang/String;Lcom/sun/jna/Structure;)Z - -
 method public,static sysctl (Ljava/lang/String;)Lcom/sun/jna/Memory; - -
in 290
class oshi/util/platform/unix/freebsd/ProcstatUtil 52 public,final,super java/lang/Object - -
 method public,static getCwdMap (I)Ljava/util/Map; (I)Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>; -
 method public,static getCwd (I)Ljava/lang/String; - -
 method public,static getOpenFiles (I)J - -
in 290
class oshi/util/platform/unix/openbsd/FstatUtil 52 public,final,super java/lang/Object - -
 method public,static getCwd (I)Ljava/lang/String; - -
 method public,static getOpenFiles (I)J - -
in 82
class oshi/util/platform/unix/openbsd/OpenBsdSysctlUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 method public,static sysctl ([II)I - -
 method public,static sysctl ([IJ)J - -
 method public,static sysctl ([ILjava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl ([ILcom/sun/jna/Structure;)Z - -
 method public,static sysctl ([I)Lcom/sun/jna/Memory; - -
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 34
class oshi/util/platform/unix/openbsd/OpenBsdSysctlUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl ([II)I - -
 method public,static sysctl ([IJ)J - -
 method public,static sysctl ([ILjava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl ([ILcom/sun/jna/Structure;)Z - -
 method public,static sysctl ([I)Lcom/sun/jna/Memory; - -
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 39
class oshi/util/platform/unix/openbsd/OpenBsdSysctlUtil 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public,static sysctl ([II)I - -
 method public,static sysctl ([IJ)J - -
 method public,static sysctl ([ILjava/lang/String;)Ljava/lang/String; - -
 method public,static sysctl ([ILcom/sun/jna/Structure;)Z - -
 method public,static sysctl ([I)Lcom/sun/jna/Memory; - -
 method public,static sysctl (Ljava/lang/String;I)I - -
 method public,static sysctl (Ljava/lang/String;J)J - -
 method public,static sysctl (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
in 1183
class oshi/util/platform/unix/solaris/KstatUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatCtl com/sun/jna/platform/unix/solaris/LibKstat KstatCtl public,static
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed com/sun/jna/platform/unix/solaris/LibKstat KstatNamed public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed$UNION com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed UNION public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed$UNION$STR com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed$UNION STR public,static
 method public,static openChain ()Loshi/util/platform/unix/solaris/KstatUtil$KstatChain; - -
 method public,static dataLookupString (Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static dataLookupLong (Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;Ljava/lang/String;)J - -
in 39
class oshi/util/platform/unix/solaris/KstatUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatCtl com/sun/jna/platform/unix/solaris/LibKstat KstatCtl public,static
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed com/sun/jna/platform/unix/solaris/LibKstat KstatNamed public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed$UNION com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed UNION public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed$UNION$STR com/sun/jna/platform/unix/solaris/LibKstat$KstatNamed$UNION STR public,static
 inner com/sun/jna/platform/unix/solaris/Kstat2$Kstat2MatcherList com/sun/jna/platform/unix/solaris/Kstat2 Kstat2MatcherList public,static
 inner com/sun/jna/platform/unix/solaris/Kstat2$Kstat2Handle com/sun/jna/platform/unix/solaris/Kstat2 Kstat2Handle public,static
 inner com/sun/jna/platform/unix/solaris/Kstat2$Kstat2Map com/sun/jna/platform/unix/solaris/Kstat2 Kstat2Map public,static
 method public,static,synchronized openChain ()Loshi/util/platform/unix/solaris/KstatUtil$KstatChain; - -
 method public,static dataLookupString (Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static dataLookupLong (Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;Ljava/lang/String;)J - -
 method public,static,varargs queryKstat2 (Ljava/lang/String;[Ljava/lang/String;)[Ljava/lang/Object; - -
 method public,static,varargs queryKstat2List (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/List<[Ljava/lang/Object;>; -
in 1183
class oshi/util/platform/unix/solaris/KstatUtil$KstatChain 52 public,final,super java/lang/Object java/lang/AutoCloseable -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatCtl com/sun/jna/platform/unix/solaris/LibKstat KstatCtl public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 method public,static read (Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;)Z - -
 method public,static lookup (Ljava/lang/String;ILjava/lang/String;)Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat; - -
 method public,static lookupAll (Ljava/lang/String;ILjava/lang/String;)Ljava/util/List; (Ljava/lang/String;ILjava/lang/String;)Ljava/util/List<Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;>; -
 method public,static update ()I - -
 method public close ()V - -
in 39
class oshi/util/platform/unix/solaris/KstatUtil$KstatChain 52 public,final,super java/lang/Object java/lang/AutoCloseable -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatCtl com/sun/jna/platform/unix/solaris/LibKstat KstatCtl public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 method public read (Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;)Z - -
 method public lookup (Ljava/lang/String;ILjava/lang/String;)Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat; - -
 method public lookupAll (Ljava/lang/String;ILjava/lang/String;)Ljava/util/List; (Ljava/lang/String;ILjava/lang/String;)Ljava/util/List<Lcom/sun/jna/platform/unix/solaris/LibKstat$Kstat;>; -
 method public update ()I - -
 method public close ()V - -
in 1183
class oshi/util/platform/windows/PerfCounterQuery 52 public,final,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner com/sun/jna/platform/win32/WinNT$HRESULT com/sun/jna/platform/win32/WinNT HRESULT public,static
 inner com/sun/jna/platform/win32/PdhUtil$PdhException com/sun/jna/platform/win32/PdhUtil PdhException public,static,final
 inner java/util/concurrent/ConcurrentHashMap$KeySetView java/util/concurrent/ConcurrentHashMap KeySetView public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TOTAL_INSTANCE Ljava/lang/String; - "_Total"
 field public,static,final TOTAL_INSTANCES Ljava/lang/String; - "*_Total"
 field public,static,final NOT_TOTAL_INSTANCE Ljava/lang/String; - "^_Total"
 field public,static,final NOT_TOTAL_INSTANCES Ljava/lang/String; - "^*_Total"
 method public,static queryValues (Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map<TT;Ljava/lang/Long;>; -
 method public,static queryValuesFromPDH (Ljava/lang/Class;Ljava/lang/String;)Ljava/util/Map; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Ljava/util/Map<TT;Ljava/lang/Long;>; -
 method public,static queryValuesFromWMI (Ljava/lang/Class;Ljava/lang/String;)Ljava/util/Map; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Ljava/util/Map<TT;Ljava/lang/Long;>; -
 method public,static localizeIfNeeded (Ljava/lang/String;)Ljava/lang/String; - -
in 39
class oshi/util/platform/windows/PerfCounterQuery 52 public,final,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner com/sun/jna/platform/win32/WinNT$HRESULT com/sun/jna/platform/win32/WinNT HRESULT public,static
 inner com/sun/jna/platform/win32/PdhUtil$PdhException com/sun/jna/platform/win32/PdhUtil PdhException public,static,final
 inner java/util/concurrent/ConcurrentHashMap$KeySetView java/util/concurrent/ConcurrentHashMap KeySetView public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TOTAL_INSTANCE Ljava/lang/String; - "_Total"
 field public,static,final TOTAL_OR_IDLE_INSTANCES Ljava/lang/String; - "_Total|Idle"
 field public,static,final TOTAL_INSTANCES Ljava/lang/String; - "*_Total"
 field public,static,final NOT_TOTAL_INSTANCE Ljava/lang/String; - "^_Total"
 field public,static,final NOT_TOTAL_INSTANCES Ljava/lang/String; - "^*_Total"
 method public,static queryValues (Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map<TT;Ljava/lang/Long;>; -
 method public,static queryValuesFromPDH (Ljava/lang/Class;Ljava/lang/String;)Ljava/util/Map; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Ljava/util/Map<TT;Ljava/lang/Long;>; -
 method public,static queryValuesFromWMI (Ljava/lang/Class;Ljava/lang/String;)Ljava/util/Map; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Ljava/util/Map<TT;Ljava/lang/Long;>; -
 method public,static localizeIfNeeded (Ljava/lang/String;Z)Ljava/lang/String; - -
in 290
class oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty 52 public,interface,abstract java/lang/Object - -
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 method public,abstract getInstance ()Ljava/lang/String; - -
 method public,abstract getCounter ()Ljava/lang/String; - -
in 1183
class oshi/util/platform/windows/PerfCounterQueryHandler 52 public,final,super java/lang/Object java/lang/AutoCloseable -
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 method public <init> ()V - -
 method public addCounterToQuery (Loshi/util/platform/windows/PerfDataUtil$PerfCounter;)Z - -
 method public removeCounterFromQuery (Loshi/util/platform/windows/PerfDataUtil$PerfCounter;)Z - -
 method public removeAllCounters ()V - -
 method public updateQuery ()J - -
 method public queryCounter (Loshi/util/platform/windows/PerfDataUtil$PerfCounter;)J - -
 method public close ()V - -
in 39
class oshi/util/platform/windows/PerfCounterQueryHandler 52 public,final,super java/lang/Object java/lang/AutoCloseable -
 inner oshi/jna/ByRef$CloseableHANDLEByReference oshi/jna/ByRef CloseableHANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 method public <init> ()V - -
 method public addCounterToQuery (Loshi/util/platform/windows/PerfDataUtil$PerfCounter;)Z - -
 method public removeCounterFromQuery (Loshi/util/platform/windows/PerfDataUtil$PerfCounter;)Z - -
 method public removeAllCounters ()V - -
 method public updateQuery ()J - -
 method public queryCounter (Loshi/util/platform/windows/PerfDataUtil$PerfCounter;)J - -
 method public close ()V - -
in 368
class oshi/util/platform/windows/PerfCounterWildcardQuery 52 public,final,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 inner com/sun/jna/platform/win32/PdhUtil$PdhEnumObjectItems com/sun/jna/platform/win32/PdhUtil PdhEnumObjectItems public,static
 inner com/sun/jna/platform/win32/PdhUtil$PdhException com/sun/jna/platform/win32/PdhUtil PdhException public,static,final
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner java/util/concurrent/ConcurrentHashMap$KeySetView java/util/concurrent/ConcurrentHashMap KeySetView public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryInstancesAndValues (Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInstancesAndValuesFromPDH (Ljava/lang/Class;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInstancesAndValuesFromWMI (Ljava/lang/Class;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 60
class oshi/util/platform/windows/PerfCounterWildcardQuery 52 public,final,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 inner com/sun/jna/platform/win32/PdhUtil$PdhEnumObjectItems com/sun/jna/platform/win32/PdhUtil PdhEnumObjectItems public,static
 inner com/sun/jna/platform/win32/PdhUtil$PdhException com/sun/jna/platform/win32/PdhUtil PdhException public,static,final
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner java/util/concurrent/ConcurrentHashMap$KeySetView java/util/concurrent/ConcurrentHashMap KeySetView public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryInstancesAndValues (Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInstancesAndValues (Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInstancesAndValuesFromPDH (Ljava/lang/Class;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInstancesAndValuesFromPDH (Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInstancesAndValuesFromWMI (Ljava/lang/Class;Ljava/lang/String;)Loshi/util/tuples/Pair; <T:Ljava/lang/Enum<TT;>;>(Ljava/lang/Class<TT;>;Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<TT;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 290
class oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty 52 public,interface,abstract java/lang/Object - -
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 method public,abstract getCounter ()Ljava/lang/String; - -
in 1183
class oshi/util/platform/windows/PerfDataUtil 52 public,final,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 inner com/sun/jna/platform/win32/WinDef$LONGLONGByReference com/sun/jna/platform/win32/WinDef LONGLONGByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/WinDef$LONGLONG com/sun/jna/platform/win32/WinDef LONGLONG public,static
 inner com/sun/jna/platform/win32/BaseTSD$DWORD_PTR com/sun/jna/platform/win32/BaseTSD DWORD_PTR public,static
 inner com/sun/jna/platform/win32/Pdh$PDH_RAW_COUNTER com/sun/jna/platform/win32/Pdh PDH_RAW_COUNTER public,static
 inner com/sun/jna/platform/win32/WinDef$DWORDByReference com/sun/jna/platform/win32/WinDef DWORDByReference public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 method public,static createCounter (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Loshi/util/platform/windows/PerfDataUtil$PerfCounter; - -
 method public,static updateQueryTimestamp (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)J - -
 method public,static openQuery (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
 method public,static closeQuery (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
 method public,static queryCounter (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)J - -
 method public,static addCounter (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;Ljava/lang/String;Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
 method public,static removeCounter (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
in 39
class oshi/util/platform/windows/PerfDataUtil 52 public,final,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 inner oshi/jna/ByRef$CloseableLONGLONGByReference oshi/jna/ByRef CloseableLONGLONGByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLEByReference com/sun/jna/platform/win32/WinNT HANDLEByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/WinDef$LONGLONGByReference com/sun/jna/platform/win32/WinDef LONGLONGByReference public,static
 inner com/sun/jna/platform/win32/WinDef$LONGLONG com/sun/jna/platform/win32/WinDef LONGLONG public,static
 inner com/sun/jna/platform/win32/BaseTSD$DWORD_PTR com/sun/jna/platform/win32/BaseTSD DWORD_PTR public,static
 inner oshi/jna/Struct$CloseablePdhRawCounter oshi/jna/Struct CloseablePdhRawCounter public,static
 inner com/sun/jna/platform/win32/WinDef$DWORDByReference com/sun/jna/platform/win32/WinDef DWORDByReference public,static
 inner com/sun/jna/platform/win32/Pdh$PDH_RAW_COUNTER com/sun/jna/platform/win32/Pdh PDH_RAW_COUNTER public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 method public,static createCounter (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Loshi/util/platform/windows/PerfDataUtil$PerfCounter; - -
 method public,static updateQueryTimestamp (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)J - -
 method public,static openQuery (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
 method public,static closeQuery (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
 method public,static queryCounter (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)J - -
 method public,static querySecondCounter (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)J - -
 method public,static addCounter (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;Ljava/lang/String;Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
 method public,static removeCounter (Lcom/sun/jna/platform/win32/WinNT$HANDLEByReference;)Z - -
in 1183
class oshi/util/platform/windows/PerfDataUtil$PerfCounter 52 public,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getObject ()Ljava/lang/String; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
 method public getCounterPath ()Ljava/lang/String; - -
in 39
class oshi/util/platform/windows/PerfDataUtil$PerfCounter 52 public,super java/lang/Object - -
 inner oshi/util/platform/windows/PerfDataUtil$PerfCounter oshi/util/platform/windows/PerfDataUtil PerfCounter public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getObject ()Ljava/lang/String; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
 method public isBaseCounter ()Z - -
 method public getCounterPath ()Ljava/lang/String; - -
in 371
class oshi/util/platform/windows/WmiQueryHandler 52 public,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner com/sun/jna/platform/win32/WinNT$HRESULT com/sun/jna/platform/win32/WinNT HRESULT public,static
 inner com/sun/jna/platform/win32/WinNT$SECURITY_DESCRIPTOR com/sun/jna/platform/win32/WinNT SECURITY_DESCRIPTOR public,static
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 field protected wmiTimeout I -
 field protected,final failedWmiClassNames Ljava/util/Set; Ljava/util/Set<Ljava/lang/String;>;
 method public <init> ()V - -
 method public,static,synchronized createInstance ()Loshi/util/platform/windows/WmiQueryHandler; - -
 method public,static,synchronized setInstanceClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Loshi/util/platform/windows/WmiQueryHandler;>;)V -
 method public queryWMI (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery<TT;>;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>; -
 method public queryWMI (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery;Z)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery<TT;>;Z)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>; -
 method protected handleComException (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery;Lcom/sun/jna/platform/win32/COM/COMException;)V (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery<*>;Lcom/sun/jna/platform/win32/COM/COMException;)V -
 method public initCOM ()Z - -
 method protected initCOM (I)Z - -
 method public unInitCOM ()V - -
 method public getComThreading ()I - -
 method public switchComThreading ()I - -
 method public isSecurityInitialized ()Z - -
 method public getWmiTimeout ()I - -
 method public setWmiTimeout (I)V - -
in 23
class oshi/util/platform/windows/WmiQueryHandler 52 public,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner com/sun/jna/platform/win32/WinNT$HRESULT com/sun/jna/platform/win32/WinNT HRESULT public,static
 inner com/sun/jna/platform/win32/WinNT$SECURITY_DESCRIPTOR com/sun/jna/platform/win32/WinNT SECURITY_DESCRIPTOR public,static
 inner oshi/util/GlobalConfig$PropertyException oshi/util/GlobalConfig PropertyException public,static
 method protected <init> ()V - -
 method public,static,synchronized createInstance ()Loshi/util/platform/windows/WmiQueryHandler; - -
 method public,static,synchronized setInstanceClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Loshi/util/platform/windows/WmiQueryHandler;>;)V -
 method public queryWMI (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery<TT;>;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>; -
 method public queryWMI (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery;Z)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery<TT;>;Z)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>; -
 method protected handleComException (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery;Lcom/sun/jna/platform/win32/COM/COMException;)V (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery<*>;Lcom/sun/jna/platform/win32/COM/COMException;)V -
 method public initCOM ()Z - -
 method protected initCOM (I)Z - -
 method public unInitCOM ()V - -
 method public getComThreading ()I - -
 method public switchComThreading ()I - -
 method public isSecurityInitialized ()Z - -
 method public getWmiTimeout ()I - -
 method public setWmiTimeout (I)V - -
in 290
class oshi/util/platform/windows/WmiUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 field public,static,final OHM_NAMESPACE Ljava/lang/String; - "ROOT\\OpenHardwareMonitor"
 method public,static queryToString (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery;)Ljava/lang/String; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery<TT;>;)Ljava/lang/String; -
 method public,static getString (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)Ljava/lang/String; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)Ljava/lang/String; -
 method public,static getDateString (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)Ljava/lang/String; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)Ljava/lang/String; -
 method public,static getDateTime (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)Ljava/time/OffsetDateTime; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)Ljava/time/OffsetDateTime; -
 method public,static getRefString (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)Ljava/lang/String; <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)Ljava/lang/String; -
 method public,static getUint64 (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)J <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)J -
 method public,static getUint32 (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)I <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)I -
 method public,static getUint32asLong (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)J <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)J -
 method public,static getSint32 (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)I <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)I -
 method public,static getUint16 (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)I <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)I -
 method public,static getFloat (Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult;Ljava/lang/Enum;I)F <T:Ljava/lang/Enum<TT;>;>(Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<TT;>;TT;I)F -
in 290
class oshi/util/tuples/Pair 52 public,super java/lang/Object - <A:Ljava/lang/Object;B:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;)V (TA;TB;)V -
 method public,final getA ()Ljava/lang/Object; ()TA; -
 method public,final getB ()Ljava/lang/Object; ()TB; -
in 290
class oshi/util/tuples/Quartet 52 public,super java/lang/Object - <A:Ljava/lang/Object;B:Ljava/lang/Object;C:Ljava/lang/Object;D:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V (TA;TB;TC;TD;)V -
 method public,final getA ()Ljava/lang/Object; ()TA; -
 method public,final getB ()Ljava/lang/Object; ()TB; -
 method public,final getC ()Ljava/lang/Object; ()TC; -
 method public,final getD ()Ljava/lang/Object; ()TD; -
in 290
class oshi/util/tuples/Quintet 52 public,super java/lang/Object - <A:Ljava/lang/Object;B:Ljava/lang/Object;C:Ljava/lang/Object;D:Ljava/lang/Object;E:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V (TA;TB;TC;TD;TE;)V -
 method public,final getA ()Ljava/lang/Object; ()TA; -
 method public,final getB ()Ljava/lang/Object; ()TB; -
 method public,final getC ()Ljava/lang/Object; ()TC; -
 method public,final getD ()Ljava/lang/Object; ()TD; -
 method public,final getE ()Ljava/lang/Object; ()TE; -
in 290
class oshi/util/tuples/Triplet 52 public,super java/lang/Object - <A:Ljava/lang/Object;B:Ljava/lang/Object;C:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V (TA;TB;TC;)V -
 method public,final getA ()Ljava/lang/Object; ()TA; -
 method public,final getB ()Ljava/lang/Object; ()TB; -
 method public,final getC ()Ljava/lang/Object; ()TC; -
