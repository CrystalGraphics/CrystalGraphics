cg-stub-db 1
in 0
class scala/ref/PhantomReference 50 public,super java/lang/Object scala/ref/ReferenceWrapper <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/ref/ReferenceWrapper<TT;>;
 method public get ()Lscala/Option; ()Lscala/Option<TT;>; -
 method public apply ()Ljava/lang/Object; ()TT; -
 method public clear ()V - -
 method public enqueue ()Z - -
 method public isEnqueued ()Z - -
 method public self ()Ljava/lang/ref/Reference; ()Ljava/lang/ref/Reference<+TT;>; -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public apply$mcZ$sp ()Z - -
 method public apply$mcB$sp ()B - -
 method public apply$mcC$sp ()C - -
 method public apply$mcD$sp ()D - -
 method public apply$mcF$sp ()F - -
 method public apply$mcI$sp ()I - -
 method public apply$mcJ$sp ()J - -
 method public apply$mcS$sp ()S - -
 method public apply$mcV$sp ()V - -
 method public underlying ()Ljava/lang/ref/PhantomReference; ()Ljava/lang/ref/PhantomReference<+TT;>; -
 method public <init> (Ljava/lang/Object;Lscala/ref/ReferenceQueue;)V (TT;Lscala/ref/ReferenceQueue<TT;>;)V -
in 0
class scala/ref/PhantomReferenceWithWrapper 50 public,super java/lang/ref/PhantomReference scala/ref/ReferenceWithWrapper <T:Ljava/lang/Object;>Ljava/lang/ref/PhantomReference<TT;>;Lscala/ref/ReferenceWithWrapper<TT;>;
 method public wrapper ()Lscala/ref/PhantomReference; ()Lscala/ref/PhantomReference<TT;>; -
 method public <init> (Ljava/lang/Object;Lscala/ref/ReferenceQueue;Lscala/ref/PhantomReference;)V (TT;Lscala/ref/ReferenceQueue<TT;>;Lscala/ref/PhantomReference<TT;>;)V -
in 0
class scala/ref/Reference 50 public,interface,abstract java/lang/Object scala/Function0 <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/Function0<TT;>;
 method public,abstract apply ()Ljava/lang/Object; ()TT; -
 method public,abstract get ()Lscala/Option; ()Lscala/Option<TT;>; -
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract clear ()V - -
 method public,abstract enqueue ()Z - -
 method public,abstract isEnqueued ()Z - -
in 0
class scala/ref/Reference$class 50 public,super,abstract java/lang/Object - -
 method public,static toString (Lscala/ref/Reference;)Ljava/lang/String; - -
 method public,static $init$ (Lscala/ref/Reference;)V - -
in 0
class scala/ref/ReferenceQueue 50 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public underlying ()Ljava/lang/ref/ReferenceQueue; ()Ljava/lang/ref/ReferenceQueue<+TT;>; -
 method public toString ()Ljava/lang/String; - -
 method public Wrapper (Ljava/lang/ref/Reference;)Lscala/Option; (Ljava/lang/ref/Reference<*>;)Lscala/Option<Lscala/ref/Reference<TT;>;>; -
 method public poll ()Lscala/Option; ()Lscala/Option<Lscala/ref/Reference<TT;>;>; -
 method public remove ()Lscala/Option; ()Lscala/Option<Lscala/ref/Reference<TT;>;>; -
 method public remove (J)Lscala/Option; (J)Lscala/Option<Lscala/ref/Reference<TT;>;>; -
 method public <init> ()V ()V -
in 0
class scala/ref/ReferenceWithWrapper 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract wrapper ()Lscala/ref/ReferenceWrapper; ()Lscala/ref/ReferenceWrapper<TT;>; -
in 0
class scala/ref/ReferenceWrapper 50 public,interface,abstract java/lang/Object scala/ref/Reference,scala/Proxy <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/ref/Reference<TT;>;Lscala/Proxy;
 method public,abstract underlying ()Ljava/lang/ref/Reference; ()Ljava/lang/ref/Reference<+TT;>; -
 method public,abstract get ()Lscala/Option; ()Lscala/Option<TT;>; -
 method public,abstract apply ()Ljava/lang/Object; ()TT; -
 method public,abstract clear ()V - -
 method public,abstract enqueue ()Z - -
 method public,abstract isEnqueued ()Z - -
 method public,abstract self ()Ljava/lang/ref/Reference; ()Ljava/lang/ref/Reference<+TT;>; -
in 0
class scala/ref/ReferenceWrapper$class 50 public,super,abstract java/lang/Object - -
 method public,static get (Lscala/ref/ReferenceWrapper;)Lscala/Option; - -
 method public,static apply (Lscala/ref/ReferenceWrapper;)Ljava/lang/Object; - -
 method public,static clear (Lscala/ref/ReferenceWrapper;)V - -
 method public,static enqueue (Lscala/ref/ReferenceWrapper;)Z - -
 method public,static isEnqueued (Lscala/ref/ReferenceWrapper;)Z - -
 method public,static self (Lscala/ref/ReferenceWrapper;)Ljava/lang/ref/Reference; - -
 method public,static $init$ (Lscala/ref/ReferenceWrapper;)V - -
in 0
class scala/ref/SoftReference 50 public,super java/lang/Object scala/ref/ReferenceWrapper <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/ref/ReferenceWrapper<TT;>;
 method public get ()Lscala/Option; ()Lscala/Option<TT;>; -
 method public apply ()Ljava/lang/Object; ()TT; -
 method public clear ()V - -
 method public enqueue ()Z - -
 method public isEnqueued ()Z - -
 method public self ()Ljava/lang/ref/Reference; ()Ljava/lang/ref/Reference<+TT;>; -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public apply$mcZ$sp ()Z - -
 method public apply$mcB$sp ()B - -
 method public apply$mcC$sp ()C - -
 method public apply$mcD$sp ()D - -
 method public apply$mcF$sp ()F - -
 method public apply$mcI$sp ()I - -
 method public apply$mcJ$sp ()J - -
 method public apply$mcS$sp ()S - -
 method public apply$mcV$sp ()V - -
 method public underlying ()Ljava/lang/ref/SoftReference; ()Ljava/lang/ref/SoftReference<+TT;>; -
 method public <init> (Ljava/lang/Object;Lscala/ref/ReferenceQueue;)V (TT;Lscala/ref/ReferenceQueue<TT;>;)V -
 method public <init> (Ljava/lang/Object;)V (TT;)V -
in 0
class scala/ref/SoftReferenceWithWrapper 50 public,super java/lang/ref/SoftReference scala/ref/ReferenceWithWrapper <T:Ljava/lang/Object;>Ljava/lang/ref/SoftReference<TT;>;Lscala/ref/ReferenceWithWrapper<TT;>;
 method public wrapper ()Lscala/ref/SoftReference; ()Lscala/ref/SoftReference<TT;>; -
 method public <init> (Ljava/lang/Object;Lscala/ref/ReferenceQueue;Lscala/ref/SoftReference;)V (TT;Lscala/ref/ReferenceQueue<TT;>;Lscala/ref/SoftReference<TT;>;)V -
in 0
class scala/ref/WeakReference 50 public,super java/lang/Object scala/ref/ReferenceWrapper <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/ref/ReferenceWrapper<TT;>;
 method public,static unapply (Lscala/ref/WeakReference;)Lscala/Option; <T:Ljava/lang/Object;>(Lscala/ref/WeakReference<TT;>;)Lscala/Option<TT;>; -
 method public get ()Lscala/Option; ()Lscala/Option<TT;>; -
 method public apply ()Ljava/lang/Object; ()TT; -
 method public clear ()V - -
 method public enqueue ()Z - -
 method public isEnqueued ()Z - -
 method public self ()Ljava/lang/ref/Reference; ()Ljava/lang/ref/Reference<+TT;>; -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public apply$mcZ$sp ()Z - -
 method public apply$mcB$sp ()B - -
 method public apply$mcC$sp ()C - -
 method public apply$mcD$sp ()D - -
 method public apply$mcF$sp ()F - -
 method public apply$mcI$sp ()I - -
 method public apply$mcJ$sp ()J - -
 method public apply$mcS$sp ()S - -
 method public apply$mcV$sp ()V - -
 method public underlying ()Ljava/lang/ref/WeakReference; ()Ljava/lang/ref/WeakReference<+TT;>; -
 method public <init> (Ljava/lang/Object;Lscala/ref/ReferenceQueue;)V (TT;Lscala/ref/ReferenceQueue<TT;>;)V -
 method public <init> (Ljava/lang/Object;)V (TT;)V -
in 0
class scala/ref/WeakReference$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/ref/WeakReference$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/lang/Object;)Lscala/ref/WeakReference; <T:Ljava/lang/Object;>(TT;)Lscala/ref/WeakReference<TT;>; -
 method public unapply (Lscala/ref/WeakReference;)Lscala/Option; <T:Ljava/lang/Object;>(Lscala/ref/WeakReference<TT;>;)Lscala/Option<TT;>; -
in 0
class scala/ref/WeakReferenceWithWrapper 50 public,super java/lang/ref/WeakReference scala/ref/ReferenceWithWrapper <T:Ljava/lang/Object;>Ljava/lang/ref/WeakReference<TT;>;Lscala/ref/ReferenceWithWrapper<TT;>;
 method public wrapper ()Lscala/ref/WeakReference; ()Lscala/ref/WeakReference<TT;>; -
 method public <init> (Ljava/lang/Object;Lscala/ref/ReferenceQueue;Lscala/ref/WeakReference;)V (TT;Lscala/ref/ReferenceQueue<TT;>;Lscala/ref/WeakReference<TT;>;)V -
