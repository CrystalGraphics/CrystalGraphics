cg-stub-db 1
in 131
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public isGuiOpen ()Z - -
 method public isFilteringCraftable (Laqr;)Z - -
 method public isFilteringCraftable ()Z - -
 method public isFurnaceGuiOpen ()Z - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public setGuiOpen (Z)V - -
 method public setFilteringCraftable (Z)V - -
 method public setFurnaceGuiOpen (Z)V - -
 method public setFurnaceFilteringCraftable (Z)V - -
in 304
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 field protected blastingFurnaceGuiOpen Z -
 field protected blastingFurnaceFilteringCraftable Z -
 field protected smokerGuiOpen Z -
 field protected smokerFilteringCraftable Z -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public isGuiOpen ()Z - -
 method public isFilteringCraftable (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFilteringCraftable ()Z - -
 method public isFurnaceGuiOpen ()Z - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public isBlastingFurnaceGuiOpen ()Z - -
 method public isBlastingFurnaceFilteringCraftable ()Z - -
 method public isSmokerGuiOpen ()Z - -
 method public isSmokerFilteringCraftable ()Z - -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public setGuiOpen (Z)V - -
 method public setFilteringCraftable (Z)V - -
 method public setFurnaceGuiOpen (Z)V - -
 method public setFurnaceFilteringCraftable (Z)V - -
 method public setBlastingFurnaceGuiOpen (Z)V - -
 method public setBlastingFurnaceFilteringCraftable (Z)V - -
 method public setSmokerGuiOpen (Z)V - -
 method public setSmokerFilteringCraftable (Z)V - -
in 308
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 field protected blastingFurnaceGuiOpen Z -
 field protected blastingFurnaceFilteringCraftable Z -
 field protected smokerGuiOpen Z -
 field protected smokerFilteringCraftable Z -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isGuiOpen ()Z - -
 method public setGuiOpen (Z)V - -
 method public isFilteringCraftable (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFilteringCraftable ()Z - -
 method public setFilteringCraftable (Z)V - -
 method public isFurnaceGuiOpen ()Z - -
 method public setFurnaceGuiOpen (Z)V - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public setFurnaceFilteringCraftable (Z)V - -
 method public isBlastingFurnaceGuiOpen ()Z - -
 method public setBlastingFurnaceGuiOpen (Z)V - -
 method public isBlastingFurnaceFilteringCraftable ()Z - -
 method public setBlastingFurnaceFilteringCraftable (Z)V - -
 method public isSmokerGuiOpen ()Z - -
 method public setSmokerGuiOpen (Z)V - -
 method public isSmokerFilteringCraftable ()Z - -
 method public setSmokerFilteringCraftable (Z)V - -
in 115
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 field protected blastingFurnaceGuiOpen Z -
 field protected blastingFurnaceFilteringCraftable Z -
 field protected smokerGuiOpen Z -
 field protected smokerFilteringCraftable Z -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isGuiOpen ()Z - -
 method public setGuiOpen (Z)V - -
 method public isFilteringCraftable (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFilteringCraftable ()Z - -
 method public setFilteringCraftable (Z)V - -
 method public isFurnaceGuiOpen ()Z - -
 method public setFurnaceGuiOpen (Z)V - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public setFurnaceFilteringCraftable (Z)V - -
 method public isBlastingFurnaceGuiOpen ()Z - -
 method public setBlastingFurnaceGuiOpen (Z)V - -
 method public isBlastingFurnaceFilteringCraftable ()Z - -
 method public setBlastingFurnaceFilteringCraftable (Z)V - -
 method public isSmokerGuiOpen ()Z - -
 method public setSmokerGuiOpen (Z)V - -
 method public isSmokerFilteringCraftable ()Z - -
 method public setSmokerFilteringCraftable (Z)V - -
in 86
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 82
class net/minecraft/stats/RecipeBook 60 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 36
class net/minecraft/stats/RecipeBook 61 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 234
class net/minecraft/stats/RecipeBook 61 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 224
class net/minecraft/stats/RecipeBook 65 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 235
class net/minecraft/stats/RecipeBook 65 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<**>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 69
class net/minecraft/stats/RecipeBook 65 public,super java/lang/Object - -
 field protected,final bookSettings Lnet/minecraft/stats/RecipeBookSettings; -
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 135
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isGuiOpen ()Z - -
 method public setGuiOpen (Z)V - -
 method public isFilteringCraftable (Laqr;)Z - -
 method public isFilteringCraftable ()Z - -
 method public setFilteringCraftable (Z)V - -
 method public isFurnaceGuiOpen ()Z - -
 method public setFurnaceGuiOpen (Z)V - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public setFurnaceFilteringCraftable (Z)V - -
in 86
class net/minecraft/stats/RecipeBookSettings 52 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 104
class net/minecraft/stats/RecipeBookSettings 60 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 374
class net/minecraft/stats/RecipeBookSettings 61 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static addTagsForType (Lnet/minecraft/world/inventory/RecipeBookType;Ljava/lang/String;Ljava/lang/String;)V - -
in 206
class net/minecraft/stats/RecipeBookSettings 61 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 710
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 325
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 249
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P4 com/mojang/datafixers/Products P4 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 field public,static,final MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public getSettings (Lnet/minecraft/world/inventory/RecipeBookType;)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
in 192
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static addTagsForType (Lnet/minecraft/world/inventory/RecipeBookType;Ljava/lang/String;Ljava/lang/String;)V - -
in 250
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P5 com/mojang/datafixers/Products P5 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/RegistryFriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 field public,static,final MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public getSettings (Lnet/minecraft/world/inventory/RecipeBookType;)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
in 108
class net/minecraft/stats/RecipeBookSettings 60 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 113
class net/minecraft/stats/RecipeBookSettings 61 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 136
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 326
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 86
class net/minecraft/stats/RecipeBookSettings$TypeSettings 52 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 82
class net/minecraft/stats/RecipeBookSettings$TypeSettings 60 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 93
class net/minecraft/stats/RecipeBookSettings$TypeSettings 61 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 94
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 118
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 final,super java/lang/Record - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; -
 method public toString ()Ljava/lang/String; - -
 method public setOpen (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public setFiltering (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public open ()Z - -
 method public filtering ()Z - -
in 249
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 public,final,super java/lang/Record - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; -
 field public,static,final CRAFTING_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final BLAST_FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final SMOKER_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 method public <init> (ZZ)V - -
 method public toString ()Ljava/lang/String; - -
 method public setOpen (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public setFiltering (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public open ()Z - -
 method public filtering ()Z - -
in 250
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 public,final,super java/lang/Record - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; -
 field public,static,final CRAFTING_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final BLAST_FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final SMOKER_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 method public <init> (ZZ)V - -
 method public toString ()Ljava/lang/String; - -
 method public setOpen (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public setFiltering (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public,static codec (Ljava/lang/String;Ljava/lang/String;)Lcom/mojang/serialization/MapCodec; (Ljava/lang/String;Ljava/lang/String;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>; -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public open ()Z - -
 method public filtering ()Z - -
in 59
class net/minecraft/stats/ServerRecipeBook 52 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 method public <init> (Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 216
class net/minecraft/stats/ServerRecipeBook 52 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 86
class net/minecraft/stats/ServerRecipeBook 52 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 82
class net/minecraft/stats/ServerRecipeBook 60 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 36
class net/minecraft/stats/ServerRecipeBook 61 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 234
class net/minecraft/stats/ServerRecipeBook 61 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 94
class net/minecraft/stats/ServerRecipeBook 65 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 118
class net/minecraft/stats/ServerRecipeBook 65 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/stats/ServerRecipeBook$DisplayResolver net/minecraft/stats/ServerRecipeBook DisplayResolver public,static,interface,abstract
 inner net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket$Entry net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket Entry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 method public <init> (Lnet/minecraft/stats/ServerRecipeBook$DisplayResolver;)V - -
 method public add (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public contains (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)Z -
 method public remove (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public removeHighlight (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Predicate;)V (Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Predicate<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;)V -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public copyOverData (Lnet/minecraft/stats/ServerRecipeBook;)V - -
in 124
class net/minecraft/stats/ServerRecipeBook 65 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/stats/ServerRecipeBook$DisplayResolver net/minecraft/stats/ServerRecipeBook DisplayResolver public,static,interface,abstract
 inner net/minecraft/stats/ServerRecipeBook$Packed net/minecraft/stats/ServerRecipeBook Packed public,static,final
 inner net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket$Entry net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket Entry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 method public <init> (Lnet/minecraft/stats/ServerRecipeBook$DisplayResolver;)V - -
 method public add (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public contains (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)Z -
 method public remove (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public removeHighlight (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public copyOverData (Lnet/minecraft/stats/ServerRecipeBook;)V - -
 method public pack ()Lnet/minecraft/stats/ServerRecipeBook$Packed; - -
 method public loadUntrusted (Lnet/minecraft/stats/ServerRecipeBook$Packed;Ljava/util/function/Predicate;)V (Lnet/minecraft/stats/ServerRecipeBook$Packed;Ljava/util/function/Predicate<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;)V -
in 69
class net/minecraft/stats/ServerRecipeBook$DisplayResolver 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/stats/ServerRecipeBook$DisplayResolver net/minecraft/stats/ServerRecipeBook DisplayResolver public,static,interface,abstract
 method public,abstract displaysForRecipe (Lnet/minecraft/resources/ResourceKey;Ljava/util/function/Consumer;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Ljava/util/function/Consumer<Lnet/minecraft/world/item/crafting/display/RecipeDisplayEntry;>;)V -
in 124
class net/minecraft/stats/ServerRecipeBook$Packed 65 public,final,super java/lang/Record - -
 inner net/minecraft/stats/ServerRecipeBook$Packed net/minecraft/stats/ServerRecipeBook Packed public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P3 com/mojang/datafixers/Products P3 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/stats/ServerRecipeBook$Packed;>;
 method public <init> (Lnet/minecraft/stats/RecipeBookSettings;Ljava/util/List;Ljava/util/List;)V (Lnet/minecraft/stats/RecipeBookSettings;Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public settings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public known ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>; -
 method public highlight ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>; -
in 59
class net/minecraft/stats/ServerStatsCounter 52 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 92
class net/minecraft/stats/ServerStatsCounter 52 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 82
class net/minecraft/stats/ServerStatsCounter 60 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 93
class net/minecraft/stats/ServerStatsCounter 61 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 128
class net/minecraft/stats/ServerStatsCounter 65 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 167
class net/minecraft/stats/ServerStatsCounter 65 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 2
class net/minecraft/stats/ServerStatsCounter 65 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/nio/file/Path;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parse (Lcom/mojang/datafixers/DataFixer;Lcom/google/gson/JsonElement;)V - -
 method protected toJson ()Lcom/google/gson/JsonElement; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 131
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method public format (I)Ljava/lang/String; - -
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lwq;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lwq;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 304
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method public format (I)Ljava/lang/String; - -
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 471
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 82
class net/minecraft/stats/Stat 60 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 93
class net/minecraft/stats/Stat 61 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/minecraft/stats/Stat 65 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/RegistryFriendlyByteBuf;Lnet/minecraft/stats/Stat<*>;>;
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 135
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lwq;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lwq;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 92
class net/minecraft/stats/StatFormatter 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 82
class net/minecraft/stats/StatFormatter 60 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 93
class net/minecraft/stats/StatFormatter 61 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 60
class net/minecraft/stats/StatFormatter 65 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 131
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public b ()I - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public get (Ljava/lang/Object;Lwq;)Lnet/minecraft/stats/Stat; (TT;Lwq;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
in 304
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
in 463
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
in 181
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 104
class net/minecraft/stats/StatType 60 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 105
class net/minecraft/stats/StatType 61 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 711
class net/minecraft/stats/StatType 61 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 234
class net/minecraft/stats/StatType 61 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;Lnet/minecraft/network/chat/Component;)V (Lnet/minecraft/core/Registry<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 60
class net/minecraft/stats/StatType 65 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;Lnet/minecraft/network/chat/Component;)V (Lnet/minecraft/core/Registry<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public streamCodec ()Lnet/minecraft/network/codec/StreamCodec; ()Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/RegistryFriendlyByteBuf;Lnet/minecraft/stats/Stat<TT;>;>; -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 135
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lwq;)Lnet/minecraft/stats/Stat; (TT;Lwq;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public b ()I - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
in 395
class net/minecraft/stats/StatType 52 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
in 190
class net/minecraft/stats/StatType 52 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 108
class net/minecraft/stats/StatType 60 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 59
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SNEAK_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 method public,static a ()V - -
in 114
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SNEAK_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
in 115
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
in 86
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
in 82
class net/minecraft/stats/Stats 60 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 36
class net/minecraft/stats/Stats 61 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 234
class net/minecraft/stats/Stats 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 221
class net/minecraft/stats/Stats 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 125
class net/minecraft/stats/Stats 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HAPPY_GHAST_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 2
class net/minecraft/stats/Stats 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/Identifier;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/Identifier; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/Identifier; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/Identifier; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/Identifier; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/Identifier; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final HAPPY_GHAST_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final NAUTILUS_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final JUMP Lnet/minecraft/resources/Identifier; -
 field public,static,final DROP Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/Identifier; -
 field public,static,final DEATHS Lnet/minecraft/resources/Identifier; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/Identifier; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/Identifier; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/Identifier; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/Identifier; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/Identifier; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/Identifier; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/Identifier; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/Identifier; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/Identifier; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/Identifier; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/Identifier; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/Identifier; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/Identifier; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/Identifier; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/Identifier; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/Identifier; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/Identifier; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/Identifier; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/Identifier; -
 field public,static,final BELL_RING Lnet/minecraft/resources/Identifier; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/Identifier; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/Identifier; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/Identifier; -
 method public <init> ()V - -
in 456
class net/minecraft/stats/StatsCounter 52 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 469
class net/minecraft/stats/StatsCounter 52 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 82
class net/minecraft/stats/StatsCounter 60 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 93
class net/minecraft/stats/StatsCounter 61 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 60
class net/minecraft/stats/StatsCounter 65 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
