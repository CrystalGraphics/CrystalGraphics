cg-stub-db 1
in 90
class net/minecraft/stats/Achievement 50 public,super net/minecraft/stats/StatBase - -
 field public,final displayColumn I -
 field public,final displayRow I -
 field public,final parentAchievement Lnet/minecraft/stats/Achievement; -
 field public,final theItemStack Lnet/minecraft/item/ItemStack; -
 method public getDescription ()Ljava/lang/String; - -
 method public setStatStringFormatter (Lnet/minecraft/stats/IStatStringFormat;)Lnet/minecraft/stats/Achievement; - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;IILnet/minecraft/item/Item;Lnet/minecraft/stats/Achievement;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;IILnet/minecraft/block/Block;Lnet/minecraft/stats/Achievement;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;IILnet/minecraft/item/ItemStack;Lnet/minecraft/stats/Achievement;)V - -
 method public initIndependentStat ()Lnet/minecraft/stats/Achievement; - -
 method public setSpecial ()Lnet/minecraft/stats/Achievement; - -
 method public registerStat ()Lnet/minecraft/stats/Achievement; - -
 method public isAchievement ()Z - -
 method public getStatName ()Lnet/minecraft/util/IChatComponent; - -
 method public func_150953_b (Ljava/lang/Class;)Lnet/minecraft/stats/Achievement; (Ljava/lang/Class<+Lnet/minecraft/util/IJsonSerializable;>;)Lnet/minecraft/stats/Achievement; -
 method public getSpecial ()Z - -
in 91
class net/minecraft/stats/Achievement 50 public,super net/minecraft/stats/StatBase - -
 field public,final displayColumn I -
 field public,final displayRow I -
 field public,final parentAchievement Lnet/minecraft/stats/Achievement; -
 field public,final theItemStack Lnet/minecraft/item/ItemStack; -
 method public getDescription ()Ljava/lang/String; - -
 method public setStatStringFormatter (Lnet/minecraft/stats/IStatStringFormat;)Lnet/minecraft/stats/Achievement; - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;IILnet/minecraft/item/Item;Lnet/minecraft/stats/Achievement;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;IILnet/minecraft/block/Block;Lnet/minecraft/stats/Achievement;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;IILnet/minecraft/item/ItemStack;Lnet/minecraft/stats/Achievement;)V - -
 method public initIndependentStat ()Lnet/minecraft/stats/Achievement; - -
 method public setSpecial ()Lnet/minecraft/stats/Achievement; - -
 method public registerStat ()Lnet/minecraft/stats/Achievement; - -
 method public isAchievement ()Z - -
 method public getStatName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public setSerializableClazz (Ljava/lang/Class;)Lnet/minecraft/stats/Achievement; (Ljava/lang/Class<+Lnet/minecraft/util/IJsonSerializable;>;)Lnet/minecraft/stats/Achievement; -
 method public getSpecial ()Z - -
in 90
class net/minecraft/stats/AchievementList 50 public,super java/lang/Object - -
 field public,static minDisplayColumn I -
 field public,static minDisplayRow I -
 field public,static maxDisplayColumn I -
 field public,static maxDisplayRow I -
 field public,static achievementList Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/Achievement;>;
 field public,static openInventory Lnet/minecraft/stats/Achievement; -
 field public,static mineWood Lnet/minecraft/stats/Achievement; -
 field public,static buildWorkBench Lnet/minecraft/stats/Achievement; -
 field public,static buildPickaxe Lnet/minecraft/stats/Achievement; -
 field public,static buildFurnace Lnet/minecraft/stats/Achievement; -
 field public,static acquireIron Lnet/minecraft/stats/Achievement; -
 field public,static buildHoe Lnet/minecraft/stats/Achievement; -
 field public,static makeBread Lnet/minecraft/stats/Achievement; -
 field public,static bakeCake Lnet/minecraft/stats/Achievement; -
 field public,static buildBetterPickaxe Lnet/minecraft/stats/Achievement; -
 field public,static cookFish Lnet/minecraft/stats/Achievement; -
 field public,static onARail Lnet/minecraft/stats/Achievement; -
 field public,static buildSword Lnet/minecraft/stats/Achievement; -
 field public,static killEnemy Lnet/minecraft/stats/Achievement; -
 field public,static killCow Lnet/minecraft/stats/Achievement; -
 field public,static flyPig Lnet/minecraft/stats/Achievement; -
 field public,static snipeSkeleton Lnet/minecraft/stats/Achievement; -
 field public,static diamonds Lnet/minecraft/stats/Achievement; -
 field public,static diamondsToYou Lnet/minecraft/stats/Achievement; -
 field public,static portal Lnet/minecraft/stats/Achievement; -
 field public,static ghast Lnet/minecraft/stats/Achievement; -
 field public,static blazeRod Lnet/minecraft/stats/Achievement; -
 field public,static potion Lnet/minecraft/stats/Achievement; -
 field public,static theEnd Lnet/minecraft/stats/Achievement; -
 field public,static theEnd2 Lnet/minecraft/stats/Achievement; -
 field public,static enchantments Lnet/minecraft/stats/Achievement; -
 field public,static overkill Lnet/minecraft/stats/Achievement; -
 field public,static bookcase Lnet/minecraft/stats/Achievement; -
 field public,static breedCow Lnet/minecraft/stats/Achievement; -
 field public,static spawnWither Lnet/minecraft/stats/Achievement; -
 field public,static killWither Lnet/minecraft/stats/Achievement; -
 field public,static fullBeacon Lnet/minecraft/stats/Achievement; -
 field public,static exploreAllBiomes Lnet/minecraft/stats/Achievement; -
 field public,static overpowered Lnet/minecraft/stats/Achievement; -
 method public,static init ()V - -
in 91
class net/minecraft/stats/AchievementList 50 public,super java/lang/Object - -
 field public,static minDisplayColumn I -
 field public,static minDisplayRow I -
 field public,static maxDisplayColumn I -
 field public,static maxDisplayRow I -
 field public,static,final ACHIEVEMENTS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/Achievement;>;
 field public,static,final OPEN_INVENTORY Lnet/minecraft/stats/Achievement; -
 field public,static,final MINE_WOOD Lnet/minecraft/stats/Achievement; -
 field public,static,final BUILD_WORK_BENCH Lnet/minecraft/stats/Achievement; -
 field public,static,final BUILD_PICKAXE Lnet/minecraft/stats/Achievement; -
 field public,static,final BUILD_FURNACE Lnet/minecraft/stats/Achievement; -
 field public,static,final ACQUIRE_IRON Lnet/minecraft/stats/Achievement; -
 field public,static,final BUILD_HOE Lnet/minecraft/stats/Achievement; -
 field public,static,final MAKE_BREAD Lnet/minecraft/stats/Achievement; -
 field public,static,final BAKE_CAKE Lnet/minecraft/stats/Achievement; -
 field public,static,final BUILD_BETTER_PICKAXE Lnet/minecraft/stats/Achievement; -
 field public,static,final COOK_FISH Lnet/minecraft/stats/Achievement; -
 field public,static,final ON_A_RAIL Lnet/minecraft/stats/Achievement; -
 field public,static,final BUILD_SWORD Lnet/minecraft/stats/Achievement; -
 field public,static,final KILL_ENEMY Lnet/minecraft/stats/Achievement; -
 field public,static,final KILL_COW Lnet/minecraft/stats/Achievement; -
 field public,static,final FLY_PIG Lnet/minecraft/stats/Achievement; -
 field public,static,final SNIPE_SKELETON Lnet/minecraft/stats/Achievement; -
 field public,static,final DIAMONDS Lnet/minecraft/stats/Achievement; -
 field public,static,final DIAMONDS_TO_YOU Lnet/minecraft/stats/Achievement; -
 field public,static,final PORTAL Lnet/minecraft/stats/Achievement; -
 field public,static,final GHAST Lnet/minecraft/stats/Achievement; -
 field public,static,final BLAZE_ROD Lnet/minecraft/stats/Achievement; -
 field public,static,final POTION Lnet/minecraft/stats/Achievement; -
 field public,static,final THE_END Lnet/minecraft/stats/Achievement; -
 field public,static,final THE_END2 Lnet/minecraft/stats/Achievement; -
 field public,static,final ENCHANTMENTS Lnet/minecraft/stats/Achievement; -
 field public,static,final OVERKILL Lnet/minecraft/stats/Achievement; -
 field public,static,final BOOKCASE Lnet/minecraft/stats/Achievement; -
 field public,static,final BREED_COW Lnet/minecraft/stats/Achievement; -
 field public,static,final SPAWN_WITHER Lnet/minecraft/stats/Achievement; -
 field public,static,final KILL_WITHER Lnet/minecraft/stats/Achievement; -
 field public,static,final FULL_BEACON Lnet/minecraft/stats/Achievement; -
 field public,static,final EXPLORE_ALL_BIOMES Lnet/minecraft/stats/Achievement; -
 field public,static,final OVERPOWERED Lnet/minecraft/stats/Achievement; -
 method public,static init ()V - -
in 24
class net/minecraft/stats/IStatStringFormat 50 public,interface,abstract java/lang/Object - -
 method public,abstract formatString (Ljava/lang/String;)Ljava/lang/String; - -
in 24
class net/minecraft/stats/IStatType 50 public,interface,abstract java/lang/Object - -
 method public,abstract format (I)Ljava/lang/String; - -
in 326
class net/minecraft/stats/IStatType 52 public,interface,abstract java/lang/Object - -
 method public,abstract format (I)Ljava/lang/String; - -
in 90
class net/minecraft/stats/ObjectiveStat 50 public,super net/minecraft/scoreboard/ScoreDummyCriteria - -
 method public <init> (Lnet/minecraft/stats/StatBase;)V - -
in 138
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public isGuiOpen ()Z - -
 method public isFilteringCraftable (Laqr;)Z - -
 method public isFilteringCraftable ()Z - -
 method public isFurnaceGuiOpen ()Z - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public setGuiOpen (Z)V - -
 method public setFilteringCraftable (Z)V - -
 method public setFurnaceGuiOpen (Z)V - -
 method public setFurnaceFilteringCraftable (Z)V - -
in 312
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 field protected blastingFurnaceGuiOpen Z -
 field protected blastingFurnaceFilteringCraftable Z -
 field protected smokerGuiOpen Z -
 field protected smokerFilteringCraftable Z -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public isGuiOpen ()Z - -
 method public isFilteringCraftable (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFilteringCraftable ()Z - -
 method public isFurnaceGuiOpen ()Z - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public isBlastingFurnaceGuiOpen ()Z - -
 method public isBlastingFurnaceFilteringCraftable ()Z - -
 method public isSmokerGuiOpen ()Z - -
 method public isSmokerFilteringCraftable ()Z - -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public setGuiOpen (Z)V - -
 method public setFilteringCraftable (Z)V - -
 method public setFurnaceGuiOpen (Z)V - -
 method public setFurnaceFilteringCraftable (Z)V - -
 method public setBlastingFurnaceGuiOpen (Z)V - -
 method public setBlastingFurnaceFilteringCraftable (Z)V - -
 method public setSmokerGuiOpen (Z)V - -
 method public setSmokerFilteringCraftable (Z)V - -
in 316
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 field protected blastingFurnaceGuiOpen Z -
 field protected blastingFurnaceFilteringCraftable Z -
 field protected smokerGuiOpen Z -
 field protected smokerFilteringCraftable Z -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isGuiOpen ()Z - -
 method public setGuiOpen (Z)V - -
 method public isFilteringCraftable (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFilteringCraftable ()Z - -
 method public setFilteringCraftable (Z)V - -
 method public isFurnaceGuiOpen ()Z - -
 method public setFurnaceGuiOpen (Z)V - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public setFurnaceFilteringCraftable (Z)V - -
 method public isBlastingFurnaceGuiOpen ()Z - -
 method public setBlastingFurnaceGuiOpen (Z)V - -
 method public isBlastingFurnaceFilteringCraftable ()Z - -
 method public setBlastingFurnaceFilteringCraftable (Z)V - -
 method public isSmokerGuiOpen ()Z - -
 method public setSmokerGuiOpen (Z)V - -
 method public isSmokerFilteringCraftable ()Z - -
 method public setSmokerFilteringCraftable (Z)V - -
in 121
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 field protected blastingFurnaceGuiOpen Z -
 field protected blastingFurnaceFilteringCraftable Z -
 field protected smokerGuiOpen Z -
 field protected smokerFilteringCraftable Z -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isGuiOpen ()Z - -
 method public setGuiOpen (Z)V - -
 method public isFilteringCraftable (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFilteringCraftable ()Z - -
 method public setFilteringCraftable (Z)V - -
 method public isFurnaceGuiOpen ()Z - -
 method public setFurnaceGuiOpen (Z)V - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public setFurnaceFilteringCraftable (Z)V - -
 method public isBlastingFurnaceGuiOpen ()Z - -
 method public setBlastingFurnaceGuiOpen (Z)V - -
 method public isBlastingFurnaceFilteringCraftable ()Z - -
 method public setBlastingFurnaceFilteringCraftable (Z)V - -
 method public isSmokerGuiOpen ()Z - -
 method public setSmokerGuiOpen (Z)V - -
 method public isSmokerFilteringCraftable ()Z - -
 method public setSmokerFilteringCraftable (Z)V - -
in 92
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 86
class net/minecraft/stats/RecipeBook 60 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 38
class net/minecraft/stats/RecipeBook 61 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z (Lnet/minecraft/world/item/crafting/Recipe<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/world/item/crafting/Recipe<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 242
class net/minecraft/stats/RecipeBook 61 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 232
class net/minecraft/stats/RecipeBook 65 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<*>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 243
class net/minecraft/stats/RecipeBook 65 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public contains (Lnet/minecraft/resources/ResourceLocation;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)Z (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)Z -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method public addHighlight (Lnet/minecraft/world/item/crafting/RecipeHolder;)V (Lnet/minecraft/world/item/crafting/RecipeHolder<*>;)V -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookMenu;)Z (Lnet/minecraft/world/inventory/RecipeBookMenu<**>;)Z -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 72
class net/minecraft/stats/RecipeBook 65 public,super java/lang/Object - -
 field protected,final bookSettings Lnet/minecraft/stats/RecipeBookSettings; -
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public setBookSettings (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public getBookSettings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public setBookSetting (Lnet/minecraft/world/inventory/RecipeBookType;ZZ)V - -
in 142
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceLocation;>;
 field protected guiOpen Z -
 field protected filteringCraftable Z -
 field protected furnaceGuiOpen Z -
 field protected furnaceFilteringCraftable Z -
 method public <init> ()V - -
 method public copyOverData (Lnet/minecraft/stats/RecipeBook;)V - -
 method public add (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected add (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public contains (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public remove (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected remove (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public willHighlight (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public removeHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public addHighlight (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method protected addHighlight (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public isGuiOpen ()Z - -
 method public setGuiOpen (Z)V - -
 method public isFilteringCraftable (Laqr;)Z - -
 method public isFilteringCraftable ()Z - -
 method public setFilteringCraftable (Z)V - -
 method public isFurnaceGuiOpen ()Z - -
 method public setFurnaceGuiOpen (Z)V - -
 method public isFurnaceFilteringCraftable ()Z - -
 method public setFurnaceFilteringCraftable (Z)V - -
in 326
class net/minecraft/stats/RecipeBook 52 public,super java/lang/Object - -
 field protected,final recipes Ljava/util/BitSet; -
 field protected,final newRecipes Ljava/util/BitSet; -
 field protected isGuiOpen Z -
 field protected isFilteringCraftable Z -
 method public <init> ()V - -
 method public copyFrom (Lnet/minecraft/stats/RecipeBook;)V - -
 method public unlock (Lnet/minecraft/item/crafting/IRecipe;)V - -
 method public isUnlocked (Lnet/minecraft/item/crafting/IRecipe;)Z - -
 method public lock (Lnet/minecraft/item/crafting/IRecipe;)V - -
 method protected,static,deprecated getRecipeId (Lnet/minecraft/item/crafting/IRecipe;)I - -
 method public isNew (Lnet/minecraft/item/crafting/IRecipe;)Z - -
 method public markSeen (Lnet/minecraft/item/crafting/IRecipe;)V - -
 method public markNew (Lnet/minecraft/item/crafting/IRecipe;)V - -
 method public isGuiOpen ()Z - -
 method public setGuiOpen (Z)V - -
 method public isFilteringCraftable ()Z - -
 method public setFilteringCraftable (Z)V - -
in 326
class net/minecraft/stats/RecipeBookServer 52 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/play/server/SPacketRecipeBook$State net/minecraft/network/play/server/SPacketRecipeBook State public,static,final,enum
 method public <init> ()V - -
 method public add (Ljava/util/List;Lnet/minecraft/entity/player/EntityPlayerMP;)V (Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/entity/player/EntityPlayerMP;)V -
 method public remove (Ljava/util/List;Lnet/minecraft/entity/player/EntityPlayerMP;)V (Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>;Lnet/minecraft/entity/player/EntityPlayerMP;)V -
 method public write ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public read (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public init (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
in 92
class net/minecraft/stats/RecipeBookSettings 52 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 110
class net/minecraft/stats/RecipeBookSettings 60 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 390
class net/minecraft/stats/RecipeBookSettings 61 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static addTagsForType (Lnet/minecraft/world/inventory/RecipeBookType;Ljava/lang/String;Ljava/lang/String;)V - -
in 214
class net/minecraft/stats/RecipeBookSettings 61 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 741
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 335
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 257
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P4 com/mojang/datafixers/Products P4 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 field public,static,final MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public getSettings (Lnet/minecraft/world/inventory/RecipeBookType;)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
in 199
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public,static addTagsForType (Lnet/minecraft/world/inventory/RecipeBookType;Ljava/lang/String;Ljava/lang/String;)V - -
in 258
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P5 com/mojang/datafixers/Products P5 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/RegistryFriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 field public,static,final MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public getSettings (Lnet/minecraft/world/inventory/RecipeBookType;)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
in 114
class net/minecraft/stats/RecipeBookSettings 60 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 119
class net/minecraft/stats/RecipeBookSettings 61 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 143
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 336
class net/minecraft/stats/RecipeBookSettings 65 public,final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/stats/RecipeBookSettings;>;
 method public <init> ()V - -
 method public isOpen (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setOpen (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public isFiltering (Lnet/minecraft/world/inventory/RecipeBookType;)Z - -
 method public setFiltering (Lnet/minecraft/world/inventory/RecipeBookType;Z)V - -
 method public,static read (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/stats/RecipeBookSettings; - -
 method public write (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public replaceFrom (Lnet/minecraft/stats/RecipeBookSettings;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 92
class net/minecraft/stats/RecipeBookSettings$TypeSettings 52 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 86
class net/minecraft/stats/RecipeBookSettings$TypeSettings 60 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 99
class net/minecraft/stats/RecipeBookSettings$TypeSettings 61 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 100
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 final,super java/lang/Object - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ZZ)V - -
 method public copy ()Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 124
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 final,super java/lang/Record - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; -
 method public toString ()Ljava/lang/String; - -
 method public setOpen (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public setFiltering (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public open ()Z - -
 method public filtering ()Z - -
in 257
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 public,final,super java/lang/Record - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; -
 field public,static,final CRAFTING_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final BLAST_FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final SMOKER_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 method public <init> (ZZ)V - -
 method public toString ()Ljava/lang/String; - -
 method public setOpen (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public setFiltering (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public open ()Z - -
 method public filtering ()Z - -
in 258
class net/minecraft/stats/RecipeBookSettings$TypeSettings 65 public,final,super java/lang/Record - -
 inner net/minecraft/stats/RecipeBookSettings$TypeSettings net/minecraft/stats/RecipeBookSettings TypeSettings public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; -
 field public,static,final CRAFTING_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final BLAST_FURNACE_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final SMOKER_MAP_CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lio/netty/buffer/ByteBuf;Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>;
 method public <init> (ZZ)V - -
 method public toString ()Ljava/lang/String; - -
 method public setOpen (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public setFiltering (Z)Lnet/minecraft/stats/RecipeBookSettings$TypeSettings; - -
 method public,static codec (Ljava/lang/String;Ljava/lang/String;)Lcom/mojang/serialization/MapCodec; (Ljava/lang/String;Ljava/lang/String;)Lcom/mojang/serialization/MapCodec<Lnet/minecraft/stats/RecipeBookSettings$TypeSettings;>; -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public open ()Z - -
 method public filtering ()Z - -
in 209
class net/minecraft/stats/ServerRecipeBook 52 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 method public <init> (Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 224
class net/minecraft/stats/ServerRecipeBook 52 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 92
class net/minecraft/stats/ServerRecipeBook 52 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 86
class net/minecraft/stats/ServerRecipeBook 60 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 38
class net/minecraft/stats/ServerRecipeBook 61 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 242
class net/minecraft/stats/ServerRecipeBook 61 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 100
class net/minecraft/stats/ServerRecipeBook 65 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/network/protocol/game/ClientboundRecipePacket$State net/minecraft/network/protocol/game/ClientboundRecipePacket State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 method public <init> ()V - -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/item/crafting/RecipeManager;)V - -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 124
class net/minecraft/stats/ServerRecipeBook 65 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/stats/ServerRecipeBook$DisplayResolver net/minecraft/stats/ServerRecipeBook DisplayResolver public,static,interface,abstract
 inner net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket$Entry net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket Entry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 method public <init> (Lnet/minecraft/stats/ServerRecipeBook$DisplayResolver;)V - -
 method public add (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public contains (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)Z -
 method public remove (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public removeHighlight (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public toNbt ()Lnet/minecraft/nbt/CompoundTag; - -
 method public fromNbt (Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Predicate;)V (Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Predicate<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;)V -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public copyOverData (Lnet/minecraft/stats/ServerRecipeBook;)V - -
in 130
class net/minecraft/stats/ServerRecipeBook 65 public,super net/minecraft/stats/RecipeBook - -
 inner net/minecraft/stats/ServerRecipeBook$DisplayResolver net/minecraft/stats/ServerRecipeBook DisplayResolver public,static,interface,abstract
 inner net/minecraft/stats/ServerRecipeBook$Packed net/minecraft/stats/ServerRecipeBook Packed public,static,final
 inner net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket$Entry net/minecraft/network/protocol/game/ClientboundRecipeBookAddPacket Entry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final RECIPE_BOOK_TAG Ljava/lang/String; - "recipeBook"
 field protected,final known Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 field protected,final highlight Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;
 method public <init> (Lnet/minecraft/stats/ServerRecipeBook$DisplayResolver;)V - -
 method public add (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public contains (Lnet/minecraft/resources/ResourceKey;)Z (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)Z -
 method public remove (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public removeHighlight (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;)V -
 method public addRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public removeRecipes (Ljava/util/Collection;Lnet/minecraft/server/level/ServerPlayer;)I (Ljava/util/Collection<Lnet/minecraft/world/item/crafting/RecipeHolder<*>;>;Lnet/minecraft/server/level/ServerPlayer;)I -
 method public sendInitialRecipeBook (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public copyOverData (Lnet/minecraft/stats/ServerRecipeBook;)V - -
 method public pack ()Lnet/minecraft/stats/ServerRecipeBook$Packed; - -
 method public loadUntrusted (Lnet/minecraft/stats/ServerRecipeBook$Packed;Ljava/util/function/Predicate;)V (Lnet/minecraft/stats/ServerRecipeBook$Packed;Ljava/util/function/Predicate<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;)V -
in 72
class net/minecraft/stats/ServerRecipeBook$DisplayResolver 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/stats/ServerRecipeBook$DisplayResolver net/minecraft/stats/ServerRecipeBook DisplayResolver public,static,interface,abstract
 method public,abstract displaysForRecipe (Lnet/minecraft/resources/ResourceKey;Ljava/util/function/Consumer;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;Ljava/util/function/Consumer<Lnet/minecraft/world/item/crafting/display/RecipeDisplayEntry;>;)V -
in 130
class net/minecraft/stats/ServerRecipeBook$Packed 65 public,final,super java/lang/Record - -
 inner net/minecraft/stats/ServerRecipeBook$Packed net/minecraft/stats/ServerRecipeBook Packed public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P3 com/mojang/datafixers/Products P3 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/stats/ServerRecipeBook$Packed;>;
 method public <init> (Lnet/minecraft/stats/RecipeBookSettings;Ljava/util/List;Ljava/util/List;)V (Lnet/minecraft/stats/RecipeBookSettings;Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public settings ()Lnet/minecraft/stats/RecipeBookSettings; - -
 method public known ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>; -
 method public highlight ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/crafting/Recipe<*>;>;>; -
in 209
class net/minecraft/stats/ServerStatsCounter 52 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 98
class net/minecraft/stats/ServerStatsCounter 52 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 86
class net/minecraft/stats/ServerStatsCounter 60 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 99
class net/minecraft/stats/ServerStatsCounter 61 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 135
class net/minecraft/stats/ServerStatsCounter 65 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/objects/Object2IntMap$Entry it/unimi/dsi/fastutil/objects/Object2IntMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 174
class net/minecraft/stats/ServerStatsCounter 65 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parseLocal (Lcom/mojang/datafixers/DataFixer;Ljava/lang/String;)V - -
 method protected toJson ()Ljava/lang/String; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 3
class net/minecraft/stats/ServerStatsCounter 65 public,super net/minecraft/stats/StatsCounter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/nio/file/Path;)V - -
 method public save ()V - -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public parse (Lcom/mojang/datafixers/DataFixer;Lcom/google/gson/JsonElement;)V - -
 method protected toJson ()Lcom/google/gson/JsonElement; - -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/server/level/ServerPlayer;)V - -
in 138
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method public format (I)Ljava/lang/String; - -
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lwq;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lwq;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 312
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method public format (I)Ljava/lang/String; - -
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 501
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 86
class net/minecraft/stats/Stat 60 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 99
class net/minecraft/stats/Stat 61 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 62
class net/minecraft/stats/Stat 65 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STREAM_CODEC Lnet/minecraft/network/codec/StreamCodec; Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/RegistryFriendlyByteBuf;Lnet/minecraft/stats/Stat<*>;>;
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lnet/minecraft/stats/StatFormatter;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 142
class net/minecraft/stats/Stat 52 public,super net/minecraft/world/scores/criteria/ObjectiveCriteria - <T:Ljava/lang/Object;>Lnet/minecraft/world/scores/criteria/ObjectiveCriteria;
 method protected <init> (Lnet/minecraft/stats/StatType;Ljava/lang/Object;Lwq;)V (Lnet/minecraft/stats/StatType<TT;>;TT;Lwq;)V -
 method public,static buildName (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)Ljava/lang/String; -
 method public getType ()Lnet/minecraft/stats/StatType; ()Lnet/minecraft/stats/StatType<TT;>; -
 method public getValue ()Ljava/lang/Object; ()TT; -
 method public format (I)Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 90
class net/minecraft/stats/StatBase 50 public,super java/lang/Object - -
 inner net/minecraft/event/HoverEvent$Action net/minecraft/event/HoverEvent Action public,static,final,enum
 field public,final statId Ljava/lang/String; -
 field public isIndependent Z -
 field public,static simpleStatType Lnet/minecraft/stats/IStatType; -
 field public,static timeStatType Lnet/minecraft/stats/IStatType; -
 field public,static distanceStatType Lnet/minecraft/stats/IStatType; -
 field public,static field_111202_k Lnet/minecraft/stats/IStatType; -
 method public format (I)Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/IChatComponent;Lnet/minecraft/stats/IStatType;)V - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/IChatComponent;)V - -
 method public initIndependentStat ()Lnet/minecraft/stats/StatBase; - -
 method public registerStat ()Lnet/minecraft/stats/StatBase; - -
 method public isAchievement ()Z - -
 method public getStatName ()Lnet/minecraft/util/IChatComponent; - -
 method public createChatComponent ()Lnet/minecraft/util/IChatComponent; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public getCriteria ()Lnet/minecraft/scoreboard/IScoreObjectiveCriteria; - -
 method public func_150954_l ()Ljava/lang/Class; ()Ljava/lang/Class<+Lnet/minecraft/util/IJsonSerializable;>; -
 method public func_150953_b (Ljava/lang/Class;)Lnet/minecraft/stats/StatBase; (Ljava/lang/Class<+Lnet/minecraft/util/IJsonSerializable;>;)Lnet/minecraft/stats/StatBase; -
in 91
class net/minecraft/stats/StatBase 50 public,super java/lang/Object - -
 inner net/minecraft/util/text/event/HoverEvent$Action net/minecraft/util/text/event/HoverEvent Action public,static,final,enum
 field public,final statId Ljava/lang/String; -
 field public isIndependent Z -
 field public,static simpleStatType Lnet/minecraft/stats/IStatType; -
 field public,static timeStatType Lnet/minecraft/stats/IStatType; -
 field public,static distanceStatType Lnet/minecraft/stats/IStatType; -
 field public,static divideByTen Lnet/minecraft/stats/IStatType; -
 method public format (I)Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;Lnet/minecraft/stats/IStatType;)V - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;)V - -
 method public initIndependentStat ()Lnet/minecraft/stats/StatBase; - -
 method public registerStat ()Lnet/minecraft/stats/StatBase; - -
 method public isAchievement ()Z - -
 method public getStatName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public createChatComponent ()Lnet/minecraft/util/text/ITextComponent; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public getCriteria ()Lnet/minecraft/scoreboard/IScoreCriteria; - -
 method public getSerializableClazz ()Ljava/lang/Class; ()Ljava/lang/Class<+Lnet/minecraft/util/IJsonSerializable;>; -
 method public setSerializableClazz (Ljava/lang/Class;)Lnet/minecraft/stats/StatBase; (Ljava/lang/Class<+Lnet/minecraft/util/IJsonSerializable;>;)Lnet/minecraft/stats/StatBase; -
in 326
class net/minecraft/stats/StatBase 52 public,super java/lang/Object - -
 field public,final statId Ljava/lang/String; -
 field public isIndependent Z -
 field public,static simpleStatType Lnet/minecraft/stats/IStatType; -
 field public,static timeStatType Lnet/minecraft/stats/IStatType; -
 field public,static distanceStatType Lnet/minecraft/stats/IStatType; -
 field public,static divideByTen Lnet/minecraft/stats/IStatType; -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;Lnet/minecraft/stats/IStatType;)V - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;)V - -
 method public initIndependentStat ()Lnet/minecraft/stats/StatBase; - -
 method public registerStat ()Lnet/minecraft/stats/StatBase; - -
 method public format (I)Ljava/lang/String; - -
 method public getStatName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public getCriteria ()Lnet/minecraft/scoreboard/IScoreCriteria; - -
 method public getSerializableClazz ()Ljava/lang/Class; ()Ljava/lang/Class<+Lnet/minecraft/util/IJsonSerializable;>; -
in 90
class net/minecraft/stats/StatBasic 50 public,super net/minecraft/stats/StatBase - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/IChatComponent;Lnet/minecraft/stats/IStatType;)V - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/IChatComponent;)V - -
 method public registerStat ()Lnet/minecraft/stats/StatBase; - -
in 91
class net/minecraft/stats/StatBasic 50 public,super net/minecraft/stats/StatBase - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;Lnet/minecraft/stats/IStatType;)V - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;)V - -
 method public registerStat ()Lnet/minecraft/stats/StatBase; - -
in 326
class net/minecraft/stats/StatBasic 52 public,super net/minecraft/stats/StatBase - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;Lnet/minecraft/stats/IStatType;)V - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;)V - -
 method public registerStat ()Lnet/minecraft/stats/StatBase; - -
in 90
class net/minecraft/stats/StatCrafting 50 public,super net/minecraft/stats/StatBase - -
 method public func_150959_a ()Lnet/minecraft/item/Item; - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/util/IChatComponent;Lnet/minecraft/item/Item;)V - -
in 91
class net/minecraft/stats/StatCrafting 50 public,super net/minecraft/stats/StatBase - -
 method public getItem ()Lnet/minecraft/item/Item; - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;Lnet/minecraft/item/Item;)V - -
in 326
class net/minecraft/stats/StatCrafting 52 public,super net/minecraft/stats/StatBase - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/util/text/ITextComponent;Lnet/minecraft/item/Item;)V - -
 method public getItem ()Lnet/minecraft/item/Item; - -
in 90
class net/minecraft/stats/StatFileWriter 50 public,super java/lang/Object - -
 field protected,final statsData Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>;
 method public func_150874_c (Lnet/minecraft/stats/Achievement;)I - -
 method public <init> ()V - -
 method public hasAchievementUnlocked (Lnet/minecraft/stats/Achievement;)Z - -
 method public canUnlockAchievement (Lnet/minecraft/stats/Achievement;)Z - -
 method public increaseStat (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public unlockAchievement (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public readStat (Lnet/minecraft/stats/StatBase;)I - -
 method public func_150870_b (Lnet/minecraft/stats/StatBase;)Lnet/minecraft/util/IJsonSerializable; <T::Lnet/minecraft/util/IJsonSerializable;>(Lnet/minecraft/stats/StatBase;)TT; -
 method public func_150872_a (Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/IJsonSerializable;)Lnet/minecraft/util/IJsonSerializable; <T::Lnet/minecraft/util/IJsonSerializable;>(Lnet/minecraft/stats/StatBase;TT;)TT; -
in 98
class net/minecraft/stats/StatFormatter 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 86
class net/minecraft/stats/StatFormatter 60 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 99
class net/minecraft/stats/StatFormatter 61 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 62
class net/minecraft/stats/StatFormatter 65 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DIVIDE_BY_TEN Lnet/minecraft/stats/StatFormatter; -
 field public,static,final DISTANCE Lnet/minecraft/stats/StatFormatter; -
 field public,static,final TIME Lnet/minecraft/stats/StatFormatter; -
 method public,abstract format (I)Ljava/lang/String; - -
in 90
class net/minecraft/stats/StatList 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 field protected,static oneShotStats Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/stats/StatBase;>;
 field public,static allStats Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatBase;>;
 field public,static generalStats Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatBase;>;
 field public,static itemStats Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatCrafting;>;
 field public,static objectMineStats Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatCrafting;>;
 field public,static leaveGameStat Lnet/minecraft/stats/StatBase; -
 field public,static minutesPlayedStat Lnet/minecraft/stats/StatBase; -
 field public,static timeSinceDeathStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceWalkedStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceCrouchedStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceSprintedStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceSwumStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceFallenStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceClimbedStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceFlownStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceDoveStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceByMinecartStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceByBoatStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceByPigStat Lnet/minecraft/stats/StatBase; -
 field public,static distanceByHorseStat Lnet/minecraft/stats/StatBase; -
 field public,static jumpStat Lnet/minecraft/stats/StatBase; -
 field public,static dropStat Lnet/minecraft/stats/StatBase; -
 field public,static damageDealtStat Lnet/minecraft/stats/StatBase; -
 field public,static damageTakenStat Lnet/minecraft/stats/StatBase; -
 field public,static deathsStat Lnet/minecraft/stats/StatBase; -
 field public,static mobKillsStat Lnet/minecraft/stats/StatBase; -
 field public,static animalsBredStat Lnet/minecraft/stats/StatBase; -
 field public,static playerKillsStat Lnet/minecraft/stats/StatBase; -
 field public,static fishCaughtStat Lnet/minecraft/stats/StatBase; -
 field public,static junkFishedStat Lnet/minecraft/stats/StatBase; -
 field public,static treasureFishedStat Lnet/minecraft/stats/StatBase; -
 field public,static timesTalkedToVillagerStat Lnet/minecraft/stats/StatBase; -
 field public,static timesTradedWithVillagerStat Lnet/minecraft/stats/StatBase; -
 field public,static field_181724_H Lnet/minecraft/stats/StatBase; -
 field public,static field_181725_I Lnet/minecraft/stats/StatBase; -
 field public,static field_181726_J Lnet/minecraft/stats/StatBase; -
 field public,static field_181727_K Lnet/minecraft/stats/StatBase; -
 field public,static field_181728_L Lnet/minecraft/stats/StatBase; -
 field public,static field_181729_M Lnet/minecraft/stats/StatBase; -
 field public,static field_181730_N Lnet/minecraft/stats/StatBase; -
 field public,static field_181731_O Lnet/minecraft/stats/StatBase; -
 field public,static field_181732_P Lnet/minecraft/stats/StatBase; -
 field public,static field_181733_Q Lnet/minecraft/stats/StatBase; -
 field public,static field_181734_R Lnet/minecraft/stats/StatBase; -
 field public,static field_181735_S Lnet/minecraft/stats/StatBase; -
 field public,static field_181736_T Lnet/minecraft/stats/StatBase; -
 field public,static field_181737_U Lnet/minecraft/stats/StatBase; -
 field public,static field_181738_V Lnet/minecraft/stats/StatBase; -
 field public,static field_181739_W Lnet/minecraft/stats/StatBase; -
 field public,static field_181740_X Lnet/minecraft/stats/StatBase; -
 field public,static field_181741_Y Lnet/minecraft/stats/StatBase; -
 field public,static field_181742_Z Lnet/minecraft/stats/StatBase; -
 field public,static field_181723_aa Lnet/minecraft/stats/StatBase; -
 field public,static,final mineBlockStatArray [Lnet/minecraft/stats/StatBase; -
 field public,static,final objectCraftStats [Lnet/minecraft/stats/StatBase; -
 field public,static,final objectUseStats [Lnet/minecraft/stats/StatBase; -
 field public,static,final objectBreakStats [Lnet/minecraft/stats/StatBase; -
 method public <init> ()V - -
 method public,static init ()V - -
 method public,static getStatKillEntity (Lnet/minecraft/entity/EntityList$EntityEggInfo;)Lnet/minecraft/stats/StatBase; - -
 method public,static getStatEntityKilledBy (Lnet/minecraft/entity/EntityList$EntityEggInfo;)Lnet/minecraft/stats/StatBase; - -
 method public,static getOneShotStat (Ljava/lang/String;)Lnet/minecraft/stats/StatBase; - -
in 91
class net/minecraft/stats/StatList 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 field protected,static,final ID_TO_STAT_MAP Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/stats/StatBase;>;
 field public,static,final ALL_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatBase;>;
 field public,static,final BASIC_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatBase;>;
 field public,static,final USE_ITEM_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatCrafting;>;
 field public,static,final MINE_BLOCK_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatCrafting;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/stats/StatBase; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/stats/StatBase; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/stats/StatBase; -
 field public,static,final SNEAK_TIME Lnet/minecraft/stats/StatBase; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final DIVE_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final JUMP Lnet/minecraft/stats/StatBase; -
 field public,static,final DROP Lnet/minecraft/stats/StatBase; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/stats/StatBase; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/stats/StatBase; -
 field public,static,final DEATHS Lnet/minecraft/stats/StatBase; -
 field public,static,final MOB_KILLS Lnet/minecraft/stats/StatBase; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/stats/StatBase; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/stats/StatBase; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/stats/StatBase; -
 field public,static,final JUNK_FISHED Lnet/minecraft/stats/StatBase; -
 field public,static,final TREASURE_FISHED Lnet/minecraft/stats/StatBase; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/stats/StatBase; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/stats/StatBase; -
 field public,static,final CAKE_SLICES_EATEN Lnet/minecraft/stats/StatBase; -
 field public,static,final CAULDRON_FILLED Lnet/minecraft/stats/StatBase; -
 field public,static,final CAULDRON_USED Lnet/minecraft/stats/StatBase; -
 field public,static,final ARMOR_CLEANED Lnet/minecraft/stats/StatBase; -
 field public,static,final BANNER_CLEANED Lnet/minecraft/stats/StatBase; -
 field public,static,final BREWINGSTAND_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final BEACON_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final DROPPER_INSPECTED Lnet/minecraft/stats/StatBase; -
 field public,static,final HOPPER_INSPECTED Lnet/minecraft/stats/StatBase; -
 field public,static,final DISPENSER_INSPECTED Lnet/minecraft/stats/StatBase; -
 field public,static,final NOTEBLOCK_PLAYED Lnet/minecraft/stats/StatBase; -
 field public,static,final NOTEBLOCK_TUNED Lnet/minecraft/stats/StatBase; -
 field public,static,final FLOWER_POTTED Lnet/minecraft/stats/StatBase; -
 field public,static,final TRAPPED_CHEST_TRIGGERED Lnet/minecraft/stats/StatBase; -
 field public,static,final ENDERCHEST_OPENED Lnet/minecraft/stats/StatBase; -
 field public,static,final ITEM_ENCHANTED Lnet/minecraft/stats/StatBase; -
 field public,static,final RECORD_PLAYED Lnet/minecraft/stats/StatBase; -
 field public,static,final FURNACE_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final CRAFTING_TABLE_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final CHEST_OPENED Lnet/minecraft/stats/StatBase; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/stats/StatBase; -
 method public <init> ()V - -
 method public,static getBlockStats (Lnet/minecraft/block/Block;)Lnet/minecraft/stats/StatBase; - -
 method public,static getCraftStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getObjectUseStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getObjectBreakStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getObjectsPickedUpStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getDroppedObjectStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static init ()V - -
 method public,static getStatKillEntity (Lnet/minecraft/entity/EntityList$EntityEggInfo;)Lnet/minecraft/stats/StatBase; - -
 method public,static getStatEntityKilledBy (Lnet/minecraft/entity/EntityList$EntityEggInfo;)Lnet/minecraft/stats/StatBase; - -
 method public,static getOneShotStat (Ljava/lang/String;)Lnet/minecraft/stats/StatBase; - -
 method public,static,deprecated reinit ()V - -
in 326
class net/minecraft/stats/StatList 52 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 field protected,static,final ID_TO_STAT_MAP Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/stats/StatBase;>;
 field public,static,final ALL_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatBase;>;
 field public,static,final BASIC_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatBase;>;
 field public,static,final USE_ITEM_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatCrafting;>;
 field public,static,final MINE_BLOCK_STATS Ljava/util/List; Ljava/util/List<Lnet/minecraft/stats/StatCrafting;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/stats/StatBase; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/stats/StatBase; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/stats/StatBase; -
 field public,static,final SNEAK_TIME Lnet/minecraft/stats/StatBase; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final DIVE_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/stats/StatBase; -
 field public,static,final JUMP Lnet/minecraft/stats/StatBase; -
 field public,static,final DROP Lnet/minecraft/stats/StatBase; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/stats/StatBase; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/stats/StatBase; -
 field public,static,final DEATHS Lnet/minecraft/stats/StatBase; -
 field public,static,final MOB_KILLS Lnet/minecraft/stats/StatBase; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/stats/StatBase; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/stats/StatBase; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/stats/StatBase; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/stats/StatBase; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/stats/StatBase; -
 field public,static,final CAKE_SLICES_EATEN Lnet/minecraft/stats/StatBase; -
 field public,static,final CAULDRON_FILLED Lnet/minecraft/stats/StatBase; -
 field public,static,final CAULDRON_USED Lnet/minecraft/stats/StatBase; -
 field public,static,final ARMOR_CLEANED Lnet/minecraft/stats/StatBase; -
 field public,static,final BANNER_CLEANED Lnet/minecraft/stats/StatBase; -
 field public,static,final BREWINGSTAND_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final BEACON_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final DROPPER_INSPECTED Lnet/minecraft/stats/StatBase; -
 field public,static,final HOPPER_INSPECTED Lnet/minecraft/stats/StatBase; -
 field public,static,final DISPENSER_INSPECTED Lnet/minecraft/stats/StatBase; -
 field public,static,final NOTEBLOCK_PLAYED Lnet/minecraft/stats/StatBase; -
 field public,static,final NOTEBLOCK_TUNED Lnet/minecraft/stats/StatBase; -
 field public,static,final FLOWER_POTTED Lnet/minecraft/stats/StatBase; -
 field public,static,final TRAPPED_CHEST_TRIGGERED Lnet/minecraft/stats/StatBase; -
 field public,static,final ENDERCHEST_OPENED Lnet/minecraft/stats/StatBase; -
 field public,static,final ITEM_ENCHANTED Lnet/minecraft/stats/StatBase; -
 field public,static,final RECORD_PLAYED Lnet/minecraft/stats/StatBase; -
 field public,static,final FURNACE_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final CRAFTING_TABLE_INTERACTION Lnet/minecraft/stats/StatBase; -
 field public,static,final CHEST_OPENED Lnet/minecraft/stats/StatBase; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/stats/StatBase; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/stats/StatBase; -
 method public <init> ()V - -
 method public,static getBlockStats (Lnet/minecraft/block/Block;)Lnet/minecraft/stats/StatBase; - -
 method public,static getCraftStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getObjectUseStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getObjectBreakStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getObjectsPickedUpStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static getDroppedObjectStats (Lnet/minecraft/item/Item;)Lnet/minecraft/stats/StatBase; - -
 method public,static init ()V - -
 method public,static getStatKillEntity (Lnet/minecraft/entity/EntityList$EntityEggInfo;)Lnet/minecraft/stats/StatBase; - -
 method public,static getStatEntityKilledBy (Lnet/minecraft/entity/EntityList$EntityEggInfo;)Lnet/minecraft/stats/StatBase; - -
 method public,static getOneShotStat (Ljava/lang/String;)Lnet/minecraft/stats/StatBase; - -
 method public,static,deprecated reinit ()V - -
in 138
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public b ()I - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public get (Ljava/lang/Object;Lwq;)Lnet/minecraft/stats/Stat; (TT;Lwq;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
in 312
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
in 493
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
in 188
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 110
class net/minecraft/stats/StatType 60 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 111
class net/minecraft/stats/StatType 61 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 742
class net/minecraft/stats/StatType 61 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 242
class net/minecraft/stats/StatType 61 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;Lnet/minecraft/network/chat/Component;)V (Lnet/minecraft/core/Registry<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 62
class net/minecraft/stats/StatType 65 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;Lnet/minecraft/network/chat/Component;)V (Lnet/minecraft/core/Registry<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public streamCodec ()Lnet/minecraft/network/codec/StreamCodec; ()Lnet/minecraft/network/codec/StreamCodec<Lnet/minecraft/network/RegistryFriendlyByteBuf;Lnet/minecraft/stats/Stat<TT;>;>; -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 142
class net/minecraft/stats/StatType 52 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lwq;)Lnet/minecraft/stats/Stat; (TT;Lwq;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public b ()I - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
in 411
class net/minecraft/stats/StatType 52 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
in 197
class net/minecraft/stats/StatType 52 public,super net/minecraftforge/registries/ForgeRegistryEntry java/lang/Iterable <T:Ljava/lang/Object;>Lnet/minecraftforge/registries/ForgeRegistryEntry<Lnet/minecraft/stats/StatType<*>;>;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 114
class net/minecraft/stats/StatType 60 public,super java/lang/Object java/lang/Iterable <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/stats/Stat<TT;>;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<TT;>;)V -
 method public contains (Ljava/lang/Object;)Z (TT;)Z -
 method public get (Ljava/lang/Object;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat; (TT;Lnet/minecraft/stats/StatFormatter;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getRegistry ()Lnet/minecraft/core/Registry; ()Lnet/minecraft/core/Registry<TT;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/stats/Stat<TT;>;>; -
 method public get (Ljava/lang/Object;)Lnet/minecraft/stats/Stat; (TT;)Lnet/minecraft/stats/Stat<TT;>; -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/network/chat/Component; - -
in 90
class net/minecraft/stats/StatisticsFile 50 public,super net/minecraft/stats/StatFileWriter - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public readStatFile ()V - -
 method public saveStatFile ()V - -
 method public unlockAchievement (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public func_150878_c ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/stats/StatBase;>; -
 method public parseJson (Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>; -
 method public,static dumpJson (Ljava/util/Map;)Ljava/lang/String; (Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>;)Ljava/lang/String; -
 method public func_150877_d ()V - -
 method public func_150876_a (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public sendAchievements (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public func_150879_e ()Z - -
in 91
class net/minecraft/stats/StatisticsManager 50 public,super java/lang/Object - -
 field protected,final statsData Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>;
 method public countRequirementsUntilAvailable (Lnet/minecraft/stats/Achievement;)I - -
 method public <init> ()V - -
 method public hasAchievementUnlocked (Lnet/minecraft/stats/Achievement;)Z - -
 method public canUnlockAchievement (Lnet/minecraft/stats/Achievement;)Z - -
 method public increaseStat (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public unlockAchievement (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public readStat (Lnet/minecraft/stats/StatBase;)I - -
 method public getProgress (Lnet/minecraft/stats/StatBase;)Lnet/minecraft/util/IJsonSerializable; <T::Lnet/minecraft/util/IJsonSerializable;>(Lnet/minecraft/stats/StatBase;)TT; -
 method public setProgress (Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/IJsonSerializable;)Lnet/minecraft/util/IJsonSerializable; <T::Lnet/minecraft/util/IJsonSerializable;>(Lnet/minecraft/stats/StatBase;TT;)TT; -
in 326
class net/minecraft/stats/StatisticsManager 52 public,super java/lang/Object - -
 field protected,final statsData Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>;
 method public <init> ()V - -
 method public increaseStat (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public unlockAchievement (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public readStat (Lnet/minecraft/stats/StatBase;)I - -
in 91
class net/minecraft/stats/StatisticsManagerServer 50 public,super net/minecraft/stats/StatisticsManager - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public readStatFile ()V - -
 method public saveStatFile ()V - -
 method public unlockAchievement (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public getDirty ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/stats/StatBase;>; -
 method public parseJson (Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>; -
 method public,static dumpJson (Ljava/util/Map;)Ljava/lang/String; (Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>;)Ljava/lang/String; -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public sendAchievements (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public hasUnsentAchievement ()Z - -
in 326
class net/minecraft/stats/StatisticsManagerServer 52 public,super net/minecraft/stats/StatisticsManager - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ljava/io/File;)V - -
 method public readStatFile ()V - -
 method public saveStatFile ()V - -
 method public unlockAchievement (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/stats/StatBase;I)V - -
 method public parseJson (Ljava/lang/String;)Ljava/util/Map; (Ljava/lang/String;)Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>; -
 method public,static dumpJson (Ljava/util/Map;)Ljava/lang/String; (Ljava/util/Map<Lnet/minecraft/stats/StatBase;Lnet/minecraft/util/TupleIntJsonSerializable;>;)Ljava/lang/String; -
 method public markAllDirty ()V - -
 method public sendStats (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
in 209
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SNEAK_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 method public,static a ()V - -
in 120
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SNEAK_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
in 121
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
in 92
class net/minecraft/stats/Stats 52 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_ONE_MINUTE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
in 86
class net/minecraft/stats/Stats 60 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 38
class net/minecraft/stats/Stats 61 public,super java/lang/Object - -
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 242
class net/minecraft/stats/Stats 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 229
class net/minecraft/stats/Stats 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 131
class net/minecraft/stats/Stats 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/ResourceLocation;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HAPPY_GHAST_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final JUMP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DROP Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final DEATHS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final BELL_RING Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/ResourceLocation; -
 method public <init> ()V - -
in 3
class net/minecraft/stats/Stats 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BLOCK_MINED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ITEM_CRAFTED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_USED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_BROKEN Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_PICKED_UP Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ITEM_DROPPED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/item/Item;>;
 field public,static,final ENTITY_KILLED Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final ENTITY_KILLED_BY Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/world/entity/EntityType<*>;>;
 field public,static,final CUSTOM Lnet/minecraft/stats/StatType; Lnet/minecraft/stats/StatType<Lnet/minecraft/resources/Identifier;>;
 field public,static,final LEAVE_GAME Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAY_TIME Lnet/minecraft/resources/Identifier; -
 field public,static,final TOTAL_WORLD_TIME Lnet/minecraft/resources/Identifier; -
 field public,static,final TIME_SINCE_DEATH Lnet/minecraft/resources/Identifier; -
 field public,static,final TIME_SINCE_REST Lnet/minecraft/resources/Identifier; -
 field public,static,final CROUCH_TIME Lnet/minecraft/resources/Identifier; -
 field public,static,final WALK_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final CROUCH_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final SPRINT_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final WALK_ON_WATER_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final FALL_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final CLIMB_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final FLY_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final WALK_UNDER_WATER_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final MINECART_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final BOAT_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final PIG_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final HAPPY_GHAST_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final HORSE_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final AVIATE_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final SWIM_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final STRIDER_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final NAUTILUS_ONE_CM Lnet/minecraft/resources/Identifier; -
 field public,static,final JUMP Lnet/minecraft/resources/Identifier; -
 field public,static,final DROP Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_DEALT Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_DEALT_ABSORBED Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_DEALT_RESISTED Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_TAKEN Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_BLOCKED_BY_SHIELD Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_ABSORBED Lnet/minecraft/resources/Identifier; -
 field public,static,final DAMAGE_RESISTED Lnet/minecraft/resources/Identifier; -
 field public,static,final DEATHS Lnet/minecraft/resources/Identifier; -
 field public,static,final MOB_KILLS Lnet/minecraft/resources/Identifier; -
 field public,static,final ANIMALS_BRED Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAYER_KILLS Lnet/minecraft/resources/Identifier; -
 field public,static,final FISH_CAUGHT Lnet/minecraft/resources/Identifier; -
 field public,static,final TALKED_TO_VILLAGER Lnet/minecraft/resources/Identifier; -
 field public,static,final TRADED_WITH_VILLAGER Lnet/minecraft/resources/Identifier; -
 field public,static,final EAT_CAKE_SLICE Lnet/minecraft/resources/Identifier; -
 field public,static,final FILL_CAULDRON Lnet/minecraft/resources/Identifier; -
 field public,static,final USE_CAULDRON Lnet/minecraft/resources/Identifier; -
 field public,static,final CLEAN_ARMOR Lnet/minecraft/resources/Identifier; -
 field public,static,final CLEAN_BANNER Lnet/minecraft/resources/Identifier; -
 field public,static,final CLEAN_SHULKER_BOX Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_BREWINGSTAND Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_BEACON Lnet/minecraft/resources/Identifier; -
 field public,static,final INSPECT_DROPPER Lnet/minecraft/resources/Identifier; -
 field public,static,final INSPECT_HOPPER Lnet/minecraft/resources/Identifier; -
 field public,static,final INSPECT_DISPENSER Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAY_NOTEBLOCK Lnet/minecraft/resources/Identifier; -
 field public,static,final TUNE_NOTEBLOCK Lnet/minecraft/resources/Identifier; -
 field public,static,final POT_FLOWER Lnet/minecraft/resources/Identifier; -
 field public,static,final TRIGGER_TRAPPED_CHEST Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_ENDERCHEST Lnet/minecraft/resources/Identifier; -
 field public,static,final ENCHANT_ITEM Lnet/minecraft/resources/Identifier; -
 field public,static,final PLAY_RECORD Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_FURNACE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_CRAFTING_TABLE Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_CHEST Lnet/minecraft/resources/Identifier; -
 field public,static,final SLEEP_IN_BED Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_SHULKER_BOX Lnet/minecraft/resources/Identifier; -
 field public,static,final OPEN_BARREL Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_BLAST_FURNACE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_SMOKER Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_LECTERN Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_CAMPFIRE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_CARTOGRAPHY_TABLE Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_LOOM Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_STONECUTTER Lnet/minecraft/resources/Identifier; -
 field public,static,final BELL_RING Lnet/minecraft/resources/Identifier; -
 field public,static,final RAID_TRIGGER Lnet/minecraft/resources/Identifier; -
 field public,static,final RAID_WIN Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_ANVIL Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_GRINDSTONE Lnet/minecraft/resources/Identifier; -
 field public,static,final TARGET_HIT Lnet/minecraft/resources/Identifier; -
 field public,static,final INTERACT_WITH_SMITHING_TABLE Lnet/minecraft/resources/Identifier; -
 method public <init> ()V - -
in 486
class net/minecraft/stats/StatsCounter 52 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 499
class net/minecraft/stats/StatsCounter 52 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 86
class net/minecraft/stats/StatsCounter 60 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 99
class net/minecraft/stats/StatsCounter 61 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
in 62
class net/minecraft/stats/StatsCounter 65 public,super java/lang/Object - -
 field protected,final stats Lit/unimi/dsi/fastutil/objects/Object2IntMap; Lit/unimi/dsi/fastutil/objects/Object2IntMap<Lnet/minecraft/stats/Stat<*>;>;
 method public <init> ()V - -
 method public increment (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public setValue (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat;I)V (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/stats/Stat<*>;I)V -
 method public getValue (Lnet/minecraft/stats/StatType;Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Lnet/minecraft/stats/StatType<TT;>;TT;)I -
 method public getValue (Lnet/minecraft/stats/Stat;)I (Lnet/minecraft/stats/Stat<*>;)I -
