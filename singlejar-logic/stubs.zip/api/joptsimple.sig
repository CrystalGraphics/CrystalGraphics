cg-stub-db 1
in 22
class joptsimple/AbstractOptionSpec 51 public,super,abstract java/lang/Object joptsimple/OptionSpec,joptsimple/OptionDescriptor <V:Ljava/lang/Object;>Ljava/lang/Object;Ljoptsimple/OptionSpec<TV;>;Ljoptsimple/OptionDescriptor;
 method public,final options ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,final values (Ljoptsimple/OptionSet;)Ljava/util/List; (Ljoptsimple/OptionSet;)Ljava/util/List<TV;>; -
 method public,final value (Ljoptsimple/OptionSet;)Ljava/lang/Object; (Ljoptsimple/OptionSet;)TV; -
 method public description ()Ljava/lang/String; - -
 method public,final forHelp ()Ljoptsimple/AbstractOptionSpec; ()Ljoptsimple/AbstractOptionSpec<TV;>; -
 method public,final isForHelp ()Z - -
 method public representsNonOptions ()Z - -
 method protected,abstract convert (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method protected convertWith (Ljoptsimple/ValueConverter;Ljava/lang/String;)Ljava/lang/Object; (Ljoptsimple/ValueConverter<TV;>;Ljava/lang/String;)TV; -
 method protected argumentTypeIndicatorFrom (Ljoptsimple/ValueConverter;)Ljava/lang/String; (Ljoptsimple/ValueConverter<TV;>;)Ljava/lang/String; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 22
class joptsimple/AlternativeLongOptionSpec 51 super joptsimple/ArgumentAcceptingOptionSpec - Ljoptsimple/ArgumentAcceptingOptionSpec<Ljava/lang/String;>;
 method protected detectOptionArgument (Ljoptsimple/OptionParser;Ljoptsimple/ArgumentList;Ljoptsimple/OptionSet;)V - -
in 22
class joptsimple/ArgumentAcceptingOptionSpec 51 public,super,abstract joptsimple/AbstractOptionSpec - <V:Ljava/lang/Object;>Ljoptsimple/AbstractOptionSpec<TV;>;
 method public,final ofType (Ljava/lang/Class;)Ljoptsimple/ArgumentAcceptingOptionSpec; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Ljoptsimple/ArgumentAcceptingOptionSpec<TT;>; -
 method public,final withValuesConvertedBy (Ljoptsimple/ValueConverter;)Ljoptsimple/ArgumentAcceptingOptionSpec; <T:Ljava/lang/Object;>(Ljoptsimple/ValueConverter<TT;>;)Ljoptsimple/ArgumentAcceptingOptionSpec<TT;>; -
 method public,final describedAs (Ljava/lang/String;)Ljoptsimple/ArgumentAcceptingOptionSpec; (Ljava/lang/String;)Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>; -
 method public,final withValuesSeparatedBy (C)Ljoptsimple/ArgumentAcceptingOptionSpec; (C)Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>; -
 method public,final withValuesSeparatedBy (Ljava/lang/String;)Ljoptsimple/ArgumentAcceptingOptionSpec; (Ljava/lang/String;)Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>; -
 method public,final,varargs defaultsTo (Ljava/lang/Object;[Ljava/lang/Object;)Ljoptsimple/ArgumentAcceptingOptionSpec; (TV;[TV;)Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>; -
 method public defaultsTo ([Ljava/lang/Object;)Ljoptsimple/ArgumentAcceptingOptionSpec; ([TV;)Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>; -
 method public required ()Ljoptsimple/ArgumentAcceptingOptionSpec; ()Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>; -
 method public isRequired ()Z - -
 method protected addArguments (Ljoptsimple/OptionSet;Ljava/lang/String;)V - -
 method protected,abstract detectOptionArgument (Ljoptsimple/OptionParser;Ljoptsimple/ArgumentList;Ljoptsimple/OptionSet;)V - -
 method protected,final convert (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method protected canConvertArgument (Ljava/lang/String;)Z - -
 method protected isArgumentOfNumberType ()Z - -
 method public acceptsArguments ()Z - -
 method public requiresArgument ()Z - -
 method public argumentDescription ()Ljava/lang/String; - -
 method public argumentTypeIndicator ()Ljava/lang/String; - -
 method public defaultValues ()Ljava/util/List; ()Ljava/util/List<TV;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class joptsimple/ArgumentList 51 super java/lang/Object - -
in 22
class joptsimple/BuiltinHelpFormatter 51 public,super java/lang/Object joptsimple/HelpFormatter -
 method public <init> (II)V - -
 method public format (Ljava/util/Map;)Ljava/lang/String; (Ljava/util/Map<Ljava/lang/String;+Ljoptsimple/OptionDescriptor;>;)Ljava/lang/String; -
 method protected addOptionRow (Ljava/lang/String;)V - -
 method protected addOptionRow (Ljava/lang/String;Ljava/lang/String;)V - -
 method protected addNonOptionRow (Ljava/lang/String;)V - -
 method protected fitRowsToWidth ()V - -
 method protected nonOptionOutput ()Ljava/lang/String; - -
 method protected optionOutput ()Ljava/lang/String; - -
 method protected formattedHelpOutput ()Ljava/lang/String; - -
 method protected addRows (Ljava/util/Collection;)V (Ljava/util/Collection<+Ljoptsimple/OptionDescriptor;>;)V -
 method protected addNonOptionsDescription (Ljava/util/Collection;)V (Ljava/util/Collection<+Ljoptsimple/OptionDescriptor;>;)V -
 method protected shouldShowNonOptionArgumentDisplay (Ljoptsimple/OptionDescriptor;)Z - -
 method protected createNonOptionArgumentsDisplay (Ljoptsimple/OptionDescriptor;)Ljava/lang/String; - -
 method protected maybeAppendNonOptionsDescription (Ljava/lang/StringBuilder;Ljoptsimple/OptionDescriptor;)V - -
 method protected findAndRemoveNonOptionsSpec (Ljava/util/Collection;)Ljoptsimple/OptionDescriptor; (Ljava/util/Collection<+Ljoptsimple/OptionDescriptor;>;)Ljoptsimple/OptionDescriptor; -
 method protected addHeaders (Ljava/util/Collection;)V (Ljava/util/Collection<+Ljoptsimple/OptionDescriptor;>;)V -
 method protected,final hasRequiredOption (Ljava/util/Collection;)Z (Ljava/util/Collection<+Ljoptsimple/OptionDescriptor;>;)Z -
 method protected addOptions (Ljava/util/Collection;)V (Ljava/util/Collection<+Ljoptsimple/OptionDescriptor;>;)V -
 method protected createOptionDisplay (Ljoptsimple/OptionDescriptor;)Ljava/lang/String; - -
 method protected optionLeader (Ljava/lang/String;)Ljava/lang/String; - -
 method protected maybeAppendOptionInfo (Ljava/lang/StringBuilder;Ljoptsimple/OptionDescriptor;)V - -
 method protected extractTypeIndicator (Ljoptsimple/OptionDescriptor;)Ljava/lang/String; - -
 method protected appendOptionHelp (Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Z)V - -
 method protected appendTypeIndicator (Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;CC)V - -
 method protected createDescriptionDisplay (Ljoptsimple/OptionDescriptor;)Ljava/lang/String; - -
 method protected createDefaultValuesDisplay (Ljava/util/List;)Ljava/lang/String; (Ljava/util/List<*>;)Ljava/lang/String; -
 method protected,varargs message (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
in 22
class joptsimple/HelpFormatter 51 public,interface,abstract java/lang/Object - -
 method public,abstract format (Ljava/util/Map;)Ljava/lang/String; (Ljava/util/Map<Ljava/lang/String;+Ljoptsimple/OptionDescriptor;>;)Ljava/lang/String; -
in 22
class joptsimple/IllegalOptionSpecificationException 51 super joptsimple/OptionException - -
in 22
class joptsimple/MissingRequiredOptionsException 51 super joptsimple/OptionException - -
 method protected <init> (Ljava/util/List;)V (Ljava/util/List<+Ljoptsimple/OptionSpec<*>;>;)V -
in 22
class joptsimple/MultipleArgumentsForOptionException 51 super joptsimple/OptionException - -
in 22
class joptsimple/NoArgumentOptionSpec 51 super joptsimple/AbstractOptionSpec - Ljoptsimple/AbstractOptionSpec<Ljava/lang/Void;>;
 method public acceptsArguments ()Z - -
 method public requiresArgument ()Z - -
 method public isRequired ()Z - -
 method public argumentDescription ()Ljava/lang/String; - -
 method public argumentTypeIndicator ()Ljava/lang/String; - -
 method protected convert (Ljava/lang/String;)Ljava/lang/Void; - -
 method public defaultValues ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/Void;>; -
in 22
class joptsimple/NonOptionArgumentSpec 51 public,super joptsimple/AbstractOptionSpec - <V:Ljava/lang/Object;>Ljoptsimple/AbstractOptionSpec<TV;>;
 method public ofType (Ljava/lang/Class;)Ljoptsimple/NonOptionArgumentSpec; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Ljoptsimple/NonOptionArgumentSpec<TT;>; -
 method public,final withValuesConvertedBy (Ljoptsimple/ValueConverter;)Ljoptsimple/NonOptionArgumentSpec; <T:Ljava/lang/Object;>(Ljoptsimple/ValueConverter<TT;>;)Ljoptsimple/NonOptionArgumentSpec<TT;>; -
 method public describedAs (Ljava/lang/String;)Ljoptsimple/NonOptionArgumentSpec; (Ljava/lang/String;)Ljoptsimple/NonOptionArgumentSpec<TV;>; -
 method protected,final convert (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method public defaultValues ()Ljava/util/List; ()Ljava/util/List<*>; -
 method public isRequired ()Z - -
 method public acceptsArguments ()Z - -
 method public requiresArgument ()Z - -
 method public argumentDescription ()Ljava/lang/String; - -
 method public argumentTypeIndicator ()Ljava/lang/String; - -
 method public representsNonOptions ()Z - -
in 22
class joptsimple/OptionArgumentConversionException 51 super joptsimple/OptionException - -
in 22
class joptsimple/OptionDeclarer 51 public,interface,abstract java/lang/Object - -
 method public,abstract accepts (Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public,abstract accepts (Ljava/lang/String;Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public,abstract acceptsAll (Ljava/util/List;)Ljoptsimple/OptionSpecBuilder; (Ljava/util/List<Ljava/lang/String;>;)Ljoptsimple/OptionSpecBuilder; -
 method public,abstract acceptsAll (Ljava/util/List;Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; -
 method public,abstract nonOptions ()Ljoptsimple/NonOptionArgumentSpec; ()Ljoptsimple/NonOptionArgumentSpec<Ljava/lang/String;>; -
 method public,abstract nonOptions (Ljava/lang/String;)Ljoptsimple/NonOptionArgumentSpec; (Ljava/lang/String;)Ljoptsimple/NonOptionArgumentSpec<Ljava/lang/String;>; -
 method public,abstract posixlyCorrect (Z)V - -
 method public,abstract allowsUnrecognizedOptions ()V - -
 method public,abstract recognizeAlternativeLongOptions (Z)V - -
in 22
class joptsimple/OptionDescriptor 51 public,interface,abstract java/lang/Object - -
 method public,abstract options ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract description ()Ljava/lang/String; - -
 method public,abstract defaultValues ()Ljava/util/List; ()Ljava/util/List<*>; -
 method public,abstract isRequired ()Z - -
 method public,abstract acceptsArguments ()Z - -
 method public,abstract requiresArgument ()Z - -
 method public,abstract argumentDescription ()Ljava/lang/String; - -
 method public,abstract argumentTypeIndicator ()Ljava/lang/String; - -
 method public,abstract representsNonOptions ()Z - -
in 22
class joptsimple/OptionException 51 public,super,abstract java/lang/RuntimeException - -
 method protected <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/String;>;)V -
 method protected <init> (Ljava/util/Collection;)V (Ljava/util/Collection<+Ljoptsimple/OptionSpec<*>;>;)V -
 method protected <init> (Ljava/util/Collection;Ljava/lang/Throwable;)V (Ljava/util/Collection<+Ljoptsimple/OptionSpec<*>;>;Ljava/lang/Throwable;)V -
 method public options ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method protected,final singleOptionString ()Ljava/lang/String; - -
 method protected,final singleOptionString (Ljava/lang/String;)Ljava/lang/String; - -
 method protected,final multipleOptionString ()Ljava/lang/String; - -
 method public,final getMessage ()Ljava/lang/String; - -
in 22
class joptsimple/OptionMissingRequiredArgumentException 51 super joptsimple/OptionException - -
in 22
class joptsimple/OptionParser 51 public,super java/lang/Object joptsimple/OptionDeclarer -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public <init> (Z)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public accepts (Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public accepts (Ljava/lang/String;Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public acceptsAll (Ljava/util/List;)Ljoptsimple/OptionSpecBuilder; (Ljava/util/List<Ljava/lang/String;>;)Ljoptsimple/OptionSpecBuilder; -
 method public acceptsAll (Ljava/util/List;Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; (Ljava/util/List<Ljava/lang/String;>;Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; -
 method public nonOptions ()Ljoptsimple/NonOptionArgumentSpec; ()Ljoptsimple/NonOptionArgumentSpec<Ljava/lang/String;>; -
 method public nonOptions (Ljava/lang/String;)Ljoptsimple/NonOptionArgumentSpec; (Ljava/lang/String;)Ljoptsimple/NonOptionArgumentSpec<Ljava/lang/String;>; -
 method public posixlyCorrect (Z)V - -
 method public allowsUnrecognizedOptions ()V - -
 method public recognizeAlternativeLongOptions (Z)V - -
 method public printHelpOn (Ljava/io/OutputStream;)V - java/io/IOException
 method public printHelpOn (Ljava/io/Writer;)V - java/io/IOException
 method public formatHelpWith (Ljoptsimple/HelpFormatter;)V - -
 method public recognizedOptions ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljoptsimple/OptionSpec<*>;>; -
 method public,varargs parse ([Ljava/lang/String;)Ljoptsimple/OptionSet; - -
 method public,varargs mutuallyExclusive ([Ljoptsimple/OptionSpecBuilder;)V - -
in 22
class joptsimple/OptionParserState 51 super,abstract java/lang/Object - -
 method protected,abstract handleArgument (Ljoptsimple/OptionParser;Ljoptsimple/ArgumentList;Ljoptsimple/OptionSet;)V - -
in 22
class joptsimple/OptionSet 51 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public hasOptions ()Z - -
 method public has (Ljava/lang/String;)Z - -
 method public has (Ljoptsimple/OptionSpec;)Z (Ljoptsimple/OptionSpec<*>;)Z -
 method public hasArgument (Ljava/lang/String;)Z - -
 method public hasArgument (Ljoptsimple/OptionSpec;)Z (Ljoptsimple/OptionSpec<*>;)Z -
 method public valueOf (Ljava/lang/String;)Ljava/lang/Object; - -
 method public valueOf (Ljoptsimple/OptionSpec;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)TV; -
 method public valuesOf (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<*>; -
 method public valuesOf (Ljoptsimple/OptionSpec;)Ljava/util/List; <V:Ljava/lang/Object;>(Ljoptsimple/OptionSpec<TV;>;)Ljava/util/List<TV;>; -
 method public specs ()Ljava/util/List; ()Ljava/util/List<Ljoptsimple/OptionSpec<*>;>; -
 method public asMap ()Ljava/util/Map; ()Ljava/util/Map<Ljoptsimple/OptionSpec<*>;Ljava/util/List<*>;>; -
 method public nonOptionArguments ()Ljava/util/List; ()Ljava/util/List<*>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 22
class joptsimple/OptionSpec 51 public,interface,abstract java/lang/Object - <V:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract values (Ljoptsimple/OptionSet;)Ljava/util/List; (Ljoptsimple/OptionSet;)Ljava/util/List<TV;>; -
 method public,abstract value (Ljoptsimple/OptionSet;)Ljava/lang/Object; (Ljoptsimple/OptionSet;)TV; -
 method public,abstract options ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract isForHelp ()Z - -
in 22
class joptsimple/OptionSpecBuilder 51 public,super joptsimple/NoArgumentOptionSpec - -
 method public withRequiredArg ()Ljoptsimple/ArgumentAcceptingOptionSpec; ()Ljoptsimple/ArgumentAcceptingOptionSpec<Ljava/lang/String;>; -
 method public withOptionalArg ()Ljoptsimple/ArgumentAcceptingOptionSpec; ()Ljoptsimple/ArgumentAcceptingOptionSpec<Ljava/lang/String;>; -
 method public,varargs requiredIf (Ljava/lang/String;[Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public,varargs requiredIf (Ljoptsimple/OptionSpec;[Ljoptsimple/OptionSpec;)Ljoptsimple/OptionSpecBuilder; (Ljoptsimple/OptionSpec<*>;[Ljoptsimple/OptionSpec<*>;)Ljoptsimple/OptionSpecBuilder; -
 method public,varargs requiredUnless (Ljava/lang/String;[Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public,varargs requiredUnless (Ljoptsimple/OptionSpec;[Ljoptsimple/OptionSpec;)Ljoptsimple/OptionSpecBuilder; (Ljoptsimple/OptionSpec<*>;[Ljoptsimple/OptionSpec<*>;)Ljoptsimple/OptionSpecBuilder; -
 method public,varargs availableIf (Ljava/lang/String;[Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public,varargs availableIf (Ljoptsimple/OptionSpec;[Ljoptsimple/OptionSpec;)Ljoptsimple/OptionSpecBuilder; (Ljoptsimple/OptionSpec<*>;[Ljoptsimple/OptionSpec<*>;)Ljoptsimple/OptionSpecBuilder; -
 method public,varargs availableUnless (Ljava/lang/String;[Ljava/lang/String;)Ljoptsimple/OptionSpecBuilder; - -
 method public,varargs availableUnless (Ljoptsimple/OptionSpec;[Ljoptsimple/OptionSpec;)Ljoptsimple/OptionSpecBuilder; (Ljoptsimple/OptionSpec<*>;[Ljoptsimple/OptionSpec<*>;)Ljoptsimple/OptionSpecBuilder; -
in 22
class joptsimple/OptionSpecTokenizer 51 super java/lang/Object - -
in 22
class joptsimple/OptionalArgumentOptionSpec 51 super joptsimple/ArgumentAcceptingOptionSpec - <V:Ljava/lang/Object;>Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>;
 method protected detectOptionArgument (Ljoptsimple/OptionParser;Ljoptsimple/ArgumentList;Ljoptsimple/OptionSet;)V - -
in 22
class joptsimple/ParserRules 51 final,super java/lang/Object - -
in 22
class joptsimple/RequiredArgumentOptionSpec 51 super joptsimple/ArgumentAcceptingOptionSpec - <V:Ljava/lang/Object;>Ljoptsimple/ArgumentAcceptingOptionSpec<TV;>;
 method protected detectOptionArgument (Ljoptsimple/OptionParser;Ljoptsimple/ArgumentList;Ljoptsimple/OptionSet;)V - -
in 22
class joptsimple/UnavailableOptionException 51 super joptsimple/OptionException - -
in 22
class joptsimple/UnconfiguredOptionException 51 super joptsimple/OptionException - -
in 22
class joptsimple/UnrecognizedOptionException 51 super joptsimple/OptionException - -
in 22
class joptsimple/ValueConversionException 51 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 22
class joptsimple/ValueConverter 51 public,interface,abstract java/lang/Object - <V:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract convert (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TV; -
 method public,abstract valueType ()Ljava/lang/Class; ()Ljava/lang/Class<+TV;>; -
 method public,abstract valuePattern ()Ljava/lang/String; - -
