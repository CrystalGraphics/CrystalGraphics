cg-stub-db 1
in 86
class net/minecraft/BlockUtil 52 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/core/Direction$AxisDirection net/minecraft/core/Direction AxisDirection public,static,final,enum
 method public,static getLargestRectangleAround (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate;)Lnet/minecraft/BlockUtil$FoundRectangle; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate<Lnet/minecraft/core/BlockPos;>;)Lnet/minecraft/BlockUtil$FoundRectangle; -
in 82
class net/minecraft/BlockUtil 60 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/core/Direction$AxisDirection net/minecraft/core/Direction AxisDirection public,static,final,enum
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 method public <init> ()V - -
 method public,static getLargestRectangleAround (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate;)Lnet/minecraft/BlockUtil$FoundRectangle; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate<Lnet/minecraft/core/BlockPos;>;)Lnet/minecraft/BlockUtil$FoundRectangle; -
 method public,static getTopConnectedBlock (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/Block;)Ljava/util/Optional; (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/Block;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
in 93
class net/minecraft/BlockUtil 61 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/core/Direction$AxisDirection net/minecraft/core/Direction AxisDirection public,static,final,enum
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 method public <init> ()V - -
 method public,static getLargestRectangleAround (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate;)Lnet/minecraft/BlockUtil$FoundRectangle; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate<Lnet/minecraft/core/BlockPos;>;)Lnet/minecraft/BlockUtil$FoundRectangle; -
 method public,static getTopConnectedBlock (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/Block;)Ljava/util/Optional; (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/Block;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
in 95
class net/minecraft/BlockUtil 65 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/core/Direction$AxisDirection net/minecraft/core/Direction AxisDirection public,static,final,enum
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 method public <init> ()V - -
 method public,static getLargestRectangleAround (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate;)Lnet/minecraft/BlockUtil$FoundRectangle; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction$Axis;ILnet/minecraft/core/Direction$Axis;ILjava/util/function/Predicate<Lnet/minecraft/core/BlockPos;>;)Lnet/minecraft/BlockUtil$FoundRectangle; -
 method public,static getTopConnectedBlock (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/Block;)Ljava/util/Optional; (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/Block;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
in 86
class net/minecraft/BlockUtil$FoundRectangle 52 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 field public,final minCorner Lnet/minecraft/core/BlockPos; -
 field public,final axis1Size I -
 field public,final axis2Size I -
 method public <init> (Lnet/minecraft/core/BlockPos;II)V - -
in 82
class net/minecraft/BlockUtil$FoundRectangle 60 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 field public,final minCorner Lnet/minecraft/core/BlockPos; -
 field public,final axis1Size I -
 field public,final axis2Size I -
 method public <init> (Lnet/minecraft/core/BlockPos;II)V - -
in 93
class net/minecraft/BlockUtil$FoundRectangle 61 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 field public,final minCorner Lnet/minecraft/core/BlockPos; -
 field public,final axis1Size I -
 field public,final axis2Size I -
 method public <init> (Lnet/minecraft/core/BlockPos;II)V - -
in 95
class net/minecraft/BlockUtil$FoundRectangle 65 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$FoundRectangle net/minecraft/BlockUtil FoundRectangle public,static
 field public,final minCorner Lnet/minecraft/core/BlockPos; -
 field public,final axis1Size I -
 field public,final axis2Size I -
 method public <init> (Lnet/minecraft/core/BlockPos;II)V - -
in 86
class net/minecraft/BlockUtil$IntBounds 52 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 field public,final min I -
 field public,final max I -
 method public <init> (II)V - -
 method public toString ()Ljava/lang/String; - -
in 82
class net/minecraft/BlockUtil$IntBounds 60 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final min I -
 field public,final max I -
 method public <init> (II)V - -
 method public toString ()Ljava/lang/String; - -
in 93
class net/minecraft/BlockUtil$IntBounds 61 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final min I -
 field public,final max I -
 method public <init> (II)V - -
 method public toString ()Ljava/lang/String; - -
in 95
class net/minecraft/BlockUtil$IntBounds 65 public,super java/lang/Object - -
 inner net/minecraft/BlockUtil$IntBounds net/minecraft/BlockUtil IntBounds public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final min I -
 field public,final max I -
 method public <init> (II)V - -
 method public toString ()Ljava/lang/String; - -
in 86
class net/minecraft/CharPredicate 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract test (C)Z - -
in 82
class net/minecraft/CharPredicate 60 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract test (C)Z - -
 method public and (Lnet/minecraft/CharPredicate;)Lnet/minecraft/CharPredicate; - -
 method public negate ()Lnet/minecraft/CharPredicate; - -
 method public or (Lnet/minecraft/CharPredicate;)Lnet/minecraft/CharPredicate; - -
in 93
class net/minecraft/CharPredicate 61 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract test (C)Z - -
 method public and (Lnet/minecraft/CharPredicate;)Lnet/minecraft/CharPredicate; - -
 method public negate ()Lnet/minecraft/CharPredicate; - -
 method public or (Lnet/minecraft/CharPredicate;)Lnet/minecraft/CharPredicate; - -
in 60
class net/minecraft/CharPredicate 65 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract test (C)Z - -
 method public and (Lnet/minecraft/CharPredicate;)Lnet/minecraft/CharPredicate; - -
 method public negate ()Lnet/minecraft/CharPredicate; - -
 method public or (Lnet/minecraft/CharPredicate;)Lnet/minecraft/CharPredicate; - -
in 456
class net/minecraft/ChatFormatting 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 method public,static getLastColors (Ljava/lang/String;)Ljava/lang/String; - -
 method public getColor ()Ljava/lang/Integer; - -
 method public shouldReset ()Z - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
in 457
class net/minecraft/ChatFormatting 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getLastColors (Ljava/lang/String;)Ljava/lang/String; - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getColor ()Ljava/lang/Integer; - -
 method public shouldReset ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
in 86
class net/minecraft/ChatFormatting 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getColor ()Ljava/lang/Integer; - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
in 82
class net/minecraft/ChatFormatting 60 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 field public,static,final PREFIX_CODE C - I167
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public getChar ()C - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getColor ()Ljava/lang/Integer; - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
in 84
class net/minecraft/ChatFormatting 61 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 field public,static,final PREFIX_CODE C - I167
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public getChar ()C - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getColor ()Ljava/lang/Integer; - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
in 127
class net/minecraft/ChatFormatting 61 public,final,super,enum java/lang/Enum net/minecraft/util/StringRepresentable Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;Lnet/minecraft/util/StringRepresentable;
 inner net/minecraft/util/StringRepresentable$EnumCodec net/minecraft/util/StringRepresentable EnumCodec public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/ChatFormatting;>;
 field public,static,final PREFIX_CODE C - I167
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public getChar ()C - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getColor ()Ljava/lang/Integer; - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
 method public getSerializedName ()Ljava/lang/String; - -
in 128
class net/minecraft/ChatFormatting 65 public,final,super,enum java/lang/Enum net/minecraft/util/StringRepresentable Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;Lnet/minecraft/util/StringRepresentable;
 inner net/minecraft/util/StringRepresentable$EnumCodec net/minecraft/util/StringRepresentable EnumCodec public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/ChatFormatting;>;
 field public,static,final PREFIX_CODE C - I167
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public getChar ()C - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getColor ()Ljava/lang/Integer; - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
 method public getSerializedName ()Ljava/lang/String; - -
in 96
class net/minecraft/ChatFormatting 65 public,final,super,enum java/lang/Enum net/minecraft/util/StringRepresentable Ljava/lang/Enum<Lnet/minecraft/ChatFormatting;>;Lnet/minecraft/util/StringRepresentable;
 inner net/minecraft/util/StringRepresentable$EnumCodec net/minecraft/util/StringRepresentable EnumCodec public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum BLACK Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum DARK_GRAY Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BLUE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum GREEN Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum AQUA Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum LIGHT_PURPLE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum YELLOW Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum WHITE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum OBFUSCATED Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum BOLD Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum STRIKETHROUGH Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum UNDERLINE Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum ITALIC Lnet/minecraft/ChatFormatting; -
 field public,static,final,enum RESET Lnet/minecraft/ChatFormatting; -
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/ChatFormatting;>;
 field public,static,final COLOR_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/ChatFormatting;>;
 field public,static,final PREFIX_CODE C - I167
 method public,static values ()[Lnet/minecraft/ChatFormatting; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public getChar ()C - -
 method public getId ()I - -
 method public isFormat ()Z - -
 method public isColor ()Z - -
 method public getColor ()Ljava/lang/Integer; - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public,static stripFormatting (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/ChatFormatting; - -
 method public,static getById (I)Lnet/minecraft/ChatFormatting; - -
 method public,static getByCode (C)Lnet/minecraft/ChatFormatting; - -
 method public,static getNames (ZZ)Ljava/util/Collection; (ZZ)Ljava/util/Collection<Ljava/lang/String;>; -
 method public getSerializedName ()Ljava/lang/String; - -
in 456
class net/minecraft/CrashReport 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSaveFile ()Ljava/io/File; - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport ()Ljava/lang/String; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getSystemDetails ()Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
in 458
class net/minecraft/CrashReport 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport ()Ljava/lang/String; - -
 method public getSaveFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getSystemDetails ()Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
in 175
class net/minecraft/CrashReport 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport ()Ljava/lang/String; - -
 method public getSaveFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getSystemDetails ()Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
 method public,static preload ()V - -
in 82
class net/minecraft/CrashReport 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails ()Ljava/lang/String; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport ()Ljava/lang/String; - -
 method public getSaveFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getSystemReport ()Lnet/minecraft/SystemReport; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
 method public,static preload ()V - -
in 36
class net/minecraft/CrashReport 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails ()Ljava/lang/String; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport ()Ljava/lang/String; - -
 method public getSaveFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getSystemReport ()Lnet/minecraft/SystemReport; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
 method public,static preload ()V - -
in 234
class net/minecraft/CrashReport 61 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails ()Ljava/lang/String; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport ()Ljava/lang/String; - -
 method public getSaveFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getSystemReport ()Lnet/minecraft/SystemReport; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
 method public,static preload ()V - -
in 224
class net/minecraft/CrashReport 65 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails ()Ljava/lang/String; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport ()Ljava/lang/String; - -
 method public getSaveFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getSystemReport ()Lnet/minecraft/SystemReport; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
 method public,static preload ()V - -
in 260
class net/minecraft/CrashReport 65 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getTitle ()Ljava/lang/String; - -
 method public getException ()Ljava/lang/Throwable; - -
 method public getDetails ()Ljava/lang/String; - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getExceptionMessage ()Ljava/lang/String; - -
 method public getFriendlyReport (Lnet/minecraft/ReportType;Ljava/util/List;)Ljava/lang/String; (Lnet/minecraft/ReportType;Ljava/util/List<Ljava/lang/String;>;)Ljava/lang/String; -
 method public getFriendlyReport (Lnet/minecraft/ReportType;)Ljava/lang/String; - -
 method public getSaveFile ()Ljava/nio/file/Path; - -
 method public saveToFile (Ljava/nio/file/Path;Lnet/minecraft/ReportType;Ljava/util/List;)Z (Ljava/nio/file/Path;Lnet/minecraft/ReportType;Ljava/util/List<Ljava/lang/String;>;)Z -
 method public saveToFile (Ljava/nio/file/Path;Lnet/minecraft/ReportType;)Z - -
 method public getSystemReport ()Lnet/minecraft/SystemReport; - -
 method public addCategory (Ljava/lang/String;)Lnet/minecraft/CrashReportCategory; - -
 method public addCategory (Ljava/lang/String;I)Lnet/minecraft/CrashReportCategory; - -
 method public,static forThrowable (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/CrashReport; - -
 method public,static preload ()V - -
in 456
class net/minecraft/CrashReportCategory 52 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static formatLocation (DDD)Ljava/lang/String; - -
 method public <init> (Lnet/minecraft/CrashReport;Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)V (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)V -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 459
class net/minecraft/CrashReportCategory 52 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/CrashReport;Ljava/lang/String;)V - -
 method public,static formatLocation (DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 104
class net/minecraft/CrashReportCategory 60 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public applyStackTrace (Ljava/lang/Throwable;)V - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 374
class net/minecraft/CrashReportCategory 61 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public applyStackTrace (Ljava/lang/Throwable;)V - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 206
class net/minecraft/CrashReportCategory 61 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 460
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 143
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public,static populateBlockLocationDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/CrashReportCategory; - -
in 461
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public,static populateBlockLocationDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/CrashReportCategory; - -
in 384
class net/minecraft/CrashReportCategory 52 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/CrashReport;Ljava/lang/String;)V - -
 method public,static formatLocation (DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)V (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)V -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 190
class net/minecraft/CrashReportCategory 52 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/CrashReport;Ljava/lang/String;)V - -
 method public,static formatLocation (DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public applyStackTrace (Ljava/lang/Throwable;)V - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 192
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public applyStackTrace (Ljava/lang/Throwable;)V - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 279
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,deprecated applyStackTrace (Ljava/lang/Throwable;)V - -
 method public setStackTrace ([Ljava/lang/StackTraceElement;)V - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 146
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public setStackTrace ([Ljava/lang/StackTraceElement;)V - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public,static populateBlockLocationDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/CrashReportCategory; - -
in 462
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public setStackTrace ([Ljava/lang/StackTraceElement;)V - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public,static populateBlockLocationDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/CrashReportCategory; - -
in 108
class net/minecraft/CrashReportCategory 60 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 113
class net/minecraft/CrashReportCategory 61 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 174
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 147
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public,static populateBlockLocationDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/CrashReportCategory; - -
in 138
class net/minecraft/CrashReportCategory 65 public,super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public,static formatLocation (DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;DDD)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Ljava/lang/String; - -
 method public,static formatLocation (Lnet/minecraft/world/level/LevelHeightAccessor;III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/CrashReportDetail;)Lnet/minecraft/CrashReportCategory; (Ljava/lang/String;Lnet/minecraft/CrashReportDetail<Ljava/lang/String;>;)Lnet/minecraft/CrashReportCategory; -
 method public setDetail (Ljava/lang/String;Ljava/lang/Object;)Lnet/minecraft/CrashReportCategory; - -
 method public setDetailError (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public fillInStackTrace (I)I - -
 method public validateStackTrace (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStacktrace (I)V - -
 method public getDetails (Ljava/lang/StringBuilder;)V - -
 method public getStacktrace ()[Ljava/lang/StackTraceElement; - -
 method public,static populateBlockDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public,static populateBlockLocationDetails (Lnet/minecraft/CrashReportCategory;Lnet/minecraft/world/level/LevelHeightAccessor;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/CrashReportCategory; - -
in 126
class net/minecraft/CrashReportCategory$Entry 52 super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 method public <init> (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getKey ()Ljava/lang/String; - -
 method public getValue ()Ljava/lang/String; - -
in 82
class net/minecraft/CrashReportCategory$Entry 60 super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getKey ()Ljava/lang/String; - -
 method public getValue ()Ljava/lang/String; - -
in 93
class net/minecraft/CrashReportCategory$Entry 61 super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getKey ()Ljava/lang/String; - -
 method public getValue ()Ljava/lang/String; - -
in 60
class net/minecraft/CrashReportCategory$Entry 65 super java/lang/Object - -
 inner net/minecraft/CrashReportCategory$Entry net/minecraft/CrashReportCategory Entry static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getKey ()Ljava/lang/String; - -
 method public getValue ()Ljava/lang/String; - -
in 126
class net/minecraft/CrashReportDetail 52 public,interface,abstract java/lang/Object java/util/concurrent/Callable <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/Callable<TV;>;
in 82
class net/minecraft/CrashReportDetail 60 public,interface,abstract java/lang/Object java/util/concurrent/Callable <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/Callable<TV;>;
in 93
class net/minecraft/CrashReportDetail 61 public,interface,abstract java/lang/Object java/util/concurrent/Callable <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/Callable<TV;>;
in 60
class net/minecraft/CrashReportDetail 65 public,interface,abstract java/lang/Object java/util/concurrent/Callable <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/Callable<TV;>;
in 126
class net/minecraft/DefaultUncaughtExceptionHandler 52 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/apache/logging/log4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 82
class net/minecraft/DefaultUncaughtExceptionHandler 60 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/apache/logging/log4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 93
class net/minecraft/DefaultUncaughtExceptionHandler 61 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/slf4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 60
class net/minecraft/DefaultUncaughtExceptionHandler 65 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/slf4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 126
class net/minecraft/DefaultUncaughtExceptionHandlerWithName 52 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/apache/logging/log4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 82
class net/minecraft/DefaultUncaughtExceptionHandlerWithName 60 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/apache/logging/log4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 93
class net/minecraft/DefaultUncaughtExceptionHandlerWithName 61 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/slf4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 60
class net/minecraft/DefaultUncaughtExceptionHandlerWithName 65 public,super java/lang/Object java/lang/Thread$UncaughtExceptionHandler -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public <init> (Lorg/slf4j/Logger;)V - -
 method public uncaughtException (Ljava/lang/Thread;Ljava/lang/Throwable;)V - -
in 216
class net/minecraft/DetectedVersion 52 public,super java/lang/Object com/mojang/bridge/game/GameVersion -
 method public <init> ()V - -
 method protected <init> (Lcom/google/gson/JsonObject;)V - -
 method public,static tryDetectVersion ()Lcom/mojang/bridge/game/GameVersion; - -
 method public getId ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getReleaseTarget ()Ljava/lang/String; - -
 method public getWorldVersion ()I - -
 method public getProtocolVersion ()I - -
 method public getPackVersion ()I - -
 method public getBuildTime ()Ljava/util/Date; - -
 method public isStable ()Z - -
in 86
class net/minecraft/DetectedVersion 52 public,super java/lang/Object com/mojang/bridge/game/GameVersion -
 field public,static,final BUILT_IN Lcom/mojang/bridge/game/GameVersion; -
 method public,static tryDetectVersion ()Lcom/mojang/bridge/game/GameVersion; - -
 method public getId ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getReleaseTarget ()Ljava/lang/String; - -
 method public getWorldVersion ()I - -
 method public getProtocolVersion ()I - -
 method public getPackVersion ()I - -
 method public getBuildTime ()Ljava/util/Date; - -
 method public isStable ()Z - -
in 82
class net/minecraft/DetectedVersion 60 public,super java/lang/Object com/mojang/bridge/game/GameVersion -
 field public,static,final BUILT_IN Lcom/mojang/bridge/game/GameVersion; -
 method public,static tryDetectVersion ()Lcom/mojang/bridge/game/GameVersion; - -
 method public getId ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getReleaseTarget ()Ljava/lang/String; - -
 method public getWorldVersion ()I - -
 method public getProtocolVersion ()I - -
 method public getPackVersion (Lcom/mojang/bridge/game/PackType;)I - -
 method public getBuildTime ()Ljava/util/Date; - -
 method public isStable ()Z - -
in 34
class net/minecraft/DetectedVersion 61 public,super java/lang/Object net/minecraft/WorldVersion -
 field public,static,final BUILT_IN Lnet/minecraft/WorldVersion; -
 method public,static tryDetectVersion ()Lnet/minecraft/WorldVersion; - -
 method public getId ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getReleaseTarget ()Ljava/lang/String; - -
 method public getDataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public getProtocolVersion ()I - -
 method public getPackVersion (Lcom/mojang/bridge/game/PackType;)I - -
 method public getBuildTime ()Ljava/util/Date; - -
 method public isStable ()Z - -
in 90
class net/minecraft/DetectedVersion 61 public,super java/lang/Object net/minecraft/WorldVersion -
 field public,static,final BUILT_IN Lnet/minecraft/WorldVersion; -
 method public,static tryDetectVersion ()Lnet/minecraft/WorldVersion; - -
 method public getId ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public getProtocolVersion ()I - -
 method public getPackVersion (Lcom/mojang/bridge/game/PackType;)I - -
 method public getBuildTime ()Ljava/util/Date; - -
 method public isStable ()Z - -
in 89
class net/minecraft/DetectedVersion 61 public,super java/lang/Object net/minecraft/WorldVersion -
 field public,static,final BUILT_IN Lnet/minecraft/WorldVersion; -
 method public,static tryDetectVersion ()Lnet/minecraft/WorldVersion; - -
 method public getId ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public getProtocolVersion ()I - -
 method public getPackVersion (Lnet/minecraft/server/packs/PackType;)I - -
 method public getBuildTime ()Ljava/util/Date; - -
 method public isStable ()Z - -
in 221
class net/minecraft/DetectedVersion 65 public,super java/lang/Object net/minecraft/WorldVersion -
 field public,static,final BUILT_IN Lnet/minecraft/WorldVersion; -
 method public,static tryDetectVersion ()Lnet/minecraft/WorldVersion; - -
 method public getId ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public getProtocolVersion ()I - -
 method public getPackVersion (Lnet/minecraft/server/packs/PackType;)I - -
 method public getBuildTime ()Ljava/util/Date; - -
 method public isStable ()Z - -
in 103
class net/minecraft/DetectedVersion 65 public,super java/lang/Object - -
 inner net/minecraft/WorldVersion$Simple net/minecraft/WorldVersion Simple public,static,final
 field public,static,final BUILT_IN Lnet/minecraft/WorldVersion; -
 method public <init> ()V - -
 method public,static tryDetectVersion ()Lnet/minecraft/WorldVersion; - -
in 74
class net/minecraft/DetectedVersion 65 public,super java/lang/Object - -
 inner net/minecraft/WorldVersion$Simple net/minecraft/WorldVersion Simple public,static,final
 field public,static,final BUILT_IN Lnet/minecraft/WorldVersion; -
 method public <init> ()V - -
 method public,static createBuiltIn (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/WorldVersion; - -
 method public,static createBuiltIn (Ljava/lang/String;Ljava/lang/String;Z)Lnet/minecraft/WorldVersion; - -
 method public,static tryDetectVersion ()Lnet/minecraft/WorldVersion; - -
in 82
class net/minecraft/FieldsAreNonnullByDefault 60 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 93
class net/minecraft/FieldsAreNonnullByDefault 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 95
class net/minecraft/FieldsAreNonnullByDefault 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 92
class net/minecraft/FileUtil 52 public,super java/lang/Object - -
 method public,static findAvailableName (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public,static isPathNormalized (Ljava/nio/file/Path;)Z - -
 method public,static isPathPortable (Ljava/nio/file/Path;)Z - -
 method public,static createPathToResource (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
in 82
class net/minecraft/FileUtil 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static findAvailableName (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public,static isPathNormalized (Ljava/nio/file/Path;)Z - -
 method public,static isPathPortable (Ljava/nio/file/Path;)Z - -
 method public,static createPathToResource (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,static getFullResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static normalizeResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
in 34
class net/minecraft/FileUtil 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static findAvailableName (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public,static isPathNormalized (Ljava/nio/file/Path;)Z - -
 method public,static isPathPortable (Ljava/nio/file/Path;)Z - -
 method public,static createPathToResource (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,static getFullResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static normalizeResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
in 220
class net/minecraft/FileUtil 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static findAvailableName (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public,static isPathNormalized (Ljava/nio/file/Path;)Z - -
 method public,static isPathPortable (Ljava/nio/file/Path;)Z - -
 method public,static createPathToResource (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,static getFullResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static normalizeResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static decomposePath (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Ljava/util/List<Ljava/lang/String;>;>; -
 method public,static resolvePath (Ljava/nio/file/Path;Ljava/util/List;)Ljava/nio/file/Path; (Ljava/nio/file/Path;Ljava/util/List<Ljava/lang/String;>;)Ljava/nio/file/Path; -
 method public,static isValidStrictPathSegment (Ljava/lang/String;)Z - -
 method public,static,varargs validatePath ([Ljava/lang/String;)V - -
 method public,static createDirectoriesSafe (Ljava/nio/file/Path;)V - java/io/IOException
in 224
class net/minecraft/FileUtil 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static findAvailableName (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public,static isPathNormalized (Ljava/nio/file/Path;)Z - -
 method public,static isPathPortable (Ljava/nio/file/Path;)Z - -
 method public,static createPathToResource (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,static getFullResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static normalizeResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static decomposePath (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Ljava/util/List<Ljava/lang/String;>;>; -
 method public,static resolvePath (Ljava/nio/file/Path;Ljava/util/List;)Ljava/nio/file/Path; (Ljava/nio/file/Path;Ljava/util/List<Ljava/lang/String;>;)Ljava/nio/file/Path; -
 method public,static isValidStrictPathSegment (Ljava/lang/String;)Z - -
 method public,static,varargs validatePath ([Ljava/lang/String;)V - -
 method public,static createDirectoriesSafe (Ljava/nio/file/Path;)V - java/io/IOException
in 259
class net/minecraft/FileUtil 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static sanitizeName (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static findAvailableName (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public,static isPathNormalized (Ljava/nio/file/Path;)Z - -
 method public,static isPathPortable (Ljava/nio/file/Path;)Z - -
 method public,static createPathToResource (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,static getFullResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static normalizeResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static decomposePath (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Ljava/util/List<Ljava/lang/String;>;>; -
 method public,static resolvePath (Ljava/nio/file/Path;Ljava/util/List;)Ljava/nio/file/Path; (Ljava/nio/file/Path;Ljava/util/List<Ljava/lang/String;>;)Ljava/nio/file/Path; -
 method public,static isValidStrictPathSegment (Ljava/lang/String;)Z - -
 method public,static,varargs validatePath ([Ljava/lang/String;)V - -
 method public,static createDirectoriesSafe (Ljava/nio/file/Path;)V - java/io/IOException
in 125
class net/minecraft/FileUtil 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static sanitizeName (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static findAvailableName (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public,static isPathNormalized (Ljava/nio/file/Path;)Z - -
 method public,static isPathPortable (Ljava/nio/file/Path;)Z - -
 method public,static isPathPartPortable (Ljava/lang/String;)Z - -
 method public,static createPathToResource (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,static getFullResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static normalizeResourcePath (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static decomposePath (Ljava/lang/String;)Lcom/mojang/serialization/DataResult; (Ljava/lang/String;)Lcom/mojang/serialization/DataResult<Ljava/util/List<Ljava/lang/String;>;>; -
 method public,static resolvePath (Ljava/nio/file/Path;Ljava/util/List;)Ljava/nio/file/Path; (Ljava/nio/file/Path;Ljava/util/List<Ljava/lang/String;>;)Ljava/nio/file/Path; -
 method public,static isValidStrictPathSegment (Ljava/lang/String;)Z - -
 method public,static,varargs validatePath ([Ljava/lang/String;)V - -
 method public,static createDirectoriesSafe (Ljava/nio/file/Path;)V - java/io/IOException
in 2
class net/minecraft/IdentifierException 65 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 82
class net/minecraft/MethodsReturnNonnullByDefault 60 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 93
class net/minecraft/MethodsReturnNonnullByDefault 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 95
class net/minecraft/MethodsReturnNonnullByDefault 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 89
class net/minecraft/Optionull 61 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static map (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;)TR; -
 method public,static mapOrDefault (Ljava/lang/Object;Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;TR;)TR; -
 method public,static mapOrElse (Ljava/lang/Object;Ljava/util/function/Function;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;Ljava/util/function/Supplier<TR;>;)TR; -
 method public,static first (Ljava/util/Collection;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;)TT; -
 method public,static firstOrDefault (Ljava/util/Collection;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;TT;)TT; -
 method public,static firstOrElse (Ljava/util/Collection;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static isNullOrEmpty ([Ljava/lang/Object;)Z <T:Ljava/lang/Object;>([TT;)Z -
 method public,static isNullOrEmpty ([Z)Z - -
 method public,static isNullOrEmpty ([B)Z - -
 method public,static isNullOrEmpty ([C)Z - -
 method public,static isNullOrEmpty ([S)Z - -
 method public,static isNullOrEmpty ([I)Z - -
 method public,static isNullOrEmpty ([J)Z - -
 method public,static isNullOrEmpty ([F)Z - -
 method public,static isNullOrEmpty ([D)Z - -
in 94
class net/minecraft/Optionull 65 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static map (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;)TR; -
 method public,static mapOrDefault (Ljava/lang/Object;Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;TR;)TR; -
 method public,static mapOrElse (Ljava/lang/Object;Ljava/util/function/Function;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;Ljava/util/function/Supplier<TR;>;)TR; -
 method public,static first (Ljava/util/Collection;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;)TT; -
 method public,static firstOrDefault (Ljava/util/Collection;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;TT;)TT; -
 method public,static firstOrElse (Ljava/util/Collection;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static isNullOrEmpty ([Ljava/lang/Object;)Z <T:Ljava/lang/Object;>([TT;)Z -
 method public,static isNullOrEmpty ([Z)Z - -
 method public,static isNullOrEmpty ([B)Z - -
 method public,static isNullOrEmpty ([C)Z - -
 method public,static isNullOrEmpty ([S)Z - -
 method public,static isNullOrEmpty ([I)Z - -
 method public,static isNullOrEmpty ([J)Z - -
 method public,static isNullOrEmpty ([F)Z - -
 method public,static isNullOrEmpty ([D)Z - -
in 69
class net/minecraft/Optionull 65 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static,deprecated orElse (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;TT;)TT; -
 method public,static map (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;)TR; -
 method public,static mapOrDefault (Ljava/lang/Object;Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;TR;)TR; -
 method public,static mapOrElse (Ljava/lang/Object;Ljava/util/function/Function;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;Ljava/util/function/Supplier<TR;>;)TR; -
 method public,static first (Ljava/util/Collection;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;)TT; -
 method public,static firstOrDefault (Ljava/util/Collection;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;TT;)TT; -
 method public,static firstOrElse (Ljava/util/Collection;Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/Collection<TT;>;Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static isNullOrEmpty ([Ljava/lang/Object;)Z <T:Ljava/lang/Object;>([TT;)Z -
 method public,static isNullOrEmpty ([Z)Z - -
 method public,static isNullOrEmpty ([B)Z - -
 method public,static isNullOrEmpty ([C)Z - -
 method public,static isNullOrEmpty ([S)Z - -
 method public,static isNullOrEmpty ([I)Z - -
 method public,static isNullOrEmpty ([J)Z - -
 method public,static isNullOrEmpty ([F)Z - -
 method public,static isNullOrEmpty ([D)Z - -
in 260
class net/minecraft/ReportType 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CRASH Lnet/minecraft/ReportType; -
 field public,static,final PROFILE Lnet/minecraft/ReportType; -
 field public,static,final TEST Lnet/minecraft/ReportType; -
 field public,static,final NETWORK_PROTOCOL_ERROR Lnet/minecraft/ReportType; -
 field public,static,final CHUNK_IO_ERROR Lnet/minecraft/ReportType; -
 method public <init> (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/String;>;)V -
 method public getErrorComment ()Ljava/lang/String; - -
 method public appendHeader (Ljava/lang/StringBuilder;Ljava/util/List;)V (Ljava/lang/StringBuilder;Ljava/util/List<Ljava/lang/String;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public header ()Ljava/lang/String; - -
 method public nuggets ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
in 126
class net/minecraft/ReportedException 52 public,super java/lang/RuntimeException - -
 method public <init> (Lnet/minecraft/CrashReport;)V - -
 method public getReport ()Lnet/minecraft/CrashReport; - -
 method public getCause ()Ljava/lang/Throwable; - -
 method public getMessage ()Ljava/lang/String; - -
in 82
class net/minecraft/ReportedException 60 public,super java/lang/RuntimeException - -
 method public <init> (Lnet/minecraft/CrashReport;)V - -
 method public getReport ()Lnet/minecraft/CrashReport; - -
 method public getCause ()Ljava/lang/Throwable; - -
 method public getMessage ()Ljava/lang/String; - -
in 93
class net/minecraft/ReportedException 61 public,super java/lang/RuntimeException - -
 method public <init> (Lnet/minecraft/CrashReport;)V - -
 method public getReport ()Lnet/minecraft/CrashReport; - -
 method public getCause ()Ljava/lang/Throwable; - -
 method public getMessage ()Ljava/lang/String; - -
in 60
class net/minecraft/ReportedException 65 public,super java/lang/RuntimeException - -
 method public <init> (Lnet/minecraft/CrashReport;)V - -
 method public getReport ()Lnet/minecraft/CrashReport; - -
 method public getCause ()Ljava/lang/Throwable; - -
 method public getMessage ()Ljava/lang/String; - -
in 126
class net/minecraft/ResourceLocationException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 82
class net/minecraft/ResourceLocationException 60 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 93
class net/minecraft/ResourceLocationException 61 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 95
class net/minecraft/ResourceLocationException 65 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
in 131
class net/minecraft/SharedConstants 52 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
in 304
class net/minecraft/SharedConstants 52 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public,static filterUnicodeSupplementary (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getCurrentVersion ()Lcom/mojang/bridge/game/GameVersion; - -
in 463
class net/minecraft/SharedConstants 52 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterUnicodeSupplementary (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getCurrentVersion ()Lcom/mojang/bridge/game/GameVersion; - -
in 181
class net/minecraft/SharedConstants 52 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getCurrentVersion ()Lcom/mojang/bridge/game/GameVersion; - -
 method public,static getProtocolVersion ()I - -
in 104
class net/minecraft/SharedConstants 60 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I2730
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.17.1"
 field public,static,final,deprecated RELEASE_TARGET Ljava/lang/String; - "1.17.1"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I756
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I40
 field public,static,final SNBT_NAG_VERSION I - I2678
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I7
 field public,static,final,deprecated DATA_PACK_FORMAT I - I7
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final CNC_PART_2 Z - I0
 field public,static,final CNC_PART_2_ITEMS_AND_BLOCKS Z - I0
 field public,static,final NEW_WORLD_GENERATION Z - I0
 field public,static,final EXTENDED_WORLD_HEIGHT Z - I0
 field public,static,final AQUIFER_ENABLED_CARVERS Z - I0
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final ENABLE_SNOOPER Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final ALLOW_INCOMPATIBLE_WORLD_HEIGHT Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_NOISE_CAVES Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_NOODLE_CAVES Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final RAIN_THRESHOLD F - F0.15
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static setVersion (Lcom/mojang/bridge/game/GameVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lcom/mojang/bridge/game/GameVersion; - -
 method public,static getProtocolVersion ()I - -
in 84
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I2975
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.18.2"
 field public,static,final,deprecated RELEASE_TARGET Ljava/lang/String; - "1.18.2"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I758
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I73
 field public,static,final SNBT_NAG_VERSION I - I2965
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I8
 field public,static,final,deprecated DATA_PACK_FORMAT I - I9
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final CNC_PART_2_ITEMS_AND_BLOCKS Z - I0
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 83
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3120
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.19.2"
 field public,static,final,deprecated RELEASE_TARGET Ljava/lang/String; - "1.19.2"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I760
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I103
 field public,static,final SNBT_NAG_VERSION I - I3075
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I9
 field public,static,final,deprecated DATA_PACK_FORMAT I - I10
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final CNC_PART_2_ITEMS_AND_BLOCKS Z - I0
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATAFIXER_OPTIMIZATION_OPTION Lnet/minecraft/util/datafix/DataFixerOptimizationOption; -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 90
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3218
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.19.3"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I761
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I114
 field public,static,final SNBT_NAG_VERSION I - I3200
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I12
 field public,static,final,deprecated DATA_PACK_FORMAT I - I10
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATAFIXER_OPTIMIZATION_OPTION Lnet/minecraft/util/datafix/DataFixerOptimizationOption; -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 233
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3337
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.19.4"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I762
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I126
 field public,static,final SNBT_NAG_VERSION I - I3318
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I13
 field public,static,final,deprecated DATA_PACK_FORMAT I - I12
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 76
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3465
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.20.1"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I763
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I142
 field public,static,final SNBT_NAG_VERSION I - I3437
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I15
 field public,static,final,deprecated DATA_PACK_FORMAT I - I15
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 72
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3578
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.20.2"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I764
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I153
 field public,static,final SNBT_NAG_VERSION I - I3563
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I18
 field public,static,final,deprecated DATA_PACK_FORMAT I - I18
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 464
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3698
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.20.3"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I765
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I168
 field public,static,final SNBT_NAG_VERSION I - I3678
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I22
 field public,static,final,deprecated DATA_PACK_FORMAT I - I26
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 465
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3700
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.20.4"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I765
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I169
 field public,static,final SNBT_NAG_VERSION I - I3678
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I22
 field public,static,final,deprecated DATA_PACK_FORMAT I - I26
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 184
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3839
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.20.6"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I766
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I192
 field public,static,final SNBT_NAG_VERSION I - I3798
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I32
 field public,static,final,deprecated DATA_PACK_FORMAT I - I41
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 185
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3955
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.1"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I767
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I204
 field public,static,final SNBT_NAG_VERSION I - I3937
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I34
 field public,static,final,deprecated DATA_PACK_FORMAT I - I48
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 466
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4082
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.3"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I768
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I219
 field public,static,final SNBT_NAG_VERSION I - I4053
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I42
 field public,static,final,deprecated DATA_PACK_FORMAT I - I57
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 467
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4189
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.4"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I769
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I228
 field public,static,final SNBT_NAG_VERSION I - I4173
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I46
 field public,static,final,deprecated DATA_PACK_FORMAT I - I61
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 151
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4325
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.5"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I770
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I243
 field public,static,final SNBT_NAG_VERSION I - I4292
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I55
 field public,static,final,deprecated DATA_PACK_FORMAT I - I71
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_CURSOR_POS Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 152
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4435
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.6"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I771
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I256
 field public,static,final SNBT_NAG_VERSION I - I4420
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I63
 field public,static,final,deprecated DATA_PACK_FORMAT I - I80
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z - I0
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_CURSOR_POS Z - I0
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 153
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4440
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.8"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I772
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I259
 field public,static,final SNBT_NAG_VERSION I - I4420
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I64
 field public,static,final,deprecated DATA_PACK_FORMAT I - I81
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z - I0
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_CURSOR_POS Z - I0
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 120
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4556
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I773
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I274
 field public,static,final SNBT_NAG_VERSION I - I4531
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MAJOR I - I69
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MINOR I - I0
 field public,static,final,deprecated DATA_PACK_FORMAT_MAJOR I - I88
 field public,static,final,deprecated DATA_PACK_FORMAT_MINOR I - I0
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final RPC_MANAGEMENT_SERVER_API_VERSION Ljava/lang/String; - "1.0.0"
 field public,static,final DEBUG_FLAG_PREFIX Ljava/lang/String; - "MC_DEBUG_"
 field public,static,final DEBUG_ENABLED Z -
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z -
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z -
 field public,static,final DEBUG_HOTKEYS Z -
 field public,static,final DEBUG_UI_NARRATION Z -
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z -
 field public,static,final DEBUG_SHUFFLE_MODELS Z -
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z -
 field public,static,final DEBUG_PATHFINDING Z -
 field public,static,final DEBUG_WATER Z -
 field public,static,final DEBUG_HEIGHTMAP Z -
 field public,static,final DEBUG_COLLISION Z -
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z -
 field public,static,final DEBUG_SUPPORT_BLOCKS Z -
 field public,static,final DEBUG_SHAPES Z -
 field public,static,final DEBUG_NEIGHBORSUPDATE Z -
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z -
 field public,static,final DEBUG_STRUCTURES Z -
 field public,static,final DEBUG_LIGHT Z -
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z -
 field public,static,final DEBUG_SOLID_FACE Z -
 field public,static,final DEBUG_CHUNKS Z -
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z -
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z -
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z -
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z -
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z -
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z -
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z -
 field public,static,final DEBUG_NAMED_RUNNABLES Z -
 field public,static,final DEBUG_GOAL_SELECTOR Z -
 field public,static,final DEBUG_VILLAGE_SECTIONS Z -
 field public,static,final DEBUG_BRAIN Z -
 field public,static,final DEBUG_POI Z -
 field public,static,final DEBUG_BEES Z -
 field public,static,final DEBUG_RAIDS Z -
 field public,static,final DEBUG_BLOCK_BREAK Z -
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z -
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z -
 field public,static,final DEBUG_DONT_SAVE_WORLD Z -
 field public,static,final DEBUG_LARGE_DRIPSTONE Z -
 field public,static,final DEBUG_CARVERS Z -
 field public,static,final DEBUG_ORE_VEINS Z -
 field public,static,final DEBUG_SCULK_CATALYST Z -
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z -
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z -
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z -
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z -
 field public,static,final DEBUG_BREEZE_MOB Z -
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z -
 field public,static,final DEBUG_CURSOR_POS Z -
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z -
 field public,static,final DEBUG_PANORAMA_SCREENSHOT Z -
 field public,static,final DEBUG_CHASE_COMMAND Z -
 field public,static,final DEBUG_VERBOSE_COMMAND_ERRORS Z -
 field public,static,final DEBUG_DEV_COMMANDS Z -
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z -
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z -
 field public,static,final DEBUG_AQUIFERS Z -
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z -
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z -
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z -
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z -
 field public,static,final DEBUG_DISABLE_AQUIFERS Z -
 field public,static,final DEBUG_DISABLE_SURFACE Z -
 field public,static,final DEBUG_DISABLE_CARVERS Z -
 field public,static,final DEBUG_DISABLE_STRUCTURES Z -
 field public,static,final DEBUG_DISABLE_FEATURES Z -
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z -
 field public,static,final DEBUG_DISABLE_BLENDING Z -
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z -
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z -
 field public,static,final DEBUG_FAKE_LATENCY_MS I -
 field public,static,final DEBUG_FAKE_JITTER_MS I -
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z -
 field public,static,final DEBUG_WORLD_RECREATE Z -
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z -
 field public,static,final DEBUG_FEATURE_COUNT Z -
 field public,static,final DEBUG_FORCE_TELEMETRY Z -
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z -
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 121
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4671
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I774
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I286
 field public,static,final SNBT_NAG_VERSION I - I4650
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MAJOR I - I75
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MINOR I - I0
 field public,static,final,deprecated DATA_PACK_FORMAT_MAJOR I - I94
 field public,static,final,deprecated DATA_PACK_FORMAT_MINOR I - I1
 field public,static,final RPC_MANAGEMENT_SERVER_API_VERSION Ljava/lang/String; - "2.0.0"
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final DEBUG_FLAG_PREFIX Ljava/lang/String; - "MC_DEBUG_"
 field public,static,final DEBUG_ENABLED Z -
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z -
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z -
 field public,static,final DEBUG_HOTKEYS Z -
 field public,static,final DEBUG_UI_NARRATION Z -
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z -
 field public,static,final DEBUG_SHUFFLE_MODELS Z -
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z -
 field public,static,final DEBUG_PATHFINDING Z -
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z -
 field public,static,final DEBUG_SHAPES Z -
 field public,static,final DEBUG_NEIGHBORSUPDATE Z -
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z -
 field public,static,final DEBUG_STRUCTURES Z -
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z -
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z -
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z -
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z -
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z -
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z -
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z -
 field public,static,final DEBUG_NAMED_RUNNABLES Z -
 field public,static,final DEBUG_GOAL_SELECTOR Z -
 field public,static,final DEBUG_VILLAGE_SECTIONS Z -
 field public,static,final DEBUG_BRAIN Z -
 field public,static,final DEBUG_POI Z -
 field public,static,final DEBUG_BEES Z -
 field public,static,final DEBUG_RAIDS Z -
 field public,static,final DEBUG_BLOCK_BREAK Z -
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z -
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z -
 field public,static,final DEBUG_DONT_SAVE_WORLD Z -
 field public,static,final DEBUG_LARGE_DRIPSTONE Z -
 field public,static,final DEBUG_CARVERS Z -
 field public,static,final DEBUG_ORE_VEINS Z -
 field public,static,final DEBUG_SCULK_CATALYST Z -
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z -
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z -
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z -
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z -
 field public,static,final DEBUG_BREEZE_MOB Z -
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z -
 field public,static,final DEBUG_CURSOR_POS Z -
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z -
 field public,static,final DEBUG_PANORAMA_SCREENSHOT Z -
 field public,static,final DEBUG_CHASE_COMMAND Z -
 field public,static,final DEBUG_VERBOSE_COMMAND_ERRORS Z -
 field public,static,final DEBUG_DEV_COMMANDS Z -
 field public,static,final DEBUG_ACTIVE_TEXT_AREAS Z -
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z -
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z -
 field public,static,final DEBUG_AQUIFERS Z -
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z -
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z -
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z -
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z -
 field public,static,final DEBUG_DISABLE_AQUIFERS Z -
 field public,static,final DEBUG_DISABLE_SURFACE Z -
 field public,static,final DEBUG_DISABLE_CARVERS Z -
 field public,static,final DEBUG_DISABLE_STRUCTURES Z -
 field public,static,final DEBUG_DISABLE_FEATURES Z -
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z -
 field public,static,final DEBUG_DISABLE_BLENDING Z -
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z -
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z -
 field public,static,final DEBUG_FAKE_LATENCY_MS I -
 field public,static,final DEBUG_FAKE_JITTER_MS I -
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z -
 field public,static,final DEBUG_WORLD_RECREATE Z -
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z -
 field public,static,final DEBUG_FEATURE_COUNT Z -
 field public,static,final DEBUG_FORCE_TELEMETRY Z -
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z -
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final MAX_CLOUD_DISTANCE I - I128
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final DEFAULT_RANDOM_TICK_SPEED I - I3
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 135
class net/minecraft/SharedConstants 52 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
in 395
class net/minecraft/SharedConstants 52 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterUnicodeSupplementary (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getCurrentVersion ()Lcom/mojang/bridge/game/GameVersion; - -
in 190
class net/minecraft/SharedConstants 52 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getCurrentVersion ()Lcom/mojang/bridge/game/GameVersion; - -
 method public,static getProtocolVersion ()I - -
in 191
class net/minecraft/SharedConstants 61 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3700
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.20.4"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I765
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I169
 field public,static,final SNBT_NAG_VERSION I - I3678
 field public,static,final THROW_ON_TASK_FAILURE Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I22
 field public,static,final,deprecated DATA_PACK_FORMAT I - I26
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static filterText (Ljava/lang/String;Z)Ljava/lang/String; - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 192
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3839
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.20.6"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I766
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I192
 field public,static,final SNBT_NAG_VERSION I - I3798
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I32
 field public,static,final,deprecated DATA_PACK_FORMAT I - I41
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static DATA_FIX_TYPES_TO_OPTIMIZE Ljava/util/Set; Ljava/util/Set<Lcom/mojang/datafixers/DSL$TypeReference;>;
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
 method public,static enableDataFixerOptimizations ()V - -
in 193
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I3955
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.1"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I767
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I204
 field public,static,final SNBT_NAG_VERSION I - I3937
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I34
 field public,static,final,deprecated DATA_PACK_FORMAT I - I48
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 7
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4082
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.3"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I768
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I219
 field public,static,final SNBT_NAG_VERSION I - I4053
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I42
 field public,static,final,deprecated DATA_PACK_FORMAT I - I57
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 173
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4189
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.4"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I769
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I228
 field public,static,final SNBT_NAG_VERSION I - I4173
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I46
 field public,static,final,deprecated DATA_PACK_FORMAT I - I61
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 154
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4325
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.5"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I770
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I243
 field public,static,final SNBT_NAG_VERSION I - I4292
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I55
 field public,static,final,deprecated DATA_PACK_FORMAT I - I71
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_CURSOR_POS Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 155
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4435
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.6"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I771
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I256
 field public,static,final SNBT_NAG_VERSION I - I4420
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I63
 field public,static,final,deprecated DATA_PACK_FORMAT I - I80
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z - I0
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_CURSOR_POS Z - I0
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 122
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4440
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated VERSION_STRING Ljava/lang/String; - "1.21.8"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I772
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I259
 field public,static,final SNBT_NAG_VERSION I - I4420
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT I - I64
 field public,static,final,deprecated DATA_PACK_FORMAT I - I81
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z - I0
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z - I0
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z - I0
 field public,static,final DEBUG_SUPPORT_BLOCKS Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SCULK_CATALYST Z - I0
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z - I0
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z - I0
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z - I0
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z - I0
 field public,static,final DEBUG_BREEZE_MOB Z - I0
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z - I0
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z - I0
 field public,static,final DEBUG_CURSOR_POS Z - I0
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z - I0
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_AQUIFERS Z - I0
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z - I0
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z - I0
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static debugGenerateStripedTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_BLENDING Z - I0
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_FEATURE_COUNT Z - I0
 field public,static,final DEBUG_RESOURCE_GENERATION_OVERRIDE Z - I0
 field public,static,final DEBUG_FORCE_TELEMETRY Z - I0
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z - I0
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 123
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4556
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I773
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I274
 field public,static,final SNBT_NAG_VERSION I - I4531
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MAJOR I - I69
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MINOR I - I0
 field public,static,final,deprecated DATA_PACK_FORMAT_MAJOR I - I88
 field public,static,final,deprecated DATA_PACK_FORMAT_MINOR I - I0
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final RPC_MANAGEMENT_SERVER_API_VERSION Ljava/lang/String; - "1.0.0"
 field public,static,final DEBUG_FLAG_PREFIX Ljava/lang/String; - "MC_DEBUG_"
 field public,static,final DEBUG_ENABLED Z -
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z -
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z -
 field public,static,final DEBUG_HOTKEYS Z -
 field public,static,final DEBUG_UI_NARRATION Z -
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z -
 field public,static,final DEBUG_SHUFFLE_MODELS Z -
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z -
 field public,static,final DEBUG_PATHFINDING Z -
 field public,static,final DEBUG_WATER Z -
 field public,static,final DEBUG_HEIGHTMAP Z -
 field public,static,final DEBUG_COLLISION Z -
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z -
 field public,static,final DEBUG_SUPPORT_BLOCKS Z -
 field public,static,final DEBUG_SHAPES Z -
 field public,static,final DEBUG_NEIGHBORSUPDATE Z -
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z -
 field public,static,final DEBUG_STRUCTURES Z -
 field public,static,final DEBUG_LIGHT Z -
 field public,static,final DEBUG_SKY_LIGHT_SECTIONS Z -
 field public,static,final DEBUG_SOLID_FACE Z -
 field public,static,final DEBUG_CHUNKS Z -
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z -
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z -
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z -
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z -
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z -
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z -
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z -
 field public,static,final DEBUG_NAMED_RUNNABLES Z -
 field public,static,final DEBUG_GOAL_SELECTOR Z -
 field public,static,final DEBUG_VILLAGE_SECTIONS Z -
 field public,static,final DEBUG_BRAIN Z -
 field public,static,final DEBUG_POI Z -
 field public,static,final DEBUG_BEES Z -
 field public,static,final DEBUG_RAIDS Z -
 field public,static,final DEBUG_BLOCK_BREAK Z -
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z -
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z -
 field public,static,final DEBUG_DONT_SAVE_WORLD Z -
 field public,static,final DEBUG_LARGE_DRIPSTONE Z -
 field public,static,final DEBUG_CARVERS Z -
 field public,static,final DEBUG_ORE_VEINS Z -
 field public,static,final DEBUG_SCULK_CATALYST Z -
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z -
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z -
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z -
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z -
 field public,static,final DEBUG_BREEZE_MOB Z -
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z -
 field public,static,final DEBUG_CURSOR_POS Z -
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z -
 field public,static,final DEBUG_PANORAMA_SCREENSHOT Z -
 field public,static,final DEBUG_CHASE_COMMAND Z -
 field public,static,final DEBUG_VERBOSE_COMMAND_ERRORS Z -
 field public,static,final DEBUG_DEV_COMMANDS Z -
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z -
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z -
 field public,static,final DEBUG_AQUIFERS Z -
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z -
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z -
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z -
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z -
 field public,static,final DEBUG_DISABLE_AQUIFERS Z -
 field public,static,final DEBUG_DISABLE_SURFACE Z -
 field public,static,final DEBUG_DISABLE_CARVERS Z -
 field public,static,final DEBUG_DISABLE_STRUCTURES Z -
 field public,static,final DEBUG_DISABLE_FEATURES Z -
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z -
 field public,static,final DEBUG_DISABLE_BLENDING Z -
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z -
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z -
 field public,static,final DEBUG_FAKE_LATENCY_MS I -
 field public,static,final DEBUG_FAKE_JITTER_MS I -
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z -
 field public,static,final DEBUG_WORLD_RECREATE Z -
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z -
 field public,static,final DEBUG_FEATURE_COUNT Z -
 field public,static,final DEBUG_FORCE_TELEMETRY Z -
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z -
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 48
class net/minecraft/SharedConstants 65 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,deprecated SNAPSHOT Z - I0
 field public,static,final,deprecated WORLD_VERSION I - I4671
 field public,static,final,deprecated SERIES Ljava/lang/String; - "main"
 field public,static,final,deprecated RELEASE_NETWORK_PROTOCOL_VERSION I - I774
 field public,static,final,deprecated SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I286
 field public,static,final SNBT_NAG_VERSION I - I4650
 field public,static,final CRASH_EAGERLY Z - I0
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MAJOR I - I75
 field public,static,final,deprecated RESOURCE_PACK_FORMAT_MINOR I - I0
 field public,static,final,deprecated DATA_PACK_FORMAT_MAJOR I - I94
 field public,static,final,deprecated DATA_PACK_FORMAT_MINOR I - I1
 field public,static,final RPC_MANAGEMENT_SERVER_API_VERSION Ljava/lang/String; - "2.0.0"
 field public,static,final,deprecated LANGUAGE_FORMAT I - I1
 field public,static,final REPORT_FORMAT_VERSION I - I1
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final DEBUG_FLAG_PREFIX Ljava/lang/String; - "MC_DEBUG_"
 field public,static,final DEBUG_ENABLED Z -
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final DEBUG_OPEN_INCOMPATIBLE_WORLDS Z -
 field public,static,final DEBUG_ALLOW_LOW_SIM_DISTANCE Z -
 field public,static,final DEBUG_HOTKEYS Z -
 field public,static,final DEBUG_UI_NARRATION Z -
 field public,static,final DEBUG_SHUFFLE_UI_RENDERING_ORDER Z -
 field public,static,final DEBUG_SHUFFLE_MODELS Z -
 field public,static,final DEBUG_RENDER_UI_LAYERING_RECTANGLES Z -
 field public,static,final DEBUG_PATHFINDING Z -
 field public,static,final DEBUG_SHOW_LOCAL_SERVER_ENTITY_HIT_BOXES Z -
 field public,static,final DEBUG_SHAPES Z -
 field public,static,final DEBUG_NEIGHBORSUPDATE Z -
 field public,static,final DEBUG_EXPERIMENTAL_REDSTONEWIRE_UPDATE_ORDER Z -
 field public,static,final DEBUG_STRUCTURES Z -
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z -
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z -
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z -
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z -
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z -
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z -
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z -
 field public,static,final DEBUG_NAMED_RUNNABLES Z -
 field public,static,final DEBUG_GOAL_SELECTOR Z -
 field public,static,final DEBUG_VILLAGE_SECTIONS Z -
 field public,static,final DEBUG_BRAIN Z -
 field public,static,final DEBUG_POI Z -
 field public,static,final DEBUG_BEES Z -
 field public,static,final DEBUG_RAIDS Z -
 field public,static,final DEBUG_BLOCK_BREAK Z -
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z -
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z -
 field public,static,final DEBUG_DONT_SAVE_WORLD Z -
 field public,static,final DEBUG_LARGE_DRIPSTONE Z -
 field public,static,final DEBUG_CARVERS Z -
 field public,static,final DEBUG_ORE_VEINS Z -
 field public,static,final DEBUG_SCULK_CATALYST Z -
 field public,static,final DEBUG_BYPASS_REALMS_VERSION_CHECK Z -
 field public,static,final DEBUG_SOCIAL_INTERACTIONS Z -
 field public,static,final DEBUG_VALIDATE_RESOURCE_PATH_CASE Z -
 field public,static,final DEBUG_UNLOCK_ALL_TRADES Z -
 field public,static,final DEBUG_BREEZE_MOB Z -
 field public,static,final DEBUG_TRIAL_SPAWNER_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_VAULT_DETECTS_SHEEP_AS_PLAYERS Z -
 field public,static,final DEBUG_FORCE_ONBOARDING_SCREEN Z -
 field public,static,final DEBUG_CURSOR_POS Z -
 field public,static,final DEBUG_DEFAULT_SKIN_OVERRIDE Z -
 field public,static,final DEBUG_PANORAMA_SCREENSHOT Z -
 field public,static,final DEBUG_CHASE_COMMAND Z -
 field public,static,final DEBUG_VERBOSE_COMMAND_ERRORS Z -
 field public,static,final DEBUG_DEV_COMMANDS Z -
 field public,static,final DEBUG_ACTIVE_TEXT_AREAS Z -
 field public,static,final DEBUG_IGNORE_LOCAL_MOB_CAP Z -
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z -
 field public,static,final DEBUG_AQUIFERS Z -
 field public,static,final DEBUG_JFR_PROFILING_ENABLE_LEVEL_LOADING Z -
 field public,static,final DEBUG_ENTITY_BLOCK_INTERSECTION Z -
 field public,static debugGenerateSquareTerrainWithoutNoise Z -
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z -
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z -
 field public,static,final DEBUG_DISABLE_AQUIFERS Z -
 field public,static,final DEBUG_DISABLE_SURFACE Z -
 field public,static,final DEBUG_DISABLE_CARVERS Z -
 field public,static,final DEBUG_DISABLE_STRUCTURES Z -
 field public,static,final DEBUG_DISABLE_FEATURES Z -
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z -
 field public,static,final DEBUG_DISABLE_BLENDING Z -
 field public,static,final DEBUG_DISABLE_BELOW_ZERO_RETROGENERATION Z -
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final DEBUG_SUBTITLES Z -
 field public,static,final DEBUG_FAKE_LATENCY_MS I -
 field public,static,final DEBUG_FAKE_JITTER_MS I -
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z -
 field public,static,final DEBUG_WORLD_RECREATE Z -
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z -
 field public,static,final DEBUG_FEATURE_COUNT Z -
 field public,static,final DEBUG_FORCE_TELEMETRY Z -
 field public,static,final DEBUG_DONT_SEND_TELEMETRY_TO_BACKEND Z -
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static,final MAXIMUM_BLOCK_EXPLOSION_RESISTANCE F - F3600000.0
 field public,static,final USE_WORKFLOWS_HOOKS Z - I0
 field public,static,final USE_DEVONLY Z - I0
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final IS_RUNNING_WITH_JDWP Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_USER_INPUT_COMMAND_LENGTH I - I32500
 field public,static,final MAX_FUNCTION_COMMAND_LENGTH I - I2000000
 field public,static,final MAX_PLAYER_NAME_LENGTH I - I16
 field public,static,final MAX_CHAINED_NEIGHBOR_UPDATES I - I1000000
 field public,static,final MAX_RENDER_DISTANCE I - I32
 field public,static,final MAX_CLOUD_DISTANCE I - I128
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final MILLIS_PER_TICK I - I50
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final DEFAULT_RANDOM_TICK_SPEED I - I3
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 field public,static,final WORLD_ICON_SIZE I - I64
 method public <init> ()V - -
 method public,static setVersion (Lnet/minecraft/WorldVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lnet/minecraft/WorldVersion; - -
 method public,static getProtocolVersion ()I - -
 method public,static debugVoidTerrain (Lnet/minecraft/world/level/ChunkPos;)Z - -
in 108
class net/minecraft/SharedConstants 60 public,super java/lang/Object - -
 inner io/netty/util/ResourceLeakDetector$Level io/netty/util/ResourceLeakDetector Level public,static,final,enum
 field public,static,final SNAPSHOT Z - I0
 field public,static,final WORLD_VERSION I - I2730
 field public,static,final VERSION_STRING Ljava/lang/String; - "1.17.1"
 field public,static,final RELEASE_TARGET Ljava/lang/String; - "1.17.1"
 field public,static,final RELEASE_NETWORK_PROTOCOL_VERSION I - I756
 field public,static,final SNAPSHOT_NETWORK_PROTOCOL_VERSION I - I40
 field public,static,final SNBT_NAG_VERSION I - I2678
 field public,static,final RESOURCE_PACK_FORMAT I - I7
 field public,static,final DATA_PACK_FORMAT I - I7
 field public,static,final DATA_VERSION_TAG Ljava/lang/String; - "DataVersion"
 field public,static,final CNC_PART_2 Z - I0
 field public,static,final CNC_PART_2_ITEMS_AND_BLOCKS Z - I0
 field public,static,final NEW_WORLD_GENERATION Z - I0
 field public,static,final EXTENDED_WORLD_HEIGHT Z - I0
 field public,static,final AQUIFER_ENABLED_CARVERS Z - I0
 field public,static,final USE_NEW_RENDERSYSTEM Z - I0
 field public,static,final MULTITHREADED_RENDERING Z - I0
 field public,static,final FIX_TNT_DUPE Z - I0
 field public,static,final FIX_SAND_DUPE Z - I0
 field public,static,final ENABLE_SNOOPER Z - I0
 field public,static,final USE_DEBUG_FEATURES Z - I0
 field public,static,final ALLOW_INCOMPATIBLE_WORLD_HEIGHT Z - I0
 field public,static,final DEBUG_HOTKEYS Z - I0
 field public,static,final DEBUG_UI_NARRATION Z - I0
 field public,static,final DEBUG_RENDER Z - I0
 field public,static,final DEBUG_PATHFINDING Z - I0
 field public,static,final DEBUG_WATER Z - I0
 field public,static,final DEBUG_HEIGHTMAP Z - I0
 field public,static,final DEBUG_COLLISION Z - I0
 field public,static,final DEBUG_SHAPES Z - I0
 field public,static,final DEBUG_NEIGHBORSUPDATE Z - I0
 field public,static,final DEBUG_STRUCTURES Z - I0
 field public,static,final DEBUG_LIGHT Z - I0
 field public,static,final DEBUG_WORLDGENATTEMPT Z - I0
 field public,static,final DEBUG_SOLID_FACE Z - I0
 field public,static,final DEBUG_CHUNKS Z - I0
 field public,static,final DEBUG_GAME_EVENT_LISTENERS Z - I0
 field public,static,final DEBUG_DUMP_TEXTURE_ATLAS Z - I0
 field public,static,final DEBUG_DUMP_INTERPOLATED_TEXTURE_FRAMES Z - I0
 field public,static,final DEBUG_STRUCTURE_EDIT_MODE Z - I0
 field public,static,final DEBUG_SAVE_STRUCTURES_AS_SNBT Z - I0
 field public,static,final DEBUG_SYNCHRONOUS_GL_LOGS Z - I0
 field public,static,final DEBUG_VERBOSE_SERVER_EVENTS Z - I0
 field public,static,final DEBUG_NAMED_RUNNABLES Z - I0
 field public,static,final DEBUG_GOAL_SELECTOR Z - I0
 field public,static,final DEBUG_VILLAGE_SECTIONS Z - I0
 field public,static,final DEBUG_BRAIN Z - I0
 field public,static,final DEBUG_BEES Z - I0
 field public,static,final DEBUG_RAIDS Z - I0
 field public,static,final DEBUG_BLOCK_BREAK Z - I0
 field public,static,final DEBUG_RESOURCE_LOAD_TIMES Z - I0
 field public,static,final DEBUG_MONITOR_TICK_TIMES Z - I0
 field public,static,final DEBUG_KEEP_JIGSAW_BLOCKS_DURING_STRUCTURE_GEN Z - I0
 field public,static,final DEBUG_DONT_SAVE_WORLD Z - I0
 field public,static,final DEBUG_LARGE_DRIPSTONE Z - I0
 field public,static,final DEBUG_PACKET_SERIALIZATION Z - I0
 field public,static,final DEBUG_CARVERS Z - I0
 field public,static,final DEBUG_ORE_VEINS Z - I0
 field public,static,final DEBUG_SMALL_SPAWN Z - I0
 field public,static,final DEBUG_DISABLE_LIQUID_SPREADING Z - I0
 field public,static,final DEBUG_ONLY_GENERATE_HALF_THE_WORLD Z - I0
 field public,static,final DEBUG_DISABLE_FLUID_GENERATION Z - I0
 field public,static,final DEBUG_DISABLE_AQUIFERS Z - I0
 field public,static,final DEBUG_DISABLE_NOISE_CAVES Z - I0
 field public,static,final DEBUG_DISABLE_SURFACE Z - I0
 field public,static,final DEBUG_DISABLE_CARVERS Z - I0
 field public,static,final DEBUG_DISABLE_STRUCTURES Z - I0
 field public,static,final DEBUG_DISABLE_FEATURES Z - I0
 field public,static,final DEBUG_DISABLE_ORE_VEINS Z - I0
 field public,static,final DEBUG_DISABLE_NOODLE_CAVES Z - I0
 field public,static,final DEFAULT_MINECRAFT_PORT I - I25565
 field public,static,final INGAME_DEBUG_OUTPUT Z - I0
 field public,static,final DEBUG_SUBTITLES Z - I0
 field public,static,final FAKE_MS_LATENCY I - I0
 field public,static,final FAKE_MS_JITTER I - I0
 field public,static,final NETTY_LEAK_DETECTION Lio/netty/util/ResourceLeakDetector$Level; -
 field public,static,final COMMAND_STACK_TRACES Z - I0
 field public,static,final DEBUG_WORLD_RECREATE Z - I0
 field public,static,final DEBUG_SHOW_SERVER_DEBUG_VALUES Z - I0
 field public,static,final DEBUG_STORE_CHUNK_STACKTRACES Z - I0
 field public,static,final RAIN_THRESHOLD F - F0.15
 field public,static,final MAXIMUM_TICK_TIME_NANOS J -
 field public,static CHECK_DATA_FIXER_SCHEMA Z -
 field public,static IS_RUNNING_IN_IDE Z -
 field public,static,final WORLD_RESOLUTION I - I16
 field public,static,final MAX_CHAT_LENGTH I - I256
 field public,static,final MAX_COMMAND_LENGTH I - I32500
 field public,static,final ILLEGAL_FILE_CHARACTERS [C -
 field public,static,final TICKS_PER_SECOND I - I20
 field public,static,final TICKS_PER_MINUTE I - I1200
 field public,static,final TICKS_PER_GAME_DAY I - I24000
 field public,static,final AVERAGE_GAME_TICKS_PER_RANDOM_TICK_PER_BLOCK F - F1365.3334
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_MINUTE F - F0.87890625
 field public,static,final AVERAGE_RANDOM_TICKS_PER_BLOCK_PER_GAME_DAY F - F17.578125
 method public <init> ()V - -
 method public,static isAllowedChatCharacter (C)Z - -
 method public,static filterText (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static setVersion (Lcom/mojang/bridge/game/GameVersion;)V - -
 method public,static tryDetectVersion ()V - -
 method public,static getCurrentVersion ()Lcom/mojang/bridge/game/GameVersion; - -
 method public,static getProtocolVersion ()I - -
in 28
class net/minecraft/SuppressForbidden 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#CONSTRUCTOR,ELjava/lang/annotation/ElementType;#FIELD,ELjava/lang/annotation/ElementType;#METHOD,ELjava/lang/annotation/ElementType;#TYPE])
 method public,abstract reason ()Ljava/lang/String; - -
in 82
class net/minecraft/SystemReport 60 public,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BYTES_PER_MEBIBYTE J - J1048576
 method public <init> ()V - -
 method public setDetail (Ljava/lang/String;Ljava/lang/String;)V - -
 method public setDetail (Ljava/lang/String;Ljava/util/function/Supplier;)V (Ljava/lang/String;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public appendToCrashReportString (Ljava/lang/StringBuilder;)V - -
 method public toLineSeparatedString ()Ljava/lang/String; - -
in 93
class net/minecraft/SystemReport 61 public,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BYTES_PER_MEBIBYTE J - J1048576
 method public <init> ()V - -
 method public setDetail (Ljava/lang/String;Ljava/lang/String;)V - -
 method public setDetail (Ljava/lang/String;Ljava/util/function/Supplier;)V (Ljava/lang/String;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public appendToCrashReportString (Ljava/lang/StringBuilder;)V - -
 method public toLineSeparatedString ()Ljava/lang/String; - -
in 224
class net/minecraft/SystemReport 65 public,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BYTES_PER_MEBIBYTE J - J1048576
 method public <init> ()V - -
 method public setDetail (Ljava/lang/String;Ljava/lang/String;)V - -
 method public setDetail (Ljava/lang/String;Ljava/util/function/Supplier;)V (Ljava/lang/String;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public appendToCrashReportString (Ljava/lang/StringBuilder;)V - -
 method public toLineSeparatedString ()Ljava/lang/String; - -
in 260
class net/minecraft/SystemReport 65 public,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final BYTES_PER_MEBIBYTE J - J1048576
 method public <init> ()V - -
 method public setDetail (Ljava/lang/String;Ljava/lang/String;)V - -
 method public setDetail (Ljava/lang/String;Ljava/util/function/Supplier;)V (Ljava/lang/String;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public,static sizeInMiB (J)F - -
 method public appendToCrashReportString (Ljava/lang/StringBuilder;)V - -
 method public toLineSeparatedString ()Ljava/lang/String; - -
in 69
class net/minecraft/TracingExecutor 65 public,final,super java/lang/Record java/util/concurrent/Executor -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/concurrent/ExecutorService;)V - -
 method public forName (Ljava/lang/String;)Ljava/util/concurrent/Executor; - -
 method public execute (Ljava/lang/Runnable;)V - -
 method public shutdownAndAwait (JLjava/util/concurrent/TimeUnit;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public service ()Ljava/util/concurrent/ExecutorService; - -
in 59
class net/minecraft/Util 52 public,super java/lang/Object - -
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static a (Ljava/nio/file/Path;)Z - -
 method public,static b (Ljava/nio/file/Path;)Z - -
 method public,static a (Ljava/nio/file/Path;Ljava/lang/String;Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public,static a (Ljava/util/concurrent/FutureTask;Lorg/apache/logging/log4j/Logger;)Ljava/lang/Object; <V:Ljava/lang/Object;>(Ljava/util/concurrent/FutureTask<TV;>;Lorg/apache/logging/log4j/Logger;)TV; -
 method public,static a (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
in 304
class net/minecraft/Util 52 public,super java/lang/Object - -
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static shutdownBackgroundExecutor ()V - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static toStream (Ljava/util/Optional;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/Optional<+TT;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static readUUID (Ljava/lang/String;Lcom/mojang/datafixers/Dynamic;)Ljava/util/Optional; (Ljava/lang/String;Lcom/mojang/datafixers/Dynamic<*>;)Ljava/util/Optional<Ljava/util/UUID;>; -
 method public,static writeUUID (Ljava/lang/String;Ljava/util/UUID;Lcom/mojang/datafixers/Dynamic;)Lcom/mojang/datafixers/Dynamic; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/UUID;Lcom/mojang/datafixers/Dynamic<TT;>;)Lcom/mojang/datafixers/Dynamic<TT;>; -
in 308
class net/minecraft/Util 52 public,super java/lang/Object - -
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static shutdownBackgroundExecutor ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static toStream (Ljava/util/Optional;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/Optional<+TT;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static readUUID (Ljava/lang/String;Lcom/mojang/datafixers/Dynamic;)Ljava/util/Optional; (Ljava/lang/String;Lcom/mojang/datafixers/Dynamic<*>;)Ljava/util/Optional<Ljava/util/UUID;>; -
 method public,static writeUUID (Ljava/lang/String;Ljava/util/UUID;Lcom/mojang/datafixers/Dynamic;)Lcom/mojang/datafixers/Dynamic; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/UUID;Lcom/mojang/datafixers/Dynamic<TT;>;)Lcom/mojang/datafixers/Dynamic<TT;>; -
in 115
class net/minecraft/Util 52 public,super java/lang/Object - -
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static shutdownBackgroundExecutor ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static toStream (Ljava/util/Optional;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/Optional<+TT;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static readUUID (Ljava/lang/String;Lcom/mojang/datafixers/Dynamic;)Ljava/util/Optional; (Ljava/lang/String;Lcom/mojang/datafixers/Dynamic<*>;)Ljava/util/Optional<Ljava/util/UUID;>; -
 method public,static writeUUID (Ljava/lang/String;Ljava/util/UUID;Lcom/mojang/datafixers/Dynamic;)Lcom/mojang/datafixers/Dynamic; <T:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/UUID;Lcom/mojang/datafixers/Dynamic<TT;>;)Lcom/mojang/datafixers/Dynamic<TT;>; -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
in 181
class net/minecraft/Util 52 public,super java/lang/Object - -
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static ioPool ()Ljava/util/concurrent/Executor; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static toStream (Ljava/util/Optional;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/Optional<+TT;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Ljava/util/Random;)TT; -
 method public,static getRandom ([ILjava/util/Random;)I - -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
in 104
class net/minecraft/Util 60 public,super java/lang/Object - -
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static ioPool ()Ljava/util/concurrent/Executor; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static toStream (Ljava/util/Optional;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/Optional<+TT;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Ljava/util/Random;)TT; -
 method public,static getRandom ([ILjava/util/Random;)I - -
 method public,static getRandom (Ljava/util/List;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/Random;)TT; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
in 105
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Ljava/util/Random;)TT; -
 method public,static getRandom ([ILjava/util/Random;)I - -
 method public,static getRandom (Ljava/util/List;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/Random;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Ljava/util/Random;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/Random;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
in 231
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;)TR; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;TR;)TR; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
in 203
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;)TR; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;TR;)TR; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
in 204
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
in 205
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
 method public,static isWhitespace (I)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
in 310
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
 method public,static isWhitespace (I)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
in 116
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static nonCriticalIoPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Throwable;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Throwable
 method public,static getPartialOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Throwable;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Throwable
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static isWhitespace (I)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
in 224
class net/minecraft/Util 65 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LINEAR_LOOKUP_THRESHOLD I - I8
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static toMutableList ()Ljava/util/stream/Collector; <T:Ljava/lang/Object;>()Ljava/util/stream/Collector<TT;*Ljava/util/List<TT;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static nonCriticalIoPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getRegisteredName (Lnet/minecraft/core/Registry;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TT;>;TT;)Ljava/lang/String; -
 method public,static allOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static copyAndAdd (Ljava/util/List;Ljava/lang/Object;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;TT;)Ljava/util/List<TT;>; -
 method public,static copyAndAdd (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(TT;Ljava/util/List<TT;>;)Ljava/util/List<TT;>; -
 method public,static copyAndPut (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/Map<TK;TV;>;TK;TV;)Ljava/util/Map<TK;TV;>; -
in 235
class net/minecraft/Util 65 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LINEAR_LOOKUP_THRESHOLD I - I8
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static toMutableList ()Ljava/util/stream/Collector; <T:Ljava/lang/Object;>()Ljava/util/stream/Collector<TT;*Ljava/util/List<TT;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static nonCriticalIoPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getRegisteredName (Lnet/minecraft/core/Registry;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TT;>;TT;)Ljava/lang/String; -
 method public,static allOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static isSymmetrical (IILjava/util/List;)Z <T:Ljava/lang/Object;>(IILjava/util/List<TT;>;)Z -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static parseAndValidateUntrustedUri (Ljava/lang/String;)Ljava/net/URI; - java/net/URISyntaxException
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static copyAndAdd (Ljava/util/List;Ljava/lang/Object;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;TT;)Ljava/util/List<TT;>; -
 method public,static copyAndAdd (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(TT;Ljava/util/List<TT;>;)Ljava/util/List<TT;>; -
 method public,static copyAndPut (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/Map<TK;TV;>;TK;TV;)Ljava/util/Map<TK;TV;>; -
in 70
class net/minecraft/Util 65 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LINEAR_LOOKUP_THRESHOLD I - I8
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static toMutableList ()Ljava/util/stream/Collector; <T:Ljava/lang/Object;>()Ljava/util/stream/Collector<TT;*Ljava/util/List<TT;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Lnet/minecraft/TracingExecutor; - -
 method public,static ioPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static nonCriticalIoPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static runNamed (Ljava/lang/Runnable;Ljava/lang/String;)V - -
 method public,static getRegisteredName (Lnet/minecraft/core/Registry;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TT;>;TT;)Ljava/lang/String; -
 method public,static allOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs allOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs anyOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static isSymmetrical (IILjava/util/List;)Z <T:Ljava/lang/Object;>(IILjava/util/List<TT;>;)Z -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static parseAndValidateUntrustedUri (Ljava/lang/String;)Ljava/net/URI; - java/net/URISyntaxException
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static makeEnumMap (Ljava/lang/Class;Ljava/util/function/Function;)Ljava/util/EnumMap; <K:Ljava/lang/Enum<TK;>;V:Ljava/lang/Object;>(Ljava/lang/Class<TK;>;Ljava/util/function/Function<TK;TV;>;)Ljava/util/EnumMap<TK;TV;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static copyAndAdd (Ljava/util/List;Ljava/lang/Object;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;TT;)Ljava/util/List<TT;>; -
 method public,static copyAndAdd (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(TT;Ljava/util/List<TT;>;)Ljava/util/List<TT;>; -
 method public,static copyAndPut (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/Map<TK;TV;>;TK;TV;)Ljava/util/Map<TK;TV;>; -
in 201
class net/minecraft/Util 65 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LINEAR_LOOKUP_THRESHOLD I - I8
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static toMutableList ()Ljava/util/stream/Collector; <T:Ljava/lang/Object;>()Ljava/util/stream/Collector<TT;*Ljava/util/List<TT;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static maxAllowedExecutorThreads ()I - -
 method public,static backgroundExecutor ()Lnet/minecraft/TracingExecutor; - -
 method public,static ioPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static nonCriticalIoPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static runNamed (Ljava/lang/Runnable;Ljava/lang/String;)V - -
 method public,static getRegisteredName (Lnet/minecraft/core/Registry;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TT;>;TT;)Ljava/lang/String; -
 method public,static allOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs allOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs anyOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static isSymmetrical (IILjava/util/List;)Z <T:Ljava/lang/Object;>(IILjava/util/List<TT;>;)Z -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static parseAndValidateUntrustedUri (Ljava/lang/String;)Ljava/net/URI; - java/net/URISyntaxException
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static makeEnumMap (Ljava/lang/Class;Ljava/util/function/Function;)Ljava/util/EnumMap; <K:Ljava/lang/Enum<TK;>;V:Ljava/lang/Object;>(Ljava/lang/Class<TK;>;Ljava/util/function/Function<TK;TV;>;)Ljava/util/EnumMap<TK;TV;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static copyAndAdd (Ljava/util/List;Ljava/lang/Object;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;TT;)Ljava/util/List<TT;>; -
 method public,static copyAndAdd (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(TT;Ljava/util/List<TT;>;)Ljava/util/List<TT;>; -
 method public,static copyAndPut (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/Map<TK;TV;>;TK;TV;)Ljava/util/Map<TK;TV;>; -
in 468
class net/minecraft/Util 65 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LINEAR_LOOKUP_THRESHOLD I - I8
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static toMutableList ()Ljava/util/stream/Collector; <T:Ljava/lang/Object;>()Ljava/util/stream/Collector<TT;*Ljava/util/List<TT;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static maxAllowedExecutorThreads ()I - -
 method public,static backgroundExecutor ()Lnet/minecraft/TracingExecutor; - -
 method public,static ioPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static nonCriticalIoPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static runNamed (Ljava/lang/Runnable;Ljava/lang/String;)V - -
 method public,static getRegisteredName (Lnet/minecraft/core/Registry;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TT;>;TT;)Ljava/lang/String; -
 method public,static allOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs allOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs anyOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static isSymmetrical (IILjava/util/List;)Z <T:Ljava/lang/Object;>(IILjava/util/List<TT;>;)Z -
 method public,static growByHalf (II)I - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static parseAndValidateUntrustedUri (Ljava/lang/String;)Ljava/net/URI; - java/net/URISyntaxException
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static makeEnumMap (Ljava/lang/Class;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Enum<TK;>;V:Ljava/lang/Object;>(Ljava/lang/Class<TK;>;Ljava/util/function/Function<TK;TV;>;)Ljava/util/Map<TK;TV;>; -
 method public,static mapValues (Ljava/util/Map;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Object;V1:Ljava/lang/Object;V2:Ljava/lang/Object;>(Ljava/util/Map<TK;TV1;>;Ljava/util/function/Function<-TV1;TV2;>;)Ljava/util/Map<TK;TV2;>; -
 method public,static mapValuesLazy (Ljava/util/Map;Lcom/google/common/base/Function;)Ljava/util/Map; <K:Ljava/lang/Object;V1:Ljava/lang/Object;V2:Ljava/lang/Object;>(Ljava/util/Map<TK;TV1;>;Lcom/google/common/base/Function<TV1;TV2;>;)Ljava/util/Map<TK;TV2;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static copyAndAdd (Ljava/util/List;Ljava/lang/Object;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;TT;)Ljava/util/List<TT;>; -
 method public,static copyAndAdd (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(TT;Ljava/util/List<TT;>;)Ljava/util/List<TT;>; -
 method public,static copyAndPut (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/Map<TK;TV;>;TK;TV;)Ljava/util/Map<TK;TV;>; -
in 97
class net/minecraft/Util 65 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LINEAR_LOOKUP_THRESHOLD I - I8
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static toMutableList ()Ljava/util/stream/Collector; <T:Ljava/lang/Object;>()Ljava/util/stream/Collector<TT;*Ljava/util/List<TT;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static maxAllowedExecutorThreads ()I - -
 method public,static backgroundExecutor ()Lnet/minecraft/TracingExecutor; - -
 method public,static ioPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static nonCriticalIoPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static runNamed (Ljava/lang/Runnable;Ljava/lang/String;)V - -
 method public,static getRegisteredName (Lnet/minecraft/core/Registry;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TT;>;TT;)Ljava/lang/String; -
 method public,static allOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs allOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs anyOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static isSymmetrical (IILjava/util/List;)Z <T:Ljava/lang/Object;>(IILjava/util/List<TT;>;)Z -
 method public,static growByHalf (II)I - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static isAarch64 ()Z - -
 method public,static parseAndValidateUntrustedUri (Ljava/lang/String;)Ljava/net/URI; - java/net/URISyntaxException
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static makeEnumMap (Ljava/lang/Class;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Enum<TK;>;V:Ljava/lang/Object;>(Ljava/lang/Class<TK;>;Ljava/util/function/Function<TK;TV;>;)Ljava/util/Map<TK;TV;>; -
 method public,static mapValues (Ljava/util/Map;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Object;V1:Ljava/lang/Object;V2:Ljava/lang/Object;>(Ljava/util/Map<TK;TV1;>;Ljava/util/function/Function<-TV1;TV2;>;)Ljava/util/Map<TK;TV2;>; -
 method public,static mapValuesLazy (Ljava/util/Map;Lcom/google/common/base/Function;)Ljava/util/Map; <K:Ljava/lang/Object;V1:Ljava/lang/Object;V2:Ljava/lang/Object;>(Ljava/util/Map<TK;TV1;>;Lcom/google/common/base/Function<TV1;TV2;>;)Ljava/util/Map<TK;TV2;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static copyAndAdd (Ljava/util/List;Ljava/lang/Object;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;TT;)Ljava/util/List<TT;>; -
 method public,static copyAndAdd (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(TT;Ljava/util/List<TT;>;)Ljava/util/List<TT;>; -
 method public,static copyAndPut (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/Map<TK;TV;>;TK;TV;)Ljava/util/Map<TK;TV;>; -
in 98
class net/minecraft/Util 65 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner com/google/common/collect/ImmutableList$Builder com/google/common/collect/ImmutableList Builder public,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final LINEAR_LOOKUP_THRESHOLD I - I8
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static toMutableList ()Ljava/util/stream/Collector; <T:Ljava/lang/Object;>()Ljava/util/stream/Collector<TT;*Ljava/util/List<TT;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static maxAllowedExecutorThreads ()I - -
 method public,static backgroundExecutor ()Lnet/minecraft/TracingExecutor; - -
 method public,static ioPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static nonCriticalIoPool ()Lnet/minecraft/TracingExecutor; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static runNamed (Ljava/lang/Runnable;Ljava/lang/String;)V - -
 method public,static getRegisteredName (Lnet/minecraft/core/Registry;Ljava/lang/Object;)Ljava/lang/String; <T:Ljava/lang/Object;>(Lnet/minecraft/core/Registry<TT;>;TT;)Ljava/lang/String; -
 method public,static allOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs allOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static allOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf ()Ljava/util/function/Predicate; <T:Ljava/lang/Object;>()Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static,varargs anyOf ([Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>([Ljava/util/function/Predicate<-TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static anyOf (Ljava/util/List;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/function/Predicate<-TT;>;>;)Ljava/util/function/Predicate<TT;>; -
 method public,static isSymmetrical (IILjava/util/List;)Z <T:Ljava/lang/Object;>(IILjava/util/List<TT;>;)Z -
 method public,static growByHalf (II)I - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static isAarch64 ()Z - -
 method public,static parseAndValidateUntrustedUri (Ljava/lang/String;)Ljava/net/URI; - java/net/URISyntaxException
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static makeEnumMap (Ljava/lang/Class;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Enum<TK;>;V:Ljava/lang/Object;>(Ljava/lang/Class<TK;>;Ljava/util/function/Function<TK;TV;>;)Ljava/util/Map<TK;TV;>; -
 method public,static mapValues (Ljava/util/Map;Ljava/util/function/Function;)Ljava/util/Map; <K:Ljava/lang/Object;V1:Ljava/lang/Object;V2:Ljava/lang/Object;>(Ljava/util/Map<TK;TV1;>;Ljava/util/function/Function<-TV1;TV2;>;)Ljava/util/Map<TK;TV2;>; -
 method public,static mapValuesLazy (Ljava/util/Map;Lcom/google/common/base/Function;)Ljava/util/Map; <K:Ljava/lang/Object;V1:Ljava/lang/Object;V2:Ljava/lang/Object;>(Ljava/util/Map<TK;TV1;>;Lcom/google/common/base/Function<TV1;TV2;>;)Ljava/util/Map<TK;TV2;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)Z - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Ljava/util/List;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexIdentityLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static writeAndReadTypedOrThrow (Lcom/mojang/datafixers/Typed;Lcom/mojang/datafixers/types/Type;Ljava/util/function/UnaryOperator;)Lcom/mojang/datafixers/Typed; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lcom/mojang/datafixers/Typed<TA;>;Lcom/mojang/datafixers/types/Type<TB;>;Ljava/util/function/UnaryOperator<Lcom/mojang/serialization/Dynamic<*>;>;)Lcom/mojang/datafixers/Typed<TB;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static readTypedOrThrow (Lcom/mojang/datafixers/types/Type;Lcom/mojang/serialization/Dynamic;Z)Lcom/mojang/datafixers/Typed; <T:Ljava/lang/Object;>(Lcom/mojang/datafixers/types/Type<TT;>;Lcom/mojang/serialization/Dynamic<*>;Z)Lcom/mojang/datafixers/Typed<TT;>; -
 method public,static copyAndAdd (Ljava/util/List;Ljava/lang/Object;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;TT;)Ljava/util/List<TT;>; -
 method public,static copyAndAdd (Ljava/lang/Object;Ljava/util/List;)Ljava/util/List; <T:Ljava/lang/Object;>(TT;Ljava/util/List<TT;>;)Ljava/util/List<TT;>; -
 method public,static copyAndPut (Ljava/util/Map;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/Map<TK;TV;>;TK;TV;)Ljava/util/Map<TK;TV;>; -
in 190
class net/minecraft/Util 52 public,super java/lang/Object - -
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static ioPool ()Ljava/util/concurrent/Executor; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static toStream (Ljava/util/Optional;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/Optional<+TT;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Ljava/util/Random;)TT; -
 method public,static getRandom ([ILjava/util/Random;)I - -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
in 108
class net/minecraft/Util 60 public,super java/lang/Object - -
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy private,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/Executor; - -
 method public,static ioPool ()Ljava/util/concurrent/Executor; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static toStream (Ljava/util/Optional;)Ljava/util/stream/Stream; <T:Ljava/lang/Object;>(Ljava/util/Optional<+TT;>;)Ljava/util/stream/Stream<TT;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Ljava/util/Random;)TT; -
 method public,static getRandom ([ILjava/util/Random;)I - -
 method public,static getRandom (Ljava/util/List;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/Random;)TT; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
in 109
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy private,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Ljava/util/function/LongSupplier; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Ljava/util/Random;)TT; -
 method public,static getRandom ([ILjava/util/Random;)I - -
 method public,static getRandom (Ljava/util/List;Ljava/util/Random;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/Random;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Ljava/util/Random;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/Random;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
in 232
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy private,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static failedFuture (Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/lang/Throwable;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;)TR; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;TR;)TR; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
in 210
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy private,static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static bootstrapExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;)TR; -
 method public,static mapNullable (Ljava/lang/Object;Ljava/util/function/Function;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(TT;Ljava/util/function/Function<TT;TR;>;TR;)TR; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
in 211
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy private,static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
in 314
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy private,static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
 method public,static isWhitespace (I)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
in 315
class net/minecraft/Util 61 public,super java/lang/Object - -
 inner net/minecraft/util/TimeSource$NanoTimeSource net/minecraft/util/TimeSource NanoTimeSource public,static,interface,abstract
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy private,static,final,enum
 inner com/mojang/serialization/DataResult$PartialResult com/mojang/serialization/DataResult PartialResult public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NANOS_PER_MILLI J - J1000000
 field public,static timeSource Lnet/minecraft/util/TimeSource$NanoTimeSource; -
 field public,static,final TICKER Lcom/google/common/base/Ticker; -
 field public,static,final NIL_UUID Ljava/util/UUID; -
 field public,static,final ZIP_FILE_SYSTEM_PROVIDER Ljava/nio/file/spi/FileSystemProvider; -
 method public <init> ()V - -
 method public,static toMap ()Ljava/util/stream/Collector; <K:Ljava/lang/Object;V:Ljava/lang/Object;>()Ljava/util/stream/Collector<Ljava/util/Map$Entry<+TK;+TV;>;*Ljava/util/Map<TK;TV;>;>; -
 method public,static getPropertyName (Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Object;)Ljava/lang/String; <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/lang/Object;)Ljava/lang/String; -
 method public,static makeDescriptionId (Ljava/lang/String;Lnet/minecraft/resources/ResourceLocation;)Ljava/lang/String; - -
 method public,static getMillis ()J - -
 method public,static getNanos ()J - -
 method public,static getEpochMillis ()J - -
 method public,static getFilenameFormattedDateTime ()Ljava/lang/String; - -
 method public,static backgroundExecutor ()Ljava/util/concurrent/ExecutorService; - -
 method public,static ioPool ()Ljava/util/concurrent/ExecutorService; - -
 method public,static shutdownExecutors ()V - -
 method public,static throwAsRuntime (Ljava/lang/Throwable;)V - -
 method public,static fetchChoiceType (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type; (Lcom/mojang/datafixers/DSL$TypeReference;Ljava/lang/String;)Lcom/mojang/datafixers/types/Type<*>; -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,static wrapThreadWithTaskName (Ljava/lang/String;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <V:Ljava/lang/Object;>(Ljava/lang/String;Ljava/util/function/Supplier<TV;>;)Ljava/util/function/Supplier<TV;>; -
 method public,static getPlatform ()Lnet/minecraft/Util$OS; - -
 method public,static getVmArguments ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Ljava/lang/String;>; -
 method public,static lastOf (Ljava/util/List;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)TT; -
 method public,static findNextInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static findPreviousInIterable (Ljava/lang/Iterable;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;TT;)TT; -
 method public,static make (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,static make (Ljava/lang/Object;Ljava/util/function/Consumer;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Ljava/util/function/Consumer<-TT;>;)TT; -
 method public,static identityStrategy ()Lit/unimi/dsi/fastutil/Hash$Strategy; <K:Ljava/lang/Object;>()Lit/unimi/dsi/fastutil/Hash$Strategy<TK;>; -
 method public,static sequence (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFast (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static sequenceFailFastAndCancel (Ljava/util/List;)Ljava/util/concurrent/CompletableFuture; <V:Ljava/lang/Object;>(Ljava/util/List<+Ljava/util/concurrent/CompletableFuture<+TV;>;>;)Ljava/util/concurrent/CompletableFuture<Ljava/util/List<TV;>;>; -
 method public,static ifElse (Ljava/util/Optional;Ljava/util/function/Consumer;Ljava/lang/Runnable;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/Optional<TT;>;Ljava/util/function/Consumer<TT;>;Ljava/lang/Runnable;)Ljava/util/Optional<TT;>; -
 method public,static name (Ljava/util/function/Supplier;Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/util/function/Supplier<TT;>; -
 method public,static name (Ljava/lang/Runnable;Ljava/util/function/Supplier;)Ljava/lang/Runnable; (Ljava/lang/Runnable;Ljava/util/function/Supplier<Ljava/lang/String;>;)Ljava/lang/Runnable; -
 method public,static logAndPauseIfInIde (Ljava/lang/String;)V - -
 method public,static logAndPauseIfInIde (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public,static pauseInIde (Ljava/lang/Throwable;)Ljava/lang/Throwable; <T:Ljava/lang/Throwable;>(TT;)TT; -
 method public,static setPause (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Ljava/lang/String;>;)V -
 method public,static describeError (Ljava/lang/Throwable;)Ljava/lang/String; - -
 method public,static getRandom ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandom ([ILnet/minecraft/util/RandomSource;)I - -
 method public,static getRandom (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)TT; -
 method public,static getRandomSafe (Ljava/util/List;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/Optional<TT;>; -
 method public,static safeReplaceFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;)V - -
 method public,static safeReplaceFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - -
 method public,static safeReplaceOrMoveFile (Ljava/io/File;Ljava/io/File;Ljava/io/File;Z)V - -
 method public,static safeReplaceOrMoveFile (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;Z)V - -
 method public,static offsetByCodepoints (Ljava/lang/String;II)I - -
 method public,static prefix (Ljava/lang/String;Ljava/util/function/Consumer;)Ljava/util/function/Consumer; (Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)Ljava/util/function/Consumer<Ljava/lang/String;>; -
 method public,static fixedSize (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/IntStream;I)Lcom/mojang/serialization/DataResult<[I>; -
 method public,static fixedSize (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult; (Ljava/util/stream/LongStream;I)Lcom/mojang/serialization/DataResult<[J>; -
 method public,static fixedSize (Ljava/util/List;I)Lcom/mojang/serialization/DataResult; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;I)Lcom/mojang/serialization/DataResult<Ljava/util/List<TT;>;>; -
 method public,static startTimerHackThread ()V - -
 method public,static copyBetweenDirs (Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static sanitizeName (Ljava/lang/String;Lnet/minecraft/CharPredicate;)Ljava/lang/String; - -
 method public,static singleKeyCache (Ljava/util/function/Function;)Lnet/minecraft/util/SingleKeyCache; <K:Ljava/lang/Object;V:Ljava/lang/Object;>(Ljava/util/function/Function<TK;TV;>;)Lnet/minecraft/util/SingleKeyCache<TK;TV;>; -
 method public,static memoize (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,static memoize (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,static toShuffledList (Ljava/util/stream/Stream;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Ljava/util/stream/Stream<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static toShuffledList (Ljava/util/stream/IntStream;Lnet/minecraft/util/RandomSource;)Lit/unimi/dsi/fastutil/ints/IntArrayList; - -
 method public,static shuffledCopy ([Ljava/lang/Object;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>([TT;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffledCopy (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)Ljava/util/List; <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)Ljava/util/List<TT;>; -
 method public,static shuffle (Lit/unimi/dsi/fastutil/objects/ObjectArrayList;Lnet/minecraft/util/RandomSource;)V <T:Ljava/lang/Object;>(Lit/unimi/dsi/fastutil/objects/ObjectArrayList<TT;>;Lnet/minecraft/util/RandomSource;)V -
 method public,static blockUntilDone (Ljava/util/function/Function;)Ljava/util/concurrent/CompletableFuture; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture<TT;>;>;)Ljava/util/concurrent/CompletableFuture<TT;>; -
 method public,static blockUntilDone (Ljava/util/function/Function;Ljava/util/function/Predicate;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Function<Ljava/util/concurrent/Executor;TT;>;Ljava/util/function/Predicate<TT;>;)TT; -
 method public,static createIndexLookup (Ljava/util/List;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static createIndexLookup (Ljava/util/List;Ljava/util/function/IntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/List<TT;>;Ljava/util/function/IntFunction<Lit/unimi/dsi/fastutil/objects/Object2IntMap<TT;>;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,static getOrThrow (Lcom/mojang/serialization/DataResult;Ljava/util/function/Function;)Ljava/lang/Object; <T:Ljava/lang/Object;E:Ljava/lang/Exception;>(Lcom/mojang/serialization/DataResult<TT;>;Ljava/util/function/Function<Ljava/lang/String;TE;>;)TT;^TE; java/lang/Exception
 method public,static isWhitespace (I)Z - -
 method public,static isBlank (Ljava/lang/String;)Z - -
in 126
class net/minecraft/Util$IdentityStrategy 52 final,super,enum java/lang/Enum it/unimi/dsi/fastutil/Hash$Strategy Ljava/lang/Enum<Lnet/minecraft/Util$IdentityStrategy;>;Lit/unimi/dsi/fastutil/Hash$Strategy<Ljava/lang/Object;>;
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 field public,static,final,enum INSTANCE Lnet/minecraft/Util$IdentityStrategy; -
 method public,static values ()[Lnet/minecraft/Util$IdentityStrategy; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$IdentityStrategy; - -
 method public hashCode (Ljava/lang/Object;)I - -
 method public equals (Ljava/lang/Object;Ljava/lang/Object;)Z - -
in 82
class net/minecraft/Util$IdentityStrategy 60 final,super,enum java/lang/Enum it/unimi/dsi/fastutil/Hash$Strategy Ljava/lang/Enum<Lnet/minecraft/Util$IdentityStrategy;>;Lit/unimi/dsi/fastutil/Hash$Strategy<Ljava/lang/Object;>;
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 field public,static,final,enum INSTANCE Lnet/minecraft/Util$IdentityStrategy; -
 method public,static values ()[Lnet/minecraft/Util$IdentityStrategy; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$IdentityStrategy; - -
 method public hashCode (Ljava/lang/Object;)I - -
 method public equals (Ljava/lang/Object;Ljava/lang/Object;)Z - -
in 223
class net/minecraft/Util$IdentityStrategy 61 final,super,enum java/lang/Enum it/unimi/dsi/fastutil/Hash$Strategy Ljava/lang/Enum<Lnet/minecraft/Util$IdentityStrategy;>;Lit/unimi/dsi/fastutil/Hash$Strategy<Ljava/lang/Object;>;
 inner net/minecraft/Util$IdentityStrategy net/minecraft/Util IdentityStrategy static,final,enum
 inner it/unimi/dsi/fastutil/Hash$Strategy it/unimi/dsi/fastutil/Hash Strategy public,static,interface,abstract
 field public,static,final,enum INSTANCE Lnet/minecraft/Util$IdentityStrategy; -
 method public,static values ()[Lnet/minecraft/Util$IdentityStrategy; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$IdentityStrategy; - -
 method public hashCode (Ljava/lang/Object;)I - -
 method public equals (Ljava/lang/Object;Ljava/lang/Object;)Z - -
in 456
class net/minecraft/Util$OS 52 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/Util$OS;>;
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum LINUX Lnet/minecraft/Util$OS; -
 field public,static,final,enum SOLARIS Lnet/minecraft/Util$OS; -
 field public,static,final,enum WINDOWS Lnet/minecraft/Util$OS; -
 field public,static,final,enum OSX Lnet/minecraft/Util$OS; -
 field public,static,final,enum UNKNOWN Lnet/minecraft/Util$OS; -
 method public openUrl (Ljava/net/URL;)V - -
 method public openUri (Ljava/net/URI;)V - -
 method public openFile (Ljava/io/File;)V - -
 method protected getOpenUrlArguments (Ljava/net/URL;)[Ljava/lang/String; - -
 method public openUri (Ljava/lang/String;)V - -
 method public,static values ()[Lnet/minecraft/Util$OS; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$OS; - -
in 469
class net/minecraft/Util$OS 52 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/Util$OS;>;
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum LINUX Lnet/minecraft/Util$OS; -
 field public,static,final,enum SOLARIS Lnet/minecraft/Util$OS; -
 field public,static,final,enum WINDOWS Lnet/minecraft/Util$OS; -
 field public,static,final,enum OSX Lnet/minecraft/Util$OS; -
 field public,static,final,enum UNKNOWN Lnet/minecraft/Util$OS; -
 method public,static values ()[Lnet/minecraft/Util$OS; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$OS; - -
 method public openUrl (Ljava/net/URL;)V - -
 method public openUri (Ljava/net/URI;)V - -
 method public openFile (Ljava/io/File;)V - -
 method protected getOpenUrlArguments (Ljava/net/URL;)[Ljava/lang/String; - -
 method public openUri (Ljava/lang/String;)V - -
in 82
class net/minecraft/Util$OS 60 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/Util$OS;>;
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum LINUX Lnet/minecraft/Util$OS; -
 field public,static,final,enum SOLARIS Lnet/minecraft/Util$OS; -
 field public,static,final,enum WINDOWS Lnet/minecraft/Util$OS; -
 field public,static,final,enum OSX Lnet/minecraft/Util$OS; -
 field public,static,final,enum UNKNOWN Lnet/minecraft/Util$OS; -
 method public,static values ()[Lnet/minecraft/Util$OS; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$OS; - -
 method public openUrl (Ljava/net/URL;)V - -
 method public openUri (Ljava/net/URI;)V - -
 method public openFile (Ljava/io/File;)V - -
 method protected getOpenUrlArguments (Ljava/net/URL;)[Ljava/lang/String; - -
 method public openUri (Ljava/lang/String;)V - -
in 93
class net/minecraft/Util$OS 61 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/Util$OS;>;
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum LINUX Lnet/minecraft/Util$OS; -
 field public,static,final,enum SOLARIS Lnet/minecraft/Util$OS; -
 field public,static,final,enum WINDOWS Lnet/minecraft/Util$OS; -
 field public,static,final,enum OSX Lnet/minecraft/Util$OS; -
 field public,static,final,enum UNKNOWN Lnet/minecraft/Util$OS; -
 method public,static values ()[Lnet/minecraft/Util$OS; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$OS; - -
 method public openUrl (Ljava/net/URL;)V - -
 method public openUri (Ljava/net/URI;)V - -
 method public openFile (Ljava/io/File;)V - -
 method protected getOpenUrlArguments (Ljava/net/URL;)[Ljava/lang/String; - -
 method public openUri (Ljava/lang/String;)V - -
 method public telemetryName ()Ljava/lang/String; - -
in 224
class net/minecraft/Util$OS 65 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/Util$OS;>;
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum LINUX Lnet/minecraft/Util$OS; -
 field public,static,final,enum SOLARIS Lnet/minecraft/Util$OS; -
 field public,static,final,enum WINDOWS Lnet/minecraft/Util$OS; -
 field public,static,final,enum OSX Lnet/minecraft/Util$OS; -
 field public,static,final,enum UNKNOWN Lnet/minecraft/Util$OS; -
 method public,static values ()[Lnet/minecraft/Util$OS; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$OS; - -
 method public openUrl (Ljava/net/URL;)V - -
 method public openUri (Ljava/net/URI;)V - -
 method public openFile (Ljava/io/File;)V - -
 method protected getOpenUrlArguments (Ljava/net/URL;)[Ljava/lang/String; - -
 method public openUri (Ljava/lang/String;)V - -
 method public telemetryName ()Ljava/lang/String; - -
in 268
class net/minecraft/Util$OS 65 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/Util$OS;>;
 inner net/minecraft/Util$OS net/minecraft/Util OS public,static,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum LINUX Lnet/minecraft/Util$OS; -
 field public,static,final,enum SOLARIS Lnet/minecraft/Util$OS; -
 field public,static,final,enum WINDOWS Lnet/minecraft/Util$OS; -
 field public,static,final,enum OSX Lnet/minecraft/Util$OS; -
 field public,static,final,enum UNKNOWN Lnet/minecraft/Util$OS; -
 method public,static values ()[Lnet/minecraft/Util$OS; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/Util$OS; - -
 method public openUri (Ljava/net/URI;)V - -
 method public openFile (Ljava/io/File;)V - -
 method public openPath (Ljava/nio/file/Path;)V - -
 method protected getOpenUriArguments (Ljava/net/URI;)[Ljava/lang/String; - -
 method public openUri (Ljava/lang/String;)V - -
 method public telemetryName ()Ljava/lang/String; - -
in 218
class net/minecraft/WorldVersion 61 public,interface,abstract java/lang/Object com/mojang/bridge/game/GameVersion -
 method public,deprecated getWorldVersion ()I - -
 method public,deprecated getSeriesId ()Ljava/lang/String; - -
 method public,abstract getDataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
in 89
class net/minecraft/WorldVersion 61 public,interface,abstract java/lang/Object - -
 method public,abstract getDataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public,abstract getId ()Ljava/lang/String; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getProtocolVersion ()I - -
 method public,abstract getPackVersion (Lnet/minecraft/server/packs/PackType;)I - -
 method public,abstract getBuildTime ()Ljava/util/Date; - -
 method public,abstract isStable ()Z - -
in 221
class net/minecraft/WorldVersion 65 public,interface,abstract java/lang/Object - -
 method public,abstract getDataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public,abstract getId ()Ljava/lang/String; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getProtocolVersion ()I - -
 method public,abstract getPackVersion (Lnet/minecraft/server/packs/PackType;)I - -
 method public,abstract getBuildTime ()Ljava/util/Date; - -
 method public,abstract isStable ()Z - -
in 103
class net/minecraft/WorldVersion 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/WorldVersion$Simple net/minecraft/WorldVersion Simple public,static,final
 method public,abstract dataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public,abstract id ()Ljava/lang/String; - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract protocolVersion ()I - -
 method public,abstract packVersion (Lnet/minecraft/server/packs/PackType;)I - -
 method public,abstract buildTime ()Ljava/util/Date; - -
 method public,abstract stable ()Z - -
in 74
class net/minecraft/WorldVersion 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/WorldVersion$Simple net/minecraft/WorldVersion Simple public,static,final
 method public,abstract dataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public,abstract id ()Ljava/lang/String; - -
 method public,abstract name ()Ljava/lang/String; - -
 method public,abstract protocolVersion ()I - -
 method public,abstract packVersion (Lnet/minecraft/server/packs/PackType;)Lnet/minecraft/server/packs/metadata/pack/PackFormat; - -
 method public,abstract buildTime ()Ljava/util/Date; - -
 method public,abstract stable ()Z - -
in 103
class net/minecraft/WorldVersion$Simple 65 public,final,super java/lang/Record net/minecraft/WorldVersion -
 inner net/minecraft/WorldVersion$Simple net/minecraft/WorldVersion Simple public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/storage/DataVersion;IIILjava/util/Date;Z)V - -
 method public packVersion (Lnet/minecraft/server/packs/PackType;)I - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public id ()Ljava/lang/String; - -
 method public name ()Ljava/lang/String; - -
 method public dataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public protocolVersion ()I - -
 method public resourcePackVersion ()I - -
 method public datapackVersion ()I - -
 method public buildTime ()Ljava/util/Date; - -
 method public stable ()Z - -
in 74
class net/minecraft/WorldVersion$Simple 65 public,final,super java/lang/Record net/minecraft/WorldVersion -
 inner net/minecraft/WorldVersion$Simple net/minecraft/WorldVersion Simple public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/storage/DataVersion;ILnet/minecraft/server/packs/metadata/pack/PackFormat;Lnet/minecraft/server/packs/metadata/pack/PackFormat;Ljava/util/Date;Z)V - -
 method public packVersion (Lnet/minecraft/server/packs/PackType;)Lnet/minecraft/server/packs/metadata/pack/PackFormat; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public id ()Ljava/lang/String; - -
 method public name ()Ljava/lang/String; - -
 method public dataVersion ()Lnet/minecraft/world/level/storage/DataVersion; - -
 method public protocolVersion ()I - -
 method public resourcePackVersion ()Lnet/minecraft/server/packs/metadata/pack/PackFormat; - -
 method public datapackVersion ()Lnet/minecraft/server/packs/metadata/pack/PackFormat; - -
 method public buildTime ()Ljava/util/Date; - -
 method public stable ()Z - -
