cg-stub-db 1
in 68
class com/machinezoo/noexception/CheckedExceptionHandler 55 public,super,abstract java/lang/Object - -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedCloseableScope com/machinezoo/noexception/CheckedExceptionHandler CheckedCloseableScope private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedComparator com/machinezoo/noexception/CheckedExceptionHandler CheckedComparator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleBinaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedLongBinaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedIntBinaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedBinaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToDoubleBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToDoubleBiFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToLongBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToLongBiFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToIntBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToIntBiFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedBiFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleUnaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedLongUnaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedIntUnaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedUnaryOperator private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleToLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleToLongFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleToIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleToIntFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToDoubleFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongToDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedLongToDoubleFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongToIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedLongToIntFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedLongFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToLongFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntToDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedIntToDoubleFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntToLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedIntToLongFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedIntFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToIntFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedFunction private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedBiPredicate private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoublePredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedDoublePredicate private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedLongPredicate private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedIntPredicate private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedPredicate private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjDoubleConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedObjDoubleConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjLongConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedObjLongConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjIntConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedObjIntConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedBiConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedLongConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedIntConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedConsumer private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBooleanSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedBooleanSupplier private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleSupplier private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedLongSupplier private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedIntSupplier private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedSupplier private,final
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedRunnable com/machinezoo/noexception/CheckedExceptionHandler CheckedRunnable private,final
 method public,abstract handle (Ljava/lang/Exception;)Ljava/lang/RuntimeException; - -
 method protected <init> ()V - -
 method public,final runnable (Lcom/machinezoo/noexception/throwing/ThrowingRunnable;)Ljava/lang/Runnable; - -
 method public,final supplier (Lcom/machinezoo/noexception/throwing/ThrowingSupplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingSupplier<TT;>;)Ljava/util/function/Supplier<TT;>; -
 method public,final fromIntSupplier (Lcom/machinezoo/noexception/throwing/ThrowingIntSupplier;)Ljava/util/function/IntSupplier; - -
 method public,final fromLongSupplier (Lcom/machinezoo/noexception/throwing/ThrowingLongSupplier;)Ljava/util/function/LongSupplier; - -
 method public,final fromDoubleSupplier (Lcom/machinezoo/noexception/throwing/ThrowingDoubleSupplier;)Ljava/util/function/DoubleSupplier; - -
 method public,final fromBooleanSupplier (Lcom/machinezoo/noexception/throwing/ThrowingBooleanSupplier;)Ljava/util/function/BooleanSupplier; - -
 method public,final consumer (Lcom/machinezoo/noexception/throwing/ThrowingConsumer;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingConsumer<TT;>;)Ljava/util/function/Consumer<TT;>; -
 method public,final fromIntConsumer (Lcom/machinezoo/noexception/throwing/ThrowingIntConsumer;)Ljava/util/function/IntConsumer; - -
 method public,final fromLongConsumer (Lcom/machinezoo/noexception/throwing/ThrowingLongConsumer;)Ljava/util/function/LongConsumer; - -
 method public,final fromDoubleConsumer (Lcom/machinezoo/noexception/throwing/ThrowingDoubleConsumer;)Ljava/util/function/DoubleConsumer; - -
 method public,final fromBiConsumer (Lcom/machinezoo/noexception/throwing/ThrowingBiConsumer;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingBiConsumer<TT;TU;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,final fromObjIntConsumer (Lcom/machinezoo/noexception/throwing/ThrowingObjIntConsumer;)Ljava/util/function/ObjIntConsumer; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingObjIntConsumer<TT;>;)Ljava/util/function/ObjIntConsumer<TT;>; -
 method public,final fromObjLongConsumer (Lcom/machinezoo/noexception/throwing/ThrowingObjLongConsumer;)Ljava/util/function/ObjLongConsumer; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingObjLongConsumer<TT;>;)Ljava/util/function/ObjLongConsumer<TT;>; -
 method public,final fromObjDoubleConsumer (Lcom/machinezoo/noexception/throwing/ThrowingObjDoubleConsumer;)Ljava/util/function/ObjDoubleConsumer; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingObjDoubleConsumer<TT;>;)Ljava/util/function/ObjDoubleConsumer<TT;>; -
 method public,final predicate (Lcom/machinezoo/noexception/throwing/ThrowingPredicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingPredicate<TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,final fromIntPredicate (Lcom/machinezoo/noexception/throwing/ThrowingIntPredicate;)Ljava/util/function/IntPredicate; - -
 method public,final fromLongPredicate (Lcom/machinezoo/noexception/throwing/ThrowingLongPredicate;)Ljava/util/function/LongPredicate; - -
 method public,final fromDoublePredicate (Lcom/machinezoo/noexception/throwing/ThrowingDoublePredicate;)Ljava/util/function/DoublePredicate; - -
 method public,final fromBiPredicate (Lcom/machinezoo/noexception/throwing/ThrowingBiPredicate;)Ljava/util/function/BiPredicate; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingBiPredicate<TT;TU;>;)Ljava/util/function/BiPredicate<TT;TU;>; -
 method public,final function (Lcom/machinezoo/noexception/throwing/ThrowingFunction;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingFunction<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,final fromToIntFunction (Lcom/machinezoo/noexception/throwing/ThrowingToIntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingToIntFunction<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,final fromIntFunction (Lcom/machinezoo/noexception/throwing/ThrowingIntFunction;)Ljava/util/function/IntFunction; <R:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingIntFunction<TR;>;)Ljava/util/function/IntFunction<TR;>; -
 method public,final fromIntToLongFunction (Lcom/machinezoo/noexception/throwing/ThrowingIntToLongFunction;)Ljava/util/function/IntToLongFunction; - -
 method public,final fromIntToDoubleFunction (Lcom/machinezoo/noexception/throwing/ThrowingIntToDoubleFunction;)Ljava/util/function/IntToDoubleFunction; - -
 method public,final fromToLongFunction (Lcom/machinezoo/noexception/throwing/ThrowingToLongFunction;)Ljava/util/function/ToLongFunction; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingToLongFunction<TT;>;)Ljava/util/function/ToLongFunction<TT;>; -
 method public,final fromLongFunction (Lcom/machinezoo/noexception/throwing/ThrowingLongFunction;)Ljava/util/function/LongFunction; <R:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingLongFunction<TR;>;)Ljava/util/function/LongFunction<TR;>; -
 method public,final fromLongToIntFunction (Lcom/machinezoo/noexception/throwing/ThrowingLongToIntFunction;)Ljava/util/function/LongToIntFunction; - -
 method public,final fromLongToDoubleFunction (Lcom/machinezoo/noexception/throwing/ThrowingLongToDoubleFunction;)Ljava/util/function/LongToDoubleFunction; - -
 method public,final fromToDoubleFunction (Lcom/machinezoo/noexception/throwing/ThrowingToDoubleFunction;)Ljava/util/function/ToDoubleFunction; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingToDoubleFunction<TT;>;)Ljava/util/function/ToDoubleFunction<TT;>; -
 method public,final fromDoubleFunction (Lcom/machinezoo/noexception/throwing/ThrowingDoubleFunction;)Ljava/util/function/DoubleFunction; <R:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingDoubleFunction<TR;>;)Ljava/util/function/DoubleFunction<TR;>; -
 method public,final fromDoubleToIntFunction (Lcom/machinezoo/noexception/throwing/ThrowingDoubleToIntFunction;)Ljava/util/function/DoubleToIntFunction; - -
 method public,final fromDoubleToLongFunction (Lcom/machinezoo/noexception/throwing/ThrowingDoubleToLongFunction;)Ljava/util/function/DoubleToLongFunction; - -
 method public,final fromUnaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingUnaryOperator;)Ljava/util/function/UnaryOperator; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingUnaryOperator<TT;>;)Ljava/util/function/UnaryOperator<TT;>; -
 method public,final fromIntUnaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingIntUnaryOperator;)Ljava/util/function/IntUnaryOperator; - -
 method public,final fromLongUnaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingLongUnaryOperator;)Ljava/util/function/LongUnaryOperator; - -
 method public,final fromDoubleUnaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingDoubleUnaryOperator;)Ljava/util/function/DoubleUnaryOperator; - -
 method public,final fromBiFunction (Lcom/machinezoo/noexception/throwing/ThrowingBiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingBiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,final fromToIntBiFunction (Lcom/machinezoo/noexception/throwing/ThrowingToIntBiFunction;)Ljava/util/function/ToIntBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingToIntBiFunction<TT;TU;>;)Ljava/util/function/ToIntBiFunction<TT;TU;>; -
 method public,final fromToLongBiFunction (Lcom/machinezoo/noexception/throwing/ThrowingToLongBiFunction;)Ljava/util/function/ToLongBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingToLongBiFunction<TT;TU;>;)Ljava/util/function/ToLongBiFunction<TT;TU;>; -
 method public,final fromToDoubleBiFunction (Lcom/machinezoo/noexception/throwing/ThrowingToDoubleBiFunction;)Ljava/util/function/ToDoubleBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingToDoubleBiFunction<TT;TU;>;)Ljava/util/function/ToDoubleBiFunction<TT;TU;>; -
 method public,final fromBinaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingBinaryOperator;)Ljava/util/function/BinaryOperator; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingBinaryOperator<TT;>;)Ljava/util/function/BinaryOperator<TT;>; -
 method public,final fromIntBinaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingIntBinaryOperator;)Ljava/util/function/IntBinaryOperator; - -
 method public,final fromLongBinaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingLongBinaryOperator;)Ljava/util/function/LongBinaryOperator; - -
 method public,final fromDoubleBinaryOperator (Lcom/machinezoo/noexception/throwing/ThrowingDoubleBinaryOperator;)Ljava/util/function/DoubleBinaryOperator; - -
 method public,final comparator (Lcom/machinezoo/noexception/throwing/ThrowingComparator;)Ljava/util/Comparator; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingComparator<TT;>;)Ljava/util/Comparator<TT;>; -
 method public,final closeable (Ljava/lang/AutoCloseable;)Lcom/machinezoo/noexception/CloseableScope; - -
 method public,final run (Lcom/machinezoo/noexception/throwing/ThrowingRunnable;)V - -
 method public,final get (Lcom/machinezoo/noexception/throwing/ThrowingSupplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/machinezoo/noexception/throwing/ThrowingSupplier<TT;>;)TT; -
 method public,final getAsInt (Lcom/machinezoo/noexception/throwing/ThrowingIntSupplier;)I - -
 method public,final getAsLong (Lcom/machinezoo/noexception/throwing/ThrowingLongSupplier;)J - -
 method public,final getAsDouble (Lcom/machinezoo/noexception/throwing/ThrowingDoubleSupplier;)D - -
 method public,final getAsBoolean (Lcom/machinezoo/noexception/throwing/ThrowingBooleanSupplier;)Z - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiConsumer 55 final,super java/lang/Object java/util/function/BiConsumer <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiConsumer<TT;TU;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedBiConsumer private,final
 method public accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiFunction 55 final,super java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;TR;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedBiFunction private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TU;)TR; -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiPredicate 55 final,super java/lang/Object java/util/function/BiPredicate <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiPredicate<TT;TU;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBiPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedBiPredicate private,final
 method public test (Ljava/lang/Object;Ljava/lang/Object;)Z (TT;TU;)Z -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedBinaryOperator 55 final,super java/lang/Object java/util/function/BinaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BinaryOperator<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedBinaryOperator private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TT;)TT; -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedBooleanSupplier 55 final,super java/lang/Object java/util/function/BooleanSupplier -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedBooleanSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedBooleanSupplier private,final
 method public getAsBoolean ()Z - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedCloseableScope 55 final,super java/lang/Object com/machinezoo/noexception/CloseableScope -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedCloseableScope com/machinezoo/noexception/CheckedExceptionHandler CheckedCloseableScope private,final
 method public close ()V - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedComparator 55 final,super java/lang/Object java/util/Comparator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Comparator<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedComparator com/machinezoo/noexception/CheckedExceptionHandler CheckedComparator private,final
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedConsumer 55 final,super java/lang/Object java/util/function/Consumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Consumer<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedConsumer private,final
 method public accept (Ljava/lang/Object;)V (TT;)V -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleBinaryOperator 55 final,super java/lang/Object java/util/function/DoubleBinaryOperator -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleBinaryOperator private,final
 method public applyAsDouble (DD)D - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleConsumer 55 final,super java/lang/Object java/util/function/DoubleConsumer -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleConsumer private,final
 method public accept (D)V - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleFunction 55 final,super java/lang/Object java/util/function/DoubleFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/DoubleFunction<TR;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleFunction private,final
 method public apply (D)Ljava/lang/Object; (D)TR; -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoublePredicate 55 final,super java/lang/Object java/util/function/DoublePredicate -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoublePredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedDoublePredicate private,final
 method public test (D)Z - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleSupplier 55 final,super java/lang/Object java/util/function/DoubleSupplier -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleSupplier private,final
 method public getAsDouble ()D - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleToIntFunction 55 final,super java/lang/Object java/util/function/DoubleToIntFunction -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleToIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleToIntFunction private,final
 method public applyAsInt (D)I - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleToLongFunction 55 final,super java/lang/Object java/util/function/DoubleToLongFunction -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleToLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleToLongFunction private,final
 method public applyAsLong (D)J - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleUnaryOperator 55 final,super java/lang/Object java/util/function/DoubleUnaryOperator -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedDoubleUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedDoubleUnaryOperator private,final
 method public applyAsDouble (D)D - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedFunction 55 final,super java/lang/Object java/util/function/Function <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;TR;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedFunction private,final
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR; -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntBinaryOperator 55 final,super java/lang/Object java/util/function/IntBinaryOperator -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedIntBinaryOperator private,final
 method public applyAsInt (II)I - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntConsumer 55 final,super java/lang/Object java/util/function/IntConsumer -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedIntConsumer private,final
 method public accept (I)V - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntFunction 55 final,super java/lang/Object java/util/function/IntFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/IntFunction<TR;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedIntFunction private,final
 method public apply (I)Ljava/lang/Object; (I)TR; -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntPredicate 55 final,super java/lang/Object java/util/function/IntPredicate -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedIntPredicate private,final
 method public test (I)Z - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntSupplier 55 final,super java/lang/Object java/util/function/IntSupplier -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedIntSupplier private,final
 method public getAsInt ()I - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntToDoubleFunction 55 final,super java/lang/Object java/util/function/IntToDoubleFunction -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntToDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedIntToDoubleFunction private,final
 method public applyAsDouble (I)D - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntToLongFunction 55 final,super java/lang/Object java/util/function/IntToLongFunction -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntToLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedIntToLongFunction private,final
 method public applyAsLong (I)J - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntUnaryOperator 55 final,super java/lang/Object java/util/function/IntUnaryOperator -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedIntUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedIntUnaryOperator private,final
 method public applyAsInt (I)I - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongBinaryOperator 55 final,super java/lang/Object java/util/function/LongBinaryOperator -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongBinaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedLongBinaryOperator private,final
 method public applyAsLong (JJ)J - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongConsumer 55 final,super java/lang/Object java/util/function/LongConsumer -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedLongConsumer private,final
 method public accept (J)V - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongFunction 55 final,super java/lang/Object java/util/function/LongFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/LongFunction<TR;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedLongFunction private,final
 method public apply (J)Ljava/lang/Object; (J)TR; -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongPredicate 55 final,super java/lang/Object java/util/function/LongPredicate -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedLongPredicate private,final
 method public test (J)Z - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongSupplier 55 final,super java/lang/Object java/util/function/LongSupplier -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedLongSupplier private,final
 method public getAsLong ()J - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongToDoubleFunction 55 final,super java/lang/Object java/util/function/LongToDoubleFunction -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongToDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedLongToDoubleFunction private,final
 method public applyAsDouble (J)D - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongToIntFunction 55 final,super java/lang/Object java/util/function/LongToIntFunction -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongToIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedLongToIntFunction private,final
 method public applyAsInt (J)I - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongUnaryOperator 55 final,super java/lang/Object java/util/function/LongUnaryOperator -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedLongUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedLongUnaryOperator private,final
 method public applyAsLong (J)J - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjDoubleConsumer 55 final,super java/lang/Object java/util/function/ObjDoubleConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjDoubleConsumer<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjDoubleConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedObjDoubleConsumer private,final
 method public accept (Ljava/lang/Object;D)V (TT;D)V -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjIntConsumer 55 final,super java/lang/Object java/util/function/ObjIntConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjIntConsumer<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjIntConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedObjIntConsumer private,final
 method public accept (Ljava/lang/Object;I)V (TT;I)V -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjLongConsumer 55 final,super java/lang/Object java/util/function/ObjLongConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjLongConsumer<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedObjLongConsumer com/machinezoo/noexception/CheckedExceptionHandler CheckedObjLongConsumer private,final
 method public accept (Ljava/lang/Object;J)V (TT;J)V -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedPredicate 55 final,super java/lang/Object java/util/function/Predicate <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Predicate<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedPredicate com/machinezoo/noexception/CheckedExceptionHandler CheckedPredicate private,final
 method public test (Ljava/lang/Object;)Z (TT;)Z -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedRunnable 55 final,super java/lang/Object java/lang/Runnable -
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedRunnable com/machinezoo/noexception/CheckedExceptionHandler CheckedRunnable private,final
 method public run ()V - -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedSupplier 55 final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedSupplier com/machinezoo/noexception/CheckedExceptionHandler CheckedSupplier private,final
 method public get ()Ljava/lang/Object; ()TT; -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedToDoubleBiFunction 55 final,super java/lang/Object java/util/function/ToDoubleBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToDoubleBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToDoubleBiFunction private,final
 method public applyAsDouble (Ljava/lang/Object;Ljava/lang/Object;)D (TT;TU;)D -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedToDoubleFunction 55 final,super java/lang/Object java/util/function/ToDoubleFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleFunction<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToDoubleFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToDoubleFunction private,final
 method public applyAsDouble (Ljava/lang/Object;)D (TT;)D -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedToIntBiFunction 55 final,super java/lang/Object java/util/function/ToIntBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToIntBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToIntBiFunction private,final
 method public applyAsInt (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TU;)I -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedToIntFunction 55 final,super java/lang/Object java/util/function/ToIntFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntFunction<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToIntFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToIntFunction private,final
 method public applyAsInt (Ljava/lang/Object;)I (TT;)I -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedToLongBiFunction 55 final,super java/lang/Object java/util/function/ToLongBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToLongBiFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToLongBiFunction private,final
 method public applyAsLong (Ljava/lang/Object;Ljava/lang/Object;)J (TT;TU;)J -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedToLongFunction 55 final,super java/lang/Object java/util/function/ToLongFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongFunction<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedToLongFunction com/machinezoo/noexception/CheckedExceptionHandler CheckedToLongFunction private,final
 method public applyAsLong (Ljava/lang/Object;)J (TT;)J -
in 68
class com/machinezoo/noexception/CheckedExceptionHandler$CheckedUnaryOperator 55 final,super java/lang/Object java/util/function/UnaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/UnaryOperator<TT;>;
 inner com/machinezoo/noexception/CheckedExceptionHandler$CheckedUnaryOperator com/machinezoo/noexception/CheckedExceptionHandler CheckedUnaryOperator private,final
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
in 68
class com/machinezoo/noexception/CloseableScope 55 public,interface,abstract java/lang/Object java/lang/AutoCloseable -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract close ()V - -
 method public andThen (Ljava/lang/Runnable;)Lcom/machinezoo/noexception/CloseableScope; - -
 method public andFinally (Ljava/lang/Runnable;)Lcom/machinezoo/noexception/CloseableScope; - -
in 68
class com/machinezoo/noexception/ExceptionFilter 55 public,super,abstract java/lang/Object - -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredCloseableScope com/machinezoo/noexception/ExceptionFilter FilteredCloseableScope private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredComparator com/machinezoo/noexception/ExceptionFilter FilteredComparator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredDoubleBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredLongBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredIntBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToDoubleBiFunction com/machinezoo/noexception/ExceptionFilter FilteredToDoubleBiFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToLongBiFunction com/machinezoo/noexception/ExceptionFilter FilteredToLongBiFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToIntBiFunction com/machinezoo/noexception/ExceptionFilter FilteredToIntBiFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBiFunction com/machinezoo/noexception/ExceptionFilter FilteredBiFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredDoubleUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredLongUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredIntUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleToLongFunction com/machinezoo/noexception/ExceptionFilter FilteredDoubleToLongFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleToIntFunction com/machinezoo/noexception/ExceptionFilter FilteredDoubleToIntFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredToDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongToDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredLongToDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongToIntFunction com/machinezoo/noexception/ExceptionFilter FilteredLongToIntFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongFunction com/machinezoo/noexception/ExceptionFilter FilteredLongFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToLongFunction com/machinezoo/noexception/ExceptionFilter FilteredToLongFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntToDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredIntToDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntToLongFunction com/machinezoo/noexception/ExceptionFilter FilteredIntToLongFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntFunction com/machinezoo/noexception/ExceptionFilter FilteredIntFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToIntFunction com/machinezoo/noexception/ExceptionFilter FilteredToIntFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredFunction com/machinezoo/noexception/ExceptionFilter FilteredFunction private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBiPredicate com/machinezoo/noexception/ExceptionFilter FilteredBiPredicate private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoublePredicate com/machinezoo/noexception/ExceptionFilter FilteredDoublePredicate private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongPredicate com/machinezoo/noexception/ExceptionFilter FilteredLongPredicate private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntPredicate com/machinezoo/noexception/ExceptionFilter FilteredIntPredicate private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredPredicate com/machinezoo/noexception/ExceptionFilter FilteredPredicate private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredObjDoubleConsumer com/machinezoo/noexception/ExceptionFilter FilteredObjDoubleConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredObjLongConsumer com/machinezoo/noexception/ExceptionFilter FilteredObjLongConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredObjIntConsumer com/machinezoo/noexception/ExceptionFilter FilteredObjIntConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBiConsumer com/machinezoo/noexception/ExceptionFilter FilteredBiConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleConsumer com/machinezoo/noexception/ExceptionFilter FilteredDoubleConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongConsumer com/machinezoo/noexception/ExceptionFilter FilteredLongConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntConsumer com/machinezoo/noexception/ExceptionFilter FilteredIntConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredConsumer com/machinezoo/noexception/ExceptionFilter FilteredConsumer private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBooleanSupplier com/machinezoo/noexception/ExceptionFilter FilteredBooleanSupplier private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleSupplier com/machinezoo/noexception/ExceptionFilter FilteredDoubleSupplier private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongSupplier com/machinezoo/noexception/ExceptionFilter FilteredLongSupplier private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntSupplier com/machinezoo/noexception/ExceptionFilter FilteredIntSupplier private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredSupplier com/machinezoo/noexception/ExceptionFilter FilteredSupplier private,final
 inner com/machinezoo/noexception/ExceptionFilter$FilteredRunnable com/machinezoo/noexception/ExceptionFilter FilteredRunnable private,final
 method public,abstract handle (Ljava/lang/Throwable;)V - -
 method protected <init> ()V - -
 method public,final runnable (Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,final supplier (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)Ljava/util/function/Supplier<TT;>; -
 method public,final fromIntSupplier (Ljava/util/function/IntSupplier;)Ljava/util/function/IntSupplier; - -
 method public,final fromLongSupplier (Ljava/util/function/LongSupplier;)Ljava/util/function/LongSupplier; - -
 method public,final fromDoubleSupplier (Ljava/util/function/DoubleSupplier;)Ljava/util/function/DoubleSupplier; - -
 method public,final fromBooleanSupplier (Ljava/util/function/BooleanSupplier;)Ljava/util/function/BooleanSupplier; - -
 method public,final consumer (Ljava/util/function/Consumer;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;>(Ljava/util/function/Consumer<TT;>;)Ljava/util/function/Consumer<TT;>; -
 method public,final fromIntConsumer (Ljava/util/function/IntConsumer;)Ljava/util/function/IntConsumer; - -
 method public,final fromLongConsumer (Ljava/util/function/LongConsumer;)Ljava/util/function/LongConsumer; - -
 method public,final fromDoubleConsumer (Ljava/util/function/DoubleConsumer;)Ljava/util/function/DoubleConsumer; - -
 method public,final fromBiConsumer (Ljava/util/function/BiConsumer;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/BiConsumer<TT;TU;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,final fromObjIntConsumer (Ljava/util/function/ObjIntConsumer;)Ljava/util/function/ObjIntConsumer; <T:Ljava/lang/Object;>(Ljava/util/function/ObjIntConsumer<TT;>;)Ljava/util/function/ObjIntConsumer<TT;>; -
 method public,final fromObjLongConsumer (Ljava/util/function/ObjLongConsumer;)Ljava/util/function/ObjLongConsumer; <T:Ljava/lang/Object;>(Ljava/util/function/ObjLongConsumer<TT;>;)Ljava/util/function/ObjLongConsumer<TT;>; -
 method public,final fromObjDoubleConsumer (Ljava/util/function/ObjDoubleConsumer;)Ljava/util/function/ObjDoubleConsumer; <T:Ljava/lang/Object;>(Ljava/util/function/ObjDoubleConsumer<TT;>;)Ljava/util/function/ObjDoubleConsumer<TT;>; -
 method public,final predicate (Ljava/util/function/Predicate;)Ljava/util/function/Predicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<TT;>;)Ljava/util/function/Predicate<TT;>; -
 method public,final fromIntPredicate (Ljava/util/function/IntPredicate;)Ljava/util/function/IntPredicate; - -
 method public,final fromLongPredicate (Ljava/util/function/LongPredicate;)Ljava/util/function/LongPredicate; - -
 method public,final fromDoublePredicate (Ljava/util/function/DoublePredicate;)Ljava/util/function/DoublePredicate; - -
 method public,final fromBiPredicate (Ljava/util/function/BiPredicate;)Ljava/util/function/BiPredicate; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/BiPredicate<TT;TU;>;)Ljava/util/function/BiPredicate<TT;TU;>; -
 method public,final function (Ljava/util/function/Function;)Ljava/util/function/Function; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Ljava/util/function/Function<TT;TR;>; -
 method public,final fromToIntFunction (Ljava/util/function/ToIntFunction;)Ljava/util/function/ToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/function/ToIntFunction<TT;>;)Ljava/util/function/ToIntFunction<TT;>; -
 method public,final fromIntFunction (Ljava/util/function/IntFunction;)Ljava/util/function/IntFunction; <R:Ljava/lang/Object;>(Ljava/util/function/IntFunction<TR;>;)Ljava/util/function/IntFunction<TR;>; -
 method public,final fromIntToLongFunction (Ljava/util/function/IntToLongFunction;)Ljava/util/function/IntToLongFunction; - -
 method public,final fromIntToDoubleFunction (Ljava/util/function/IntToDoubleFunction;)Ljava/util/function/IntToDoubleFunction; - -
 method public,final fromToLongFunction (Ljava/util/function/ToLongFunction;)Ljava/util/function/ToLongFunction; <T:Ljava/lang/Object;>(Ljava/util/function/ToLongFunction<TT;>;)Ljava/util/function/ToLongFunction<TT;>; -
 method public,final fromLongFunction (Ljava/util/function/LongFunction;)Ljava/util/function/LongFunction; <R:Ljava/lang/Object;>(Ljava/util/function/LongFunction<TR;>;)Ljava/util/function/LongFunction<TR;>; -
 method public,final fromLongToIntFunction (Ljava/util/function/LongToIntFunction;)Ljava/util/function/LongToIntFunction; - -
 method public,final fromLongToDoubleFunction (Ljava/util/function/LongToDoubleFunction;)Ljava/util/function/LongToDoubleFunction; - -
 method public,final fromToDoubleFunction (Ljava/util/function/ToDoubleFunction;)Ljava/util/function/ToDoubleFunction; <T:Ljava/lang/Object;>(Ljava/util/function/ToDoubleFunction<TT;>;)Ljava/util/function/ToDoubleFunction<TT;>; -
 method public,final fromDoubleFunction (Ljava/util/function/DoubleFunction;)Ljava/util/function/DoubleFunction; <R:Ljava/lang/Object;>(Ljava/util/function/DoubleFunction<TR;>;)Ljava/util/function/DoubleFunction<TR;>; -
 method public,final fromDoubleToIntFunction (Ljava/util/function/DoubleToIntFunction;)Ljava/util/function/DoubleToIntFunction; - -
 method public,final fromDoubleToLongFunction (Ljava/util/function/DoubleToLongFunction;)Ljava/util/function/DoubleToLongFunction; - -
 method public,final fromUnaryOperator (Ljava/util/function/UnaryOperator;)Ljava/util/function/UnaryOperator; <T:Ljava/lang/Object;>(Ljava/util/function/UnaryOperator<TT;>;)Ljava/util/function/UnaryOperator<TT;>; -
 method public,final fromIntUnaryOperator (Ljava/util/function/IntUnaryOperator;)Ljava/util/function/IntUnaryOperator; - -
 method public,final fromLongUnaryOperator (Ljava/util/function/LongUnaryOperator;)Ljava/util/function/LongUnaryOperator; - -
 method public,final fromDoubleUnaryOperator (Ljava/util/function/DoubleUnaryOperator;)Ljava/util/function/DoubleUnaryOperator; - -
 method public,final fromBiFunction (Ljava/util/function/BiFunction;)Ljava/util/function/BiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public,final fromToIntBiFunction (Ljava/util/function/ToIntBiFunction;)Ljava/util/function/ToIntBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/ToIntBiFunction<TT;TU;>;)Ljava/util/function/ToIntBiFunction<TT;TU;>; -
 method public,final fromToLongBiFunction (Ljava/util/function/ToLongBiFunction;)Ljava/util/function/ToLongBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/ToLongBiFunction<TT;TU;>;)Ljava/util/function/ToLongBiFunction<TT;TU;>; -
 method public,final fromToDoubleBiFunction (Ljava/util/function/ToDoubleBiFunction;)Ljava/util/function/ToDoubleBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/ToDoubleBiFunction<TT;TU;>;)Ljava/util/function/ToDoubleBiFunction<TT;TU;>; -
 method public,final fromBinaryOperator (Ljava/util/function/BinaryOperator;)Ljava/util/function/BinaryOperator; <T:Ljava/lang/Object;>(Ljava/util/function/BinaryOperator<TT;>;)Ljava/util/function/BinaryOperator<TT;>; -
 method public,final fromIntBinaryOperator (Ljava/util/function/IntBinaryOperator;)Ljava/util/function/IntBinaryOperator; - -
 method public,final fromLongBinaryOperator (Ljava/util/function/LongBinaryOperator;)Ljava/util/function/LongBinaryOperator; - -
 method public,final fromDoubleBinaryOperator (Ljava/util/function/DoubleBinaryOperator;)Ljava/util/function/DoubleBinaryOperator; - -
 method public,final comparator (Ljava/util/Comparator;)Ljava/util/Comparator; <T:Ljava/lang/Object;>(Ljava/util/Comparator<TT;>;)Ljava/util/Comparator<TT;>; -
 method public,final closeable (Lcom/machinezoo/noexception/CloseableScope;)Lcom/machinezoo/noexception/CloseableScope; - -
 method public,final run (Ljava/lang/Runnable;)V - -
 method public,final get (Ljava/util/function/Supplier;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)TT; -
 method public,final getAsInt (Ljava/util/function/IntSupplier;)I - -
 method public,final getAsLong (Ljava/util/function/LongSupplier;)J - -
 method public,final getAsDouble (Ljava/util/function/DoubleSupplier;)D - -
 method public,final getAsBoolean (Ljava/util/function/BooleanSupplier;)Z - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredBiConsumer 55 final,super java/lang/Object java/util/function/BiConsumer <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiConsumer<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBiConsumer com/machinezoo/noexception/ExceptionFilter FilteredBiConsumer private,final
 method public accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredBiFunction 55 final,super java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;TR;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBiFunction com/machinezoo/noexception/ExceptionFilter FilteredBiFunction private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TU;)TR; -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredBiPredicate 55 final,super java/lang/Object java/util/function/BiPredicate <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiPredicate<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBiPredicate com/machinezoo/noexception/ExceptionFilter FilteredBiPredicate private,final
 method public test (Ljava/lang/Object;Ljava/lang/Object;)Z (TT;TU;)Z -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredBinaryOperator 55 final,super java/lang/Object java/util/function/BinaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BinaryOperator<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredBinaryOperator private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TT;)TT; -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredBooleanSupplier 55 final,super java/lang/Object java/util/function/BooleanSupplier -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredBooleanSupplier com/machinezoo/noexception/ExceptionFilter FilteredBooleanSupplier private,final
 method public getAsBoolean ()Z - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredCloseableScope 55 final,super java/lang/Object com/machinezoo/noexception/CloseableScope -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredCloseableScope com/machinezoo/noexception/ExceptionFilter FilteredCloseableScope private,final
 method public close ()V - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredComparator 55 final,super java/lang/Object java/util/Comparator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Comparator<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredComparator com/machinezoo/noexception/ExceptionFilter FilteredComparator private,final
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredConsumer 55 final,super java/lang/Object java/util/function/Consumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Consumer<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredConsumer com/machinezoo/noexception/ExceptionFilter FilteredConsumer private,final
 method public accept (Ljava/lang/Object;)V (TT;)V -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoubleBinaryOperator 55 final,super java/lang/Object java/util/function/DoubleBinaryOperator -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredDoubleBinaryOperator private,final
 method public applyAsDouble (DD)D - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoubleConsumer 55 final,super java/lang/Object java/util/function/DoubleConsumer -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleConsumer com/machinezoo/noexception/ExceptionFilter FilteredDoubleConsumer private,final
 method public accept (D)V - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoubleFunction 55 final,super java/lang/Object java/util/function/DoubleFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/DoubleFunction<TR;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredDoubleFunction private,final
 method public apply (D)Ljava/lang/Object; (D)TR; -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoublePredicate 55 final,super java/lang/Object java/util/function/DoublePredicate -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoublePredicate com/machinezoo/noexception/ExceptionFilter FilteredDoublePredicate private,final
 method public test (D)Z - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoubleSupplier 55 final,super java/lang/Object java/util/function/DoubleSupplier -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleSupplier com/machinezoo/noexception/ExceptionFilter FilteredDoubleSupplier private,final
 method public getAsDouble ()D - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoubleToIntFunction 55 final,super java/lang/Object java/util/function/DoubleToIntFunction -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleToIntFunction com/machinezoo/noexception/ExceptionFilter FilteredDoubleToIntFunction private,final
 method public applyAsInt (D)I - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoubleToLongFunction 55 final,super java/lang/Object java/util/function/DoubleToLongFunction -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleToLongFunction com/machinezoo/noexception/ExceptionFilter FilteredDoubleToLongFunction private,final
 method public applyAsLong (D)J - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredDoubleUnaryOperator 55 final,super java/lang/Object java/util/function/DoubleUnaryOperator -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredDoubleUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredDoubleUnaryOperator private,final
 method public applyAsDouble (D)D - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredFunction 55 final,super java/lang/Object java/util/function/Function <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;TR;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredFunction com/machinezoo/noexception/ExceptionFilter FilteredFunction private,final
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR; -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntBinaryOperator 55 final,super java/lang/Object java/util/function/IntBinaryOperator -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredIntBinaryOperator private,final
 method public applyAsInt (II)I - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntConsumer 55 final,super java/lang/Object java/util/function/IntConsumer -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntConsumer com/machinezoo/noexception/ExceptionFilter FilteredIntConsumer private,final
 method public accept (I)V - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntFunction 55 final,super java/lang/Object java/util/function/IntFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/IntFunction<TR;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntFunction com/machinezoo/noexception/ExceptionFilter FilteredIntFunction private,final
 method public apply (I)Ljava/lang/Object; (I)TR; -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntPredicate 55 final,super java/lang/Object java/util/function/IntPredicate -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntPredicate com/machinezoo/noexception/ExceptionFilter FilteredIntPredicate private,final
 method public test (I)Z - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntSupplier 55 final,super java/lang/Object java/util/function/IntSupplier -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntSupplier com/machinezoo/noexception/ExceptionFilter FilteredIntSupplier private,final
 method public getAsInt ()I - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntToDoubleFunction 55 final,super java/lang/Object java/util/function/IntToDoubleFunction -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntToDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredIntToDoubleFunction private,final
 method public applyAsDouble (I)D - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntToLongFunction 55 final,super java/lang/Object java/util/function/IntToLongFunction -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntToLongFunction com/machinezoo/noexception/ExceptionFilter FilteredIntToLongFunction private,final
 method public applyAsLong (I)J - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredIntUnaryOperator 55 final,super java/lang/Object java/util/function/IntUnaryOperator -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredIntUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredIntUnaryOperator private,final
 method public applyAsInt (I)I - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongBinaryOperator 55 final,super java/lang/Object java/util/function/LongBinaryOperator -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongBinaryOperator com/machinezoo/noexception/ExceptionFilter FilteredLongBinaryOperator private,final
 method public applyAsLong (JJ)J - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongConsumer 55 final,super java/lang/Object java/util/function/LongConsumer -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongConsumer com/machinezoo/noexception/ExceptionFilter FilteredLongConsumer private,final
 method public accept (J)V - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongFunction 55 final,super java/lang/Object java/util/function/LongFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/LongFunction<TR;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongFunction com/machinezoo/noexception/ExceptionFilter FilteredLongFunction private,final
 method public apply (J)Ljava/lang/Object; (J)TR; -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongPredicate 55 final,super java/lang/Object java/util/function/LongPredicate -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongPredicate com/machinezoo/noexception/ExceptionFilter FilteredLongPredicate private,final
 method public test (J)Z - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongSupplier 55 final,super java/lang/Object java/util/function/LongSupplier -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongSupplier com/machinezoo/noexception/ExceptionFilter FilteredLongSupplier private,final
 method public getAsLong ()J - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongToDoubleFunction 55 final,super java/lang/Object java/util/function/LongToDoubleFunction -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongToDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredLongToDoubleFunction private,final
 method public applyAsDouble (J)D - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongToIntFunction 55 final,super java/lang/Object java/util/function/LongToIntFunction -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongToIntFunction com/machinezoo/noexception/ExceptionFilter FilteredLongToIntFunction private,final
 method public applyAsInt (J)I - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredLongUnaryOperator 55 final,super java/lang/Object java/util/function/LongUnaryOperator -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredLongUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredLongUnaryOperator private,final
 method public applyAsLong (J)J - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredObjDoubleConsumer 55 final,super java/lang/Object java/util/function/ObjDoubleConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjDoubleConsumer<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredObjDoubleConsumer com/machinezoo/noexception/ExceptionFilter FilteredObjDoubleConsumer private,final
 method public accept (Ljava/lang/Object;D)V (TT;D)V -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredObjIntConsumer 55 final,super java/lang/Object java/util/function/ObjIntConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjIntConsumer<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredObjIntConsumer com/machinezoo/noexception/ExceptionFilter FilteredObjIntConsumer private,final
 method public accept (Ljava/lang/Object;I)V (TT;I)V -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredObjLongConsumer 55 final,super java/lang/Object java/util/function/ObjLongConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjLongConsumer<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredObjLongConsumer com/machinezoo/noexception/ExceptionFilter FilteredObjLongConsumer private,final
 method public accept (Ljava/lang/Object;J)V (TT;J)V -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredPredicate 55 final,super java/lang/Object java/util/function/Predicate <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Predicate<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredPredicate com/machinezoo/noexception/ExceptionFilter FilteredPredicate private,final
 method public test (Ljava/lang/Object;)Z (TT;)Z -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredRunnable 55 final,super java/lang/Object java/lang/Runnable -
 inner com/machinezoo/noexception/ExceptionFilter$FilteredRunnable com/machinezoo/noexception/ExceptionFilter FilteredRunnable private,final
 method public run ()V - -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredSupplier 55 final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredSupplier com/machinezoo/noexception/ExceptionFilter FilteredSupplier private,final
 method public get ()Ljava/lang/Object; ()TT; -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredToDoubleBiFunction 55 final,super java/lang/Object java/util/function/ToDoubleBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToDoubleBiFunction com/machinezoo/noexception/ExceptionFilter FilteredToDoubleBiFunction private,final
 method public applyAsDouble (Ljava/lang/Object;Ljava/lang/Object;)D (TT;TU;)D -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredToDoubleFunction 55 final,super java/lang/Object java/util/function/ToDoubleFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleFunction<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToDoubleFunction com/machinezoo/noexception/ExceptionFilter FilteredToDoubleFunction private,final
 method public applyAsDouble (Ljava/lang/Object;)D (TT;)D -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredToIntBiFunction 55 final,super java/lang/Object java/util/function/ToIntBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToIntBiFunction com/machinezoo/noexception/ExceptionFilter FilteredToIntBiFunction private,final
 method public applyAsInt (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TU;)I -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredToIntFunction 55 final,super java/lang/Object java/util/function/ToIntFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntFunction<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToIntFunction com/machinezoo/noexception/ExceptionFilter FilteredToIntFunction private,final
 method public applyAsInt (Ljava/lang/Object;)I (TT;)I -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredToLongBiFunction 55 final,super java/lang/Object java/util/function/ToLongBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToLongBiFunction com/machinezoo/noexception/ExceptionFilter FilteredToLongBiFunction private,final
 method public applyAsLong (Ljava/lang/Object;Ljava/lang/Object;)J (TT;TU;)J -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredToLongFunction 55 final,super java/lang/Object java/util/function/ToLongFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongFunction<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredToLongFunction com/machinezoo/noexception/ExceptionFilter FilteredToLongFunction private,final
 method public applyAsLong (Ljava/lang/Object;)J (TT;)J -
in 68
class com/machinezoo/noexception/ExceptionFilter$FilteredUnaryOperator 55 final,super java/lang/Object java/util/function/UnaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/UnaryOperator<TT;>;
 inner com/machinezoo/noexception/ExceptionFilter$FilteredUnaryOperator com/machinezoo/noexception/ExceptionFilter FilteredUnaryOperator private,final
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
in 68
class com/machinezoo/noexception/ExceptionHandler 55 public,super,abstract java/lang/Object - -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingCloseableScope com/machinezoo/noexception/ExceptionHandler CatchingCloseableScope private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingComparator com/machinezoo/noexception/ExceptionHandler CatchingComparator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingDoubleBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingLongBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingIntBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingBinaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToDoubleBiFunction com/machinezoo/noexception/ExceptionHandler CatchingToDoubleBiFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToLongBiFunction com/machinezoo/noexception/ExceptionHandler CatchingToLongBiFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToIntBiFunction com/machinezoo/noexception/ExceptionHandler CatchingToIntBiFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBiFunction com/machinezoo/noexception/ExceptionHandler CatchingBiFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingDoubleUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingLongUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingIntUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingUnaryOperator private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleToLongFunction com/machinezoo/noexception/ExceptionHandler CatchingDoubleToLongFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleToIntFunction com/machinezoo/noexception/ExceptionHandler CatchingDoubleToIntFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingToDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongToDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingLongToDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongToIntFunction com/machinezoo/noexception/ExceptionHandler CatchingLongToIntFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongFunction com/machinezoo/noexception/ExceptionHandler CatchingLongFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToLongFunction com/machinezoo/noexception/ExceptionHandler CatchingToLongFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntToDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingIntToDoubleFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntToLongFunction com/machinezoo/noexception/ExceptionHandler CatchingIntToLongFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntFunction com/machinezoo/noexception/ExceptionHandler CatchingIntFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToIntFunction com/machinezoo/noexception/ExceptionHandler CatchingToIntFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingFunction com/machinezoo/noexception/ExceptionHandler CatchingFunction private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBiPredicate com/machinezoo/noexception/ExceptionHandler CatchingBiPredicate private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoublePredicate com/machinezoo/noexception/ExceptionHandler CatchingDoublePredicate private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongPredicate com/machinezoo/noexception/ExceptionHandler CatchingLongPredicate private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntPredicate com/machinezoo/noexception/ExceptionHandler CatchingIntPredicate private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingPredicate com/machinezoo/noexception/ExceptionHandler CatchingPredicate private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingObjDoubleConsumer com/machinezoo/noexception/ExceptionHandler CatchingObjDoubleConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingObjLongConsumer com/machinezoo/noexception/ExceptionHandler CatchingObjLongConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingObjIntConsumer com/machinezoo/noexception/ExceptionHandler CatchingObjIntConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBiConsumer com/machinezoo/noexception/ExceptionHandler CatchingBiConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleConsumer com/machinezoo/noexception/ExceptionHandler CatchingDoubleConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongConsumer com/machinezoo/noexception/ExceptionHandler CatchingLongConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntConsumer com/machinezoo/noexception/ExceptionHandler CatchingIntConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingConsumer com/machinezoo/noexception/ExceptionHandler CatchingConsumer private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBooleanSupplier com/machinezoo/noexception/ExceptionHandler CatchingBooleanSupplier private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleSupplier com/machinezoo/noexception/ExceptionHandler CatchingDoubleSupplier private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongSupplier com/machinezoo/noexception/ExceptionHandler CatchingLongSupplier private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntSupplier com/machinezoo/noexception/ExceptionHandler CatchingIntSupplier private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingSupplier com/machinezoo/noexception/ExceptionHandler CatchingSupplier private,final
 inner com/machinezoo/noexception/ExceptionHandler$CatchingRunnable com/machinezoo/noexception/ExceptionHandler CatchingRunnable private,final
 method public,abstract handle (Ljava/lang/Throwable;)Z - -
 method protected <init> ()V - -
 method public passing ()Lcom/machinezoo/noexception/ExceptionFilter; - -
 method public,final runnable (Ljava/lang/Runnable;)Ljava/lang/Runnable; - -
 method public,final supplier (Ljava/util/function/Supplier;)Lcom/machinezoo/noexception/optional/OptionalSupplier; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)Lcom/machinezoo/noexception/optional/OptionalSupplier<TT;>; -
 method public,final fromIntSupplier (Ljava/util/function/IntSupplier;)Lcom/machinezoo/noexception/optional/OptionalIntSupplier; - -
 method public,final fromLongSupplier (Ljava/util/function/LongSupplier;)Lcom/machinezoo/noexception/optional/OptionalLongSupplier; - -
 method public,final fromDoubleSupplier (Ljava/util/function/DoubleSupplier;)Lcom/machinezoo/noexception/optional/OptionalDoubleSupplier; - -
 method public,final fromBooleanSupplier (Ljava/util/function/BooleanSupplier;)Lcom/machinezoo/noexception/optional/OptionalBooleanSupplier; - -
 method public,final consumer (Ljava/util/function/Consumer;)Ljava/util/function/Consumer; <T:Ljava/lang/Object;>(Ljava/util/function/Consumer<TT;>;)Ljava/util/function/Consumer<TT;>; -
 method public,final fromIntConsumer (Ljava/util/function/IntConsumer;)Ljava/util/function/IntConsumer; - -
 method public,final fromLongConsumer (Ljava/util/function/LongConsumer;)Ljava/util/function/LongConsumer; - -
 method public,final fromDoubleConsumer (Ljava/util/function/DoubleConsumer;)Ljava/util/function/DoubleConsumer; - -
 method public,final fromBiConsumer (Ljava/util/function/BiConsumer;)Ljava/util/function/BiConsumer; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/BiConsumer<TT;TU;>;)Ljava/util/function/BiConsumer<TT;TU;>; -
 method public,final fromObjIntConsumer (Ljava/util/function/ObjIntConsumer;)Ljava/util/function/ObjIntConsumer; <T:Ljava/lang/Object;>(Ljava/util/function/ObjIntConsumer<TT;>;)Ljava/util/function/ObjIntConsumer<TT;>; -
 method public,final fromObjLongConsumer (Ljava/util/function/ObjLongConsumer;)Ljava/util/function/ObjLongConsumer; <T:Ljava/lang/Object;>(Ljava/util/function/ObjLongConsumer<TT;>;)Ljava/util/function/ObjLongConsumer<TT;>; -
 method public,final fromObjDoubleConsumer (Ljava/util/function/ObjDoubleConsumer;)Ljava/util/function/ObjDoubleConsumer; <T:Ljava/lang/Object;>(Ljava/util/function/ObjDoubleConsumer<TT;>;)Ljava/util/function/ObjDoubleConsumer<TT;>; -
 method public,final predicate (Ljava/util/function/Predicate;)Lcom/machinezoo/noexception/optional/OptionalPredicate; <T:Ljava/lang/Object;>(Ljava/util/function/Predicate<TT;>;)Lcom/machinezoo/noexception/optional/OptionalPredicate<TT;>; -
 method public,final fromIntPredicate (Ljava/util/function/IntPredicate;)Lcom/machinezoo/noexception/optional/OptionalIntPredicate; - -
 method public,final fromLongPredicate (Ljava/util/function/LongPredicate;)Lcom/machinezoo/noexception/optional/OptionalLongPredicate; - -
 method public,final fromDoublePredicate (Ljava/util/function/DoublePredicate;)Lcom/machinezoo/noexception/optional/OptionalDoublePredicate; - -
 method public,final fromBiPredicate (Ljava/util/function/BiPredicate;)Lcom/machinezoo/noexception/optional/OptionalBiPredicate; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/BiPredicate<TT;TU;>;)Lcom/machinezoo/noexception/optional/OptionalBiPredicate<TT;TU;>; -
 method public,final function (Ljava/util/function/Function;)Lcom/machinezoo/noexception/optional/OptionalFunction; <T:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/Function<TT;TR;>;)Lcom/machinezoo/noexception/optional/OptionalFunction<TT;TR;>; -
 method public,final fromToIntFunction (Ljava/util/function/ToIntFunction;)Lcom/machinezoo/noexception/optional/OptionalToIntFunction; <T:Ljava/lang/Object;>(Ljava/util/function/ToIntFunction<TT;>;)Lcom/machinezoo/noexception/optional/OptionalToIntFunction<TT;>; -
 method public,final fromIntFunction (Ljava/util/function/IntFunction;)Lcom/machinezoo/noexception/optional/OptionalIntFunction; <R:Ljava/lang/Object;>(Ljava/util/function/IntFunction<TR;>;)Lcom/machinezoo/noexception/optional/OptionalIntFunction<TR;>; -
 method public,final fromIntToLongFunction (Ljava/util/function/IntToLongFunction;)Lcom/machinezoo/noexception/optional/OptionalIntToLongFunction; - -
 method public,final fromIntToDoubleFunction (Ljava/util/function/IntToDoubleFunction;)Lcom/machinezoo/noexception/optional/OptionalIntToDoubleFunction; - -
 method public,final fromToLongFunction (Ljava/util/function/ToLongFunction;)Lcom/machinezoo/noexception/optional/OptionalToLongFunction; <T:Ljava/lang/Object;>(Ljava/util/function/ToLongFunction<TT;>;)Lcom/machinezoo/noexception/optional/OptionalToLongFunction<TT;>; -
 method public,final fromLongFunction (Ljava/util/function/LongFunction;)Lcom/machinezoo/noexception/optional/OptionalLongFunction; <R:Ljava/lang/Object;>(Ljava/util/function/LongFunction<TR;>;)Lcom/machinezoo/noexception/optional/OptionalLongFunction<TR;>; -
 method public,final fromLongToIntFunction (Ljava/util/function/LongToIntFunction;)Lcom/machinezoo/noexception/optional/OptionalLongToIntFunction; - -
 method public,final fromLongToDoubleFunction (Ljava/util/function/LongToDoubleFunction;)Lcom/machinezoo/noexception/optional/OptionalLongToDoubleFunction; - -
 method public,final fromToDoubleFunction (Ljava/util/function/ToDoubleFunction;)Lcom/machinezoo/noexception/optional/OptionalToDoubleFunction; <T:Ljava/lang/Object;>(Ljava/util/function/ToDoubleFunction<TT;>;)Lcom/machinezoo/noexception/optional/OptionalToDoubleFunction<TT;>; -
 method public,final fromDoubleFunction (Ljava/util/function/DoubleFunction;)Lcom/machinezoo/noexception/optional/OptionalDoubleFunction; <R:Ljava/lang/Object;>(Ljava/util/function/DoubleFunction<TR;>;)Lcom/machinezoo/noexception/optional/OptionalDoubleFunction<TR;>; -
 method public,final fromDoubleToIntFunction (Ljava/util/function/DoubleToIntFunction;)Lcom/machinezoo/noexception/optional/OptionalDoubleToIntFunction; - -
 method public,final fromDoubleToLongFunction (Ljava/util/function/DoubleToLongFunction;)Lcom/machinezoo/noexception/optional/OptionalDoubleToLongFunction; - -
 method public,final fromUnaryOperator (Ljava/util/function/UnaryOperator;)Lcom/machinezoo/noexception/optional/OptionalUnaryOperator; <T:Ljava/lang/Object;>(Ljava/util/function/UnaryOperator<TT;>;)Lcom/machinezoo/noexception/optional/OptionalUnaryOperator<TT;>; -
 method public,final fromIntUnaryOperator (Ljava/util/function/IntUnaryOperator;)Lcom/machinezoo/noexception/optional/OptionalIntUnaryOperator; - -
 method public,final fromLongUnaryOperator (Ljava/util/function/LongUnaryOperator;)Lcom/machinezoo/noexception/optional/OptionalLongUnaryOperator; - -
 method public,final fromDoubleUnaryOperator (Ljava/util/function/DoubleUnaryOperator;)Lcom/machinezoo/noexception/optional/OptionalDoubleUnaryOperator; - -
 method public,final fromBiFunction (Ljava/util/function/BiFunction;)Lcom/machinezoo/noexception/optional/OptionalBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>(Ljava/util/function/BiFunction<TT;TU;TR;>;)Lcom/machinezoo/noexception/optional/OptionalBiFunction<TT;TU;TR;>; -
 method public,final fromToIntBiFunction (Ljava/util/function/ToIntBiFunction;)Lcom/machinezoo/noexception/optional/OptionalToIntBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/ToIntBiFunction<TT;TU;>;)Lcom/machinezoo/noexception/optional/OptionalToIntBiFunction<TT;TU;>; -
 method public,final fromToLongBiFunction (Ljava/util/function/ToLongBiFunction;)Lcom/machinezoo/noexception/optional/OptionalToLongBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/ToLongBiFunction<TT;TU;>;)Lcom/machinezoo/noexception/optional/OptionalToLongBiFunction<TT;TU;>; -
 method public,final fromToDoubleBiFunction (Ljava/util/function/ToDoubleBiFunction;)Lcom/machinezoo/noexception/optional/OptionalToDoubleBiFunction; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Ljava/util/function/ToDoubleBiFunction<TT;TU;>;)Lcom/machinezoo/noexception/optional/OptionalToDoubleBiFunction<TT;TU;>; -
 method public,final fromBinaryOperator (Ljava/util/function/BinaryOperator;)Lcom/machinezoo/noexception/optional/OptionalBinaryOperator; <T:Ljava/lang/Object;>(Ljava/util/function/BinaryOperator<TT;>;)Lcom/machinezoo/noexception/optional/OptionalBinaryOperator<TT;>; -
 method public,final fromIntBinaryOperator (Ljava/util/function/IntBinaryOperator;)Lcom/machinezoo/noexception/optional/OptionalIntBinaryOperator; - -
 method public,final fromLongBinaryOperator (Ljava/util/function/LongBinaryOperator;)Lcom/machinezoo/noexception/optional/OptionalLongBinaryOperator; - -
 method public,final fromDoubleBinaryOperator (Ljava/util/function/DoubleBinaryOperator;)Lcom/machinezoo/noexception/optional/OptionalDoubleBinaryOperator; - -
 method public,final comparator (Ljava/util/Comparator;)Lcom/machinezoo/noexception/optional/OptionalComparator; <T:Ljava/lang/Object;>(Ljava/util/Comparator<TT;>;)Lcom/machinezoo/noexception/optional/OptionalComparator<TT;>; -
 method public,final closeable (Lcom/machinezoo/noexception/CloseableScope;)Lcom/machinezoo/noexception/CloseableScope; - -
 method public,final run (Ljava/lang/Runnable;)V - -
 method public,final get (Ljava/util/function/Supplier;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/util/function/Supplier<TT;>;)Ljava/util/Optional<TT;>; -
 method public,final getAsInt (Ljava/util/function/IntSupplier;)Ljava/util/OptionalInt; - -
 method public,final getAsLong (Ljava/util/function/LongSupplier;)Ljava/util/OptionalLong; - -
 method public,final getAsDouble (Ljava/util/function/DoubleSupplier;)Ljava/util/OptionalDouble; - -
 method public,final getAsBoolean (Ljava/util/function/BooleanSupplier;)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingBiConsumer 55 final,super java/lang/Object java/util/function/BiConsumer <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiConsumer<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBiConsumer com/machinezoo/noexception/ExceptionHandler CatchingBiConsumer private,final
 method public accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingBiFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalBiFunction<TT;TU;TR;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBiFunction com/machinezoo/noexception/ExceptionHandler CatchingBiFunction private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Optional; (TT;TU;)Ljava/util/Optional<TR;>; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingBiPredicate 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalBiPredicate <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalBiPredicate<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBiPredicate com/machinezoo/noexception/ExceptionHandler CatchingBiPredicate private,final
 method public test (Ljava/lang/Object;Ljava/lang/Object;)Lcom/machinezoo/noexception/optional/OptionalBoolean; (TT;TU;)Lcom/machinezoo/noexception/optional/OptionalBoolean; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingBinaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalBinaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalBinaryOperator<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingBinaryOperator private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Optional; (TT;TT;)Ljava/util/Optional<TT;>; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingBooleanSupplier 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalBooleanSupplier -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingBooleanSupplier com/machinezoo/noexception/ExceptionHandler CatchingBooleanSupplier private,final
 method public get ()Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingCloseableScope 55 final,super java/lang/Object com/machinezoo/noexception/CloseableScope -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingCloseableScope com/machinezoo/noexception/ExceptionHandler CatchingCloseableScope private,final
 method public close ()V - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingComparator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalComparator <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalComparator<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingComparator com/machinezoo/noexception/ExceptionHandler CatchingComparator private,final
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalInt; (TT;TT;)Ljava/util/OptionalInt; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingConsumer 55 final,super java/lang/Object java/util/function/Consumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Consumer<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingConsumer com/machinezoo/noexception/ExceptionHandler CatchingConsumer private,final
 method public accept (Ljava/lang/Object;)V (TT;)V -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoubleBinaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalDoubleBinaryOperator -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingDoubleBinaryOperator private,final
 method public apply (DD)Ljava/util/OptionalDouble; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoubleConsumer 55 final,super java/lang/Object java/util/function/DoubleConsumer -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleConsumer com/machinezoo/noexception/ExceptionHandler CatchingDoubleConsumer private,final
 method public accept (D)V - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoubleFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalDoubleFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalDoubleFunction<TR;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingDoubleFunction private,final
 method public apply (D)Ljava/util/Optional; (D)Ljava/util/Optional<TR;>; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoublePredicate 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalDoublePredicate -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoublePredicate com/machinezoo/noexception/ExceptionHandler CatchingDoublePredicate private,final
 method public test (D)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoubleSupplier 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalDoubleSupplier -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleSupplier com/machinezoo/noexception/ExceptionHandler CatchingDoubleSupplier private,final
 method public get ()Ljava/util/OptionalDouble; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoubleToIntFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalDoubleToIntFunction -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleToIntFunction com/machinezoo/noexception/ExceptionHandler CatchingDoubleToIntFunction private,final
 method public apply (D)Ljava/util/OptionalInt; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoubleToLongFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalDoubleToLongFunction -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleToLongFunction com/machinezoo/noexception/ExceptionHandler CatchingDoubleToLongFunction private,final
 method public apply (D)Ljava/util/OptionalLong; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingDoubleUnaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalDoubleUnaryOperator -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingDoubleUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingDoubleUnaryOperator private,final
 method public apply (D)Ljava/util/OptionalDouble; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalFunction <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalFunction<TT;TR;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingFunction com/machinezoo/noexception/ExceptionHandler CatchingFunction private,final
 method public apply (Ljava/lang/Object;)Ljava/util/Optional; (TT;)Ljava/util/Optional<TR;>; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntBinaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalIntBinaryOperator -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingIntBinaryOperator private,final
 method public apply (II)Ljava/util/OptionalInt; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntConsumer 55 final,super java/lang/Object java/util/function/IntConsumer -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntConsumer com/machinezoo/noexception/ExceptionHandler CatchingIntConsumer private,final
 method public accept (I)V - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalIntFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalIntFunction<TR;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntFunction com/machinezoo/noexception/ExceptionHandler CatchingIntFunction private,final
 method public apply (I)Ljava/util/Optional; (I)Ljava/util/Optional<TR;>; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntPredicate 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalIntPredicate -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntPredicate com/machinezoo/noexception/ExceptionHandler CatchingIntPredicate private,final
 method public test (I)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntSupplier 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalIntSupplier -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntSupplier com/machinezoo/noexception/ExceptionHandler CatchingIntSupplier private,final
 method public get ()Ljava/util/OptionalInt; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntToDoubleFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalIntToDoubleFunction -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntToDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingIntToDoubleFunction private,final
 method public apply (I)Ljava/util/OptionalDouble; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntToLongFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalIntToLongFunction -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntToLongFunction com/machinezoo/noexception/ExceptionHandler CatchingIntToLongFunction private,final
 method public apply (I)Ljava/util/OptionalLong; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingIntUnaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalIntUnaryOperator -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingIntUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingIntUnaryOperator private,final
 method public apply (I)Ljava/util/OptionalInt; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongBinaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalLongBinaryOperator -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongBinaryOperator com/machinezoo/noexception/ExceptionHandler CatchingLongBinaryOperator private,final
 method public apply (JJ)Ljava/util/OptionalLong; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongConsumer 55 final,super java/lang/Object java/util/function/LongConsumer -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongConsumer com/machinezoo/noexception/ExceptionHandler CatchingLongConsumer private,final
 method public accept (J)V - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalLongFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalLongFunction<TR;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongFunction com/machinezoo/noexception/ExceptionHandler CatchingLongFunction private,final
 method public apply (J)Ljava/util/Optional; (J)Ljava/util/Optional<TR;>; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongPredicate 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalLongPredicate -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongPredicate com/machinezoo/noexception/ExceptionHandler CatchingLongPredicate private,final
 method public test (J)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongSupplier 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalLongSupplier -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongSupplier com/machinezoo/noexception/ExceptionHandler CatchingLongSupplier private,final
 method public get ()Ljava/util/OptionalLong; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongToDoubleFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalLongToDoubleFunction -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongToDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingLongToDoubleFunction private,final
 method public apply (J)Ljava/util/OptionalDouble; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongToIntFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalLongToIntFunction -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongToIntFunction com/machinezoo/noexception/ExceptionHandler CatchingLongToIntFunction private,final
 method public apply (J)Ljava/util/OptionalInt; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingLongUnaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalLongUnaryOperator -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingLongUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingLongUnaryOperator private,final
 method public apply (J)Ljava/util/OptionalLong; - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingObjDoubleConsumer 55 final,super java/lang/Object java/util/function/ObjDoubleConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjDoubleConsumer<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingObjDoubleConsumer com/machinezoo/noexception/ExceptionHandler CatchingObjDoubleConsumer private,final
 method public accept (Ljava/lang/Object;D)V (TT;D)V -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingObjIntConsumer 55 final,super java/lang/Object java/util/function/ObjIntConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjIntConsumer<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingObjIntConsumer com/machinezoo/noexception/ExceptionHandler CatchingObjIntConsumer private,final
 method public accept (Ljava/lang/Object;I)V (TT;I)V -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingObjLongConsumer 55 final,super java/lang/Object java/util/function/ObjLongConsumer <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ObjLongConsumer<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingObjLongConsumer com/machinezoo/noexception/ExceptionHandler CatchingObjLongConsumer private,final
 method public accept (Ljava/lang/Object;J)V (TT;J)V -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingPredicate 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalPredicate <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalPredicate<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingPredicate com/machinezoo/noexception/ExceptionHandler CatchingPredicate private,final
 method public test (Ljava/lang/Object;)Lcom/machinezoo/noexception/optional/OptionalBoolean; (TT;)Lcom/machinezoo/noexception/optional/OptionalBoolean; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingRunnable 55 final,super java/lang/Object java/lang/Runnable -
 inner com/machinezoo/noexception/ExceptionHandler$CatchingRunnable com/machinezoo/noexception/ExceptionHandler CatchingRunnable private,final
 method public run ()V - -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingSupplier 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalSupplier <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalSupplier<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingSupplier com/machinezoo/noexception/ExceptionHandler CatchingSupplier private,final
 method public get ()Ljava/util/Optional; ()Ljava/util/Optional<TT;>; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingToDoubleBiFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalToDoubleBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalToDoubleBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToDoubleBiFunction com/machinezoo/noexception/ExceptionHandler CatchingToDoubleBiFunction private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalDouble; (TT;TU;)Ljava/util/OptionalDouble; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingToDoubleFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalToDoubleFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalToDoubleFunction<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToDoubleFunction com/machinezoo/noexception/ExceptionHandler CatchingToDoubleFunction private,final
 method public apply (Ljava/lang/Object;)Ljava/util/OptionalDouble; (TT;)Ljava/util/OptionalDouble; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingToIntBiFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalToIntBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalToIntBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToIntBiFunction com/machinezoo/noexception/ExceptionHandler CatchingToIntBiFunction private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalInt; (TT;TU;)Ljava/util/OptionalInt; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingToIntFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalToIntFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalToIntFunction<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToIntFunction com/machinezoo/noexception/ExceptionHandler CatchingToIntFunction private,final
 method public apply (Ljava/lang/Object;)Ljava/util/OptionalInt; (TT;)Ljava/util/OptionalInt; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingToLongBiFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalToLongBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalToLongBiFunction<TT;TU;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToLongBiFunction com/machinezoo/noexception/ExceptionHandler CatchingToLongBiFunction private,final
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalLong; (TT;TU;)Ljava/util/OptionalLong; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingToLongFunction 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalToLongFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalToLongFunction<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingToLongFunction com/machinezoo/noexception/ExceptionHandler CatchingToLongFunction private,final
 method public apply (Ljava/lang/Object;)Ljava/util/OptionalLong; (TT;)Ljava/util/OptionalLong; -
in 68
class com/machinezoo/noexception/ExceptionHandler$CatchingUnaryOperator 55 final,super java/lang/Object com/machinezoo/noexception/optional/OptionalUnaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/optional/OptionalUnaryOperator<TT;>;
 inner com/machinezoo/noexception/ExceptionHandler$CatchingUnaryOperator com/machinezoo/noexception/ExceptionHandler CatchingUnaryOperator private,final
 method public apply (Ljava/lang/Object;)Ljava/util/Optional; (TT;)Ljava/util/Optional<TT;>; -
in 68
class com/machinezoo/noexception/Exceptions 55 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static ignore ()Lcom/machinezoo/noexception/ExceptionHandler; - -
 method public,static,deprecated pass ()Lcom/machinezoo/noexception/ExceptionHandler; - -
 method public,static log ()Lcom/machinezoo/noexception/ExceptionHandler; - -
 method public,static log (Lorg/slf4j/Logger;)Lcom/machinezoo/noexception/ExceptionHandler; - -
 method public,static log (Lorg/slf4j/Logger;Ljava/lang/String;)Lcom/machinezoo/noexception/ExceptionHandler; - -
 method public,static log (Lorg/slf4j/Logger;Ljava/util/function/Supplier;)Lcom/machinezoo/noexception/ExceptionHandler; (Lorg/slf4j/Logger;Ljava/util/function/Supplier<Ljava/lang/String;>;)Lcom/machinezoo/noexception/ExceptionHandler; -
 method public,static silence ()Lcom/machinezoo/noexception/ExceptionHandler; - -
 method public,static sneak ()Lcom/machinezoo/noexception/CheckedExceptionHandler; - -
 method public,static wrap ()Lcom/machinezoo/noexception/CheckedExceptionHandler; - -
 method public,static wrap (Ljava/util/function/Function;)Lcom/machinezoo/noexception/CheckedExceptionHandler; (Ljava/util/function/Function<Ljava/lang/Exception;Ljava/lang/RuntimeException;>;)Lcom/machinezoo/noexception/CheckedExceptionHandler; -
in 68
class com/machinezoo/noexception/IgnoringHandler 55 final,super com/machinezoo/noexception/ExceptionHandler - -
 method public handle (Ljava/lang/Throwable;)Z - -
in 68
class com/machinezoo/noexception/LoggingHandler 55 final,super com/machinezoo/noexception/ExceptionHandler - -
 method public handle (Ljava/lang/Throwable;)Z - -
in 68
class com/machinezoo/noexception/MappingHandler 55 final,super com/machinezoo/noexception/CheckedExceptionHandler - -
 method public handle (Ljava/lang/Exception;)Ljava/lang/RuntimeException; - -
in 68
class com/machinezoo/noexception/PassingFilter 55 super com/machinezoo/noexception/ExceptionFilter - -
 method public handle (Ljava/lang/Throwable;)V - -
in 68
class com/machinezoo/noexception/SilencingHandler 55 final,super com/machinezoo/noexception/ExceptionHandler - -
 method public handle (Ljava/lang/Throwable;)Z - -
in 68
class com/machinezoo/noexception/SneakingHandler 55 final,super com/machinezoo/noexception/CheckedExceptionHandler - -
 method public handle (Ljava/lang/Exception;)Ljava/lang/RuntimeException; - -
in 68
class com/machinezoo/noexception/WrappedException 55 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/Throwable;)V - -
in 68
class com/machinezoo/noexception/WrappingHandler 55 final,super com/machinezoo/noexception/CheckedExceptionHandler - -
 method public handle (Ljava/lang/Exception;)Ljava/lang/RuntimeException; - -
in 68
class com/machinezoo/noexception/optional/DefaultBiFunction 55 final,super java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBiFunction;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalBiFunction<TT;TU;TR;>;TR;)V -
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TU;)TR; -
in 68
class com/machinezoo/noexception/optional/DefaultBiPredicate 55 final,super java/lang/Object java/util/function/BiPredicate <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiPredicate<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBiPredicate;Z)V (Lcom/machinezoo/noexception/optional/OptionalBiPredicate<TT;TU;>;Z)V -
 method public test (Ljava/lang/Object;Ljava/lang/Object;)Z (TT;TU;)Z -
in 68
class com/machinezoo/noexception/optional/DefaultBinaryOperator 55 final,super java/lang/Object java/util/function/BinaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BinaryOperator<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBinaryOperator;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalBinaryOperator<TT;>;TT;)V -
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TT;)TT; -
in 68
class com/machinezoo/noexception/optional/DefaultBooleanSupplier 55 final,super java/lang/Object java/util/function/BooleanSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBooleanSupplier;Z)V - -
 method public getAsBoolean ()Z - -
in 68
class com/machinezoo/noexception/optional/DefaultComparator 55 final,super java/lang/Object java/util/Comparator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Comparator<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalComparator;I)V (Lcom/machinezoo/noexception/optional/OptionalComparator<TT;>;I)V -
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I -
in 68
class com/machinezoo/noexception/optional/DefaultDoubleBinaryOperator 55 final,super java/lang/Object java/util/function/DoubleBinaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleBinaryOperator;D)V - -
 method public applyAsDouble (DD)D - -
in 68
class com/machinezoo/noexception/optional/DefaultDoubleFunction 55 final,super java/lang/Object java/util/function/DoubleFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/DoubleFunction<TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleFunction;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalDoubleFunction<TR;>;TR;)V -
 method public apply (D)Ljava/lang/Object; (D)TR; -
in 68
class com/machinezoo/noexception/optional/DefaultDoublePredicate 55 final,super java/lang/Object java/util/function/DoublePredicate -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoublePredicate;Z)V - -
 method public test (D)Z - -
in 68
class com/machinezoo/noexception/optional/DefaultDoubleSupplier 55 final,super java/lang/Object java/util/function/DoubleSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleSupplier;D)V - -
 method public getAsDouble ()D - -
in 68
class com/machinezoo/noexception/optional/DefaultDoubleToIntFunction 55 final,super java/lang/Object java/util/function/DoubleToIntFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleToIntFunction;I)V - -
 method public applyAsInt (D)I - -
in 68
class com/machinezoo/noexception/optional/DefaultDoubleToLongFunction 55 final,super java/lang/Object java/util/function/DoubleToLongFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleToLongFunction;J)V - -
 method public applyAsLong (D)J - -
in 68
class com/machinezoo/noexception/optional/DefaultDoubleUnaryOperator 55 final,super java/lang/Object java/util/function/DoubleUnaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleUnaryOperator;D)V - -
 method public applyAsDouble (D)D - -
in 68
class com/machinezoo/noexception/optional/DefaultFunction 55 final,super java/lang/Object java/util/function/Function <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalFunction;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalFunction<TT;TR;>;TR;)V -
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR; -
in 68
class com/machinezoo/noexception/optional/DefaultIntBinaryOperator 55 final,super java/lang/Object java/util/function/IntBinaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntBinaryOperator;I)V - -
 method public applyAsInt (II)I - -
in 68
class com/machinezoo/noexception/optional/DefaultIntFunction 55 final,super java/lang/Object java/util/function/IntFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/IntFunction<TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntFunction;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalIntFunction<TR;>;TR;)V -
 method public apply (I)Ljava/lang/Object; (I)TR; -
in 68
class com/machinezoo/noexception/optional/DefaultIntPredicate 55 final,super java/lang/Object java/util/function/IntPredicate -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntPredicate;Z)V - -
 method public test (I)Z - -
in 68
class com/machinezoo/noexception/optional/DefaultIntSupplier 55 final,super java/lang/Object java/util/function/IntSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntSupplier;I)V - -
 method public getAsInt ()I - -
in 68
class com/machinezoo/noexception/optional/DefaultIntToDoubleFunction 55 final,super java/lang/Object java/util/function/IntToDoubleFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntToDoubleFunction;D)V - -
 method public applyAsDouble (I)D - -
in 68
class com/machinezoo/noexception/optional/DefaultIntToLongFunction 55 final,super java/lang/Object java/util/function/IntToLongFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntToLongFunction;J)V - -
 method public applyAsLong (I)J - -
in 68
class com/machinezoo/noexception/optional/DefaultIntUnaryOperator 55 final,super java/lang/Object java/util/function/IntUnaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntUnaryOperator;I)V - -
 method public applyAsInt (I)I - -
in 68
class com/machinezoo/noexception/optional/DefaultLongBinaryOperator 55 final,super java/lang/Object java/util/function/LongBinaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongBinaryOperator;J)V - -
 method public applyAsLong (JJ)J - -
in 68
class com/machinezoo/noexception/optional/DefaultLongFunction 55 final,super java/lang/Object java/util/function/LongFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/LongFunction<TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongFunction;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalLongFunction<TR;>;TR;)V -
 method public apply (J)Ljava/lang/Object; (J)TR; -
in 68
class com/machinezoo/noexception/optional/DefaultLongPredicate 55 final,super java/lang/Object java/util/function/LongPredicate -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongPredicate;Z)V - -
 method public test (J)Z - -
in 68
class com/machinezoo/noexception/optional/DefaultLongSupplier 55 final,super java/lang/Object java/util/function/LongSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongSupplier;J)V - -
 method public getAsLong ()J - -
in 68
class com/machinezoo/noexception/optional/DefaultLongToDoubleFunction 55 final,super java/lang/Object java/util/function/LongToDoubleFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongToDoubleFunction;D)V - -
 method public applyAsDouble (J)D - -
in 68
class com/machinezoo/noexception/optional/DefaultLongToIntFunction 55 final,super java/lang/Object java/util/function/LongToIntFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongToIntFunction;I)V - -
 method public applyAsInt (J)I - -
in 68
class com/machinezoo/noexception/optional/DefaultLongUnaryOperator 55 final,super java/lang/Object java/util/function/LongUnaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongUnaryOperator;J)V - -
 method public applyAsLong (J)J - -
in 68
class com/machinezoo/noexception/optional/DefaultPredicate 55 final,super java/lang/Object java/util/function/Predicate <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Predicate<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalPredicate;Z)V (Lcom/machinezoo/noexception/optional/OptionalPredicate<TT;>;Z)V -
 method public test (Ljava/lang/Object;)Z (TT;)Z -
in 68
class com/machinezoo/noexception/optional/DefaultSupplier 55 final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalSupplier;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalSupplier<TT;>;TT;)V -
 method public get ()Ljava/lang/Object; ()TT; -
in 68
class com/machinezoo/noexception/optional/DefaultToDoubleBiFunction 55 final,super java/lang/Object java/util/function/ToDoubleBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleBiFunction<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToDoubleBiFunction;D)V (Lcom/machinezoo/noexception/optional/OptionalToDoubleBiFunction<TT;TU;>;D)V -
 method public applyAsDouble (Ljava/lang/Object;Ljava/lang/Object;)D (TT;TU;)D -
in 68
class com/machinezoo/noexception/optional/DefaultToDoubleFunction 55 final,super java/lang/Object java/util/function/ToDoubleFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleFunction<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToDoubleFunction;D)V (Lcom/machinezoo/noexception/optional/OptionalToDoubleFunction<TT;>;D)V -
 method public applyAsDouble (Ljava/lang/Object;)D (TT;)D -
in 68
class com/machinezoo/noexception/optional/DefaultToIntBiFunction 55 final,super java/lang/Object java/util/function/ToIntBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntBiFunction<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToIntBiFunction;I)V (Lcom/machinezoo/noexception/optional/OptionalToIntBiFunction<TT;TU;>;I)V -
 method public applyAsInt (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TU;)I -
in 68
class com/machinezoo/noexception/optional/DefaultToIntFunction 55 final,super java/lang/Object java/util/function/ToIntFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntFunction<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToIntFunction;I)V (Lcom/machinezoo/noexception/optional/OptionalToIntFunction<TT;>;I)V -
 method public applyAsInt (Ljava/lang/Object;)I (TT;)I -
in 68
class com/machinezoo/noexception/optional/DefaultToLongBiFunction 55 final,super java/lang/Object java/util/function/ToLongBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongBiFunction<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToLongBiFunction;J)V (Lcom/machinezoo/noexception/optional/OptionalToLongBiFunction<TT;TU;>;J)V -
 method public applyAsLong (Ljava/lang/Object;Ljava/lang/Object;)J (TT;TU;)J -
in 68
class com/machinezoo/noexception/optional/DefaultToLongFunction 55 final,super java/lang/Object java/util/function/ToLongFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongFunction<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToLongFunction;J)V (Lcom/machinezoo/noexception/optional/OptionalToLongFunction<TT;>;J)V -
 method public applyAsLong (Ljava/lang/Object;)J (TT;)J -
in 68
class com/machinezoo/noexception/optional/DefaultUnaryOperator 55 final,super java/lang/Object java/util/function/UnaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/UnaryOperator<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalUnaryOperator;Ljava/lang/Object;)V (Lcom/machinezoo/noexception/optional/OptionalUnaryOperator<TT;>;TT;)V -
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
in 68
class com/machinezoo/noexception/optional/FallbackBiFunction 55 final,super java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBiFunction;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalBiFunction<TT;TU;TR;>;Ljava/util/function/Supplier<TR;>;)V -
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TU;)TR; -
in 68
class com/machinezoo/noexception/optional/FallbackBiPredicate 55 final,super java/lang/Object java/util/function/BiPredicate <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiPredicate<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBiPredicate;Ljava/util/function/BooleanSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalBiPredicate<TT;TU;>;Ljava/util/function/BooleanSupplier;)V -
 method public test (Ljava/lang/Object;Ljava/lang/Object;)Z (TT;TU;)Z -
in 68
class com/machinezoo/noexception/optional/FallbackBinaryOperator 55 final,super java/lang/Object java/util/function/BinaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BinaryOperator<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBinaryOperator;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalBinaryOperator<TT;>;Ljava/util/function/Supplier<TT;>;)V -
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TT;)TT; -
in 68
class com/machinezoo/noexception/optional/FallbackBooleanSupplier 55 final,super java/lang/Object java/util/function/BooleanSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalBooleanSupplier;Ljava/util/function/BooleanSupplier;)V - -
 method public getAsBoolean ()Z - -
in 68
class com/machinezoo/noexception/optional/FallbackComparator 55 final,super java/lang/Object java/util/Comparator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/Comparator<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalComparator;Ljava/util/function/IntSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalComparator<TT;>;Ljava/util/function/IntSupplier;)V -
 method public compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I -
in 68
class com/machinezoo/noexception/optional/FallbackDoubleBinaryOperator 55 final,super java/lang/Object java/util/function/DoubleBinaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleBinaryOperator;Ljava/util/function/DoubleSupplier;)V - -
 method public applyAsDouble (DD)D - -
in 68
class com/machinezoo/noexception/optional/FallbackDoubleFunction 55 final,super java/lang/Object java/util/function/DoubleFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/DoubleFunction<TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleFunction;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalDoubleFunction<TR;>;Ljava/util/function/Supplier<TR;>;)V -
 method public apply (D)Ljava/lang/Object; (D)TR; -
in 68
class com/machinezoo/noexception/optional/FallbackDoublePredicate 55 final,super java/lang/Object java/util/function/DoublePredicate -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoublePredicate;Ljava/util/function/BooleanSupplier;)V - -
 method public test (D)Z - -
in 68
class com/machinezoo/noexception/optional/FallbackDoubleSupplier 55 final,super java/lang/Object java/util/function/DoubleSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleSupplier;Ljava/util/function/DoubleSupplier;)V - -
 method public getAsDouble ()D - -
in 68
class com/machinezoo/noexception/optional/FallbackDoubleToIntFunction 55 final,super java/lang/Object java/util/function/DoubleToIntFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleToIntFunction;Ljava/util/function/IntSupplier;)V - -
 method public applyAsInt (D)I - -
in 68
class com/machinezoo/noexception/optional/FallbackDoubleToLongFunction 55 final,super java/lang/Object java/util/function/DoubleToLongFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleToLongFunction;Ljava/util/function/LongSupplier;)V - -
 method public applyAsLong (D)J - -
in 68
class com/machinezoo/noexception/optional/FallbackDoubleUnaryOperator 55 final,super java/lang/Object java/util/function/DoubleUnaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalDoubleUnaryOperator;Ljava/util/function/DoubleSupplier;)V - -
 method public applyAsDouble (D)D - -
in 68
class com/machinezoo/noexception/optional/FallbackFunction 55 final,super java/lang/Object java/util/function/Function <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalFunction;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalFunction<TT;TR;>;Ljava/util/function/Supplier<TR;>;)V -
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR; -
in 68
class com/machinezoo/noexception/optional/FallbackIntBinaryOperator 55 final,super java/lang/Object java/util/function/IntBinaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntBinaryOperator;Ljava/util/function/IntSupplier;)V - -
 method public applyAsInt (II)I - -
in 68
class com/machinezoo/noexception/optional/FallbackIntFunction 55 final,super java/lang/Object java/util/function/IntFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/IntFunction<TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntFunction;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalIntFunction<TR;>;Ljava/util/function/Supplier<TR;>;)V -
 method public apply (I)Ljava/lang/Object; (I)TR; -
in 68
class com/machinezoo/noexception/optional/FallbackIntPredicate 55 final,super java/lang/Object java/util/function/IntPredicate -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntPredicate;Ljava/util/function/BooleanSupplier;)V - -
 method public test (I)Z - -
in 68
class com/machinezoo/noexception/optional/FallbackIntSupplier 55 final,super java/lang/Object java/util/function/IntSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntSupplier;Ljava/util/function/IntSupplier;)V - -
 method public getAsInt ()I - -
in 68
class com/machinezoo/noexception/optional/FallbackIntToDoubleFunction 55 final,super java/lang/Object java/util/function/IntToDoubleFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntToDoubleFunction;Ljava/util/function/DoubleSupplier;)V - -
 method public applyAsDouble (I)D - -
in 68
class com/machinezoo/noexception/optional/FallbackIntToLongFunction 55 final,super java/lang/Object java/util/function/IntToLongFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntToLongFunction;Ljava/util/function/LongSupplier;)V - -
 method public applyAsLong (I)J - -
in 68
class com/machinezoo/noexception/optional/FallbackIntUnaryOperator 55 final,super java/lang/Object java/util/function/IntUnaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalIntUnaryOperator;Ljava/util/function/IntSupplier;)V - -
 method public applyAsInt (I)I - -
in 68
class com/machinezoo/noexception/optional/FallbackLongBinaryOperator 55 final,super java/lang/Object java/util/function/LongBinaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongBinaryOperator;Ljava/util/function/LongSupplier;)V - -
 method public applyAsLong (JJ)J - -
in 68
class com/machinezoo/noexception/optional/FallbackLongFunction 55 final,super java/lang/Object java/util/function/LongFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/LongFunction<TR;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongFunction;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalLongFunction<TR;>;Ljava/util/function/Supplier<TR;>;)V -
 method public apply (J)Ljava/lang/Object; (J)TR; -
in 68
class com/machinezoo/noexception/optional/FallbackLongPredicate 55 final,super java/lang/Object java/util/function/LongPredicate -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongPredicate;Ljava/util/function/BooleanSupplier;)V - -
 method public test (J)Z - -
in 68
class com/machinezoo/noexception/optional/FallbackLongSupplier 55 final,super java/lang/Object java/util/function/LongSupplier -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongSupplier;Ljava/util/function/LongSupplier;)V - -
 method public getAsLong ()J - -
in 68
class com/machinezoo/noexception/optional/FallbackLongToDoubleFunction 55 final,super java/lang/Object java/util/function/LongToDoubleFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongToDoubleFunction;Ljava/util/function/DoubleSupplier;)V - -
 method public applyAsDouble (J)D - -
in 68
class com/machinezoo/noexception/optional/FallbackLongToIntFunction 55 final,super java/lang/Object java/util/function/LongToIntFunction -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongToIntFunction;Ljava/util/function/IntSupplier;)V - -
 method public applyAsInt (J)I - -
in 68
class com/machinezoo/noexception/optional/FallbackLongUnaryOperator 55 final,super java/lang/Object java/util/function/LongUnaryOperator -
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalLongUnaryOperator;Ljava/util/function/LongSupplier;)V - -
 method public applyAsLong (J)J - -
in 68
class com/machinezoo/noexception/optional/FallbackPredicate 55 final,super java/lang/Object java/util/function/Predicate <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Predicate<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalPredicate;Ljava/util/function/BooleanSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalPredicate<TT;>;Ljava/util/function/BooleanSupplier;)V -
 method public test (Ljava/lang/Object;)Z (TT;)Z -
in 68
class com/machinezoo/noexception/optional/FallbackSupplier 55 final,super java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalSupplier;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalSupplier<TT;>;Ljava/util/function/Supplier<TT;>;)V -
 method public get ()Ljava/lang/Object; ()TT; -
in 68
class com/machinezoo/noexception/optional/FallbackToDoubleBiFunction 55 final,super java/lang/Object java/util/function/ToDoubleBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleBiFunction<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToDoubleBiFunction;Ljava/util/function/DoubleSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalToDoubleBiFunction<TT;TU;>;Ljava/util/function/DoubleSupplier;)V -
 method public applyAsDouble (Ljava/lang/Object;Ljava/lang/Object;)D (TT;TU;)D -
in 68
class com/machinezoo/noexception/optional/FallbackToDoubleFunction 55 final,super java/lang/Object java/util/function/ToDoubleFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToDoubleFunction<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToDoubleFunction;Ljava/util/function/DoubleSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalToDoubleFunction<TT;>;Ljava/util/function/DoubleSupplier;)V -
 method public applyAsDouble (Ljava/lang/Object;)D (TT;)D -
in 68
class com/machinezoo/noexception/optional/FallbackToIntBiFunction 55 final,super java/lang/Object java/util/function/ToIntBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntBiFunction<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToIntBiFunction;Ljava/util/function/IntSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalToIntBiFunction<TT;TU;>;Ljava/util/function/IntSupplier;)V -
 method public applyAsInt (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TU;)I -
in 68
class com/machinezoo/noexception/optional/FallbackToIntFunction 55 final,super java/lang/Object java/util/function/ToIntFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToIntFunction<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToIntFunction;Ljava/util/function/IntSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalToIntFunction<TT;>;Ljava/util/function/IntSupplier;)V -
 method public applyAsInt (Ljava/lang/Object;)I (TT;)I -
in 68
class com/machinezoo/noexception/optional/FallbackToLongBiFunction 55 final,super java/lang/Object java/util/function/ToLongBiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongBiFunction<TT;TU;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToLongBiFunction;Ljava/util/function/LongSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalToLongBiFunction<TT;TU;>;Ljava/util/function/LongSupplier;)V -
 method public applyAsLong (Ljava/lang/Object;Ljava/lang/Object;)J (TT;TU;)J -
in 68
class com/machinezoo/noexception/optional/FallbackToLongFunction 55 final,super java/lang/Object java/util/function/ToLongFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/ToLongFunction<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalToLongFunction;Ljava/util/function/LongSupplier;)V (Lcom/machinezoo/noexception/optional/OptionalToLongFunction<TT;>;Ljava/util/function/LongSupplier;)V -
 method public applyAsLong (Ljava/lang/Object;)J (TT;)J -
in 68
class com/machinezoo/noexception/optional/FallbackUnaryOperator 55 final,super java/lang/Object java/util/function/UnaryOperator <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/UnaryOperator<TT;>;
 method public <init> (Lcom/machinezoo/noexception/optional/OptionalUnaryOperator;Ljava/util/function/Supplier;)V (Lcom/machinezoo/noexception/optional/OptionalUnaryOperator<TT;>;Ljava/util/function/Supplier<TT;>;)V -
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TT; -
in 68
class com/machinezoo/noexception/optional/OptionalBiFunction 55 public,interface,abstract java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;Ljava/util/Optional<TR;>;>;
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Optional; (TT;TU;)Ljava/util/Optional<TR;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/BiFunction; (TR;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/BiFunction; (Ljava/util/function/Supplier<TR;>;)Ljava/util/function/BiFunction<TT;TU;TR;>; -
in 68
class com/machinezoo/noexception/optional/OptionalBiPredicate 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract test (Ljava/lang/Object;Ljava/lang/Object;)Lcom/machinezoo/noexception/optional/OptionalBoolean; (TT;TU;)Lcom/machinezoo/noexception/optional/OptionalBoolean; -
 method public orElse (Z)Ljava/util/function/BiPredicate; (Z)Ljava/util/function/BiPredicate<TT;TU;>; -
 method public orElseGet (Ljava/util/function/BooleanSupplier;)Ljava/util/function/BiPredicate; (Ljava/util/function/BooleanSupplier;)Ljava/util/function/BiPredicate<TT;TU;>; -
in 68
class com/machinezoo/noexception/optional/OptionalBinaryOperator 55 public,interface,abstract java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TT;Ljava/util/Optional<TT;>;>;
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Optional; (TT;TT;)Ljava/util/Optional<TT;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/BinaryOperator; (TT;)Ljava/util/function/BinaryOperator<TT;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/BinaryOperator; (Ljava/util/function/Supplier<TT;>;)Ljava/util/function/BinaryOperator<TT;>; -
in 68
class com/machinezoo/noexception/optional/OptionalBoolean 55 public,final,super java/lang/Object - -
 method public,static empty ()Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
 method public,static of (Z)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
 method public isPresent ()Z - -
 method public getAsBoolean ()Z - -
 method public orElse (Z)Z - -
 method public orElseGet (Ljava/util/function/BooleanSupplier;)Z - -
 method public orElseThrow (Ljava/util/function/Supplier;)Z <X:Ljava/lang/Throwable;>(Ljava/util/function/Supplier<TX;>;)Z^TX; java/lang/Throwable
 method public orElseThrow ()Z - -
 method public stream ()Ljava/util/stream/IntStream; - -
 method public ifPresent (Ljava/util/function/IntConsumer;)V - -
 method public ifPresentOrElse (Ljava/util/function/IntConsumer;Ljava/lang/Runnable;)V - -
 method public toInt ()Ljava/util/OptionalInt; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 68
class com/machinezoo/noexception/optional/OptionalBooleanSupplier 55 public,interface,abstract java/lang/Object java/util/function/Supplier Ljava/lang/Object;Ljava/util/function/Supplier<Lcom/machinezoo/noexception/optional/OptionalBoolean;>;
 method public,abstract get ()Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
 method public orElse (Z)Ljava/util/function/BooleanSupplier; - -
 method public orElseGet (Ljava/util/function/BooleanSupplier;)Ljava/util/function/BooleanSupplier; - -
in 68
class com/machinezoo/noexception/optional/OptionalComparator 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract compare (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalInt; (TT;TT;)Ljava/util/OptionalInt; -
 method public orElse (I)Ljava/util/Comparator; (I)Ljava/util/Comparator<TT;>; -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/Comparator; (Ljava/util/function/IntSupplier;)Ljava/util/Comparator<TT;>; -
in 68
class com/machinezoo/noexception/optional/OptionalDoubleBinaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract apply (DD)Ljava/util/OptionalDouble; - -
 method public orElse (D)Ljava/util/function/DoubleBinaryOperator; - -
 method public orElseGet (Ljava/util/function/DoubleSupplier;)Ljava/util/function/DoubleBinaryOperator; - -
in 68
class com/machinezoo/noexception/optional/OptionalDoubleFunction 55 public,interface,abstract java/lang/Object java/util/function/DoubleFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/DoubleFunction<Ljava/util/Optional<TR;>;>;
 method public,abstract apply (D)Ljava/util/Optional; (D)Ljava/util/Optional<TR;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/DoubleFunction; (TR;)Ljava/util/function/DoubleFunction<TR;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/DoubleFunction; (Ljava/util/function/Supplier<TR;>;)Ljava/util/function/DoubleFunction<TR;>; -
in 68
class com/machinezoo/noexception/optional/OptionalDoublePredicate 55 public,interface,abstract java/lang/Object - -
 method public,abstract test (D)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
 method public orElse (Z)Ljava/util/function/DoublePredicate; - -
 method public orElseGet (Ljava/util/function/BooleanSupplier;)Ljava/util/function/DoublePredicate; - -
in 68
class com/machinezoo/noexception/optional/OptionalDoubleSupplier 55 public,interface,abstract java/lang/Object java/util/function/Supplier Ljava/lang/Object;Ljava/util/function/Supplier<Ljava/util/OptionalDouble;>;
 method public,abstract get ()Ljava/util/OptionalDouble; - -
 method public orElse (D)Ljava/util/function/DoubleSupplier; - -
 method public orElseGet (Ljava/util/function/DoubleSupplier;)Ljava/util/function/DoubleSupplier; - -
in 68
class com/machinezoo/noexception/optional/OptionalDoubleToIntFunction 55 public,interface,abstract java/lang/Object java/util/function/DoubleFunction Ljava/lang/Object;Ljava/util/function/DoubleFunction<Ljava/util/OptionalInt;>;
 method public,abstract apply (D)Ljava/util/OptionalInt; - -
 method public orElse (I)Ljava/util/function/DoubleToIntFunction; - -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/function/DoubleToIntFunction; - -
in 68
class com/machinezoo/noexception/optional/OptionalDoubleToLongFunction 55 public,interface,abstract java/lang/Object java/util/function/DoubleFunction Ljava/lang/Object;Ljava/util/function/DoubleFunction<Ljava/util/OptionalLong;>;
 method public,abstract apply (D)Ljava/util/OptionalLong; - -
 method public orElse (J)Ljava/util/function/DoubleToLongFunction; - -
 method public orElseGet (Ljava/util/function/LongSupplier;)Ljava/util/function/DoubleToLongFunction; - -
in 68
class com/machinezoo/noexception/optional/OptionalDoubleUnaryOperator 55 public,interface,abstract java/lang/Object java/util/function/DoubleFunction Ljava/lang/Object;Ljava/util/function/DoubleFunction<Ljava/util/OptionalDouble;>;
 method public,abstract apply (D)Ljava/util/OptionalDouble; - -
 method public orElse (D)Ljava/util/function/DoubleUnaryOperator; - -
 method public orElseGet (Ljava/util/function/DoubleSupplier;)Ljava/util/function/DoubleUnaryOperator; - -
in 68
class com/machinezoo/noexception/optional/OptionalFunction 55 public,interface,abstract java/lang/Object java/util/function/Function <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;Ljava/util/Optional<TR;>;>;
 method public,abstract apply (Ljava/lang/Object;)Ljava/util/Optional; (TT;)Ljava/util/Optional<TR;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/Function; (TR;)Ljava/util/function/Function<TT;TR;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/Function; (Ljava/util/function/Supplier<TR;>;)Ljava/util/function/Function<TT;TR;>; -
in 68
class com/machinezoo/noexception/optional/OptionalIntBinaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract apply (II)Ljava/util/OptionalInt; - -
 method public orElse (I)Ljava/util/function/IntBinaryOperator; - -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/function/IntBinaryOperator; - -
in 68
class com/machinezoo/noexception/optional/OptionalIntFunction 55 public,interface,abstract java/lang/Object java/util/function/IntFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/IntFunction<Ljava/util/Optional<TR;>;>;
 method public,abstract apply (I)Ljava/util/Optional; (I)Ljava/util/Optional<TR;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/IntFunction; (TR;)Ljava/util/function/IntFunction<TR;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/IntFunction; (Ljava/util/function/Supplier<TR;>;)Ljava/util/function/IntFunction<TR;>; -
in 68
class com/machinezoo/noexception/optional/OptionalIntPredicate 55 public,interface,abstract java/lang/Object - -
 method public,abstract test (I)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
 method public orElse (Z)Ljava/util/function/IntPredicate; - -
 method public orElseGet (Ljava/util/function/BooleanSupplier;)Ljava/util/function/IntPredicate; - -
in 68
class com/machinezoo/noexception/optional/OptionalIntSupplier 55 public,interface,abstract java/lang/Object java/util/function/Supplier Ljava/lang/Object;Ljava/util/function/Supplier<Ljava/util/OptionalInt;>;
 method public,abstract get ()Ljava/util/OptionalInt; - -
 method public orElse (I)Ljava/util/function/IntSupplier; - -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/function/IntSupplier; - -
in 68
class com/machinezoo/noexception/optional/OptionalIntToDoubleFunction 55 public,interface,abstract java/lang/Object java/util/function/IntFunction Ljava/lang/Object;Ljava/util/function/IntFunction<Ljava/util/OptionalDouble;>;
 method public,abstract apply (I)Ljava/util/OptionalDouble; - -
 method public orElse (D)Ljava/util/function/IntToDoubleFunction; - -
 method public orElseGet (Ljava/util/function/DoubleSupplier;)Ljava/util/function/IntToDoubleFunction; - -
in 68
class com/machinezoo/noexception/optional/OptionalIntToLongFunction 55 public,interface,abstract java/lang/Object java/util/function/IntFunction Ljava/lang/Object;Ljava/util/function/IntFunction<Ljava/util/OptionalLong;>;
 method public,abstract apply (I)Ljava/util/OptionalLong; - -
 method public orElse (J)Ljava/util/function/IntToLongFunction; - -
 method public orElseGet (Ljava/util/function/LongSupplier;)Ljava/util/function/IntToLongFunction; - -
in 68
class com/machinezoo/noexception/optional/OptionalIntUnaryOperator 55 public,interface,abstract java/lang/Object java/util/function/IntFunction Ljava/lang/Object;Ljava/util/function/IntFunction<Ljava/util/OptionalInt;>;
 method public,abstract apply (I)Ljava/util/OptionalInt; - -
 method public orElse (I)Ljava/util/function/IntUnaryOperator; - -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/function/IntUnaryOperator; - -
in 68
class com/machinezoo/noexception/optional/OptionalLongBinaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract apply (JJ)Ljava/util/OptionalLong; - -
 method public orElse (J)Ljava/util/function/LongBinaryOperator; - -
 method public orElseGet (Ljava/util/function/LongSupplier;)Ljava/util/function/LongBinaryOperator; - -
in 68
class com/machinezoo/noexception/optional/OptionalLongFunction 55 public,interface,abstract java/lang/Object java/util/function/LongFunction <R:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/LongFunction<Ljava/util/Optional<TR;>;>;
 method public,abstract apply (J)Ljava/util/Optional; (J)Ljava/util/Optional<TR;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/LongFunction; (TR;)Ljava/util/function/LongFunction<TR;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/LongFunction; (Ljava/util/function/Supplier<TR;>;)Ljava/util/function/LongFunction<TR;>; -
in 68
class com/machinezoo/noexception/optional/OptionalLongPredicate 55 public,interface,abstract java/lang/Object - -
 method public,abstract test (J)Lcom/machinezoo/noexception/optional/OptionalBoolean; - -
 method public orElse (Z)Ljava/util/function/LongPredicate; - -
 method public orElseGet (Ljava/util/function/BooleanSupplier;)Ljava/util/function/LongPredicate; - -
in 68
class com/machinezoo/noexception/optional/OptionalLongSupplier 55 public,interface,abstract java/lang/Object java/util/function/Supplier Ljava/lang/Object;Ljava/util/function/Supplier<Ljava/util/OptionalLong;>;
 method public,abstract get ()Ljava/util/OptionalLong; - -
 method public orElse (J)Ljava/util/function/LongSupplier; - -
 method public orElseGet (Ljava/util/function/LongSupplier;)Ljava/util/function/LongSupplier; - -
in 68
class com/machinezoo/noexception/optional/OptionalLongToDoubleFunction 55 public,interface,abstract java/lang/Object java/util/function/LongFunction Ljava/lang/Object;Ljava/util/function/LongFunction<Ljava/util/OptionalDouble;>;
 method public,abstract apply (J)Ljava/util/OptionalDouble; - -
 method public orElse (D)Ljava/util/function/LongToDoubleFunction; - -
 method public orElseGet (Ljava/util/function/DoubleSupplier;)Ljava/util/function/LongToDoubleFunction; - -
in 68
class com/machinezoo/noexception/optional/OptionalLongToIntFunction 55 public,interface,abstract java/lang/Object java/util/function/LongFunction Ljava/lang/Object;Ljava/util/function/LongFunction<Ljava/util/OptionalInt;>;
 method public,abstract apply (J)Ljava/util/OptionalInt; - -
 method public orElse (I)Ljava/util/function/LongToIntFunction; - -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/function/LongToIntFunction; - -
in 68
class com/machinezoo/noexception/optional/OptionalLongUnaryOperator 55 public,interface,abstract java/lang/Object java/util/function/LongFunction Ljava/lang/Object;Ljava/util/function/LongFunction<Ljava/util/OptionalLong;>;
 method public,abstract apply (J)Ljava/util/OptionalLong; - -
 method public orElse (J)Ljava/util/function/LongUnaryOperator; - -
 method public orElseGet (Ljava/util/function/LongSupplier;)Ljava/util/function/LongUnaryOperator; - -
in 68
class com/machinezoo/noexception/optional/OptionalPredicate 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract test (Ljava/lang/Object;)Lcom/machinezoo/noexception/optional/OptionalBoolean; (TT;)Lcom/machinezoo/noexception/optional/OptionalBoolean; -
 method public orElse (Z)Ljava/util/function/Predicate; (Z)Ljava/util/function/Predicate<TT;>; -
 method public orElseGet (Ljava/util/function/BooleanSupplier;)Ljava/util/function/Predicate; (Ljava/util/function/BooleanSupplier;)Ljava/util/function/Predicate<TT;>; -
in 68
class com/machinezoo/noexception/optional/OptionalSupplier 55 public,interface,abstract java/lang/Object java/util/function/Supplier <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Supplier<Ljava/util/Optional<TT;>;>;
 method public,abstract get ()Ljava/util/Optional; ()Ljava/util/Optional<TT;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/Supplier; (TT;)Ljava/util/function/Supplier<TT;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/Supplier; (Ljava/util/function/Supplier<TT;>;)Ljava/util/function/Supplier<TT;>; -
in 68
class com/machinezoo/noexception/optional/OptionalToDoubleBiFunction 55 public,interface,abstract java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;Ljava/util/OptionalDouble;>;
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalDouble; (TT;TU;)Ljava/util/OptionalDouble; -
 method public orElse (D)Ljava/util/function/ToDoubleBiFunction; (D)Ljava/util/function/ToDoubleBiFunction<TT;TU;>; -
 method public orElseGet (Ljava/util/function/DoubleSupplier;)Ljava/util/function/ToDoubleBiFunction; (Ljava/util/function/DoubleSupplier;)Ljava/util/function/ToDoubleBiFunction<TT;TU;>; -
in 68
class com/machinezoo/noexception/optional/OptionalToDoubleFunction 55 public,interface,abstract java/lang/Object java/util/function/Function <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;Ljava/util/OptionalDouble;>;
 method public,abstract apply (Ljava/lang/Object;)Ljava/util/OptionalDouble; (TT;)Ljava/util/OptionalDouble; -
 method public orElse (D)Ljava/util/function/ToDoubleFunction; (D)Ljava/util/function/ToDoubleFunction<TT;>; -
 method public orElseGet (Ljava/util/function/DoubleSupplier;)Ljava/util/function/ToDoubleFunction; (Ljava/util/function/DoubleSupplier;)Ljava/util/function/ToDoubleFunction<TT;>; -
in 68
class com/machinezoo/noexception/optional/OptionalToIntBiFunction 55 public,interface,abstract java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;Ljava/util/OptionalInt;>;
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalInt; (TT;TU;)Ljava/util/OptionalInt; -
 method public orElse (I)Ljava/util/function/ToIntBiFunction; (I)Ljava/util/function/ToIntBiFunction<TT;TU;>; -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/function/ToIntBiFunction; (Ljava/util/function/IntSupplier;)Ljava/util/function/ToIntBiFunction<TT;TU;>; -
in 68
class com/machinezoo/noexception/optional/OptionalToIntFunction 55 public,interface,abstract java/lang/Object java/util/function/Function <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;Ljava/util/OptionalInt;>;
 method public,abstract apply (Ljava/lang/Object;)Ljava/util/OptionalInt; (TT;)Ljava/util/OptionalInt; -
 method public orElse (I)Ljava/util/function/ToIntFunction; (I)Ljava/util/function/ToIntFunction<TT;>; -
 method public orElseGet (Ljava/util/function/IntSupplier;)Ljava/util/function/ToIntFunction; (Ljava/util/function/IntSupplier;)Ljava/util/function/ToIntFunction<TT;>; -
in 68
class com/machinezoo/noexception/optional/OptionalToLongBiFunction 55 public,interface,abstract java/lang/Object java/util/function/BiFunction <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/BiFunction<TT;TU;Ljava/util/OptionalLong;>;
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/OptionalLong; (TT;TU;)Ljava/util/OptionalLong; -
 method public orElse (J)Ljava/util/function/ToLongBiFunction; (J)Ljava/util/function/ToLongBiFunction<TT;TU;>; -
 method public orElseGet (Ljava/util/function/LongSupplier;)Ljava/util/function/ToLongBiFunction; (Ljava/util/function/LongSupplier;)Ljava/util/function/ToLongBiFunction<TT;TU;>; -
in 68
class com/machinezoo/noexception/optional/OptionalToLongFunction 55 public,interface,abstract java/lang/Object java/util/function/Function <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;Ljava/util/OptionalLong;>;
 method public,abstract apply (Ljava/lang/Object;)Ljava/util/OptionalLong; (TT;)Ljava/util/OptionalLong; -
 method public orElse (J)Ljava/util/function/ToLongFunction; (J)Ljava/util/function/ToLongFunction<TT;>; -
 method public orElseGet (Ljava/util/function/LongSupplier;)Ljava/util/function/ToLongFunction; (Ljava/util/function/LongSupplier;)Ljava/util/function/ToLongFunction<TT;>; -
in 68
class com/machinezoo/noexception/optional/OptionalUnaryOperator 55 public,interface,abstract java/lang/Object java/util/function/Function <T:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/function/Function<TT;Ljava/util/Optional<TT;>;>;
 method public,abstract apply (Ljava/lang/Object;)Ljava/util/Optional; (TT;)Ljava/util/Optional<TT;>; -
 method public orElse (Ljava/lang/Object;)Ljava/util/function/UnaryOperator; (TT;)Ljava/util/function/UnaryOperator<TT;>; -
 method public orElseGet (Ljava/util/function/Supplier;)Ljava/util/function/UnaryOperator; (Ljava/util/function/Supplier<TT;>;)Ljava/util/function/UnaryOperator<TT;>; -
in 68
class com/machinezoo/noexception/throwing/ThrowingBiConsumer 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract accept (Ljava/lang/Object;Ljava/lang/Object;)V (TT;TU;)V java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingBiFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT;TU;)TR; java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingBiPredicate 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract test (Ljava/lang/Object;Ljava/lang/Object;)Z (TT;TU;)Z java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingBinaryOperator 55 public,interface,abstract java/lang/Object com/machinezoo/noexception/throwing/ThrowingBiFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/throwing/ThrowingBiFunction<TT;TT;TT;>;
in 68
class com/machinezoo/noexception/throwing/ThrowingBooleanSupplier 55 public,interface,abstract java/lang/Object - -
 method public,abstract getAsBoolean ()Z - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingComparator 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract compare (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TT;)I java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingConsumer 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract accept (Ljava/lang/Object;)V (TT;)V java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoubleBinaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsDouble (DD)D - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoubleConsumer 55 public,interface,abstract java/lang/Object - -
 method public,abstract accept (D)V - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoubleFunction 55 public,interface,abstract java/lang/Object - <R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (D)Ljava/lang/Object; (D)TR; java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoublePredicate 55 public,interface,abstract java/lang/Object - -
 method public,abstract test (D)Z - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoubleSupplier 55 public,interface,abstract java/lang/Object - -
 method public,abstract getAsDouble ()D - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoubleToIntFunction 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsInt (D)I - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoubleToLongFunction 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsLong (D)J - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingDoubleUnaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsDouble (D)D - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR; java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntBinaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsInt (II)I - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntConsumer 55 public,interface,abstract java/lang/Object - -
 method public,abstract accept (I)V - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntFunction 55 public,interface,abstract java/lang/Object - <R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (I)Ljava/lang/Object; (I)TR; java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntPredicate 55 public,interface,abstract java/lang/Object - -
 method public,abstract test (I)Z - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntSupplier 55 public,interface,abstract java/lang/Object - -
 method public,abstract getAsInt ()I - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntToDoubleFunction 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsDouble (I)D - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntToLongFunction 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsLong (I)J - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingIntUnaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsInt (I)I - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongBinaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsLong (JJ)J - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongConsumer 55 public,interface,abstract java/lang/Object - -
 method public,abstract accept (J)V - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongFunction 55 public,interface,abstract java/lang/Object - <R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (J)Ljava/lang/Object; (J)TR; java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongPredicate 55 public,interface,abstract java/lang/Object - -
 method public,abstract test (J)Z - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongSupplier 55 public,interface,abstract java/lang/Object - -
 method public,abstract getAsLong ()J - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongToDoubleFunction 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsDouble (J)D - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongToIntFunction 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsInt (J)I - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingLongUnaryOperator 55 public,interface,abstract java/lang/Object - -
 method public,abstract applyAsLong (J)J - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingObjDoubleConsumer 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract accept (Ljava/lang/Object;D)V (TT;D)V java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingObjIntConsumer 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract accept (Ljava/lang/Object;I)V (TT;I)V java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingObjLongConsumer 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract accept (Ljava/lang/Object;J)V (TT;J)V java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingPredicate 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract test (Ljava/lang/Object;)Z (TT;)Z java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingRunnable 55 public,interface,abstract java/lang/Object - -
 method public,abstract run ()V - java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingSupplier 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract get ()Ljava/lang/Object; ()TT; java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingToDoubleBiFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract applyAsDouble (Ljava/lang/Object;Ljava/lang/Object;)D (TT;TU;)D java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingToDoubleFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract applyAsDouble (Ljava/lang/Object;)D (TT;)D java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingToIntBiFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract applyAsInt (Ljava/lang/Object;Ljava/lang/Object;)I (TT;TU;)I java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingToIntFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract applyAsInt (Ljava/lang/Object;)I (TT;)I java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingToLongBiFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract applyAsLong (Ljava/lang/Object;Ljava/lang/Object;)J (TT;TU;)J java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingToLongFunction 55 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract applyAsLong (Ljava/lang/Object;)J (TT;)J java/lang/Throwable
in 68
class com/machinezoo/noexception/throwing/ThrowingUnaryOperator 55 public,interface,abstract java/lang/Object com/machinezoo/noexception/throwing/ThrowingFunction <T:Ljava/lang/Object;>Ljava/lang/Object;Lcom/machinezoo/noexception/throwing/ThrowingFunction<TT;TT;>;
