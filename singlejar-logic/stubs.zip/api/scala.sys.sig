cg-stub-db 1
in 0
class scala/sys/BooleanProp 50 public,interface,abstract java/lang/Object scala/sys/Prop Ljava/lang/Object;Lscala/sys/Prop<Ljava/lang/Object;>;
 inner scala/sys/BooleanProp$ConstantImpl scala/sys/BooleanProp ConstantImpl public,static
 inner scala/sys/BooleanProp$BooleanPropImpl scala/sys/BooleanProp BooleanPropImpl public,static
 method public,abstract value ()Z - -
 method public,abstract enable ()V - -
 method public,abstract disable ()V - -
 method public,abstract toggle ()V - -
in 0
class scala/sys/BooleanProp$ 50 public,final,super java/lang/Object - -
 inner scala/sys/BooleanProp$ConstantImpl scala/sys/BooleanProp ConstantImpl public,static
 inner scala/sys/BooleanProp$BooleanPropImpl scala/sys/BooleanProp BooleanPropImpl public,static
 field public,static,final MODULE$ Lscala/sys/BooleanProp$; -
 method public,static <clinit> ()V - -
 method public valueIsTrue (Ljava/lang/String;)Lscala/sys/BooleanProp; <T:Ljava/lang/Object;>(Ljava/lang/String;)Lscala/sys/BooleanProp; -
 method public keyExists (Ljava/lang/String;)Lscala/sys/BooleanProp; <T:Ljava/lang/Object;>(Ljava/lang/String;)Lscala/sys/BooleanProp; -
 method public constant (Ljava/lang/String;Z)Lscala/sys/BooleanProp; - -
 method public booleanPropAsBoolean (Lscala/sys/BooleanProp;)Z - -
in 0
class scala/sys/BooleanProp$BooleanPropImpl 50 public,super scala/sys/PropImpl scala/sys/BooleanProp Lscala/sys/PropImpl<Ljava/lang/Object;>;Lscala/sys/BooleanProp;
 inner scala/sys/BooleanProp$BooleanPropImpl scala/sys/BooleanProp BooleanPropImpl public,static
 method public setValue (Ljava/lang/Object;)Z <T1:Ljava/lang/Object;>(TT1;)Z -
 method public enable ()V - -
 method public disable ()V - -
 method public toggle ()V - -
 method public <init> (Ljava/lang/String;Lscala/Function1;)V (Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Ljava/lang/Object;>;)V -
in 0
class scala/sys/BooleanProp$ConstantImpl 50 public,super java/lang/Object scala/sys/BooleanProp -
 inner scala/sys/BooleanProp$ConstantImpl scala/sys/BooleanProp ConstantImpl public,static
 method public key ()Ljava/lang/String; - -
 method public value ()Z - -
 method public isSet ()Z - -
 method public set (Ljava/lang/String;)Ljava/lang/String; - -
 method public setValue (Ljava/lang/Object;)Z <T1:Ljava/lang/Object;>(TT1;)Z -
 method public get ()Ljava/lang/String; - -
 method public clear ()V - -
 method public enable ()V - -
 method public disable ()V - -
 method public toggle ()V - -
 method public option ()Lscala/Option; ()Lscala/Option<Ljava/lang/Object;>; -
 method public zero ()Z - -
 method public <init> (Ljava/lang/String;Z)V - -
in 0
class scala/sys/CreatorImpl 50 public,super,abstract java/lang/Object scala/sys/Prop$Creator <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/sys/Prop$Creator<TT;>;
 inner scala/sys/Prop$Creator scala/sys/Prop Creator public,static,interface,abstract
 method public apply (Ljava/lang/String;)Lscala/sys/Prop; (Ljava/lang/String;)Lscala/sys/Prop<TT;>; -
 method public <init> (Lscala/Function1;)V (Lscala/Function1<Ljava/lang/String;TT;>;)V -
in 0
class scala/sys/Prop 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner scala/sys/Prop$Creator scala/sys/Prop Creator public,static,interface,abstract
 inner scala/sys/Prop$IntProp$ scala/sys/Prop IntProp$ public,static
 inner scala/sys/Prop$FileProp$ scala/sys/Prop FileProp$ public,static
 inner scala/sys/Prop$StringProp$ scala/sys/Prop StringProp$ public,static
 inner scala/sys/Prop$DoubleProp$ scala/sys/Prop DoubleProp$ public,static
 method public,abstract key ()Ljava/lang/String; - -
 method public,abstract value ()Ljava/lang/Object; ()TT; -
 method public,abstract isSet ()Z - -
 method public,abstract set (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract setValue (Ljava/lang/Object;)Ljava/lang/Object; <T1:Ljava/lang/Object;>(TT1;)TT; -
 method public,abstract get ()Ljava/lang/String; - -
 method public,abstract option ()Lscala/Option; ()Lscala/Option<TT;>; -
 method public,abstract clear ()V - -
 method public,abstract zero ()Ljava/lang/Object; ()TT; -
in 0
class scala/sys/Prop$ 50 public,final,super java/lang/Object - -
 inner scala/sys/Prop$Creator scala/sys/Prop Creator public,static,interface,abstract
 inner scala/sys/Prop$IntProp$ scala/sys/Prop IntProp$ public,static
 inner scala/sys/Prop$FileProp$ scala/sys/Prop FileProp$ public,static
 inner scala/sys/Prop$StringProp$ scala/sys/Prop StringProp$ public,static
 inner scala/sys/Prop$DoubleProp$ scala/sys/Prop DoubleProp$ public,static
 field public,static,final MODULE$ Lscala/sys/Prop$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/lang/String;Lscala/sys/Prop$Creator;)Lscala/sys/Prop; <T:Ljava/lang/Object;>(Ljava/lang/String;Lscala/sys/Prop$Creator<TT;>;)Lscala/sys/Prop<TT;>; -
in 0
class scala/sys/Prop$Creator 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner scala/sys/Prop$Creator scala/sys/Prop Creator public,static,interface,abstract
 method public,abstract apply (Ljava/lang/String;)Lscala/sys/Prop; (Ljava/lang/String;)Lscala/sys/Prop<TT;>; -
in 0
class scala/sys/Prop$DoubleProp$ 50 public,super scala/sys/CreatorImpl - Lscala/sys/CreatorImpl<Ljava/lang/Object;>;
 inner scala/sys/Prop$DoubleProp$ scala/sys/Prop DoubleProp$ public,static
 field public,static,final MODULE$ Lscala/sys/Prop$DoubleProp$; -
 method public,static <clinit> ()V - -
 method public <init> ()V - -
in 0
class scala/sys/Prop$FileProp$ 50 public,super scala/sys/CreatorImpl - Lscala/sys/CreatorImpl<Ljava/io/File;>;
 inner scala/sys/Prop$FileProp$ scala/sys/Prop FileProp$ public,static
 field public,static,final MODULE$ Lscala/sys/Prop$FileProp$; -
 method public,static <clinit> ()V - -
 method public <init> ()V - -
in 0
class scala/sys/Prop$IntProp$ 50 public,super scala/sys/CreatorImpl - Lscala/sys/CreatorImpl<Ljava/lang/Object;>;
 inner scala/sys/Prop$IntProp$ scala/sys/Prop IntProp$ public,static
 field public,static,final MODULE$ Lscala/sys/Prop$IntProp$; -
 method public,static <clinit> ()V - -
 method public <init> ()V - -
in 0
class scala/sys/Prop$StringProp$ 50 public,super scala/sys/CreatorImpl - Lscala/sys/CreatorImpl<Ljava/lang/String;>;
 inner scala/sys/Prop$StringProp$ scala/sys/Prop StringProp$ public,static
 field public,static,final MODULE$ Lscala/sys/Prop$StringProp$; -
 method public,static <clinit> ()V - -
 method public <init> ()V - -
in 0
class scala/sys/PropImpl 50 public,super java/lang/Object scala/sys/Prop <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/sys/Prop<TT;>;
 method public key ()Ljava/lang/String; - -
 method public value ()Ljava/lang/Object; ()TT; -
 method public isSet ()Z - -
 method public set (Ljava/lang/String;)Ljava/lang/String; - -
 method public setValue (Ljava/lang/Object;)Ljava/lang/Object; <T1:Ljava/lang/Object;>(TT1;)TT; -
 method public get ()Ljava/lang/String; - -
 method public clear ()V - -
 method public option ()Lscala/Option; ()Lscala/Option<TT;>; -
 method public or (Lscala/Function0;)Ljava/lang/Object; <T1:Ljava/lang/Object;>(Lscala/Function0<TT1;>;)TT1; -
 method public underlying ()Lscala/collection/mutable/Map; ()Lscala/collection/mutable/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public zero ()Ljava/lang/Object; ()TT; -
 method public toString ()Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;Lscala/Function1;)V (Ljava/lang/String;Lscala/Function1<Ljava/lang/String;TT;>;)V -
in 0
class scala/sys/ShutdownHookThread 50 public,super java/lang/Thread - -
 method public,static apply (Lscala/Function0;)Lscala/sys/ShutdownHookThread; (Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Lscala/sys/ShutdownHookThread; -
 method public remove ()Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/sys/ShutdownHookThread$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/sys/ShutdownHookThread$; -
 method public,static <clinit> ()V - -
 method public,synchronized scala$sys$ShutdownHookThread$$hookName ()Ljava/lang/String; - -
 method public apply (Lscala/Function0;)Lscala/sys/ShutdownHookThread; (Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Lscala/sys/ShutdownHookThread; -
in 0
class scala/sys/SystemProperties 50 public,super scala/collection/mutable/AbstractMap - Lscala/collection/mutable/AbstractMap<Ljava/lang/String;Ljava/lang/String;>;Lscala/collection/mutable/Map<Ljava/lang/String;Ljava/lang/String;>;
 method public,static noTraceSupression ()Lscala/sys/BooleanProp; - -
 method public,static preferIPv6Addresses ()Lscala/sys/BooleanProp; - -
 method public,static preferIPv4Stack ()Lscala/sys/BooleanProp; - -
 method public,static headless ()Lscala/sys/BooleanProp; - -
 method public,static help (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static systemPropertiesToCompanion (Lscala/sys/SystemProperties;)Lscala/sys/SystemProperties$; - -
 method public,static exclusively (Lscala/Function0;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)TT; -
 method public empty ()Lscala/sys/SystemProperties; - -
 method public default (Ljava/lang/String;)Ljava/lang/String; - -
 method public iterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
 method public get (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public contains (Ljava/lang/String;)Z - -
 method public $minus$eq (Ljava/lang/String;)Lscala/sys/SystemProperties; - -
 method public $plus$eq (Lscala/Tuple2;)Lscala/sys/SystemProperties; (Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;)Lscala/sys/SystemProperties; -
 method public wrapAccess (Lscala/Function0;)Lscala/Option; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)Lscala/Option<TT;>; -
 method public <init> ()V - -
in 0
class scala/sys/SystemProperties$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/sys/SystemProperties$; -
 method public,static <clinit> ()V - -
 method public,synchronized exclusively (Lscala/Function0;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)TT; -
 method public systemPropertiesToCompanion (Lscala/sys/SystemProperties;)Lscala/sys/SystemProperties$; - -
 method public help (Ljava/lang/String;)Ljava/lang/String; - -
 method public headless ()Lscala/sys/BooleanProp; - -
 method public preferIPv4Stack ()Lscala/sys/BooleanProp; - -
 method public preferIPv6Addresses ()Lscala/sys/BooleanProp; - -
 method public noTraceSupression ()Lscala/sys/BooleanProp; - -
in 0
class scala/sys/package 50 public,final,super java/lang/Object - -
 method public,static allThreads ()Lscala/collection/IndexedSeq; ()Lscala/collection/IndexedSeq<Ljava/lang/Thread;>; -
 method public,static addShutdownHook (Lscala/Function0;)Lscala/sys/ShutdownHookThread; (Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Lscala/sys/ShutdownHookThread; -
 method public,static env ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static props ()Lscala/sys/SystemProperties; - -
 method public,static runtime ()Ljava/lang/Runtime; - -
 method public,static exit (I)Lscala/runtime/Nothing$; - -
 method public,static exit ()Lscala/runtime/Nothing$; - -
 method public,static error (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
in 0
class scala/sys/package$ 50 public,final,super java/lang/Object - -
 inner scala/collection/convert/Decorators$AsScala scala/collection/convert/Decorators AsScala public
 field public,static,final MODULE$ Lscala/sys/package$; -
 method public,static <clinit> ()V - -
 method public error (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public exit ()Lscala/runtime/Nothing$; - -
 method public exit (I)Lscala/runtime/Nothing$; - -
 method public runtime ()Ljava/lang/Runtime; - -
 method public props ()Lscala/sys/SystemProperties; - -
 method public env ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public addShutdownHook (Lscala/Function0;)Lscala/sys/ShutdownHookThread; (Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Lscala/sys/ShutdownHookThread; -
 method public allThreads ()Lscala/collection/IndexedSeq; ()Lscala/collection/IndexedSeq<Ljava/lang/Thread;>; -
in 0
class scala/sys/process/BasicIO 50 public,final,super java/lang/Object - -
 inner scala/sys/process/BasicIO$Streamed scala/sys/process/BasicIO Streamed public,static,final
 inner scala/sys/process/BasicIO$Streamed$ scala/sys/process/BasicIO Streamed$ public,static
 inner scala/sys/process/BasicIO$Uncloseable scala/sys/process/BasicIO Uncloseable public,static,interface,abstract
 inner scala/sys/process/BasicIO$Uncloseable$ scala/sys/process/BasicIO Uncloseable$ public,static
 inner scala/sys/process/BasicIO$Uncloseable$class scala/sys/process/BasicIO Uncloseable$class public,static,abstract
 method public,static transferFully (Ljava/io/InputStream;Ljava/io/OutputStream;)V - -
 method public,static toStdOut ()Lscala/Function1; ()Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public,static toStdErr ()Lscala/Function1; ()Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public,static standard (Lscala/Function1;)Lscala/sys/process/ProcessIO; (Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>;)Lscala/sys/process/ProcessIO; -
 method public,static standard (Z)Lscala/sys/process/ProcessIO; - -
 method public,static input (Z)Lscala/Function1; (Z)Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>; -
 method public,static connectToIn (Ljava/io/OutputStream;)V - -
 method public,static processLinesFully (Lscala/Function1;Lscala/Function0;)V (Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;Lscala/Function0<Ljava/lang/String;>;)V -
 method public,static processFully (Lscala/Function1;)Lscala/Function1; (Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;)Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public,static processFully (Ljava/lang/Appendable;)Lscala/Function1; (Ljava/lang/Appendable;)Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public,static close (Ljava/io/Closeable;)V - -
 method public,static getErr (Lscala/Option;)Lscala/Function1; (Lscala/Option<Lscala/sys/process/ProcessLogger;>;)Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public,static apply (ZLscala/sys/process/ProcessLogger;)Lscala/sys/process/ProcessIO; - -
 method public,static apply (ZLjava/lang/StringBuffer;Lscala/Option;)Lscala/sys/process/ProcessIO; (ZLjava/lang/StringBuffer;Lscala/Option<Lscala/sys/process/ProcessLogger;>;)Lscala/sys/process/ProcessIO; -
 method public,static apply (ZLscala/Function1;Lscala/Option;)Lscala/sys/process/ProcessIO; (ZLscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;Lscala/Option<Lscala/sys/process/ProcessLogger;>;)Lscala/sys/process/ProcessIO; -
 method public,static Newline ()Ljava/lang/String; - -
 method public,static BufferSize ()I - -
in 0
class scala/sys/process/BasicIO$ 50 public,final,super java/lang/Object - -
 inner scala/sys/process/BasicIO$Streamed scala/sys/process/BasicIO Streamed public,static,final
 inner scala/sys/process/BasicIO$Streamed$ scala/sys/process/BasicIO Streamed$ public,static
 inner scala/sys/process/BasicIO$Uncloseable$ scala/sys/process/BasicIO Uncloseable$ public,static
 inner scala/sys/process/BasicIO$Uncloseable scala/sys/process/BasicIO Uncloseable public,static,interface,abstract
 inner scala/sys/process/BasicIO$Uncloseable$class scala/sys/process/BasicIO Uncloseable$class public,static,abstract
 field public,static,final MODULE$ Lscala/sys/process/BasicIO$; -
 method public,static <clinit> ()V - -
 method public,final BufferSize ()I - -
 method public,final Newline ()Ljava/lang/String; - -
 method public apply (ZLscala/Function1;Lscala/Option;)Lscala/sys/process/ProcessIO; (ZLscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;Lscala/Option<Lscala/sys/process/ProcessLogger;>;)Lscala/sys/process/ProcessIO; -
 method public apply (ZLjava/lang/StringBuffer;Lscala/Option;)Lscala/sys/process/ProcessIO; (ZLjava/lang/StringBuffer;Lscala/Option<Lscala/sys/process/ProcessLogger;>;)Lscala/sys/process/ProcessIO; -
 method public apply (ZLscala/sys/process/ProcessLogger;)Lscala/sys/process/ProcessIO; - -
 method public getErr (Lscala/Option;)Lscala/Function1; (Lscala/Option<Lscala/sys/process/ProcessLogger;>;)Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public close (Ljava/io/Closeable;)V - -
 method public processFully (Ljava/lang/Appendable;)Lscala/Function1; (Ljava/lang/Appendable;)Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public processFully (Lscala/Function1;)Lscala/Function1; (Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;)Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public processLinesFully (Lscala/Function1;Lscala/Function0;)V (Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;Lscala/Function0<Ljava/lang/String;>;)V -
 method public connectToIn (Ljava/io/OutputStream;)V - -
 method public input (Z)Lscala/Function1; (Z)Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>; -
 method public standard (Z)Lscala/sys/process/ProcessIO; - -
 method public standard (Lscala/Function1;)Lscala/sys/process/ProcessIO; (Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>;)Lscala/sys/process/ProcessIO; -
 method public toStdErr ()Lscala/Function1; ()Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public toStdOut ()Lscala/Function1; ()Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public transferFully (Ljava/io/InputStream;Ljava/io/OutputStream;)V - -
in 0
class scala/sys/process/BasicIO$Streamed 50 public,final,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner scala/sys/process/BasicIO$Streamed scala/sys/process/BasicIO Streamed public,static,final
 method public process ()Lscala/Function1; ()Lscala/Function1<TT;Lscala/runtime/BoxedUnit;>; -
 method public done ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public stream ()Lscala/Function0; ()Lscala/Function0<Lscala/collection/immutable/Stream<TT;>;>; -
 method public <init> (Lscala/Function1;Lscala/Function1;Lscala/Function0;)V (Lscala/Function1<TT;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>;Lscala/Function0<Lscala/collection/immutable/Stream<TT;>;>;)V -
in 0
class scala/sys/process/BasicIO$Streamed$ 50 public,super java/lang/Object - -
 inner scala/collection/immutable/Stream$cons$ scala/collection/immutable/Stream cons$ public,static
 inner scala/collection/immutable/Stream$Cons scala/collection/immutable/Stream Cons public,static,final
 inner scala/collection/immutable/Stream$Empty$ scala/collection/immutable/Stream Empty$ public,static
 inner scala/sys/process/BasicIO$Streamed$ scala/sys/process/BasicIO Streamed$ public,static
 inner scala/sys/process/BasicIO$Streamed scala/sys/process/BasicIO Streamed public,static,final
 field public,static,final MODULE$ Lscala/sys/process/BasicIO$Streamed$; -
 method public,static <clinit> ()V - -
 method public apply (Z)Lscala/sys/process/BasicIO$Streamed; <T:Ljava/lang/Object;>(Z)Lscala/sys/process/BasicIO$Streamed<TT;>; -
 method public,final scala$sys$process$BasicIO$Streamed$$next$1 (ZLjava/util/concurrent/LinkedBlockingQueue;)Lscala/collection/immutable/Stream; - -
 method public <init> ()V - -
in 0
class scala/sys/process/BasicIO$Uncloseable 50 public,interface,abstract java/lang/Object java/io/Closeable -
 inner scala/sys/process/BasicIO$Uncloseable scala/sys/process/BasicIO Uncloseable public,static,interface,abstract
 method public,abstract close ()V - -
in 0
class scala/sys/process/BasicIO$Uncloseable$ 50 public,super java/lang/Object - -
 inner scala/sys/process/BasicIO$Uncloseable$ scala/sys/process/BasicIO Uncloseable$ public,static
 field public,static,final MODULE$ Lscala/sys/process/BasicIO$Uncloseable$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/io/InputStream;)Ljava/io/InputStream; - -
 method public apply (Ljava/io/OutputStream;)Ljava/io/OutputStream; - -
 method public protect (Ljava/io/InputStream;)Ljava/io/InputStream; - -
 method public protect (Ljava/io/OutputStream;)Ljava/io/OutputStream; - -
 method public <init> ()V - -
in 0
class scala/sys/process/BasicIO$Uncloseable$class 50 public,super,abstract java/lang/Object - -
 inner scala/sys/process/BasicIO$Uncloseable scala/sys/process/BasicIO Uncloseable public,static,interface,abstract
 inner scala/sys/process/BasicIO$Uncloseable$class scala/sys/process/BasicIO Uncloseable$class public,static,abstract
 method public,static,final close (Lscala/sys/process/BasicIO$Uncloseable;)V - -
 method public,static $init$ (Lscala/sys/process/BasicIO$Uncloseable;)V - -
in 0
class scala/sys/process/FileProcessLogger 50 public,super java/lang/Object scala/sys/process/ProcessLogger,java/io/Closeable,java/io/Flushable -
 method public out (Lscala/Function0;)V (Lscala/Function0<Ljava/lang/String;>;)V -
 method public err (Lscala/Function0;)V (Lscala/Function0<Ljava/lang/String;>;)V -
 method public buffer (Lscala/Function0;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)TT; -
 method public close ()V - -
 method public flush ()V - -
 method public <init> (Ljava/io/File;)V - -
in 0
class scala/sys/process/Process 50 public,interface,abstract java/lang/Object - -
 method public,abstract exitValue ()I - -
 method public,abstract destroy ()V - -
in 0
class scala/sys/process/Process$ 50 public,final,super java/lang/Object scala/sys/process/ProcessImpl,scala/sys/process/ProcessCreation -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessImpl$Future$ scala/sys/process/ProcessImpl Future$ public
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 field public,static,final MODULE$ Lscala/sys/process/Process$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/lang/String;)Lscala/sys/process/ProcessBuilder; - -
 method public apply (Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;)Lscala/sys/process/ProcessBuilder; -
 method public apply (Ljava/lang/String;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Lscala/collection/Seq<Ljava/lang/String;>;)Lscala/sys/process/ProcessBuilder; -
 method public apply (Ljava/lang/String;Ljava/io/File;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Ljava/io/File;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public apply (Lscala/collection/Seq;Ljava/io/File;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;Ljava/io/File;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public apply (Ljava/lang/String;Lscala/Option;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Lscala/Option<Ljava/io/File;>;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public apply (Lscala/collection/Seq;Lscala/Option;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;Lscala/Option<Ljava/io/File;>;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public apply (Ljava/lang/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public apply (Ljava/io/File;)Lscala/sys/process/ProcessBuilder$FileBuilder; - -
 method public apply (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder$URLBuilder; - -
 method public apply (Z)Lscala/sys/process/ProcessBuilder; - -
 method public apply (Ljava/lang/String;Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Lscala/Function0<Ljava/lang/Object;>;)Lscala/sys/process/ProcessBuilder; -
 method public applySeq (Lscala/collection/Seq;Lscala/Function1;)Lscala/collection/Seq; <T:Ljava/lang/Object;>(Lscala/collection/Seq<TT;>;Lscala/Function1<TT;Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>; -
 method public cat (Lscala/sys/process/ProcessBuilder$Source;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/sys/process/ProcessBuilder$Source;Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/sys/process/ProcessBuilder; -
 method public cat (Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/sys/process/ProcessBuilder; -
 method public Spawn ()Lscala/sys/process/ProcessImpl$Spawn$; - -
 method public Future ()Lscala/sys/process/ProcessImpl$Future$; - -
in 0
class scala/sys/process/ProcessBuilder 50 public,interface,abstract java/lang/Object scala/sys/process/ProcessBuilder$Source,scala/sys/process/ProcessBuilder$Sink -
 inner scala/sys/process/ProcessBuilder$Sink scala/sys/process/ProcessBuilder Sink public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Sink$class scala/sys/process/ProcessBuilder Sink$class public,static,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source$class scala/sys/process/ProcessBuilder Source$class public,static,abstract
 method public,abstract $bang$bang ()Ljava/lang/String; - -
 method public,abstract $bang$bang (Lscala/sys/process/ProcessLogger;)Ljava/lang/String; - -
 method public,abstract $bang$bang$less ()Ljava/lang/String; - -
 method public,abstract $bang$bang$less (Lscala/sys/process/ProcessLogger;)Ljava/lang/String; - -
 method public,abstract lineStream ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract,deprecated lines ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract lineStream (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract,deprecated lines (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract lineStream_$bang ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract,deprecated lines_$bang ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract lineStream_$bang (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract,deprecated lines_$bang (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,abstract $bang ()I - -
 method public,abstract $bang (Lscala/sys/process/ProcessLogger;)I - -
 method public,abstract $bang$less ()I - -
 method public,abstract $bang$less (Lscala/sys/process/ProcessLogger;)I - -
 method public,abstract run ()Lscala/sys/process/Process; - -
 method public,abstract run (Lscala/sys/process/ProcessLogger;)Lscala/sys/process/Process; - -
 method public,abstract run (Lscala/sys/process/ProcessIO;)Lscala/sys/process/Process; - -
 method public,abstract run (Z)Lscala/sys/process/Process; - -
 method public,abstract run (Lscala/sys/process/ProcessLogger;Z)Lscala/sys/process/Process; - -
 method public,abstract $hash$amp$amp (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$bar$bar (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$bar (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$hash$hash (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract canPipeTo ()Z - -
 method public,abstract hasExitValue ()Z - -
in 0
class scala/sys/process/ProcessBuilder$ 50 public,final,super java/lang/Object scala/sys/process/ProcessBuilderImpl -
 inner scala/sys/process/ProcessBuilder$Sink scala/sys/process/ProcessBuilder Sink public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Sink$class scala/sys/process/ProcessBuilder Sink$class public,static,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source$class scala/sys/process/ProcessBuilder Source$class public,static,abstract
 field public,static,final MODULE$ Lscala/sys/process/ProcessBuilder$; -
 method public,static <clinit> ()V - -
in 0
class scala/sys/process/ProcessBuilder$FileBuilder 50 public,interface,abstract java/lang/Object scala/sys/process/ProcessBuilder$Sink,scala/sys/process/ProcessBuilder$Source -
 inner scala/sys/process/ProcessBuilder$Sink scala/sys/process/ProcessBuilder Sink public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 method public,abstract $hash$less$less (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$less$less (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$less$less (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/InputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract $hash$less$less (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
in 0
class scala/sys/process/ProcessBuilder$Sink 50 public,interface,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$Sink scala/sys/process/ProcessBuilder Sink public,static,interface,abstract
 method public,abstract toSink ()Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$less (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$less (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$less (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/InputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract $hash$less (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
in 0
class scala/sys/process/ProcessBuilder$Sink$class 50 public,super,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$Sink scala/sys/process/ProcessBuilder Sink public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Sink$class scala/sys/process/ProcessBuilder Sink$class public,static,abstract
 inner scala/sys/process/ProcessBuilderImpl$URLInput scala/sys/process/ProcessBuilderImpl URLInput public
 inner scala/sys/process/ProcessBuilderImpl$FileInput scala/sys/process/ProcessBuilderImpl FileInput public
 inner scala/sys/process/ProcessBuilderImpl$PipedBuilder scala/sys/process/ProcessBuilderImpl PipedBuilder public
 inner scala/sys/process/ProcessBuilderImpl$IStreamBuilder scala/sys/process/ProcessBuilderImpl IStreamBuilder public
 method public,static $hash$less (Lscala/sys/process/ProcessBuilder$Sink;Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $hash$less (Lscala/sys/process/ProcessBuilder$Sink;Ljava/net/URL;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $hash$less (Lscala/sys/process/ProcessBuilder$Sink;Lscala/Function0;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $hash$less (Lscala/sys/process/ProcessBuilder$Sink;Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $init$ (Lscala/sys/process/ProcessBuilder$Sink;)V - -
in 0
class scala/sys/process/ProcessBuilder$Source 50 public,interface,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 method public,abstract toSource ()Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$greater$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract $hash$greater (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/OutputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract $hash$greater (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract cat ()Lscala/sys/process/ProcessBuilder; - -
in 0
class scala/sys/process/ProcessBuilder$Source$class 50 public,super,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source$class scala/sys/process/ProcessBuilder Source$class public,static,abstract
 inner scala/sys/process/ProcessBuilderImpl$FileOutput scala/sys/process/ProcessBuilderImpl FileOutput public
 inner scala/sys/process/ProcessBuilderImpl$PipedBuilder scala/sys/process/ProcessBuilderImpl PipedBuilder public
 inner scala/sys/process/ProcessBuilderImpl$OStreamBuilder scala/sys/process/ProcessBuilderImpl OStreamBuilder public
 method public,static $hash$greater (Lscala/sys/process/ProcessBuilder$Source;Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $hash$greater$greater (Lscala/sys/process/ProcessBuilder$Source;Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $hash$greater (Lscala/sys/process/ProcessBuilder$Source;Lscala/Function0;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $hash$greater (Lscala/sys/process/ProcessBuilder$Source;Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,static cat (Lscala/sys/process/ProcessBuilder$Source;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $init$ (Lscala/sys/process/ProcessBuilder$Source;)V - -
in 0
class scala/sys/process/ProcessBuilder$URLBuilder 50 public,interface,abstract java/lang/Object scala/sys/process/ProcessBuilder$Source -
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
in 0
class scala/sys/process/ProcessBuilder$class 50 public,super,abstract java/lang/Object - -
 method public,static,deprecated lines (Lscala/sys/process/ProcessBuilder;)Lscala/collection/immutable/Stream; - -
 method public,static,deprecated lines (Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; - -
 method public,static,deprecated lines_$bang (Lscala/sys/process/ProcessBuilder;)Lscala/collection/immutable/Stream; - -
 method public,static,deprecated lines_$bang (Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; - -
 method public,static $init$ (Lscala/sys/process/ProcessBuilder;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl 50 public,interface,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilderImpl$Dummy scala/sys/process/ProcessBuilderImpl Dummy public
 inner scala/sys/process/ProcessBuilderImpl$Simple scala/sys/process/ProcessBuilderImpl Simple public
 inner scala/sys/process/ProcessBuilderImpl$URLImpl scala/sys/process/ProcessBuilderImpl URLImpl public
 inner scala/sys/process/ProcessBuilderImpl$URLInput scala/sys/process/ProcessBuilderImpl URLInput public
 inner scala/sys/process/ProcessBuilderImpl$FileImpl scala/sys/process/ProcessBuilderImpl FileImpl public
 inner scala/sys/process/ProcessBuilderImpl$FileInput scala/sys/process/ProcessBuilderImpl FileInput public
 inner scala/sys/process/ProcessBuilderImpl$OrBuilder scala/sys/process/ProcessBuilderImpl OrBuilder public
 inner scala/sys/process/ProcessBuilderImpl$FileOutput scala/sys/process/ProcessBuilderImpl FileOutput public
 inner scala/sys/process/ProcessBuilderImpl$AndBuilder scala/sys/process/ProcessBuilderImpl AndBuilder public
 inner scala/sys/process/ProcessBuilderImpl$BasicBuilder scala/sys/process/ProcessBuilderImpl BasicBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$PipedBuilder scala/sys/process/ProcessBuilderImpl PipedBuilder public
 inner scala/sys/process/ProcessBuilderImpl$DaemonBuilder scala/sys/process/ProcessBuilderImpl DaemonBuilder public
 inner scala/sys/process/ProcessBuilderImpl$ThreadBuilder scala/sys/process/ProcessBuilderImpl ThreadBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$OStreamBuilder scala/sys/process/ProcessBuilderImpl OStreamBuilder public
 inner scala/sys/process/ProcessBuilderImpl$IStreamBuilder scala/sys/process/ProcessBuilderImpl IStreamBuilder public
 inner scala/sys/process/ProcessBuilderImpl$AbstractBuilder scala/sys/process/ProcessBuilderImpl AbstractBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$SequenceBuilder scala/sys/process/ProcessBuilderImpl SequenceBuilder public
 inner scala/sys/process/ProcessBuilderImpl$SequentialBuilder scala/sys/process/ProcessBuilderImpl SequentialBuilder public,abstract
in 0
class scala/sys/process/ProcessBuilderImpl$AbstractBuilder 50 public,super,abstract java/lang/Object scala/sys/process/ProcessBuilder -
 inner scala/sys/process/BasicIO$Streamed$ scala/sys/process/BasicIO Streamed$ public,static
 inner scala/sys/process/BasicIO$Streamed scala/sys/process/BasicIO Streamed public,static,final
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessBuilder$Sink scala/sys/process/ProcessBuilder Sink public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Sink$class scala/sys/process/ProcessBuilder Sink$class public,static,abstract
 inner scala/sys/process/ProcessBuilder$Source$class scala/sys/process/ProcessBuilder Source$class public,static,abstract
 inner scala/sys/process/ProcessBuilderImpl$OrBuilder scala/sys/process/ProcessBuilderImpl OrBuilder public
 inner scala/sys/process/ProcessBuilderImpl$AndBuilder scala/sys/process/ProcessBuilderImpl AndBuilder public
 inner scala/sys/process/ProcessBuilderImpl$PipedBuilder scala/sys/process/ProcessBuilderImpl PipedBuilder public
 inner scala/sys/process/ProcessBuilderImpl$DaemonBuilder scala/sys/process/ProcessBuilderImpl DaemonBuilder public
 inner scala/sys/process/ProcessBuilderImpl$AbstractBuilder scala/sys/process/ProcessBuilderImpl AbstractBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$SequenceBuilder scala/sys/process/ProcessBuilderImpl SequenceBuilder public
 method public,deprecated lines ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,deprecated lines (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,deprecated lines_$bang ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public,deprecated lines_$bang (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public $hash$less (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$less (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$less (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/InputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public $hash$less (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$greater$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$greater (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/OutputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public $hash$greater (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public cat ()Lscala/sys/process/ProcessBuilder; - -
 method public toSource ()Lscala/sys/process/ProcessBuilderImpl$AbstractBuilder; - -
 method public toSink ()Lscala/sys/process/ProcessBuilderImpl$AbstractBuilder; - -
 method public $hash$bar (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$bar$bar (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$amp$amp (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$hash$hash (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public run ()Lscala/sys/process/Process; - -
 method public run (Z)Lscala/sys/process/Process; - -
 method public run (Lscala/sys/process/ProcessLogger;)Lscala/sys/process/Process; - -
 method public run (Lscala/sys/process/ProcessLogger;Z)Lscala/sys/process/Process; - -
 method public $bang$bang ()Ljava/lang/String; - -
 method public $bang$bang (Lscala/sys/process/ProcessLogger;)Ljava/lang/String; - -
 method public $bang$bang$less ()Ljava/lang/String; - -
 method public $bang$bang$less (Lscala/sys/process/ProcessLogger;)Ljava/lang/String; - -
 method public lineStream ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public lineStream (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public lineStream_$bang ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public lineStream_$bang (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream; (Lscala/sys/process/ProcessLogger;)Lscala/collection/immutable/Stream<Ljava/lang/String;>; -
 method public $bang ()I - -
 method public $bang (Lscala/sys/process/ProcessIO;)I - -
 method public $bang (Lscala/sys/process/ProcessLogger;)I - -
 method public $bang$less ()I - -
 method public $bang$less (Lscala/sys/process/ProcessLogger;)I - -
 method public daemonized ()Lscala/sys/process/ProcessBuilder; - -
 method public canPipeTo ()Z - -
 method public hasExitValue ()Z - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$AndBuilder 50 public,super scala/sys/process/ProcessBuilderImpl$SequentialBuilder - -
 inner scala/sys/process/ProcessImpl$AndProcess scala/sys/process/ProcessImpl AndProcess public
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 inner scala/sys/process/ProcessBuilderImpl$AndBuilder scala/sys/process/ProcessBuilderImpl AndBuilder public
 inner scala/sys/process/ProcessBuilderImpl$SequentialBuilder scala/sys/process/ProcessBuilderImpl SequentialBuilder public,abstract
 method public createProcess (Lscala/sys/process/ProcessIO;)Lscala/sys/process/ProcessImpl$AndProcess; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$BasicBuilder 50 public,super,abstract scala/sys/process/ProcessBuilderImpl$AbstractBuilder - -
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 inner scala/sys/process/ProcessBuilderImpl$BasicBuilder scala/sys/process/ProcessBuilderImpl BasicBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$AbstractBuilder scala/sys/process/ProcessBuilderImpl AbstractBuilder public,abstract
 method public checkNotThis (Lscala/sys/process/ProcessBuilder;)V - -
 method public,final run (Lscala/sys/process/ProcessIO;)Lscala/sys/process/Process; - -
 method public,abstract createProcess (Lscala/sys/process/ProcessIO;)Lscala/sys/process/ProcessImpl$BasicProcess; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$DaemonBuilder 50 public,super scala/sys/process/ProcessBuilderImpl$AbstractBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$DaemonBuilder scala/sys/process/ProcessBuilderImpl DaemonBuilder public
 inner scala/sys/process/ProcessBuilderImpl$AbstractBuilder scala/sys/process/ProcessBuilderImpl AbstractBuilder public,abstract
 method public,final run (Lscala/sys/process/ProcessIO;)Lscala/sys/process/Process; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/sys/process/ProcessBuilder;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$Dummy 50 public,super scala/sys/process/ProcessBuilderImpl$AbstractBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$Dummy scala/sys/process/ProcessBuilderImpl Dummy public
 inner scala/sys/process/ProcessImpl$DummyProcess scala/sys/process/ProcessImpl DummyProcess public
 inner scala/sys/process/ProcessBuilderImpl$AbstractBuilder scala/sys/process/ProcessBuilderImpl AbstractBuilder public,abstract
 method public toString ()Ljava/lang/String; - -
 method public run (Lscala/sys/process/ProcessIO;)Lscala/sys/process/Process; - -
 method public canPipeTo ()Z - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/lang/String;Lscala/Function0;)V (Lscala/sys/process/ProcessBuilder$;Ljava/lang/String;Lscala/Function0<Ljava/lang/Object;>;)V -
in 0
class scala/sys/process/ProcessBuilderImpl$FileImpl 50 public,super java/lang/Object scala/sys/process/ProcessBuilder$FileBuilder -
 inner scala/sys/process/ProcessBuilder$Sink scala/sys/process/ProcessBuilder Sink public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$Sink$class scala/sys/process/ProcessBuilder Sink$class public,static,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilderImpl$FileImpl scala/sys/process/ProcessBuilderImpl FileImpl public
 inner scala/sys/process/ProcessBuilder$Source$class scala/sys/process/ProcessBuilder Source$class public,static,abstract
 inner scala/sys/process/ProcessBuilderImpl$URLInput scala/sys/process/ProcessBuilderImpl URLInput public
 inner scala/sys/process/ProcessBuilderImpl$FileInput scala/sys/process/ProcessBuilderImpl FileInput public
 inner scala/sys/process/ProcessBuilderImpl$FileOutput scala/sys/process/ProcessBuilderImpl FileOutput public
 inner scala/sys/process/ProcessBuilderImpl$PipedBuilder scala/sys/process/ProcessBuilderImpl PipedBuilder public
 inner scala/sys/process/ProcessBuilderImpl$IStreamBuilder scala/sys/process/ProcessBuilderImpl IStreamBuilder public
 method public $hash$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$greater$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$greater (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/OutputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public $hash$greater (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public cat ()Lscala/sys/process/ProcessBuilder; - -
 method public $hash$less (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$less (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$less (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/InputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public $hash$less (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public toSource ()Lscala/sys/process/ProcessBuilderImpl$FileInput; - -
 method public toSink ()Lscala/sys/process/ProcessBuilderImpl$FileOutput; - -
 method public $hash$less$less (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$less$less (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$less$less (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/InputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public $hash$less$less (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/io/File;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$FileInput 50 public,super scala/sys/process/ProcessBuilderImpl$IStreamBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$FileInput scala/sys/process/ProcessBuilderImpl FileInput public
 inner scala/sys/process/ProcessBuilderImpl$IStreamBuilder scala/sys/process/ProcessBuilderImpl IStreamBuilder public
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/io/File;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$FileOutput 50 public,super scala/sys/process/ProcessBuilderImpl$OStreamBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$FileOutput scala/sys/process/ProcessBuilderImpl FileOutput public
 inner scala/sys/process/ProcessBuilderImpl$OStreamBuilder scala/sys/process/ProcessBuilderImpl OStreamBuilder public
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/io/File;Z)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$IStreamBuilder 50 public,super scala/sys/process/ProcessBuilderImpl$ThreadBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$ThreadBuilder scala/sys/process/ProcessBuilderImpl ThreadBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$IStreamBuilder scala/sys/process/ProcessBuilderImpl IStreamBuilder public
 method public hasExitValue ()Z - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/Function0;Ljava/lang/String;)V (Lscala/sys/process/ProcessBuilder$;Lscala/Function0<Ljava/io/InputStream;>;Ljava/lang/String;)V -
in 0
class scala/sys/process/ProcessBuilderImpl$OStreamBuilder 50 public,super scala/sys/process/ProcessBuilderImpl$ThreadBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$ThreadBuilder scala/sys/process/ProcessBuilderImpl ThreadBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$OStreamBuilder scala/sys/process/ProcessBuilderImpl OStreamBuilder public
 method public hasExitValue ()Z - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/Function0;Ljava/lang/String;)V (Lscala/sys/process/ProcessBuilder$;Lscala/Function0<Ljava/io/OutputStream;>;Ljava/lang/String;)V -
in 0
class scala/sys/process/ProcessBuilderImpl$OrBuilder 50 public,super scala/sys/process/ProcessBuilderImpl$SequentialBuilder - -
 inner scala/sys/process/ProcessImpl$OrProcess scala/sys/process/ProcessImpl OrProcess public
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 inner scala/sys/process/ProcessBuilderImpl$OrBuilder scala/sys/process/ProcessBuilderImpl OrBuilder public
 inner scala/sys/process/ProcessBuilderImpl$SequentialBuilder scala/sys/process/ProcessBuilderImpl SequentialBuilder public,abstract
 method public createProcess (Lscala/sys/process/ProcessIO;)Lscala/sys/process/ProcessImpl$OrProcess; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$PipedBuilder 50 public,super scala/sys/process/ProcessBuilderImpl$SequentialBuilder - -
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 inner scala/sys/process/ProcessImpl$PipedProcesses scala/sys/process/ProcessImpl PipedProcesses public
 inner scala/sys/process/ProcessBuilderImpl$PipedBuilder scala/sys/process/ProcessBuilderImpl PipedBuilder public
 inner scala/sys/process/ProcessBuilderImpl$SequentialBuilder scala/sys/process/ProcessBuilderImpl SequentialBuilder public,abstract
 method public createProcess (Lscala/sys/process/ProcessIO;)Lscala/sys/process/ProcessImpl$PipedProcesses; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Z)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$SequenceBuilder 50 public,super scala/sys/process/ProcessBuilderImpl$SequentialBuilder - -
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 inner scala/sys/process/ProcessImpl$ProcessSequence scala/sys/process/ProcessImpl ProcessSequence public
 inner scala/sys/process/ProcessBuilderImpl$SequenceBuilder scala/sys/process/ProcessBuilderImpl SequenceBuilder public
 inner scala/sys/process/ProcessBuilderImpl$SequentialBuilder scala/sys/process/ProcessBuilderImpl SequentialBuilder public,abstract
 method public createProcess (Lscala/sys/process/ProcessIO;)Lscala/sys/process/ProcessImpl$ProcessSequence; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$SequentialBuilder 50 public,super,abstract scala/sys/process/ProcessBuilderImpl$BasicBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$BasicBuilder scala/sys/process/ProcessBuilderImpl BasicBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$SequentialBuilder scala/sys/process/ProcessBuilderImpl SequentialBuilder public,abstract
 method public toString ()Ljava/lang/String; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Ljava/lang/String;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$Simple 50 public,super scala/sys/process/ProcessBuilderImpl$AbstractBuilder - -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessBuilderImpl$Simple scala/sys/process/ProcessBuilderImpl Simple public
 inner scala/sys/process/ProcessImpl$SimpleProcess scala/sys/process/ProcessImpl SimpleProcess public
 inner scala/sys/process/ProcessBuilderImpl$AbstractBuilder scala/sys/process/ProcessBuilderImpl AbstractBuilder public,abstract
 method public run (Lscala/sys/process/ProcessIO;)Lscala/sys/process/Process; - -
 method public toString ()Ljava/lang/String; - -
 method public canPipeTo ()Z - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/lang/ProcessBuilder;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$ThreadBuilder 50 public,super,abstract scala/sys/process/ProcessBuilderImpl$AbstractBuilder - -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessImpl$ThreadProcess scala/sys/process/ProcessImpl ThreadProcess public,final
 inner scala/sys/process/ProcessBuilderImpl$ThreadBuilder scala/sys/process/ProcessBuilderImpl ThreadBuilder public,abstract
 inner scala/sys/process/ProcessBuilderImpl$AbstractBuilder scala/sys/process/ProcessBuilderImpl AbstractBuilder public,abstract
 field public,final scala$sys$process$ProcessBuilderImpl$ThreadBuilder$$runImpl Lscala/Function1; Lscala/Function1<Lscala/sys/process/ProcessIO;Lscala/runtime/BoxedUnit;>;
 method public toString ()Ljava/lang/String; - -
 method public run (Lscala/sys/process/ProcessIO;)Lscala/sys/process/Process; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/lang/String;Lscala/Function1;)V (Lscala/sys/process/ProcessBuilder$;Ljava/lang/String;Lscala/Function1<Lscala/sys/process/ProcessIO;Lscala/runtime/BoxedUnit;>;)V -
in 0
class scala/sys/process/ProcessBuilderImpl$URLImpl 50 public,super java/lang/Object scala/sys/process/ProcessBuilder$URLBuilder -
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilderImpl$URLImpl scala/sys/process/ProcessBuilderImpl URLImpl public
 inner scala/sys/process/ProcessBuilder$Source$class scala/sys/process/ProcessBuilder Source$class public,static,abstract
 inner scala/sys/process/ProcessBuilderImpl$URLInput scala/sys/process/ProcessBuilderImpl URLInput public
 method public $hash$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$greater$greater (Ljava/io/File;)Lscala/sys/process/ProcessBuilder; - -
 method public $hash$greater (Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Lscala/Function0<Ljava/io/OutputStream;>;)Lscala/sys/process/ProcessBuilder; -
 method public $hash$greater (Lscala/sys/process/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public cat ()Lscala/sys/process/ProcessBuilder; - -
 method public toSource ()Lscala/sys/process/ProcessBuilderImpl$URLInput; - -
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/net/URL;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$URLInput 50 public,super scala/sys/process/ProcessBuilderImpl$IStreamBuilder - -
 inner scala/sys/process/ProcessBuilderImpl$URLInput scala/sys/process/ProcessBuilderImpl URLInput public
 inner scala/sys/process/ProcessBuilderImpl$IStreamBuilder scala/sys/process/ProcessBuilderImpl IStreamBuilder public
 method public <init> (Lscala/sys/process/ProcessBuilder$;Ljava/net/URL;)V - -
in 0
class scala/sys/process/ProcessBuilderImpl$class 50 public,super,abstract java/lang/Object - -
 method public,static $init$ (Lscala/sys/process/ProcessBuilder$;)V - -
in 0
class scala/sys/process/ProcessCreation 50 public,interface,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 method public,abstract apply (Ljava/lang/String;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract apply (Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract apply (Ljava/lang/String;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Lscala/collection/Seq<Ljava/lang/String;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract apply (Ljava/lang/String;Ljava/io/File;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Ljava/io/File;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract apply (Lscala/collection/Seq;Ljava/io/File;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;Ljava/io/File;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract apply (Ljava/lang/String;Lscala/Option;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Lscala/Option<Ljava/io/File;>;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract apply (Lscala/collection/Seq;Lscala/Option;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;Lscala/Option<Ljava/io/File;>;Lscala/collection/Seq<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract apply (Ljava/lang/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract apply (Ljava/io/File;)Lscala/sys/process/ProcessBuilder$FileBuilder; - -
 method public,abstract apply (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder$URLBuilder; - -
 method public,abstract apply (Z)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract apply (Ljava/lang/String;Lscala/Function0;)Lscala/sys/process/ProcessBuilder; (Ljava/lang/String;Lscala/Function0<Ljava/lang/Object;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract applySeq (Lscala/collection/Seq;Lscala/Function1;)Lscala/collection/Seq; <T:Ljava/lang/Object;>(Lscala/collection/Seq<TT;>;Lscala/Function1<TT;Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>; -
 method public,abstract cat (Lscala/sys/process/ProcessBuilder$Source;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/sys/process/ProcessBuilder$Source;Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/sys/process/ProcessBuilder; -
 method public,abstract cat (Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/sys/process/ProcessBuilder; -
in 0
class scala/sys/process/ProcessCreation$class 50 public,super,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$Source scala/sys/process/ProcessBuilder Source public,static,interface,abstract
 inner scala/sys/process/ProcessBuilderImpl$Dummy scala/sys/process/ProcessBuilderImpl Dummy public
 inner scala/sys/process/ProcessBuilderImpl$Simple scala/sys/process/ProcessBuilderImpl Simple public
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilderImpl$URLImpl scala/sys/process/ProcessBuilderImpl URLImpl public
 inner scala/sys/process/ProcessBuilderImpl$FileImpl scala/sys/process/ProcessBuilderImpl FileImpl public
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/lang/String;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/lang/String;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/lang/String;Ljava/io/File;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Lscala/collection/Seq;Ljava/io/File;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/lang/String;Lscala/Option;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Lscala/collection/Seq;Lscala/Option;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/lang/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/io/File;)Lscala/sys/process/ProcessBuilder$FileBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/net/URL;)Lscala/sys/process/ProcessBuilder$URLBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Z)Lscala/sys/process/ProcessBuilder; - -
 method public,static apply (Lscala/sys/process/ProcessCreation;Ljava/lang/String;Lscala/Function0;)Lscala/sys/process/ProcessBuilder; - -
 method public,static applySeq (Lscala/sys/process/ProcessCreation;Lscala/collection/Seq;Lscala/Function1;)Lscala/collection/Seq; - -
 method public,static cat (Lscala/sys/process/ProcessCreation;Lscala/sys/process/ProcessBuilder$Source;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static cat (Lscala/sys/process/ProcessCreation;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $init$ (Lscala/sys/process/ProcessCreation;)V - -
in 0
class scala/sys/process/ProcessIO 50 public,final,super java/lang/Object - -
 method public writeInput ()Lscala/Function1; ()Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>; -
 method public processOutput ()Lscala/Function1; ()Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public processError ()Lscala/Function1; ()Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>; -
 method public daemonizeThreads ()Z - -
 method public withInput (Lscala/Function1;)Lscala/sys/process/ProcessIO; (Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>;)Lscala/sys/process/ProcessIO; -
 method public withOutput (Lscala/Function1;)Lscala/sys/process/ProcessIO; (Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>;)Lscala/sys/process/ProcessIO; -
 method public withError (Lscala/Function1;)Lscala/sys/process/ProcessIO; (Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>;)Lscala/sys/process/ProcessIO; -
 method public daemonized ()Lscala/sys/process/ProcessIO; - -
 method public <init> (Lscala/Function1;Lscala/Function1;Lscala/Function1;Z)V (Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>;Z)V -
 method public <init> (Lscala/Function1;Lscala/Function1;Lscala/Function1;)V (Lscala/Function1<Ljava/io/OutputStream;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/io/InputStream;Lscala/runtime/BoxedUnit;>;)V -
in 0
class scala/sys/process/ProcessImpl 50 public,interface,abstract java/lang/Object - -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessImpl$Future$ scala/sys/process/ProcessImpl Future$ public
 inner scala/sys/process/ProcessImpl$PipeSink scala/sys/process/ProcessImpl PipeSink public
 inner scala/sys/process/ProcessImpl$OrProcess scala/sys/process/ProcessImpl OrProcess public
 inner scala/sys/process/ProcessImpl$AndProcess scala/sys/process/ProcessImpl AndProcess public
 inner scala/sys/process/ProcessImpl$PipeThread scala/sys/process/ProcessImpl PipeThread public,abstract
 inner scala/sys/process/ProcessImpl$PipeSource scala/sys/process/ProcessImpl PipeSource public
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 inner scala/sys/process/ProcessImpl$DummyProcess scala/sys/process/ProcessImpl DummyProcess public
 inner scala/sys/process/ProcessImpl$SimpleProcess scala/sys/process/ProcessImpl SimpleProcess public
 inner scala/sys/process/ProcessImpl$ThreadProcess scala/sys/process/ProcessImpl ThreadProcess public,final
 inner scala/sys/process/ProcessImpl$PipedProcesses scala/sys/process/ProcessImpl PipedProcesses public
 inner scala/sys/process/ProcessImpl$ProcessSequence scala/sys/process/ProcessImpl ProcessSequence public
 inner scala/sys/process/ProcessImpl$CompoundProcess scala/sys/process/ProcessImpl CompoundProcess public,abstract
 inner scala/sys/process/ProcessImpl$SequentialProcess scala/sys/process/ProcessImpl SequentialProcess public
 method public,abstract Spawn ()Lscala/sys/process/ProcessImpl$Spawn$; - -
 method public,abstract Future ()Lscala/sys/process/ProcessImpl$Future$; - -
in 0
class scala/sys/process/ProcessImpl$AndProcess 50 public,super scala/sys/process/ProcessImpl$SequentialProcess - -
 inner scala/sys/process/ProcessImpl$AndProcess scala/sys/process/ProcessImpl AndProcess public
 inner scala/sys/process/ProcessImpl$SequentialProcess scala/sys/process/ProcessImpl SequentialProcess public
 method public <init> (Lscala/sys/process/Process$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessIO;)V - -
in 0
class scala/sys/process/ProcessImpl$BasicProcess 50 public,super,abstract java/lang/Object scala/sys/process/Process -
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 method public,abstract start ()V - -
 method public <init> (Lscala/sys/process/Process$;)V - -
in 0
class scala/sys/process/ProcessImpl$CompoundProcess 50 public,super,abstract scala/sys/process/ProcessImpl$BasicProcess - -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessImpl$Future$ scala/sys/process/ProcessImpl Future$ public
 inner scala/sys/process/ProcessImpl$BasicProcess scala/sys/process/ProcessImpl BasicProcess public,abstract
 inner scala/sys/process/ProcessImpl$CompoundProcess scala/sys/process/ProcessImpl CompoundProcess public,abstract
 method public destroy ()V - -
 method public exitValue ()I - -
 method public start ()V - -
 method public getExitValue ()Lscala/Function0; ()Lscala/Function0<Lscala/Option<Ljava/lang/Object;>;>; -
 method public destroyer ()Lscala/Function0; ()Lscala/Function0<Lscala/runtime/BoxedUnit;>; -
 method public,abstract runAndExitValue ()Lscala/Option; ()Lscala/Option<Ljava/lang/Object;>; -
 method public runInterruptible (Lscala/Function0;Lscala/Function0;)Lscala/Option; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Lscala/Option<TT;>; -
 method public <init> (Lscala/sys/process/Process$;)V - -
in 0
class scala/sys/process/ProcessImpl$DummyProcess 50 public,super java/lang/Object scala/sys/process/Process -
 inner scala/sys/process/ProcessImpl$Future$ scala/sys/process/ProcessImpl Future$ public
 inner scala/sys/process/ProcessImpl$DummyProcess scala/sys/process/ProcessImpl DummyProcess public
 method public exitValue ()I - -
 method public destroy ()V - -
 method public <init> (Lscala/sys/process/Process$;Lscala/Function0;)V (Lscala/sys/process/Process$;Lscala/Function0<Ljava/lang/Object;>;)V -
in 0
class scala/sys/process/ProcessImpl$Future$ 50 public,super java/lang/Object - -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessImpl$Future$ scala/sys/process/ProcessImpl Future$ public
 method public apply (Lscala/Function0;)Lscala/Function0; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)Lscala/Function0<TT;>; -
 method public,final scala$sys$process$ProcessImpl$Future$$run$1 (Lscala/Function0;Lscala/concurrent/SyncVar;)V - -
 method public <init> (Lscala/sys/process/Process$;)V - -
in 0
class scala/sys/process/ProcessImpl$OrProcess 50 public,super scala/sys/process/ProcessImpl$SequentialProcess - -
 inner scala/sys/process/ProcessImpl$OrProcess scala/sys/process/ProcessImpl OrProcess public
 inner scala/sys/process/ProcessImpl$SequentialProcess scala/sys/process/ProcessImpl SequentialProcess public
 method public <init> (Lscala/sys/process/Process$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessIO;)V - -
in 0
class scala/sys/process/ProcessImpl$PipeSink 50 public,super scala/sys/process/ProcessImpl$PipeThread - -
 inner scala/sys/process/ProcessImpl$PipeSink scala/sys/process/ProcessImpl PipeSink public
 inner scala/sys/process/ProcessImpl$PipeThread scala/sys/process/ProcessImpl PipeThread public,abstract
 method public,final run ()V - -
 method public <init> (Lscala/sys/process/Process$;Ljava/io/PipedInputStream;Lscala/concurrent/SyncVar;Lscala/Function0;)V (Lscala/sys/process/Process$;Ljava/io/PipedInputStream;Lscala/concurrent/SyncVar<Lscala/Option<Ljava/io/OutputStream;>;>;Lscala/Function0<Ljava/lang/String;>;)V -
in 0
class scala/sys/process/ProcessImpl$PipeSource 50 public,super scala/sys/process/ProcessImpl$PipeThread - -
 inner scala/sys/process/ProcessImpl$PipeSource scala/sys/process/ProcessImpl PipeSource public
 inner scala/sys/process/ProcessImpl$PipeThread scala/sys/process/ProcessImpl PipeThread public,abstract
 method public,final run ()V - -
 method public <init> (Lscala/sys/process/Process$;Lscala/concurrent/SyncVar;Ljava/io/PipedOutputStream;Lscala/Function0;)V (Lscala/sys/process/Process$;Lscala/concurrent/SyncVar<Lscala/Option<Ljava/io/InputStream;>;>;Ljava/io/PipedOutputStream;Lscala/Function0<Ljava/lang/String;>;)V -
in 0
class scala/sys/process/ProcessImpl$PipeThread 50 public,super,abstract java/lang/Thread - -
 inner scala/sys/process/ProcessImpl$PipeThread scala/sys/process/ProcessImpl PipeThread public,abstract
 method public,abstract run ()V - -
 method public runloop (Ljava/io/InputStream;Ljava/io/OutputStream;)V - -
 method public scala$sys$process$ProcessImpl$PipeThread$$ioHandler (Ljava/io/IOException;)V - -
 method public <init> (Lscala/sys/process/Process$;ZLscala/Function0;)V (Lscala/sys/process/Process$;ZLscala/Function0<Ljava/lang/String;>;)V -
in 0
class scala/sys/process/ProcessImpl$PipedProcesses 50 public,super scala/sys/process/ProcessImpl$CompoundProcess - -
 inner scala/sys/process/ProcessImpl$PipeSink scala/sys/process/ProcessImpl PipeSink public
 inner scala/sys/process/ProcessImpl$PipeSource scala/sys/process/ProcessImpl PipeSource public
 inner scala/sys/process/ProcessImpl$PipedProcesses scala/sys/process/ProcessImpl PipedProcesses public
 inner scala/sys/process/ProcessImpl$CompoundProcess scala/sys/process/ProcessImpl CompoundProcess public,abstract
 field public,final scala$sys$process$ProcessImpl$PipedProcesses$$a Lscala/sys/process/ProcessBuilder; -
 field public,final scala$sys$process$ProcessImpl$PipedProcesses$$b Lscala/sys/process/ProcessBuilder; -
 method public runAndExitValue ()Lscala/Option; ()Lscala/Option<Ljava/lang/Object;>; -
 method public,final scala$sys$process$ProcessImpl$PipedProcesses$$handleOutOrError$1 (Ljava/io/InputStream;Lscala/concurrent/SyncVar;)V - -
 method public <init> (Lscala/sys/process/Process$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessIO;Z)V - -
in 0
class scala/sys/process/ProcessImpl$ProcessSequence 50 public,super scala/sys/process/ProcessImpl$SequentialProcess - -
 inner scala/sys/process/ProcessImpl$ProcessSequence scala/sys/process/ProcessImpl ProcessSequence public
 inner scala/sys/process/ProcessImpl$SequentialProcess scala/sys/process/ProcessImpl SequentialProcess public
 method public <init> (Lscala/sys/process/Process$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessIO;)V - -
in 0
class scala/sys/process/ProcessImpl$SequentialProcess 50 public,super scala/sys/process/ProcessImpl$CompoundProcess - -
 inner scala/sys/process/ProcessImpl$CompoundProcess scala/sys/process/ProcessImpl CompoundProcess public,abstract
 inner scala/sys/process/ProcessImpl$SequentialProcess scala/sys/process/ProcessImpl SequentialProcess public
 field public,final scala$sys$process$ProcessImpl$SequentialProcess$$b Lscala/sys/process/ProcessBuilder; -
 field public,final scala$sys$process$ProcessImpl$SequentialProcess$$io Lscala/sys/process/ProcessIO; -
 field public,final scala$sys$process$ProcessImpl$SequentialProcess$$evaluateSecondProcess Lscala/Function1; Lscala/Function1<Ljava/lang/Object;Ljava/lang/Object;>;
 method public runAndExitValue ()Lscala/Option; ()Lscala/Option<Ljava/lang/Object;>; -
 method public <init> (Lscala/sys/process/Process$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessIO;Lscala/Function1;)V (Lscala/sys/process/Process$;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessBuilder;Lscala/sys/process/ProcessIO;Lscala/Function1<Ljava/lang/Object;Ljava/lang/Object;>;)V -
in 0
class scala/sys/process/ProcessImpl$SimpleProcess 50 public,super java/lang/Object scala/sys/process/Process -
 inner scala/sys/process/ProcessImpl$SimpleProcess scala/sys/process/ProcessImpl SimpleProcess public
 method public exitValue ()I - -
 method public destroy ()V - -
 method public <init> (Lscala/sys/process/Process$;Ljava/lang/Process;Ljava/lang/Thread;Lscala/collection/immutable/List;)V (Lscala/sys/process/Process$;Ljava/lang/Process;Ljava/lang/Thread;Lscala/collection/immutable/List<Ljava/lang/Thread;>;)V -
in 0
class scala/sys/process/ProcessImpl$Spawn$ 50 public,super java/lang/Object - -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 method public apply (Lscala/Function0;)Ljava/lang/Thread; (Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Ljava/lang/Thread; -
 method public apply (Lscala/Function0;Z)Ljava/lang/Thread; (Lscala/Function0<Lscala/runtime/BoxedUnit;>;Z)Ljava/lang/Thread; -
 method public <init> (Lscala/sys/process/Process$;)V - -
in 0
class scala/sys/process/ProcessImpl$ThreadProcess 50 public,final,super java/lang/Object scala/sys/process/Process -
 inner scala/sys/process/ProcessImpl$ThreadProcess scala/sys/process/ProcessImpl ThreadProcess public,final
 method public exitValue ()I - -
 method public destroy ()V - -
 method public <init> (Lscala/sys/process/Process$;Ljava/lang/Thread;Lscala/concurrent/SyncVar;)V (Lscala/sys/process/Process$;Ljava/lang/Thread;Lscala/concurrent/SyncVar<Ljava/lang/Object;>;)V -
in 0
class scala/sys/process/ProcessImpl$class 50 public,super,abstract java/lang/Object - -
 inner scala/sys/process/ProcessImpl$Spawn$ scala/sys/process/ProcessImpl Spawn$ public
 inner scala/sys/process/ProcessImpl$Future$ scala/sys/process/ProcessImpl Future$ public
 method public,static $init$ (Lscala/sys/process/Process$;)V - -
in 0
class scala/sys/process/ProcessImplicits 50 public,interface,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 method public,abstract buildersToProcess (Lscala/collection/Seq;Lscala/Function1;)Lscala/collection/Seq; <T:Ljava/lang/Object;>(Lscala/collection/Seq<TT;>;Lscala/Function1<TT;Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>; -
 method public,abstract builderToProcess (Ljava/lang/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract fileToProcess (Ljava/io/File;)Lscala/sys/process/ProcessBuilder$FileBuilder; - -
 method public,abstract urlToProcess (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder$URLBuilder; - -
 method public,abstract stringToProcess (Ljava/lang/String;)Lscala/sys/process/ProcessBuilder; - -
 method public,abstract stringSeqToProcess (Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;)Lscala/sys/process/ProcessBuilder; -
in 0
class scala/sys/process/ProcessImplicits$class 50 public,super,abstract java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 method public,static buildersToProcess (Lscala/sys/process/ProcessImplicits;Lscala/collection/Seq;Lscala/Function1;)Lscala/collection/Seq; - -
 method public,static builderToProcess (Lscala/sys/process/ProcessImplicits;Ljava/lang/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,static fileToProcess (Lscala/sys/process/ProcessImplicits;Ljava/io/File;)Lscala/sys/process/ProcessBuilder$FileBuilder; - -
 method public,static urlToProcess (Lscala/sys/process/ProcessImplicits;Ljava/net/URL;)Lscala/sys/process/ProcessBuilder$URLBuilder; - -
 method public,static stringToProcess (Lscala/sys/process/ProcessImplicits;Ljava/lang/String;)Lscala/sys/process/ProcessBuilder; - -
 method public,static stringSeqToProcess (Lscala/sys/process/ProcessImplicits;Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; - -
 method public,static $init$ (Lscala/sys/process/ProcessImplicits;)V - -
in 0
class scala/sys/process/ProcessLogger 50 public,interface,abstract java/lang/Object - -
 method public,abstract out (Lscala/Function0;)V (Lscala/Function0<Ljava/lang/String;>;)V -
 method public,abstract err (Lscala/Function0;)V (Lscala/Function0<Ljava/lang/String;>;)V -
 method public,abstract buffer (Lscala/Function0;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)TT; -
in 0
class scala/sys/process/ProcessLogger$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/sys/process/ProcessLogger$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/io/File;)Lscala/sys/process/FileProcessLogger; - -
 method public apply (Lscala/Function1;)Lscala/sys/process/ProcessLogger; (Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;)Lscala/sys/process/ProcessLogger; -
 method public apply (Lscala/Function1;Lscala/Function1;)Lscala/sys/process/ProcessLogger; (Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;)Lscala/sys/process/ProcessLogger; -
in 0
class scala/sys/process/package 50 public,final,super java/lang/Object - -
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 method public,static stringSeqToProcess (Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;)Lscala/sys/process/ProcessBuilder; -
 method public,static stringToProcess (Ljava/lang/String;)Lscala/sys/process/ProcessBuilder; - -
 method public,static urlToProcess (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder$URLBuilder; - -
 method public,static fileToProcess (Ljava/io/File;)Lscala/sys/process/ProcessBuilder$FileBuilder; - -
 method public,static builderToProcess (Ljava/lang/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public,static buildersToProcess (Lscala/collection/Seq;Lscala/Function1;)Lscala/collection/Seq; <T:Ljava/lang/Object;>(Lscala/collection/Seq<TT;>;Lscala/Function1<TT;Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>; -
 method public,static stderr ()Ljava/io/PrintStream; - -
 method public,static stdout ()Ljava/io/PrintStream; - -
 method public,static stdin ()Ljava/io/InputStream; - -
 method public,static javaVmArguments ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Ljava/lang/String;>; -
in 0
class scala/sys/process/package$ 50 public,final,super java/lang/Object scala/sys/process/ProcessImplicits -
 inner scala/sys/process/ProcessBuilder$URLBuilder scala/sys/process/ProcessBuilder URLBuilder public,static,interface,abstract
 inner scala/sys/process/ProcessBuilder$FileBuilder scala/sys/process/ProcessBuilder FileBuilder public,static,interface,abstract
 field public,static,final MODULE$ Lscala/sys/process/package$; -
 method public,static <clinit> ()V - -
 method public buildersToProcess (Lscala/collection/Seq;Lscala/Function1;)Lscala/collection/Seq; <T:Ljava/lang/Object;>(Lscala/collection/Seq<TT;>;Lscala/Function1<TT;Lscala/sys/process/ProcessBuilder$Source;>;)Lscala/collection/Seq<Lscala/sys/process/ProcessBuilder$Source;>; -
 method public builderToProcess (Ljava/lang/ProcessBuilder;)Lscala/sys/process/ProcessBuilder; - -
 method public fileToProcess (Ljava/io/File;)Lscala/sys/process/ProcessBuilder$FileBuilder; - -
 method public urlToProcess (Ljava/net/URL;)Lscala/sys/process/ProcessBuilder$URLBuilder; - -
 method public stringToProcess (Ljava/lang/String;)Lscala/sys/process/ProcessBuilder; - -
 method public stringSeqToProcess (Lscala/collection/Seq;)Lscala/sys/process/ProcessBuilder; (Lscala/collection/Seq<Ljava/lang/String;>;)Lscala/sys/process/ProcessBuilder; -
 method public javaVmArguments ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Ljava/lang/String;>; -
 method public stdin ()Ljava/io/InputStream; - -
 method public stdout ()Ljava/io/PrintStream; - -
 method public stderr ()Ljava/io/PrintStream; - -
in 0
class scala/sys/process/processInternal 50 public,final,super java/lang/Object - -
 method public,static dbg (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
 method public,static ioFailure (Lscala/Function1;)Lscala/PartialFunction; <T:Ljava/lang/Object;>(Lscala/Function1<Ljava/io/IOException;TT;>;)Lscala/PartialFunction<Ljava/lang/Throwable;TT;>; -
 method public,static onInterrupt (Lscala/Function0;)Lscala/PartialFunction; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)Lscala/PartialFunction<Ljava/lang/Throwable;TT;>; -
 method public,static processDebug ()Z - -
in 0
class scala/sys/process/processInternal$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/sys/process/processInternal$; -
 method public,static <clinit> ()V - -
 method public,final processDebug ()Z - -
 method public onInterrupt (Lscala/Function0;)Lscala/PartialFunction; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)Lscala/PartialFunction<Ljava/lang/Throwable;TT;>; -
 method public ioFailure (Lscala/Function1;)Lscala/PartialFunction; <T:Ljava/lang/Object;>(Lscala/Function1<Ljava/io/IOException;TT;>;)Lscala/PartialFunction<Ljava/lang/Throwable;TT;>; -
 method public dbg (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
