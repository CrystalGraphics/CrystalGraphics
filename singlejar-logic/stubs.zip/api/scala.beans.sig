cg-stub-db 1
in 0
class scala/beans/BeanDescription 50 public,super scala/annotation/Annotation - -
 method public description ()Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/beans/BeanDisplayName 50 public,super scala/annotation/Annotation - -
 method public name ()Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/beans/BeanInfo 50 public,super scala/annotation/Annotation - -
 method public <init> ()V - -
in 0
class scala/beans/BeanInfoSkip 50 public,super scala/annotation/Annotation - -
 method public <init> ()V - -
in 0
class scala/beans/BeanProperty 50 public,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/beans/BooleanBeanProperty 50 public,super scala/annotation/Annotation scala/annotation/StaticAnnotation -
 method public <init> ()V - -
in 0
class scala/beans/ScalaBeanInfo 50 public,super,abstract java/beans/SimpleBeanInfo - -
 field public,final scala$beans$ScalaBeanInfo$$methods [Ljava/lang/String; -
 method public getPropertyDescriptors ()[Ljava/beans/PropertyDescriptor; - -
 method public getMethodDescriptors ()[Ljava/beans/MethodDescriptor; - -
 method public <init> (Ljava/lang/Class;[Ljava/lang/String;[Ljava/lang/String;)V (Ljava/lang/Class<*>;[Ljava/lang/String;[Ljava/lang/String;)V -
