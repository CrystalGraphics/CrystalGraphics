cg-stub-db 1
in 0
class scala/compat/Platform 50 public,final,super java/lang/Object - -
 method public,static defaultCharsetName ()Ljava/lang/String; - -
 method public,static collectGarbage ()V - -
 method public,static currentTime ()J - -
 method public,static EOL ()Ljava/lang/String; - -
 method public,static getClassForName (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
 method public,static arrayclear ([I)V - -
 method public,static createArray (Ljava/lang/Class;I)Ljava/lang/Object; (Ljava/lang/Class<*>;I)Ljava/lang/Object; -
 method public,static arraycopy (Ljava/lang/Object;ILjava/lang/Object;II)V - -
in 0
class scala/compat/Platform$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/compat/Platform$; -
 method public,static <clinit> ()V - -
 method public arraycopy (Ljava/lang/Object;ILjava/lang/Object;II)V - -
 method public createArray (Ljava/lang/Class;I)Ljava/lang/Object; (Ljava/lang/Class<*>;I)Ljava/lang/Object; -
 method public arrayclear ([I)V - -
 method public getClassForName (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; -
 method public EOL ()Ljava/lang/String; - -
 method public currentTime ()J - -
 method public collectGarbage ()V - -
 method public defaultCharsetName ()Ljava/lang/String; - -
