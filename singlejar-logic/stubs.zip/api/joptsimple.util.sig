cg-stub-db 1
in 22
class joptsimple/util/DateConverter 51 public,super java/lang/Object joptsimple/ValueConverter Ljava/lang/Object;Ljoptsimple/ValueConverter<Ljava/util/Date;>;
 method public <init> (Ljava/text/DateFormat;)V - -
 method public,static datePattern (Ljava/lang/String;)Ljoptsimple/util/DateConverter; - -
 method public convert (Ljava/lang/String;)Ljava/util/Date; - -
 method public valueType ()Ljava/lang/Class; ()Ljava/lang/Class<Ljava/util/Date;>; -
 method public valuePattern ()Ljava/lang/String; - -
in 22
class joptsimple/util/EnumConverter 51 public,super,abstract java/lang/Object joptsimple/ValueConverter <E:Ljava/lang/Enum<TE;>;>Ljava/lang/Object;Ljoptsimple/ValueConverter<TE;>;
 method protected <init> (Ljava/lang/Class;)V (Ljava/lang/Class<TE;>;)V -
 method public convert (Ljava/lang/String;)Ljava/lang/Enum; (Ljava/lang/String;)TE; -
 method public valueType ()Ljava/lang/Class; ()Ljava/lang/Class<TE;>; -
 method public setDelimiters (Ljava/lang/String;)V - -
 method public valuePattern ()Ljava/lang/String; - -
in 22
class joptsimple/util/InetAddressConverter 51 public,super java/lang/Object joptsimple/ValueConverter Ljava/lang/Object;Ljoptsimple/ValueConverter<Ljava/net/InetAddress;>;
 method public <init> ()V - -
 method public convert (Ljava/lang/String;)Ljava/net/InetAddress; - -
 method public valueType ()Ljava/lang/Class; ()Ljava/lang/Class<Ljava/net/InetAddress;>; -
 method public valuePattern ()Ljava/lang/String; - -
in 22
class joptsimple/util/KeyValuePair 51 public,final,super java/lang/Object - -
 field public,final key Ljava/lang/String; -
 field public,final value Ljava/lang/String; -
 method public,static valueOf (Ljava/lang/String;)Ljoptsimple/util/KeyValuePair; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 22
class joptsimple/util/PathConverter 51 public,super java/lang/Object joptsimple/ValueConverter Ljava/lang/Object;Ljoptsimple/ValueConverter<Ljava/nio/file/Path;>;
 method public,varargs <init> ([Ljoptsimple/util/PathProperties;)V - -
 method public convert (Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public valueType ()Ljava/lang/Class; ()Ljava/lang/Class<Ljava/nio/file/Path;>; -
 method public valuePattern ()Ljava/lang/String; - -
in 22
class joptsimple/util/PathProperties 51 public,super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Ljoptsimple/util/PathProperties;>;
 field public,static,final,enum FILE_EXISTING Ljoptsimple/util/PathProperties; -
 field public,static,final,enum DIRECTORY_EXISTING Ljoptsimple/util/PathProperties; -
 field public,static,final,enum NOT_EXISTING Ljoptsimple/util/PathProperties; -
 field public,static,final,enum FILE_OVERWRITABLE Ljoptsimple/util/PathProperties; -
 field public,static,final,enum READABLE Ljoptsimple/util/PathProperties; -
 field public,static,final,enum WRITABLE Ljoptsimple/util/PathProperties; -
 method public,static values ()[Ljoptsimple/util/PathProperties; - -
 method public,static valueOf (Ljava/lang/String;)Ljoptsimple/util/PathProperties; - -
in 22
class joptsimple/util/RegexMatcher 51 public,super java/lang/Object joptsimple/ValueConverter Ljava/lang/Object;Ljoptsimple/ValueConverter<Ljava/lang/String;>;
 method public <init> (Ljava/lang/String;I)V - -
 method public,static regex (Ljava/lang/String;)Ljoptsimple/ValueConverter; (Ljava/lang/String;)Ljoptsimple/ValueConverter<Ljava/lang/String;>; -
 method public convert (Ljava/lang/String;)Ljava/lang/String; - -
 method public valueType ()Ljava/lang/Class; ()Ljava/lang/Class<Ljava/lang/String;>; -
 method public valuePattern ()Ljava/lang/String; - -
