cg-stub-db 1
in 209
class net/minecraft/nbt/ByteArrayTag 52 public,super gx - Lgx<Lnet/minecraft/nbt/ByteTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public a (I)Lnet/minecraft/nbt/ByteTag; - -
 method public a (ILnet/minecraft/nbt/Tag;)V - -
 method public b (I)V - -
in 203
class net/minecraft/nbt/ByteArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public a (I)Lnet/minecraft/nbt/ByteTag; - -
 method public a (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public b (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public b (I)Lnet/minecraft/nbt/ByteTag; - -
 method public clear ()V - -
in 233
class net/minecraft/nbt/ByteArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public set (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public add (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public clear ()V - -
in 121
class net/minecraft/nbt/ByteArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public set (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public add (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public clear ()V - -
in 92
class net/minecraft/nbt/ByteArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public set (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public add (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
in 86
class net/minecraft/nbt/ByteArrayTag 60 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public set (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public add (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
in 36
class net/minecraft/nbt/ByteArrayTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public set (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public add (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/ByteArrayTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public set (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public add (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 135
class net/minecraft/nbt/ByteArrayTag 65 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/ByteTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>;
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public set (ILnet/minecraft/nbt/ByteTag;)Lnet/minecraft/nbt/ByteTag; - -
 method public add (ILnet/minecraft/nbt/ByteTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 102
class net/minecraft/nbt/ByteArrayTag 65 public,final,super java/lang/Object net/minecraft/nbt/CollectionTag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>;
 method public <init> ([B)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsByteArray ()[B - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/ByteTag; - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/ByteTag; - -
 method public clear ()V - -
 method public asByteArray ()Ljava/util/Optional; ()Ljava/util/Optional<[B>; -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 209
class net/minecraft/nbt/ByteTag 52 public,super hl - -
 method public <init> (B)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 120
class net/minecraft/nbt/ByteTag 52 public,super net/minecraft/nbt/NumericTag - -
 method public <init> (B)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 182
class net/minecraft/nbt/ByteTag 52 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 110
class net/minecraft/nbt/ByteTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 46
class net/minecraft/nbt/ByteTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 529
class net/minecraft/nbt/ByteTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 210
class net/minecraft/nbt/ByteTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 165
class net/minecraft/nbt/ByteTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,deprecated <init> (B)V - -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()B - -
in 114
class net/minecraft/nbt/ByteTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache private,static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 60
class net/minecraft/nbt/ByteTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 437
class net/minecraft/nbt/ByteTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 181
class net/minecraft/nbt/ByteTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 166
class net/minecraft/nbt/ByteTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>;
 field public,static,final ZERO Lnet/minecraft/nbt/ByteTag; -
 field public,static,final ONE Lnet/minecraft/nbt/ByteTag; -
 method public,deprecated <init> (B)V - -
 method public,static valueOf (B)Lnet/minecraft/nbt/ByteTag; - -
 method public,static valueOf (Z)Lnet/minecraft/nbt/ByteTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ByteTag;>; -
 method public copy ()Lnet/minecraft/nbt/ByteTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()B - -
in 182
class net/minecraft/nbt/ByteTag$Cache 52 super java/lang/Object - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
in 86
class net/minecraft/nbt/ByteTag$Cache 60 super java/lang/Object - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
in 99
class net/minecraft/nbt/ByteTag$Cache 61 super java/lang/Object - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
in 62
class net/minecraft/nbt/ByteTag$Cache 65 super java/lang/Object - -
 inner net/minecraft/nbt/ByteTag$Cache net/minecraft/nbt/ByteTag Cache static
in 203
class net/minecraft/nbt/CollectionTag 52 public,super,abstract java/util/AbstractList net/minecraft/nbt/Tag <T::Lnet/minecraft/nbt/Tag;>Ljava/util/AbstractList<TT;>;Lnet/minecraft/nbt/Tag;
 method public <init> ()V - -
 method public,abstract d (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; (ITT;)TT; -
 method public,abstract c (ILnet/minecraft/nbt/Tag;)V (ITT;)V -
 method public,abstract c (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public,abstract setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract addTag (ILnet/minecraft/nbt/Tag;)Z - -
in 227
class net/minecraft/nbt/CollectionTag 52 public,super,abstract java/util/AbstractList net/minecraft/nbt/Tag <T::Lnet/minecraft/nbt/Tag;>Ljava/util/AbstractList<TT;>;Lnet/minecraft/nbt/Tag;
 method public <init> ()V - -
 method public,abstract set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; (ITT;)TT; -
 method public,abstract add (ILnet/minecraft/nbt/Tag;)V (ITT;)V -
 method public,abstract remove (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public,abstract setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract addTag (ILnet/minecraft/nbt/Tag;)Z - -
in 92
class net/minecraft/nbt/CollectionTag 52 public,super,abstract java/util/AbstractList net/minecraft/nbt/Tag <T::Lnet/minecraft/nbt/Tag;>Ljava/util/AbstractList<TT;>;Lnet/minecraft/nbt/Tag;
 method public <init> ()V - -
 method public,abstract set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; (ITT;)TT; -
 method public,abstract add (ILnet/minecraft/nbt/Tag;)V (ITT;)V -
 method public,abstract remove (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public,abstract setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract getElementType ()B - -
in 86
class net/minecraft/nbt/CollectionTag 60 public,super,abstract java/util/AbstractList net/minecraft/nbt/Tag <T::Lnet/minecraft/nbt/Tag;>Ljava/util/AbstractList<TT;>;Lnet/minecraft/nbt/Tag;
 method public <init> ()V - -
 method public,abstract set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; (ITT;)TT; -
 method public,abstract add (ILnet/minecraft/nbt/Tag;)V (ITT;)V -
 method public,abstract remove (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public,abstract setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract getElementType ()B - -
in 99
class net/minecraft/nbt/CollectionTag 61 public,super,abstract java/util/AbstractList net/minecraft/nbt/Tag <T::Lnet/minecraft/nbt/Tag;>Ljava/util/AbstractList<TT;>;Lnet/minecraft/nbt/Tag;
 method public <init> ()V - -
 method public,abstract set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; (ITT;)TT; -
 method public,abstract add (ILnet/minecraft/nbt/Tag;)V (ITT;)V -
 method public,abstract remove (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public,abstract setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract getElementType ()B - -
in 135
class net/minecraft/nbt/CollectionTag 65 public,super,abstract java/util/AbstractList net/minecraft/nbt/Tag <T::Lnet/minecraft/nbt/Tag;>Ljava/util/AbstractList<TT;>;Lnet/minecraft/nbt/Tag;
 method public <init> ()V - -
 method public,abstract set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; (ITT;)TT; -
 method public,abstract add (ILnet/minecraft/nbt/Tag;)V (ITT;)V -
 method public,abstract remove (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public,abstract setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract getElementType ()B - -
in 102
class net/minecraft/nbt/CollectionTag 65 public,interface,abstract java/lang/Object java/lang/Iterable,net/minecraft/nbt/Tag Ljava/lang/Object;Ljava/lang/Iterable<Lnet/minecraft/nbt/Tag;>;Lnet/minecraft/nbt/Tag;
 method public,abstract clear ()V - -
 method public,abstract setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public,abstract remove (I)Lnet/minecraft/nbt/Tag; - -
 method public,abstract get (I)Lnet/minecraft/nbt/Tag; - -
 method public,abstract size ()I - -
 method public isEmpty ()Z - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/nbt/Tag;>; -
 method public stream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>; -
in 209
class net/minecraft/nbt/CompoundTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public size ()I - -
 method public a (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)V - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
in 120
class net/minecraft/nbt/CompoundTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
in 121
class net/minecraft/nbt/CompoundTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public removeUUID (Ljava/lang/String;)V - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
in 92
class net/minecraft/nbt/CompoundTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method protected entries ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>; -
in 86
class net/minecraft/nbt/CompoundTag 60 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putByteArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method protected entries ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>; -
in 36
class net/minecraft/nbt/CompoundTag 61 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putByteArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method protected entries ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>; -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/CompoundTag 61 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putByteArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method protected entries ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>; -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 313
class net/minecraft/nbt/CompoundTag 65 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putByteArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method protected shallowCopy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method protected entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;>; -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 722
class net/minecraft/nbt/CompoundTag 65 public,final,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public contains (Ljava/lang/String;)Z - -
 method public getByte (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Byte;>; -
 method public getByteOr (Ljava/lang/String;B)B - -
 method public getShort (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Short;>; -
 method public getShortOr (Ljava/lang/String;S)S - -
 method public getInt (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public getIntOr (Ljava/lang/String;I)I - -
 method public getLong (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Long;>; -
 method public getLongOr (Ljava/lang/String;J)J - -
 method public getFloat (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Float;>; -
 method public getFloatOr (Ljava/lang/String;F)F - -
 method public getDouble (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Double;>; -
 method public getDoubleOr (Ljava/lang/String;D)D - -
 method public getString (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getStringOr (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[B>; -
 method public getIntArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[I>; -
 method public getLongArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[J>; -
 method public getCompound (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public getCompoundOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public getListOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Boolean;>; -
 method public getBooleanOr (Ljava/lang/String;Z)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method protected shallowCopy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public asCompound ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
in 127
class net/minecraft/nbt/CompoundTag 65 public,final,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public contains (Ljava/lang/String;)Z - -
 method public getByte (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Byte;>; -
 method public getByteOr (Ljava/lang/String;B)B - -
 method public getShort (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Short;>; -
 method public getShortOr (Ljava/lang/String;S)S - -
 method public getInt (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public getIntOr (Ljava/lang/String;I)I - -
 method public getLong (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Long;>; -
 method public getLongOr (Ljava/lang/String;J)J - -
 method public getFloat (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Float;>; -
 method public getFloatOr (Ljava/lang/String;F)F - -
 method public getDouble (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Double;>; -
 method public getDoubleOr (Ljava/lang/String;D)D - -
 method public getString (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getStringOr (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[B>; -
 method public getIntArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[I>; -
 method public getLongArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[J>; -
 method public getCompound (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public getCompoundOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public getListOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Boolean;>; -
 method public getBooleanOr (Ljava/lang/String;Z)Z - -
 method public remove (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method protected shallowCopy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public asCompound ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
in 314
class net/minecraft/nbt/CompoundTag 65 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method protected <init> (Ljava/util/Map;)V (Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> ()V - -
 method public <init> (I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getAllKeys ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putUUID (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUUID (Ljava/lang/String;)Z - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putByteArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putIntArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putLongArray (Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/util/List<Ljava/lang/Long;>;)V -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public getTagType (Ljava/lang/String;)B - -
 method public contains (Ljava/lang/String;)Z - -
 method public contains (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInt (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getLongArray (Ljava/lang/String;)[J - -
 method public getCompound (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;I)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method protected shallowCopy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method protected entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;>; -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 723
class net/minecraft/nbt/CompoundTag 65 public,final,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method public <init> ()V - -
 method public <init> (I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public contains (Ljava/lang/String;)Z - -
 method public getByte (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Byte;>; -
 method public getByteOr (Ljava/lang/String;B)B - -
 method public getShort (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Short;>; -
 method public getShortOr (Ljava/lang/String;S)S - -
 method public getInt (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public getIntOr (Ljava/lang/String;I)I - -
 method public getLong (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Long;>; -
 method public getLongOr (Ljava/lang/String;J)J - -
 method public getFloat (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Float;>; -
 method public getFloatOr (Ljava/lang/String;F)F - -
 method public getDouble (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Double;>; -
 method public getDoubleOr (Ljava/lang/String;D)D - -
 method public getString (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getStringOr (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[B>; -
 method public getIntArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[I>; -
 method public getLongArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[J>; -
 method public getCompound (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public getCompoundOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public getListOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Boolean;>; -
 method public getBooleanOr (Ljava/lang/String;Z)Z - -
 method public remove (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method protected shallowCopy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public asCompound ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
in 50
class net/minecraft/nbt/CompoundTag 65 public,final,super java/lang/Object net/minecraft/nbt/Tag -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>;
 method public <init> ()V - -
 method public <init> (I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public keySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public entrySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/util/Map$Entry<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;>; -
 method public values ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>; -
 method public forEach (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Ljava/lang/String;Lnet/minecraft/nbt/Tag;>;)V -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/CompoundTag;>; -
 method public size ()I - -
 method public put (Ljava/lang/String;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public putByte (Ljava/lang/String;B)V - -
 method public putShort (Ljava/lang/String;S)V - -
 method public putInt (Ljava/lang/String;I)V - -
 method public putLong (Ljava/lang/String;J)V - -
 method public putFloat (Ljava/lang/String;F)V - -
 method public putDouble (Ljava/lang/String;D)V - -
 method public putString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public putByteArray (Ljava/lang/String;[B)V - -
 method public putIntArray (Ljava/lang/String;[I)V - -
 method public putLongArray (Ljava/lang/String;[J)V - -
 method public putBoolean (Ljava/lang/String;Z)V - -
 method public get (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public contains (Ljava/lang/String;)Z - -
 method public getByte (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Byte;>; -
 method public getByteOr (Ljava/lang/String;B)B - -
 method public getShort (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Short;>; -
 method public getShortOr (Ljava/lang/String;S)S - -
 method public getInt (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public getIntOr (Ljava/lang/String;I)I - -
 method public getLong (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Long;>; -
 method public getLongOr (Ljava/lang/String;J)J - -
 method public getFloat (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Float;>; -
 method public getFloatOr (Ljava/lang/String;F)F - -
 method public getDouble (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Double;>; -
 method public getDoubleOr (Ljava/lang/String;D)D - -
 method public getString (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getStringOr (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[B>; -
 method public getIntArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[I>; -
 method public getLongArray (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<[J>; -
 method public getCompound (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public getCompoundOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public getListOrEmpty (Ljava/lang/String;)Lnet/minecraft/nbt/ListTag; - -
 method public getBoolean (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Ljava/lang/Boolean;>; -
 method public getBooleanOr (Ljava/lang/String;Z)Z - -
 method public remove (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method protected shallowCopy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public copy ()Lnet/minecraft/nbt/CompoundTag; - -
 method public asCompound ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;TT;)V -
 method public store (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public storeNullable (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;TT;)V -
 method public store (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)V <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;TT;)V -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Ljava/lang/String;Lcom/mojang/serialization/Codec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Ljava/lang/String;Lcom/mojang/serialization/Codec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;)Ljava/util/Optional<TT;>; -
 method public read (Lcom/mojang/serialization/MapCodec;Lcom/mojang/serialization/DynamicOps;)Ljava/util/Optional; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/MapCodec<TT;>;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;)Ljava/util/Optional<TT;>; -
in 24
class net/minecraft/nbt/CompressedStreamTools 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static safeWrite (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/DataInputStream;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NBTSizeTracker;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
in 326
class net/minecraft/nbt/CompressedStreamTools 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static safeWrite (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/DataInputStream;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NBTSizeTracker;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/NBTTagCompound;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/NBTTagCompound; - java/io/IOException
in 209
class net/minecraft/nbt/DoubleTag 52 public,super hl - -
 method public <init> (D)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 120
class net/minecraft/nbt/DoubleTag 52 public,super net/minecraft/nbt/NumericTag - -
 method public <init> (D)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 182
class net/minecraft/nbt/DoubleTag 52 public,super net/minecraft/nbt/NumericTag - -
 field public,static,final ZERO Lnet/minecraft/nbt/DoubleTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>;
 method public,static valueOf (D)Lnet/minecraft/nbt/DoubleTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 86
class net/minecraft/nbt/DoubleTag 60 public,super net/minecraft/nbt/NumericTag - -
 field public,static,final ZERO Lnet/minecraft/nbt/DoubleTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>;
 method public,static valueOf (D)Lnet/minecraft/nbt/DoubleTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>; -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 36
class net/minecraft/nbt/DoubleTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final ZERO Lnet/minecraft/nbt/DoubleTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>;
 method public,static valueOf (D)Lnet/minecraft/nbt/DoubleTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>; -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/DoubleTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final ZERO Lnet/minecraft/nbt/DoubleTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>;
 method public,static valueOf (D)Lnet/minecraft/nbt/DoubleTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>; -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 135
class net/minecraft/nbt/DoubleTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final ZERO Lnet/minecraft/nbt/DoubleTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>;
 method public,static valueOf (D)Lnet/minecraft/nbt/DoubleTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>; -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 102
class net/minecraft/nbt/DoubleTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ZERO Lnet/minecraft/nbt/DoubleTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>;
 method public,deprecated <init> (D)V - -
 method public,static valueOf (D)Lnet/minecraft/nbt/DoubleTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/DoubleTag;>; -
 method public copy ()Lnet/minecraft/nbt/DoubleTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()D - -
in 120
class net/minecraft/nbt/EndTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 method public <init> ()V - -
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/EndTag; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 182
class net/minecraft/nbt/EndTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>;
 field public,static,final INSTANCE Lnet/minecraft/nbt/EndTag; -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/EndTag; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
in 86
class net/minecraft/nbt/EndTag 60 public,super java/lang/Object net/minecraft/nbt/Tag -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>;
 field public,static,final INSTANCE Lnet/minecraft/nbt/EndTag; -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/EndTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
in 36
class net/minecraft/nbt/EndTag 61 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>;
 field public,static,final INSTANCE Lnet/minecraft/nbt/EndTag; -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/EndTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/EndTag 61 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>;
 field public,static,final INSTANCE Lnet/minecraft/nbt/EndTag; -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/EndTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 135
class net/minecraft/nbt/EndTag 65 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>;
 field public,static,final INSTANCE Lnet/minecraft/nbt/EndTag; -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/EndTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 102
class net/minecraft/nbt/EndTag 65 public,final,super java/lang/Object net/minecraft/nbt/Tag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>;
 field public,static,final INSTANCE Lnet/minecraft/nbt/EndTag; -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/EndTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 209
class net/minecraft/nbt/FloatTag 52 public,super hl - -
 method public <init> (F)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 120
class net/minecraft/nbt/FloatTag 52 public,super net/minecraft/nbt/NumericTag - -
 method public <init> (F)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 182
class net/minecraft/nbt/FloatTag 52 public,super net/minecraft/nbt/NumericTag - -
 field public,static,final ZERO Lnet/minecraft/nbt/FloatTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>;
 method public,static valueOf (F)Lnet/minecraft/nbt/FloatTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 86
class net/minecraft/nbt/FloatTag 60 public,super net/minecraft/nbt/NumericTag - -
 field public,static,final ZERO Lnet/minecraft/nbt/FloatTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>;
 method public,static valueOf (F)Lnet/minecraft/nbt/FloatTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>; -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 36
class net/minecraft/nbt/FloatTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final ZERO Lnet/minecraft/nbt/FloatTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>;
 method public,static valueOf (F)Lnet/minecraft/nbt/FloatTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>; -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/FloatTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final ZERO Lnet/minecraft/nbt/FloatTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>;
 method public,static valueOf (F)Lnet/minecraft/nbt/FloatTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>; -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 135
class net/minecraft/nbt/FloatTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final ZERO Lnet/minecraft/nbt/FloatTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>;
 method public,static valueOf (F)Lnet/minecraft/nbt/FloatTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>; -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 102
class net/minecraft/nbt/FloatTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ZERO Lnet/minecraft/nbt/FloatTag; -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>;
 method public,deprecated <init> (F)V - -
 method public,static valueOf (F)Lnet/minecraft/nbt/FloatTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/FloatTag;>; -
 method public copy ()Lnet/minecraft/nbt/FloatTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()F - -
in 209
class net/minecraft/nbt/IntArrayTag 52 public,super gx - Lgx<Lnet/minecraft/nbt/IntTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public size ()I - -
 method public a (I)Lnet/minecraft/nbt/IntTag; - -
 method public a (ILnet/minecraft/nbt/Tag;)V - -
 method public b (I)V - -
in 203
class net/minecraft/nbt/IntArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public size ()I - -
 method public a (I)Lnet/minecraft/nbt/IntTag; - -
 method public a (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public b (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public b (I)Lnet/minecraft/nbt/IntTag; - -
 method public clear ()V - -
in 233
class net/minecraft/nbt/IntArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public set (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public add (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public clear ()V - -
in 121
class net/minecraft/nbt/IntArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public set (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public add (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public clear ()V - -
in 92
class net/minecraft/nbt/IntArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public set (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public add (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
in 86
class net/minecraft/nbt/IntArrayTag 60 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public set (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public add (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
in 36
class net/minecraft/nbt/IntArrayTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public set (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public add (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/IntArrayTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public set (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public add (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 135
class net/minecraft/nbt/IntArrayTag 65 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/IntTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>;
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public set (ILnet/minecraft/nbt/IntTag;)Lnet/minecraft/nbt/IntTag; - -
 method public add (ILnet/minecraft/nbt/IntTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 102
class net/minecraft/nbt/IntArrayTag 65 public,final,super java/lang/Object net/minecraft/nbt/CollectionTag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>;
 method public <init> ([I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsIntArray ()[I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/IntTag; - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/IntTag; - -
 method public clear ()V - -
 method public asIntArray ()Ljava/util/Optional; ()Ljava/util/Optional<[I>; -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 209
class net/minecraft/nbt/IntTag 52 public,super hl - -
 method public <init> (I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 120
class net/minecraft/nbt/IntTag 52 public,super net/minecraft/nbt/NumericTag - -
 method public <init> (I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 182
class net/minecraft/nbt/IntTag 52 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 110
class net/minecraft/nbt/IntTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 46
class net/minecraft/nbt/IntTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 529
class net/minecraft/nbt/IntTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 210
class net/minecraft/nbt/IntTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 165
class net/minecraft/nbt/IntTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,deprecated <init> (I)V - -
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()I - -
in 114
class net/minecraft/nbt/IntTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache private,static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 60
class net/minecraft/nbt/IntTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 437
class net/minecraft/nbt/IntTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 181
class net/minecraft/nbt/IntTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 166
class net/minecraft/nbt/IntTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>;
 method public,deprecated <init> (I)V - -
 method public,static valueOf (I)Lnet/minecraft/nbt/IntTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/IntTag;>; -
 method public copy ()Lnet/minecraft/nbt/IntTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()I - -
in 182
class net/minecraft/nbt/IntTag$Cache 52 super java/lang/Object - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
in 86
class net/minecraft/nbt/IntTag$Cache 60 super java/lang/Object - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
in 99
class net/minecraft/nbt/IntTag$Cache 61 super java/lang/Object - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
in 62
class net/minecraft/nbt/IntTag$Cache 65 super java/lang/Object - -
 inner net/minecraft/nbt/IntTag$Cache net/minecraft/nbt/IntTag Cache static
in 24
class net/minecraft/nbt/JsonToNBT 50 public,super java/lang/Object - -
 inner net/minecraft/nbt/JsonToNBT$Primitive net/minecraft/nbt/JsonToNBT Primitive static
 inner net/minecraft/nbt/JsonToNBT$List net/minecraft/nbt/JsonToNBT List static
 inner net/minecraft/nbt/JsonToNBT$Compound net/minecraft/nbt/JsonToNBT Compound static
 inner net/minecraft/nbt/JsonToNBT$Any net/minecraft/nbt/JsonToNBT Any static,abstract
 method public,static getTagFromJson (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound; - net/minecraft/nbt/NBTException
in 326
class net/minecraft/nbt/JsonToNBT 52 public,super java/lang/Object - -
 method public,static getTagFromJson (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound; - net/minecraft/nbt/NBTException
 method protected readKey ()Ljava/lang/String; - net/minecraft/nbt/NBTException
 method protected readTypedValue ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
 method protected readValue ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
 method protected readList ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
 method protected readStruct ()Lnet/minecraft/nbt/NBTTagCompound; - net/minecraft/nbt/NBTException
 method protected isAllowedInKey (C)Z - -
in 24
class net/minecraft/nbt/JsonToNBT$Any 50 super,abstract java/lang/Object - -
 inner net/minecraft/nbt/JsonToNBT$Any net/minecraft/nbt/JsonToNBT Any static,abstract
 field protected json Ljava/lang/String; -
 method public,abstract parse ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
in 90
class net/minecraft/nbt/JsonToNBT$Compound 50 super net/minecraft/nbt/JsonToNBT$Any - -
 inner net/minecraft/nbt/JsonToNBT$Any net/minecraft/nbt/JsonToNBT Any static,abstract
 inner net/minecraft/nbt/JsonToNBT$Compound net/minecraft/nbt/JsonToNBT Compound static
 field protected field_150491_b Ljava/util/List; Ljava/util/List<Lnet/minecraft/nbt/JsonToNBT$Any;>;
 method public <init> (Ljava/lang/String;)V - -
 method public parse ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
in 91
class net/minecraft/nbt/JsonToNBT$Compound 50 super net/minecraft/nbt/JsonToNBT$Any - -
 inner net/minecraft/nbt/JsonToNBT$Any net/minecraft/nbt/JsonToNBT Any static,abstract
 inner net/minecraft/nbt/JsonToNBT$Compound net/minecraft/nbt/JsonToNBT Compound static
 field protected tagList Ljava/util/List; Ljava/util/List<Lnet/minecraft/nbt/JsonToNBT$Any;>;
 method public <init> (Ljava/lang/String;)V - -
 method public parse ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
in 90
class net/minecraft/nbt/JsonToNBT$List 50 super net/minecraft/nbt/JsonToNBT$Any - -
 inner net/minecraft/nbt/JsonToNBT$Any net/minecraft/nbt/JsonToNBT Any static,abstract
 inner net/minecraft/nbt/JsonToNBT$List net/minecraft/nbt/JsonToNBT List static
 field protected field_150492_b Ljava/util/List; Ljava/util/List<Lnet/minecraft/nbt/JsonToNBT$Any;>;
 method public <init> (Ljava/lang/String;)V - -
 method public parse ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
in 91
class net/minecraft/nbt/JsonToNBT$List 50 super net/minecraft/nbt/JsonToNBT$Any - -
 inner net/minecraft/nbt/JsonToNBT$Any net/minecraft/nbt/JsonToNBT Any static,abstract
 inner net/minecraft/nbt/JsonToNBT$List net/minecraft/nbt/JsonToNBT List static
 field protected tagList Ljava/util/List; Ljava/util/List<Lnet/minecraft/nbt/JsonToNBT$Any;>;
 method public <init> (Ljava/lang/String;)V - -
 method public parse ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
in 24
class net/minecraft/nbt/JsonToNBT$Primitive 50 super net/minecraft/nbt/JsonToNBT$Any - -
 inner net/minecraft/nbt/JsonToNBT$Primitive net/minecraft/nbt/JsonToNBT Primitive static
 inner net/minecraft/nbt/JsonToNBT$Any net/minecraft/nbt/JsonToNBT Any static,abstract
 field protected jsonValue Ljava/lang/String; -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public parse ()Lnet/minecraft/nbt/NBTBase; - net/minecraft/nbt/NBTException
in 209
class net/minecraft/nbt/ListTag 52 public,super gx - Lgx<Lnet/minecraft/nbt/Tag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public a (Lnet/minecraft/nbt/Tag;)Z - -
 method public b (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public a (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public d (I)Lnet/minecraft/nbt/Tag; - -
 method public size ()I - -
 method public c (I)Lnet/minecraft/nbt/Tag; - -
 method public a (ILnet/minecraft/nbt/Tag;)V - -
 method public b (I)V - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getElementType ()I - -
in 203
class net/minecraft/nbt/ListTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public c (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public k (I)Lnet/minecraft/nbt/Tag; - -
 method public d (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public c (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getElementType ()I - -
 method public clear ()V - -
in 233
class net/minecraft/nbt/ListTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getElementType ()I - -
 method public clear ()V - -
in 121
class net/minecraft/nbt/ListTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getElementType ()I - -
 method public clear ()V - -
in 92
class net/minecraft/nbt/ListTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getElementType ()B - -
 method public clear ()V - -
in 86
class net/minecraft/nbt/ListTag 60 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getLongArray (I)[J - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getElementType ()B - -
 method public clear ()V - -
in 36
class net/minecraft/nbt/ListTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getLongArray (I)[J - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/ListTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getLongArray (I)[J - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 313
class net/minecraft/nbt/ListTag 65 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getLongArray (I)[J - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 724
class net/minecraft/nbt/ListTag 65 public,final,super java/util/AbstractList net/minecraft/nbt/CollectionTag Ljava/util/AbstractList<Lnet/minecraft/nbt/Tag;>;Lnet/minecraft/nbt/CollectionTag;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public addAndUnwrap (Lnet/minecraft/nbt/Tag;)V - -
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Ljava/util/Optional; (I)Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public getCompoundOrEmpty (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Ljava/util/Optional; (I)Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public getListOrEmpty (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Short;>; -
 method public getShortOr (IS)S - -
 method public getInt (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public getIntOr (II)I - -
 method public getIntArray (I)Ljava/util/Optional; (I)Ljava/util/Optional<[I>; -
 method public getLongArray (I)Ljava/util/Optional; (I)Ljava/util/Optional<[J>; -
 method public getDouble (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Double;>; -
 method public getDoubleOr (ID)D - -
 method public getFloat (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Float;>; -
 method public getFloatOr (IF)F - -
 method public getString (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getStringOr (ILjava/lang/String;)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public asList ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public stream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>; -
 method public compoundStream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/nbt/CompoundTag;>; -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 314
class net/minecraft/nbt/ListTag 65 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public <init> (I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)S - -
 method public getInt (I)I - -
 method public getIntArray (I)[I - -
 method public getLongArray (I)[J - -
 method public getDouble (I)D - -
 method public getFloat (I)F - -
 method public getString (I)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 725
class net/minecraft/nbt/ListTag 65 public,final,super java/util/AbstractList net/minecraft/nbt/CollectionTag Ljava/util/AbstractList<Lnet/minecraft/nbt/Tag;>;Lnet/minecraft/nbt/CollectionTag;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>;
 method public <init> ()V - -
 method public <init> (I)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public addAndUnwrap (Lnet/minecraft/nbt/Tag;)V - -
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ListTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public remove (I)Lnet/minecraft/nbt/Tag; - -
 method public isEmpty ()Z - -
 method public getCompound (I)Ljava/util/Optional; (I)Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public getCompoundOrEmpty (I)Lnet/minecraft/nbt/CompoundTag; - -
 method public getList (I)Ljava/util/Optional; (I)Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public getListOrEmpty (I)Lnet/minecraft/nbt/ListTag; - -
 method public getShort (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Short;>; -
 method public getShortOr (IS)S - -
 method public getInt (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public getIntOr (II)I - -
 method public getIntArray (I)Ljava/util/Optional; (I)Ljava/util/Optional<[I>; -
 method public getLongArray (I)Ljava/util/Optional; (I)Ljava/util/Optional<[J>; -
 method public getDouble (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Double;>; -
 method public getDoubleOr (ID)D - -
 method public getFloat (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/Float;>; -
 method public getFloatOr (IF)F - -
 method public getString (I)Ljava/util/Optional; (I)Ljava/util/Optional<Ljava/lang/String;>; -
 method public getStringOr (ILjava/lang/String;)Ljava/lang/String; - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/Tag; - -
 method public set (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public add (ILnet/minecraft/nbt/Tag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public copy ()Lnet/minecraft/nbt/ListTag; - -
 method public asList ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public stream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>; -
 method public compoundStream ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/nbt/CompoundTag;>; -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 209
class net/minecraft/nbt/LongArrayTag 52 public,super gx - Lgx<Lnet/minecraft/nbt/LongTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public a (I)Lnet/minecraft/nbt/LongTag; - -
 method public a (ILnet/minecraft/nbt/Tag;)V - -
 method public b (I)V - -
in 203
class net/minecraft/nbt/LongArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public a (I)Lnet/minecraft/nbt/LongTag; - -
 method public a (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public b (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public b (I)Lnet/minecraft/nbt/LongTag; - -
 method public clear ()V - -
in 233
class net/minecraft/nbt/LongArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public set (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public add (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public clear ()V - -
in 121
class net/minecraft/nbt/LongArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public set (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public add (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public clear ()V - -
in 92
class net/minecraft/nbt/LongArrayTag 52 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public set (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public add (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
in 86
class net/minecraft/nbt/LongArrayTag 60 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public set (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public add (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
in 36
class net/minecraft/nbt/LongArrayTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public set (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public add (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/LongArrayTag 61 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public set (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public add (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 135
class net/minecraft/nbt/LongArrayTag 65 public,super net/minecraft/nbt/CollectionTag - Lnet/minecraft/nbt/CollectionTag<Lnet/minecraft/nbt/LongTag;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>;
 method public <init> ([J)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongSet;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public set (ILnet/minecraft/nbt/LongTag;)Lnet/minecraft/nbt/LongTag; - -
 method public add (ILnet/minecraft/nbt/LongTag;)V - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public getElementType ()B - -
 method public clear ()V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 102
class net/minecraft/nbt/LongArrayTag 65 public,final,super java/lang/Object net/minecraft/nbt/CollectionTag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>;
 method public <init> ([J)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongArrayTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongArrayTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLongArray ()[J - -
 method public size ()I - -
 method public get (I)Lnet/minecraft/nbt/LongTag; - -
 method public setTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public addTag (ILnet/minecraft/nbt/Tag;)Z - -
 method public remove (I)Lnet/minecraft/nbt/LongTag; - -
 method public clear ()V - -
 method public asLongArray ()Ljava/util/Optional; ()Ljava/util/Optional<[J>; -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 209
class net/minecraft/nbt/LongTag 52 public,super hl - -
 method public <init> (J)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 120
class net/minecraft/nbt/LongTag 52 public,super net/minecraft/nbt/NumericTag - -
 method public <init> (J)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 182
class net/minecraft/nbt/LongTag 52 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 110
class net/minecraft/nbt/LongTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 46
class net/minecraft/nbt/LongTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 529
class net/minecraft/nbt/LongTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 210
class net/minecraft/nbt/LongTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 165
class net/minecraft/nbt/LongTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,deprecated <init> (J)V - -
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()J - -
in 114
class net/minecraft/nbt/LongTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache private,static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 60
class net/minecraft/nbt/LongTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 437
class net/minecraft/nbt/LongTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 181
class net/minecraft/nbt/LongTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 166
class net/minecraft/nbt/LongTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>;
 method public,deprecated <init> (J)V - -
 method public,static valueOf (J)Lnet/minecraft/nbt/LongTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/LongTag;>; -
 method public copy ()Lnet/minecraft/nbt/LongTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()J - -
in 182
class net/minecraft/nbt/LongTag$Cache 52 super java/lang/Object - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
in 86
class net/minecraft/nbt/LongTag$Cache 60 super java/lang/Object - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
in 99
class net/minecraft/nbt/LongTag$Cache 61 super java/lang/Object - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
in 62
class net/minecraft/nbt/LongTag$Cache 65 super java/lang/Object - -
 inner net/minecraft/nbt/LongTag$Cache net/minecraft/nbt/LongTag Cache static
in 90
class net/minecraft/nbt/NBTBase 50 public,super,abstract java/lang/Object - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 field public,static,final NBT_TYPES [Ljava/lang/String; -
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method protected <init> ()V - -
 method protected,static createNewByType (B)Lnet/minecraft/nbt/NBTBase; - -
 method public,abstract copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public hasNoTags ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method protected getString ()Ljava/lang/String; - -
in 91
class net/minecraft/nbt/NBTBase 50 public,super,abstract java/lang/Object - -
 field public,static,final NBT_TYPES [Ljava/lang/String; -
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method protected <init> ()V - -
 method protected,static createNewByType (B)Lnet/minecraft/nbt/NBTBase; - -
 method public,abstract copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public hasNoTags ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method protected getString ()Ljava/lang/String; - -
in 326
class net/minecraft/nbt/NBTBase 52 public,super,abstract java/lang/Object - -
 field public,static,final NBT_TYPES [Ljava/lang/String; -
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method protected <init> ()V - -
 method protected,static create (B)Lnet/minecraft/nbt/NBTBase; - -
 method public,static getTypeName (I)Ljava/lang/String; - -
 method public,abstract copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public isEmpty ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method protected getString ()Ljava/lang/String; - -
in 90
class net/minecraft/nbt/NBTBase$NBTPrimitive 50 public,super,abstract net/minecraft/nbt/NBTBase - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method protected <init> ()V - -
 method public,abstract getLong ()J - -
 method public,abstract getInt ()I - -
 method public,abstract getShort ()S - -
 method public,abstract getByte ()B - -
 method public,abstract getDouble ()D - -
 method public,abstract getFloat ()F - -
in 24
class net/minecraft/nbt/NBTException 50 public,super java/lang/Exception - -
 method public <init> (Ljava/lang/String;)V - -
in 326
class net/minecraft/nbt/NBTException 52 public,super java/lang/Exception - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;I)V - -
in 91
class net/minecraft/nbt/NBTPrimitive 50 public,super,abstract net/minecraft/nbt/NBTBase - -
 method protected <init> ()V - -
 method public,abstract getLong ()J - -
 method public,abstract getInt ()I - -
 method public,abstract getShort ()S - -
 method public,abstract getByte ()B - -
 method public,abstract getDouble ()D - -
 method public,abstract getFloat ()F - -
in 326
class net/minecraft/nbt/NBTPrimitive 52 public,super,abstract net/minecraft/nbt/NBTBase - -
 method protected <init> ()V - -
 method public,abstract getLong ()J - -
 method public,abstract getInt ()I - -
 method public,abstract getShort ()S - -
 method public,abstract getByte ()B - -
 method public,abstract getDouble ()D - -
 method public,abstract getFloat ()F - -
in 24
class net/minecraft/nbt/NBTSizeTracker 50 public,super java/lang/Object - -
 field public,static,final INFINITE Lnet/minecraft/nbt/NBTSizeTracker; -
 method public <init> (J)V - -
 method public read (J)V - -
 method public,static readUTF (Lnet/minecraft/nbt/NBTSizeTracker;Ljava/lang/String;)V - -
in 326
class net/minecraft/nbt/NBTSizeTracker 52 public,super java/lang/Object - -
 field public,static,final INFINITE Lnet/minecraft/nbt/NBTSizeTracker; -
 method public <init> (J)V - -
 method public read (J)V - -
 method public,static readUTF (Lnet/minecraft/nbt/NBTSizeTracker;Ljava/lang/String;)V - -
in 90
class net/minecraft/nbt/NBTTagByte 50 public,super net/minecraft/nbt/NBTBase$NBTPrimitive - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method public <init> (B)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 91
class net/minecraft/nbt/NBTTagByte 50 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (B)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagByte; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 326
class net/minecraft/nbt/NBTTagByte 52 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (B)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagByte; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 24
class net/minecraft/nbt/NBTTagByteArray 50 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ([B)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getByteArray ()[B - -
in 326
class net/minecraft/nbt/NBTTagByteArray 52 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ([B)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Byte;>;)V -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getByteArray ()[B - -
in 90
class net/minecraft/nbt/NBTTagCompound 50 public,super net/minecraft/nbt/NBTBase - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method public <init> ()V - -
 method public getKeySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public setTag (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V - -
 method public setByte (Ljava/lang/String;B)V - -
 method public setShort (Ljava/lang/String;S)V - -
 method public setInteger (Ljava/lang/String;I)V - -
 method public setLong (Ljava/lang/String;J)V - -
 method public setFloat (Ljava/lang/String;F)V - -
 method public setDouble (Ljava/lang/String;D)V - -
 method public setString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public setByteArray (Ljava/lang/String;[B)V - -
 method public setIntArray (Ljava/lang/String;[I)V - -
 method public setBoolean (Ljava/lang/String;Z)V - -
 method public getTag (Ljava/lang/String;)Lnet/minecraft/nbt/NBTBase; - -
 method public getTagId (Ljava/lang/String;)B - -
 method public hasKey (Ljava/lang/String;)Z - -
 method public hasKey (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInteger (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getCompoundTag (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getTagList (Ljava/lang/String;I)Lnet/minecraft/nbt/NBTTagList; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public removeTag (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public hasNoTags ()Z - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/nbt/NBTTagCompound 50 public,super net/minecraft/nbt/NBTBase - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public getKeySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getSize ()I - -
 method public setTag (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V - -
 method public setByte (Ljava/lang/String;B)V - -
 method public setShort (Ljava/lang/String;S)V - -
 method public setInteger (Ljava/lang/String;I)V - -
 method public setLong (Ljava/lang/String;J)V - -
 method public setUniqueId (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUniqueId (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUniqueId (Ljava/lang/String;)Z - -
 method public setFloat (Ljava/lang/String;F)V - -
 method public setDouble (Ljava/lang/String;D)V - -
 method public setString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public setByteArray (Ljava/lang/String;[B)V - -
 method public setIntArray (Ljava/lang/String;[I)V - -
 method public setBoolean (Ljava/lang/String;Z)V - -
 method public getTag (Ljava/lang/String;)Lnet/minecraft/nbt/NBTBase; - -
 method public getTagId (Ljava/lang/String;)B - -
 method public hasKey (Ljava/lang/String;)Z - -
 method public hasKey (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInteger (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getCompoundTag (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getTagList (Ljava/lang/String;I)Lnet/minecraft/nbt/NBTTagList; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public removeTag (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public hasNoTags ()Z - -
 method public copy ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/nbt/NBTTagCompound 52 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ()V - -
 method public getKeySet ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public getId ()B - -
 method public getSize ()I - -
 method public setTag (Ljava/lang/String;Lnet/minecraft/nbt/NBTBase;)V - -
 method public setByte (Ljava/lang/String;B)V - -
 method public setShort (Ljava/lang/String;S)V - -
 method public setInteger (Ljava/lang/String;I)V - -
 method public setLong (Ljava/lang/String;J)V - -
 method public setUniqueId (Ljava/lang/String;Ljava/util/UUID;)V - -
 method public getUniqueId (Ljava/lang/String;)Ljava/util/UUID; - -
 method public hasUniqueId (Ljava/lang/String;)Z - -
 method public setFloat (Ljava/lang/String;F)V - -
 method public setDouble (Ljava/lang/String;D)V - -
 method public setString (Ljava/lang/String;Ljava/lang/String;)V - -
 method public setByteArray (Ljava/lang/String;[B)V - -
 method public setIntArray (Ljava/lang/String;[I)V - -
 method public setBoolean (Ljava/lang/String;Z)V - -
 method public getTag (Ljava/lang/String;)Lnet/minecraft/nbt/NBTBase; - -
 method public getTagId (Ljava/lang/String;)B - -
 method public hasKey (Ljava/lang/String;)Z - -
 method public hasKey (Ljava/lang/String;I)Z - -
 method public getByte (Ljava/lang/String;)B - -
 method public getShort (Ljava/lang/String;)S - -
 method public getInteger (Ljava/lang/String;)I - -
 method public getLong (Ljava/lang/String;)J - -
 method public getFloat (Ljava/lang/String;)F - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getString (Ljava/lang/String;)Ljava/lang/String; - -
 method public getByteArray (Ljava/lang/String;)[B - -
 method public getIntArray (Ljava/lang/String;)[I - -
 method public getCompoundTag (Ljava/lang/String;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getTagList (Ljava/lang/String;I)Lnet/minecraft/nbt/NBTTagList; - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public removeTag (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isEmpty ()Z - -
 method public copy ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public merge (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
in 90
class net/minecraft/nbt/NBTTagDouble 50 public,super net/minecraft/nbt/NBTBase$NBTPrimitive - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method public <init> (D)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 91
class net/minecraft/nbt/NBTTagDouble 50 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (D)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagDouble; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 326
class net/minecraft/nbt/NBTTagDouble 52 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (D)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagDouble; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 90
class net/minecraft/nbt/NBTTagEnd 50 public,super net/minecraft/nbt/NBTBase - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
in 91
class net/minecraft/nbt/NBTTagEnd 50 public,super net/minecraft/nbt/NBTBase - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagEnd; - -
in 326
class net/minecraft/nbt/NBTTagEnd 52 public,super net/minecraft/nbt/NBTBase - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagEnd; - -
in 90
class net/minecraft/nbt/NBTTagFloat 50 public,super net/minecraft/nbt/NBTBase$NBTPrimitive - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method public <init> (F)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 91
class net/minecraft/nbt/NBTTagFloat 50 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (F)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagFloat; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 326
class net/minecraft/nbt/NBTTagFloat 52 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (F)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagFloat; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 90
class net/minecraft/nbt/NBTTagInt 50 public,super net/minecraft/nbt/NBTBase$NBTPrimitive - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method public <init> (I)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 91
class net/minecraft/nbt/NBTTagInt 50 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (I)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagInt; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 326
class net/minecraft/nbt/NBTTagInt 52 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (I)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagInt; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 90
class net/minecraft/nbt/NBTTagIntArray 50 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ([I)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getIntArray ()[I - -
in 91
class net/minecraft/nbt/NBTTagIntArray 50 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ([I)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagIntArray; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getIntArray ()[I - -
in 326
class net/minecraft/nbt/NBTTagIntArray 52 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ([I)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Integer;>;)V -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagIntArray; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getIntArray ()[I - -
in 90
class net/minecraft/nbt/NBTTagList 50 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ()V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public appendTag (Lnet/minecraft/nbt/NBTBase;)V - -
 method public set (ILnet/minecraft/nbt/NBTBase;)V - -
 method public removeTag (I)Lnet/minecraft/nbt/NBTBase; - -
 method public hasNoTags ()Z - -
 method public getCompoundTagAt (I)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getIntArrayAt (I)[I - -
 method public getDoubleAt (I)D - -
 method public getFloatAt (I)F - -
 method public getStringTagAt (I)Ljava/lang/String; - -
 method public get (I)Lnet/minecraft/nbt/NBTBase; - -
 method public tagCount ()I - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getTagType ()I - -
in 91
class net/minecraft/nbt/NBTTagList 50 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ()V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public appendTag (Lnet/minecraft/nbt/NBTBase;)V - -
 method public set (ILnet/minecraft/nbt/NBTBase;)V - -
 method public removeTag (I)Lnet/minecraft/nbt/NBTBase; - -
 method public hasNoTags ()Z - -
 method public getCompoundTagAt (I)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getIntAt (I)I - -
 method public getIntArrayAt (I)[I - -
 method public getDoubleAt (I)D - -
 method public getFloatAt (I)F - -
 method public getStringTagAt (I)Ljava/lang/String; - -
 method public get (I)Lnet/minecraft/nbt/NBTBase; - -
 method public tagCount ()I - -
 method public copy ()Lnet/minecraft/nbt/NBTTagList; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getTagType ()I - -
in 326
class net/minecraft/nbt/NBTTagList 52 public,super net/minecraft/nbt/NBTBase java/lang/Iterable Lnet/minecraft/nbt/NBTBase;Ljava/lang/Iterable<Lnet/minecraft/nbt/NBTBase;>;
 method public <init> ()V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public appendTag (Lnet/minecraft/nbt/NBTBase;)V - -
 method public set (ILnet/minecraft/nbt/NBTBase;)V - -
 method public removeTag (I)Lnet/minecraft/nbt/NBTBase; - -
 method public isEmpty ()Z - -
 method public getCompoundTagAt (I)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getIntAt (I)I - -
 method public getIntArrayAt (I)[I - -
 method public getDoubleAt (I)D - -
 method public getFloatAt (I)F - -
 method public getStringTagAt (I)Ljava/lang/String; - -
 method public get (I)Lnet/minecraft/nbt/NBTBase; - -
 method public tagCount ()I - -
 method public copy ()Lnet/minecraft/nbt/NBTTagList; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getTagType ()I - -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/nbt/NBTBase;>; -
in 90
class net/minecraft/nbt/NBTTagLong 50 public,super net/minecraft/nbt/NBTBase$NBTPrimitive - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method public <init> (J)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 91
class net/minecraft/nbt/NBTTagLong 50 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (J)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagLong; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 326
class net/minecraft/nbt/NBTTagLong 52 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> (J)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagLong; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 326
class net/minecraft/nbt/NBTTagLongArray 52 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ([J)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljava/lang/Long;>;)V -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagLongArray; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 90
class net/minecraft/nbt/NBTTagShort 50 public,super net/minecraft/nbt/NBTBase$NBTPrimitive - -
 inner net/minecraft/nbt/NBTBase$NBTPrimitive net/minecraft/nbt/NBTBase NBTPrimitive public,static,abstract
 method public <init> ()V - -
 method public <init> (S)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 91
class net/minecraft/nbt/NBTTagShort 50 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> ()V - -
 method public <init> (S)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagShort; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 326
class net/minecraft/nbt/NBTTagShort 52 public,super net/minecraft/nbt/NBTPrimitive - -
 method public <init> ()V - -
 method public <init> (S)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagShort; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getLong ()J - -
 method public getInt ()I - -
 method public getShort ()S - -
 method public getByte ()B - -
 method public getDouble ()D - -
 method public getFloat ()F - -
in 90
class net/minecraft/nbt/NBTTagString 50 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTBase; - -
 method public hasNoTags ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getString ()Ljava/lang/String; - -
in 91
class net/minecraft/nbt/NBTTagString 50 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagString; - -
 method public hasNoTags ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getString ()Ljava/lang/String; - -
in 326
class net/minecraft/nbt/NBTTagString 52 public,super net/minecraft/nbt/NBTBase - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/NBTTagString; - -
 method public isEmpty ()Z - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getString ()Ljava/lang/String; - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
in 90
class net/minecraft/nbt/NBTUtil 50 public,final,super java/lang/Object - -
 method public,static readGameProfileFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/NBTTagCompound;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static func_181123_a (Lnet/minecraft/nbt/NBTBase;Lnet/minecraft/nbt/NBTBase;Z)Z - -
in 91
class net/minecraft/nbt/NBTUtil 50 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static readGameProfileFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/NBTTagCompound;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static areNBTEquals (Lnet/minecraft/nbt/NBTBase;Lnet/minecraft/nbt/NBTBase;Z)Z - -
 method public,static createUUIDTag (Ljava/util/UUID;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static getUUIDFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/UUID; - -
 method public,static getPosFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/util/math/BlockPos; - -
 method public,static createPosTag (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static readBlockState (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/block/state/IBlockState; - -
 method public,static writeBlockState (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/nbt/NBTTagCompound; - -
in 326
class net/minecraft/nbt/NBTUtil 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static readGameProfileFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/NBTTagCompound;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static areNBTEquals (Lnet/minecraft/nbt/NBTBase;Lnet/minecraft/nbt/NBTBase;Z)Z - -
 method public,static createUUIDTag (Ljava/util/UUID;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static getUUIDFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/UUID; - -
 method public,static getPosFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/util/math/BlockPos; - -
 method public,static createPosTag (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static readBlockState (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/block/state/IBlockState; - -
 method public,static writeBlockState (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/nbt/NBTTagCompound; - -
in 539
class net/minecraft/nbt/NbtAccounter 52 public,super java/lang/Object - -
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBits (J)V - -
in 110
class net/minecraft/nbt/NbtAccounter 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBits (J)V - -
 method public readUTF (Ljava/lang/String;)Ljava/lang/String; - -
in 46
class net/minecraft/nbt/NbtAccounter 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBits (J)V - -
 method public readUTF (Ljava/lang/String;)Ljava/lang/String; - -
in 47
class net/minecraft/nbt/NbtAccounter 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBytes (J)V - -
 method public readUTF (Ljava/lang/String;)Ljava/lang/String; - -
 method public getUsage ()J - -
in 561
class net/minecraft/nbt/NbtAccounter 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (JI)V - -
 method public,static create (J)Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static unlimitedHeap ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public accountBytes (JJ)V - -
 method public accountBytes (J)V - -
 method public pushDepth ()V - -
 method public popDepth ()V - -
 method public getUsage ()J - -
 method public getDepth ()I - -
in 559
class net/minecraft/nbt/NbtAccounter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (JI)V - -
 method public,static create (J)Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static unlimitedHeap ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public accountBytes (JJ)V - -
 method public accountBytes (J)V - -
 method public pushDepth ()V - -
 method public popDepth ()V - -
 method public getUsage ()J - -
 method public getDepth ()I - -
in 127
class net/minecraft/nbt/NbtAccounter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_NBT_QUOTA I - I2097152
 field public,static,final UNCOMPRESSED_NBT_QUOTA I - I104857600
 method public <init> (JI)V - -
 method public,static create (J)Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static defaultQuota ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static uncompressedQuota ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static unlimitedHeap ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public accountBytes (JJ)V - -
 method public accountBytes (J)V - -
 method public pushDepth ()V - -
 method public popDepth ()V - -
 method public getUsage ()J - -
 method public getDepth ()I - -
in 264
class net/minecraft/nbt/NbtAccounter 52 public,super java/lang/Object - -
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBits (J)V - -
 method public,static readUTF (Lnet/minecraft/nbt/NbtAccounter;Ljava/lang/String;)V - -
in 223
class net/minecraft/nbt/NbtAccounter 52 public,super java/lang/Object - -
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBits (J)V - -
 method public readUTF (Ljava/lang/String;)Ljava/lang/String; - -
in 198
class net/minecraft/nbt/NbtAccounter 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (JI)V - -
 method public,static create (J)Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static unlimitedHeap ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public accountBytes (JJ)V - -
 method public accountBytes (J)V - -
 method public pushDepth ()V - -
 method public popDepth ()V - -
 method public readUTF (Ljava/lang/String;)Ljava/lang/String; - -
 method public getUsage ()J - -
 method public getDepth ()I - -
in 569
class net/minecraft/nbt/NbtAccounter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (JI)V - -
 method public,static create (J)Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static unlimitedHeap ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public accountBytes (JJ)V - -
 method public accountBytes (J)V - -
 method public pushDepth ()V - -
 method public popDepth ()V - -
 method public readUTF (Ljava/lang/String;)Ljava/lang/String; - -
 method public getUsage ()J - -
 method public getDepth ()I - -
in 50
class net/minecraft/nbt/NbtAccounter 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_NBT_QUOTA I - I2097152
 field public,static,final UNCOMPRESSED_NBT_QUOTA I - I104857600
 method public <init> (JI)V - -
 method public,static create (J)Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static defaultQuota ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static uncompressedQuota ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public,static unlimitedHeap ()Lnet/minecraft/nbt/NbtAccounter; - -
 method public accountBytes (JJ)V - -
 method public accountBytes (J)V - -
 method public pushDepth ()V - -
 method public popDepth ()V - -
 method public readUTF (Ljava/lang/String;)Ljava/lang/String; - -
 method public getUsage ()J - -
 method public getDepth ()I - -
in 114
class net/minecraft/nbt/NbtAccounter 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBits (J)V - -
in 60
class net/minecraft/nbt/NbtAccounter 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBits (J)V - -
in 57
class net/minecraft/nbt/NbtAccounter 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final UNLIMITED Lnet/minecraft/nbt/NbtAccounter; -
 method public <init> (J)V - -
 method public accountBytes (J)V - -
 method public getUsage ()J - -
in 75
class net/minecraft/nbt/NbtAccounterException 61 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 122
class net/minecraft/nbt/NbtAccounterException 61 public,super net/minecraft/nbt/NbtException - -
 method public <init> (Ljava/lang/String;)V - -
in 62
class net/minecraft/nbt/NbtAccounterException 65 public,super net/minecraft/nbt/NbtException - -
 method public <init> (Ljava/lang/String;)V - -
in 122
class net/minecraft/nbt/NbtException 61 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 62
class net/minecraft/nbt/NbtException 65 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 122
class net/minecraft/nbt/NbtFormatException 61 public,super net/minecraft/nbt/NbtException - -
 method public <init> (Ljava/lang/String;)V - -
in 62
class net/minecraft/nbt/NbtFormatException 65 public,super net/minecraft/nbt/NbtException - -
 method public <init> (Ljava/lang/String;)V - -
in 486
class net/minecraft/nbt/NbtIo 52 public,super java/lang/Object - -
 method public,static safeWrite (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static read (Ljava/io/DataInputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
in 493
class net/minecraft/nbt/NbtIo 52 public,super java/lang/Object - -
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static safeWrite (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
in 188
class net/minecraft/nbt/NbtIo 52 public,super java/lang/Object - -
 method public,static readCompressed (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
in 86
class net/minecraft/nbt/NbtIo 60 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static readCompressed (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
in 38
class net/minecraft/nbt/NbtIo 61 public,super java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 method public <init> ()V - -
 method public,static readCompressed (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static parseCompressed (Ljava/io/File;Lnet/minecraft/nbt/StreamTagVisitor;)V - java/io/IOException
 method public,static parseCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/StreamTagVisitor;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;)V - java/io/IOException
 method public,static writeUnnamedTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
in 75
class net/minecraft/nbt/NbtIo 61 public,super java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 method public <init> ()V - -
 method public,static readCompressed (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static parseCompressed (Ljava/io/File;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static parseCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static readAnyTag (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; - java/io/IOException
 method public,static writeAnyTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static writeUnnamedTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
in 122
class net/minecraft/nbt/NbtIo 61 public,super java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/NbtIo$StringFallbackDataOutput net/minecraft/nbt/NbtIo StringFallbackDataOutput public,static
 method public <init> ()V - -
 method public,static readCompressed (Ljava/nio/file/Path;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static parseCompressed (Ljava/nio/file/Path;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static parseCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static read (Ljava/nio/file/Path;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static readAnyTag (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; - java/io/IOException
 method public,static writeAnyTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static writeUnnamedTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static writeUnnamedTagWithFallback (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
in 135
class net/minecraft/nbt/NbtIo 65 public,super java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/NbtIo$StringFallbackDataOutput net/minecraft/nbt/NbtIo StringFallbackDataOutput public,static
 method public <init> ()V - -
 method public,static readCompressed (Ljava/nio/file/Path;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static parseCompressed (Ljava/nio/file/Path;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static parseCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static read (Ljava/nio/file/Path;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static readAnyTag (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; - java/io/IOException
 method public,static writeAnyTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static writeUnnamedTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static writeUnnamedTagWithFallback (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
in 102
class net/minecraft/nbt/NbtIo 65 public,super java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/NbtIo$StringFallbackDataOutput net/minecraft/nbt/NbtIo StringFallbackDataOutput public,static
 method public <init> ()V - -
 method public,static readCompressed (Ljava/nio/file/Path;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static parseCompressed (Ljava/nio/file/Path;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static parseCompressed (Ljava/io/InputStream;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/nio/file/Path;)V - java/io/IOException
 method public,static read (Ljava/nio/file/Path;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,static readAnyTag (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; - java/io/IOException
 method public,static writeAnyTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static writeUnnamedTag (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static writeUnnamedTagWithFallback (Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V - java/io/IOException
 method public,static readUnnamedTag (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; - java/io/IOException
in 398
class net/minecraft/nbt/NbtIo 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static safeWrite (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
in 197
class net/minecraft/nbt/NbtIo 52 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static readCompressed (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static readCompressed (Ljava/io/InputStream;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static writeCompressed (Lnet/minecraft/nbt/CompoundTag;Ljava/io/OutputStream;)V - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/File;)V - java/io/IOException
 method public,static read (Ljava/io/File;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static read (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
 method public,static write (Lnet/minecraft/nbt/CompoundTag;Ljava/io/DataOutput;)V - java/io/IOException
in 122
class net/minecraft/nbt/NbtIo$StringFallbackDataOutput 61 public,super net/minecraft/util/DelegateDataOutput - -
 inner net/minecraft/nbt/NbtIo$StringFallbackDataOutput net/minecraft/nbt/NbtIo StringFallbackDataOutput public,static
 method public <init> (Ljava/io/DataOutput;)V - -
 method public writeUTF (Ljava/lang/String;)V - java/io/IOException
in 62
class net/minecraft/nbt/NbtIo$StringFallbackDataOutput 65 public,super net/minecraft/util/DelegateDataOutput - -
 inner net/minecraft/nbt/NbtIo$StringFallbackDataOutput net/minecraft/nbt/NbtIo StringFallbackDataOutput public,static
 method public <init> (Ljava/io/DataOutput;)V - -
 method public writeUTF (Ljava/lang/String;)V - java/io/IOException
in 315
class net/minecraft/nbt/NbtOps 52 public,super java/lang/Object com/mojang/datafixers/types/DynamicOps Ljava/lang/Object;Lcom/mojang/datafixers/types/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/types/templates/List$ListType com/mojang/datafixers/types/templates/List ListType public,static,final
 inner com/mojang/datafixers/types/templates/CompoundList$CompoundListType com/mojang/datafixers/types/templates/CompoundList CompoundListType public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public a ()Lnet/minecraft/nbt/Tag; - -
 method public a (Lnet/minecraft/nbt/Tag;)Lcom/mojang/datafixers/types/Type; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/datafixers/types/Type<*>; -
 method public b (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/lang/Number;>; -
 method public a (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public a (B)Lnet/minecraft/nbt/Tag; - -
 method public a (S)Lnet/minecraft/nbt/Tag; - -
 method public a (I)Lnet/minecraft/nbt/Tag; - -
 method public a (J)Lnet/minecraft/nbt/Tag; - -
 method public a (F)Lnet/minecraft/nbt/Tag; - -
 method public a (D)Lnet/minecraft/nbt/Tag; - -
 method public c (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public a (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public a (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public a (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public b (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public d (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>; -
 method public a (Ljava/util/Map;)Lnet/minecraft/nbt/Tag; (Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public e (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public f (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/nio/ByteBuffer;>; -
 method public a (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public g (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/IntStream;>; -
 method public a (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public h (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/LongStream;>; -
 method public a (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public a (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public a (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
in 233
class net/minecraft/nbt/NbtOps 52 public,super java/lang/Object com/mojang/datafixers/types/DynamicOps Ljava/lang/Object;Lcom/mojang/datafixers/types/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/types/templates/List$ListType com/mojang/datafixers/types/templates/List ListType public,static,final
 inner com/mojang/datafixers/types/templates/CompoundList$CompoundListType com/mojang/datafixers/types/templates/CompoundList CompoundListType public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public getType (Lnet/minecraft/nbt/Tag;)Lcom/mojang/datafixers/types/Type; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/datafixers/types/Type<*>; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeInto (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public mergeInto (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public merge (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/Map;)Lnet/minecraft/nbt/Tag; (Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
in 121
class net/minecraft/nbt/NbtOps 52 public,super java/lang/Object com/mojang/datafixers/types/DynamicOps Ljava/lang/Object;Lcom/mojang/datafixers/types/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/types/templates/List$ListType com/mojang/datafixers/types/templates/List ListType public,static,final
 inner com/mojang/datafixers/types/templates/CompoundList$CompoundListType com/mojang/datafixers/types/templates/CompoundList CompoundListType public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public getType (Lnet/minecraft/nbt/Tag;)Lcom/mojang/datafixers/types/Type; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/datafixers/types/Type<*>; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeInto (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public mergeInto (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public merge (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; - -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/Map;)Lnet/minecraft/nbt/Tag; (Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional; (Lnet/minecraft/nbt/Tag;)Ljava/util/Optional<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
in 92
class net/minecraft/nbt/NbtOps 52 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 110
class net/minecraft/nbt/NbtOps 60 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 46
class net/minecraft/nbt/NbtOps 61 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 529
class net/minecraft/nbt/NbtOps 61 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 210
class net/minecraft/nbt/NbtOps 65 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 641
class net/minecraft/nbt/NbtOps 65 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 147
class net/minecraft/nbt/NbtOps 65 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public emptyList ()Lnet/minecraft/nbt/Tag; - -
 method public emptyMap ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 114
class net/minecraft/nbt/NbtOps 60 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 60
class net/minecraft/nbt/NbtOps 61 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder private
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 437
class net/minecraft/nbt/NbtOps 61 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder private
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector private,static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector private,static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 181
class net/minecraft/nbt/NbtOps 65 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder private
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector private,static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector private,static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method protected <init> ()V - -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 289
class net/minecraft/nbt/NbtOps 65 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder private
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector private,static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector private,static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector private,static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 149
class net/minecraft/nbt/NbtOps 65 public,super java/lang/Object com/mojang/serialization/DynamicOps Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps<Lnet/minecraft/nbt/Tag;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder private
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector private,static
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector private,static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector private,static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps; -
 method public empty ()Lnet/minecraft/nbt/Tag; - -
 method public emptyList ()Lnet/minecraft/nbt/Tag; - -
 method public emptyMap ()Lnet/minecraft/nbt/Tag; - -
 method public convertTo (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/Tag;)Ljava/lang/Object; <U:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TU;>;Lnet/minecraft/nbt/Tag;)TU; -
 method public getNumberValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/Number;>; -
 method public createNumeric (Ljava/lang/Number;)Lnet/minecraft/nbt/Tag; - -
 method public createByte (B)Lnet/minecraft/nbt/Tag; - -
 method public createShort (S)Lnet/minecraft/nbt/Tag; - -
 method public createInt (I)Lnet/minecraft/nbt/Tag; - -
 method public createLong (J)Lnet/minecraft/nbt/Tag; - -
 method public createFloat (F)Lnet/minecraft/nbt/Tag; - -
 method public createDouble (D)Lnet/minecraft/nbt/Tag; - -
 method public createBoolean (Z)Lnet/minecraft/nbt/Tag; - -
 method public getStringValue (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/lang/String;>; -
 method public createString (Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToList (Lnet/minecraft/nbt/Tag;Ljava/util/List;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/List<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public mergeToMap (Lnet/minecraft/nbt/Tag;Ljava/util/Map;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;Ljava/util/Map<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
 method public getMapValues (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMapEntries (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/BiConsumer<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getMap (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lcom/mojang/serialization/MapLike<Lnet/minecraft/nbt/Tag;>;>; -
 method public createMap (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lcom/mojang/datafixers/util/Pair<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;>;>;)Lnet/minecraft/nbt/Tag; -
 method public getStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;>; -
 method public getList (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/function/Consumer<Ljava/util/function/Consumer<Lnet/minecraft/nbt/Tag;>;>;>; -
 method public getByteBuffer (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/nio/ByteBuffer;>; -
 method public createByteList (Ljava/nio/ByteBuffer;)Lnet/minecraft/nbt/Tag; - -
 method public getIntStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/IntStream;>; -
 method public createIntList (Ljava/util/stream/IntStream;)Lnet/minecraft/nbt/Tag; - -
 method public getLongStream (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Ljava/util/stream/LongStream;>; -
 method public createLongList (Ljava/util/stream/LongStream;)Lnet/minecraft/nbt/Tag; - -
 method public createList (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/Tag; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/Tag; -
 method public remove (Lnet/minecraft/nbt/Tag;Ljava/lang/String;)Lnet/minecraft/nbt/Tag; - -
 method public toString ()Ljava/lang/String; - -
 method public mapBuilder ()Lcom/mojang/serialization/RecordBuilder; ()Lcom/mojang/serialization/RecordBuilder<Lnet/minecraft/nbt/Tag;>; -
in 529
class net/minecraft/nbt/NbtOps$ByteListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> (B)V - -
 method public <init> ([B)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 210
class net/minecraft/nbt/NbtOps$ByteListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> (B)V - -
 method public <init> ([B)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 165
class net/minecraft/nbt/NbtOps$ByteListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> ([B)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 437
class net/minecraft/nbt/NbtOps$ByteListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> (B)V - -
 method public <init> ([B)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 181
class net/minecraft/nbt/NbtOps$ByteListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> (B)V - -
 method public <init> ([B)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 166
class net/minecraft/nbt/NbtOps$ByteListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> ([B)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 165
class net/minecraft/nbt/NbtOps$GenericListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lit/unimi/dsi/fastutil/ints/IntArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/bytes/ByteArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongArrayList;)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 166
class net/minecraft/nbt/NbtOps$GenericListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lit/unimi/dsi/fastutil/ints/IntArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/bytes/ByteArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongArrayList;)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 529
class net/minecraft/nbt/NbtOps$HeterogenousListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> (Lit/unimi/dsi/fastutil/ints/IntArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/bytes/ByteArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongArrayList;)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 210
class net/minecraft/nbt/NbtOps$HeterogenousListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> (Lit/unimi/dsi/fastutil/ints/IntArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/bytes/ByteArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongArrayList;)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 437
class net/minecraft/nbt/NbtOps$HeterogenousListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> (Lit/unimi/dsi/fastutil/ints/IntArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/bytes/ByteArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongArrayList;)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 181
class net/minecraft/nbt/NbtOps$HeterogenousListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/nbt/Tag;>;)V -
 method public <init> (Lit/unimi/dsi/fastutil/ints/IntArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/bytes/ByteArrayList;)V - -
 method public <init> (Lit/unimi/dsi/fastutil/longs/LongArrayList;)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 529
class net/minecraft/nbt/NbtOps$HomogenousListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 210
class net/minecraft/nbt/NbtOps$HomogenousListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 437
class net/minecraft/nbt/NbtOps$HomogenousListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 181
class net/minecraft/nbt/NbtOps$HomogenousListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 529
class net/minecraft/nbt/NbtOps$InitialListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector static
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps$InitialListCollector; -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 210
class net/minecraft/nbt/NbtOps$InitialListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector static
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector static
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps$InitialListCollector; -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 437
class net/minecraft/nbt/NbtOps$InitialListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector private,static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector private,static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector private,static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector static
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps$InitialListCollector; -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 181
class net/minecraft/nbt/NbtOps$InitialListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$ByteListCollector net/minecraft/nbt/NbtOps ByteListCollector private,static
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector private,static
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector private,static
 inner net/minecraft/nbt/NbtOps$HomogenousListCollector net/minecraft/nbt/NbtOps HomogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$InitialListCollector net/minecraft/nbt/NbtOps InitialListCollector static
 field public,static,final INSTANCE Lnet/minecraft/nbt/NbtOps$InitialListCollector; -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 529
class net/minecraft/nbt/NbtOps$IntListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> (I)V - -
 method public <init> ([I)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 210
class net/minecraft/nbt/NbtOps$IntListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> (I)V - -
 method public <init> ([I)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 165
class net/minecraft/nbt/NbtOps$IntListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> ([I)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 437
class net/minecraft/nbt/NbtOps$IntListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> (I)V - -
 method public <init> ([I)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 181
class net/minecraft/nbt/NbtOps$IntListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> (I)V - -
 method public <init> ([I)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 166
class net/minecraft/nbt/NbtOps$IntListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$IntListCollector net/minecraft/nbt/NbtOps IntListCollector static
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> ([I)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 228
class net/minecraft/nbt/NbtOps$ListCollector 61 interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public acceptAll (Ljava/lang/Iterable;)Lnet/minecraft/nbt/NbtOps$ListCollector; (Ljava/lang/Iterable<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/NbtOps$ListCollector; -
 method public acceptAll (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/NbtOps$ListCollector; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/NbtOps$ListCollector; -
 method public,abstract result ()Lnet/minecraft/nbt/Tag; - -
in 62
class net/minecraft/nbt/NbtOps$ListCollector 65 interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public acceptAll (Ljava/lang/Iterable;)Lnet/minecraft/nbt/NbtOps$ListCollector; (Ljava/lang/Iterable<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/NbtOps$ListCollector; -
 method public acceptAll (Ljava/util/stream/Stream;)Lnet/minecraft/nbt/NbtOps$ListCollector; (Ljava/util/stream/Stream<Lnet/minecraft/nbt/Tag;>;)Lnet/minecraft/nbt/NbtOps$ListCollector; -
 method public,abstract result ()Lnet/minecraft/nbt/Tag; - -
in 529
class net/minecraft/nbt/NbtOps$LongListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> (J)V - -
 method public <init> ([J)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 210
class net/minecraft/nbt/NbtOps$LongListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> (J)V - -
 method public <init> ([J)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 165
class net/minecraft/nbt/NbtOps$LongListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector static,interface,abstract
 method public <init> ([J)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 437
class net/minecraft/nbt/NbtOps$LongListCollector 61 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> (J)V - -
 method public <init> ([J)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 181
class net/minecraft/nbt/NbtOps$LongListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$HeterogenousListCollector net/minecraft/nbt/NbtOps HeterogenousListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> (J)V - -
 method public <init> ([J)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 166
class net/minecraft/nbt/NbtOps$LongListCollector 65 super java/lang/Object net/minecraft/nbt/NbtOps$ListCollector -
 inner net/minecraft/nbt/NbtOps$LongListCollector net/minecraft/nbt/NbtOps LongListCollector static
 inner net/minecraft/nbt/NbtOps$GenericListCollector net/minecraft/nbt/NbtOps GenericListCollector private,static
 inner net/minecraft/nbt/NbtOps$ListCollector net/minecraft/nbt/NbtOps ListCollector private,static,interface,abstract
 method public <init> ([J)V - -
 method public accept (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/NbtOps$ListCollector; - -
 method public result ()Lnet/minecraft/nbt/Tag; - -
in 92
class net/minecraft/nbt/NbtOps$NbtRecordBuilder 52 super com/mojang/serialization/RecordBuilder$AbstractStringBuilder - Lcom/mojang/serialization/RecordBuilder$AbstractStringBuilder<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/serialization/RecordBuilder$AbstractStringBuilder com/mojang/serialization/RecordBuilder AbstractStringBuilder public,static,abstract
 method protected <init> (Lnet/minecraft/nbt/NbtOps;)V - -
 method protected initBuilder ()Lnet/minecraft/nbt/CompoundTag; - -
 method protected append (Ljava/lang/String;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected build (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
in 86
class net/minecraft/nbt/NbtOps$NbtRecordBuilder 60 super com/mojang/serialization/RecordBuilder$AbstractStringBuilder - Lcom/mojang/serialization/RecordBuilder$AbstractStringBuilder<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner com/mojang/serialization/RecordBuilder$AbstractStringBuilder com/mojang/serialization/RecordBuilder AbstractStringBuilder public,static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/nbt/NbtOps;)V - -
 method protected initBuilder ()Lnet/minecraft/nbt/CompoundTag; - -
 method protected append (Ljava/lang/String;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected build (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
in 99
class net/minecraft/nbt/NbtOps$NbtRecordBuilder 61 super com/mojang/serialization/RecordBuilder$AbstractStringBuilder - Lcom/mojang/serialization/RecordBuilder$AbstractStringBuilder<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;>;
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner com/mojang/serialization/RecordBuilder$AbstractStringBuilder com/mojang/serialization/RecordBuilder AbstractStringBuilder public,static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/nbt/NbtOps;)V - -
 method protected initBuilder ()Lnet/minecraft/nbt/CompoundTag; - -
 method protected append (Ljava/lang/String;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected build (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
in 62
class net/minecraft/nbt/NbtOps$NbtRecordBuilder 65 super com/mojang/serialization/RecordBuilder$AbstractStringBuilder - Lcom/mojang/serialization/RecordBuilder$AbstractStringBuilder<Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;>;
 inner com/mojang/serialization/RecordBuilder$AbstractStringBuilder com/mojang/serialization/RecordBuilder AbstractStringBuilder public,static,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/NbtOps$NbtRecordBuilder net/minecraft/nbt/NbtOps NbtRecordBuilder -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Lnet/minecraft/nbt/NbtOps;)V - -
 method protected initBuilder ()Lnet/minecraft/nbt/CompoundTag; - -
 method protected append (Ljava/lang/String;Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method protected build (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult; (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/nbt/Tag;)Lcom/mojang/serialization/DataResult<Lnet/minecraft/nbt/Tag;>; -
in 209
class net/minecraft/nbt/NbtUtils 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 method public,static readGameProfile (Lnet/minecraft/nbt/CompoundTag;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/CompoundTag;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUIDTag (Ljava/util/UUID;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static loadUUIDTag (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/core/BlockPos; - -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static readBlockState (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lcom/mojang/datafixers/DSL$TypeReference;Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lcom/mojang/datafixers/DSL$TypeReference;Lnet/minecraft/nbt/CompoundTag;II)Lnet/minecraft/nbt/CompoundTag; - -
in 224
class net/minecraft/nbt/NbtUtils 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 method public,static readGameProfile (Lnet/minecraft/nbt/CompoundTag;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/CompoundTag;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUIDTag (Ljava/util/UUID;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static loadUUIDTag (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/core/BlockPos; - -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static readBlockState (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;II)Lnet/minecraft/nbt/CompoundTag; - -
in 92
class net/minecraft/nbt/NbtUtils 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static readGameProfile (Lnet/minecraft/nbt/CompoundTag;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/CompoundTag;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUID (Ljava/util/UUID;)Lnet/minecraft/nbt/IntArrayTag; - -
 method public,static loadUUID (Lnet/minecraft/nbt/Tag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/core/BlockPos; - -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static readBlockState (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;II)Lnet/minecraft/nbt/CompoundTag; - -
in 86
class net/minecraft/nbt/NbtUtils 60 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static readGameProfile (Lnet/minecraft/nbt/CompoundTag;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/CompoundTag;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUID (Ljava/util/UUID;)Lnet/minecraft/nbt/IntArrayTag; - -
 method public,static loadUUID (Lnet/minecraft/nbt/Tag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/core/BlockPos; - -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static readBlockState (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;II)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 36
class net/minecraft/nbt/NbtUtils 61 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static readGameProfile (Lnet/minecraft/nbt/CompoundTag;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/CompoundTag;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUID (Ljava/util/UUID;)Lnet/minecraft/nbt/IntArrayTag; - -
 method public,static loadUUID (Lnet/minecraft/nbt/Tag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/core/BlockPos; - -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static readBlockState (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;II)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 96
class net/minecraft/nbt/NbtUtils 61 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static readGameProfile (Lnet/minecraft/nbt/CompoundTag;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/CompoundTag;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUID (Ljava/util/UUID;)Lnet/minecraft/nbt/IntArrayTag; - -
 method public,static loadUUID (Lnet/minecraft/nbt/Tag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/core/BlockPos; - -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static readBlockState (Lnet/minecraft/core/HolderGetter;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; (Lnet/minecraft/core/HolderGetter<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static update (Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/util/datafix/DataFixTypes;Lnet/minecraft/nbt/CompoundTag;II)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 95
class net/minecraft/nbt/NbtUtils 61 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static readGameProfile (Lnet/minecraft/nbt/CompoundTag;)Lcom/mojang/authlib/GameProfile; - -
 method public,static writeGameProfile (Lnet/minecraft/nbt/CompoundTag;Lcom/mojang/authlib/GameProfile;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUID (Ljava/util/UUID;)Lnet/minecraft/nbt/IntArrayTag; - -
 method public,static loadUUID (Lnet/minecraft/nbt/Tag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/core/BlockPos; - -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static readBlockState (Lnet/minecraft/core/HolderGetter;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; (Lnet/minecraft/core/HolderGetter<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static addCurrentDataVersion (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addDataVersion (Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static getDataVersion (Lnet/minecraft/nbt/CompoundTag;I)I - -
in 135
class net/minecraft/nbt/NbtUtils 65 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static createUUID (Ljava/util/UUID;)Lnet/minecraft/nbt/IntArrayTag; - -
 method public,static loadUUID (Lnet/minecraft/nbt/Tag;)Ljava/util/UUID; - -
 method public,static readBlockPos (Lnet/minecraft/nbt/CompoundTag;Ljava/lang/String;)Ljava/util/Optional; (Lnet/minecraft/nbt/CompoundTag;Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static writeBlockPos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/nbt/Tag; - -
 method public,static readBlockState (Lnet/minecraft/core/HolderGetter;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; (Lnet/minecraft/core/HolderGetter<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static addCurrentDataVersion (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addDataVersion (Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static getDataVersion (Lnet/minecraft/nbt/CompoundTag;I)I - -
in 108
class net/minecraft/nbt/NbtUtils 65 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static readBlockState (Lnet/minecraft/core/HolderGetter;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; (Lnet/minecraft/core/HolderGetter<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static addCurrentDataVersion (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addDataVersion (Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static getDataVersion (Lnet/minecraft/nbt/CompoundTag;I)I - -
 method public,static getDataVersion (Lcom/mojang/serialization/Dynamic;I)I (Lcom/mojang/serialization/Dynamic<*>;I)I -
in 109
class net/minecraft/nbt/NbtUtils 65 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static readBlockState (Lnet/minecraft/core/HolderGetter;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; (Lnet/minecraft/core/HolderGetter<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static addCurrentDataVersion (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addDataVersion (Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addCurrentDataVersion (Lnet/minecraft/world/level/storage/ValueOutput;)V - -
 method public,static addDataVersion (Lnet/minecraft/world/level/storage/ValueOutput;I)V - -
 method public,static getDataVersion (Lnet/minecraft/nbt/CompoundTag;I)I - -
 method public,static getDataVersion (Lcom/mojang/serialization/Dynamic;I)I (Lcom/mojang/serialization/Dynamic<*>;I)I -
in 104
class net/minecraft/nbt/NbtUtils 65 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static readBlockState (Lnet/minecraft/core/HolderGetter;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; (Lnet/minecraft/core/HolderGetter<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static addCurrentDataVersion (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addDataVersion (Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addCurrentDataVersion (Lcom/mojang/serialization/Dynamic;)Lcom/mojang/serialization/Dynamic; (Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>; -
 method public,static addDataVersion (Lcom/mojang/serialization/Dynamic;I)Lcom/mojang/serialization/Dynamic; (Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>;I)Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>; -
 method public,static addCurrentDataVersion (Lnet/minecraft/world/level/storage/ValueOutput;)V - -
 method public,static addDataVersion (Lnet/minecraft/world/level/storage/ValueOutput;I)V - -
 method public,static getDataVersion (Lnet/minecraft/nbt/CompoundTag;I)I - -
 method public,static getDataVersion (Lcom/mojang/serialization/Dynamic;I)I (Lcom/mojang/serialization/Dynamic<*>;I)I -
in 3
class net/minecraft/nbt/NbtUtils 65 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SNBT_DATA_TAG Ljava/lang/String; - "data"
 method public,static compareNbt (Lnet/minecraft/nbt/Tag;Lnet/minecraft/nbt/Tag;Z)Z - -
 method public,static readBlockState (Lnet/minecraft/core/HolderGetter;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; (Lnet/minecraft/core/HolderGetter<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/block/state/BlockState; -
 method public,static writeBlockState (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static writeFluidState (Lnet/minecraft/world/level/material/FluidState;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public,static prettyPrint (Lnet/minecraft/nbt/Tag;Z)Ljava/lang/String; - -
 method public,static prettyPrint (Ljava/lang/StringBuilder;Lnet/minecraft/nbt/Tag;IZ)Ljava/lang/StringBuilder; - -
 method public,static toPrettyComponent (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public,static structureToSnbt (Lnet/minecraft/nbt/CompoundTag;)Ljava/lang/String; - -
 method public,static snbtToStructure (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static addCurrentDataVersion (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addDataVersion (Lnet/minecraft/nbt/CompoundTag;I)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static addCurrentDataVersion (Lcom/mojang/serialization/Dynamic;)Lcom/mojang/serialization/Dynamic; (Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>;)Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>; -
 method public,static addDataVersion (Lcom/mojang/serialization/Dynamic;I)Lcom/mojang/serialization/Dynamic; (Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>;I)Lcom/mojang/serialization/Dynamic<Lnet/minecraft/nbt/Tag;>; -
 method public,static addCurrentDataVersion (Lnet/minecraft/world/level/storage/ValueOutput;)V - -
 method public,static addDataVersion (Lnet/minecraft/world/level/storage/ValueOutput;I)V - -
 method public,static getDataVersion (Lnet/minecraft/nbt/CompoundTag;)I - -
 method public,static getDataVersion (Lnet/minecraft/nbt/CompoundTag;I)I - -
 method public,static getDataVersion (Lcom/mojang/serialization/Dynamic;I)I (Lcom/mojang/serialization/Dynamic<*>;I)I -
in 98
class net/minecraft/nbt/NumericTag 52 public,super,abstract java/lang/Object net/minecraft/nbt/Tag -
 method protected <init> ()V - -
 method public,abstract getAsLong ()J - -
 method public,abstract getAsInt ()I - -
 method public,abstract getAsShort ()S - -
 method public,abstract getAsByte ()B - -
 method public,abstract getAsDouble ()D - -
 method public,abstract getAsFloat ()F - -
 method public,abstract getAsNumber ()Ljava/lang/Number; - -
in 86
class net/minecraft/nbt/NumericTag 60 public,super,abstract java/lang/Object net/minecraft/nbt/Tag -
 method protected <init> ()V - -
 method public,abstract getAsLong ()J - -
 method public,abstract getAsInt ()I - -
 method public,abstract getAsShort ()S - -
 method public,abstract getAsByte ()B - -
 method public,abstract getAsDouble ()D - -
 method public,abstract getAsFloat ()F - -
 method public,abstract getAsNumber ()Ljava/lang/Number; - -
 method public toString ()Ljava/lang/String; - -
in 99
class net/minecraft/nbt/NumericTag 61 public,super,abstract java/lang/Object net/minecraft/nbt/Tag -
 method protected <init> ()V - -
 method public,abstract getAsLong ()J - -
 method public,abstract getAsInt ()I - -
 method public,abstract getAsShort ()S - -
 method public,abstract getAsByte ()B - -
 method public,abstract getAsDouble ()D - -
 method public,abstract getAsFloat ()F - -
 method public,abstract getAsNumber ()Ljava/lang/Number; - -
 method public toString ()Ljava/lang/String; - -
in 135
class net/minecraft/nbt/NumericTag 65 public,super,abstract java/lang/Object net/minecraft/nbt/Tag -
 method protected <init> ()V - -
 method public,abstract getAsLong ()J - -
 method public,abstract getAsInt ()I - -
 method public,abstract getAsShort ()S - -
 method public,abstract getAsByte ()B - -
 method public,abstract getAsDouble ()D - -
 method public,abstract getAsFloat ()F - -
 method public,abstract getAsNumber ()Ljava/lang/Number; - -
 method public toString ()Ljava/lang/String; - -
in 102
class net/minecraft/nbt/NumericTag 65 public,interface,abstract java/lang/Object net/minecraft/nbt/PrimitiveTag -
 method public,abstract byteValue ()B - -
 method public,abstract shortValue ()S - -
 method public,abstract intValue ()I - -
 method public,abstract longValue ()J - -
 method public,abstract floatValue ()F - -
 method public,abstract doubleValue ()D - -
 method public,abstract box ()Ljava/lang/Number; - -
 method public asNumber ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Number;>; -
 method public asByte ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Byte;>; -
 method public asShort ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Short;>; -
 method public asInt ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public asLong ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Long;>; -
 method public asFloat ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Float;>; -
 method public asDouble ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Double;>; -
 method public asBoolean ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Boolean;>; -
in 102
class net/minecraft/nbt/PrimitiveTag 65 public,interface,abstract java/lang/Object net/minecraft/nbt/Tag -
 method public copy ()Lnet/minecraft/nbt/Tag; - -
in 122
class net/minecraft/nbt/ReportedNbtException 61 public,super net/minecraft/ReportedException - -
 method public <init> (Lnet/minecraft/CrashReport;)V - -
in 62
class net/minecraft/nbt/ReportedNbtException 65 public,super net/minecraft/ReportedException - -
 method public <init> (Lnet/minecraft/CrashReport;)V - -
in 209
class net/minecraft/nbt/ShortTag 52 public,super hl - -
 method public <init> ()V - -
 method public <init> (S)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 120
class net/minecraft/nbt/ShortTag 52 public,super net/minecraft/nbt/NumericTag - -
 method public <init> ()V - -
 method public <init> (S)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 182
class net/minecraft/nbt/ShortTag 52 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 110
class net/minecraft/nbt/ShortTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 46
class net/minecraft/nbt/ShortTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 529
class net/minecraft/nbt/ShortTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 210
class net/minecraft/nbt/ShortTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 165
class net/minecraft/nbt/ShortTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,deprecated <init> (S)V - -
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()S - -
in 114
class net/minecraft/nbt/ShortTag 60 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache private,static
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
in 60
class net/minecraft/nbt/ShortTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 437
class net/minecraft/nbt/ShortTag 61 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 181
class net/minecraft/nbt/ShortTag 65 public,super net/minecraft/nbt/NumericTag - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public getAsLong ()J - -
 method public getAsInt ()I - -
 method public getAsShort ()S - -
 method public getAsByte ()B - -
 method public getAsDouble ()D - -
 method public getAsFloat ()F - -
 method public getAsNumber ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 166
class net/minecraft/nbt/ShortTag 65 public,final,super java/lang/Record net/minecraft/nbt/NumericTag -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache private,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>;
 method public,deprecated <init> (S)V - -
 method public,static valueOf (S)Lnet/minecraft/nbt/ShortTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/ShortTag;>; -
 method public copy ()Lnet/minecraft/nbt/ShortTag; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public longValue ()J - -
 method public intValue ()I - -
 method public shortValue ()S - -
 method public byteValue ()B - -
 method public doubleValue ()D - -
 method public floatValue ()F - -
 method public box ()Ljava/lang/Number; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()S - -
in 182
class net/minecraft/nbt/ShortTag$Cache 52 super java/lang/Object - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
in 86
class net/minecraft/nbt/ShortTag$Cache 60 super java/lang/Object - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
in 99
class net/minecraft/nbt/ShortTag$Cache 61 super java/lang/Object - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
in 62
class net/minecraft/nbt/ShortTag$Cache 65 super java/lang/Object - -
 inner net/minecraft/nbt/ShortTag$Cache net/minecraft/nbt/ShortTag Cache static
in 165
class net/minecraft/nbt/SnbtGrammar 65 public,super java/lang/Object - -
 inner net/minecraft/nbt/SnbtGrammar$Sign net/minecraft/nbt/SnbtGrammar Sign static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$Signed net/minecraft/nbt/SnbtGrammar Signed static,final
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix static,final,enum
 inner net/minecraft/util/parsing/packrat/Rule$SimpleRuleAction net/minecraft/util/parsing/packrat/Rule SimpleRuleAction public,static,interface,abstract
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix static,final
 inner net/minecraft/nbt/SnbtGrammar$SignedPrefix net/minecraft/nbt/SnbtGrammar SignedPrefix static,final,enum
 inner net/minecraft/util/parsing/packrat/Rule$RuleAction net/minecraft/util/parsing/packrat/Rule RuleAction public,static,interface,abstract
 inner net/minecraft/nbt/SnbtGrammar$SimpleHexLiteralParseRule net/minecraft/nbt/SnbtGrammar SimpleHexLiteralParseRule static
 inner net/minecraft/nbt/SnbtGrammar$ArrayPrefix net/minecraft/nbt/SnbtGrammar ArrayPrefix static,abstract,enum
 inner net/minecraft/util/parsing/packrat/commands/StringReaderTerms$TerminalCharacters net/minecraft/util/parsing/packrat/commands/StringReaderTerms TerminalCharacters public,static,abstract
 inner net/minecraft/nbt/SnbtGrammar$IntegerLiteral net/minecraft/nbt/SnbtGrammar IntegerLiteral static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/SnbtOperations$BuiltinKey net/minecraft/nbt/SnbtOperations BuiltinKey public,static,final
 inner net/minecraft/nbt/SnbtOperations$BuiltinOperation net/minecraft/nbt/SnbtOperations BuiltinOperation public,static,interface,abstract
 inner net/minecraft/nbt/SnbtGrammar$Base net/minecraft/nbt/SnbtGrammar Base static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static escapeControlCharacters (C)Ljava/lang/String; - -
 method public,static createParser (Lcom/mojang/serialization/DynamicOps;)Lnet/minecraft/util/parsing/packrat/commands/Grammar; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;)Lnet/minecraft/util/parsing/packrat/commands/Grammar<TT;>; -
in 166
class net/minecraft/nbt/SnbtGrammar 65 public,super java/lang/Object - -
 inner net/minecraft/nbt/SnbtGrammar$Sign net/minecraft/nbt/SnbtGrammar Sign private,static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$Signed net/minecraft/nbt/SnbtGrammar Signed private,static,final
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix private,static,final,enum
 inner net/minecraft/util/parsing/packrat/Rule$SimpleRuleAction net/minecraft/util/parsing/packrat/Rule SimpleRuleAction public,static,interface,abstract
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix private,static,final
 inner net/minecraft/nbt/SnbtGrammar$SignedPrefix net/minecraft/nbt/SnbtGrammar SignedPrefix private,static,final,enum
 inner net/minecraft/util/parsing/packrat/Rule$RuleAction net/minecraft/util/parsing/packrat/Rule RuleAction public,static,interface,abstract
 inner net/minecraft/nbt/SnbtGrammar$SimpleHexLiteralParseRule net/minecraft/nbt/SnbtGrammar SimpleHexLiteralParseRule private,static
 inner net/minecraft/nbt/SnbtGrammar$ArrayPrefix net/minecraft/nbt/SnbtGrammar ArrayPrefix private,static,abstract,enum
 inner net/minecraft/util/parsing/packrat/commands/StringReaderTerms$TerminalCharacters net/minecraft/util/parsing/packrat/commands/StringReaderTerms TerminalCharacters public,static,abstract
 inner net/minecraft/nbt/SnbtGrammar$IntegerLiteral net/minecraft/nbt/SnbtGrammar IntegerLiteral private,static,final
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/nbt/SnbtOperations$BuiltinKey net/minecraft/nbt/SnbtOperations BuiltinKey public,static,final
 inner net/minecraft/nbt/SnbtOperations$BuiltinOperation net/minecraft/nbt/SnbtOperations BuiltinOperation public,static,interface,abstract
 inner net/minecraft/nbt/SnbtGrammar$Base net/minecraft/nbt/SnbtGrammar Base private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static escapeControlCharacters (C)Ljava/lang/String; - -
 method public,static createParser (Lcom/mojang/serialization/DynamicOps;)Lnet/minecraft/util/parsing/packrat/commands/Grammar; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;)Lnet/minecraft/util/parsing/packrat/commands/Grammar<TT;>; -
in 165
class net/minecraft/nbt/SnbtGrammar$ArrayPrefix 65 super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix;>;
 inner net/minecraft/nbt/SnbtGrammar$ArrayPrefix net/minecraft/nbt/SnbtGrammar ArrayPrefix static,abstract,enum
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$IntegerLiteral net/minecraft/nbt/SnbtGrammar IntegerLiteral static,final
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix static,final
 field public,static,final,enum BYTE Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; -
 field public,static,final,enum INT Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; -
 field public,static,final,enum LONG Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; -
 method public,static values ()[Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; - -
 method public isAllowed (Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix;)Z - -
 method public,abstract create (Lcom/mojang/serialization/DynamicOps;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;)TT; -
 method public,abstract create (Lcom/mojang/serialization/DynamicOps;Ljava/util/List;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Ljava/util/List<Lnet/minecraft/nbt/SnbtGrammar$IntegerLiteral;>;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)TT; -
 method protected buildNumber (Lnet/minecraft/nbt/SnbtGrammar$IntegerLiteral;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Number; (Lnet/minecraft/nbt/SnbtGrammar$IntegerLiteral;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)Ljava/lang/Number; -
in 166
class net/minecraft/nbt/SnbtGrammar$ArrayPrefix 65 super,abstract,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix;>;
 inner net/minecraft/nbt/SnbtGrammar$ArrayPrefix net/minecraft/nbt/SnbtGrammar ArrayPrefix static,abstract,enum
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix private,static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$IntegerLiteral net/minecraft/nbt/SnbtGrammar IntegerLiteral private,static,final
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix private,static,final
 field public,static,final,enum BYTE Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; -
 field public,static,final,enum INT Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; -
 field public,static,final,enum LONG Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; -
 method public,static values ()[Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/SnbtGrammar$ArrayPrefix; - -
 method public isAllowed (Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix;)Z - -
 method public,abstract create (Lcom/mojang/serialization/DynamicOps;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;)TT; -
 method public,abstract create (Lcom/mojang/serialization/DynamicOps;Ljava/util/List;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Ljava/util/List<Lnet/minecraft/nbt/SnbtGrammar$IntegerLiteral;>;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)TT; -
 method protected buildNumber (Lnet/minecraft/nbt/SnbtGrammar$IntegerLiteral;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Number; (Lnet/minecraft/nbt/SnbtGrammar$IntegerLiteral;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)Ljava/lang/Number; -
in 102
class net/minecraft/nbt/SnbtGrammar$Base 65 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/SnbtGrammar$Base;>;
 inner net/minecraft/nbt/SnbtGrammar$Base net/minecraft/nbt/SnbtGrammar Base static,final,enum
 field public,static,final,enum BINARY Lnet/minecraft/nbt/SnbtGrammar$Base; -
 field public,static,final,enum DECIMAL Lnet/minecraft/nbt/SnbtGrammar$Base; -
 field public,static,final,enum HEX Lnet/minecraft/nbt/SnbtGrammar$Base; -
 method public,static values ()[Lnet/minecraft/nbt/SnbtGrammar$Base; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/SnbtGrammar$Base; - -
in 165
class net/minecraft/nbt/SnbtGrammar$IntegerLiteral 65 final,super java/lang/Record - -
 inner net/minecraft/nbt/SnbtGrammar$IntegerLiteral net/minecraft/nbt/SnbtGrammar IntegerLiteral static,final
 inner net/minecraft/nbt/SnbtGrammar$Sign net/minecraft/nbt/SnbtGrammar Sign static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$Base net/minecraft/nbt/SnbtGrammar Base static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix static,final
 inner net/minecraft/nbt/SnbtGrammar$SignedPrefix net/minecraft/nbt/SnbtGrammar SignedPrefix static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)TT; -
 method public create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)TT; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public sign ()Lnet/minecraft/nbt/SnbtGrammar$Sign; - -
 method public base ()Lnet/minecraft/nbt/SnbtGrammar$Base; - -
 method public digits ()Ljava/lang/String; - -
 method public suffix ()Lnet/minecraft/nbt/SnbtGrammar$IntegerSuffix; - -
in 166
class net/minecraft/nbt/SnbtGrammar$IntegerLiteral 65 final,super java/lang/Record - -
 inner net/minecraft/nbt/SnbtGrammar$IntegerLiteral net/minecraft/nbt/SnbtGrammar IntegerLiteral static,final
 inner net/minecraft/nbt/SnbtGrammar$Sign net/minecraft/nbt/SnbtGrammar Sign private,static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$Base net/minecraft/nbt/SnbtGrammar Base private,static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix private,static,final
 inner net/minecraft/nbt/SnbtGrammar$SignedPrefix net/minecraft/nbt/SnbtGrammar SignedPrefix private,static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)TT; -
 method public create (Lcom/mojang/serialization/DynamicOps;Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix;Lnet/minecraft/util/parsing/packrat/ParseState<*>;)TT; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public sign ()Lnet/minecraft/nbt/SnbtGrammar$Sign; - -
 method public base ()Lnet/minecraft/nbt/SnbtGrammar$Base; - -
 method public digits ()Ljava/lang/String; - -
 method public suffix ()Lnet/minecraft/nbt/SnbtGrammar$IntegerSuffix; - -
in 165
class net/minecraft/nbt/SnbtGrammar$IntegerSuffix 65 final,super java/lang/Record - -
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix static,final
 inner net/minecraft/nbt/SnbtGrammar$SignedPrefix net/minecraft/nbt/SnbtGrammar SignedPrefix static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final EMPTY Lnet/minecraft/nbt/SnbtGrammar$IntegerSuffix; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public signed ()Lnet/minecraft/nbt/SnbtGrammar$SignedPrefix; - -
 method public type ()Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; - -
in 166
class net/minecraft/nbt/SnbtGrammar$IntegerSuffix 65 final,super java/lang/Record - -
 inner net/minecraft/nbt/SnbtGrammar$IntegerSuffix net/minecraft/nbt/SnbtGrammar IntegerSuffix static,final
 inner net/minecraft/nbt/SnbtGrammar$SignedPrefix net/minecraft/nbt/SnbtGrammar SignedPrefix private,static,final,enum
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final EMPTY Lnet/minecraft/nbt/SnbtGrammar$IntegerSuffix; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public signed ()Lnet/minecraft/nbt/SnbtGrammar$SignedPrefix; - -
 method public type ()Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; - -
in 102
class net/minecraft/nbt/SnbtGrammar$Sign 65 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/SnbtGrammar$Sign;>;
 inner net/minecraft/nbt/SnbtGrammar$Sign net/minecraft/nbt/SnbtGrammar Sign static,final,enum
 field public,static,final,enum PLUS Lnet/minecraft/nbt/SnbtGrammar$Sign; -
 field public,static,final,enum MINUS Lnet/minecraft/nbt/SnbtGrammar$Sign; -
 method public,static values ()[Lnet/minecraft/nbt/SnbtGrammar$Sign; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/SnbtGrammar$Sign; - -
 method public append (Ljava/lang/StringBuilder;)V - -
in 165
class net/minecraft/nbt/SnbtGrammar$Signed 65 final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/nbt/SnbtGrammar$Signed net/minecraft/nbt/SnbtGrammar Signed static,final
 inner net/minecraft/nbt/SnbtGrammar$Sign net/minecraft/nbt/SnbtGrammar Sign static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public sign ()Lnet/minecraft/nbt/SnbtGrammar$Sign; - -
 method public value ()Ljava/lang/Object; ()TT; -
in 166
class net/minecraft/nbt/SnbtGrammar$Signed 65 final,super java/lang/Record - <T:Ljava/lang/Object;>Ljava/lang/Record;
 inner net/minecraft/nbt/SnbtGrammar$Signed net/minecraft/nbt/SnbtGrammar Signed static,final
 inner net/minecraft/nbt/SnbtGrammar$Sign net/minecraft/nbt/SnbtGrammar Sign private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public sign ()Lnet/minecraft/nbt/SnbtGrammar$Sign; - -
 method public value ()Ljava/lang/Object; ()TT; -
in 102
class net/minecraft/nbt/SnbtGrammar$SignedPrefix 65 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/SnbtGrammar$SignedPrefix;>;
 inner net/minecraft/nbt/SnbtGrammar$SignedPrefix net/minecraft/nbt/SnbtGrammar SignedPrefix static,final,enum
 field public,static,final,enum SIGNED Lnet/minecraft/nbt/SnbtGrammar$SignedPrefix; -
 field public,static,final,enum UNSIGNED Lnet/minecraft/nbt/SnbtGrammar$SignedPrefix; -
 method public,static values ()[Lnet/minecraft/nbt/SnbtGrammar$SignedPrefix; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/SnbtGrammar$SignedPrefix; - -
in 102
class net/minecraft/nbt/SnbtGrammar$SimpleHexLiteralParseRule 65 super net/minecraft/util/parsing/packrat/commands/GreedyPredicateParseRule - -
 inner net/minecraft/nbt/SnbtGrammar$SimpleHexLiteralParseRule net/minecraft/nbt/SnbtGrammar SimpleHexLiteralParseRule static
 method public <init> (I)V - -
 method protected isAccepted (C)Z - -
in 102
class net/minecraft/nbt/SnbtGrammar$TypeSuffix 65 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix;>;
 inner net/minecraft/nbt/SnbtGrammar$TypeSuffix net/minecraft/nbt/SnbtGrammar TypeSuffix static,final,enum
 field public,static,final,enum FLOAT Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; -
 field public,static,final,enum DOUBLE Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; -
 field public,static,final,enum BYTE Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; -
 field public,static,final,enum SHORT Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; -
 field public,static,final,enum INT Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; -
 field public,static,final,enum LONG Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; -
 method public,static values ()[Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/SnbtGrammar$TypeSuffix; - -
in 102
class net/minecraft/nbt/SnbtOperations 65 public,super java/lang/Object - -
 inner net/minecraft/nbt/SnbtOperations$BuiltinKey net/minecraft/nbt/SnbtOperations BuiltinKey public,static,final
 inner net/minecraft/nbt/SnbtOperations$BuiltinOperation net/minecraft/nbt/SnbtOperations BuiltinOperation public,static,interface,abstract
 field public,static,final BUILTIN_TRUE Ljava/lang/String; - "true"
 field public,static,final BUILTIN_FALSE Ljava/lang/String; - "false"
 field public,static,final BUILTIN_OPERATIONS Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/nbt/SnbtOperations$BuiltinKey;Lnet/minecraft/nbt/SnbtOperations$BuiltinOperation;>;
 field public,static,final BUILTIN_IDS Lnet/minecraft/util/parsing/packrat/SuggestionSupplier; Lnet/minecraft/util/parsing/packrat/SuggestionSupplier<Lcom/mojang/brigadier/StringReader;>;
 method public <init> ()V - -
in 102
class net/minecraft/nbt/SnbtOperations$BuiltinKey 65 public,final,super java/lang/Record - -
 inner net/minecraft/nbt/SnbtOperations$BuiltinKey net/minecraft/nbt/SnbtOperations BuiltinKey public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;I)V - -
 method public toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public id ()Ljava/lang/String; - -
 method public argCount ()I - -
in 102
class net/minecraft/nbt/SnbtOperations$BuiltinOperation 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/SnbtOperations$BuiltinOperation net/minecraft/nbt/SnbtOperations BuiltinOperation public,static,interface,abstract
 method public,abstract run (Lcom/mojang/serialization/DynamicOps;Ljava/util/List;Lnet/minecraft/util/parsing/packrat/ParseState;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;Ljava/util/List<TT;>;Lnet/minecraft/util/parsing/packrat/ParseState<Lcom/mojang/brigadier/StringReader;>;)TT; -
in 86
class net/minecraft/nbt/SnbtPrinterTagVisitor 60 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;ILjava/util/List;)V (Ljava/lang/String;ILjava/util/List<Ljava/lang/String;>;)V -
 method public visit (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected getKeys (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/List; (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/List<Ljava/lang/String;>; -
 method public pathString ()Ljava/lang/String; - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Ljava/lang/String; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 99
class net/minecraft/nbt/SnbtPrinterTagVisitor 61 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;ILjava/util/List;)V (Ljava/lang/String;ILjava/util/List<Ljava/lang/String;>;)V -
 method public visit (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected getKeys (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/List; (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/List<Ljava/lang/String;>; -
 method public pathString ()Ljava/lang/String; - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Ljava/lang/String; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 62
class net/minecraft/nbt/SnbtPrinterTagVisitor 65 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;ILjava/util/List;)V (Ljava/lang/String;ILjava/util/List<Ljava/lang/String;>;)V -
 method public visit (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected getKeys (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/List; (Lnet/minecraft/nbt/CompoundTag;)Ljava/util/List<Ljava/lang/String;>; -
 method public pathString ()Ljava/lang/String; - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Ljava/lang/String; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 118
class net/minecraft/nbt/StreamTagVisitor 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 method public,abstract visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 113
class net/minecraft/nbt/StreamTagVisitor 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 method public,abstract visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 119
class net/minecraft/nbt/StreamTagVisitor 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 method public,abstract visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 117
class net/minecraft/nbt/StreamTagVisitor 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 method public,abstract visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,abstract visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,abstract visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 99
class net/minecraft/nbt/StreamTagVisitor$EntryResult 61 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/StreamTagVisitor$EntryResult;>;
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 field public,static,final,enum ENTER Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 field public,static,final,enum SKIP Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 field public,static,final,enum BREAK Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 field public,static,final,enum HALT Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,static values ()[Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; - -
in 62
class net/minecraft/nbt/StreamTagVisitor$EntryResult 65 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/StreamTagVisitor$EntryResult;>;
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 field public,static,final,enum ENTER Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 field public,static,final,enum SKIP Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 field public,static,final,enum BREAK Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 field public,static,final,enum HALT Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public,static values ()[Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; - -
in 99
class net/minecraft/nbt/StreamTagVisitor$ValueResult 61 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/StreamTagVisitor$ValueResult;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final,enum CONTINUE Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 field public,static,final,enum BREAK Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 field public,static,final,enum HALT Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public,static values ()[Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 62
class net/minecraft/nbt/StreamTagVisitor$ValueResult 65 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/nbt/StreamTagVisitor$ValueResult;>;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final,enum CONTINUE Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 field public,static,final,enum BREAK Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 field public,static,final,enum HALT Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public,static values ()[Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 209
class net/minecraft/nbt/StringTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public,static quoteAndEscape (Ljava/lang/String;Z)Ljava/lang/String; - -
in 120
class net/minecraft/nbt/StringTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
in 182
class net/minecraft/nbt/StringTag 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>;
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StringTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
in 86
class net/minecraft/nbt/StringTag 60 public,super java/lang/Object net/minecraft/nbt/Tag -
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>;
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StringTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
in 36
class net/minecraft/nbt/StringTag 61 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>;
 method public,static skipString (Ljava/io/DataInput;)V - java/io/IOException
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StringTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 228
class net/minecraft/nbt/StringTag 61 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>;
 method public,static skipString (Ljava/io/DataInput;)V - java/io/IOException
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StringTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 135
class net/minecraft/nbt/StringTag 65 public,super java/lang/Object net/minecraft/nbt/Tag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>;
 method public,static skipString (Ljava/io/DataInput;)V - java/io/IOException
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StringTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 108
class net/minecraft/nbt/StringTag 65 public,final,super java/lang/Record net/minecraft/nbt/PrimitiveTag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>;
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public,static skipString (Ljava/io/DataInput;)V - java/io/IOException
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StringTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public asString ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/String;>; -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static quoteAndEscape (Ljava/lang/String;Ljava/lang/StringBuilder;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()Ljava/lang/String; - -
in 130
class net/minecraft/nbt/StringTag 65 public,final,super java/lang/Record net/minecraft/nbt/PrimitiveTag -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TYPE Lnet/minecraft/nbt/TagType; Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>;
 method public,deprecated <init> (Ljava/lang/String;)V - -
 method public,static skipString (Ljava/io/DataInput;)V - java/io/IOException
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/nbt/StringTag; - -
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public sizeInBytes ()I - -
 method public getId ()B - -
 method public getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/StringTag;>; -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lnet/minecraft/nbt/StringTag; - -
 method public asString ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/String;>; -
 method public accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,static quoteAndEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static quoteAndEscape (Ljava/lang/String;Ljava/lang/StringBuilder;)V - -
 method public,static escapeWithoutQuotes (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static escapeWithoutQuotes (Ljava/lang/String;Ljava/lang/StringBuilder;)V - -
 method public accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public value ()Ljava/lang/String; - -
in 86
class net/minecraft/nbt/StringTagVisitor 60 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 method public <init> ()V - -
 method public visit (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 99
class net/minecraft/nbt/StringTagVisitor 61 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 method public <init> ()V - -
 method public visit (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 135
class net/minecraft/nbt/StringTagVisitor 65 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 method public <init> ()V - -
 method public visit (Lnet/minecraft/nbt/Tag;)Ljava/lang/String; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected,static handleEscape (Ljava/lang/String;)Ljava/lang/String; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 102
class net/minecraft/nbt/StringTagVisitor 65 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public build ()Ljava/lang/String; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 207
class net/minecraft/nbt/Tag 52 public,interface,abstract java/lang/Object - -
 field public,static,final TAG_NAMES [Ljava/lang/String; -
 field public,static,final SYNTAX_HIGHLIGHTING_KEY Lnet/minecraft/ChatFormatting; -
 field public,static,final SYNTAX_HIGHLIGHTING_STRING Lnet/minecraft/ChatFormatting; -
 field public,static,final SYNTAX_HIGHLIGHTING_NUMBER Lnet/minecraft/ChatFormatting; -
 field public,static,final SYNTAX_HIGHLIGHTING_NUMBER_TYPE Lnet/minecraft/ChatFormatting; -
 method public,abstract write (Ljava/io/DataOutput;)V - java/io/IOException
 method public,abstract load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method public,static newTag (B)Lnet/minecraft/nbt/Tag; - -
 method public,static getTagTypeName (I)Ljava/lang/String; - -
 method public,abstract copy ()Lnet/minecraft/nbt/Tag; - -
 method public getAsString ()Ljava/lang/String; - -
 method public getPrettyDisplay ()Lnet/minecraft/network/chat/Component; - -
 method public,abstract getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
in 182
class net/minecraft/nbt/Tag 52 public,interface,abstract java/lang/Object - -
 field public,static,final SYNTAX_HIGHLIGHTING_KEY Lnet/minecraft/ChatFormatting; -
 field public,static,final SYNTAX_HIGHLIGHTING_STRING Lnet/minecraft/ChatFormatting; -
 field public,static,final SYNTAX_HIGHLIGHTING_NUMBER Lnet/minecraft/ChatFormatting; -
 field public,static,final SYNTAX_HIGHLIGHTING_NUMBER_TYPE Lnet/minecraft/ChatFormatting; -
 method public,abstract write (Ljava/io/DataOutput;)V - java/io/IOException
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method public,abstract getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public,abstract copy ()Lnet/minecraft/nbt/Tag; - -
 method public getAsString ()Ljava/lang/String; - -
 method public getPrettyDisplay ()Lnet/minecraft/network/chat/Component; - -
 method public,abstract getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
in 86
class net/minecraft/nbt/Tag 60 public,interface,abstract java/lang/Object - -
 field public,static,final OBJECT_HEADER I - I64
 field public,static,final ARRAY_HEADER I - I96
 field public,static,final OBJECT_REFERENCE I - I32
 field public,static,final STRING_SIZE I - I224
 field public,static,final TAG_END B - I0
 field public,static,final TAG_BYTE B - I1
 field public,static,final TAG_SHORT B - I2
 field public,static,final TAG_INT B - I3
 field public,static,final TAG_LONG B - I4
 field public,static,final TAG_FLOAT B - I5
 field public,static,final TAG_DOUBLE B - I6
 field public,static,final TAG_BYTE_ARRAY B - I7
 field public,static,final TAG_STRING B - I8
 field public,static,final TAG_LIST B - I9
 field public,static,final TAG_COMPOUND B - I10
 field public,static,final TAG_INT_ARRAY B - I11
 field public,static,final TAG_LONG_ARRAY B - I12
 field public,static,final TAG_ANY_NUMERIC B - I99
 field public,static,final MAX_DEPTH I - I512
 method public,abstract write (Ljava/io/DataOutput;)V - java/io/IOException
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method public,abstract getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public,abstract copy ()Lnet/minecraft/nbt/Tag; - -
 method public getAsString ()Ljava/lang/String; - -
 method public,abstract accept (Lnet/minecraft/nbt/TagVisitor;)V - -
in 36
class net/minecraft/nbt/Tag 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final OBJECT_HEADER I - I64
 field public,static,final ARRAY_HEADER I - I96
 field public,static,final OBJECT_REFERENCE I - I32
 field public,static,final STRING_SIZE I - I224
 field public,static,final TAG_END B - I0
 field public,static,final TAG_BYTE B - I1
 field public,static,final TAG_SHORT B - I2
 field public,static,final TAG_INT B - I3
 field public,static,final TAG_LONG B - I4
 field public,static,final TAG_FLOAT B - I5
 field public,static,final TAG_DOUBLE B - I6
 field public,static,final TAG_BYTE_ARRAY B - I7
 field public,static,final TAG_STRING B - I8
 field public,static,final TAG_LIST B - I9
 field public,static,final TAG_COMPOUND B - I10
 field public,static,final TAG_INT_ARRAY B - I11
 field public,static,final TAG_LONG_ARRAY B - I12
 field public,static,final TAG_ANY_NUMERIC B - I99
 field public,static,final MAX_DEPTH I - I512
 method public,abstract write (Ljava/io/DataOutput;)V - java/io/IOException
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method public,abstract getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public,abstract copy ()Lnet/minecraft/nbt/Tag; - -
 method public getAsString ()Ljava/lang/String; - -
 method public,abstract accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,abstract accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public acceptAsRoot (Lnet/minecraft/nbt/StreamTagVisitor;)V - -
in 228
class net/minecraft/nbt/Tag 61 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final OBJECT_HEADER I - I8
 field public,static,final ARRAY_HEADER I - I12
 field public,static,final OBJECT_REFERENCE I - I4
 field public,static,final STRING_SIZE I - I28
 field public,static,final TAG_END B - I0
 field public,static,final TAG_BYTE B - I1
 field public,static,final TAG_SHORT B - I2
 field public,static,final TAG_INT B - I3
 field public,static,final TAG_LONG B - I4
 field public,static,final TAG_FLOAT B - I5
 field public,static,final TAG_DOUBLE B - I6
 field public,static,final TAG_BYTE_ARRAY B - I7
 field public,static,final TAG_STRING B - I8
 field public,static,final TAG_LIST B - I9
 field public,static,final TAG_COMPOUND B - I10
 field public,static,final TAG_INT_ARRAY B - I11
 field public,static,final TAG_LONG_ARRAY B - I12
 field public,static,final TAG_ANY_NUMERIC B - I99
 field public,static,final MAX_DEPTH I - I512
 method public,abstract write (Ljava/io/DataOutput;)V - java/io/IOException
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method public,abstract getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public,abstract copy ()Lnet/minecraft/nbt/Tag; - -
 method public,abstract sizeInBytes ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public,abstract accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,abstract accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public acceptAsRoot (Lnet/minecraft/nbt/StreamTagVisitor;)V - -
in 135
class net/minecraft/nbt/Tag 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 field public,static,final OBJECT_HEADER I - I8
 field public,static,final ARRAY_HEADER I - I12
 field public,static,final OBJECT_REFERENCE I - I4
 field public,static,final STRING_SIZE I - I28
 field public,static,final TAG_END B - I0
 field public,static,final TAG_BYTE B - I1
 field public,static,final TAG_SHORT B - I2
 field public,static,final TAG_INT B - I3
 field public,static,final TAG_LONG B - I4
 field public,static,final TAG_FLOAT B - I5
 field public,static,final TAG_DOUBLE B - I6
 field public,static,final TAG_BYTE_ARRAY B - I7
 field public,static,final TAG_STRING B - I8
 field public,static,final TAG_LIST B - I9
 field public,static,final TAG_COMPOUND B - I10
 field public,static,final TAG_INT_ARRAY B - I11
 field public,static,final TAG_LONG_ARRAY B - I12
 field public,static,final TAG_ANY_NUMERIC B - I99
 field public,static,final MAX_DEPTH I - I512
 method public,abstract write (Ljava/io/DataOutput;)V - java/io/IOException
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method public,abstract getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public,abstract copy ()Lnet/minecraft/nbt/Tag; - -
 method public,abstract sizeInBytes ()I - -
 method public getAsString ()Ljava/lang/String; - -
 method public,abstract accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,abstract accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public acceptAsRoot (Lnet/minecraft/nbt/StreamTagVisitor;)V - -
in 102
class net/minecraft/nbt/Tag 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OBJECT_HEADER I - I8
 field public,static,final ARRAY_HEADER I - I12
 field public,static,final OBJECT_REFERENCE I - I4
 field public,static,final STRING_SIZE I - I28
 field public,static,final TAG_END B - I0
 field public,static,final TAG_BYTE B - I1
 field public,static,final TAG_SHORT B - I2
 field public,static,final TAG_INT B - I3
 field public,static,final TAG_LONG B - I4
 field public,static,final TAG_FLOAT B - I5
 field public,static,final TAG_DOUBLE B - I6
 field public,static,final TAG_BYTE_ARRAY B - I7
 field public,static,final TAG_STRING B - I8
 field public,static,final TAG_LIST B - I9
 field public,static,final TAG_COMPOUND B - I10
 field public,static,final TAG_INT_ARRAY B - I11
 field public,static,final TAG_LONG_ARRAY B - I12
 field public,static,final MAX_DEPTH I - I512
 method public,abstract write (Ljava/io/DataOutput;)V - java/io/IOException
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract getId ()B - -
 method public,abstract getType ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public,abstract copy ()Lnet/minecraft/nbt/Tag; - -
 method public,abstract sizeInBytes ()I - -
 method public,abstract accept (Lnet/minecraft/nbt/TagVisitor;)V - -
 method public,abstract accept (Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public acceptAsRoot (Lnet/minecraft/nbt/StreamTagVisitor;)V - -
 method public asString ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/String;>; -
 method public asNumber ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Number;>; -
 method public asByte ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Byte;>; -
 method public asShort ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Short;>; -
 method public asInt ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Integer;>; -
 method public asLong ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Long;>; -
 method public asFloat ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Float;>; -
 method public asDouble ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Double;>; -
 method public asBoolean ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/Boolean;>; -
 method public asByteArray ()Ljava/util/Optional; ()Ljava/util/Optional<[B>; -
 method public asIntArray ()Ljava/util/Optional; ()Ljava/util/Optional<[I>; -
 method public asLongArray ()Ljava/util/Optional; ()Ljava/util/Optional<[J>; -
 method public asCompound ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/CompoundTag;>; -
 method public asList ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/nbt/ListTag;>; -
in 209
class net/minecraft/nbt/TagParser 52 public,super java/lang/Object - -
 inner com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ERROR_TRAILING_DATA Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_KEY Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_VALUE Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_LIST Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_ARRAY Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INVALID_ARRAY Lcom/mojang/brigadier/exceptions/DynamicCommandExceptionType; -
 method public,static parseTag (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public <init> (Lcom/mojang/brigadier/StringReader;)V - -
 method protected readKey ()Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readTypedValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readList ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readStruct ()Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 98
class net/minecraft/nbt/TagParser 52 public,super java/lang/Object - -
 inner com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ERROR_TRAILING_DATA Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_KEY Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_VALUE Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_LIST Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_ARRAY Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INVALID_ARRAY Lcom/mojang/brigadier/exceptions/DynamicCommandExceptionType; -
 method public,static parseTag (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public <init> (Lcom/mojang/brigadier/StringReader;)V - -
 method protected readKey ()Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readTypedValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readList ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readStruct ()Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 86
class net/minecraft/nbt/TagParser 60 public,super java/lang/Object - -
 inner com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ERROR_TRAILING_DATA Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_KEY Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_VALUE Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_LIST Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_ARRAY Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INVALID_ARRAY Lcom/mojang/brigadier/exceptions/DynamicCommandExceptionType; -
 field public,static,final ELEMENT_SEPARATOR C - I44
 field public,static,final NAME_VALUE_SEPARATOR C - I58
 method public,static parseTag (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public <init> (Lcom/mojang/brigadier/StringReader;)V - -
 method protected readKey ()Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readTypedValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readList ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readStruct ()Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 38
class net/minecraft/nbt/TagParser 61 public,super java/lang/Object - -
 inner com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ERROR_TRAILING_DATA Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_KEY Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_VALUE Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_LIST Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_ARRAY Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INVALID_ARRAY Lcom/mojang/brigadier/exceptions/DynamicCommandExceptionType; -
 field public,static,final ELEMENT_SEPARATOR C - I44
 field public,static,final NAME_VALUE_SEPARATOR C - I58
 method public,static parseTag (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public <init> (Lcom/mojang/brigadier/StringReader;)V - -
 method protected readKey ()Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readTypedValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readList ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readStruct ()Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 242
class net/minecraft/nbt/TagParser 61 public,super java/lang/Object - -
 inner com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ERROR_TRAILING_DATA Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_KEY Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_VALUE Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_LIST Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_ARRAY Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INVALID_ARRAY Lcom/mojang/brigadier/exceptions/DynamicCommandExceptionType; -
 field public,static,final ELEMENT_SEPARATOR C - I44
 field public,static,final NAME_VALUE_SEPARATOR C - I58
 field public,static,final AS_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 method public,static parseTag (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public <init> (Lcom/mojang/brigadier/StringReader;)V - -
 method protected readKey ()Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readTypedValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readList ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readStruct ()Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 135
class net/minecraft/nbt/TagParser 65 public,super java/lang/Object - -
 inner com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic2CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ERROR_TRAILING_DATA Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_KEY Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_VALUE Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_LIST Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INSERT_MIXED_ARRAY Lcom/mojang/brigadier/exceptions/Dynamic2CommandExceptionType; -
 field public,static,final ERROR_INVALID_ARRAY Lcom/mojang/brigadier/exceptions/DynamicCommandExceptionType; -
 field public,static,final ELEMENT_SEPARATOR C - I44
 field public,static,final NAME_VALUE_SEPARATOR C - I58
 field public,static,final AS_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final LENIENT_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 method public,static parseTag (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public <init> (Lcom/mojang/brigadier/StringReader;)V - -
 method protected readKey ()Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readTypedValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readValue ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method protected readList ()Lnet/minecraft/nbt/Tag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public readStruct ()Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 102
class net/minecraft/nbt/TagParser 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ERROR_TRAILING_DATA Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ERROR_EXPECTED_COMPOUND Lcom/mojang/brigadier/exceptions/SimpleCommandExceptionType; -
 field public,static,final ELEMENT_SEPARATOR C - I44
 field public,static,final NAME_VALUE_SEPARATOR C - I58
 field public,static,final FLATTENED_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 field public,static,final LENIENT_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/nbt/CompoundTag;>;
 method public getOps ()Lcom/mojang/serialization/DynamicOps; ()Lcom/mojang/serialization/DynamicOps<TT;>; -
 method public,static create (Lcom/mojang/serialization/DynamicOps;)Lnet/minecraft/nbt/TagParser; <T:Ljava/lang/Object;>(Lcom/mojang/serialization/DynamicOps<TT;>;)Lnet/minecraft/nbt/TagParser<TT;>; -
 method public,static parseCompoundFully (Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public parseFully (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TT; com/mojang/brigadier/exceptions/CommandSyntaxException
 method public parseFully (Lcom/mojang/brigadier/StringReader;)Ljava/lang/Object; (Lcom/mojang/brigadier/StringReader;)TT; com/mojang/brigadier/exceptions/CommandSyntaxException
 method public parseAsArgument (Lcom/mojang/brigadier/StringReader;)Ljava/lang/Object; (Lcom/mojang/brigadier/StringReader;)TT; com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static parseCompoundAsArgument (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
in 182
class net/minecraft/nbt/TagType 52 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;
 method public,abstract load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)TT; java/io/IOException
 method public isValue ()Z - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPrettyName ()Ljava/lang/String; - -
 method public,static createInvalid (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
in 86
class net/minecraft/nbt/TagType 60 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;
 method public,abstract load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)TT; java/io/IOException
 method public isValue ()Z - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPrettyName ()Ljava/lang/String; - -
 method public,static createInvalid (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
in 38
class net/minecraft/nbt/TagType 61 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/TagType$VariableSize net/minecraft/nbt/TagType VariableSize public,static,interface,abstract
 inner net/minecraft/nbt/TagType$StaticSize net/minecraft/nbt/TagType StaticSize public,static,interface,abstract
 method public,abstract load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)TT; java/io/IOException
 method public,abstract parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - java/io/IOException
 method public parseRoot (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;I)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;)V - java/io/IOException
 method public isValue ()Z - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPrettyName ()Ljava/lang/String; - -
 method public,static createInvalid (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
in 242
class net/minecraft/nbt/TagType 61 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/TagType$VariableSize net/minecraft/nbt/TagType VariableSize public,static,interface,abstract
 inner net/minecraft/nbt/TagType$StaticSize net/minecraft/nbt/TagType StaticSize public,static,interface,abstract
 method public,abstract load (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)TT; java/io/IOException
 method public,abstract parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - java/io/IOException
 method public parseRoot (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public isValue ()Z - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPrettyName ()Ljava/lang/String; - -
 method public,static createInvalid (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
in 135
class net/minecraft/nbt/TagType 65 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/TagType$VariableSize net/minecraft/nbt/TagType VariableSize public,static,interface,abstract
 inner net/minecraft/nbt/TagType$StaticSize net/minecraft/nbt/TagType StaticSize public,static,interface,abstract
 method public,abstract load (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)TT; java/io/IOException
 method public,abstract parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - java/io/IOException
 method public parseRoot (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public isValue ()Z - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPrettyName ()Ljava/lang/String; - -
 method public,static createInvalid (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
in 102
class net/minecraft/nbt/TagType 65 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/TagType$VariableSize net/minecraft/nbt/TagType VariableSize public,static,interface,abstract
 inner net/minecraft/nbt/TagType$StaticSize net/minecraft/nbt/TagType StaticSize public,static,interface,abstract
 method public,abstract load (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag; (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)TT; java/io/IOException
 method public,abstract parse (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - java/io/IOException
 method public parseRoot (Ljava/io/DataInput;Lnet/minecraft/nbt/StreamTagVisitor;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract skip (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPrettyName ()Ljava/lang/String; - -
 method public,static createInvalid (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<Lnet/minecraft/nbt/EndTag;>; -
in 38
class net/minecraft/nbt/TagType$StaticSize 61 public,interface,abstract java/lang/Object net/minecraft/nbt/TagType <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;Lnet/minecraft/nbt/TagType<TT;>;
 inner net/minecraft/nbt/TagType$StaticSize net/minecraft/nbt/TagType StaticSize public,static,interface,abstract
 method public skip (Ljava/io/DataInput;)V - java/io/IOException
 method public skip (Ljava/io/DataInput;I)V - java/io/IOException
 method public,abstract size ()I - -
in 242
class net/minecraft/nbt/TagType$StaticSize 61 public,interface,abstract java/lang/Object net/minecraft/nbt/TagType <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;Lnet/minecraft/nbt/TagType<TT;>;
 inner net/minecraft/nbt/TagType$StaticSize net/minecraft/nbt/TagType StaticSize public,static,interface,abstract
 method public skip (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public skip (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract size ()I - -
in 62
class net/minecraft/nbt/TagType$StaticSize 65 public,interface,abstract java/lang/Object net/minecraft/nbt/TagType <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;Lnet/minecraft/nbt/TagType<TT;>;
 inner net/minecraft/nbt/TagType$StaticSize net/minecraft/nbt/TagType StaticSize public,static,interface,abstract
 method public skip (Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public skip (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public,abstract size ()I - -
in 38
class net/minecraft/nbt/TagType$VariableSize 61 public,interface,abstract java/lang/Object net/minecraft/nbt/TagType <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;Lnet/minecraft/nbt/TagType<TT;>;
 inner net/minecraft/nbt/TagType$VariableSize net/minecraft/nbt/TagType VariableSize public,static,interface,abstract
 method public skip (Ljava/io/DataInput;I)V - java/io/IOException
in 242
class net/minecraft/nbt/TagType$VariableSize 61 public,interface,abstract java/lang/Object net/minecraft/nbt/TagType <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;Lnet/minecraft/nbt/TagType<TT;>;
 inner net/minecraft/nbt/TagType$VariableSize net/minecraft/nbt/TagType VariableSize public,static,interface,abstract
 method public skip (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
in 62
class net/minecraft/nbt/TagType$VariableSize 65 public,interface,abstract java/lang/Object net/minecraft/nbt/TagType <T::Lnet/minecraft/nbt/Tag;>Ljava/lang/Object;Lnet/minecraft/nbt/TagType<TT;>;
 inner net/minecraft/nbt/TagType$VariableSize net/minecraft/nbt/TagType VariableSize public,static,interface,abstract
 method public skip (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
in 182
class net/minecraft/nbt/TagTypes 52 public,super java/lang/Object - -
 method public,static getType (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<*>; -
in 86
class net/minecraft/nbt/TagTypes 60 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getType (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<*>; -
in 99
class net/minecraft/nbt/TagTypes 61 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getType (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<*>; -
in 62
class net/minecraft/nbt/TagTypes 65 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getType (I)Lnet/minecraft/nbt/TagType; (I)Lnet/minecraft/nbt/TagType<*>; -
in 86
class net/minecraft/nbt/TagVisitor 60 public,interface,abstract java/lang/Object - -
 method public,abstract visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public,abstract visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public,abstract visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public,abstract visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public,abstract visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public,abstract visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public,abstract visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public,abstract visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public,abstract visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public,abstract visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public,abstract visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public,abstract visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public,abstract visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 99
class net/minecraft/nbt/TagVisitor 61 public,interface,abstract java/lang/Object - -
 method public,abstract visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public,abstract visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public,abstract visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public,abstract visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public,abstract visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public,abstract visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public,abstract visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public,abstract visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public,abstract visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public,abstract visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public,abstract visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public,abstract visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public,abstract visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 62
class net/minecraft/nbt/TagVisitor 65 public,interface,abstract java/lang/Object - -
 method public,abstract visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public,abstract visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public,abstract visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public,abstract visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public,abstract visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public,abstract visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public,abstract visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public,abstract visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public,abstract visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public,abstract visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public,abstract visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public,abstract visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public,abstract visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 86
class net/minecraft/nbt/TextComponentTagVisitor 60 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;I)V - -
 method public visit (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 99
class net/minecraft/nbt/TextComponentTagVisitor 61 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;I)V - -
 method public visit (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 62
class net/minecraft/nbt/TextComponentTagVisitor 65 public,super java/lang/Object net/minecraft/nbt/TagVisitor -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public visit (Lnet/minecraft/nbt/Tag;)Lnet/minecraft/network/chat/Component; - -
 method public visitString (Lnet/minecraft/nbt/StringTag;)V - -
 method public visitByte (Lnet/minecraft/nbt/ByteTag;)V - -
 method public visitShort (Lnet/minecraft/nbt/ShortTag;)V - -
 method public visitInt (Lnet/minecraft/nbt/IntTag;)V - -
 method public visitLong (Lnet/minecraft/nbt/LongTag;)V - -
 method public visitFloat (Lnet/minecraft/nbt/FloatTag;)V - -
 method public visitDouble (Lnet/minecraft/nbt/DoubleTag;)V - -
 method public visitByteArray (Lnet/minecraft/nbt/ByteArrayTag;)V - -
 method public visitIntArray (Lnet/minecraft/nbt/IntArrayTag;)V - -
 method public visitLongArray (Lnet/minecraft/nbt/LongArrayTag;)V - -
 method public visitList (Lnet/minecraft/nbt/ListTag;)V - -
 method public visitCompound (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected,static handleEscapePretty (Ljava/lang/String;)Lnet/minecraft/network/chat/Component; - -
 method public visitEnd (Lnet/minecraft/nbt/EndTag;)V - -
in 99
class net/minecraft/nbt/visitors/CollectFields 61 public,super net/minecraft/nbt/visitors/CollectToTag - -
 inner com/google/common/collect/ImmutableSet$Builder com/google/common/collect/ImmutableSet Builder public,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 method public,varargs <init> ([Lnet/minecraft/nbt/visitors/FieldSelector;)V - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public getMissingFieldCount ()I - -
in 62
class net/minecraft/nbt/visitors/CollectFields 65 public,super net/minecraft/nbt/visitors/CollectToTag - -
 inner com/google/common/collect/ImmutableSet$Builder com/google/common/collect/ImmutableSet Builder public,static
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 method public,varargs <init> ([Lnet/minecraft/nbt/visitors/FieldSelector;)V - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public getMissingFieldCount ()I - -
in 99
class net/minecraft/nbt/visitors/CollectToTag 61 public,super java/lang/Object net/minecraft/nbt/StreamTagVisitor -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getResult ()Lnet/minecraft/nbt/Tag; - -
 method protected depth ()I - -
 method public visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 135
class net/minecraft/nbt/visitors/CollectToTag 65 public,super java/lang/Object net/minecraft/nbt/StreamTagVisitor -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getResult ()Lnet/minecraft/nbt/Tag; - -
 method protected depth ()I - -
 method public visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 165
class net/minecraft/nbt/visitors/CollectToTag 65 public,super java/lang/Object net/minecraft/nbt/StreamTagVisitor -
 inner net/minecraft/nbt/visitors/CollectToTag$RootBuilder net/minecraft/nbt/visitors/CollectToTag RootBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/visitors/CollectToTag$ListBuilder net/minecraft/nbt/visitors/CollectToTag ListBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$CompoundBuilder net/minecraft/nbt/visitors/CollectToTag CompoundBuilder static
 method public <init> ()V - -
 method public getResult ()Lnet/minecraft/nbt/Tag; - -
 method protected depth ()I - -
 method public visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 166
class net/minecraft/nbt/visitors/CollectToTag 65 public,super java/lang/Object net/minecraft/nbt/StreamTagVisitor -
 inner net/minecraft/nbt/visitors/CollectToTag$RootBuilder net/minecraft/nbt/visitors/CollectToTag RootBuilder private,static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder private,static,interface,abstract
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/visitors/CollectToTag$ListBuilder net/minecraft/nbt/visitors/CollectToTag ListBuilder private,static
 inner net/minecraft/nbt/visitors/CollectToTag$CompoundBuilder net/minecraft/nbt/visitors/CollectToTag CompoundBuilder private,static
 method public <init> ()V - -
 method public getResult ()Lnet/minecraft/nbt/Tag; - -
 method protected depth ()I - -
 method public visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 165
class net/minecraft/nbt/visitors/CollectToTag$CompoundBuilder 65 super java/lang/Object net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder -
 inner net/minecraft/nbt/visitors/CollectToTag$CompoundBuilder net/minecraft/nbt/visitors/CollectToTag CompoundBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder static,interface,abstract
 method public acceptKey (Ljava/lang/String;)V - -
 method public acceptValue (Lnet/minecraft/nbt/Tag;)V - -
 method public build ()Lnet/minecraft/nbt/Tag; - -
in 166
class net/minecraft/nbt/visitors/CollectToTag$CompoundBuilder 65 super java/lang/Object net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder -
 inner net/minecraft/nbt/visitors/CollectToTag$CompoundBuilder net/minecraft/nbt/visitors/CollectToTag CompoundBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder private,static,interface,abstract
 method public acceptKey (Ljava/lang/String;)V - -
 method public acceptValue (Lnet/minecraft/nbt/Tag;)V - -
 method public build ()Lnet/minecraft/nbt/Tag; - -
in 102
class net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder 65 interface,abstract java/lang/Object - -
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder static,interface,abstract
 method public acceptKey (Ljava/lang/String;)V - -
 method public,abstract acceptValue (Lnet/minecraft/nbt/Tag;)V - -
 method public,abstract build ()Lnet/minecraft/nbt/Tag; - -
in 165
class net/minecraft/nbt/visitors/CollectToTag$ListBuilder 65 super java/lang/Object net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder -
 inner net/minecraft/nbt/visitors/CollectToTag$ListBuilder net/minecraft/nbt/visitors/CollectToTag ListBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder static,interface,abstract
 method public acceptValue (Lnet/minecraft/nbt/Tag;)V - -
 method public build ()Lnet/minecraft/nbt/Tag; - -
in 166
class net/minecraft/nbt/visitors/CollectToTag$ListBuilder 65 super java/lang/Object net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder -
 inner net/minecraft/nbt/visitors/CollectToTag$ListBuilder net/minecraft/nbt/visitors/CollectToTag ListBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder private,static,interface,abstract
 method public acceptValue (Lnet/minecraft/nbt/Tag;)V - -
 method public build ()Lnet/minecraft/nbt/Tag; - -
in 165
class net/minecraft/nbt/visitors/CollectToTag$RootBuilder 65 super java/lang/Object net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder -
 inner net/minecraft/nbt/visitors/CollectToTag$RootBuilder net/minecraft/nbt/visitors/CollectToTag RootBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder static,interface,abstract
 method public acceptValue (Lnet/minecraft/nbt/Tag;)V - -
 method public build ()Lnet/minecraft/nbt/Tag; - -
in 166
class net/minecraft/nbt/visitors/CollectToTag$RootBuilder 65 super java/lang/Object net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder -
 inner net/minecraft/nbt/visitors/CollectToTag$RootBuilder net/minecraft/nbt/visitors/CollectToTag RootBuilder static
 inner net/minecraft/nbt/visitors/CollectToTag$ContainerBuilder net/minecraft/nbt/visitors/CollectToTag ContainerBuilder private,static,interface,abstract
 method public acceptValue (Lnet/minecraft/nbt/Tag;)V - -
 method public build ()Lnet/minecraft/nbt/Tag; - -
in 99
class net/minecraft/nbt/visitors/FieldSelector 61 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public <init> (Ljava/lang/String;Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public <init> (Ljava/util/List;Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public path ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public type ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public name ()Ljava/lang/String; - -
in 62
class net/minecraft/nbt/visitors/FieldSelector 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public <init> (Ljava/lang/String;Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public <init> (Ljava/util/List;Lnet/minecraft/nbt/TagType;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public path ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public type ()Lnet/minecraft/nbt/TagType; ()Lnet/minecraft/nbt/TagType<*>; -
 method public name ()Ljava/lang/String; - -
in 99
class net/minecraft/nbt/visitors/FieldTree 61 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;Ljava/util/Map;)V (ILjava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;>;Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/visitors/FieldTree;>;)V -
 method public,static createRoot ()Lnet/minecraft/nbt/visitors/FieldTree; - -
 method public addEntry (Lnet/minecraft/nbt/visitors/FieldSelector;)V - -
 method public isSelected (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Z (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Z -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public depth ()I - -
 method public selectedFields ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;>; -
 method public fieldsToRecurse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/visitors/FieldTree;>; -
in 62
class net/minecraft/nbt/visitors/FieldTree 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Map;Ljava/util/Map;)V (ILjava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;>;Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/visitors/FieldTree;>;)V -
 method public,static createRoot ()Lnet/minecraft/nbt/visitors/FieldTree; - -
 method public addEntry (Lnet/minecraft/nbt/visitors/FieldSelector;)V - -
 method public isSelected (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Z (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Z -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public depth ()I - -
 method public selectedFields ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/TagType<*>;>; -
 method public fieldsToRecurse ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/nbt/visitors/FieldTree;>; -
in 99
class net/minecraft/nbt/visitors/SkipAll 61 public,interface,abstract java/lang/Object net/minecraft/nbt/StreamTagVisitor -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 field public,static,final INSTANCE Lnet/minecraft/nbt/visitors/SkipAll; -
 method public visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 62
class net/minecraft/nbt/visitors/SkipAll 65 public,interface,abstract java/lang/Object net/minecraft/nbt/StreamTagVisitor -
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 field public,static,final INSTANCE Lnet/minecraft/nbt/visitors/SkipAll; -
 method public visitEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (S)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (F)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit (D)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([B)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visit ([J)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitList (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
 method public visitElement (Lnet/minecraft/nbt/TagType;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;I)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
 method public visitRootEntry (Lnet/minecraft/nbt/TagType;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; (Lnet/minecraft/nbt/TagType<*>;)Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; -
in 99
class net/minecraft/nbt/visitors/SkipFields 61 public,super net/minecraft/nbt/visitors/CollectToTag - -
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 method public,varargs <init> ([Lnet/minecraft/nbt/visitors/FieldSelector;)V - -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
in 62
class net/minecraft/nbt/visitors/SkipFields 65 public,super net/minecraft/nbt/visitors/CollectToTag - -
 inner net/minecraft/nbt/StreamTagVisitor$EntryResult net/minecraft/nbt/StreamTagVisitor EntryResult public,static,final,enum
 inner net/minecraft/nbt/StreamTagVisitor$ValueResult net/minecraft/nbt/StreamTagVisitor ValueResult public,static,final,enum
 method public,varargs <init> ([Lnet/minecraft/nbt/visitors/FieldSelector;)V - -
 method public visitEntry (Lnet/minecraft/nbt/TagType;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; (Lnet/minecraft/nbt/TagType<*>;Ljava/lang/String;)Lnet/minecraft/nbt/StreamTagVisitor$EntryResult; -
 method public visitContainerEnd ()Lnet/minecraft/nbt/StreamTagVisitor$ValueResult; - -
