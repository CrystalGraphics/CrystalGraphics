cg-stub-db 1
in 453
class net/jodah/typetools/ReifiedParameterizedType 52 super java/lang/Object java/lang/reflect/ParameterizedType -
 method public getActualTypeArguments ()[Ljava/lang/reflect/Type; - -
 method public getRawType ()Ljava/lang/reflect/Type; - -
 method public getOwnerType ()Ljava/lang/reflect/Type; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 454
class net/jodah/typetools/ReifiedParameterizedType 50 super java/lang/Object java/lang/reflect/ParameterizedType -
 method public getActualTypeArguments ()[Ljava/lang/reflect/Type; - -
 method public getRawType ()Ljava/lang/reflect/Type; - -
 method public getOwnerType ()Ljava/lang/reflect/Type; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 453
class net/jodah/typetools/TypeResolver 52 public,final,super java/lang/Object - -
 inner net/jodah/typetools/TypeResolver$Unknown net/jodah/typetools/TypeResolver Unknown public,static,final
 inner net/jodah/typetools/TypeResolver$AccessMaker net/jodah/typetools/TypeResolver AccessMaker private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static enableCache ()V - -
 method public,static disableCache ()V - -
 method public,static resolveRawArgument (Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/Class; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)Ljava/lang/Class<*>; -
 method public,static resolveRawArgument (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/Class<*>; -
 method public,static resolveRawArguments (Ljava/lang/Class;Ljava/lang/Class;)[Ljava/lang/Class; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)[Ljava/lang/Class<*>; -
 method public,static reify (Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/reflect/Type; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)Ljava/lang/reflect/Type; -
 method public,static reify (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/reflect/Type; -
 method public,static reify (Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; - -
 method public,static resolveRawArguments (Ljava/lang/reflect/Type;Ljava/lang/Class;)[Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)[Ljava/lang/Class<*>; -
 method public,static resolveGenericType (Ljava/lang/Class;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; (Ljava/lang/Class<*>;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; -
 method public,static resolveRawClass (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/Class<*>; -
 method public,static resolveBound (Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/TypeVariable<*>;)Ljava/lang/reflect/Type; -
in 454
class net/jodah/typetools/TypeResolver 50 public,final,super java/lang/Object - -
 inner net/jodah/typetools/TypeResolver$Unknown net/jodah/typetools/TypeResolver Unknown public,static,final
 inner net/jodah/typetools/TypeResolver$AccessMaker net/jodah/typetools/TypeResolver AccessMaker private,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static enableCache ()V - -
 method public,static disableCache ()V - -
 method public,static resolveRawArgument (Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/Class; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)Ljava/lang/Class<*>; -
 method public,static resolveRawArgument (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/Class<*>; -
 method public,static resolveRawArguments (Ljava/lang/Class;Ljava/lang/Class;)[Ljava/lang/Class; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)[Ljava/lang/Class<*>; -
 method public,static reify (Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/reflect/Type; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)Ljava/lang/reflect/Type; -
 method public,static reify (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/reflect/Type; -
 method public,static reify (Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; - -
 method public,static resolveRawArguments (Ljava/lang/reflect/Type;Ljava/lang/Class;)[Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)[Ljava/lang/Class<*>; -
 method public,static resolveGenericType (Ljava/lang/Class;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; (Ljava/lang/Class<*>;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; -
 method public,static resolveRawClass (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/Class<*>; -
 method public,static resolveBound (Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/TypeVariable<*>;)Ljava/lang/reflect/Type; -
in 256
class net/jodah/typetools/TypeResolver 50 public,final,super java/lang/Object - -
 inner net/jodah/typetools/TypeResolver$ReifiedParameterizedType net/jodah/typetools/TypeResolver ReifiedParameterizedType private,static
 inner net/jodah/typetools/TypeResolver$Unknown net/jodah/typetools/TypeResolver Unknown public,static,final
 method public,static enableCache ()V - -
 method public,static disableCache ()V - -
 method public,static resolveRawArgument (Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/Class; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)Ljava/lang/Class<*>; -
 method public,static resolveRawArgument (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/Class<*>; -
 method public,static resolveRawArguments (Ljava/lang/Class;Ljava/lang/Class;)[Ljava/lang/Class; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)[Ljava/lang/Class<*>; -
 method public,static reify (Ljava/lang/Class;Ljava/lang/Class;)Ljava/lang/reflect/Type; <T:Ljava/lang/Object;S:TT;>(Ljava/lang/Class<TT;>;Ljava/lang/Class<TS;>;)Ljava/lang/reflect/Type; -
 method public,static reify (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/reflect/Type; -
 method public,static reify (Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; - -
 method public,static resolveRawArguments (Ljava/lang/reflect/Type;Ljava/lang/Class;)[Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)[Ljava/lang/Class<*>; -
 method public,static resolveGenericType (Ljava/lang/Class;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; (Ljava/lang/Class<*>;Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type; -
 method public,static resolveRawClass (Ljava/lang/reflect/Type;Ljava/lang/Class;)Ljava/lang/Class; (Ljava/lang/reflect/Type;Ljava/lang/Class<*>;)Ljava/lang/Class<*>; -
 method public,static resolveBound (Ljava/lang/reflect/TypeVariable;)Ljava/lang/reflect/Type; (Ljava/lang/reflect/TypeVariable<*>;)Ljava/lang/reflect/Type; -
in 453
class net/jodah/typetools/TypeResolver$AccessMaker 52 interface,abstract java/lang/Object - -
 inner net/jodah/typetools/TypeResolver$AccessMaker net/jodah/typetools/TypeResolver AccessMaker private,static,interface,abstract
 method public,abstract makeAccessible (Ljava/lang/reflect/AccessibleObject;)V - java/lang/Throwable
in 454
class net/jodah/typetools/TypeResolver$AccessMaker 50 interface,abstract java/lang/Object - -
 inner net/jodah/typetools/TypeResolver$AccessMaker net/jodah/typetools/TypeResolver AccessMaker private,static,interface,abstract
 method public,abstract makeAccessible (Ljava/lang/reflect/AccessibleObject;)V - java/lang/Throwable
in 256
class net/jodah/typetools/TypeResolver$ReifiedParameterizedType 50 super java/lang/Object java/lang/reflect/ParameterizedType -
 inner net/jodah/typetools/TypeResolver$ReifiedParameterizedType net/jodah/typetools/TypeResolver ReifiedParameterizedType private,static
 method public getActualTypeArguments ()[Ljava/lang/reflect/Type; - -
 method public getRawType ()Ljava/lang/reflect/Type; - -
 method public getOwnerType ()Ljava/lang/reflect/Type; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 453
class net/jodah/typetools/TypeResolver$Unknown 52 public,final,super java/lang/Object - -
 inner net/jodah/typetools/TypeResolver$Unknown net/jodah/typetools/TypeResolver Unknown public,static,final
in 455
class net/jodah/typetools/TypeResolver$Unknown 50 public,final,super java/lang/Object - -
 inner net/jodah/typetools/TypeResolver$Unknown net/jodah/typetools/TypeResolver Unknown public,static,final
