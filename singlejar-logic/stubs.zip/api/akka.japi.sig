cg-stub-db 1
in 0
class akka/japi/Creator 50 public,interface,abstract java/lang/Object scala/Serializable <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,abstract create ()Ljava/lang/Object; ()TT; java/lang/Exception
in 0
class akka/japi/Effect 50 public,interface,abstract java/lang/Object - -
 method public,abstract apply ()V - java/lang/Exception
in 0
class akka/japi/Function 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TT;)TR; java/lang/Exception
in 0
class akka/japi/Function2 50 public,interface,abstract java/lang/Object - <T1:Ljava/lang/Object;T2:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TT1;TT2;)TR; java/lang/Exception
in 0
class akka/japi/JAPI 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static,varargs seq ([Ljava/lang/Object;)Lscala/collection/Seq; <T:Ljava/lang/Object;>([TT;)Lscala/collection/Seq<TT;>; -
in 0
class akka/japi/JavaPartialFunction 50 public,super,abstract scala/runtime/AbstractPartialFunction - <A:Ljava/lang/Object;B:Ljava/lang/Object;>Lscala/runtime/AbstractPartialFunction<TA;TB;>;
 inner akka/japi/JavaPartialFunction$NoMatch$ akka/japi/JavaPartialFunction NoMatch$ public,static
 inner akka/japi/JavaPartialFunction$NoMatchException akka/japi/JavaPartialFunction NoMatchException public,static,abstract
 method public,static noMatch ()Ljava/lang/RuntimeException; - -
 method public,abstract apply (Ljava/lang/Object;Z)Ljava/lang/Object; (TA;Z)TB; java/lang/Exception
 method public,final isDefinedAt (Ljava/lang/Object;)Z (TA;)Z -
 method public,final apply (Ljava/lang/Object;)Ljava/lang/Object; (TA;)TB; -
 method public,final applyOrElse (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <A1:TA;B1:Ljava/lang/Object;>(TA1;Lscala/Function1<TA1;TB1;>;)TB1; -
 method public <init> ()V ()V -
in 0
class akka/japi/JavaPartialFunction$ 50 public,final,super java/lang/Object - -
 inner akka/japi/JavaPartialFunction$NoMatch$ akka/japi/JavaPartialFunction NoMatch$ public,static
 inner akka/japi/JavaPartialFunction$NoMatchException akka/japi/JavaPartialFunction NoMatchException public,static,abstract
 field public,static,final MODULE$ Lakka/japi/JavaPartialFunction$; -
 method public,static <clinit> ()V - -
 method public,final noMatch ()Ljava/lang/RuntimeException; - -
in 0
class akka/japi/JavaPartialFunction$NoMatch$ 50 public,super akka/japi/JavaPartialFunction$NoMatchException scala/Product,scala/Serializable -
 inner akka/japi/JavaPartialFunction$NoMatch$ akka/japi/JavaPartialFunction NoMatch$ public,static
 inner akka/japi/JavaPartialFunction$NoMatchException akka/japi/JavaPartialFunction NoMatchException public,static,abstract
 field public,static,final MODULE$ Lakka/japi/JavaPartialFunction$NoMatch$; -
 method public,static <clinit> ()V - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public <init> ()V - -
in 0
class akka/japi/JavaPartialFunction$NoMatchException 50 public,super,abstract java/lang/RuntimeException scala/util/control/NoStackTrace -
 inner akka/japi/JavaPartialFunction$NoMatchException akka/japi/JavaPartialFunction NoMatchException public,static,abstract
 method public fillInStackTrace ()Ljava/lang/Throwable; - -
 method public <init> ()V - -
in 0
class akka/japi/Option 50 public,super,abstract java/lang/Object java/lang/Iterable <A:Ljava/lang/Object;>Ljava/lang/Object;Ljava/lang/Iterable<TA;>;
 inner akka/japi/Option$Some akka/japi/Option Some public,static,final
 inner akka/japi/Option$Some$ akka/japi/Option Some$ public,static
 inner akka/japi/Option$None$ akka/japi/Option None$ public,static
 method public,static scala2JavaOption (Lscala/Option;)Lakka/japi/Option; <A:Ljava/lang/Object;>(Lscala/Option<TA;>;)Lakka/japi/Option<TA;>; -
 method public,static java2ScalaOption (Lakka/japi/Option;)Lscala/Option; <A:Ljava/lang/Object;>(Lakka/japi/Option<TA;>;)Lscala/Option<TA;>; -
 method public,static fromScalaOption (Lscala/Option;)Lakka/japi/Option; <T:Ljava/lang/Object;>(Lscala/Option<TT;>;)Lakka/japi/Option<TT;>; -
 method public,static option (Ljava/lang/Object;)Lakka/japi/Option; <A:Ljava/lang/Object;>(TA;)Lakka/japi/Option<TA;>; -
 method public,static none ()Lakka/japi/Option; <A:Ljava/lang/Object;>()Lakka/japi/Option<TA;>; -
 method public,static some (Ljava/lang/Object;)Lakka/japi/Option; <A:Ljava/lang/Object;>(TA;)Lakka/japi/Option<TA;>; -
 method public,abstract get ()Ljava/lang/Object; ()TA; -
 method public,abstract isEmpty ()Z - -
 method public isDefined ()Z - -
 method public,abstract asScala ()Lscala/Option; ()Lscala/Option<TA;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<TA;>; -
 method public <init> ()V ()V -
in 0
class akka/japi/Option$ 50 public,final,super java/lang/Object - -
 inner akka/japi/Option$Some akka/japi/Option Some public,static,final
 inner akka/japi/Option$None$ akka/japi/Option None$ public,static
 inner akka/japi/Option$Some$ akka/japi/Option Some$ public,static
 field public,static,final MODULE$ Lakka/japi/Option$; -
 method public,static <clinit> ()V - -
 method public some (Ljava/lang/Object;)Lakka/japi/Option; <A:Ljava/lang/Object;>(TA;)Lakka/japi/Option<TA;>; -
 method public none ()Lakka/japi/Option; <A:Ljava/lang/Object;>()Lakka/japi/Option<TA;>; -
 method public option (Ljava/lang/Object;)Lakka/japi/Option; <A:Ljava/lang/Object;>(TA;)Lakka/japi/Option<TA;>; -
 method public fromScalaOption (Lscala/Option;)Lakka/japi/Option; <T:Ljava/lang/Object;>(Lscala/Option<TT;>;)Lakka/japi/Option<TT;>; -
 method public java2ScalaOption (Lakka/japi/Option;)Lscala/Option; <A:Ljava/lang/Object;>(Lakka/japi/Option<TA;>;)Lscala/Option<TA;>; -
 method public scala2JavaOption (Lscala/Option;)Lakka/japi/Option; <A:Ljava/lang/Object;>(Lscala/Option<TA;>;)Lakka/japi/Option<TA;>; -
in 0
class akka/japi/Option$None$ 50 public,super akka/japi/Option scala/Product,scala/Serializable Lakka/japi/Option<Lscala/runtime/Nothing$;>;Lscala/Product;Lscala/Serializable;
 inner akka/japi/Option$None$ akka/japi/Option None$ public,static
 field public,static,final MODULE$ Lakka/japi/Option$None$; -
 method public,static <clinit> ()V - -
 method public get ()Lscala/runtime/Nothing$; - -
 method public isEmpty ()Z - -
 method public asScala ()Lscala/None$; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class akka/japi/Option$Some 50 public,final,super akka/japi/Option scala/Product,scala/Serializable <A:Ljava/lang/Object;>Lakka/japi/Option<TA;>;Lscala/Product;Lscala/Serializable;
 inner akka/japi/Option$Some akka/japi/Option Some public,static,final
 method public v ()Ljava/lang/Object; ()TA; -
 method public get ()Ljava/lang/Object; ()TA; -
 method public isEmpty ()Z - -
 method public asScala ()Lscala/Some; ()Lscala/Some<TA;>; -
 method public copy (Ljava/lang/Object;)Lakka/japi/Option$Some; <A:Ljava/lang/Object;>(TA;)Lakka/japi/Option$Some<TA;>; -
 method public copy$default$1 ()Ljava/lang/Object; <A:Ljava/lang/Object;>()TA; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/Object;)V (TA;)V -
in 0
class akka/japi/Option$Some$ 50 public,super java/lang/Object scala/Serializable -
 inner akka/japi/Option$Some$ akka/japi/Option Some$ public,static
 inner akka/japi/Option$Some akka/japi/Option Some public,static,final
 field public,static,final MODULE$ Lakka/japi/Option$Some$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/Object;)Lakka/japi/Option$Some; <A:Ljava/lang/Object;>(TA;)Lakka/japi/Option$Some<TA;>; -
 method public unapply (Lakka/japi/Option$Some;)Lscala/Option; <A:Ljava/lang/Object;>(Lakka/japi/Option$Some<TA;>;)Lscala/Option<TA;>; -
 method public <init> ()V - -
in 0
class akka/japi/Pair 50 public,super java/lang/Object scala/Product,scala/Serializable <A:Ljava/lang/Object;B:Ljava/lang/Object;>Ljava/lang/Object;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/japi/Pair;)Lscala/Option; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lakka/japi/Pair<TA;TB;>;)Lscala/Option<Lscala/Tuple2<TA;TB;>;>; -
 method public,static apply (Ljava/lang/Object;Ljava/lang/Object;)Lakka/japi/Pair; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(TA;TB;)Lakka/japi/Pair<TA;TB;>; -
 method public first ()Ljava/lang/Object; ()TA; -
 method public second ()Ljava/lang/Object; ()TB; -
 method public copy (Ljava/lang/Object;Ljava/lang/Object;)Lakka/japi/Pair; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(TA;TB;)Lakka/japi/Pair<TA;TB;>; -
 method public copy$default$1 ()Ljava/lang/Object; <A:Ljava/lang/Object;B:Ljava/lang/Object;>()TA; -
 method public copy$default$2 ()Ljava/lang/Object; <A:Ljava/lang/Object;B:Ljava/lang/Object;>()TB; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;)V (TA;TB;)V -
in 0
class akka/japi/Pair$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lakka/japi/Pair$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Lakka/japi/Pair; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(TA;TB;)Lakka/japi/Pair<TA;TB;>; -
 method public unapply (Lakka/japi/Pair;)Lscala/Option; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(Lakka/japi/Pair<TA;TB;>;)Lscala/Option<Lscala/Tuple2<TA;TB;>;>; -
in 0
class akka/japi/Predicate 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract test (Ljava/lang/Object;)Z (TT;)Z -
in 0
class akka/japi/Procedure 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract apply (Ljava/lang/Object;)V (TT;)V java/lang/Exception
in 0
class akka/japi/Util 50 public,final,super java/lang/Object - -
 method public,static immutableIndexedSeq (Ljava/lang/Iterable;)Lscala/collection/immutable/IndexedSeq; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;)Lscala/collection/immutable/IndexedSeq<TT;>; -
 method public,static immutableSingletonSeq (Ljava/lang/Object;)Lscala/collection/immutable/Seq; <T:Ljava/lang/Object;>(TT;)Lscala/collection/immutable/Seq<TT;>; -
 method public,static immutableSeq (Ljava/lang/Iterable;)Lscala/collection/immutable/Seq; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;)Lscala/collection/immutable/Seq<TT;>; -
 method public,static immutableSeq (Ljava/lang/Object;)Lscala/collection/immutable/Seq; <T:Ljava/lang/Object;>(Ljava/lang/Object;)Lscala/collection/immutable/Seq<TT;>; -
 method public,static immutableSeq ([Ljava/lang/Class;)Lscala/collection/immutable/Seq; ([Ljava/lang/Class<*>;)Lscala/collection/immutable/Seq<Ljava/lang/Class<*>;>; -
 method public,static classTag (Ljava/lang/Class;)Lscala/reflect/ClassTag; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Lscala/reflect/ClassTag<TT;>; -
in 0
class akka/japi/Util$ 50 public,final,super java/lang/Object - -
 inner akka/util/Collections$EmptyImmutableSeq$ akka/util/Collections EmptyImmutableSeq$ public,static
 field public,static,final MODULE$ Lakka/japi/Util$; -
 method public,static <clinit> ()V - -
 method public classTag (Ljava/lang/Class;)Lscala/reflect/ClassTag; <T:Ljava/lang/Object;>(Ljava/lang/Class<TT;>;)Lscala/reflect/ClassTag<TT;>; -
 method public immutableSeq ([Ljava/lang/Class;)Lscala/collection/immutable/Seq; ([Ljava/lang/Class<*>;)Lscala/collection/immutable/Seq<Ljava/lang/Class<*>;>; -
 method public immutableSeq (Ljava/lang/Object;)Lscala/collection/immutable/Seq; <T:Ljava/lang/Object;>(Ljava/lang/Object;)Lscala/collection/immutable/Seq<TT;>; -
 method public immutableSeq (Ljava/lang/Iterable;)Lscala/collection/immutable/Seq; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;)Lscala/collection/immutable/Seq<TT;>; -
 method public immutableSingletonSeq (Ljava/lang/Object;)Lscala/collection/immutable/Seq; <T:Ljava/lang/Object;>(TT;)Lscala/collection/immutable/Seq<TT;>; -
 method public immutableIndexedSeq (Ljava/lang/Iterable;)Lscala/collection/immutable/IndexedSeq; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;)Lscala/collection/immutable/IndexedSeq<TT;>; -
in 0
class akka/japi/pf/AbstractMatch 50 super java/lang/Object - <I:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 field protected,final statements Lscala/PartialFunction; Lscala/PartialFunction<TI;TR;>;
 method public asPF ()Lscala/PartialFunction; ()Lscala/PartialFunction<TI;TR;>; -
in 0
class akka/japi/pf/AbstractPFBuilder 50 super,abstract java/lang/Object - <F:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/lang/Object;
 field protected statements Lscala/PartialFunction; Lscala/PartialFunction<TF;TT;>;
 method protected addStatement (Lscala/PartialFunction;)V (Lscala/PartialFunction<TF;TT;>;)V -
 method public build ()Lscala/PartialFunction; ()Lscala/PartialFunction<TF;TT;>; -
in 0
class akka/japi/pf/CaseStatement 50 public,super java/lang/Object scala/PartialFunction <F:Ljava/lang/Object;P:Ljava/lang/Object;T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/PartialFunction<TF;TT;>;
 inner akka/japi/pf/FI$Apply akka/japi/pf/FI Apply public,static,interface,abstract
 inner akka/japi/pf/FI$Predicate akka/japi/pf/FI Predicate public,static,interface,abstract
 method public,static empty ()Lscala/PartialFunction; <F:Ljava/lang/Object;T:Ljava/lang/Object;>()Lscala/PartialFunction<TF;TT;>; -
 method public orElse (Lscala/PartialFunction;)Lscala/PartialFunction; <A1:TF;B1:Ljava/lang/Object;>(Lscala/PartialFunction<TA1;TB1;>;)Lscala/PartialFunction<TA1;TB1;>; -
 method public andThen (Lscala/Function1;)Lscala/PartialFunction; <C:Ljava/lang/Object;>(Lscala/Function1<TT;TC;>;)Lscala/PartialFunction<TF;TC;>; -
 method public lift ()Lscala/Function1; ()Lscala/Function1<TF;Lscala/Option<TT;>;>; -
 method public applyOrElse (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <A1:TF;B1:Ljava/lang/Object;>(TA1;Lscala/Function1<TA1;TB1;>;)TB1; -
 method public runWith (Lscala/Function1;)Lscala/Function1; <U:Ljava/lang/Object;>(Lscala/Function1<TT;TU;>;)Lscala/Function1<TF;Ljava/lang/Object;>; -
 method public apply$mcZD$sp (D)Z - -
 method public apply$mcDD$sp (D)D - -
 method public apply$mcFD$sp (D)F - -
 method public apply$mcID$sp (D)I - -
 method public apply$mcJD$sp (D)J - -
 method public apply$mcVD$sp (D)V - -
 method public apply$mcZF$sp (F)Z - -
 method public apply$mcDF$sp (F)D - -
 method public apply$mcFF$sp (F)F - -
 method public apply$mcIF$sp (F)I - -
 method public apply$mcJF$sp (F)J - -
 method public apply$mcVF$sp (F)V - -
 method public apply$mcZI$sp (I)Z - -
 method public apply$mcDI$sp (I)D - -
 method public apply$mcFI$sp (I)F - -
 method public apply$mcII$sp (I)I - -
 method public apply$mcJI$sp (I)J - -
 method public apply$mcVI$sp (I)V - -
 method public apply$mcZJ$sp (J)Z - -
 method public apply$mcDJ$sp (J)D - -
 method public apply$mcFJ$sp (J)F - -
 method public apply$mcIJ$sp (J)I - -
 method public apply$mcJJ$sp (J)J - -
 method public apply$mcVJ$sp (J)V - -
 method public compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;TF;>;)Lscala/Function1<TA;TT;>; -
 method public toString ()Ljava/lang/String; - -
 method public isDefinedAt (Ljava/lang/Object;)Z (TF;)Z -
 method public apply (Ljava/lang/Object;)Ljava/lang/Object; (TF;)TT; -
 method public <init> (Lakka/japi/pf/FI$Predicate;Lakka/japi/pf/FI$Apply;)V (Lakka/japi/pf/FI$Predicate;Lakka/japi/pf/FI$Apply<TP;TT;>;)V -
in 0
class akka/japi/pf/CaseStatement$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lakka/japi/pf/CaseStatement$; -
 method public,static <clinit> ()V - -
 method public empty ()Lscala/PartialFunction; <F:Ljava/lang/Object;T:Ljava/lang/Object;>()Lscala/PartialFunction<TF;TT;>; -
in 0
class akka/japi/pf/DeciderBuilder 50 public,super java/lang/Object - -
 inner akka/japi/pf/FI$Apply akka/japi/pf/FI Apply public,static,interface,abstract
 inner akka/actor/SupervisorStrategy$Directive akka/actor/SupervisorStrategy Directive public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 method public,static match (Ljava/lang/Class;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <P:Ljava/lang/Throwable;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$Apply<TP;Lakka/actor/SupervisorStrategy$Directive;>;)Lakka/japi/pf/PFBuilder<Ljava/lang/Throwable;Lakka/actor/SupervisorStrategy$Directive;>; -
 method public,static match (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <P:Ljava/lang/Throwable;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$Apply<TP;Lakka/actor/SupervisorStrategy$Directive;>;)Lakka/japi/pf/PFBuilder<Ljava/lang/Throwable;Lakka/actor/SupervisorStrategy$Directive;>; -
 method public,static matchAny (Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; (Lakka/japi/pf/FI$Apply<Ljava/lang/Object;Lakka/actor/SupervisorStrategy$Directive;>;)Lakka/japi/pf/PFBuilder<Ljava/lang/Throwable;Lakka/actor/SupervisorStrategy$Directive;>; -
in 0
class akka/japi/pf/FI 50 public,final,super java/lang/Object - -
 inner akka/japi/pf/FI$Predicate akka/japi/pf/FI Predicate static,interface,abstract
 inner akka/japi/pf/FI$UnitApplyVoid akka/japi/pf/FI UnitApplyVoid public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply3 akka/japi/pf/FI UnitApply3 public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply2 akka/japi/pf/FI UnitApply2 public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate2 akka/japi/pf/FI TypedPredicate2 public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 inner akka/japi/pf/FI$Apply2 akka/japi/pf/FI Apply2 public,static,interface,abstract
 inner akka/japi/pf/FI$Apply akka/japi/pf/FI Apply public,static,interface,abstract
in 0
class akka/japi/pf/FI$Apply 50 public,interface,abstract java/lang/Object - <I:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$Apply akka/japi/pf/FI Apply public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;)Ljava/lang/Object; (TI;)TR; java/lang/Exception
in 0
class akka/japi/pf/FI$Apply2 50 public,interface,abstract java/lang/Object - <I1:Ljava/lang/Object;I2:Ljava/lang/Object;R:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$Apply2 akka/japi/pf/FI Apply2 public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object; (TI1;TI2;)TR; java/lang/Exception
in 0
class akka/japi/pf/FI$Predicate 50 interface,abstract java/lang/Object - -
 inner akka/japi/pf/FI$Predicate akka/japi/pf/FI Predicate static,interface,abstract
 method public,abstract defined (Ljava/lang/Object;)Z - -
in 0
class akka/japi/pf/FI$TypedPredicate 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 method public,abstract defined (Ljava/lang/Object;)Z (TT;)Z -
in 0
class akka/japi/pf/FI$TypedPredicate2 50 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;U:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$TypedPredicate2 akka/japi/pf/FI TypedPredicate2 public,static,interface,abstract
 method public,abstract defined (Ljava/lang/Object;Ljava/lang/Object;)Z (TT;TU;)Z -
in 0
class akka/japi/pf/FI$UnitApply 50 public,interface,abstract java/lang/Object - <I:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;)V (TI;)V java/lang/Exception
in 0
class akka/japi/pf/FI$UnitApply2 50 public,interface,abstract java/lang/Object - <I1:Ljava/lang/Object;I2:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$UnitApply2 akka/japi/pf/FI UnitApply2 public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;)V (TI1;TI2;)V java/lang/Exception
in 0
class akka/japi/pf/FI$UnitApply3 50 public,interface,abstract java/lang/Object - <I1:Ljava/lang/Object;I2:Ljava/lang/Object;I3:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$UnitApply3 akka/japi/pf/FI UnitApply3 public,static,interface,abstract
 method public,abstract apply (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V (TI1;TI2;TI3;)V java/lang/Exception
in 0
class akka/japi/pf/FI$UnitApplyVoid 50 public,interface,abstract java/lang/Object - -
 inner akka/japi/pf/FI$UnitApplyVoid akka/japi/pf/FI UnitApplyVoid public,static,interface,abstract
 method public,abstract apply ()V - java/lang/Exception
in 0
class akka/japi/pf/FSMStateFunctionBuilder 50 public,super java/lang/Object - <S:Ljava/lang/Object;D:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/actor/FSM$Event akka/actor/FSM Event public,static
 inner akka/actor/FSM$State akka/actor/FSM State public,static
 inner akka/japi/pf/FI$TypedPredicate2 akka/japi/pf/FI TypedPredicate2 public,static,interface,abstract
 inner akka/japi/pf/FI$Apply2 akka/japi/pf/FI Apply2 public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 inner akka/japi/pf/FI$Apply akka/japi/pf/FI Apply public,static,interface,abstract
 method public <init> ()V - -
 method public,final event (Ljava/lang/Class;Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate2;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; <P:Ljava/lang/Object;Q:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Ljava/lang/Class<TQ;>;Lakka/japi/pf/FI$TypedPredicate2<TP;TQ;>;Lakka/japi/pf/FI$Apply2<TP;TQ;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public event (Ljava/lang/Class;Ljava/lang/Class;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; <P:Ljava/lang/Object;Q:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Ljava/lang/Class<TQ;>;Lakka/japi/pf/FI$Apply2<TP;TQ;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public event (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate2;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate2<TP;TD;>;Lakka/japi/pf/FI$Apply2<TP;TD;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public event (Ljava/lang/Class;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$Apply2<TP;TD;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public event (Lakka/japi/pf/FI$TypedPredicate2;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; (Lakka/japi/pf/FI$TypedPredicate2<Ljava/lang/Object;TD;>;Lakka/japi/pf/FI$Apply2<Ljava/lang/Object;TD;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public event (Ljava/util/List;Ljava/lang/Class;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; <Q:Ljava/lang/Object;>(Ljava/util/List<Ljava/lang/Object;>;Ljava/lang/Class<TQ;>;Lakka/japi/pf/FI$Apply2<Ljava/lang/Object;TQ;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public event (Ljava/util/List;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; (Ljava/util/List<Ljava/lang/Object;>;Lakka/japi/pf/FI$Apply2<Ljava/lang/Object;TD;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public eventEquals (Ljava/lang/Object;Ljava/lang/Class;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; <P:Ljava/lang/Object;Q:Ljava/lang/Object;>(TP;Ljava/lang/Class<TQ;>;Lakka/japi/pf/FI$Apply2<TP;TQ;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public eventEquals (Ljava/lang/Object;Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; <P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$Apply2<TP;TD;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public anyEvent (Lakka/japi/pf/FI$Apply2;)Lakka/japi/pf/FSMStateFunctionBuilder; (Lakka/japi/pf/FI$Apply2<Ljava/lang/Object;TD;Lakka/actor/FSM$State<TS;TD;>;>;)Lakka/japi/pf/FSMStateFunctionBuilder<TS;TD;>; -
 method public build ()Lscala/PartialFunction; ()Lscala/PartialFunction<Lakka/actor/FSM$Event<TD;>;Lakka/actor/FSM$State<TS;TD;>;>; -
in 0
class akka/japi/pf/FSMStopBuilder 50 public,super java/lang/Object - <S:Ljava/lang/Object;D:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/actor/FSM$StopEvent akka/actor/FSM StopEvent public,static
 inner akka/actor/FSM$Reason akka/actor/FSM Reason public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply2 akka/japi/pf/FI UnitApply2 public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply3 akka/japi/pf/FI UnitApply3 public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 method public <init> ()V - -
 method public stop (Lakka/actor/FSM$Reason;Lakka/japi/pf/FI$UnitApply2;)Lakka/japi/pf/FSMStopBuilder; (Lakka/actor/FSM$Reason;Lakka/japi/pf/FI$UnitApply2<TS;TD;>;)Lakka/japi/pf/FSMStopBuilder<TS;TD;>; -
 method public stop (Ljava/lang/Class;Lakka/japi/pf/FI$UnitApply3;)Lakka/japi/pf/FSMStopBuilder; <P::Lakka/actor/FSM$Reason;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$UnitApply3<TP;TS;TD;>;)Lakka/japi/pf/FSMStopBuilder<TS;TD;>; -
 method public stop (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$UnitApply3;)Lakka/japi/pf/FSMStopBuilder; <P::Lakka/actor/FSM$Reason;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$UnitApply3<TP;TS;TD;>;)Lakka/japi/pf/FSMStopBuilder<TS;TD;>; -
 method public build ()Lscala/PartialFunction; ()Lscala/PartialFunction<Lakka/actor/FSM$StopEvent<TS;TD;>;Lscala/runtime/BoxedUnit;>; -
in 0
class akka/japi/pf/FSMTransitionHandlerBuilder 50 public,super java/lang/Object - <S:Ljava/lang/Object;>Ljava/lang/Object;
 inner akka/japi/pf/FI$UnitApplyVoid akka/japi/pf/FI UnitApplyVoid public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply2 akka/japi/pf/FI UnitApply2 public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 method public <init> ()V - -
 method public state (Ljava/lang/Object;Ljava/lang/Object;Lakka/japi/pf/FI$UnitApplyVoid;)Lakka/japi/pf/FSMTransitionHandlerBuilder; (TS;TS;Lakka/japi/pf/FI$UnitApplyVoid;)Lakka/japi/pf/FSMTransitionHandlerBuilder<TS;>; -
 method public state (Ljava/lang/Object;Ljava/lang/Object;Lakka/japi/pf/FI$UnitApply2;)Lakka/japi/pf/FSMTransitionHandlerBuilder; (TS;TS;Lakka/japi/pf/FI$UnitApply2<TS;TS;>;)Lakka/japi/pf/FSMTransitionHandlerBuilder<TS;>; -
 method public build ()Lscala/PartialFunction; ()Lscala/PartialFunction<Lscala/Tuple2<TS;TS;>;Lscala/runtime/BoxedUnit;>; -
in 0
class akka/japi/pf/Match 50 public,super akka/japi/pf/AbstractMatch - <I:Ljava/lang/Object;R:Ljava/lang/Object;>Lakka/japi/pf/AbstractMatch<TI;TR;>;
 inner akka/japi/pf/FI$Apply akka/japi/pf/FI Apply public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 method public,static,final match (Ljava/lang/Class;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <F:Ljava/lang/Object;T:Ljava/lang/Object;P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$Apply<TP;TT;>;)Lakka/japi/pf/PFBuilder<TF;TT;>; -
 method public,static match (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <F:Ljava/lang/Object;T:Ljava/lang/Object;P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$Apply<TP;TT;>;)Lakka/japi/pf/PFBuilder<TF;TT;>; -
 method public,static matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <F:Ljava/lang/Object;T:Ljava/lang/Object;P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$Apply<TP;TT;>;)Lakka/japi/pf/PFBuilder<TF;TT;>; -
 method public,static matchAny (Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <F:Ljava/lang/Object;T:Ljava/lang/Object;>(Lakka/japi/pf/FI$Apply<Ljava/lang/Object;TT;>;)Lakka/japi/pf/PFBuilder<TF;TT;>; -
 method public,static,final create (Lakka/japi/pf/PFBuilder;)Lakka/japi/pf/Match; <F:Ljava/lang/Object;T:Ljava/lang/Object;>(Lakka/japi/pf/PFBuilder<TF;TT;>;)Lakka/japi/pf/Match<TF;TT;>; -
 method public match (Ljava/lang/Object;)Ljava/lang/Object; (TI;)TR; scala/MatchError
in 0
class akka/japi/pf/PFBuilder 50 public,final,super akka/japi/pf/AbstractPFBuilder - <I:Ljava/lang/Object;R:Ljava/lang/Object;>Lakka/japi/pf/AbstractPFBuilder<TI;TR;>;
 inner akka/japi/pf/FI$Apply akka/japi/pf/FI Apply public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 inner akka/japi/pf/FI$Predicate akka/japi/pf/FI Predicate static,interface,abstract
 method public <init> ()V - -
 method public match (Ljava/lang/Class;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$Apply<TP;TR;>;)Lakka/japi/pf/PFBuilder<TI;TR;>; -
 method public match (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$Apply<TP;TR;>;)Lakka/japi/pf/PFBuilder<TI;TR;>; -
 method public matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; <P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$Apply<TP;TR;>;)Lakka/japi/pf/PFBuilder<TI;TR;>; -
 method public matchAny (Lakka/japi/pf/FI$Apply;)Lakka/japi/pf/PFBuilder; (Lakka/japi/pf/FI$Apply<Ljava/lang/Object;TR;>;)Lakka/japi/pf/PFBuilder<TI;TR;>; -
in 0
class akka/japi/pf/ReceiveBuilder 50 public,super java/lang/Object - -
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 method public,static match (Ljava/lang/Class;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<Ljava/lang/Object;>; -
 method public,static match (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<Ljava/lang/Object;>; -
 method public,static matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<Ljava/lang/Object;>; -
 method public,static matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<Ljava/lang/Object;>; -
 method public,static matchAny (Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; (Lakka/japi/pf/FI$UnitApply<Ljava/lang/Object;>;)Lakka/japi/pf/UnitPFBuilder<Ljava/lang/Object;>; -
in 0
class akka/japi/pf/UnitCaseStatement 50 public,super java/lang/Object scala/PartialFunction <F:Ljava/lang/Object;P:Ljava/lang/Object;>Ljava/lang/Object;Lscala/PartialFunction<TF;Lscala/runtime/BoxedUnit;>;
 inner akka/japi/pf/FI$Predicate akka/japi/pf/FI Predicate public,static,interface,abstract
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 method public orElse (Lscala/PartialFunction;)Lscala/PartialFunction; <A1:TF;B1:Ljava/lang/Object;>(Lscala/PartialFunction<TA1;TB1;>;)Lscala/PartialFunction<TA1;TB1;>; -
 method public andThen (Lscala/Function1;)Lscala/PartialFunction; <C:Ljava/lang/Object;>(Lscala/Function1<Lscala/runtime/BoxedUnit;TC;>;)Lscala/PartialFunction<TF;TC;>; -
 method public lift ()Lscala/Function1; ()Lscala/Function1<TF;Lscala/Option<Lscala/runtime/BoxedUnit;>;>; -
 method public applyOrElse (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <A1:TF;B1:Ljava/lang/Object;>(TA1;Lscala/Function1<TA1;TB1;>;)TB1; -
 method public runWith (Lscala/Function1;)Lscala/Function1; <U:Ljava/lang/Object;>(Lscala/Function1<Lscala/runtime/BoxedUnit;TU;>;)Lscala/Function1<TF;Ljava/lang/Object;>; -
 method public apply$mcZD$sp (D)Z - -
 method public apply$mcDD$sp (D)D - -
 method public apply$mcFD$sp (D)F - -
 method public apply$mcID$sp (D)I - -
 method public apply$mcJD$sp (D)J - -
 method public apply$mcVD$sp (D)V - -
 method public apply$mcZF$sp (F)Z - -
 method public apply$mcDF$sp (F)D - -
 method public apply$mcFF$sp (F)F - -
 method public apply$mcIF$sp (F)I - -
 method public apply$mcJF$sp (F)J - -
 method public apply$mcVF$sp (F)V - -
 method public apply$mcZI$sp (I)Z - -
 method public apply$mcDI$sp (I)D - -
 method public apply$mcFI$sp (I)F - -
 method public apply$mcII$sp (I)I - -
 method public apply$mcJI$sp (I)J - -
 method public apply$mcVI$sp (I)V - -
 method public apply$mcZJ$sp (J)Z - -
 method public apply$mcDJ$sp (J)D - -
 method public apply$mcFJ$sp (J)F - -
 method public apply$mcIJ$sp (J)I - -
 method public apply$mcJJ$sp (J)J - -
 method public apply$mcVJ$sp (J)V - -
 method public compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;TF;>;)Lscala/Function1<TA;Lscala/runtime/BoxedUnit;>; -
 method public toString ()Ljava/lang/String; - -
 method public isDefinedAt (Ljava/lang/Object;)Z (TF;)Z -
 method public apply (Ljava/lang/Object;)V (TF;)V -
 method public <init> (Lakka/japi/pf/FI$Predicate;Lakka/japi/pf/FI$UnitApply;)V (Lakka/japi/pf/FI$Predicate;Lakka/japi/pf/FI$UnitApply<TP;>;)V -
in 0
class akka/japi/pf/UnitMatch 50 public,super akka/japi/pf/AbstractMatch - <I:Ljava/lang/Object;>Lakka/japi/pf/AbstractMatch<TI;Lscala/runtime/BoxedUnit;>;
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 method public,static,final match (Ljava/lang/Class;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <F:Ljava/lang/Object;P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TF;>; -
 method public,static match (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <F:Ljava/lang/Object;P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TF;>; -
 method public,static matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <F:Ljava/lang/Object;P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TF;>; -
 method public,static matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <F:Ljava/lang/Object;P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TF;>; -
 method public,static matchAny (Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <F:Ljava/lang/Object;>(Lakka/japi/pf/FI$UnitApply<Ljava/lang/Object;>;)Lakka/japi/pf/UnitPFBuilder<TF;>; -
 method public,static create (Lakka/japi/pf/UnitPFBuilder;)Lakka/japi/pf/UnitMatch; <F:Ljava/lang/Object;>(Lakka/japi/pf/UnitPFBuilder<TF;>;)Lakka/japi/pf/UnitMatch<TF;>; -
 method public match (Ljava/lang/Object;)V (TI;)V scala/MatchError
in 0
class akka/japi/pf/UnitPFBuilder 50 public,final,super akka/japi/pf/AbstractPFBuilder - <I:Ljava/lang/Object;>Lakka/japi/pf/AbstractPFBuilder<TI;Lscala/runtime/BoxedUnit;>;
 inner akka/japi/pf/FI$UnitApply akka/japi/pf/FI UnitApply public,static,interface,abstract
 inner akka/japi/pf/FI$TypedPredicate akka/japi/pf/FI TypedPredicate public,static,interface,abstract
 inner akka/japi/pf/FI$Predicate akka/japi/pf/FI Predicate static,interface,abstract
 method public <init> ()V - -
 method public match (Ljava/lang/Class;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TI;>; -
 method public match (Ljava/lang/Class;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(Ljava/lang/Class<TP;>;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TI;>; -
 method public matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TI;>; -
 method public matchEquals (Ljava/lang/Object;Lakka/japi/pf/FI$TypedPredicate;Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; <P:Ljava/lang/Object;>(TP;Lakka/japi/pf/FI$TypedPredicate<TP;>;Lakka/japi/pf/FI$UnitApply<TP;>;)Lakka/japi/pf/UnitPFBuilder<TI;>; -
 method public matchAny (Lakka/japi/pf/FI$UnitApply;)Lakka/japi/pf/UnitPFBuilder; (Lakka/japi/pf/FI$UnitApply<Ljava/lang/Object;>;)Lakka/japi/pf/UnitPFBuilder<TI;>; -
