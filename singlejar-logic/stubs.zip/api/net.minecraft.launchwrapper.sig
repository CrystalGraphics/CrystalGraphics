cg-stub-db 1
in 0
class net/minecraft/launchwrapper/AlphaVanillaTweaker 50 public,super java/lang/Object net/minecraft/launchwrapper/ITweaker -
 method public <init> ()V - -
 method public acceptOptions (Ljava/util/List;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V -
 method public injectIntoClassLoader (Lnet/minecraft/launchwrapper/LaunchClassLoader;)V - -
 method public getLaunchTarget ()Ljava/lang/String; - -
 method public getLaunchArguments ()[Ljava/lang/String; - -
in 0
class net/minecraft/launchwrapper/IClassNameTransformer 50 public,interface,abstract java/lang/Object - -
 method public,abstract unmapClassName (Ljava/lang/String;)Ljava/lang/String; - -
 method public,abstract remapClassName (Ljava/lang/String;)Ljava/lang/String; - -
in 0
class net/minecraft/launchwrapper/IClassTransformer 50 public,interface,abstract java/lang/Object - -
 method public,abstract transform (Ljava/lang/String;Ljava/lang/String;[B)[B - -
in 0
class net/minecraft/launchwrapper/ITweaker 50 public,interface,abstract java/lang/Object - -
 method public,abstract acceptOptions (Ljava/util/List;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V -
 method public,abstract injectIntoClassLoader (Lnet/minecraft/launchwrapper/LaunchClassLoader;)V - -
 method public,abstract getLaunchTarget ()Ljava/lang/String; - -
 method public,abstract getLaunchArguments ()[Ljava/lang/String; - -
in 0
class net/minecraft/launchwrapper/IndevVanillaTweaker 50 public,super java/lang/Object net/minecraft/launchwrapper/ITweaker -
 method public <init> ()V - -
 method public acceptOptions (Ljava/util/List;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V -
 method public injectIntoClassLoader (Lnet/minecraft/launchwrapper/LaunchClassLoader;)V - -
 method public getLaunchTarget ()Ljava/lang/String; - -
 method public getLaunchArguments ()[Ljava/lang/String; - -
in 0
class net/minecraft/launchwrapper/Launch 50 public,super java/lang/Object - -
 field public,static minecraftHome Ljava/io/File; -
 field public,static assetsDir Ljava/io/File; -
 field public,static blackboard Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;
 field public,static classLoader Lnet/minecraft/launchwrapper/LaunchClassLoader; -
 method public,static main ([Ljava/lang/String;)V - -
in 0
class net/minecraft/launchwrapper/LaunchClassLoader 50 public,super java/net/URLClassLoader - -
 inner java/util/jar/Attributes$Name java/util/jar/Attributes Name public,static
 field public,static,final BUFFER_SIZE I - I4096
 method public <init> ([Ljava/net/URL;)V - -
 method public registerTransformer (Ljava/lang/String;)V - -
 method public findClass (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<*>; java/lang/ClassNotFoundException
 method public addURL (Ljava/net/URL;)V - -
 method public getSources ()Ljava/util/List; ()Ljava/util/List<Ljava/net/URL;>; -
 method public getTransformers ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/launchwrapper/IClassTransformer;>; -
 method public addClassLoaderExclusion (Ljava/lang/String;)V - -
 method public addTransformerExclusion (Ljava/lang/String;)V - -
 method public getClassBytes (Ljava/lang/String;)[B - java/io/IOException
 method public clearNegativeEntries (Ljava/util/Set;)V (Ljava/util/Set<Ljava/lang/String;>;)V -
in 0
class net/minecraft/launchwrapper/LogWrapper 50 public,super java/lang/Object - -
 field public,static log Lnet/minecraft/launchwrapper/LogWrapper; -
 method public <init> ()V - -
 method public,static retarget (Lorg/apache/logging/log4j/Logger;)V - -
 method public,static,varargs log (Ljava/lang/String;Lorg/apache/logging/log4j/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs log (Lorg/apache/logging/log4j/Level;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs log (Ljava/lang/String;Lorg/apache/logging/log4j/Level;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs log (Lorg/apache/logging/log4j/Level;Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs severe (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs warning (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs info (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs fine (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs finer (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static,varargs finest (Ljava/lang/String;[Ljava/lang/Object;)V - -
 method public,static makeLog (Ljava/lang/String;)V - -
in 0
class net/minecraft/launchwrapper/VanillaTweaker 50 public,super java/lang/Object net/minecraft/launchwrapper/ITweaker -
 method public <init> ()V - -
 method public acceptOptions (Ljava/util/List;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V (Ljava/util/List<Ljava/lang/String;>;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V -
 method public injectIntoClassLoader (Lnet/minecraft/launchwrapper/LaunchClassLoader;)V - -
 method public getLaunchTarget ()Ljava/lang/String; - -
 method public getLaunchArguments ()[Ljava/lang/String; - -
in 0
class net/minecraft/launchwrapper/injector/AlphaVanillaTweakInjector 50 public,super java/lang/Object net/minecraft/launchwrapper/IClassTransformer -
 method public <init> ()V - -
 method public transform (Ljava/lang/String;Ljava/lang/String;[B)[B - -
 method public,static main ([Ljava/lang/String;)V - java/lang/ClassNotFoundException,java/lang/NoSuchMethodException,java/lang/IllegalAccessException,java/lang/reflect/InvocationTargetException,java/lang/InstantiationException
in 0
class net/minecraft/launchwrapper/injector/IndevVanillaTweakInjector 50 public,super java/lang/Object net/minecraft/launchwrapper/IClassTransformer -
 method public <init> ()V - -
 method public transform (Ljava/lang/String;Ljava/lang/String;[B)[B - -
 method public,static inject ()Ljava/io/File; - -
in 0
class net/minecraft/launchwrapper/injector/VanillaTweakInjector 50 public,super java/lang/Object net/minecraft/launchwrapper/IClassTransformer -
 method public <init> ()V - -
 method public transform (Ljava/lang/String;Ljava/lang/String;[B)[B - -
 method public,static inject ()Ljava/io/File; - -
 method public,static loadIconsOnFrames ()V - -
