cg-stub-db 1
in 90
class net/minecraft/event/ClickEvent 50 public,super java/lang/Object - -
 inner net/minecraft/event/ClickEvent$Action net/minecraft/event/ClickEvent Action public,static,final,enum
 method public <init> (Lnet/minecraft/event/ClickEvent$Action;Ljava/lang/String;)V - -
 method public getAction ()Lnet/minecraft/event/ClickEvent$Action; - -
 method public getValue ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public hashCode ()I - -
in 90
class net/minecraft/event/ClickEvent$Action 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/event/ClickEvent$Action;>;
 inner net/minecraft/event/ClickEvent$Action net/minecraft/event/ClickEvent Action public,static,final,enum
 field public,static,final,enum OPEN_URL Lnet/minecraft/event/ClickEvent$Action; -
 field public,static,final,enum OPEN_FILE Lnet/minecraft/event/ClickEvent$Action; -
 field public,static,final,enum RUN_COMMAND Lnet/minecraft/event/ClickEvent$Action; -
 field public,static,final,enum TWITCH_USER_INFO Lnet/minecraft/event/ClickEvent$Action; -
 field public,static,final,enum SUGGEST_COMMAND Lnet/minecraft/event/ClickEvent$Action; -
 field public,static,final,enum CHANGE_PAGE Lnet/minecraft/event/ClickEvent$Action; -
 method public,static values ()[Lnet/minecraft/event/ClickEvent$Action; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/event/ClickEvent$Action; - -
 method public shouldAllowInChat ()Z - -
 method public getCanonicalName ()Ljava/lang/String; - -
 method public,static getValueByCanonicalName (Ljava/lang/String;)Lnet/minecraft/event/ClickEvent$Action; - -
in 90
class net/minecraft/event/HoverEvent 50 public,super java/lang/Object - -
 inner net/minecraft/event/HoverEvent$Action net/minecraft/event/HoverEvent Action public,static,final,enum
 method public <init> (Lnet/minecraft/event/HoverEvent$Action;Lnet/minecraft/util/IChatComponent;)V - -
 method public getAction ()Lnet/minecraft/event/HoverEvent$Action; - -
 method public getValue ()Lnet/minecraft/util/IChatComponent; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public hashCode ()I - -
in 90
class net/minecraft/event/HoverEvent$Action 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/event/HoverEvent$Action;>;
 inner net/minecraft/event/HoverEvent$Action net/minecraft/event/HoverEvent Action public,static,final,enum
 field public,static,final,enum SHOW_TEXT Lnet/minecraft/event/HoverEvent$Action; -
 field public,static,final,enum SHOW_ACHIEVEMENT Lnet/minecraft/event/HoverEvent$Action; -
 field public,static,final,enum SHOW_ITEM Lnet/minecraft/event/HoverEvent$Action; -
 field public,static,final,enum SHOW_ENTITY Lnet/minecraft/event/HoverEvent$Action; -
 method public,static values ()[Lnet/minecraft/event/HoverEvent$Action; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/event/HoverEvent$Action; - -
 method public shouldAllowInChat ()Z - -
 method public getCanonicalName ()Ljava/lang/String; - -
 method public,static getValueByCanonicalName (Ljava/lang/String;)Lnet/minecraft/event/HoverEvent$Action; - -
