cg-stub-db 1
in 0
class akka/routing/ActorRefRoutee 50 public,super java/lang/Object akka/routing/Routee,scala/Product,scala/Serializable -
 method public,static unapply (Lakka/routing/ActorRefRoutee;)Lscala/Option; (Lakka/routing/ActorRefRoutee;)Lscala/Option<Lakka/actor/ActorRef;>; -
 method public,static apply (Lakka/actor/ActorRef;)Lakka/routing/ActorRefRoutee; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/ActorRefRoutee;TA;>;)Lscala/Function1<Lakka/actor/ActorRef;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lakka/actor/ActorRef;>;)Lscala/Function1<TA;Lakka/routing/ActorRefRoutee;>; -
 method public ref ()Lakka/actor/ActorRef; - -
 method public send (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
 method public copy (Lakka/actor/ActorRef;)Lakka/routing/ActorRefRoutee; - -
 method public copy$default$1 ()Lakka/actor/ActorRef; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/actor/ActorRef;)V - -
in 0
class akka/routing/ActorRefRoutee$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lakka/actor/ActorRef;Lakka/routing/ActorRefRoutee;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ActorRefRoutee$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/actor/ActorRef;)Lakka/routing/ActorRefRoutee; - -
 method public unapply (Lakka/routing/ActorRefRoutee;)Lscala/Option; (Lakka/routing/ActorRefRoutee;)Lscala/Option<Lakka/actor/ActorRef;>; -
in 0
class akka/routing/ActorSelectionRoutee 50 public,super java/lang/Object akka/routing/Routee,scala/Product,scala/Serializable -
 method public,static unapply (Lakka/routing/ActorSelectionRoutee;)Lscala/Option; (Lakka/routing/ActorSelectionRoutee;)Lscala/Option<Lakka/actor/ActorSelection;>; -
 method public,static apply (Lakka/actor/ActorSelection;)Lakka/routing/ActorSelectionRoutee; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/ActorSelectionRoutee;TA;>;)Lscala/Function1<Lakka/actor/ActorSelection;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lakka/actor/ActorSelection;>;)Lscala/Function1<TA;Lakka/routing/ActorSelectionRoutee;>; -
 method public selection ()Lakka/actor/ActorSelection; - -
 method public send (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
 method public copy (Lakka/actor/ActorSelection;)Lakka/routing/ActorSelectionRoutee; - -
 method public copy$default$1 ()Lakka/actor/ActorSelection; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/actor/ActorSelection;)V - -
in 0
class akka/routing/ActorSelectionRoutee$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lakka/actor/ActorSelection;Lakka/routing/ActorSelectionRoutee;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ActorSelectionRoutee$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/actor/ActorSelection;)Lakka/routing/ActorSelectionRoutee; - -
 method public unapply (Lakka/routing/ActorSelectionRoutee;)Lscala/Option; (Lakka/routing/ActorSelectionRoutee;)Lscala/Option<Lakka/actor/ActorSelection;>; -
in 0
class akka/routing/AddRoutee 50 public,super java/lang/Object akka/routing/RouterManagementMesssage,scala/Product,scala/Serializable -
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/AddRoutee;)Lscala/Option; (Lakka/routing/AddRoutee;)Lscala/Option<Lakka/routing/Routee;>; -
 method public,static apply (Lakka/routing/Routee;)Lakka/routing/AddRoutee; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/AddRoutee;TA;>;)Lscala/Function1<Lakka/routing/Routee;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lakka/routing/Routee;>;)Lscala/Function1<TA;Lakka/routing/AddRoutee;>; -
 method public routee ()Lakka/routing/Routee; - -
 method public copy (Lakka/routing/Routee;)Lakka/routing/AddRoutee; - -
 method public copy$default$1 ()Lakka/routing/Routee; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/routing/Routee;)V - -
in 0
class akka/routing/AddRoutee$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lakka/routing/Routee;Lakka/routing/AddRoutee;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/AddRoutee$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/routing/Routee;)Lakka/routing/AddRoutee; - -
 method public unapply (Lakka/routing/AddRoutee;)Lscala/Option; (Lakka/routing/AddRoutee;)Lscala/Option<Lakka/routing/Routee;>; -
in 0
class akka/routing/AdjustPoolSize 50 public,super java/lang/Object akka/routing/RouterManagementMesssage,scala/Product,scala/Serializable -
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/AdjustPoolSize;)Lscala/Option; (Lakka/routing/AdjustPoolSize;)Lscala/Option<Ljava/lang/Object;>; -
 method public,static apply (I)Lakka/routing/AdjustPoolSize; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/AdjustPoolSize;TA;>;)Lscala/Function1<Ljava/lang/Object;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/Object;>;)Lscala/Function1<TA;Lakka/routing/AdjustPoolSize;>; -
 method public change ()I - -
 method public copy (I)Lakka/routing/AdjustPoolSize; - -
 method public copy$default$1 ()I - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (I)V - -
in 0
class akka/routing/AdjustPoolSize$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/Object;Lakka/routing/AdjustPoolSize;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/AdjustPoolSize$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (I)Lakka/routing/AdjustPoolSize; - -
 method public unapply (Lakka/routing/AdjustPoolSize;)Lscala/Option; (Lakka/routing/AdjustPoolSize;)Lscala/Option<Ljava/lang/Object;>; -
in 0
class akka/routing/BalancingPool 50 public,final,super java/lang/Object akka/routing/Pool,scala/Product -
 inner akka/actor/ActorSystem$Settings akka/actor/ActorSystem Settings public,static
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$3 ()Ljava/lang/String; - -
 method public,static apply$default$2 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$3 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$2 ()Lakka/actor/SupervisorStrategy; - -
 method public,static unapply (Lakka/routing/BalancingPool;)Lscala/Option; (Lakka/routing/BalancingPool;)Lscala/Option<Lscala/Tuple3<Ljava/lang/Object;Lakka/actor/SupervisorStrategy;Ljava/lang/String;>;>; -
 method public,static apply (ILakka/actor/SupervisorStrategy;Ljava/lang/String;)Lakka/routing/BalancingPool; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple3<Ljava/lang/Object;Lakka/actor/SupervisorStrategy;Ljava/lang/String;>;Lakka/routing/BalancingPool;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lakka/actor/SupervisorStrategy;Lscala/Function1<Ljava/lang/String;Lakka/routing/BalancingPool;>;>;>; -
 method public usePoolDispatcher ()Z - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/BalancingPool; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/BalancingPool; - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy (ILakka/actor/SupervisorStrategy;Ljava/lang/String;)Lakka/routing/BalancingPool; - -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$3 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILakka/actor/SupervisorStrategy;Ljava/lang/String;)V - -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (I)V - -
in 0
class akka/routing/BalancingPool$ 50 public,final,super scala/runtime/AbstractFunction3 scala/Serializable Lscala/runtime/AbstractFunction3<Ljava/lang/Object;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Lakka/routing/BalancingPool;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/BalancingPool$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILakka/actor/SupervisorStrategy;Ljava/lang/String;)Lakka/routing/BalancingPool; - -
 method public unapply (Lakka/routing/BalancingPool;)Lscala/Option; (Lakka/routing/BalancingPool;)Lscala/Option<Lscala/Tuple3<Ljava/lang/Object;Lakka/actor/SupervisorStrategy;Ljava/lang/String;>;>; -
 method public $lessinit$greater$default$2 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$3 ()Ljava/lang/String; - -
 method public apply$default$2 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$3 ()Ljava/lang/String; - -
in 0
class akka/routing/BalancingRoutingLogic 50 public,final,super java/lang/Object akka/routing/RoutingLogic -
 field public,static,final serialVersionUID J - J1
 method public,static apply ()Lakka/routing/BalancingRoutingLogic; - -
 method public select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
 method public <init> ()V - -
in 0
class akka/routing/BalancingRoutingLogic$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lakka/routing/BalancingRoutingLogic$; -
 method public,static <clinit> ()V - -
 method public apply ()Lakka/routing/BalancingRoutingLogic; - -
in 0
class akka/routing/Broadcast 50 public,super java/lang/Object akka/routing/RouterEnvelope,scala/Product,scala/Serializable -
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/Broadcast;)Lscala/Option; (Lakka/routing/Broadcast;)Lscala/Option<Ljava/lang/Object;>; -
 method public,static apply (Ljava/lang/Object;)Lakka/routing/Broadcast; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/Broadcast;TA;>;)Lscala/Function1<Ljava/lang/Object;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/Object;>;)Lscala/Function1<TA;Lakka/routing/Broadcast;>; -
 method public message ()Ljava/lang/Object; - -
 method public copy (Ljava/lang/Object;)Lakka/routing/Broadcast; - -
 method public copy$default$1 ()Ljava/lang/Object; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/Object;)V - -
in 0
class akka/routing/Broadcast$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/Object;Lakka/routing/Broadcast;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/Broadcast$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/Object;)Lakka/routing/Broadcast; - -
 method public unapply (Lakka/routing/Broadcast;)Lscala/Option; (Lakka/routing/Broadcast;)Lscala/Option<Ljava/lang/Object;>; -
in 0
class akka/routing/BroadcastGroup 50 public,final,super java/lang/Object akka/routing/Group,scala/Product -
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$2 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$2 ()Ljava/lang/String; - -
 method public,static unapply (Lakka/routing/BroadcastGroup;)Lscala/Option; (Lakka/routing/BroadcastGroup;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;>; -
 method public,static apply (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/BroadcastGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/BroadcastGroup; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;Lakka/routing/BroadcastGroup;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Function1<Ljava/lang/String;Lakka/routing/BroadcastGroup;>;>; -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/BroadcastGroup; - -
 method public copy (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/BroadcastGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/BroadcastGroup; -
 method public copy$default$1 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/Iterable;Ljava/lang/String;)V (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
in 0
class akka/routing/BroadcastGroup$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;Lakka/routing/BroadcastGroup;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/BroadcastGroup$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/BroadcastGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/BroadcastGroup; -
 method public unapply (Lakka/routing/BroadcastGroup;)Lscala/Option; (Lakka/routing/BroadcastGroup;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;>; -
 method public $lessinit$greater$default$2 ()Ljava/lang/String; - -
 method public apply$default$2 ()Ljava/lang/String; - -
in 0
class akka/routing/BroadcastPool 50 public,final,super java/lang/Object akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/Pool;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/BroadcastPool;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$5 ()Z - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$5 ()Z - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static unapply (Lakka/routing/BroadcastPool;)Lscala/Option; (Lakka/routing/BroadcastPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public,static apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/BroadcastPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/BroadcastPool; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;Lakka/routing/BroadcastPool;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/Option<Lakka/routing/Resizer;>;Lscala/Function1<Lakka/actor/SupervisorStrategy;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/Object;Lakka/routing/BroadcastPool;>;>;>;>;>; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public usePoolDispatcher ()Z - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastPool; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/BroadcastPool; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/BroadcastPool; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public copy (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/BroadcastPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/BroadcastPool; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Z - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (I)V - -
in 0
class akka/routing/BroadcastPool$ 50 public,final,super scala/runtime/AbstractFunction5 scala/Serializable Lscala/runtime/AbstractFunction5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;Lakka/routing/BroadcastPool;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/BroadcastPool$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/BroadcastPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/BroadcastPool; -
 method public unapply (Lakka/routing/BroadcastPool;)Lscala/Option; (Lakka/routing/BroadcastPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Z - -
 method public apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Z - -
in 0
class akka/routing/BroadcastRouter 50 public,super,deprecated java/lang/Object akka/routing/DeprecatedRouterConfig,akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/DeprecatedRouterConfig;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/BroadcastRouter;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static apply$default$1 ()I - -
 method public,static $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static $lessinit$greater$default$1 ()I - -
 method public,static unapply (Lakka/routing/BroadcastRouter;)Lscala/Option; (Lakka/routing/BroadcastRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public,static apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastRouter; -
 method public,static create (Ljava/lang/Iterable;)Lakka/routing/BroadcastRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/BroadcastRouter; -
 method public,static apply (Lscala/collection/immutable/Iterable;)Lakka/routing/BroadcastRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/BroadcastRouter; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public routees ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/BroadcastRouter; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastRouter; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/BroadcastRouter; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public copy (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastRouter; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V -
 method public <init> (I)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
 method public <init> (Lakka/routing/Resizer;)V - -
in 0
class akka/routing/BroadcastRouter$ 50 public,final,super,deprecated java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/BroadcastRouter$; -
 method public,static <clinit> ()V - -
 method public apply (Lscala/collection/immutable/Iterable;)Lakka/routing/BroadcastRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/BroadcastRouter; -
 method public apply$default$1 ()I - -
 method public apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public create (Ljava/lang/Iterable;)Lakka/routing/BroadcastRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/BroadcastRouter; -
 method public apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/BroadcastRouter; -
 method public unapply (Lakka/routing/BroadcastRouter;)Lscala/Option; (Lakka/routing/BroadcastRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public $lessinit$greater$default$1 ()I - -
 method public $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
in 0
class akka/routing/BroadcastRoutingLogic 50 public,final,super java/lang/Object akka/routing/RoutingLogic -
 field public,static,final serialVersionUID J - J1
 method public,static apply ()Lakka/routing/BroadcastRoutingLogic; - -
 method public select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
 method public <init> ()V - -
in 0
class akka/routing/BroadcastRoutingLogic$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lakka/routing/BroadcastRoutingLogic$; -
 method public,static <clinit> ()V - -
 method public apply ()Lakka/routing/BroadcastRoutingLogic; - -
in 0
class akka/routing/CollectRouteeRefs 50 public,super java/lang/Object akka/actor/Actor -
 inner scala/concurrent/duration/package$DurationInt scala/concurrent/duration/package DurationInt public,static,final
 field public,final akka$routing$CollectRouteeRefs$$routees Lscala/collection/immutable/IndexedSeq; Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;
 method public context ()Lakka/actor/ActorContext; - -
 method public,final self ()Lakka/actor/ActorRef; - -
 method public akka$actor$Actor$_setter_$context_$eq (Lakka/actor/ActorContext;)V - -
 method public,final akka$actor$Actor$_setter_$self_$eq (Lakka/actor/ActorRef;)V - -
 method public,final sender ()Lakka/actor/ActorRef; - -
 method public aroundReceive (Lscala/PartialFunction;Ljava/lang/Object;)V (Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>;Ljava/lang/Object;)V -
 method public aroundPreStart ()V - -
 method public aroundPostStop ()V - -
 method public aroundPreRestart (Ljava/lang/Throwable;Lscala/Option;)V (Ljava/lang/Throwable;Lscala/Option<Ljava/lang/Object;>;)V -
 method public aroundPostRestart (Ljava/lang/Throwable;)V - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public preStart ()V - java/lang/Exception
 method public postStop ()V - java/lang/Exception
 method public preRestart (Ljava/lang/Throwable;Lscala/Option;)V (Ljava/lang/Throwable;Lscala/Option<Ljava/lang/Object;>;)V java/lang/Exception
 method public postRestart (Ljava/lang/Throwable;)V - java/lang/Exception
 method public unhandled (Ljava/lang/Object;)V - -
 method public collected ()Lscala/collection/immutable/Vector; ()Lscala/collection/immutable/Vector<Lakka/actor/ActorRef;>; -
 method public collected_$eq (Lscala/collection/immutable/Vector;)V (Lscala/collection/immutable/Vector<Lakka/actor/ActorRef;>;)V -
 method public count ()I - -
 method public count_$eq (I)V - -
 method public receive ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public done ()V - -
 method public <init> (Lscala/collection/immutable/IndexedSeq;Lakka/actor/ActorRef;)V (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lakka/actor/ActorRef;)V -
in 0
class akka/routing/ConsistentActorRef 50 public,super,deprecated java/lang/Object scala/Product,scala/Serializable -
 method public,static unapply (Lakka/routing/ConsistentActorRef;)Lscala/Option; (Lakka/routing/ConsistentActorRef;)Lscala/Option<Lscala/Tuple2<Lakka/actor/ActorRef;Lakka/actor/Address;>;>; -
 method public,static apply (Lakka/actor/ActorRef;Lakka/actor/Address;)Lakka/routing/ConsistentActorRef; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lakka/actor/ActorRef;Lakka/actor/Address;>;Lakka/routing/ConsistentActorRef;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lakka/actor/ActorRef;Lscala/Function1<Lakka/actor/Address;Lakka/routing/ConsistentActorRef;>;>; -
 method public actorRef ()Lakka/actor/ActorRef; - -
 method public selfAddress ()Lakka/actor/Address; - -
 method public toString ()Ljava/lang/String; - -
 method public copy (Lakka/actor/ActorRef;Lakka/actor/Address;)Lakka/routing/ConsistentActorRef; - -
 method public copy$default$1 ()Lakka/actor/ActorRef; - -
 method public copy$default$2 ()Lakka/actor/Address; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/actor/ActorRef;Lakka/actor/Address;)V - -
in 0
class akka/routing/ConsistentActorRef$ 50 public,final,super,deprecated scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lakka/actor/ActorRef;Lakka/actor/Address;Lakka/routing/ConsistentActorRef;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ConsistentActorRef$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/actor/ActorRef;Lakka/actor/Address;)Lakka/routing/ConsistentActorRef; - -
 method public unapply (Lakka/routing/ConsistentActorRef;)Lscala/Option; (Lakka/routing/ConsistentActorRef;)Lscala/Option<Lscala/Tuple2<Lakka/actor/ActorRef;Lakka/actor/Address;>;>; -
in 0
class akka/routing/ConsistentHash 50 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner scala/collection/immutable/Range$Inclusive scala/collection/immutable/Range Inclusive public,static
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public,static create (Ljava/lang/Iterable;I)Lakka/routing/ConsistentHash; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;I)Lakka/routing/ConsistentHash<TT;>; -
 method public,static apply (Lscala/collection/Iterable;ILscala/reflect/ClassTag;)Lakka/routing/ConsistentHash; <T:Ljava/lang/Object;>(Lscala/collection/Iterable<TT;>;ILscala/reflect/ClassTag<TT;>;)Lakka/routing/ConsistentHash<TT;>; -
 method public virtualNodesFactor ()I - -
 method public $colon$plus (Ljava/lang/Object;)Lakka/routing/ConsistentHash; (TT;)Lakka/routing/ConsistentHash<TT;>; -
 method public add (Ljava/lang/Object;)Lakka/routing/ConsistentHash; (TT;)Lakka/routing/ConsistentHash<TT;>; -
 method public $colon$minus (Ljava/lang/Object;)Lakka/routing/ConsistentHash; (TT;)Lakka/routing/ConsistentHash<TT;>; -
 method public remove (Ljava/lang/Object;)Lakka/routing/ConsistentHash; (TT;)Lakka/routing/ConsistentHash<TT;>; -
 method public nodeFor ([B)Ljava/lang/Object; ([B)TT; -
 method public nodeFor (Ljava/lang/String;)Ljava/lang/Object; (Ljava/lang/String;)TT; -
 method public isEmpty ()Z - -
 method public <init> (Lscala/collection/immutable/SortedMap;ILscala/reflect/ClassTag;)V (Lscala/collection/immutable/SortedMap<Ljava/lang/Object;TT;>;ILscala/reflect/ClassTag<TT;>;)V -
in 0
class akka/routing/ConsistentHash$ 50 public,final,super java/lang/Object - -
 inner scala/math/Ordering$Int$ scala/math/Ordering Int$ public,static
 inner scala/collection/convert/Decorators$AsScala scala/collection/convert/Decorators AsScala public
 field public,static,final MODULE$ Lakka/routing/ConsistentHash$; -
 method public,static <clinit> ()V - -
 method public apply (Lscala/collection/Iterable;ILscala/reflect/ClassTag;)Lakka/routing/ConsistentHash; <T:Ljava/lang/Object;>(Lscala/collection/Iterable<TT;>;ILscala/reflect/ClassTag<TT;>;)Lakka/routing/ConsistentHash<TT;>; -
 method public create (Ljava/lang/Iterable;I)Lakka/routing/ConsistentHash; <T:Ljava/lang/Object;>(Ljava/lang/Iterable<TT;>;I)Lakka/routing/ConsistentHash<TT;>; -
 method public akka$routing$ConsistentHash$$concatenateNodeHash (II)I - -
 method public akka$routing$ConsistentHash$$hashFor ([B)I - -
 method public akka$routing$ConsistentHash$$hashFor (Ljava/lang/String;)I - -
in 0
class akka/routing/ConsistentHashingGroup 50 public,final,super java/lang/Object akka/routing/Group,scala/Product -
 inner akka/routing/ConsistentHashingRouter$ConsistentHashMapper akka/routing/ConsistentHashingRouter ConsistentHashMapper public,static,interface,abstract
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static apply$default$2 ()I - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static $lessinit$greater$default$2 ()I - -
 method public,static unapply (Lakka/routing/ConsistentHashingGroup;)Lscala/Option; (Lakka/routing/ConsistentHashingGroup;)Lscala/Option<Lscala/Tuple4<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;>;>; -
 method public,static apply (Lscala/collection/immutable/Iterable;ILscala/PartialFunction;Ljava/lang/String;)Lakka/routing/ConsistentHashingGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;)Lakka/routing/ConsistentHashingGroup; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple4<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;>;Lakka/routing/ConsistentHashingGroup;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lscala/Function1<Ljava/lang/String;Lakka/routing/ConsistentHashingGroup;>;>;>;>; -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public virtualNodesFactor ()I - -
 method public hashMapping ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/ConsistentHashingGroup; - -
 method public withVirtualNodesFactor (I)Lakka/routing/ConsistentHashingGroup; - -
 method public withHashMapper (Lakka/routing/ConsistentHashingRouter$ConsistentHashMapper;)Lakka/routing/ConsistentHashingGroup; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public copy (Lscala/collection/immutable/Iterable;ILscala/PartialFunction;Ljava/lang/String;)Lakka/routing/ConsistentHashingGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;)Lakka/routing/ConsistentHashingGroup; -
 method public copy$default$1 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$2 ()I - -
 method public copy$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/Iterable;ILscala/PartialFunction;Ljava/lang/String;)V (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
in 0
class akka/routing/ConsistentHashingGroup$ 50 public,final,super scala/runtime/AbstractFunction4 scala/Serializable Lscala/runtime/AbstractFunction4<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;Lakka/routing/ConsistentHashingGroup;>;Lscala/Serializable;
 inner akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ akka/routing/ConsistentHashingRouter emptyConsistentHashMapping$ public,static
 field public,static,final MODULE$ Lakka/routing/ConsistentHashingGroup$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/Iterable;ILscala/PartialFunction;Ljava/lang/String;)Lakka/routing/ConsistentHashingGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;)Lakka/routing/ConsistentHashingGroup; -
 method public unapply (Lakka/routing/ConsistentHashingGroup;)Lscala/Option; (Lakka/routing/ConsistentHashingGroup;)Lscala/Option<Lscala/Tuple4<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/String;>;>; -
 method public $lessinit$greater$default$2 ()I - -
 method public $lessinit$greater$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public apply$default$2 ()I - -
 method public apply$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public apply$default$4 ()Ljava/lang/String; - -
in 0
class akka/routing/ConsistentHashingPool 50 public,final,super java/lang/Object akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/Pool;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/ConsistentHashingPool;>;Lscala/Product;Lscala/Serializable;
 inner akka/routing/ConsistentHashingRouter$ConsistentHashMapper akka/routing/ConsistentHashingRouter ConsistentHashMapper public,static,interface,abstract
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$7 ()Z - -
 method public,static apply$default$6 ()Ljava/lang/String; - -
 method public,static apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$4 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static apply$default$3 ()I - -
 method public,static apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$7 ()Z - -
 method public,static $lessinit$greater$default$6 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$4 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static $lessinit$greater$default$3 ()I - -
 method public,static $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static unapply (Lakka/routing/ConsistentHashingPool;)Lscala/Option; (Lakka/routing/ConsistentHashingPool;)Lscala/Option<Lscala/Tuple7<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public,static apply (ILscala/Option;ILscala/PartialFunction;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ConsistentHashingPool; (ILscala/Option<Lakka/routing/Resizer;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ConsistentHashingPool; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple7<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;Lakka/routing/ConsistentHashingPool;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/Option<Lakka/routing/Resizer;>;Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lscala/Function1<Lakka/actor/SupervisorStrategy;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/Object;Lakka/routing/ConsistentHashingPool;>;>;>;>;>;>;>; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public virtualNodesFactor ()I - -
 method public hashMapping ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public usePoolDispatcher ()Z - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/ConsistentHashingPool; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/ConsistentHashingPool; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/ConsistentHashingPool; - -
 method public withVirtualNodesFactor (I)Lakka/routing/ConsistentHashingPool; - -
 method public withHashMapper (Lakka/routing/ConsistentHashingRouter$ConsistentHashMapper;)Lakka/routing/ConsistentHashingPool; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public copy (ILscala/Option;ILscala/PartialFunction;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ConsistentHashingPool; (ILscala/Option<Lakka/routing/Resizer;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ConsistentHashingPool; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$3 ()I - -
 method public copy$default$4 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public copy$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$6 ()Ljava/lang/String; - -
 method public copy$default$7 ()Z - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/Option;ILscala/PartialFunction;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V (ILscala/Option<Lakka/routing/Resizer;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (I)V - -
in 0
class akka/routing/ConsistentHashingPool$ 50 public,final,super scala/runtime/AbstractFunction7 scala/Serializable Lscala/runtime/AbstractFunction7<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;Lakka/routing/ConsistentHashingPool;>;Lscala/Serializable;
 inner akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ akka/routing/ConsistentHashingRouter emptyConsistentHashMapping$ public,static
 field public,static,final MODULE$ Lakka/routing/ConsistentHashingPool$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILscala/Option;ILscala/PartialFunction;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ConsistentHashingPool; (ILscala/Option<Lakka/routing/Resizer;>;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ConsistentHashingPool; -
 method public unapply (Lakka/routing/ConsistentHashingPool;)Lscala/Option; (Lakka/routing/ConsistentHashingPool;)Lscala/Option<Lscala/Tuple7<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$3 ()I - -
 method public $lessinit$greater$default$4 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$6 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$7 ()Z - -
 method public apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$3 ()I - -
 method public apply$default$4 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$6 ()Ljava/lang/String; - -
 method public apply$default$7 ()Z - -
in 0
class akka/routing/ConsistentHashingRouter 50 public,super,deprecated java/lang/Object akka/routing/DeprecatedRouterConfig,akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/DeprecatedRouterConfig;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/ConsistentHashingRouter;>;Lscala/Product;Lscala/Serializable;
 inner akka/routing/ConsistentHashingRouter$ConsistentHashable akka/routing/ConsistentHashingRouter ConsistentHashable public,static,interface,abstract
 inner akka/routing/ConsistentHashingRouter$ConsistentHashMapper akka/routing/ConsistentHashingRouter ConsistentHashMapper public,static,interface,abstract
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope public,static,final
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope$ akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope$ public,static
 inner akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ akka/routing/ConsistentHashingRouter emptyConsistentHashMapping$ public,static
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$7 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static apply$default$6 ()I - -
 method public,static apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static apply$default$1 ()I - -
 method public,static $lessinit$greater$default$7 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static $lessinit$greater$default$6 ()I - -
 method public,static $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static $lessinit$greater$default$1 ()I - -
 method public,static unapply (Lakka/routing/ConsistentHashingRouter;)Lscala/Option; (Lakka/routing/ConsistentHashingRouter;)Lscala/Option<Lscala/Tuple7<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;>;>; -
 method public,static apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction;)Lakka/routing/ConsistentHashingRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)Lakka/routing/ConsistentHashingRouter; -
 method public,static create (Ljava/lang/Iterable;)Lakka/routing/ConsistentHashingRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/ConsistentHashingRouter; -
 method public,static apply (Lscala/collection/immutable/Iterable;)Lakka/routing/ConsistentHashingRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/ConsistentHashingRouter; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public routees ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public virtualNodesFactor ()I - -
 method public hashMapping ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/ConsistentHashingRouter; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/ConsistentHashingRouter; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/ConsistentHashingRouter; - -
 method public withVirtualNodesFactor (I)Lakka/routing/ConsistentHashingRouter; - -
 method public withHashMapper (Lakka/routing/ConsistentHashingRouter$ConsistentHashMapper;)Lakka/routing/ConsistentHashingRouter; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public copy (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction;)Lakka/routing/ConsistentHashingRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)Lakka/routing/ConsistentHashingRouter; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$6 ()I - -
 method public copy$default$7 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction;)V (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)V -
 method public <init> (I)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
 method public <init> (Lakka/routing/Resizer;)V - -
in 0
class akka/routing/ConsistentHashingRouter$ 50 public,final,super,deprecated java/lang/Object scala/Serializable -
 inner akka/routing/ConsistentHashingRouter$ConsistentHashable akka/routing/ConsistentHashingRouter ConsistentHashable public,static,interface,abstract
 inner akka/routing/ConsistentHashingRouter$ConsistentHashMapper akka/routing/ConsistentHashingRouter ConsistentHashMapper public,static,interface,abstract
 inner akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ akka/routing/ConsistentHashingRouter emptyConsistentHashMapping$ public,static
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope public,static,final
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope$ akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope$ public,static
 field public,static,final MODULE$ Lakka/routing/ConsistentHashingRouter$; -
 method public,static <clinit> ()V - -
 method public hashMappingAdapter (Lakka/routing/ConsistentHashingRouter$ConsistentHashMapper;)Lscala/PartialFunction; (Lakka/routing/ConsistentHashingRouter$ConsistentHashMapper;)Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,deprecated apply (Lscala/collection/immutable/Iterable;)Lakka/routing/ConsistentHashingRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/ConsistentHashingRouter; -
 method public apply$default$1 ()I - -
 method public apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$6 ()I - -
 method public apply$default$7 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,deprecated create (Ljava/lang/Iterable;)Lakka/routing/ConsistentHashingRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/ConsistentHashingRouter; -
 method public apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction;)Lakka/routing/ConsistentHashingRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)Lakka/routing/ConsistentHashingRouter; -
 method public unapply (Lakka/routing/ConsistentHashingRouter;)Lscala/Option; (Lakka/routing/ConsistentHashingRouter;)Lscala/Option<Lscala/Tuple7<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;>;>; -
 method public $lessinit$greater$default$1 ()I - -
 method public $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$6 ()I - -
 method public $lessinit$greater$default$7 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
in 0
class akka/routing/ConsistentHashingRouter$ConsistentHashMapper 50 public,interface,abstract java/lang/Object - -
 inner akka/routing/ConsistentHashingRouter$ConsistentHashMapper akka/routing/ConsistentHashingRouter ConsistentHashMapper public,static,interface,abstract
 method public,abstract hashKey (Ljava/lang/Object;)Ljava/lang/Object; - -
in 0
class akka/routing/ConsistentHashingRouter$ConsistentHashable 50 public,interface,abstract java/lang/Object - -
 inner akka/routing/ConsistentHashingRouter$ConsistentHashable akka/routing/ConsistentHashingRouter ConsistentHashable public,static,interface,abstract
 method public,abstract consistentHashKey ()Ljava/lang/Object; - -
in 0
class akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope 50 public,final,super java/lang/Object akka/routing/ConsistentHashingRouter$ConsistentHashable,akka/routing/RouterEnvelope,scala/Product,scala/Serializable -
 inner akka/routing/ConsistentHashingRouter$ConsistentHashable akka/routing/ConsistentHashingRouter ConsistentHashable public,static,interface,abstract
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope public,static,final
 field public,static,final serialVersionUID J - J1
 method public message ()Ljava/lang/Object; - -
 method public hashKey ()Ljava/lang/Object; - -
 method public consistentHashKey ()Ljava/lang/Object; - -
 method public copy (Ljava/lang/Object;Ljava/lang/Object;)Lakka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope; - -
 method public copy$default$1 ()Ljava/lang/Object; - -
 method public copy$default$2 ()Ljava/lang/Object; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/Object;Ljava/lang/Object;)V - -
in 0
class akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope$ 50 public,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/Object;Ljava/lang/Object;Lakka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope;>;Lscala/Serializable;
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope$ akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope$ public,static
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope public,static,final
 field public,static,final MODULE$ Lakka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/Object;Ljava/lang/Object;)Lakka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope; - -
 method public unapply (Lakka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope;)Lscala/Option; (Lakka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope;)Lscala/Option<Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/Object;>;>; -
 method public <init> ()V - -
in 0
class akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ 50 public,super java/lang/Object scala/PartialFunction Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;
 inner akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ akka/routing/ConsistentHashingRouter emptyConsistentHashMapping$ public,static
 field public,static,final MODULE$ Lakka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$; -
 field public,static,final serialVersionUID J - J1
 method public,static <clinit> ()V - -
 method public orElse (Lscala/PartialFunction;)Lscala/PartialFunction; <A1:Ljava/lang/Object;B1:Ljava/lang/Object;>(Lscala/PartialFunction<TA1;TB1;>;)Lscala/PartialFunction<TA1;TB1;>; -
 method public andThen (Lscala/Function1;)Lscala/PartialFunction; <C:Ljava/lang/Object;>(Lscala/Function1<Ljava/lang/Object;TC;>;)Lscala/PartialFunction<Ljava/lang/Object;TC;>; -
 method public lift ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Option<Ljava/lang/Object;>;>; -
 method public applyOrElse (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <A1:Ljava/lang/Object;B1:Ljava/lang/Object;>(TA1;Lscala/Function1<TA1;TB1;>;)TB1; -
 method public runWith (Lscala/Function1;)Lscala/Function1; <U:Ljava/lang/Object;>(Lscala/Function1<Ljava/lang/Object;TU;>;)Lscala/Function1<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public apply$mcZD$sp (D)Z - -
 method public apply$mcDD$sp (D)D - -
 method public apply$mcFD$sp (D)F - -
 method public apply$mcID$sp (D)I - -
 method public apply$mcJD$sp (D)J - -
 method public apply$mcVD$sp (D)V - -
 method public apply$mcZF$sp (F)Z - -
 method public apply$mcDF$sp (F)D - -
 method public apply$mcFF$sp (F)F - -
 method public apply$mcIF$sp (F)I - -
 method public apply$mcJF$sp (F)J - -
 method public apply$mcVF$sp (F)V - -
 method public apply$mcZI$sp (I)Z - -
 method public apply$mcDI$sp (I)D - -
 method public apply$mcFI$sp (I)F - -
 method public apply$mcII$sp (I)I - -
 method public apply$mcJI$sp (I)J - -
 method public apply$mcVI$sp (I)V - -
 method public apply$mcZJ$sp (J)Z - -
 method public apply$mcDJ$sp (J)D - -
 method public apply$mcFJ$sp (J)F - -
 method public apply$mcIJ$sp (J)I - -
 method public apply$mcJJ$sp (J)J - -
 method public apply$mcVJ$sp (J)V - -
 method public compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/Object;>;)Lscala/Function1<TA;Ljava/lang/Object;>; -
 method public toString ()Ljava/lang/String; - -
 method public isDefinedAt (Ljava/lang/Object;)Z - -
 method public apply (Ljava/lang/Object;)Lscala/runtime/Nothing$; - -
 method public <init> ()V - -
in 0
class akka/routing/ConsistentHashingRoutingLogic 50 public,final,super java/lang/Object akka/routing/RoutingLogic,scala/Product,scala/Serializable -
 inner akka/actor/ActorSystem$Settings akka/actor/ActorSystem Settings public,static
 inner akka/routing/ConsistentHashingRouter$ConsistentHashable akka/routing/ConsistentHashingRouter ConsistentHashable public,static,interface,abstract
 inner akka/routing/ConsistentHashingRouter$ConsistentHashMapper akka/routing/ConsistentHashingRouter ConsistentHashMapper public,static,interface,abstract
 inner akka/routing/ConsistentHashingRouter$ConsistentHashableEnvelope akka/routing/ConsistentHashingRouter ConsistentHashableEnvelope public,static,final
 inner akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ akka/routing/ConsistentHashingRouter emptyConsistentHashMapping$ public,static
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static apply$default$2 ()I - -
 method public,static $lessinit$greater$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public,static $lessinit$greater$default$2 ()I - -
 method public,static unapply (Lakka/routing/ConsistentHashingRoutingLogic;)Lscala/Option; (Lakka/routing/ConsistentHashingRoutingLogic;)Lscala/Option<Lscala/Tuple3<Lakka/actor/ActorSystem;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;>;>; -
 method public,static apply (Lakka/actor/ActorSystem;ILscala/PartialFunction;)Lakka/routing/ConsistentHashingRoutingLogic; (Lakka/actor/ActorSystem;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)Lakka/routing/ConsistentHashingRoutingLogic; -
 method public,static defaultAddress (Lakka/actor/ActorSystem;)Lakka/actor/Address; - -
 method public system ()Lakka/actor/ActorSystem; - -
 method public virtualNodesFactor ()I - -
 method public hashMapping ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public akka$routing$ConsistentHashingRoutingLogic$$selfAddress ()Lakka/actor/Address; - -
 method public vnodes ()I - -
 method public withVirtualNodesFactor (I)Lakka/routing/ConsistentHashingRoutingLogic; - -
 method public withHashMapper (Lakka/routing/ConsistentHashingRouter$ConsistentHashMapper;)Lakka/routing/ConsistentHashingRoutingLogic; - -
 method public select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
 method public copy (Lakka/actor/ActorSystem;ILscala/PartialFunction;)Lakka/routing/ConsistentHashingRoutingLogic; (Lakka/actor/ActorSystem;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)Lakka/routing/ConsistentHashingRoutingLogic; -
 method public copy$default$1 ()Lakka/actor/ActorSystem; - -
 method public copy$default$2 ()I - -
 method public copy$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/actor/ActorSystem;ILscala/PartialFunction;)V (Lakka/actor/ActorSystem;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)V -
 method public <init> (Lakka/actor/ActorSystem;)V - -
in 0
class akka/routing/ConsistentHashingRoutingLogic$ 50 public,final,super java/lang/Object scala/Serializable -
 inner akka/routing/ConsistentHashingRouter$emptyConsistentHashMapping$ akka/routing/ConsistentHashingRouter emptyConsistentHashMapping$ public,static
 field public,static,final MODULE$ Lakka/routing/ConsistentHashingRoutingLogic$; -
 method public,static <clinit> ()V - -
 method public defaultAddress (Lakka/actor/ActorSystem;)Lakka/actor/Address; - -
 method public apply (Lakka/actor/ActorSystem;ILscala/PartialFunction;)Lakka/routing/ConsistentHashingRoutingLogic; (Lakka/actor/ActorSystem;ILscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;)Lakka/routing/ConsistentHashingRoutingLogic; -
 method public unapply (Lakka/routing/ConsistentHashingRoutingLogic;)Lscala/Option; (Lakka/routing/ConsistentHashingRoutingLogic;)Lscala/Option<Lscala/Tuple3<Lakka/actor/ActorSystem;Ljava/lang/Object;Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>;>;>; -
 method public $lessinit$greater$default$2 ()I - -
 method public $lessinit$greater$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public apply$default$2 ()I - -
 method public apply$default$3 ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Ljava/lang/Object;>; -
in 0
class akka/routing/ConsistentRoutee 50 public,super java/lang/Object scala/Product,scala/Serializable -
 method public,static unapply (Lakka/routing/ConsistentRoutee;)Lscala/Option; (Lakka/routing/ConsistentRoutee;)Lscala/Option<Lscala/Tuple2<Lakka/routing/Routee;Lakka/actor/Address;>;>; -
 method public,static apply (Lakka/routing/Routee;Lakka/actor/Address;)Lakka/routing/ConsistentRoutee; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lakka/routing/Routee;Lakka/actor/Address;>;Lakka/routing/ConsistentRoutee;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lakka/routing/Routee;Lscala/Function1<Lakka/actor/Address;Lakka/routing/ConsistentRoutee;>;>; -
 method public routee ()Lakka/routing/Routee; - -
 method public selfAddress ()Lakka/actor/Address; - -
 method public toString ()Ljava/lang/String; - -
 method public copy (Lakka/routing/Routee;Lakka/actor/Address;)Lakka/routing/ConsistentRoutee; - -
 method public copy$default$1 ()Lakka/routing/Routee; - -
 method public copy$default$2 ()Lakka/actor/Address; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/routing/Routee;Lakka/actor/Address;)V - -
in 0
class akka/routing/ConsistentRoutee$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lakka/routing/Routee;Lakka/actor/Address;Lakka/routing/ConsistentRoutee;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ConsistentRoutee$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/routing/Routee;Lakka/actor/Address;)Lakka/routing/ConsistentRoutee; - -
 method public unapply (Lakka/routing/ConsistentRoutee;)Lscala/Option; (Lakka/routing/ConsistentRoutee;)Lscala/Option<Lscala/Tuple2<Lakka/routing/Routee;Lakka/actor/Address;>;>; -
in 0
class akka/routing/CurrentRoutees 50 public,super,abstract,deprecated java/lang/Object akka/routing/RouterManagementMesssage -
 field public,static,final serialVersionUID J - J1
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static getInstance ()Lakka/routing/CurrentRoutees$; - -
 method public <init> ()V - -
in 0
class akka/routing/CurrentRoutees$ 50 public,final,super,deprecated akka/routing/CurrentRoutees scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/CurrentRoutees$; -
 field public,static,final serialVersionUID J - J1
 method public,static <clinit> ()V - -
 method public getInstance ()Lakka/routing/CurrentRoutees$; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 0
class akka/routing/CustomRouterConfig 50 public,super,abstract java/lang/Object akka/routing/RouterConfig -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class akka/routing/Deafen 50 public,super java/lang/Object akka/routing/ListenerMessage,scala/Product,scala/Serializable -
 method public,static unapply (Lakka/routing/Deafen;)Lscala/Option; (Lakka/routing/Deafen;)Lscala/Option<Lakka/actor/ActorRef;>; -
 method public,static apply (Lakka/actor/ActorRef;)Lakka/routing/Deafen; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/Deafen;TA;>;)Lscala/Function1<Lakka/actor/ActorRef;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lakka/actor/ActorRef;>;)Lscala/Function1<TA;Lakka/routing/Deafen;>; -
 method public listener ()Lakka/actor/ActorRef; - -
 method public copy (Lakka/actor/ActorRef;)Lakka/routing/Deafen; - -
 method public copy$default$1 ()Lakka/actor/ActorRef; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/actor/ActorRef;)V - -
in 0
class akka/routing/Deafen$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lakka/actor/ActorRef;Lakka/routing/Deafen;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/Deafen$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/actor/ActorRef;)Lakka/routing/Deafen; - -
 method public unapply (Lakka/routing/Deafen;)Lscala/Option; (Lakka/routing/Deafen;)Lscala/Option<Lakka/actor/ActorRef;>; -
in 0
class akka/routing/DefaultResizer 50 public,super java/lang/Object akka/routing/Resizer,scala/Product,scala/Serializable -
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$7 ()I - -
 method public,static apply$default$6 ()D - -
 method public,static apply$default$5 ()D - -
 method public,static apply$default$4 ()D - -
 method public,static apply$default$3 ()I - -
 method public,static apply$default$2 ()I - -
 method public,static apply$default$1 ()I - -
 method public,static $lessinit$greater$default$7 ()I - -
 method public,static $lessinit$greater$default$6 ()D - -
 method public,static $lessinit$greater$default$5 ()D - -
 method public,static $lessinit$greater$default$4 ()D - -
 method public,static $lessinit$greater$default$3 ()I - -
 method public,static $lessinit$greater$default$2 ()I - -
 method public,static $lessinit$greater$default$1 ()I - -
 method public,static unapply (Lakka/routing/DefaultResizer;)Lscala/Option; (Lakka/routing/DefaultResizer;)Lscala/Option<Lscala/Tuple7<Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;>;>; -
 method public,static apply (IIIDDDI)Lakka/routing/DefaultResizer; - -
 method public,static fromConfig (Lcom/typesafe/config/Config;)Lscala/Option; (Lcom/typesafe/config/Config;)Lscala/Option<Lakka/routing/DefaultResizer;>; -
 method public,static apply (Lcom/typesafe/config/Config;)Lakka/routing/DefaultResizer; - -
 method public lowerBound ()I - -
 method public upperBound ()I - -
 method public pressureThreshold ()I - -
 method public rampupRate ()D - -
 method public backoffThreshold ()D - -
 method public backoffRate ()D - -
 method public messagesPerResize ()I - -
 method public isTimeForResize (J)Z - -
 method public resize (Lscala/collection/immutable/IndexedSeq;)I (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)I -
 method public capacity (Lscala/collection/immutable/IndexedSeq;)I (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)I -
 method public pressure (Lscala/collection/immutable/IndexedSeq;)I (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)I -
 method public filter (II)I - -
 method public rampup (II)I - -
 method public backoff (II)I - -
 method public copy (IIIDDDI)Lakka/routing/DefaultResizer; - -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()I - -
 method public copy$default$3 ()I - -
 method public copy$default$4 ()D - -
 method public copy$default$5 ()D - -
 method public copy$default$6 ()D - -
 method public copy$default$7 ()I - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (IIIDDDI)V - -
 method public <init> (II)V - -
in 0
class akka/routing/DefaultResizer$ 50 public,final,super java/lang/Object scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/DefaultResizer$; -
 method public,static <clinit> ()V - -
 method public apply (Lcom/typesafe/config/Config;)Lakka/routing/DefaultResizer; - -
 method public apply$default$1 ()I - -
 method public apply$default$2 ()I - -
 method public apply$default$3 ()I - -
 method public apply$default$4 ()D - -
 method public apply$default$5 ()D - -
 method public apply$default$6 ()D - -
 method public apply$default$7 ()I - -
 method public fromConfig (Lcom/typesafe/config/Config;)Lscala/Option; (Lcom/typesafe/config/Config;)Lscala/Option<Lakka/routing/DefaultResizer;>; -
 method public apply (IIIDDDI)Lakka/routing/DefaultResizer; - -
 method public unapply (Lakka/routing/DefaultResizer;)Lscala/Option; (Lakka/routing/DefaultResizer;)Lscala/Option<Lscala/Tuple7<Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;>;>; -
 method public $lessinit$greater$default$1 ()I - -
 method public $lessinit$greater$default$2 ()I - -
 method public $lessinit$greater$default$3 ()I - -
 method public $lessinit$greater$default$4 ()D - -
 method public $lessinit$greater$default$5 ()D - -
 method public $lessinit$greater$default$6 ()D - -
 method public $lessinit$greater$default$7 ()I - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 0
class akka/routing/DeprecatedRouterConfig 50 public,interface,abstract,deprecated java/lang/Object akka/routing/Group,akka/routing/Pool -
in 0
class akka/routing/FromConfig 50 public,super java/lang/Object akka/routing/Pool -
 field public,static,final serialVersionUID J - J1
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Ljava/lang/String; - -
 method public,static apply$default$2 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$1 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static unapply (Lakka/routing/FromConfig;)Lscala/Option; (Lakka/routing/FromConfig;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Lscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;)Lakka/routing/FromConfig; (Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;)Lakka/routing/FromConfig; -
 method public,static getInstance ()Lakka/routing/FromConfig$; - -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/FromConfig; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/FromConfig; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/FromConfig; - -
 method public nrOfInstances ()I - -
 method public props ()Lakka/actor/Props; - -
 method public <init> (Lscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;)V (Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;)V -
 method public <init> ()V - -
in 0
class akka/routing/FromConfig$ 50 public,final,super akka/routing/FromConfig scala/Product -
 field public,static,final MODULE$ Lakka/routing/FromConfig$; -
 method public,static <clinit> ()V - -
 method public getInstance ()Lakka/routing/FromConfig$; - -
 method public,final apply (Lscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;)Lakka/routing/FromConfig; (Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;)Lakka/routing/FromConfig; -
 method public,final apply$default$1 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,final apply$default$2 ()Lakka/actor/SupervisorStrategy; - -
 method public,final apply$default$3 ()Ljava/lang/String; - -
 method public,final unapply (Lakka/routing/FromConfig;)Lscala/Option; (Lakka/routing/FromConfig;)Lscala/Option<Ljava/lang/String;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 0
class akka/routing/GetRoutees 50 public,super,abstract java/lang/Object akka/routing/RouterManagementMesssage -
 field public,static,final serialVersionUID J - J1
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static getInstance ()Lakka/routing/GetRoutees$; - -
 method public <init> ()V - -
in 0
class akka/routing/GetRoutees$ 50 public,final,super akka/routing/GetRoutees scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/GetRoutees$; -
 field public,static,final serialVersionUID J - J1
 method public,static <clinit> ()V - -
 method public getInstance ()Lakka/routing/GetRoutees$; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 0
class akka/routing/Group 50 public,interface,abstract java/lang/Object akka/routing/RouterConfig -
 method public,abstract paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,abstract props ()Lakka/actor/Props; - -
 method public,abstract routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public,abstract createRouterActor ()Lakka/routing/RouterActor; - -
in 0
class akka/routing/Group$class 50 public,super,abstract java/lang/Object - -
 method public,static props (Lakka/routing/Group;)Lakka/actor/Props; - -
 method public,static routeeFor (Lakka/routing/Group;Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public,static createRouterActor (Lakka/routing/Group;)Lakka/routing/RouterActor; - -
 method public,static $init$ (Lakka/routing/Group;)V - -
in 0
class akka/routing/GroupBase 50 public,super,abstract java/lang/Object akka/routing/Group -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public,abstract getPaths ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Ljava/lang/String;>; -
 method public,final paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public <init> ()V - -
in 0
class akka/routing/Listen 50 public,super java/lang/Object akka/routing/ListenerMessage,scala/Product,scala/Serializable -
 method public,static unapply (Lakka/routing/Listen;)Lscala/Option; (Lakka/routing/Listen;)Lscala/Option<Lakka/actor/ActorRef;>; -
 method public,static apply (Lakka/actor/ActorRef;)Lakka/routing/Listen; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/Listen;TA;>;)Lscala/Function1<Lakka/actor/ActorRef;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lakka/actor/ActorRef;>;)Lscala/Function1<TA;Lakka/routing/Listen;>; -
 method public listener ()Lakka/actor/ActorRef; - -
 method public copy (Lakka/actor/ActorRef;)Lakka/routing/Listen; - -
 method public copy$default$1 ()Lakka/actor/ActorRef; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/actor/ActorRef;)V - -
in 0
class akka/routing/Listen$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lakka/actor/ActorRef;Lakka/routing/Listen;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/Listen$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/actor/ActorRef;)Lakka/routing/Listen; - -
 method public unapply (Lakka/routing/Listen;)Lscala/Option; (Lakka/routing/Listen;)Lscala/Option<Lakka/actor/ActorRef;>; -
in 0
class akka/routing/ListenerMessage 50 public,interface,abstract java/lang/Object - -
in 0
class akka/routing/Listeners 50 public,interface,abstract java/lang/Object - -
 method public,abstract akka$routing$Listeners$_setter_$listeners_$eq (Ljava/util/Set;)V - -
 method public,abstract listeners ()Ljava/util/Set; ()Ljava/util/Set<Lakka/actor/ActorRef;>; -
 method public,abstract listenerManagement ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public,abstract gossip (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
 method public,abstract gossip$default$2 (Ljava/lang/Object;)Lakka/actor/ActorRef; - -
in 0
class akka/routing/Listeners$class 50 public,super,abstract java/lang/Object - -
 method public,static listenerManagement (Lakka/routing/Listeners;)Lscala/PartialFunction; - -
 method public,static gossip (Lakka/routing/Listeners;Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
 method public,static gossip$default$2 (Lakka/routing/Listeners;Ljava/lang/Object;)Lakka/actor/ActorRef; - -
 method public,static $init$ (Lakka/routing/Listeners;)V - -
in 0
class akka/routing/MurmurHash 50 public,final,super java/lang/Object - -
 method public,static symmetricHash (Lscala/collection/TraversableOnce;I)I <T:Ljava/lang/Object;>(Lscala/collection/TraversableOnce<TT;>;I)I -
 method public,static stringHash (Ljava/lang/String;)I - -
 method public,static arrayHash (Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Ljava/lang/Object;)I -
 method public,static finalizeHash (I)I - -
 method public,static nextMagicB (I)I - -
 method public,static nextMagicA (I)I - -
 method public,static extendHash (IIII)I - -
 method public,static startMagicB ()I - -
 method public,static startMagicA ()I - -
 method public,static startHash (I)I - -
in 0
class akka/routing/MurmurHash$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lakka/routing/MurmurHash$; -
 method public,static <clinit> ()V - -
 method public,final akka$routing$MurmurHash$$hiddenMagicA ()I - -
 method public,final akka$routing$MurmurHash$$hiddenMagicB ()I - -
 method public,final akka$routing$MurmurHash$$seedArray ()I - -
 method public startHash (I)I - -
 method public startMagicA ()I - -
 method public startMagicB ()I - -
 method public extendHash (IIII)I - -
 method public nextMagicA (I)I - -
 method public nextMagicB (I)I - -
 method public finalizeHash (I)I - -
 method public arrayHash (Ljava/lang/Object;)I <T:Ljava/lang/Object;>(Ljava/lang/Object;)I -
 method public stringHash (Ljava/lang/String;)I - -
 method public symmetricHash (Lscala/collection/TraversableOnce;I)I <T:Ljava/lang/Object;>(Lscala/collection/TraversableOnce<TT;>;I)I -
 method public arrayHash$mZc$sp ([Z)I - -
 method public arrayHash$mBc$sp ([B)I - -
 method public arrayHash$mCc$sp ([C)I - -
 method public arrayHash$mDc$sp ([D)I - -
 method public arrayHash$mFc$sp ([F)I - -
 method public arrayHash$mIc$sp ([I)I - -
 method public arrayHash$mJc$sp ([J)I - -
 method public arrayHash$mSc$sp ([S)I - -
 method public arrayHash$mVc$sp ([Lscala/runtime/BoxedUnit;)I - -
in 0
class akka/routing/NoRoutee 50 public,final,super java/lang/Object - -
 method public,static send (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
in 0
class akka/routing/NoRoutee$ 50 public,final,super java/lang/Object akka/routing/Routee -
 field public,static,final MODULE$ Lakka/routing/NoRoutee$; -
 method public,static <clinit> ()V - -
 method public send (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
in 0
class akka/routing/NoRouter 50 public,super,abstract java/lang/Object akka/routing/RouterConfig -
 field public,static,final serialVersionUID J - J1
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public,static getInstance ()Lakka/routing/NoRouter$; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public <init> ()V - -
in 0
class akka/routing/NoRouter$ 50 public,final,super akka/routing/NoRouter scala/Product -
 field public,static,final MODULE$ Lakka/routing/NoRouter$; -
 method public,static <clinit> ()V - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public getInstance ()Lakka/routing/NoRouter$; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 0
class akka/routing/Pool 50 public,interface,abstract java/lang/Object akka/routing/RouterConfig -
 method public,abstract nrOfInstances ()I - -
 method public,abstract usePoolDispatcher ()Z - -
 method public,abstract newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public,abstract enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public,abstract resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,abstract supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public,abstract props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public,abstract stopRouterWhenAllRouteesRemoved ()Z - -
 method public,abstract createRouterActor ()Lakka/routing/RouterActor; - -
in 0
class akka/routing/Pool$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/Pool$; -
 method public,static <clinit> ()V - -
 method public defaultSupervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
in 0
class akka/routing/Pool$class 50 public,super,abstract java/lang/Object - -
 method public,static usePoolDispatcher (Lakka/routing/Pool;)Z - -
 method public,static newRoutee (Lakka/routing/Pool;Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public,static enrichWithPoolDispatcher (Lakka/routing/Pool;Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public,static props (Lakka/routing/Pool;Lakka/actor/Props;)Lakka/actor/Props; - -
 method public,static stopRouterWhenAllRouteesRemoved (Lakka/routing/Pool;)Z - -
 method public,static createRouterActor (Lakka/routing/Pool;)Lakka/routing/RouterActor; - -
 method public,static $init$ (Lakka/routing/Pool;)V - -
in 0
class akka/routing/PoolBase 50 public,super,abstract java/lang/Object akka/routing/Pool -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public <init> ()V - -
in 0
class akka/routing/PoolOverrideUnsetConfig 50 public,interface,abstract java/lang/Object akka/routing/Pool <T::Lakka/routing/Pool;>Ljava/lang/Object;Lakka/routing/Pool;
 method public,abstract overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public,abstract withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/Pool; (Lakka/actor/SupervisorStrategy;)TT; -
 method public,abstract withResizer (Lakka/routing/Resizer;)Lakka/routing/Pool; (Lakka/routing/Resizer;)TT; -
in 0
class akka/routing/PoolOverrideUnsetConfig$class 50 public,super,abstract java/lang/Object - -
 method public,static,final overrideUnsetConfig (Lakka/routing/PoolOverrideUnsetConfig;Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public,static $init$ (Lakka/routing/PoolOverrideUnsetConfig;)V - -
in 0
class akka/routing/RandomGroup 50 public,final,super java/lang/Object akka/routing/Group,scala/Product -
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$2 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$2 ()Ljava/lang/String; - -
 method public,static unapply (Lakka/routing/RandomGroup;)Lscala/Option; (Lakka/routing/RandomGroup;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;>; -
 method public,static apply (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/RandomGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/RandomGroup; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;Lakka/routing/RandomGroup;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Function1<Ljava/lang/String;Lakka/routing/RandomGroup;>;>; -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/RandomGroup; - -
 method public copy (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/RandomGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/RandomGroup; -
 method public copy$default$1 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/Iterable;Ljava/lang/String;)V (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
in 0
class akka/routing/RandomGroup$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;Lakka/routing/RandomGroup;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/RandomGroup$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/RandomGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/RandomGroup; -
 method public unapply (Lakka/routing/RandomGroup;)Lscala/Option; (Lakka/routing/RandomGroup;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;>; -
 method public $lessinit$greater$default$2 ()Ljava/lang/String; - -
 method public apply$default$2 ()Ljava/lang/String; - -
in 0
class akka/routing/RandomPool 50 public,final,super java/lang/Object akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/Pool;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/RandomPool;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$5 ()Z - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$5 ()Z - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static unapply (Lakka/routing/RandomPool;)Lscala/Option; (Lakka/routing/RandomPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public,static apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RandomPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RandomPool; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;Lakka/routing/RandomPool;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/Option<Lakka/routing/Resizer;>;Lscala/Function1<Lakka/actor/SupervisorStrategy;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/Object;Lakka/routing/RandomPool;>;>;>;>;>; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public usePoolDispatcher ()Z - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomPool; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/RandomPool; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/RandomPool; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public copy (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RandomPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RandomPool; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Z - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (I)V - -
in 0
class akka/routing/RandomPool$ 50 public,final,super scala/runtime/AbstractFunction5 scala/Serializable Lscala/runtime/AbstractFunction5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;Lakka/routing/RandomPool;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/RandomPool$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RandomPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RandomPool; -
 method public unapply (Lakka/routing/RandomPool;)Lscala/Option; (Lakka/routing/RandomPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Z - -
 method public apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Z - -
in 0
class akka/routing/RandomRouter 50 public,super,deprecated java/lang/Object akka/routing/DeprecatedRouterConfig,akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/DeprecatedRouterConfig;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/RandomRouter;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static $lessinit$greater$default$1 ()I - -
 method public,static apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static apply$default$1 ()I - -
 method public,static unapply (Lakka/routing/RandomRouter;)Lscala/Option; (Lakka/routing/RandomRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public,static apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomRouter; -
 method public,static create (Ljava/lang/Iterable;)Lakka/routing/RandomRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RandomRouter; -
 method public,static apply (Lscala/collection/immutable/Iterable;)Lakka/routing/RandomRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RandomRouter; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public routees ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/RandomRouter; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomRouter; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/RandomRouter; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public copy (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomRouter; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V -
 method public <init> (I)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
 method public <init> (Lakka/routing/Resizer;)V - -
in 0
class akka/routing/RandomRouter$ 50 public,final,super,deprecated java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/RandomRouter$; -
 method public,static <clinit> ()V - -
 method public apply (Lscala/collection/immutable/Iterable;)Lakka/routing/RandomRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RandomRouter; -
 method public apply$default$1 ()I - -
 method public apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public create (Ljava/lang/Iterable;)Lakka/routing/RandomRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RandomRouter; -
 method public apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RandomRouter; -
 method public unapply (Lakka/routing/RandomRouter;)Lscala/Option; (Lakka/routing/RandomRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public $lessinit$greater$default$1 ()I - -
 method public $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
in 0
class akka/routing/RandomRoutingLogic 50 public,final,super java/lang/Object akka/routing/RoutingLogic -
 field public,static,final serialVersionUID J - J1
 method public,static apply ()Lakka/routing/RandomRoutingLogic; - -
 method public select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
 method public <init> ()V - -
in 0
class akka/routing/RandomRoutingLogic$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lakka/routing/RandomRoutingLogic$; -
 method public,static <clinit> ()V - -
 method public apply ()Lakka/routing/RandomRoutingLogic; - -
in 0
class akka/routing/RemoveRoutee 50 public,super java/lang/Object akka/routing/RouterManagementMesssage,scala/Product,scala/Serializable -
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/RemoveRoutee;)Lscala/Option; (Lakka/routing/RemoveRoutee;)Lscala/Option<Lakka/routing/Routee;>; -
 method public,static apply (Lakka/routing/Routee;)Lakka/routing/RemoveRoutee; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/RemoveRoutee;TA;>;)Lscala/Function1<Lakka/routing/Routee;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lakka/routing/Routee;>;)Lscala/Function1<TA;Lakka/routing/RemoveRoutee;>; -
 method public routee ()Lakka/routing/Routee; - -
 method public copy (Lakka/routing/Routee;)Lakka/routing/RemoveRoutee; - -
 method public copy$default$1 ()Lakka/routing/Routee; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/routing/Routee;)V - -
in 0
class akka/routing/RemoveRoutee$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lakka/routing/Routee;Lakka/routing/RemoveRoutee;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/RemoveRoutee$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/routing/Routee;)Lakka/routing/RemoveRoutee; - -
 method public unapply (Lakka/routing/RemoveRoutee;)Lscala/Option; (Lakka/routing/RemoveRoutee;)Lscala/Option<Lakka/routing/Routee;>; -
in 0
class akka/routing/ResizablePoolActor 50 public,super akka/routing/RouterPoolActor - -
 inner akka/routing/ResizablePoolActor$Resize$ akka/routing/ResizablePoolActor Resize$ public,static
 method public resizerCell ()Lakka/routing/ResizablePoolCell; - -
 method public receive ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public <init> (Lakka/actor/SupervisorStrategy;)V - -
in 0
class akka/routing/ResizablePoolActor$ 50 public,final,super java/lang/Object - -
 inner akka/routing/ResizablePoolActor$Resize$ akka/routing/ResizablePoolActor Resize$ public,static
 field public,static,final MODULE$ Lakka/routing/ResizablePoolActor$; -
 method public,static <clinit> ()V - -
in 0
class akka/routing/ResizablePoolActor$Resize$ 50 public,super java/lang/Object akka/routing/RouterManagementMesssage,scala/Product,scala/Serializable -
 inner akka/routing/ResizablePoolActor$Resize$ akka/routing/ResizablePoolActor Resize$ public,static
 field public,static,final MODULE$ Lakka/routing/ResizablePoolActor$Resize$; -
 method public,static <clinit> ()V - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class akka/routing/ResizablePoolCell 50 public,final,super akka/routing/RoutedActorCell - -
 inner akka/routing/ResizablePoolActor$Resize$ akka/routing/ResizablePoolActor Resize$ public,static
 method public pool ()Lakka/routing/Pool; - -
 method public resizer ()Lakka/routing/Resizer; - -
 method public preSuperStart ()V - -
 method public sendMessage (Lakka/dispatch/Envelope;)V - -
 method public resize (Z)V - -
 method public <init> (Lakka/actor/ActorSystemImpl;Lakka/actor/InternalActorRef;Lakka/actor/Props;Lakka/dispatch/MessageDispatcher;Lakka/actor/Props;Lakka/actor/InternalActorRef;Lakka/routing/Pool;)V - -
in 0
class akka/routing/Resizer 50 public,interface,abstract java/lang/Object - -
 method public,abstract isTimeForResize (J)Z - -
 method public,abstract resize (Lscala/collection/immutable/IndexedSeq;)I (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)I -
in 0
class akka/routing/RoundRobinGroup 50 public,final,super java/lang/Object akka/routing/Group,scala/Product -
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$2 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$2 ()Ljava/lang/String; - -
 method public,static unapply (Lakka/routing/RoundRobinGroup;)Lscala/Option; (Lakka/routing/RoundRobinGroup;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;>; -
 method public,static apply (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/RoundRobinGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/RoundRobinGroup; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;Lakka/routing/RoundRobinGroup;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Function1<Ljava/lang/String;Lakka/routing/RoundRobinGroup;>;>; -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/RoundRobinGroup; - -
 method public copy (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/RoundRobinGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/RoundRobinGroup; -
 method public copy$default$1 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/Iterable;Ljava/lang/String;)V (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
in 0
class akka/routing/RoundRobinGroup$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;Lakka/routing/RoundRobinGroup;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/RoundRobinGroup$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/Iterable;Ljava/lang/String;)Lakka/routing/RoundRobinGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;)Lakka/routing/RoundRobinGroup; -
 method public unapply (Lakka/routing/RoundRobinGroup;)Lscala/Option; (Lakka/routing/RoundRobinGroup;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Ljava/lang/String;>;>; -
 method public $lessinit$greater$default$2 ()Ljava/lang/String; - -
 method public apply$default$2 ()Ljava/lang/String; - -
in 0
class akka/routing/RoundRobinPool 50 public,final,super java/lang/Object akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/Pool;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/RoundRobinPool;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$5 ()Z - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$5 ()Z - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static unapply (Lakka/routing/RoundRobinPool;)Lscala/Option; (Lakka/routing/RoundRobinPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public,static apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RoundRobinPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RoundRobinPool; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;Lakka/routing/RoundRobinPool;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/Option<Lakka/routing/Resizer;>;Lscala/Function1<Lakka/actor/SupervisorStrategy;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/Object;Lakka/routing/RoundRobinPool;>;>;>;>;>; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public usePoolDispatcher ()Z - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinPool; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/RoundRobinPool; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/RoundRobinPool; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public copy (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RoundRobinPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RoundRobinPool; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Z - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (I)V - -
in 0
class akka/routing/RoundRobinPool$ 50 public,final,super scala/runtime/AbstractFunction5 scala/Serializable Lscala/runtime/AbstractFunction5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;Lakka/routing/RoundRobinPool;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/RoundRobinPool$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RoundRobinPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/RoundRobinPool; -
 method public unapply (Lakka/routing/RoundRobinPool;)Lscala/Option; (Lakka/routing/RoundRobinPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Z - -
 method public apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Z - -
in 0
class akka/routing/RoundRobinRouter 50 public,super,deprecated java/lang/Object akka/routing/DeprecatedRouterConfig,akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/DeprecatedRouterConfig;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/RoundRobinRouter;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static apply$default$1 ()I - -
 method public,static $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static $lessinit$greater$default$1 ()I - -
 method public,static unapply (Lakka/routing/RoundRobinRouter;)Lscala/Option; (Lakka/routing/RoundRobinRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public,static apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinRouter; -
 method public,static create (Ljava/lang/Iterable;)Lakka/routing/RoundRobinRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RoundRobinRouter; -
 method public,static apply (Lscala/collection/immutable/Iterable;)Lakka/routing/RoundRobinRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RoundRobinRouter; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public routees ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/RoundRobinRouter; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinRouter; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/RoundRobinRouter; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public copy (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinRouter; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V -
 method public <init> (I)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
 method public <init> (Lakka/routing/Resizer;)V - -
in 0
class akka/routing/RoundRobinRouter$ 50 public,final,super,deprecated java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/RoundRobinRouter$; -
 method public,static <clinit> ()V - -
 method public apply (Lscala/collection/immutable/Iterable;)Lakka/routing/RoundRobinRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RoundRobinRouter; -
 method public apply$default$1 ()I - -
 method public apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public create (Ljava/lang/Iterable;)Lakka/routing/RoundRobinRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/RoundRobinRouter; -
 method public apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/RoundRobinRouter; -
 method public unapply (Lakka/routing/RoundRobinRouter;)Lscala/Option; (Lakka/routing/RoundRobinRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public $lessinit$greater$default$1 ()I - -
 method public $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
in 0
class akka/routing/RoundRobinRoutingLogic 50 public,final,super java/lang/Object akka/routing/RoutingLogic -
 field public,static,final serialVersionUID J - J1
 method public,static apply ()Lakka/routing/RoundRobinRoutingLogic; - -
 method public next ()Ljava/util/concurrent/atomic/AtomicLong; - -
 method public select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
 method public <init> ()V - -
in 0
class akka/routing/RoundRobinRoutingLogic$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lakka/routing/RoundRobinRoutingLogic$; -
 method public,static <clinit> ()V - -
 method public apply ()Lakka/routing/RoundRobinRoutingLogic; - -
in 0
class akka/routing/RoutedActorCell 50 public,super akka/actor/ActorCell - -
 inner scala/concurrent/duration/package$DurationInt scala/concurrent/duration/package DurationInt public,static,final
 inner akka/routing/RoutedActorCell$RouterActorCreator akka/routing/RoutedActorCell RouterActorCreator public,static
 method public routeeProps ()Lakka/actor/Props; - -
 method public routerConfig ()Lakka/routing/RouterConfig; - -
 method public router ()Lakka/routing/Router; - -
 method public addRoutee (Lakka/routing/Routee;)V - -
 method public addRoutees (Lscala/collection/immutable/Iterable;)V (Lscala/collection/immutable/Iterable<Lakka/routing/Routee;>;)V -
 method public removeRoutee (Lakka/routing/Routee;Z)V - -
 method public removeRoutees (Lscala/collection/immutable/Iterable;Z)V (Lscala/collection/immutable/Iterable<Lakka/routing/Routee;>;Z)V -
 method public akka$routing$RoutedActorCell$$watch (Lakka/routing/Routee;)V - -
 method public akka$routing$RoutedActorCell$$unwatch (Lakka/routing/Routee;)V - -
 method public akka$routing$RoutedActorCell$$stopIfChild (Lakka/routing/Routee;)V - -
 method public start ()Lakka/routing/RoutedActorCell; - -
 method public preSuperStart ()V - -
 method public sendMessage (Lakka/dispatch/Envelope;)V - -
 method public <init> (Lakka/actor/ActorSystemImpl;Lakka/actor/InternalActorRef;Lakka/actor/Props;Lakka/dispatch/MessageDispatcher;Lakka/actor/Props;Lakka/actor/InternalActorRef;)V - -
in 0
class akka/routing/RoutedActorCell$ 50 public,final,super java/lang/Object - -
 inner akka/routing/RoutedActorCell$RouterActorCreator akka/routing/RoutedActorCell RouterActorCreator public,static
 field public,static,final MODULE$ Lakka/routing/RoutedActorCell$; -
 method public,static <clinit> ()V - -
in 0
class akka/routing/RoutedActorCell$RouterActorCreator 50 public,super java/lang/Object akka/actor/IndirectActorProducer -
 inner akka/routing/RoutedActorCell$RouterActorCreator akka/routing/RoutedActorCell RouterActorCreator public,static
 method public actorClass ()Ljava/lang/Class; ()Ljava/lang/Class<Lakka/routing/RouterActor;>; -
 method public produce ()Lakka/routing/RouterActor; - -
 method public <init> (Lakka/routing/RouterConfig;)V - -
in 0
class akka/routing/RoutedActorRef 50 public,super akka/actor/RepointableActorRef - -
 method public newCell (Lakka/actor/UnstartedCell;)Lakka/actor/Cell; - -
 method public <init> (Lakka/actor/ActorSystemImpl;Lakka/actor/Props;Lakka/dispatch/MessageDispatcher;Lakka/dispatch/MailboxType;Lakka/actor/Props;Lakka/actor/InternalActorRef;Lakka/actor/ActorPath;)V - -
in 0
class akka/routing/Routee 50 public,interface,abstract java/lang/Object - -
 method public,abstract send (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
in 0
class akka/routing/Routees 50 public,super java/lang/Object scala/Product,scala/Serializable -
 inner scala/collection/convert/Decorators$AsJava scala/collection/convert/Decorators AsJava public
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/Routees;)Lscala/Option; (Lakka/routing/Routees;)Lscala/Option<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>; -
 method public,static apply (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routees; -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/Routees;TA;>;)Lscala/Function1<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>;)Lscala/Function1<TA;Lakka/routing/Routees;>; -
 method public routees ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public getRoutees ()Ljava/util/List; ()Ljava/util/List<Lakka/routing/Routee;>; -
 method public copy (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routees; -
 method public copy$default$1 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/IndexedSeq;)V (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)V -
in 0
class akka/routing/Routees$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lakka/routing/Routees;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/Routees$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routees; -
 method public unapply (Lakka/routing/Routees;)Lscala/Option; (Lakka/routing/Routees;)Lscala/Option<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>; -
in 0
class akka/routing/Router 50 public,final,super java/lang/Object scala/Product,scala/Serializable -
 method public,static apply$default$2 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public,static $lessinit$greater$default$2 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public,static unapply (Lakka/routing/Router;)Lscala/Option; (Lakka/routing/Router;)Lscala/Option<Lscala/Tuple2<Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>;>; -
 method public,static apply (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Router; (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Router; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>;Lakka/routing/Router;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lakka/routing/RoutingLogic;Lscala/Function1<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lakka/routing/Router;>;>; -
 method public logic ()Lakka/routing/RoutingLogic; - -
 method public routees ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public route (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
 method public withRoutees (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Router; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Router; -
 method public addRoutee (Lakka/routing/Routee;)Lakka/routing/Router; - -
 method public addRoutee (Lakka/actor/ActorRef;)Lakka/routing/Router; - -
 method public addRoutee (Lakka/actor/ActorSelection;)Lakka/routing/Router; - -
 method public removeRoutee (Lakka/routing/Routee;)Lakka/routing/Router; - -
 method public removeRoutee (Lakka/actor/ActorRef;)Lakka/routing/Router; - -
 method public removeRoutee (Lakka/actor/ActorSelection;)Lakka/routing/Router; - -
 method public copy (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Router; (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Router; -
 method public copy$default$1 ()Lakka/routing/RoutingLogic; - -
 method public copy$default$2 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq;)V (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)V -
 method public <init> (Lakka/routing/RoutingLogic;)V - -
 method public <init> (Lakka/routing/RoutingLogic;Ljava/lang/Iterable;)V (Lakka/routing/RoutingLogic;Ljava/lang/Iterable<Lakka/routing/Routee;>;)V -
in 0
class akka/routing/Router$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lakka/routing/Router;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/Router$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Router; (Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Router; -
 method public unapply (Lakka/routing/Router;)Lscala/Option; (Lakka/routing/Router;)Lscala/Option<Lscala/Tuple2<Lakka/routing/RoutingLogic;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>;>; -
 method public $lessinit$greater$default$2 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public apply$default$2 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
in 0
class akka/routing/RouterActor 50 public,super java/lang/Object akka/actor/Actor -
 method public context ()Lakka/actor/ActorContext; - -
 method public,final self ()Lakka/actor/ActorRef; - -
 method public akka$actor$Actor$_setter_$context_$eq (Lakka/actor/ActorContext;)V - -
 method public,final akka$actor$Actor$_setter_$self_$eq (Lakka/actor/ActorRef;)V - -
 method public,final sender ()Lakka/actor/ActorRef; - -
 method public aroundReceive (Lscala/PartialFunction;Ljava/lang/Object;)V (Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>;Ljava/lang/Object;)V -
 method public aroundPreStart ()V - -
 method public aroundPostStop ()V - -
 method public aroundPreRestart (Ljava/lang/Throwable;Lscala/Option;)V (Ljava/lang/Throwable;Lscala/Option<Ljava/lang/Object;>;)V -
 method public aroundPostRestart (Ljava/lang/Throwable;)V - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public preStart ()V - java/lang/Exception
 method public postStop ()V - java/lang/Exception
 method public postRestart (Ljava/lang/Throwable;)V - java/lang/Exception
 method public unhandled (Ljava/lang/Object;)V - -
 method public cell ()Lakka/routing/RoutedActorCell; - -
 method public routingLogicController ()Lscala/Option; ()Lscala/Option<Lakka/actor/ActorRef;>; -
 method public receive ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public stopIfAllRouteesRemoved ()V - -
 method public preRestart (Ljava/lang/Throwable;Lscala/Option;)V (Ljava/lang/Throwable;Lscala/Option<Ljava/lang/Object;>;)V -
 method public <init> ()V - -
in 0
class akka/routing/RouterConfig 50 public,interface,abstract java/lang/Object scala/Serializable -
 field public,static,final serialVersionUID J - J1
 method public,abstract createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public,abstract routerDispatcher ()Ljava/lang/String; - -
 method public,abstract routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public,abstract isManagementMessage (Ljava/lang/Object;)Z - -
 method public,abstract stopRouterWhenAllRouteesRemoved ()Z - -
 method public,abstract withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public,abstract verifyConfig (Lakka/actor/ActorPath;)V - -
 method public,abstract createRouterActor ()Lakka/routing/RouterActor; - -
in 0
class akka/routing/RouterConfig$class 50 public,super,abstract java/lang/Object - -
 method public,static routingLogicController (Lakka/routing/RouterConfig;Lakka/routing/RoutingLogic;)Lscala/Option; - -
 method public,static isManagementMessage (Lakka/routing/RouterConfig;Ljava/lang/Object;)Z - -
 method public,static stopRouterWhenAllRouteesRemoved (Lakka/routing/RouterConfig;)Z - -
 method public,static withFallback (Lakka/routing/RouterConfig;Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public,static verifyConfig (Lakka/routing/RouterConfig;Lakka/actor/ActorPath;)V - -
 method public,static $init$ (Lakka/routing/RouterConfig;)V - -
in 0
class akka/routing/RouterEnvelope 50 public,interface,abstract java/lang/Object - -
 method public,abstract message ()Ljava/lang/Object; - -
in 0
class akka/routing/RouterManagementMesssage 50 public,interface,abstract java/lang/Object - -
 field public,static,final serialVersionUID J - J1
in 0
class akka/routing/RouterPoolActor 50 public,super akka/routing/RouterActor - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public pool ()Lakka/routing/Pool; - -
 method public receive ()Lscala/PartialFunction; ()Lscala/PartialFunction<Ljava/lang/Object;Lscala/runtime/BoxedUnit;>; -
 method public <init> (Lakka/actor/SupervisorStrategy;)V - -
in 0
class akka/routing/RouterRoutees 50 public,super,deprecated java/lang/Object scala/Product,scala/Serializable -
 inner scala/collection/convert/Decorators$AsJava scala/collection/convert/Decorators AsJava public
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/RouterRoutees;)Lscala/Option; (Lakka/routing/RouterRoutees;)Lscala/Option<Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;>; -
 method public,static apply (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/RouterRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;)Lakka/routing/RouterRoutees; -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/RouterRoutees;TA;>;)Lscala/Function1<Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;>;)Lscala/Function1<TA;Lakka/routing/RouterRoutees;>; -
 method public routees ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>; -
 method public getRoutees ()Ljava/util/List; ()Ljava/util/List<Lakka/actor/ActorRef;>; -
 method public copy (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/RouterRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;)Lakka/routing/RouterRoutees; -
 method public copy$default$1 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/IndexedSeq;)V (Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;)V -
in 0
class akka/routing/RouterRoutees$ 50 public,final,super,deprecated scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;Lakka/routing/RouterRoutees;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/RouterRoutees$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/RouterRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;)Lakka/routing/RouterRoutees; -
 method public unapply (Lakka/routing/RouterRoutees;)Lscala/Option; (Lakka/routing/RouterRoutees;)Lscala/Option<Lscala/collection/immutable/IndexedSeq<Lakka/actor/ActorRef;>;>; -
in 0
class akka/routing/RoutingLogic 50 public,interface,abstract java/lang/Object akka/actor/NoSerializationVerificationNeeded -
 method public,abstract select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
in 0
class akka/routing/ScatterGatherFirstCompletedGroup 50 public,final,super java/lang/Object akka/routing/Group,scala/Product -
 inner akka/util/Helpers$ConfigOps$ akka/util/Helpers ConfigOps$ public,static
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$3 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Ljava/lang/String; - -
 method public,static unapply (Lakka/routing/ScatterGatherFirstCompletedGroup;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedGroup;)Lscala/Option<Lscala/Tuple3<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;>;>; -
 method public,static apply (Lscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedGroup; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple3<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;>;Lakka/routing/ScatterGatherFirstCompletedGroup;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Function1<Lscala/concurrent/duration/FiniteDuration;Lscala/Function1<Ljava/lang/String;Lakka/routing/ScatterGatherFirstCompletedGroup;>;>;>; -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public within ()Lscala/concurrent/duration/FiniteDuration; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedGroup; - -
 method public copy (Lscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedGroup; -
 method public copy$default$1 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$2 ()Lscala/concurrent/duration/FiniteDuration; - -
 method public copy$default$3 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)V (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (Ljava/lang/Iterable;Lscala/concurrent/duration/FiniteDuration;)V (Ljava/lang/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;)V -
in 0
class akka/routing/ScatterGatherFirstCompletedGroup$ 50 public,final,super scala/runtime/AbstractFunction3 scala/Serializable Lscala/runtime/AbstractFunction3<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;Lakka/routing/ScatterGatherFirstCompletedGroup;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ScatterGatherFirstCompletedGroup$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedGroup; (Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedGroup; -
 method public unapply (Lakka/routing/ScatterGatherFirstCompletedGroup;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedGroup;)Lscala/Option<Lscala/Tuple3<Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Ljava/lang/String;>;>; -
 method public $lessinit$greater$default$3 ()Ljava/lang/String; - -
 method public apply$default$3 ()Ljava/lang/String; - -
in 0
class akka/routing/ScatterGatherFirstCompletedPool 50 public,final,super java/lang/Object akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/Pool;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/ScatterGatherFirstCompletedPool;>;Lscala/Product;Lscala/Serializable;
 inner akka/util/Helpers$ConfigOps$ akka/util/Helpers ConfigOps$ public,static
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$6 ()Z - -
 method public,static apply$default$5 ()Ljava/lang/String; - -
 method public,static apply$default$4 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$6 ()Z - -
 method public,static $lessinit$greater$default$5 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$4 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static unapply (Lakka/routing/ScatterGatherFirstCompletedPool;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedPool;)Lscala/Option<Lscala/Tuple6<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public,static apply (ILscala/Option;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ScatterGatherFirstCompletedPool; (ILscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ScatterGatherFirstCompletedPool; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple6<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;Lakka/routing/ScatterGatherFirstCompletedPool;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/Option<Lakka/routing/Resizer;>;Lscala/Function1<Lscala/concurrent/duration/FiniteDuration;Lscala/Function1<Lakka/actor/SupervisorStrategy;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/Object;Lakka/routing/ScatterGatherFirstCompletedPool;>;>;>;>;>;>; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public within ()Lscala/concurrent/duration/FiniteDuration; - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public usePoolDispatcher ()Z - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedPool; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/ScatterGatherFirstCompletedPool; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedPool; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public copy (ILscala/Option;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ScatterGatherFirstCompletedPool; (ILscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ScatterGatherFirstCompletedPool; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$3 ()Lscala/concurrent/duration/FiniteDuration; - -
 method public copy$default$4 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$5 ()Ljava/lang/String; - -
 method public copy$default$6 ()Z - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/Option;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V (ILscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (ILscala/concurrent/duration/FiniteDuration;)V - -
in 0
class akka/routing/ScatterGatherFirstCompletedPool$ 50 public,final,super scala/runtime/AbstractFunction6 scala/Serializable Lscala/runtime/AbstractFunction6<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;Lakka/routing/ScatterGatherFirstCompletedPool;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ScatterGatherFirstCompletedPool$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILscala/Option;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ScatterGatherFirstCompletedPool; (ILscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/ScatterGatherFirstCompletedPool; -
 method public unapply (Lakka/routing/ScatterGatherFirstCompletedPool;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedPool;)Lscala/Option<Lscala/Tuple6<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lscala/concurrent/duration/FiniteDuration;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$4 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$5 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$6 ()Z - -
 method public apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$4 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$5 ()Ljava/lang/String; - -
 method public apply$default$6 ()Z - -
in 0
class akka/routing/ScatterGatherFirstCompletedRoutees 50 public,super java/lang/Object akka/routing/Routee,scala/Product,scala/Serializable -
 inner akka/pattern/PipeToSupport$PipeableFuture akka/pattern/PipeToSupport PipeableFuture public,final
 inner akka/dispatch/ExecutionContexts$sameThreadExecutionContext$ akka/dispatch/ExecutionContexts sameThreadExecutionContext$ public,static
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/ScatterGatherFirstCompletedRoutees;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedRoutees;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;>;>; -
 method public,static apply (Lscala/collection/immutable/IndexedSeq;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutees; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;>;Lakka/routing/ScatterGatherFirstCompletedRoutees;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/Function1<Lscala/concurrent/duration/FiniteDuration;Lakka/routing/ScatterGatherFirstCompletedRoutees;>;>; -
 method public routees ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public within ()Lscala/concurrent/duration/FiniteDuration; - -
 method public send (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
 method public copy (Lscala/collection/immutable/IndexedSeq;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutees; -
 method public copy$default$1 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public copy$default$2 ()Lscala/concurrent/duration/FiniteDuration; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/IndexedSeq;Lscala/concurrent/duration/FiniteDuration;)V (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;)V -
in 0
class akka/routing/ScatterGatherFirstCompletedRoutees$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;Lakka/routing/ScatterGatherFirstCompletedRoutees;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ScatterGatherFirstCompletedRoutees$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/IndexedSeq;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutees; -
 method public unapply (Lakka/routing/ScatterGatherFirstCompletedRoutees;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedRoutees;)Lscala/Option<Lscala/Tuple2<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lscala/concurrent/duration/FiniteDuration;>;>; -
in 0
class akka/routing/ScatterGatherFirstCompletedRouter 50 public,super,deprecated java/lang/Object akka/routing/DeprecatedRouterConfig,akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/DeprecatedRouterConfig;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/ScatterGatherFirstCompletedRouter;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$6 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$5 ()Ljava/lang/String; - -
 method public,static apply$default$4 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static apply$default$1 ()I - -
 method public,static $lessinit$greater$default$6 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$5 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$4 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static $lessinit$greater$default$1 ()I - -
 method public,static unapply (Lakka/routing/ScatterGatherFirstCompletedRouter;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedRouter;)Lscala/Option<Lscala/Tuple6<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public,static apply (ILscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedRouter; -
 method public,static create (Ljava/lang/Iterable;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; -
 method public,static apply (Lscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public routees ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public within ()Lscala/concurrent/duration/FiniteDuration; - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/ScatterGatherFirstCompletedRouter; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedRouter; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/ScatterGatherFirstCompletedRouter; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public copy (ILscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedRouter; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$3 ()Lscala/concurrent/duration/FiniteDuration; - -
 method public copy$default$4 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$5 ()Ljava/lang/String; - -
 method public copy$default$6 ()Lakka/actor/SupervisorStrategy; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V -
 method public <init> (ILscala/concurrent/duration/FiniteDuration;)V - -
 method public <init> (Ljava/lang/Iterable;Lscala/concurrent/duration/FiniteDuration;)V (Ljava/lang/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;)V -
 method public <init> (Lakka/routing/Resizer;Lscala/concurrent/duration/FiniteDuration;)V - -
in 0
class akka/routing/ScatterGatherFirstCompletedRouter$ 50 public,final,super,deprecated java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/ScatterGatherFirstCompletedRouter$; -
 method public,static <clinit> ()V - -
 method public apply (Lscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; -
 method public apply$default$1 ()I - -
 method public apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public apply$default$4 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$5 ()Ljava/lang/String; - -
 method public apply$default$6 ()Lakka/actor/SupervisorStrategy; - -
 method public create (Ljava/lang/Iterable;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRouter; -
 method public apply (ILscala/collection/immutable/Iterable;Lscala/concurrent/duration/FiniteDuration;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/ScatterGatherFirstCompletedRouter; -
 method public unapply (Lakka/routing/ScatterGatherFirstCompletedRouter;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedRouter;)Lscala/Option<Lscala/Tuple6<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/concurrent/duration/FiniteDuration;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public $lessinit$greater$default$1 ()I - -
 method public $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public $lessinit$greater$default$4 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$5 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$6 ()Lakka/actor/SupervisorStrategy; - -
in 0
class akka/routing/ScatterGatherFirstCompletedRoutingLogic 50 public,final,super java/lang/Object akka/routing/RoutingLogic,scala/Product,scala/Serializable -
 field public,static,final serialVersionUID J - J1
 method public,static unapply (Lakka/routing/ScatterGatherFirstCompletedRoutingLogic;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedRoutingLogic;)Lscala/Option<Lscala/concurrent/duration/FiniteDuration;>; -
 method public,static apply (Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutingLogic; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/ScatterGatherFirstCompletedRoutingLogic;TA;>;)Lscala/Function1<Lscala/concurrent/duration/FiniteDuration;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/concurrent/duration/FiniteDuration;>;)Lscala/Function1<TA;Lakka/routing/ScatterGatherFirstCompletedRoutingLogic;>; -
 method public within ()Lscala/concurrent/duration/FiniteDuration; - -
 method public select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
 method public copy (Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutingLogic; - -
 method public copy$default$1 ()Lscala/concurrent/duration/FiniteDuration; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/concurrent/duration/FiniteDuration;)V - -
in 0
class akka/routing/ScatterGatherFirstCompletedRoutingLogic$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/concurrent/duration/FiniteDuration;Lakka/routing/ScatterGatherFirstCompletedRoutingLogic;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/ScatterGatherFirstCompletedRoutingLogic$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/concurrent/duration/FiniteDuration;)Lakka/routing/ScatterGatherFirstCompletedRoutingLogic; - -
 method public unapply (Lakka/routing/ScatterGatherFirstCompletedRoutingLogic;)Lscala/Option; (Lakka/routing/ScatterGatherFirstCompletedRoutingLogic;)Lscala/Option<Lscala/concurrent/duration/FiniteDuration;>; -
in 0
class akka/routing/SeveralRoutees 50 public,super java/lang/Object akka/routing/Routee,scala/Product,scala/Serializable -
 inner scala/collection/convert/Decorators$AsJava scala/collection/convert/Decorators AsJava public
 method public,static unapply (Lakka/routing/SeveralRoutees;)Lscala/Option; (Lakka/routing/SeveralRoutees;)Lscala/Option<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>; -
 method public,static apply (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/SeveralRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/SeveralRoutees; -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/SeveralRoutees;TA;>;)Lscala/Function1<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>;)Lscala/Function1<TA;Lakka/routing/SeveralRoutees;>; -
 method public routees ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public getRoutees ()Ljava/util/List; ()Ljava/util/List<Lakka/routing/Routee;>; -
 method public send (Ljava/lang/Object;Lakka/actor/ActorRef;)V - -
 method public copy (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/SeveralRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/SeveralRoutees; -
 method public copy$default$1 ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/collection/immutable/IndexedSeq;)V (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)V -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Lakka/routing/Routee;>;)V -
in 0
class akka/routing/SeveralRoutees$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;Lakka/routing/SeveralRoutees;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/SeveralRoutees$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/immutable/IndexedSeq;)Lakka/routing/SeveralRoutees; (Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/SeveralRoutees; -
 method public unapply (Lakka/routing/SeveralRoutees;)Lscala/Option; (Lakka/routing/SeveralRoutees;)Lscala/Option<Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;>; -
in 0
class akka/routing/SmallestMailboxPool 50 public,final,super java/lang/Object akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/Pool;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/SmallestMailboxPool;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$5 ()Z - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$5 ()Z - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static unapply (Lakka/routing/SmallestMailboxPool;)Lscala/Option; (Lakka/routing/SmallestMailboxPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public,static apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/SmallestMailboxPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/SmallestMailboxPool; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;Lakka/routing/SmallestMailboxPool;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/Option<Lakka/routing/Resizer;>;Lscala/Function1<Lakka/actor/SupervisorStrategy;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/Object;Lakka/routing/SmallestMailboxPool;>;>;>;>;>; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public usePoolDispatcher ()Z - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxPool; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/SmallestMailboxPool; - -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/SmallestMailboxPool; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public copy (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/SmallestMailboxPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/SmallestMailboxPool; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Z - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)V -
 method public <init> (Lcom/typesafe/config/Config;)V - -
 method public <init> (I)V - -
in 0
class akka/routing/SmallestMailboxPool$ 50 public,final,super scala/runtime/AbstractFunction5 scala/Serializable Lscala/runtime/AbstractFunction5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;Lakka/routing/SmallestMailboxPool;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/SmallestMailboxPool$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILscala/Option;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/SmallestMailboxPool; (ILscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Z)Lakka/routing/SmallestMailboxPool; -
 method public unapply (Lakka/routing/SmallestMailboxPool;)Lscala/Option; (Lakka/routing/SmallestMailboxPool;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/Option<Lakka/routing/Resizer;>;Lakka/actor/SupervisorStrategy;Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public $lessinit$greater$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Z - -
 method public apply$default$2 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$3 ()Lakka/actor/SupervisorStrategy; - -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Z - -
in 0
class akka/routing/SmallestMailboxRouter 50 public,super,deprecated java/lang/Object akka/routing/DeprecatedRouterConfig,akka/routing/PoolOverrideUnsetConfig,scala/Product Ljava/lang/Object;Lakka/routing/DeprecatedRouterConfig;Lakka/routing/PoolOverrideUnsetConfig<Lakka/routing/SmallestMailboxRouter;>;Lscala/Product;Lscala/Serializable;
 field public,static,final serialVersionUID J - J1
 method public,static apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static apply$default$4 ()Ljava/lang/String; - -
 method public,static apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static apply$default$1 ()I - -
 method public,static $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public,static $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public,static $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public,static $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public,static $lessinit$greater$default$1 ()I - -
 method public,static unapply (Lakka/routing/SmallestMailboxRouter;)Lscala/Option; (Lakka/routing/SmallestMailboxRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public,static apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxRouter; -
 method public,static create (Ljava/lang/Iterable;)Lakka/routing/SmallestMailboxRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/SmallestMailboxRouter; -
 method public,static apply (Lscala/collection/immutable/Iterable;)Lakka/routing/SmallestMailboxRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/SmallestMailboxRouter; -
 method public,final overrideUnsetConfig (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public usePoolDispatcher ()Z - -
 method public newRoutee (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public enrichWithPoolDispatcher (Lakka/actor/Props;Lakka/actor/ActorContext;)Lakka/actor/Props; - -
 method public props (Lakka/actor/Props;)Lakka/actor/Props; - -
 method public stopRouterWhenAllRouteesRemoved ()Z - -
 method public createRouterActor ()Lakka/routing/RouterActor; - -
 method public props ()Lakka/actor/Props; - -
 method public routeeFor (Ljava/lang/String;Lakka/actor/ActorContext;)Lakka/routing/Routee; - -
 method public routingLogicController (Lakka/routing/RoutingLogic;)Lscala/Option; (Lakka/routing/RoutingLogic;)Lscala/Option<Lakka/actor/Props;>; -
 method public isManagementMessage (Ljava/lang/Object;)Z - -
 method public verifyConfig (Lakka/actor/ActorPath;)V - -
 method public nrOfInstances ()I - -
 method public routees ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public resizer ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public routerDispatcher ()Ljava/lang/String; - -
 method public supervisorStrategy ()Lakka/actor/SupervisorStrategy; - -
 method public paths ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public withDispatcher (Ljava/lang/String;)Lakka/routing/SmallestMailboxRouter; - -
 method public withSupervisorStrategy (Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxRouter; - -
 method public withResizer (Lakka/routing/Resizer;)Lakka/routing/SmallestMailboxRouter; - -
 method public withFallback (Lakka/routing/RouterConfig;)Lakka/routing/RouterConfig; - -
 method public createRouter (Lakka/actor/ActorSystem;)Lakka/routing/Router; - -
 method public copy (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxRouter; -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public copy$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public copy$default$4 ()Ljava/lang/String; - -
 method public copy$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)V -
 method public <init> (I)V - -
 method public <init> (Ljava/lang/Iterable;)V (Ljava/lang/Iterable<Ljava/lang/String;>;)V -
 method public <init> (Lakka/routing/Resizer;)V - -
in 0
class akka/routing/SmallestMailboxRouter$ 50 public,final,super,deprecated java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lakka/routing/SmallestMailboxRouter$; -
 method public,static <clinit> ()V - -
 method public apply (Lscala/collection/immutable/Iterable;)Lakka/routing/SmallestMailboxRouter; (Lscala/collection/immutable/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/SmallestMailboxRouter; -
 method public apply$default$1 ()I - -
 method public apply$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public apply$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public apply$default$4 ()Ljava/lang/String; - -
 method public apply$default$5 ()Lakka/actor/SupervisorStrategy; - -
 method public create (Ljava/lang/Iterable;)Lakka/routing/SmallestMailboxRouter; (Ljava/lang/Iterable<Lakka/actor/ActorRef;>;)Lakka/routing/SmallestMailboxRouter; -
 method public apply (ILscala/collection/immutable/Iterable;Lscala/Option;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxRouter; (ILscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;)Lakka/routing/SmallestMailboxRouter; -
 method public unapply (Lakka/routing/SmallestMailboxRouter;)Lscala/Option; (Lakka/routing/SmallestMailboxRouter;)Lscala/Option<Lscala/Tuple5<Ljava/lang/Object;Lscala/collection/immutable/Iterable<Ljava/lang/String;>;Lscala/Option<Lakka/routing/Resizer;>;Ljava/lang/String;Lakka/actor/SupervisorStrategy;>;>; -
 method public $lessinit$greater$default$1 ()I - -
 method public $lessinit$greater$default$2 ()Lscala/collection/immutable/Iterable; ()Lscala/collection/immutable/Iterable<Ljava/lang/String;>; -
 method public $lessinit$greater$default$3 ()Lscala/Option; ()Lscala/Option<Lakka/routing/Resizer;>; -
 method public $lessinit$greater$default$4 ()Ljava/lang/String; - -
 method public $lessinit$greater$default$5 ()Lakka/actor/SupervisorStrategy; - -
in 0
class akka/routing/SmallestMailboxRoutingLogic 50 public,super java/lang/Object akka/routing/RoutingLogic -
 field public,static,final serialVersionUID J - J1
 method public,static apply ()Lakka/routing/SmallestMailboxRoutingLogic; - -
 method public select (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq;)Lakka/routing/Routee; (Ljava/lang/Object;Lscala/collection/immutable/IndexedSeq<Lakka/routing/Routee;>;)Lakka/routing/Routee; -
 method public isTerminated (Lakka/routing/Routee;)Z - -
 method public isProcessingMessage (Lakka/routing/Routee;)Z - -
 method public hasMessages (Lakka/routing/Routee;)Z - -
 method public isSuspended (Lakka/routing/Routee;)Z - -
 method public numberOfMessages (Lakka/routing/Routee;)I - -
 method public <init> ()V - -
in 0
class akka/routing/SmallestMailboxRoutingLogic$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lakka/routing/SmallestMailboxRoutingLogic$; -
 method public,static <clinit> ()V - -
 method public apply ()Lakka/routing/SmallestMailboxRoutingLogic; - -
in 0
class akka/routing/WithListeners 50 public,super java/lang/Object akka/routing/ListenerMessage,scala/Product,scala/Serializable -
 method public,static unapply (Lakka/routing/WithListeners;)Lscala/Option; (Lakka/routing/WithListeners;)Lscala/Option<Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;>; -
 method public,static apply (Lscala/Function1;)Lakka/routing/WithListeners; (Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;)Lakka/routing/WithListeners; -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lakka/routing/WithListeners;TA;>;)Lscala/Function1<Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;>;)Lscala/Function1<TA;Lakka/routing/WithListeners;>; -
 method public f ()Lscala/Function1; ()Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>; -
 method public copy (Lscala/Function1;)Lakka/routing/WithListeners; (Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;)Lakka/routing/WithListeners; -
 method public copy$default$1 ()Lscala/Function1; ()Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/Function1;)V (Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;)V -
in 0
class akka/routing/WithListeners$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;Lakka/routing/WithListeners;>;Lscala/Serializable;
 field public,static,final MODULE$ Lakka/routing/WithListeners$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/Function1;)Lakka/routing/WithListeners; (Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;)Lakka/routing/WithListeners; -
 method public unapply (Lakka/routing/WithListeners;)Lscala/Option; (Lakka/routing/WithListeners;)Lscala/Option<Lscala/Function1<Lakka/actor/ActorRef;Lscala/runtime/BoxedUnit;>;>; -
