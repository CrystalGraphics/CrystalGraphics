cg-stub-db 1
in 24
class net/minecraft/crash/CrashReport 50 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getDescription ()Ljava/lang/String; - -
 method public getCrashCause ()Ljava/lang/Throwable; - -
 method public getSectionsInStringBuilder (Ljava/lang/StringBuilder;)V - -
 method public getCauseStackTraceOrString ()Ljava/lang/String; - -
 method public getCompleteReport ()Ljava/lang/String; - -
 method public getFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getCategory ()Lnet/minecraft/crash/CrashReportCategory; - -
 method public makeCategory (Ljava/lang/String;)Lnet/minecraft/crash/CrashReportCategory; - -
 method public makeCategoryDepth (Ljava/lang/String;I)Lnet/minecraft/crash/CrashReportCategory; - -
 method public,static makeCrashReport (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/crash/CrashReport; - -
in 326
class net/minecraft/crash/CrashReport 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getDescription ()Ljava/lang/String; - -
 method public getCrashCause ()Ljava/lang/Throwable; - -
 method public getSectionsInStringBuilder (Ljava/lang/StringBuilder;)V - -
 method public getCauseStackTraceOrString ()Ljava/lang/String; - -
 method public getCompleteReport ()Ljava/lang/String; - -
 method public getFile ()Ljava/io/File; - -
 method public saveToFile (Ljava/io/File;)Z - -
 method public getCategory ()Lnet/minecraft/crash/CrashReportCategory; - -
 method public makeCategory (Ljava/lang/String;)Lnet/minecraft/crash/CrashReportCategory; - -
 method public makeCategoryDepth (Ljava/lang/String;I)Lnet/minecraft/crash/CrashReportCategory; - -
 method public,static makeCrashReport (Ljava/lang/Throwable;Ljava/lang/String;)Lnet/minecraft/crash/CrashReport; - -
in 90
class net/minecraft/crash/CrashReportCategory 50 public,super java/lang/Object - -
 inner net/minecraft/crash/CrashReportCategory$Entry net/minecraft/crash/CrashReportCategory Entry static
 method public <init> (Lnet/minecraft/crash/CrashReport;Ljava/lang/String;)V - -
 method public,static getCoordinateInfo (DDD)Ljava/lang/String; - -
 method public,static getCoordinateInfo (Lnet/minecraft/util/BlockPos;)Ljava/lang/String; - -
 method public addCrashSectionCallable (Ljava/lang/String;Ljava/util/concurrent/Callable;)V (Ljava/lang/String;Ljava/util/concurrent/Callable<Ljava/lang/String;>;)V -
 method public addCrashSection (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public addCrashSectionThrowable (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getPrunedStackTrace (I)I - -
 method public firstTwoElementsOfStackTraceMatch (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStackTraceEntriesFromBottom (I)V - -
 method public appendToStringBuilder (Ljava/lang/StringBuilder;)V - -
 method public getStackTrace ()[Ljava/lang/StackTraceElement; - -
 method public,static addBlockInfo (Lnet/minecraft/crash/CrashReportCategory;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;I)V - -
 method public,static addBlockInfo (Lnet/minecraft/crash/CrashReportCategory;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
in 91
class net/minecraft/crash/CrashReportCategory 50 public,super java/lang/Object - -
 inner net/minecraft/crash/CrashReportCategory$Entry net/minecraft/crash/CrashReportCategory Entry static
 method public <init> (Lnet/minecraft/crash/CrashReport;Ljava/lang/String;)V - -
 method public,static getCoordinateInfo (DDD)Ljava/lang/String; - -
 method public,static getCoordinateInfo (Lnet/minecraft/util/math/BlockPos;)Ljava/lang/String; - -
 method public,static getCoordinateInfo (III)Ljava/lang/String; - -
 method public setDetail (Ljava/lang/String;Lnet/minecraft/crash/ICrashReportDetail;)V (Ljava/lang/String;Lnet/minecraft/crash/ICrashReportDetail<Ljava/lang/String;>;)V -
 method public addCrashSection (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public addCrashSectionThrowable (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getPrunedStackTrace (I)I - -
 method public firstTwoElementsOfStackTraceMatch (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStackTraceEntriesFromBottom (I)V - -
 method public appendToStringBuilder (Ljava/lang/StringBuilder;)V - -
 method public getStackTrace ()[Ljava/lang/StackTraceElement; - -
 method public,static addBlockInfo (Lnet/minecraft/crash/CrashReportCategory;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;I)V - -
 method public,static addBlockInfo (Lnet/minecraft/crash/CrashReportCategory;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
in 326
class net/minecraft/crash/CrashReportCategory 52 public,super java/lang/Object - -
 inner net/minecraft/crash/CrashReportCategory$Entry net/minecraft/crash/CrashReportCategory Entry static
 method public <init> (Lnet/minecraft/crash/CrashReport;Ljava/lang/String;)V - -
 method public,static getCoordinateInfo (DDD)Ljava/lang/String; - -
 method public,static getCoordinateInfo (Lnet/minecraft/util/math/BlockPos;)Ljava/lang/String; - -
 method public,static getCoordinateInfo (III)Ljava/lang/String; - -
 method public addDetail (Ljava/lang/String;Lnet/minecraft/crash/ICrashReportDetail;)V (Ljava/lang/String;Lnet/minecraft/crash/ICrashReportDetail<Ljava/lang/String;>;)V -
 method public addCrashSection (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public addCrashSectionThrowable (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public getPrunedStackTrace (I)I - -
 method public firstTwoElementsOfStackTraceMatch (Ljava/lang/StackTraceElement;Ljava/lang/StackTraceElement;)Z - -
 method public trimStackTraceEntriesFromBottom (I)V - -
 method public appendToStringBuilder (Ljava/lang/StringBuilder;)V - -
 method public getStackTrace ()[Ljava/lang/StackTraceElement; - -
 method public,static addBlockInfo (Lnet/minecraft/crash/CrashReportCategory;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;I)V - -
 method public,static addBlockInfo (Lnet/minecraft/crash/CrashReportCategory;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
in 24
class net/minecraft/crash/CrashReportCategory$Entry 50 super java/lang/Object - -
 inner net/minecraft/crash/CrashReportCategory$Entry net/minecraft/crash/CrashReportCategory Entry static
 method public <init> (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getKey ()Ljava/lang/String; - -
 method public getValue ()Ljava/lang/String; - -
in 326
class net/minecraft/crash/CrashReportCategory$Entry 52 super java/lang/Object - -
 inner net/minecraft/crash/CrashReportCategory$Entry net/minecraft/crash/CrashReportCategory Entry static
 method public <init> (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getKey ()Ljava/lang/String; - -
 method public getValue ()Ljava/lang/String; - -
in 91
class net/minecraft/crash/ICrashReportDetail 50 public,interface,abstract java/lang/Object java/util/concurrent/Callable <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/Callable<TV;>;
in 326
class net/minecraft/crash/ICrashReportDetail 52 public,interface,abstract java/lang/Object java/util/concurrent/Callable <V:Ljava/lang/Object;>Ljava/lang/Object;Ljava/util/concurrent/Callable<TV;>;
