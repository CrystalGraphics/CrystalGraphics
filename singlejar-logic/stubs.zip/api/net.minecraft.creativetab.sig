cg-stub-db 1
in 90
class net/minecraft/creativetab/CreativeTabs 50 public,super,abstract java/lang/Object - -
 field public,static creativeTabArray [Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabBlock Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabDecorations Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabRedstone Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabTransport Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabMisc Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabAllSearch Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabFood Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabTools Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabCombat Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabBrewing Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabMaterials Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final tabInventory Lnet/minecraft/creativetab/CreativeTabs; -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (ILjava/lang/String;)V - -
 method public getTabIndex ()I - -
 method public setBackgroundImageName (Ljava/lang/String;)Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getTabLabel ()Ljava/lang/String; - -
 method public getTranslatedTabLabel ()Ljava/lang/String; - -
 method public getIconItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public,abstract getTabIconItem ()Lnet/minecraft/item/Item; - -
 method public getIconItemDamage ()I - -
 method public getBackgroundImageName ()Ljava/lang/String; - -
 method public drawInForegroundOfTab ()Z - -
 method public setNoTitle ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public shouldHidePlayerInventory ()Z - -
 method public setNoScrollbar ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getTabColumn ()I - -
 method public isTabInFirstRow ()Z - -
 method public getRelevantEnchantmentTypes ()[Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public,varargs setRelevantEnchantmentTypes ([Lnet/minecraft/enchantment/EnumEnchantmentType;)Lnet/minecraft/creativetab/CreativeTabs; - -
 method public hasRelevantEnchantmentType (Lnet/minecraft/enchantment/EnumEnchantmentType;)Z - -
 method public displayAllReleventItems (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public,varargs addEnchantmentBooksToList (Ljava/util/List;[Lnet/minecraft/enchantment/EnumEnchantmentType;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;[Lnet/minecraft/enchantment/EnumEnchantmentType;)V -
 method public getTabPage ()I - -
 method public,static getNextID ()I - -
 method public hasSearchBar ()Z - -
 method public getSearchbarWidth ()I - -
in 91
class net/minecraft/creativetab/CreativeTabs 50 public,super,abstract java/lang/Object - -
 field public,static CREATIVE_TAB_ARRAY [Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final BUILDING_BLOCKS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final DECORATIONS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final REDSTONE Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final TRANSPORTATION Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final MISC Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final SEARCH Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final FOOD Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final TOOLS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final COMBAT Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final BREWING Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final MATERIALS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final INVENTORY Lnet/minecraft/creativetab/CreativeTabs; -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (ILjava/lang/String;)V - -
 method public getTabIndex ()I - -
 method public setBackgroundImageName (Ljava/lang/String;)Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getTabLabel ()Ljava/lang/String; - -
 method public getTranslatedTabLabel ()Ljava/lang/String; - -
 method public getIconItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public,abstract getTabIconItem ()Lnet/minecraft/item/Item; - -
 method public getIconItemDamage ()I - -
 method public getBackgroundImageName ()Ljava/lang/String; - -
 method public drawInForegroundOfTab ()Z - -
 method public setNoTitle ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public shouldHidePlayerInventory ()Z - -
 method public setNoScrollbar ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getTabColumn ()I - -
 method public isTabInFirstRow ()Z - -
 method public getRelevantEnchantmentTypes ()[Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public,varargs setRelevantEnchantmentTypes ([Lnet/minecraft/enchantment/EnumEnchantmentType;)Lnet/minecraft/creativetab/CreativeTabs; - -
 method public hasRelevantEnchantmentType (Lnet/minecraft/enchantment/EnumEnchantmentType;)Z - -
 method public displayAllRelevantItems (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public,varargs addEnchantmentBooksToList (Ljava/util/List;[Lnet/minecraft/enchantment/EnumEnchantmentType;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;[Lnet/minecraft/enchantment/EnumEnchantmentType;)V -
 method public getTabPage ()I - -
 method public,static getNextID ()I - -
 method public hasSearchBar ()Z - -
 method public getSearchbarWidth ()I - -
in 326
class net/minecraft/creativetab/CreativeTabs 52 public,super,abstract java/lang/Object - -
 field public,static CREATIVE_TAB_ARRAY [Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final BUILDING_BLOCKS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final DECORATIONS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final REDSTONE Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final TRANSPORTATION Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final MISC Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final SEARCH Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final FOOD Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final TOOLS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final COMBAT Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final BREWING Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final MATERIALS Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final HOTBAR Lnet/minecraft/creativetab/CreativeTabs; -
 field public,static,final INVENTORY Lnet/minecraft/creativetab/CreativeTabs; -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (ILjava/lang/String;)V - -
 method public getIndex ()I - -
 method public setBackgroundImageName (Ljava/lang/String;)Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getTabLabel ()Ljava/lang/String; - -
 method public getTranslationKey ()Ljava/lang/String; - -
 method public getIcon ()Lnet/minecraft/item/ItemStack; - -
 method public,abstract createIcon ()Lnet/minecraft/item/ItemStack; - -
 method public getBackgroundImageName ()Ljava/lang/String; - -
 method public drawInForegroundOfTab ()Z - -
 method public setNoTitle ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public hasScrollbar ()Z - -
 method public setNoScrollbar ()Lnet/minecraft/creativetab/CreativeTabs; - -
 method public getColumn ()I - -
 method public isOnTopRow ()Z - -
 method public isAlignedRight ()Z - -
 method public getRelevantEnchantmentTypes ()[Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public,varargs setRelevantEnchantmentTypes ([Lnet/minecraft/enchantment/EnumEnchantmentType;)Lnet/minecraft/creativetab/CreativeTabs; - -
 method public hasRelevantEnchantmentType (Lnet/minecraft/enchantment/EnumEnchantmentType;)Z - -
 method public displayAllRelevantItems (Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public getTabPage ()I - -
 method public,static getNextID ()I - -
 method public hasSearchBar ()Z - -
 method public getSearchbarWidth ()I - -
 method public getBackgroundImage ()Lnet/minecraft/util/ResourceLocation; - -
 method public getLabelColor ()I - -
