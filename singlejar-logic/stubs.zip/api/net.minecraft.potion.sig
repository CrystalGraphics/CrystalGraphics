cg-stub-db 1
in 90
class net/minecraft/potion/Potion 50 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field public,static,final potionTypes [Lnet/minecraft/potion/Potion; -
 field public,static,final field_180151_b Lnet/minecraft/potion/Potion; -
 field public,static,final moveSpeed Lnet/minecraft/potion/Potion; -
 field public,static,final moveSlowdown Lnet/minecraft/potion/Potion; -
 field public,static,final digSpeed Lnet/minecraft/potion/Potion; -
 field public,static,final digSlowdown Lnet/minecraft/potion/Potion; -
 field public,static,final damageBoost Lnet/minecraft/potion/Potion; -
 field public,static,final heal Lnet/minecraft/potion/Potion; -
 field public,static,final harm Lnet/minecraft/potion/Potion; -
 field public,static,final jump Lnet/minecraft/potion/Potion; -
 field public,static,final confusion Lnet/minecraft/potion/Potion; -
 field public,static,final regeneration Lnet/minecraft/potion/Potion; -
 field public,static,final resistance Lnet/minecraft/potion/Potion; -
 field public,static,final fireResistance Lnet/minecraft/potion/Potion; -
 field public,static,final waterBreathing Lnet/minecraft/potion/Potion; -
 field public,static,final invisibility Lnet/minecraft/potion/Potion; -
 field public,static,final blindness Lnet/minecraft/potion/Potion; -
 field public,static,final nightVision Lnet/minecraft/potion/Potion; -
 field public,static,final hunger Lnet/minecraft/potion/Potion; -
 field public,static,final weakness Lnet/minecraft/potion/Potion; -
 field public,static,final poison Lnet/minecraft/potion/Potion; -
 field public,static,final wither Lnet/minecraft/potion/Potion; -
 field public,static,final healthBoost Lnet/minecraft/potion/Potion; -
 field public,static,final absorption Lnet/minecraft/potion/Potion; -
 field public,static,final saturation Lnet/minecraft/potion/Potion; -
 field public,static,final field_180153_z Lnet/minecraft/potion/Potion; -
 field public,static,final field_180147_A Lnet/minecraft/potion/Potion; -
 field public,static,final field_180148_B Lnet/minecraft/potion/Potion; -
 field public,static,final field_180149_C Lnet/minecraft/potion/Potion; -
 field public,static,final field_180143_D Lnet/minecraft/potion/Potion; -
 field public,static,final field_180144_E Lnet/minecraft/potion/Potion; -
 field public,static,final field_180145_F Lnet/minecraft/potion/Potion; -
 field public,static,final field_180146_G Lnet/minecraft/potion/Potion; -
 field public id I -
 method protected,deprecated <init> (ILnet/minecraft/util/ResourceLocation;ZI)V - -
 method protected <init> (Lnet/minecraft/util/ResourceLocation;ZI)V - -
 method public,static getPotionFromResourceLocation (Ljava/lang/String;)Lnet/minecraft/potion/Potion; - -
 method public,static getPotionLocations ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/util/ResourceLocation;>; -
 method protected setIconIndex (II)Lnet/minecraft/potion/Potion; - -
 method public getId ()I - -
 method public performEffect (Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public affectEntity (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EntityLivingBase;ID)V - -
 method public isInstant ()Z - -
 method public isReady (II)Z - -
 method public setPotionName (Ljava/lang/String;)Lnet/minecraft/potion/Potion; - -
 method public getName ()Ljava/lang/String; - -
 method protected setEffectiveness (D)Lnet/minecraft/potion/Potion; - -
 method public hasStatusIcon ()Z - -
 method public getStatusIconIndex ()I - -
 method public isBadEffect ()Z - -
 method public,static getDurationString (Lnet/minecraft/potion/PotionEffect;)Ljava/lang/String; - -
 method public getEffectiveness ()D - -
 method public isUsable ()Z - -
 method public getLiquidColor ()I - -
 method public registerPotionAttributeModifier (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;DI)Lnet/minecraft/potion/Potion; - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;I)V - -
 method public getAttributeModifierMap ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public applyAttributesModifiersToEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;I)V - -
 method public getAttributeModifierAmount (ILnet/minecraft/entity/ai/attributes/AttributeModifier;)D - -
 method public shouldRender (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public shouldRenderInvText (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public renderInventoryEffect (IILnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/Minecraft;)V - -
in 91
class net/minecraft/potion/Potion 50 public,super net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl - Lnet/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl<Lnet/minecraft/potion/Potion;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl net/minecraftforge/fml/common/registry/IForgeRegistryEntry Impl public,static
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespaced; Lnet/minecraft/util/registry/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/potion/Potion;>;
 method public,static getPotionById (I)Lnet/minecraft/potion/Potion; - -
 method public,static getIdFromPotion (Lnet/minecraft/potion/Potion;)I - -
 method public,static getPotionFromResourceLocation (Ljava/lang/String;)Lnet/minecraft/potion/Potion; - -
 method protected <init> (ZI)V - -
 method protected setIconIndex (II)Lnet/minecraft/potion/Potion; - -
 method public performEffect (Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public affectEntity (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EntityLivingBase;ID)V - -
 method public isReady (II)Z - -
 method public isInstant ()Z - -
 method public setPotionName (Ljava/lang/String;)Lnet/minecraft/potion/Potion; - -
 method public getName ()Ljava/lang/String; - -
 method protected setEffectiveness (D)Lnet/minecraft/potion/Potion; - -
 method public hasStatusIcon ()Z - -
 method public getStatusIconIndex ()I - -
 method public isBadEffect ()Z - -
 method public,static getPotionDurationString (Lnet/minecraft/potion/PotionEffect;F)Ljava/lang/String; - -
 method public getLiquidColor ()I - -
 method public registerPotionAttributeModifier (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;DI)Lnet/minecraft/potion/Potion; - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
 method public getAttributeModifierMap ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public applyAttributesModifiersToEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
 method public getAttributeModifierAmount (ILnet/minecraft/entity/ai/attributes/AttributeModifier;)D - -
 method public shouldRender (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public shouldRenderInvText (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public shouldRenderHUD (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public renderInventoryEffect (IILnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/Minecraft;)V - -
 method public renderHUDEffect (IILnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/Minecraft;F)V - -
 method public isBeneficial ()Z - -
 method public setBeneficial ()Lnet/minecraft/potion/Potion; - -
 method public,static registerPotions ()V - -
in 326
class net/minecraft/potion/Potion 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl - Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/potion/Potion;>;
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespaced; Lnet/minecraft/util/registry/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/potion/Potion;>;
 method public,static getPotionById (I)Lnet/minecraft/potion/Potion; - -
 method public,static getIdFromPotion (Lnet/minecraft/potion/Potion;)I - -
 method public,static getPotionFromResourceLocation (Ljava/lang/String;)Lnet/minecraft/potion/Potion; - -
 method protected <init> (ZI)V - -
 method protected setIconIndex (II)Lnet/minecraft/potion/Potion; - -
 method public performEffect (Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public affectEntity (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/EntityLivingBase;ID)V - -
 method public isReady (II)Z - -
 method public isInstant ()Z - -
 method public setPotionName (Ljava/lang/String;)Lnet/minecraft/potion/Potion; - -
 method public getName ()Ljava/lang/String; - -
 method protected setEffectiveness (D)Lnet/minecraft/potion/Potion; - -
 method public hasStatusIcon ()Z - -
 method public getStatusIconIndex ()I - -
 method public isBadEffect ()Z - -
 method public,static getPotionDurationString (Lnet/minecraft/potion/PotionEffect;F)Ljava/lang/String; - -
 method public getLiquidColor ()I - -
 method public registerPotionAttributeModifier (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;DI)Lnet/minecraft/potion/Potion; - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
 method public getAttributeModifierMap ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public applyAttributesModifiersToEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
 method public getAttributeModifierAmount (ILnet/minecraft/entity/ai/attributes/AttributeModifier;)D - -
 method public shouldRender (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public shouldRenderInvText (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public shouldRenderHUD (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public,deprecated renderInventoryEffect (IILnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/Minecraft;)V - -
 method public renderInventoryEffect (Lnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/gui/Gui;IIF)V - -
 method public,deprecated renderHUDEffect (IILnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/Minecraft;F)V - -
 method public renderHUDEffect (Lnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/gui/Gui;IIFF)V - -
 method public getCurativeItems ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public getGuiSortColor (Lnet/minecraft/potion/PotionEffect;)I - -
 method public isBeneficial ()Z - -
 method public setBeneficial ()Lnet/minecraft/potion/Potion; - -
 method public,static registerPotions ()V - -
in 90
class net/minecraft/potion/PotionAbsorption 50 public,super net/minecraft/potion/Potion - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;ZI)V - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;I)V - -
 method public applyAttributesModifiersToEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;I)V - -
in 91
class net/minecraft/potion/PotionAbsorption 50 public,super net/minecraft/potion/Potion - -
 method protected <init> (ZI)V - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
 method public applyAttributesModifiersToEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
in 326
class net/minecraft/potion/PotionAbsorption 52 public,super net/minecraft/potion/Potion - -
 method protected <init> (ZI)V - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
 method public applyAttributesModifiersToEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
in 90
class net/minecraft/potion/PotionAttackDamage 50 public,super net/minecraft/potion/Potion - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;ZI)V - -
 method public getAttributeModifierAmount (ILnet/minecraft/entity/ai/attributes/AttributeModifier;)D - -
in 91
class net/minecraft/potion/PotionAttackDamage 50 public,super net/minecraft/potion/Potion - -
 field protected,final bonusPerLevel D -
 method protected <init> (ZID)V - -
 method public getAttributeModifierAmount (ILnet/minecraft/entity/ai/attributes/AttributeModifier;)D - -
in 326
class net/minecraft/potion/PotionAttackDamage 52 public,super net/minecraft/potion/Potion - -
 field protected,final bonusPerLevel D -
 method protected <init> (ZID)V - -
 method public getAttributeModifierAmount (ILnet/minecraft/entity/ai/attributes/AttributeModifier;)D - -
in 90
class net/minecraft/potion/PotionEffect 50 public,super java/lang/Object - -
 method public <init> (II)V - -
 method public <init> (III)V - -
 method public <init> (IIIZZ)V - -
 method public <init> (Lnet/minecraft/potion/PotionEffect;)V - -
 method public combine (Lnet/minecraft/potion/PotionEffect;)V - -
 method public getPotionID ()I - -
 method public getDuration ()I - -
 method public getAmplifier ()I - -
 method public setSplashPotion (Z)V - -
 method public getIsAmbient ()Z - -
 method public getIsShowParticles ()Z - -
 method public onUpdate (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public performEffect (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEffectName ()Ljava/lang/String; - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public writeCustomPotionEffectToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static readCustomPotionEffectFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/potion/PotionEffect; - -
 method public setPotionDurationMax (Z)V - -
 method public getIsPotionDurationMax ()Z - -
 method public getCurativeItems ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public isCurativeItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public setCurativeItems (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public addCurativeItem (Lnet/minecraft/item/ItemStack;)V - -
in 91
class net/minecraft/potion/PotionEffect 50 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/potion/PotionEffect;>;
 method public <init> (Lnet/minecraft/potion/Potion;)V - -
 method public <init> (Lnet/minecraft/potion/Potion;I)V - -
 method public <init> (Lnet/minecraft/potion/Potion;II)V - -
 method public <init> (Lnet/minecraft/potion/Potion;IIZZ)V - -
 method public <init> (Lnet/minecraft/potion/PotionEffect;)V - -
 method public combine (Lnet/minecraft/potion/PotionEffect;)V - -
 method public getPotion ()Lnet/minecraft/potion/Potion; - -
 method public getDuration ()I - -
 method public getAmplifier ()I - -
 method public getIsAmbient ()Z - -
 method public doesShowParticles ()Z - -
 method public onUpdate (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public performEffect (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEffectName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public writeCustomPotionEffectToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static readCustomPotionEffectFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/potion/PotionEffect; - -
 method public setPotionDurationMax (Z)V - -
 method public compareTo (Lnet/minecraft/potion/PotionEffect;)I - -
 method public getIsPotionDurationMax ()Z - -
 method public getCurativeItems ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public isCurativeItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public setCurativeItems (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public addCurativeItem (Lnet/minecraft/item/ItemStack;)V - -
in 326
class net/minecraft/potion/PotionEffect 52 public,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/potion/PotionEffect;>;
 inner net/minecraftforge/common/util/Constants$NBT net/minecraftforge/common/util/Constants NBT public,static
 method public <init> (Lnet/minecraft/potion/Potion;)V - -
 method public <init> (Lnet/minecraft/potion/Potion;I)V - -
 method public <init> (Lnet/minecraft/potion/Potion;II)V - -
 method public <init> (Lnet/minecraft/potion/Potion;IIZZ)V - -
 method public <init> (Lnet/minecraft/potion/PotionEffect;)V - -
 method public combine (Lnet/minecraft/potion/PotionEffect;)V - -
 method public getPotion ()Lnet/minecraft/potion/Potion; - -
 method public getDuration ()I - -
 method public getAmplifier ()I - -
 method public getIsAmbient ()Z - -
 method public doesShowParticles ()Z - -
 method public onUpdate (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public performEffect (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEffectName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public writeCustomPotionEffectToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static readCustomPotionEffectFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/potion/PotionEffect; - -
 method public setPotionDurationMax (Z)V - -
 method public compareTo (Lnet/minecraft/potion/PotionEffect;)I - -
 method public getIsPotionDurationMax ()Z - -
 method public getCurativeItems ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public isCurativeItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public setCurativeItems (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public addCurativeItem (Lnet/minecraft/item/ItemStack;)V - -
in 90
class net/minecraft/potion/PotionHealth 50 public,super net/minecraft/potion/Potion - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;ZI)V - -
 method public isInstant ()Z - -
 method public isReady (II)Z - -
in 91
class net/minecraft/potion/PotionHealth 50 public,super net/minecraft/potion/Potion - -
 method public <init> (ZI)V - -
 method public isInstant ()Z - -
 method public isReady (II)Z - -
in 326
class net/minecraft/potion/PotionHealth 52 public,super net/minecraft/potion/Potion - -
 method public <init> (ZI)V - -
 method public isInstant ()Z - -
 method public isReady (II)Z - -
in 90
class net/minecraft/potion/PotionHealthBoost 50 public,super net/minecraft/potion/Potion - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;ZI)V - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;I)V - -
in 91
class net/minecraft/potion/PotionHealthBoost 50 public,super net/minecraft/potion/Potion - -
 method public <init> (ZI)V - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
in 326
class net/minecraft/potion/PotionHealthBoost 52 public,super net/minecraft/potion/Potion - -
 method public <init> (ZI)V - -
 method public removeAttributesModifiersFromEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;I)V - -
in 90
class net/minecraft/potion/PotionHelper 50 public,super java/lang/Object - -
 field public,static,final unusedString Ljava/lang/String; -
 field public,static,final sugarEffect Ljava/lang/String; -
 field public,static,final ghastTearEffect Ljava/lang/String; -
 field public,static,final spiderEyeEffect Ljava/lang/String; -
 field public,static,final fermentedSpiderEyeEffect Ljava/lang/String; -
 field public,static,final speckledMelonEffect Ljava/lang/String; -
 field public,static,final blazePowderEffect Ljava/lang/String; -
 field public,static,final magmaCreamEffect Ljava/lang/String; -
 field public,static,final redstoneEffect Ljava/lang/String; -
 field public,static,final glowstoneEffect Ljava/lang/String; -
 field public,static,final gunpowderEffect Ljava/lang/String; -
 field public,static,final goldenCarrotEffect Ljava/lang/String; -
 field public,static,final pufferfishEffect Ljava/lang/String; -
 field public,static,final rabbitFootEffect Ljava/lang/String; -
 method public,static getLiquidColor (IZ)I - -
 method public,static checkFlag (II)Z - -
 method public,static getPotionPrefixIndex (I)I - -
 method public,static calcPotionLiquidColor (Ljava/util/Collection;)I (Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)I -
 method public,static getAreAmbient (Ljava/util/Collection;)Z (Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)Z -
 method public,static getPotionPrefix (I)Ljava/lang/String; - -
 method public,static getPotionEffects (IZ)Ljava/util/List; (IZ)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static applyIngredient (ILjava/lang/String;)I - -
 method public,static getPotionPrefixIndexFlags (IIIIII)I - -
in 91
class net/minecraft/potion/PotionHelper 50 public,super java/lang/Object - -
 inner net/minecraft/potion/PotionHelper$ItemPredicateInstance net/minecraft/potion/PotionHelper ItemPredicateInstance public,static
 inner net/minecraft/potion/PotionHelper$MixPredicate net/minecraft/potion/PotionHelper MixPredicate public,static
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 method public,static isReagent (Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static isItemConversionReagent (Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static isTypeConversionReagent (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static hasConversions (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static hasItemConversions (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static hasTypeConversions (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static doReaction (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public,static init ()V - -
 method public,static registerPotionItemConversion (Lnet/minecraft/item/ItemPotion;Lnet/minecraft/potion/PotionHelper$ItemPredicateInstance;Lnet/minecraft/item/ItemPotion;)V - -
 method public,static registerPotionItem (Lnet/minecraft/potion/PotionHelper$ItemPredicateInstance;)V - -
 method public,static registerPotionTypeConversion (Lnet/minecraft/potion/PotionType;Lcom/google/common/base/Predicate;Lnet/minecraft/potion/PotionType;)V (Lnet/minecraft/potion/PotionType;Lcom/google/common/base/Predicate<Lnet/minecraft/item/ItemStack;>;Lnet/minecraft/potion/PotionType;)V -
in 326
class net/minecraft/potion/PotionHelper 52 public,super java/lang/Object - -
 inner net/minecraft/potion/PotionHelper$MixPredicate net/minecraft/potion/PotionHelper MixPredicate static
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 method public <init> ()V - -
 method public,static isReagent (Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static isItemConversionReagent (Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static isTypeConversionReagent (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static hasConversions (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static hasItemConversions (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method protected,static hasTypeConversions (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Z - -
 method public,static doReaction (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public,static init ()V - -
 method public,static addContainerRecipe (Lnet/minecraft/item/ItemPotion;Lnet/minecraft/item/Item;Lnet/minecraft/item/ItemPotion;)V - -
 method public,static addContainer (Lnet/minecraft/item/ItemPotion;)V - -
 method public,static addMix (Lnet/minecraft/potion/PotionType;Lnet/minecraft/item/Item;Lnet/minecraft/potion/PotionType;)V - -
 method public,static addMix (Lnet/minecraft/potion/PotionType;Lnet/minecraft/item/crafting/Ingredient;Lnet/minecraft/potion/PotionType;)V - -
in 91
class net/minecraft/potion/PotionHelper$ItemPredicateInstance 50 public,super java/lang/Object com/google/common/base/Predicate Ljava/lang/Object;Lcom/google/common/base/Predicate<Lnet/minecraft/item/ItemStack;>;
 inner net/minecraft/potion/PotionHelper$ItemPredicateInstance net/minecraft/potion/PotionHelper ItemPredicateInstance public,static
 method public <init> (Lnet/minecraft/item/Item;)V - -
 method public <init> (Lnet/minecraft/item/Item;I)V - -
 method public apply (Lnet/minecraft/item/ItemStack;)Z - -
in 91
class net/minecraft/potion/PotionHelper$MixPredicate 50 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/potion/PotionHelper$MixPredicate net/minecraft/potion/PotionHelper MixPredicate public,static
 method public <init> (Ljava/lang/Object;Lcom/google/common/base/Predicate;Ljava/lang/Object;)V (TT;Lcom/google/common/base/Predicate<Lnet/minecraft/item/ItemStack;>;TT;)V -
in 326
class net/minecraft/potion/PotionHelper$MixPredicate 52 super java/lang/Object - <T:Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<TT;>;>Ljava/lang/Object;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 inner net/minecraft/potion/PotionHelper$MixPredicate net/minecraft/potion/PotionHelper MixPredicate static
 method public <init> (Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl;Lnet/minecraft/item/crafting/Ingredient;Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl;)V (TT;Lnet/minecraft/item/crafting/Ingredient;TT;)V -
in 91
class net/minecraft/potion/PotionType 50 public,super net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl - Lnet/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl<Lnet/minecraft/potion/PotionType;>;
 inner net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl net/minecraftforge/fml/common/registry/IForgeRegistryEntry Impl public,static
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespacedDefaultedByKey; Lnet/minecraft/util/registry/RegistryNamespacedDefaultedByKey<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/potion/PotionType;>;
 method public,static getPotionTypeForID (I)Lnet/minecraft/potion/PotionType; - -
 method public,static getID (Lnet/minecraft/potion/PotionType;)I - -
 method public,static getPotionTypeForName (Ljava/lang/String;)Lnet/minecraft/potion/PotionType; - -
 method public,varargs <init> ([Lnet/minecraft/potion/PotionEffect;)V - -
 method public,varargs <init> (Ljava/lang/String;[Lnet/minecraft/potion/PotionEffect;)V - -
 method public getNamePrefixed (Ljava/lang/String;)Ljava/lang/String; - -
 method public getEffects ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static registerPotionTypes ()V - -
 method protected,static registerPotionType (Ljava/lang/String;Lnet/minecraft/potion/PotionType;)V - -
 method public hasInstantEffect ()Z - -
in 326
class net/minecraft/potion/PotionType 52 public,super net/minecraftforge/registries/IForgeRegistryEntry$Impl - Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/potion/PotionType;>;
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespacedDefaultedByKey; Lnet/minecraft/util/registry/RegistryNamespacedDefaultedByKey<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/potion/PotionType;>;
 method public,static getPotionTypeForName (Ljava/lang/String;)Lnet/minecraft/potion/PotionType; - -
 method public,varargs <init> ([Lnet/minecraft/potion/PotionEffect;)V - -
 method public,varargs <init> (Ljava/lang/String;[Lnet/minecraft/potion/PotionEffect;)V - -
 method public getNamePrefixed (Ljava/lang/String;)Ljava/lang/String; - -
 method public getEffects ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static registerPotionTypes ()V - -
 method protected,static registerPotionType (Ljava/lang/String;Lnet/minecraft/potion/PotionType;)V - -
 method public hasInstantEffect ()Z - -
in 91
class net/minecraft/potion/PotionUtils 50 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static getPotionColor (Lnet/minecraft/potion/PotionType;)I - -
 method public,static addPotionTooltip (Lnet/minecraft/item/ItemStack;Ljava/util/List;F)V (Lnet/minecraft/item/ItemStack;Ljava/util/List<Ljava/lang/String;>;F)V -
 method public,static getEffectsFromStack (Lnet/minecraft/item/ItemStack;)Ljava/util/List; (Lnet/minecraft/item/ItemStack;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static mergeEffects (Lnet/minecraft/potion/PotionType;Ljava/util/Collection;)Ljava/util/List; (Lnet/minecraft/potion/PotionType;Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static getEffectsFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List; (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static getFullEffectsFromItem (Lnet/minecraft/item/ItemStack;)Ljava/util/List; (Lnet/minecraft/item/ItemStack;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static getFullEffectsFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List; (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static addCustomPotionEffectToList (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List;)V (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>;)V -
 method public,static getPotionColorFromEffectList (Ljava/util/Collection;)I (Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)I -
 method public,static getPotionFromItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/potion/PotionType; - -
 method public,static getPotionTypeFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/potion/PotionType; - -
 method public,static addPotionToItemStack (Lnet/minecraft/item/ItemStack;Lnet/minecraft/potion/PotionType;)Lnet/minecraft/item/ItemStack; - -
 method public,static appendEffects (Lnet/minecraft/item/ItemStack;Ljava/util/Collection;)Lnet/minecraft/item/ItemStack; (Lnet/minecraft/item/ItemStack;Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)Lnet/minecraft/item/ItemStack; -
in 326
class net/minecraft/potion/PotionUtils 52 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static getEffectsFromStack (Lnet/minecraft/item/ItemStack;)Ljava/util/List; (Lnet/minecraft/item/ItemStack;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static mergeEffects (Lnet/minecraft/potion/PotionType;Ljava/util/Collection;)Ljava/util/List; (Lnet/minecraft/potion/PotionType;Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static getEffectsFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List; (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static getFullEffectsFromItem (Lnet/minecraft/item/ItemStack;)Ljava/util/List; (Lnet/minecraft/item/ItemStack;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static getFullEffectsFromTag (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List; (Lnet/minecraft/nbt/NBTTagCompound;)Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>; -
 method public,static addCustomPotionEffectToList (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List;)V (Lnet/minecraft/nbt/NBTTagCompound;Ljava/util/List<Lnet/minecraft/potion/PotionEffect;>;)V -
 method public,static getColor (Lnet/minecraft/item/ItemStack;)I - -
 method public,static getPotionColor (Lnet/minecraft/potion/PotionType;)I - -
 method public,static getPotionColorFromEffectList (Ljava/util/Collection;)I (Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)I -
 method public,static getPotionFromItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/potion/PotionType; - -
 method public,static getPotionTypeFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/potion/PotionType; - -
 method public,static addPotionToItemStack (Lnet/minecraft/item/ItemStack;Lnet/minecraft/potion/PotionType;)Lnet/minecraft/item/ItemStack; - -
 method public,static appendEffects (Lnet/minecraft/item/ItemStack;Ljava/util/Collection;)Lnet/minecraft/item/ItemStack; (Lnet/minecraft/item/ItemStack;Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)Lnet/minecraft/item/ItemStack; -
 method public,static addPotionTooltip (Lnet/minecraft/item/ItemStack;Ljava/util/List;F)V (Lnet/minecraft/item/ItemStack;Ljava/util/List<Ljava/lang/String;>;F)V -
