cg-stub-db 1
in 0
class ca/weblite/nativeutils/NativeUtils 49 public,super java/lang/Object - -
 method public,static loadLibraryFromJar (Ljava/lang/String;)V - java/io/IOException
 method public,static loadLibraryFromJar (Ljava/lang/String;Ljava/lang/Class;)V - java/io/IOException
 method public,static loadFileFromJar (Ljava/lang/String;Ljava/lang/Class;)Ljava/io/File; - java/io/IOException
in 1
class ca/weblite/nativeutils/NativeUtils 55 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static loadLibraryFromJar (Ljava/lang/String;)V - java/io/IOException
 method public,static loadLibraryFromJar (Ljava/lang/String;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/Class<*>;)V java/io/IOException,java/lang/UnsatisfiedLinkError
 method public,static extractFromJar (Ljava/lang/String;Ljava/lang/Class;)Ljava/nio/file/Path; (Ljava/lang/String;Ljava/lang/Class<*>;)Ljava/nio/file/Path; java/io/IOException
in 0
class ca/weblite/objc/Client 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getInstance ()Lca/weblite/objc/Client; - -
 method public,static getRawClient ()Lca/weblite/objc/Client; - -
 method public setCoerceInputs (Z)Lca/weblite/objc/Client; - -
 method public setCoerceOutputs (Z)Lca/weblite/objc/Client; - -
 method public getCoerceInputs ()Z - -
 method public getCoerceOutputs ()Z - -
 method public,varargs send (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Lca/weblite/objc/Peerable;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Lca/weblite/objc/Peerable;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs sendPointer (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendProxy (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs chain (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs,deprecated chain (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public newObject (Ljava/lang/Class;)Lca/weblite/objc/PeerableRecipient; (Ljava/lang/Class<+Lca/weblite/objc/PeerableRecipient;>;)Lca/weblite/objc/PeerableRecipient; -
 method public,varargs send ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,varargs buildMessageChain ([Ljava/lang/Object;)[Lca/weblite/objc/Message; - -
in 1
class ca/weblite/objc/Client 55 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getInstance ()Lca/weblite/objc/Client; - -
 method public,static getRawClient ()Lca/weblite/objc/Client; - -
 method public,deprecated setCoerceInputs (Z)Lca/weblite/objc/Client; - -
 method public,deprecated setCoerceOutputs (Z)Lca/weblite/objc/Client; - -
 method public getCoerceInputs ()Z - -
 method public getCoerceOutputs ()Z - -
 method public,varargs send (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Lca/weblite/objc/Peerable;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Lca/weblite/objc/Peerable;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs sendPointer (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendProxy (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs chain (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs chain (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public newObject (Ljava/lang/Class;)Lca/weblite/objc/PeerableRecipient; (Ljava/lang/Class<+Lca/weblite/objc/PeerableRecipient;>;)Lca/weblite/objc/PeerableRecipient; -
 method public,varargs send ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,varargs buildMessageChain ([Ljava/lang/Object;)[Lca/weblite/objc/Message; - -
in 0
class ca/weblite/objc/Message 49 public,super java/lang/Object - -
 field public,static,final STATUS_SKIPPED I - I1
 field public,static,final STATUS_CANCELLED I - I2
 field public,static,final STATUS_COMPLETED I - I3
 field public,static,final STATUS_READY I - I0
 field public receiver Lcom/sun/jna/Pointer; -
 field public selector Lcom/sun/jna/Pointer; -
 field public args Ljava/util/List; -
 field public result Ljava/lang/Object; -
 field public error Ljava/lang/Exception; -
 field public status I -
 field public coerceInput Z -
 field public coerceOutput Z -
 field public inputWasCoerced Z -
 field public outputWasCoerced Z -
 field public next Lca/weblite/objc/Message; -
 field public previous Lca/weblite/objc/Message; -
 method public <init> ()V - -
 method public beforeRequest ()V - -
 method public afterResponse ()V - -
in 1
class ca/weblite/objc/Message 55 public,super java/lang/Object - -
 field public,static,final STATUS_SKIPPED I - I1
 field public,static,final STATUS_CANCELLED I - I2
 field public,static,final STATUS_COMPLETED I - I3
 field public,static,final STATUS_READY I - I0
 field public receiver Lcom/sun/jna/Pointer; -
 field public selector Lcom/sun/jna/Pointer; -
 field public args Ljava/util/List; -
 field public result Ljava/lang/Object; -
 field public error Ljava/lang/Exception; -
 field public status I -
 field public coerceInput Z -
 field public coerceOutput Z -
 field public inputWasCoerced Z -
 field public outputWasCoerced Z -
 field public next Lca/weblite/objc/Message; -
 field public previous Lca/weblite/objc/Message; -
 method public <init> ()V - -
 method public beforeRequest ()V - -
 method public afterResponse ()V - -
in 1
class ca/weblite/objc/NSMessageInvocationException 55 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;Ljava/lang/reflect/Method;Ljava/lang/Throwable;)V - -
 method public getSelectorName ()Ljava/lang/String; - -
 method public getMethod ()Ljava/lang/reflect/Method; - -
in 0
class ca/weblite/objc/NSObject 49 public,super ca/weblite/objc/Proxy ca/weblite/objc/PeerableRecipient -
 field public parent Lcom/sun/jna/Pointer; -
 method protected,static getMethodMap (Ljava/lang/Class;)Ljava/util/Map; (Ljava/lang/Class;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/reflect/Method;>; -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public <init> (Lca/weblite/objc/Client;)V - -
 method public <init> (Lca/weblite/objc/Client;Lcom/sun/jna/Pointer;)V - -
 method public init (Lcom/sun/jna/Pointer;)Lca/weblite/objc/NSObject; - -
 method public init (Ljava/lang/String;)Lca/weblite/objc/NSObject; - -
 method public methodForSelector (Ljava/lang/String;)Ljava/lang/reflect/Method; - -
 method public methodSignatureForSelector (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public methodSignatureForSelector (J)J - -
 method public forwardInvocationToParent (Lcom/sun/jna/Pointer;)V - -
 method public forwardInvocationToParent (J)V - -
 method public forwardInvocation (Lcom/sun/jna/Pointer;)V - -
 method public forwardInvocation (J)V - -
 method public respondsToSelector (Lcom/sun/jna/Pointer;)Z - -
 method public respondsToSelector (J)Z - -
 method public,varargs,deprecated chain (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/NSObject; - -
 method public,varargs,deprecated chain (Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/NSObject; - -
 method public,varargs,deprecated chain ([Lca/weblite/objc/Message;)Lca/weblite/objc/NSObject; - -
 method public,deprecated dealloc ()Lca/weblite/objc/NSObject; - -
in 1
class ca/weblite/objc/NSObject 55 public,super ca/weblite/objc/Proxy ca/weblite/objc/PeerableRecipient -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public parent Lcom/sun/jna/Pointer; -
 method protected,static getMethodMap (Ljava/lang/Class;)Ljava/util/Map; (Ljava/lang/Class<*>;)Ljava/util/Map<Ljava/lang/String;Ljava/lang/reflect/Method;>; -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> ()V - -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public <init> (Lca/weblite/objc/Client;)V - -
 method public <init> (Lca/weblite/objc/Client;Lcom/sun/jna/Pointer;)V - -
 method public init (Lcom/sun/jna/Pointer;)Lca/weblite/objc/NSObject; - -
 method public init (Ljava/lang/String;)Lca/weblite/objc/NSObject; - -
 method public methodForSelector (Ljava/lang/String;)Ljava/lang/reflect/Method; - -
 method public methodSignatureForSelector (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public methodSignatureForSelector (J)J - -
 method public forwardInvocationToParent (Lcom/sun/jna/Pointer;)V - -
 method public forwardInvocationToParent (J)V - -
 method public forwardInvocation (Lcom/sun/jna/Pointer;)V - -
 method public forwardInvocation (J)V - -
 method public respondsToSelector (Lcom/sun/jna/Pointer;)Z - -
 method public respondsToSelector (J)Z - -
 method public,varargs chain (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/NSObject; - -
 method public,varargs chain (Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/NSObject; - -
 method public,varargs chain ([Lca/weblite/objc/Message;)Lca/weblite/objc/NSObject; - -
 method public dealloc ()Lca/weblite/objc/NSObject; - -
in 0
class ca/weblite/objc/Peerable 49 public,interface,abstract java/lang/Object - -
 method public,abstract getPeer ()Lcom/sun/jna/Pointer; - -
 method public,abstract setPeer (Lcom/sun/jna/Pointer;)V - -
in 1
class ca/weblite/objc/Peerable 55 public,interface,abstract java/lang/Object - -
 method public,abstract getPeer ()Lcom/sun/jna/Pointer; - -
 method public,abstract setPeer (Lcom/sun/jna/Pointer;)V - -
in 0
class ca/weblite/objc/PeerableRecipient 49 public,interface,abstract java/lang/Object ca/weblite/objc/Peerable,ca/weblite/objc/Recipient -
in 1
class ca/weblite/objc/PeerableRecipient 55 public,interface,abstract java/lang/Object ca/weblite/objc/Peerable,ca/weblite/objc/Recipient -
in 0
class ca/weblite/objc/Proxy 49 public,super java/lang/Object ca/weblite/objc/Peerable -
 method public,static retain (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static release (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static drainCache ()V - -
 method public <init> ()V - -
 method public <init> (Lca/weblite/objc/Client;)V - -
 method public <init> (Lca/weblite/objc/Client;Lcom/sun/jna/Pointer;)V - -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public,static load (Lcom/sun/jna/Pointer;)Lca/weblite/objc/Proxy; - -
 method public dispose (Z)V - -
 method public,varargs sendPointer (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendProxy (Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendString (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,varargs sendString (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,varargs sendInt (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)I - -
 method public,varargs sendInt (Ljava/lang/String;[Ljava/lang/Object;)I - -
 method public,varargs sendDouble (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)D - -
 method public,varargs sendDouble (Ljava/lang/String;[Ljava/lang/Object;)D - -
 method public,varargs sendBoolean (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Z - -
 method public,varargs sendBoolean (Ljava/lang/String;[Ljava/lang/Object;)Z - -
 method public,varargs send (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,varargs sendRaw (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs sendRaw (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs sendRaw ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,varargs,deprecated chain (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs,deprecated chain (Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs,deprecated chain ([Lca/weblite/objc/Message;)Lca/weblite/objc/Proxy; - -
 method public getClient ()Lca/weblite/objc/Client; - -
 method public setClient (Lca/weblite/objc/Client;)Lca/weblite/objc/Proxy; - -
 method public getPeer ()Lcom/sun/jna/Pointer; - -
 method public setPeer (Lcom/sun/jna/Pointer;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public set (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public get (Ljava/lang/String;)Ljava/lang/Object; - -
 method public getInt (Ljava/lang/String;)I - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public getProxy (Ljava/lang/String;)Lca/weblite/objc/Proxy; - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getPointer (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
in 1
class ca/weblite/objc/Proxy 55 public,super java/lang/Object ca/weblite/objc/Peerable -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static retain (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static release (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static drainCache ()V - -
 method public <init> ()V - -
 method public <init> (Lca/weblite/objc/Client;)V - -
 method public <init> (Lca/weblite/objc/Client;Lcom/sun/jna/Pointer;)V - -
 method public <init> (Lcom/sun/jna/Pointer;)V - -
 method public,static load (Lcom/sun/jna/Pointer;)Lca/weblite/objc/Proxy; - -
 method public dispose (Z)V - -
 method public,varargs sendPointer (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendPointer (Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,varargs sendProxy (Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendProxy (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs sendString (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,varargs sendString (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,varargs sendInt (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)I - -
 method public,varargs sendInt (Ljava/lang/String;[Ljava/lang/Object;)I - -
 method public,varargs sendDouble (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)D - -
 method public,varargs sendDouble (Ljava/lang/String;[Ljava/lang/Object;)D - -
 method public,varargs sendBoolean (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Z - -
 method public,varargs sendBoolean (Ljava/lang/String;[Ljava/lang/Object;)Z - -
 method public,varargs send (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs send ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,varargs sendRaw (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs sendRaw (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,varargs sendRaw ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,varargs chain (Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs chain (Ljava/lang/String;[Ljava/lang/Object;)Lca/weblite/objc/Proxy; - -
 method public,varargs chain ([Lca/weblite/objc/Message;)Lca/weblite/objc/Proxy; - -
 method public getClient ()Lca/weblite/objc/Client; - -
 method public setClient (Lca/weblite/objc/Client;)Lca/weblite/objc/Proxy; - -
 method public getPeer ()Lcom/sun/jna/Pointer; - -
 method public setPeer (Lcom/sun/jna/Pointer;)V - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public set (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public get (Ljava/lang/String;)Ljava/lang/Object; - -
 method public getInt (Ljava/lang/String;)I - -
 method public getBoolean (Ljava/lang/String;)Z - -
 method public getProxy (Ljava/lang/String;)Lca/weblite/objc/Proxy; - -
 method public getDouble (Ljava/lang/String;)D - -
 method public getPointer (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
in 0
class ca/weblite/objc/Recipient 49 public,interface,abstract java/lang/Object - -
 method public,abstract methodSignatureForSelector (J)J - -
 method public,abstract forwardInvocation (J)V - -
 method public,abstract respondsToSelector (J)Z - -
in 1
class ca/weblite/objc/Recipient 55 public,interface,abstract java/lang/Object - -
 method public,abstract methodSignatureForSelector (J)J - -
 method public,abstract forwardInvocation (J)V - -
 method public,abstract respondsToSelector (J)Z - -
in 0
class ca/weblite/objc/Runtime 49 public,interface,abstract java/lang/Object com/sun/jna/Library -
 field public,static,final INSTANCE Lca/weblite/objc/Runtime; -
 method public,abstract objc_lookUpClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract class_getProperty (Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getSuperclass (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getVersion (Lcom/sun/jna/Pointer;)I - -
 method public,abstract class_getWeakIvarLayout (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract class_isMetaClass (Lcom/sun/jna/Pointer;)Z - -
 method public,abstract class_getInstanceSize (Lcom/sun/jna/Pointer;)I - -
 method public,abstract class_getInstanceVariable (Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getInstanceMethod (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getClassMethod (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getIvarLayout (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract class_getMethodImplementation (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getMethodImplementation_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_replaceMethod (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_respondsToSelector (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_setIvarLayout (Lcom/sun/jna/Pointer;Ljava/lang/String;)V - -
 method public,abstract class_setSuperclass (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_setVersion (Lcom/sun/jna/Pointer;I)V - -
 method public,abstract class_setWeakIvarLayout (Lcom/sun/jna/Pointer;Ljava/lang/String;)V - -
 method public,abstract ivar_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract ivar_getOffset (Lcom/sun/jna/Pointer;)J - -
 method public,abstract ivar_getTypeEncoding (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract method_copyArgumentType (Lcom/sun/jna/Pointer;I)Ljava/lang/String; - -
 method public,abstract method_copyReturnType (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract method_exchangeImplementations (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)V - -
 method public,abstract method_getArgumentType (Lcom/sun/jna/Pointer;ILcom/sun/jna/Pointer;J)V - -
 method public,abstract method_getImplementation (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract method_getName (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract method_getNumberOfArguments (Lcom/sun/jna/Pointer;)I - -
 method public,abstract method_getReturnType (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;J)V - -
 method public,abstract method_getTypeEncoding (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract method_setImplementation (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_allocateClassPair (Lcom/sun/jna/Pointer;Ljava/lang/String;J)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_copyProtocolList (Lcom/sun/jna/Pointer;)[Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getAssociatedObject (Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getClassList (Lcom/sun/jna/Pointer;I)I - -
 method public,abstract objc_getFutureClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getMetaClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getProtocol (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getRequiredClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,varargs,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,varargs,abstract objc_msgSendSuper (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,varargs,abstract objc_msgSendSuper_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,varargs,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)D - -
 method public,varargs,abstract objc_msgSend_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)V - -
 method public,abstract objc_registerClassPair (Lcom/sun/jna/Pointer;)V - -
 method public,abstract objc_removeAssociatedObjects (Lcom/sun/jna/Pointer;)V - -
 method public,abstract objc_setAssociatedObject (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)V - -
 method public,abstract objc_setFutureClass (Lcom/sun/jna/Pointer;Ljava/lang/String;)V - -
 method public,abstract object_copy (Lcom/sun/jna/Pointer;J)Lcom/sun/jna/Pointer; - -
 method public,abstract object_dispose (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getClass (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getClassName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract object_getIndexedIvars (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getInstanceVariable (Lcom/sun/jna/Pointer;Ljava/lang/String;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getIvar (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_setClass (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_setInstanceVariable (Lcom/sun/jna/Pointer;Ljava/lang/String;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_setIvar (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)V - -
 method public,abstract property_getAttributes (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract protocol_conformsToProtocol (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Z - -
 method public,abstract protocol_copyMethodDescriptionList (Lcom/sun/jna/Pointer;ZZLcom/sun/jna/Pointer;)Lcom/sun/jna/Structure; - -
 method public,abstract protocol_copyPropertyList (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_copyProtocolList (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_getMethodDescription (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;ZZ)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract protocol_getProperty (Lcom/sun/jna/Pointer;Ljava/lang/String;ZZ)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_isEqual (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Z - -
 method public,abstract sel_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract sel_getUid (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract sel_isEqual (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Z - -
 method public,abstract sel_registerName (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
in 1
class ca/weblite/objc/Runtime 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 field public,static,final INSTANCE Lca/weblite/objc/Runtime; -
 method public,abstract acceptNSRange (Ljava/lang/Object;)J - -
 method public,abstract objc_lookUpClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract class_getProperty (Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getSuperclass (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getVersion (Lcom/sun/jna/Pointer;)I - -
 method public,abstract class_getWeakIvarLayout (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract class_isMetaClass (Lcom/sun/jna/Pointer;)Z - -
 method public,abstract class_getInstanceSize (Lcom/sun/jna/Pointer;)I - -
 method public,abstract class_getInstanceVariable (Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getInstanceMethod (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getClassMethod (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getIvarLayout (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract class_getMethodImplementation (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_getMethodImplementation_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_replaceMethod (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_respondsToSelector (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_setIvarLayout (Lcom/sun/jna/Pointer;Ljava/lang/String;)V - -
 method public,abstract class_setSuperclass (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract class_setVersion (Lcom/sun/jna/Pointer;I)V - -
 method public,abstract class_setWeakIvarLayout (Lcom/sun/jna/Pointer;Ljava/lang/String;)V - -
 method public,abstract ivar_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract ivar_getOffset (Lcom/sun/jna/Pointer;)J - -
 method public,abstract ivar_getTypeEncoding (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract method_copyArgumentType (Lcom/sun/jna/Pointer;I)Ljava/lang/String; - -
 method public,abstract method_copyReturnType (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract method_exchangeImplementations (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)V - -
 method public,abstract method_getArgumentType (Lcom/sun/jna/Pointer;ILcom/sun/jna/Pointer;J)V - -
 method public,abstract method_getImplementation (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract method_getName (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract method_getNumberOfArguments (Lcom/sun/jna/Pointer;)I - -
 method public,abstract method_getReturnType (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;J)V - -
 method public,abstract method_getTypeEncoding (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract method_setImplementation (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_allocateClassPair (Lcom/sun/jna/Pointer;Ljava/lang/String;J)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_copyProtocolList (Lcom/sun/jna/Pointer;)[Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getAssociatedObject (Lcom/sun/jna/Pointer;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getClassList (Lcom/sun/jna/Pointer;I)I - -
 method public,abstract objc_getFutureClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getMetaClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getProtocol (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_getRequiredClass (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)J - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,varargs,abstract objc_msgSendSuper (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,abstract objc_msgSendSuper_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)D - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;)D - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;)D - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D - -
 method public,abstract objc_msgSend_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)V - -
 method public,abstract objc_msgSend_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;)V - -
 method public,abstract objc_msgSend_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;)V - -
 method public,abstract objc_msgSend_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V - -
 method public,abstract objc_msgSend_stret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V - -
 method public,abstract objc_registerClassPair (Lcom/sun/jna/Pointer;)V - -
 method public,abstract objc_removeAssociatedObjects (Lcom/sun/jna/Pointer;)V - -
 method public,abstract objc_setAssociatedObject (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)V - -
 method public,abstract objc_setFutureClass (Lcom/sun/jna/Pointer;Ljava/lang/String;)V - -
 method public,abstract object_copy (Lcom/sun/jna/Pointer;J)Lcom/sun/jna/Pointer; - -
 method public,abstract object_dispose (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getClass (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getClassName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract object_getIndexedIvars (Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getInstanceVariable (Lcom/sun/jna/Pointer;Ljava/lang/String;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_getIvar (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_setClass (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_setInstanceVariable (Lcom/sun/jna/Pointer;Ljava/lang/String;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract object_setIvar (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)V - -
 method public,abstract property_getAttributes (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract protocol_conformsToProtocol (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Z - -
 method public,abstract protocol_copyMethodDescriptionList (Lcom/sun/jna/Pointer;ZZLcom/sun/jna/Pointer;)Lcom/sun/jna/Structure; - -
 method public,abstract protocol_copyPropertyList (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_copyProtocolList (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_getMethodDescription (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;ZZ)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract protocol_getProperty (Lcom/sun/jna/Pointer;Ljava/lang/String;ZZ)Lcom/sun/jna/Pointer; - -
 method public,abstract protocol_isEqual (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Z - -
 method public,abstract sel_getName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,abstract sel_getUid (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,abstract sel_isEqual (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)Z - -
 method public,abstract sel_registerName (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
in 1
class ca/weblite/objc/RuntimeMappings 55 public,interface,abstract java/lang/Object - -
 inner ca/weblite/objc/RuntimeMappings$Runtime1111 ca/weblite/objc/RuntimeMappings Runtime1111 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1110 ca/weblite/objc/RuntimeMappings Runtime1110 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime111 ca/weblite/objc/RuntimeMappings Runtime111 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1101 ca/weblite/objc/RuntimeMappings Runtime1101 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1100 ca/weblite/objc/RuntimeMappings Runtime1100 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime110 ca/weblite/objc/RuntimeMappings Runtime110 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime11 ca/weblite/objc/RuntimeMappings Runtime11 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1011 ca/weblite/objc/RuntimeMappings Runtime1011 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1010 ca/weblite/objc/RuntimeMappings Runtime1010 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime101 ca/weblite/objc/RuntimeMappings Runtime101 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1001 ca/weblite/objc/RuntimeMappings Runtime1001 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1000 ca/weblite/objc/RuntimeMappings Runtime1000 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime100 ca/weblite/objc/RuntimeMappings Runtime100 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime10 ca/weblite/objc/RuntimeMappings Runtime10 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime1 ca/weblite/objc/RuntimeMappings Runtime1 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0111 ca/weblite/objc/RuntimeMappings Runtime0111 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0110 ca/weblite/objc/RuntimeMappings Runtime0110 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime011 ca/weblite/objc/RuntimeMappings Runtime011 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0101 ca/weblite/objc/RuntimeMappings Runtime0101 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0100 ca/weblite/objc/RuntimeMappings Runtime0100 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime010 ca/weblite/objc/RuntimeMappings Runtime010 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime01 ca/weblite/objc/RuntimeMappings Runtime01 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0011 ca/weblite/objc/RuntimeMappings Runtime0011 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0010 ca/weblite/objc/RuntimeMappings Runtime0010 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime001 ca/weblite/objc/RuntimeMappings Runtime001 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0001 ca/weblite/objc/RuntimeMappings Runtime0001 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0000 ca/weblite/objc/RuntimeMappings Runtime0000 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime000 ca/weblite/objc/RuntimeMappings Runtime000 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime00 ca/weblite/objc/RuntimeMappings Runtime00 public,static,interface,abstract
 inner ca/weblite/objc/RuntimeMappings$Runtime0 ca/weblite/objc/RuntimeMappings Runtime0 public,static,interface,abstract
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0 ca/weblite/objc/RuntimeMappings Runtime0 public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime00 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime00 ca/weblite/objc/RuntimeMappings Runtime00 public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime00; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime000 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime000 ca/weblite/objc/RuntimeMappings Runtime000 public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime000; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0000 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0000 ca/weblite/objc/RuntimeMappings Runtime0000 public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0000; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0001 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0001 ca/weblite/objc/RuntimeMappings Runtime0001 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0001; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime001 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime001 ca/weblite/objc/RuntimeMappings Runtime001 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime001; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0010 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0010 ca/weblite/objc/RuntimeMappings Runtime0010 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0010; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0011 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0011 ca/weblite/objc/RuntimeMappings Runtime0011 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0011; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime01 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime01 ca/weblite/objc/RuntimeMappings Runtime01 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime01; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime010 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime010 ca/weblite/objc/RuntimeMappings Runtime010 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime010; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0100 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0100 ca/weblite/objc/RuntimeMappings Runtime0100 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0100; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0101 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0101 ca/weblite/objc/RuntimeMappings Runtime0101 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0101; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime011 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime011 ca/weblite/objc/RuntimeMappings Runtime011 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime011; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0110 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0110 ca/weblite/objc/RuntimeMappings Runtime0110 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0110; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime0111 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime0111 ca/weblite/objc/RuntimeMappings Runtime0111 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime0111; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1 ca/weblite/objc/RuntimeMappings Runtime1 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime10 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime10 ca/weblite/objc/RuntimeMappings Runtime10 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime10; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime100 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime100 ca/weblite/objc/RuntimeMappings Runtime100 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime100; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1000 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1000 ca/weblite/objc/RuntimeMappings Runtime1000 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1000; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1001 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1001 ca/weblite/objc/RuntimeMappings Runtime1001 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1001; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime101 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime101 ca/weblite/objc/RuntimeMappings Runtime101 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime101; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1010 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1010 ca/weblite/objc/RuntimeMappings Runtime1010 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1010; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1011 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1011 ca/weblite/objc/RuntimeMappings Runtime1011 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1011; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime11 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime11 ca/weblite/objc/RuntimeMappings Runtime11 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime11; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime110 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime110 ca/weblite/objc/RuntimeMappings Runtime110 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime110; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1100 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1100 ca/weblite/objc/RuntimeMappings Runtime1100 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1100; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1101 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1101 ca/weblite/objc/RuntimeMappings Runtime1101 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1101; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime111 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime111 ca/weblite/objc/RuntimeMappings Runtime111 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime111; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1110 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1110 ca/weblite/objc/RuntimeMappings Runtime1110 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1110; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Ljava/lang/Object;)D - -
in 1
class ca/weblite/objc/RuntimeMappings$Runtime1111 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 inner ca/weblite/objc/RuntimeMappings$Runtime1111 ca/weblite/objc/RuntimeMappings Runtime1111 public,static,interface,abstract
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 field public,static,final INSTANCE Lca/weblite/objc/RuntimeMappings$Runtime1111; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)J - -
 method public,abstract objc_msgSend_fpret (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;Lcom/sun/jna/Structure$ByValue;)D - -
in 0
class ca/weblite/objc/RuntimeUtils 49 public,super java/lang/Object - -
 field public,static rt Lca/weblite/objc/Runtime; -
 field public,static loaded Z -
 method public <init> ()V - -
 method public,static cls (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static cls (Lca/weblite/objc/Peerable;)Lcom/sun/jna/Pointer; - -
 method public,static clsName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,static clsName (Lca/weblite/objc/Peerable;)Ljava/lang/String; - -
 method public,static sel (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static sel (Lca/weblite/objc/Peerable;)Lcom/sun/jna/Pointer; - -
 method public,static selName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,static selName (Lca/weblite/objc/Peerable;)Ljava/lang/String; - -
 method public,static,varargs msg (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)J - -
 method public,static,varargs msg (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,static,varargs msg (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)J - -
 method public,static,varargs msg (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,static,varargs msgPointer (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgPointer (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgPointer (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgPointer (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgInt (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)I - -
 method public,static,varargs msgInt (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)I - -
 method public,static,varargs msgInt (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I - -
 method public,static,varargs msgInt (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)I - -
 method public,static,varargs msgBoolean (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgBoolean (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgBoolean (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgBoolean (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgString (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgString (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgString (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgString (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgDouble (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)D - -
 method public,static,varargs msgDouble (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)D - -
 method public,static,varargs msgDouble (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)D - -
 method public,static,varargs msgDouble (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)D - -
 method public,static,varargs msg (ZZLcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static arraySize (Ljava/lang/String;)I - -
 method public,static addr (Lca/weblite/objc/Peerable;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msg ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,static str (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static str (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,static getAsReference (Ljava/lang/Object;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static getAsReferenceWrapper (Ljava/lang/Object;Ljava/lang/String;)Lcom/sun/jna/ptr/ByReference; - -
 method public,static,native init ()V - -
 method public,static,native createProxy (Lca/weblite/objc/Recipient;)J - -
 method public,static,native getJavaPeer (J)Lca/weblite/objc/Recipient; - -
in 1
class ca/weblite/objc/RuntimeUtils 55 public,super java/lang/Object - -
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static cls (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static cls (Lca/weblite/objc/Peerable;)Lcom/sun/jna/Pointer; - -
 method public,static clsName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,static clsName (Lca/weblite/objc/Peerable;)Ljava/lang/String; - -
 method public,static sel (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static sel (Lca/weblite/objc/Peerable;)Lcom/sun/jna/Pointer; - -
 method public,static selName (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,static selName (Lca/weblite/objc/Peerable;)Ljava/lang/String; - -
 method public,static,varargs msg (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)J - -
 method public,static,varargs msg (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,static,varargs msg (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)J - -
 method public,static,varargs msg (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)J - -
 method public,static,varargs msgPointer (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgPointer (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgPointer (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgPointer (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msgInt (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)I - -
 method public,static,varargs msgInt (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)I - -
 method public,static,varargs msgInt (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)I - -
 method public,static,varargs msgInt (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)I - -
 method public,static,varargs msgBoolean (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgBoolean (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgBoolean (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgBoolean (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Z - -
 method public,static,varargs msgString (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgString (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgString (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgString (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String; - -
 method public,static,varargs msgDouble (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)D - -
 method public,static,varargs msgDouble (Ljava/lang/String;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)D - -
 method public,static,varargs msgDouble (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)D - -
 method public,static,varargs msgDouble (Lcom/sun/jna/Pointer;Ljava/lang/String;[Ljava/lang/Object;)D - -
 method public,static,varargs msg (ZZLcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;[Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static arraySize (Ljava/lang/String;)I - -
 method public,static addr (Lca/weblite/objc/Peerable;)Lcom/sun/jna/Pointer; - -
 method public,static,varargs msg ([Lca/weblite/objc/Message;)Ljava/lang/Object; - -
 method public,static str (Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static str (Lcom/sun/jna/Pointer;)Ljava/lang/String; - -
 method public,static getAsReference (Ljava/lang/Object;Ljava/lang/String;)Lcom/sun/jna/Pointer; - -
 method public,static getAsReferenceWrapper (Ljava/lang/Object;Ljava/lang/String;)Lcom/sun/jna/ptr/ByReference; - -
 method public,static,native createProxy (Lca/weblite/objc/Recipient;)J - -
 method public,static,native getJavaPeer (J)Lca/weblite/objc/Recipient; - -
in 1
class ca/weblite/objc/RuntmeArm64Extensions 55 public,interface,abstract java/lang/Object com/sun/jna/Library -
 field public,static,final INSTANCE Lca/weblite/objc/RuntmeArm64Extensions; -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;)D - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;)D - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;)D - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D - -
 method public,abstract objc_msgSend (Lcom/sun/jna/Pointer;Lcom/sun/jna/Pointer;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D - -
in 0
class ca/weblite/objc/TypeMapper 49 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 method public,static getInstance ()Lca/weblite/objc/TypeMapper; - -
 method public <init> ()V - -
 method public,varargs addMapping (Lca/weblite/objc/TypeMapping;[Ljava/lang/String;)Lca/weblite/objc/TypeMapper; - -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 1
class ca/weblite/objc/TypeMapper 55 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lca/weblite/objc/TypeMapper; -
 method public,static getInstance ()Lca/weblite/objc/TypeMapper; - -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 0
class ca/weblite/objc/TypeMapping 49 public,interface,abstract java/lang/Object - -
 method public,abstract cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public,abstract jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 1
class ca/weblite/objc/TypeMapping 55 public,interface,abstract java/lang/Object - -
 method public,abstract cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public,abstract jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 0
class ca/weblite/objc/annotations/Msg 49 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract selector ()Ljava/lang/String; - -
 method public,abstract signature ()Ljava/lang/String; - - ""
 method public,abstract like ()Ljava/lang/String; - - ""
in 1
class ca/weblite/objc/annotations/Msg 55 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 method public,abstract selector ()Ljava/lang/String; - -
 method public,abstract signature ()Ljava/lang/String; - - ""
 method public,abstract like ()Ljava/lang/String; - - ""
in 1
class ca/weblite/objc/foundation/NSRange 55 public,super com/sun/jna/Structure - -
 inner ca/weblite/objc/foundation/NSRange$ByValue ca/weblite/objc/foundation/NSRange ByValue public,static
 inner ca/weblite/objc/foundation/NSRange$ByReference ca/weblite/objc/foundation/NSRange ByReference public,static
 field public location J -
 field public length J -
 method public <init> ()V - -
 method public setLocation (I)V - -
 method public setLength (I)V - -
 method public getLocation ()I - -
 method public getLength ()I - -
 method protected getFieldOrder ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
in 1
class ca/weblite/objc/foundation/NSRange$ByReference 55 public,super ca/weblite/objc/foundation/NSRange com/sun/jna/Structure$ByReference -
 inner ca/weblite/objc/foundation/NSRange$ByReference ca/weblite/objc/foundation/NSRange ByReference public,static
 inner com/sun/jna/Structure$ByReference com/sun/jna/Structure ByReference public,static,interface,abstract
 method public <init> ()V - -
in 1
class ca/weblite/objc/foundation/NSRange$ByValue 55 public,super ca/weblite/objc/foundation/NSRange com/sun/jna/Structure$ByValue -
 inner ca/weblite/objc/foundation/NSRange$ByValue ca/weblite/objc/foundation/NSRange ByValue public,static
 inner com/sun/jna/Structure$ByValue com/sun/jna/Structure ByValue public,static,interface,abstract
 method public <init> ()V - -
in 1
class ca/weblite/objc/jna/PointerTool 55 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static getPeer (Lcom/sun/jna/Pointer;)J - -
in 0
class ca/weblite/objc/mappers/NSObjectMapping 49 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 method public <init> ()V - -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 1
class ca/weblite/objc/mappers/NSObjectMapping 55 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final INSTANCE Lca/weblite/objc/mappers/NSObjectMapping; -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 0
class ca/weblite/objc/mappers/PointerMapping 49 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 method public <init> ()V - -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 1
class ca/weblite/objc/mappers/PointerMapping 55 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 field public,static,final INSTANCE Lca/weblite/objc/mappers/PointerMapping; -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 0
class ca/weblite/objc/mappers/ScalarMapping 49 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 method public <init> ()V - -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 1
class ca/weblite/objc/mappers/ScalarMapping 55 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 field public,static,final INSTANCE Lca/weblite/objc/mappers/ScalarMapping; -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 0
class ca/weblite/objc/mappers/StringMapping 49 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 method public <init> ()V - -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 1
class ca/weblite/objc/mappers/StringMapping 55 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 field public,static,final INSTANCE Lca/weblite/objc/mappers/StringMapping; -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 0
class ca/weblite/objc/mappers/StructureMapping 49 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 method public <init> ()V - -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 1
class ca/weblite/objc/mappers/StructureMapping 55 public,super java/lang/Object ca/weblite/objc/TypeMapping -
 field public,static,final INSTANCE Lca/weblite/objc/mappers/StructureMapping; -
 method public cToJ (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
 method public jToC (Ljava/lang/Object;Ljava/lang/String;Lca/weblite/objc/TypeMapping;)Ljava/lang/Object; - -
in 0
class ca/weblite/objc/util/CocoaUtils 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static dispatch_async (Ljava/lang/Runnable;)V - -
 method public,static dispatch_sync (Ljava/lang/Runnable;)V - -
in 1
class ca/weblite/objc/util/CocoaUtils 55 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static dispatch_async (Ljava/lang/Runnable;)V - -
 method public,static dispatch_sync (Ljava/lang/Runnable;)V - -
