cg-stub-db 1
in 0
class scala/xml/Atom 50 public,super scala/xml/SpecialNode scala/Serializable <A:Ljava/lang/Object;>Lscala/xml/SpecialNode;Lscala/Serializable;
 method public data ()Ljava/lang/Object; ()TA; -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public,final doCollectNamespaces ()Z - -
 method public,final doTransform ()Z - -
 method public label ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public text ()Ljava/lang/String; - -
 method public <init> (Ljava/lang/Object;)V (TA;)V -
in 0
class scala/xml/Attribute 50 public,interface,abstract java/lang/Object - -
 method public,abstract pre ()Ljava/lang/String; - -
 method public,abstract key ()Ljava/lang/String; - -
 method public,abstract value ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,abstract next ()Lscala/xml/MetaData; - -
 method public,abstract apply (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,abstract apply (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,abstract copy (Lscala/xml/MetaData;)Lscala/xml/Attribute; - -
 method public,abstract remove (Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public,abstract remove (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public,abstract isPrefixed ()Z - -
 method public,abstract getNamespace (Lscala/xml/Node;)Ljava/lang/String; - -
 method public,abstract wellformed (Lscala/xml/NamespaceBinding;)Z - -
 method public,abstract iterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/MetaData;>; -
 method public,abstract size ()I - -
 method public,abstract toString1 (Lscala/collection/mutable/StringBuilder;)V - -
in 0
class scala/xml/Attribute$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/Attribute$; -
 method public,static <clinit> ()V - -
 method public unapply (Lscala/xml/Attribute;)Lscala/Option; (Lscala/xml/Attribute;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;>;>; -
 method public apply (Ljava/lang/String;Lscala/collection/Seq;Lscala/xml/MetaData;)Lscala/xml/Attribute; (Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;)Lscala/xml/Attribute; -
 method public apply (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;)Lscala/xml/Attribute; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;Lscala/collection/Seq;Lscala/xml/MetaData;)Lscala/xml/Attribute; (Ljava/lang/String;Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;)Lscala/xml/Attribute; -
 method public apply (Lscala/Option;Ljava/lang/String;Lscala/collection/Seq;Lscala/xml/MetaData;)Lscala/xml/Attribute; (Lscala/Option<Ljava/lang/String;>;Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;)Lscala/xml/Attribute; -
in 0
class scala/xml/Attribute$class 50 public,super,abstract java/lang/Object - -
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 method public,static remove (Lscala/xml/Attribute;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public,static remove (Lscala/xml/Attribute;Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public,static isPrefixed (Lscala/xml/Attribute;)Z - -
 method public,static wellformed (Lscala/xml/Attribute;Lscala/xml/NamespaceBinding;)Z - -
 method public,static iterator (Lscala/xml/Attribute;)Lscala/collection/Iterator; - -
 method public,static size (Lscala/xml/Attribute;)I - -
 method public,static toString1 (Lscala/xml/Attribute;Lscala/collection/mutable/StringBuilder;)V - -
 method public,static $init$ (Lscala/xml/Attribute;)V - -
in 0
class scala/xml/Comment 50 public,super scala/xml/SpecialNode scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/Comment;)Lscala/Option; (Lscala/xml/Comment;)Lscala/Option<Ljava/lang/String;>; -
 method public commentText ()Ljava/lang/String; - -
 method public label ()Ljava/lang/String; - -
 method public text ()Ljava/lang/String; - -
 method public,final doCollectNamespaces ()Z - -
 method public,final doTransform ()Z - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;)Lscala/xml/Comment; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/Comment$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/Comment;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/Comment$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/Comment; - -
 method public unapply (Lscala/xml/Comment;)Lscala/Option; (Lscala/xml/Comment;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/Document 50 public,super scala/xml/NodeSeq scala/xml/pull/XMLEvent,scala/Serializable -
 field public,static,final serialVersionUID J - J-2289320563321795109
 method public children ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public children_$eq (Lscala/collection/Seq;)V (Lscala/collection/Seq<Lscala/xml/Node;>;)V -
 method public docElem ()Lscala/xml/Node; - -
 method public docElem_$eq (Lscala/xml/Node;)V - -
 method public dtd ()Lscala/xml/dtd/DTD; - -
 method public dtd_$eq (Lscala/xml/dtd/DTD;)V - -
 method public notations ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/NotationDecl;>; -
 method public unparsedEntities ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/EntityDecl;>; -
 method public baseURI ()Ljava/lang/String; - -
 method public baseURI_$eq (Ljava/lang/String;)V - -
 method public encoding ()Lscala/Option; ()Lscala/Option<Ljava/lang/String;>; -
 method public encoding_$eq (Lscala/Option;)V (Lscala/Option<Ljava/lang/String;>;)V -
 method public standAlone ()Lscala/Option; ()Lscala/Option<Ljava/lang/Object;>; -
 method public standAlone_$eq (Lscala/Option;)V (Lscala/Option<Ljava/lang/Object;>;)V -
 method public version ()Lscala/Option; ()Lscala/Option<Ljava/lang/String;>; -
 method public version_$eq (Lscala/Option;)V (Lscala/Option<Ljava/lang/String;>;)V -
 method public allDeclarationsProcessed ()Z - -
 method public allDeclarationsProcessed_$eq (Z)V - -
 method public theSeq ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public <init> ()V - -
in 0
class scala/xml/Elem 50 public,super scala/xml/Node scala/Serializable -
 method public,static processXml (Lscala/sys/process/Process$;)Ljava/lang/Object; - -
 method public,static xmlToProcess (Lscala/xml/Elem;)Lscala/sys/process/ProcessBuilder; - -
 method public,static unapplySeq (Lscala/xml/Node;)Lscala/Option; (Lscala/xml/Node;)Lscala/Option<Lscala/Tuple5<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;>;>; -
 method public prefix ()Ljava/lang/String; - -
 method public label ()Ljava/lang/String; - -
 method public scope ()Lscala/xml/NamespaceBinding; - -
 method public minimizeEmpty ()Z - -
 method public child ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,final doCollectNamespaces ()Z - -
 method public,final doTransform ()Z - -
 method public attributes ()Lscala/xml/MetaData; - -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public,final $percent (Lscala/xml/MetaData;)Lscala/xml/Elem; - -
 method public copy (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/collection/Seq;)Lscala/xml/Elem; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/Elem; -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public copy$default$3 ()Lscala/xml/MetaData; - -
 method public copy$default$4 ()Lscala/xml/NamespaceBinding; - -
 method public copy$default$5 ()Z - -
 method public copy$default$6 ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public text ()Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/collection/Seq;)V (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/collection/Seq<Lscala/xml/Node;>;)V -
 method public,deprecated <init> (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)V (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)V -
in 0
class scala/xml/Elem$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/Elem$; -
 method public,static <clinit> ()V - -
 method public,deprecated apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Elem; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/Elem; -
 method public apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/collection/Seq;)Lscala/xml/Elem; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/Elem; -
 method public unapplySeq (Lscala/xml/Node;)Lscala/Option; (Lscala/xml/Node;)Lscala/Option<Lscala/Tuple5<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;>;>; -
 method public,deprecated xmlToProcess (Lscala/xml/Elem;)Lscala/sys/process/ProcessBuilder; - -
 method public,deprecated processXml (Lscala/sys/process/Process$;)Ljava/lang/Object; - -
in 0
class scala/xml/EntityRef 50 public,super scala/xml/SpecialNode scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/EntityRef;)Lscala/Option; (Lscala/xml/EntityRef;)Lscala/Option<Ljava/lang/String;>; -
 method public entityName ()Ljava/lang/String; - -
 method public,final doCollectNamespaces ()Z - -
 method public,final doTransform ()Z - -
 method public label ()Ljava/lang/String; - -
 method public text ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;)Lscala/xml/EntityRef; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/EntityRef$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/EntityRef;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/EntityRef$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/EntityRef; - -
 method public unapply (Lscala/xml/EntityRef;)Lscala/Option; (Lscala/xml/EntityRef;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/Equality 50 public,interface,abstract java/lang/Object scala/Equals -
 method public,abstract basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public,abstract strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public,abstract strict_$bang$eq (Lscala/xml/Equality;)Z - -
 method public,abstract canEqual (Ljava/lang/Object;)Z - -
 method public,abstract hashCode ()I - -
 method public,abstract equals (Ljava/lang/Object;)Z - -
 method public,abstract xml_$eq$eq (Ljava/lang/Object;)Z - -
 method public,abstract xml_$bang$eq (Ljava/lang/Object;)Z - -
in 0
class scala/xml/Equality$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/Equality$; -
 method public,static <clinit> ()V - -
 method public asRef (Ljava/lang/Object;)Ljava/lang/Object; - -
 method public compareBlithely (Ljava/lang/Object;Ljava/lang/String;)Z - -
 method public compareBlithely (Ljava/lang/Object;Lscala/xml/Node;)Z - -
 method public compareBlithely (Ljava/lang/Object;Ljava/lang/Object;)Z - -
in 0
class scala/xml/Equality$class 50 public,super,abstract java/lang/Object - -
 method public,static strict_$bang$eq (Lscala/xml/Equality;Lscala/xml/Equality;)Z - -
 method public,static canEqual (Lscala/xml/Equality;Ljava/lang/Object;)Z - -
 method public,static hashCode (Lscala/xml/Equality;)I - -
 method public,static equals (Lscala/xml/Equality;Ljava/lang/Object;)Z - -
 method public,static,final xml_$eq$eq (Lscala/xml/Equality;Ljava/lang/Object;)Z - -
 method public,static,final xml_$bang$eq (Lscala/xml/Equality;Ljava/lang/Object;)Z - -
 method public,static $init$ (Lscala/xml/Equality;)V - -
in 0
class scala/xml/Group 50 public,final,super scala/xml/Node scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/Group;)Lscala/Option; (Lscala/xml/Group;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public nodes ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public theSeq ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public label ()Lscala/runtime/Nothing$; - -
 method public attributes ()Lscala/runtime/Nothing$; - -
 method public namespace ()Lscala/runtime/Nothing$; - -
 method public child ()Lscala/runtime/Nothing$; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/runtime/Nothing$; - -
 method public copy (Lscala/collection/Seq;)Lscala/xml/Group; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/Group; -
 method public copy$default$1 ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public <init> (Lscala/collection/Seq;)V (Lscala/collection/Seq<Lscala/xml/Node;>;)V -
in 0
class scala/xml/Group$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/Group;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/Group$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/collection/Seq;)Lscala/xml/Group; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/Group; -
 method public unapply (Lscala/xml/Group;)Lscala/Option; (Lscala/xml/Group;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
in 0
class scala/xml/MalformedAttributeException 50 public,super java/lang/RuntimeException scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/MalformedAttributeException;)Lscala/Option; (Lscala/xml/MalformedAttributeException;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/MalformedAttributeException; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/MalformedAttributeException;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/MalformedAttributeException;>; -
 method public msg ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/MalformedAttributeException; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/MalformedAttributeException$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/MalformedAttributeException;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/MalformedAttributeException$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/MalformedAttributeException; - -
 method public unapply (Lscala/xml/MalformedAttributeException;)Lscala/Option; (Lscala/xml/MalformedAttributeException;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/MetaData 50 public,super,abstract scala/collection/AbstractIterable scala/xml/Equality,scala/Serializable Lscala/collection/AbstractIterable<Lscala/xml/MetaData;>;Lscala/collection/Iterable<Lscala/xml/MetaData;>;Lscala/xml/Equality;Lscala/Serializable;
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public,static update (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public,static getUniversalKey (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Ljava/lang/String; - -
 method public,static normalize (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/MetaData; - -
 method public,static concatenate (Lscala/xml/MetaData;Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public strict_$bang$eq (Lscala/xml/Equality;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public,final xml_$eq$eq (Ljava/lang/Object;)Z - -
 method public,final xml_$bang$eq (Ljava/lang/Object;)Z - -
 method public append (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/MetaData; - -
 method public append$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,abstract apply (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,final apply (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,abstract apply (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,abstract copy (Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public,abstract getNamespace (Lscala/xml/Node;)Ljava/lang/String; - -
 method public hasNext ()Z - -
 method public length ()I - -
 method public length (I)I - -
 method public,abstract isPrefixed ()Z - -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public filter (Lscala/Function1;)Lscala/xml/MetaData; (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/xml/MetaData; -
 method public,abstract key ()Ljava/lang/String; - -
 method public,abstract value ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public prefixedKey ()Ljava/lang/String; - -
 method public asAttrMap ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,abstract next ()Lscala/xml/MetaData; - -
 method public,final get (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public,final get (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public,final get (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public toString1 ()Ljava/lang/String; - -
 method public,abstract toString1 (Lscala/collection/mutable/StringBuilder;)V - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,abstract wellformed (Lscala/xml/NamespaceBinding;)Z - -
 method public,abstract remove (Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public,abstract remove (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public,final remove (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public <init> ()V - -
in 0
class scala/xml/MetaData$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/MetaData$; -
 method public,static <clinit> ()V - -
 method public,final concatenate (Lscala/xml/MetaData;Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public normalize (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/MetaData; - -
 method public getUniversalKey (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Ljava/lang/String; - -
 method public update (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
in 0
class scala/xml/MinimizeMode 50 public,final,super java/lang/Object - -
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 inner scala/Enumeration$ValueSet scala/Enumeration ValueSet public
 method public,static Never ()Lscala/Enumeration$Value; - -
 method public,static Always ()Lscala/Enumeration$Value; - -
 method public,static Default ()Lscala/Enumeration$Value; - -
 method public,static withName (Ljava/lang/String;)Lscala/Enumeration$Value; - -
 method public,static apply (I)Lscala/Enumeration$Value; - -
 method public,static maxId ()I - -
 method public,static values ()Lscala/Enumeration$ValueSet; - -
 method public,static toString ()Ljava/lang/String; - -
in 0
class scala/xml/MinimizeMode$ 50 public,final,super scala/Enumeration - -
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 field public,static,final MODULE$ Lscala/xml/MinimizeMode$; -
 method public,static <clinit> ()V - -
 method public Default ()Lscala/Enumeration$Value; - -
 method public Always ()Lscala/Enumeration$Value; - -
 method public Never ()Lscala/Enumeration$Value; - -
in 0
class scala/xml/NamespaceBinding 50 public,super java/lang/Object scala/xml/Equality,scala/Product,scala/Serializable -
 field public,static,final serialVersionUID J - J-2518644165573446725
 method public,static unapply (Lscala/xml/NamespaceBinding;)Lscala/Option; (Lscala/xml/NamespaceBinding;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;>;>; -
 method public,static apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/xml/NamespaceBinding; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;>;Lscala/xml/NamespaceBinding;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/NamespaceBinding;Lscala/xml/NamespaceBinding;>;>;>; -
 method public strict_$bang$eq (Lscala/xml/Equality;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public,final xml_$eq$eq (Ljava/lang/Object;)Z - -
 method public,final xml_$bang$eq (Ljava/lang/Object;)Z - -
 method public prefix ()Ljava/lang/String; - -
 method public uri ()Ljava/lang/String; - -
 method public parent ()Lscala/xml/NamespaceBinding; - -
 method public getURI (Ljava/lang/String;)Ljava/lang/String; - -
 method public getPrefix (Ljava/lang/String;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public buildString (Lscala/xml/NamespaceBinding;)Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;Lscala/xml/NamespaceBinding;)V - -
 method public copy (Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/xml/NamespaceBinding; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public copy$default$3 ()Lscala/xml/NamespaceBinding; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;)V - -
in 0
class scala/xml/NamespaceBinding$ 50 public,final,super scala/runtime/AbstractFunction3 scala/Serializable Lscala/runtime/AbstractFunction3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;Lscala/xml/NamespaceBinding;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/NamespaceBinding$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/xml/NamespaceBinding; - -
 method public unapply (Lscala/xml/NamespaceBinding;)Lscala/Option; (Lscala/xml/NamespaceBinding;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;>;>; -
in 0
class scala/xml/Node 50 public,super,abstract scala/xml/NodeSeq - -
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 method public,static unapplySeq (Lscala/xml/Node;)Lscala/Some; (Lscala/xml/Node;)Lscala/Some<Lscala/Tuple3<Ljava/lang/String;Lscala/xml/MetaData;Lscala/collection/Seq<Lscala/xml/Node;>;>;>; -
 method public,static EmptyNamespace ()Ljava/lang/String; - -
 method public,static NoAttributes ()Lscala/xml/MetaData; - -
 method public prefix ()Ljava/lang/String; - -
 method public,abstract label ()Ljava/lang/String; - -
 method public isAtom ()Z - -
 method public doCollectNamespaces ()Z - -
 method public doTransform ()Z - -
 method public scope ()Lscala/xml/NamespaceBinding; - -
 method public namespace ()Ljava/lang/String; - -
 method public getNamespace (Ljava/lang/String;)Ljava/lang/String; - -
 method public,final attribute (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public,final attribute (Ljava/lang/String;Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public attributes ()Lscala/xml/MetaData; - -
 method public,abstract child ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public nonEmptyChildren ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public descendant ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/Node;>; -
 method public descendant_or_self ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/Node;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public theSeq ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public buildString (Z)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public nameToString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public xmlType ()Lscala/xml/TypeSymbol; - -
 method public text ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class scala/xml/Node$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/Node$; -
 method public,static <clinit> ()V - -
 method public,final NoAttributes ()Lscala/xml/MetaData; - -
 method public EmptyNamespace ()Ljava/lang/String; - -
 method public unapplySeq (Lscala/xml/Node;)Lscala/Some; (Lscala/xml/Node;)Lscala/Some<Lscala/Tuple3<Ljava/lang/String;Lscala/xml/MetaData;Lscala/collection/Seq<Lscala/xml/Node;>;>;>; -
in 0
class scala/xml/NodeBuffer 50 public,super scala/collection/mutable/ArrayBuffer - Lscala/collection/mutable/ArrayBuffer<Lscala/xml/Node;>;
 method public $amp$plus (Ljava/lang/Object;)Lscala/xml/NodeBuffer; - -
 method public <init> ()V - -
in 0
class scala/xml/NodeSeq 50 public,super,abstract scala/collection/AbstractSeq scala/collection/immutable/Seq,scala/xml/Equality Lscala/collection/AbstractSeq<Lscala/xml/Node;>;Lscala/collection/immutable/Seq<Lscala/xml/Node;>;Lscala/collection/SeqLike<Lscala/xml/Node;Lscala/xml/NodeSeq;>;Lscala/xml/Equality;
 method public,static seqToNodeSeq (Lscala/collection/Seq;)Lscala/xml/NodeSeq; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/NodeSeq; -
 method public,static canBuildFrom ()Lscala/collection/generic/CanBuildFrom; ()Lscala/collection/generic/CanBuildFrom<Lscala/xml/NodeSeq;Lscala/xml/Node;Lscala/xml/NodeSeq;>; -
 method public,static fromSeq (Lscala/collection/Seq;)Lscala/xml/NodeSeq; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/NodeSeq; -
 method public,static Empty ()Lscala/xml/NodeSeq; - -
 method public strict_$bang$eq (Lscala/xml/Equality;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public,final xml_$eq$eq (Ljava/lang/Object;)Z - -
 method public,final xml_$bang$eq (Ljava/lang/Object;)Z - -
 method public companion ()Lscala/collection/generic/GenericCompanion; ()Lscala/collection/generic/GenericCompanion<Lscala/collection/immutable/Seq;>; -
 method public toSeq ()Lscala/collection/immutable/Seq; ()Lscala/collection/immutable/Seq<Lscala/xml/Node;>; -
 method public seq ()Lscala/collection/immutable/Seq; ()Lscala/collection/immutable/Seq<Lscala/xml/Node;>; -
 method public parCombiner ()Lscala/collection/parallel/Combiner; ()Lscala/collection/parallel/Combiner<Lscala/xml/Node;Lscala/collection/parallel/immutable/ParSeq<Lscala/xml/Node;>;>; -
 method public newBuilder ()Lscala/collection/mutable/Builder; ()Lscala/collection/mutable/Builder<Lscala/xml/Node;Lscala/xml/NodeSeq;>; -
 method public,abstract theSeq ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public length ()I - -
 method public iterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/Node;>; -
 method public apply (I)Lscala/xml/Node; - -
 method public apply (Lscala/Function1;)Lscala/xml/NodeSeq; (Lscala/Function1<Lscala/xml/Node;Ljava/lang/Object;>;)Lscala/xml/NodeSeq; -
 method public xml_sameElements (Lscala/collection/Iterable;)Z <A:Ljava/lang/Object;>(Lscala/collection/Iterable<TA;>;)Z -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public $bslash (Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public $bslash$bslash (Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public $bslash$at (Ljava/lang/String;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public text ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class scala/xml/NodeSeq$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/NodeSeq$; -
 method public,static <clinit> ()V - -
 method public,final Empty ()Lscala/xml/NodeSeq; - -
 method public fromSeq (Lscala/collection/Seq;)Lscala/xml/NodeSeq; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/NodeSeq; -
 method public canBuildFrom ()Lscala/collection/generic/CanBuildFrom; ()Lscala/collection/generic/CanBuildFrom<Lscala/xml/NodeSeq;Lscala/xml/Node;Lscala/xml/NodeSeq;>; -
 method public newBuilder ()Lscala/collection/mutable/Builder; ()Lscala/collection/mutable/Builder<Lscala/xml/Node;Lscala/xml/NodeSeq;>; -
 method public seqToNodeSeq (Lscala/collection/Seq;)Lscala/xml/NodeSeq; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/NodeSeq; -
in 0
class scala/xml/Null 50 public,final,super java/lang/Object - -
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static append$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,static remove (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/xml/Null$; - -
 method public,static remove (Ljava/lang/String;)Lscala/xml/Null$; - -
 method public,static wellformed (Lscala/xml/NamespaceBinding;)Z - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static toString ()Ljava/lang/String; - -
 method public,static apply (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,static apply (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/runtime/Null$; - -
 method public,static strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public,static length (I)I - -
 method public,static length ()I - -
 method public,static isPrefixed ()Z - -
 method public,static value ()Lscala/runtime/Null$; - -
 method public,static key ()Lscala/runtime/Null$; - -
 method public,static next ()Lscala/runtime/Null$; - -
 method public,static hasNext ()Z - -
 method public,static getNamespace (Lscala/xml/Node;)Lscala/runtime/Null$; - -
 method public,static copy (Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public,static filter (Lscala/Function1;)Lscala/xml/MetaData; (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/xml/MetaData; -
 method public,static append (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/MetaData; - -
 method public,static size ()I - -
 method public,static iterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/runtime/Nothing$;>; -
 method public,static xml_$bang$eq (Ljava/lang/Object;)Z - -
 method public,static xml_$eq$eq (Ljava/lang/Object;)Z - -
 method public,static equals (Ljava/lang/Object;)Z - -
 method public,static hashCode ()I - -
 method public,static strict_$bang$eq (Lscala/xml/Equality;)Z - -
 method public,static remove (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public,static get (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public,static get (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public,static get (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>; -
 method public,static asAttrMap ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static prefixedKey ()Ljava/lang/String; - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static apply (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,static view (II)Lscala/collection/IterableView; (II)Lscala/collection/IterableView<Lscala/xml/MetaData;Lscala/collection/Iterable<Lscala/xml/MetaData;>;>; -
 method public,static view ()Lscala/collection/IterableView; ()Ljava/lang/Object; -
 method public,static toStream ()Lscala/collection/immutable/Stream; ()Lscala/collection/immutable/Stream<Lscala/xml/MetaData;>; -
 method public,static sameElements (Lscala/collection/GenIterable;)Z <B:Ljava/lang/Object;>(Lscala/collection/GenIterable<Ljava/lang/Object;>;)Z -
 method public,static zipWithIndex (Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <A1:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/collection/generic/CanBuildFrom<Lscala/collection/Iterable<Lscala/xml/MetaData;>;Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static zipAll (Lscala/collection/GenIterable;Ljava/lang/Object;Ljava/lang/Object;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;A1:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/collection/GenIterable<Ljava/lang/Object;>;Ljava/lang/Object;Ljava/lang/Object;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Iterable<Lscala/xml/MetaData;>;Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static zip (Lscala/collection/GenIterable;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <A1:Ljava/lang/Object;B:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/collection/GenIterable<Ljava/lang/Object;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Iterable<Lscala/xml/MetaData;>;Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/Object;>;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static copyToArray (Ljava/lang/Object;II)V <B:Ljava/lang/Object;>(Ljava/lang/Object;II)V -
 method public,static dropRight (I)Ljava/lang/Object; - -
 method public,static takeRight (I)Ljava/lang/Object; - -
 method public,static sliding (II)Lscala/collection/Iterator; (II)Lscala/collection/Iterator<Lscala/collection/Iterable<Lscala/xml/MetaData;>;>; -
 method public,static sliding (I)Lscala/collection/Iterator; (I)Lscala/collection/Iterator<Lscala/collection/Iterable<Lscala/xml/MetaData;>;>; -
 method public,static grouped (I)Lscala/collection/Iterator; (I)Lscala/collection/Iterator<Lscala/collection/Iterable<Lscala/xml/MetaData;>;>; -
 method public,static takeWhile (Lscala/Function1;)Ljava/lang/Object; - -
 method public,static drop (I)Ljava/lang/Object; - -
 method public,static take (I)Ljava/lang/Object; - -
 method public,static slice (II)Ljava/lang/Object; - -
 method public,static head ()Ljava/lang/Object; - -
 method public,static toIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/MetaData;>; -
 method public,static toIterable ()Lscala/collection/Iterable; ()Lscala/collection/Iterable<Lscala/xml/MetaData;>; -
 method public,static reduceRight (Lscala/Function2;)Ljava/lang/Object; <B:Ljava/lang/Object;>(Lscala/Function2<Lscala/xml/MetaData;Ljava/lang/Object;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static foldRight (Ljava/lang/Object;Lscala/Function2;)Ljava/lang/Object; <B:Ljava/lang/Object;>(TB;Lscala/Function2<Lscala/xml/MetaData;TB;TB;>;)TB; -
 method public,static isEmpty ()Z - -
 method public,static find (Lscala/Function1;)Lscala/Option; (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/Option<Lscala/xml/MetaData;>; -
 method public,static exists (Lscala/Function1;)Z (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Z -
 method public,static forall (Lscala/Function1;)Z (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Z -
 method public,static foreach (Lscala/Function1;)V <U:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/MetaData;TU;>;)V -
 method public,static toCollection (Ljava/lang/Object;)Lscala/collection/Iterable; - -
 method public,static thisCollection ()Lscala/collection/Iterable; ()Lscala/collection/Iterable<Lscala/xml/MetaData;>; -
 method public,static seq ()Lscala/collection/Iterable; ()Lscala/collection/Iterable<Lscala/xml/MetaData;>; -
 method public,static companion ()Lscala/collection/generic/GenericCompanion; ()Lscala/collection/generic/GenericCompanion<Lscala/collection/Iterable;>; -
 method public,static addString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static addString (Lscala/collection/mutable/StringBuilder;Ljava/lang/String;)Lscala/collection/mutable/StringBuilder; - -
 method public,static addString (Lscala/collection/mutable/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lscala/collection/mutable/StringBuilder; - -
 method public,static mkString ()Ljava/lang/String; - -
 method public,static mkString (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static mkString (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static toMap (Lscala/Predef$$less$colon$less;)Lscala/collection/immutable/Map; <T:Ljava/lang/Object;U:Ljava/lang/Object;>(Lscala/Predef$$less$colon$less<Lscala/xml/MetaData;Lscala/Tuple2<TT;TU;>;>;)Lscala/collection/immutable/Map<TT;TU;>; -
 method public,static toVector ()Lscala/collection/immutable/Vector; ()Lscala/collection/immutable/Vector<Lscala/xml/MetaData;>; -
 method public,static toSet ()Lscala/collection/immutable/Set; <B:Ljava/lang/Object;>()Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public,static toBuffer ()Lscala/collection/mutable/Buffer; <B:Ljava/lang/Object;>()Lscala/collection/mutable/Buffer<Ljava/lang/Object;>; -
 method public,static toIndexedSeq ()Lscala/collection/immutable/IndexedSeq; ()Lscala/collection/immutable/IndexedSeq<Lscala/xml/MetaData;>; -
 method public,static toSeq ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/MetaData;>; -
 method public,static toList ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/MetaData;>; -
 method public,static toArray (Lscala/reflect/ClassTag;)Ljava/lang/Object; - -
 method public,static copyToArray (Ljava/lang/Object;)V <B:Ljava/lang/Object;>(Ljava/lang/Object;)V -
 method public,static copyToArray (Ljava/lang/Object;I)V <B:Ljava/lang/Object;>(Ljava/lang/Object;I)V -
 method public,static copyToBuffer (Lscala/collection/mutable/Buffer;)V <B:Ljava/lang/Object;>(Lscala/collection/mutable/Buffer<Ljava/lang/Object;>;)V -
 method public,static minBy (Lscala/Function1;Lscala/math/Ordering;)Ljava/lang/Object; - -
 method public,static maxBy (Lscala/Function1;Lscala/math/Ordering;)Ljava/lang/Object; - -
 method public,static max (Lscala/math/Ordering;)Ljava/lang/Object; - -
 method public,static min (Lscala/math/Ordering;)Ljava/lang/Object; - -
 method public,static product (Lscala/math/Numeric;)Ljava/lang/Object; <B:Ljava/lang/Object;>(Lscala/math/Numeric<Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static sum (Lscala/math/Numeric;)Ljava/lang/Object; <B:Ljava/lang/Object;>(Lscala/math/Numeric<Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static aggregate (Lscala/Function0;Lscala/Function2;Lscala/Function2;)Ljava/lang/Object; <B:Ljava/lang/Object;>(Lscala/Function0<TB;>;Lscala/Function2<TB;Lscala/xml/MetaData;TB;>;Lscala/Function2<TB;TB;TB;>;)TB; -
 method public,static fold (Ljava/lang/Object;Lscala/Function2;)Ljava/lang/Object; <A1:Ljava/lang/Object;>(Ljava/lang/Object;Lscala/Function2<Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static reduceOption (Lscala/Function2;)Lscala/Option; <A1:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;>;)Lscala/Option<Ljava/lang/Object;>; -
 method public,static reduce (Lscala/Function2;)Ljava/lang/Object; <A1:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static reduceRightOption (Lscala/Function2;)Lscala/Option; <B:Ljava/lang/Object;>(Lscala/Function2<Lscala/xml/MetaData;Ljava/lang/Object;Ljava/lang/Object;>;)Lscala/Option<Ljava/lang/Object;>; -
 method public,static reduceLeftOption (Lscala/Function2;)Lscala/Option; <B:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/Option<Ljava/lang/Object;>; -
 method public,static reduceLeft (Lscala/Function2;)Ljava/lang/Object; <B:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Lscala/xml/MetaData;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static foldLeft (Ljava/lang/Object;Lscala/Function2;)Ljava/lang/Object; <B:Ljava/lang/Object;>(TB;Lscala/Function2<TB;Lscala/xml/MetaData;TB;>;)TB; -
 method public,static $colon$bslash (Ljava/lang/Object;Lscala/Function2;)Ljava/lang/Object; <B:Ljava/lang/Object;>(TB;Lscala/Function2<Lscala/xml/MetaData;TB;TB;>;)TB; -
 method public,static $div$colon (Ljava/lang/Object;Lscala/Function2;)Ljava/lang/Object; <B:Ljava/lang/Object;>(TB;Lscala/Function2<TB;Lscala/xml/MetaData;TB;>;)TB; -
 method public,static collectFirst (Lscala/PartialFunction;)Lscala/Option; <B:Ljava/lang/Object;>(Lscala/PartialFunction<Lscala/xml/MetaData;TB;>;)Lscala/Option<TB;>; -
 method public,static count (Lscala/Function1;)I (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)I -
 method public,static nonEmpty ()Z - -
 method public,static reversed ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/MetaData;>; -
 method public,static par ()Lscala/collection/Parallel; - -
 method public,static withFilter (Lscala/Function1;)Lscala/collection/generic/FilterMonadic; (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/collection/generic/FilterMonadic<Lscala/xml/MetaData;Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static view (II)Lscala/collection/TraversableView; (II)Lscala/collection/TraversableView<Lscala/xml/MetaData;Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static view ()Lscala/collection/TraversableView; ()Ljava/lang/Object; -
 method public,static stringPrefix ()Ljava/lang/String; - -
 method public,static to (Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <Col:Ljava/lang/Object;>(Lscala/collection/generic/CanBuildFrom<Lscala/runtime/Nothing$;Lscala/xml/MetaData;TCol;>;)TCol; -
 method public,static toTraversable ()Lscala/collection/Traversable; ()Lscala/collection/Traversable<Lscala/xml/MetaData;>; -
 method public,static inits ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static tails ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static splitAt (I)Lscala/Tuple2; (I)Lscala/Tuple2<Lscala/collection/Traversable<Lscala/xml/MetaData;>;Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static span (Lscala/Function1;)Lscala/Tuple2; (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/Tuple2<Lscala/collection/Traversable<Lscala/xml/MetaData;>;Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static dropWhile (Lscala/Function1;)Ljava/lang/Object; - -
 method public,static init ()Ljava/lang/Object; - -
 method public,static lastOption ()Lscala/Option; ()Lscala/Option<Lscala/xml/MetaData;>; -
 method public,static last ()Ljava/lang/Object; - -
 method public,static tail ()Ljava/lang/Object; - -
 method public,static headOption ()Lscala/Option; ()Lscala/Option<Lscala/xml/MetaData;>; -
 method public,static scanRight (Ljava/lang/Object;Lscala/Function2;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(TB;Lscala/Function2<Lscala/xml/MetaData;TB;TB;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;TB;TThat;>;)TThat; -
 method public,static scanLeft (Ljava/lang/Object;Lscala/Function2;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(TB;Lscala/Function2<TB;Lscala/xml/MetaData;TB;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;TB;TThat;>;)TThat; -
 method public,static scan (Ljava/lang/Object;Lscala/Function2;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(Ljava/lang/Object;Lscala/Function2<Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;Ljava/lang/Object;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static groupBy (Lscala/Function1;)Lscala/collection/immutable/Map; <K:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/MetaData;TK;>;)Lscala/collection/immutable/Map<TK;Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static partition (Lscala/Function1;)Lscala/Tuple2; (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/Tuple2<Lscala/collection/Traversable<Lscala/xml/MetaData;>;Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static collect (Lscala/PartialFunction;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/PartialFunction<Lscala/xml/MetaData;TB;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;TB;TThat;>;)TThat; -
 method public,static filterNot (Lscala/Function1;)Ljava/lang/Object; - -
 method public,static filter (Lscala/Function1;)Ljava/lang/Object; - -
 method public,static flatMap (Lscala/Function1;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/MetaData;Lscala/collection/GenTraversableOnce<TB;>;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;TB;TThat;>;)TThat; -
 method public,static map (Lscala/Function1;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/MetaData;TB;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;TB;TThat;>;)TThat; -
 method public,static $plus$plus$colon (Lscala/collection/Traversable;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/collection/Traversable<Ljava/lang/Object;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;Ljava/lang/Object;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static $plus$plus$colon (Lscala/collection/TraversableOnce;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/collection/TraversableOnce<Ljava/lang/Object;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;Ljava/lang/Object;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static $plus$plus (Lscala/collection/GenTraversableOnce;Lscala/collection/generic/CanBuildFrom;)Ljava/lang/Object; <B:Ljava/lang/Object;That:Ljava/lang/Object;>(Lscala/collection/GenTraversableOnce<Ljava/lang/Object;>;Lscala/collection/generic/CanBuildFrom<Lscala/collection/Traversable<Lscala/xml/MetaData;>;Ljava/lang/Object;Ljava/lang/Object;>;)Ljava/lang/Object; -
 method public,static hasDefiniteSize ()Z - -
 method public,static parCombiner ()Lscala/collection/parallel/Combiner; ()Lscala/collection/parallel/Combiner<Lscala/xml/MetaData;Lscala/collection/parallel/ParIterable<Lscala/xml/MetaData;>;>; -
 method public,static toCollection (Ljava/lang/Object;)Lscala/collection/Traversable; - -
 method public,static thisCollection ()Lscala/collection/Traversable; ()Lscala/collection/Traversable<Lscala/xml/MetaData;>; -
 method public,static isTraversableAgain ()Z - -
 method public,static repr ()Ljava/lang/Object; - -
 method public,static transpose (Lscala/Function1;)Lscala/collection/GenTraversable; - -
 method public,static flatten (Lscala/Function1;)Lscala/collection/GenTraversable; - -
 method public,static unzip3 (Lscala/Function1;)Lscala/Tuple3; <A1:Ljava/lang/Object;A2:Ljava/lang/Object;A3:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/MetaData;Lscala/Tuple3<TA1;TA2;TA3;>;>;)Lscala/Tuple3<Lscala/collection/Traversable<TA1;>;Lscala/collection/Traversable<TA2;>;Lscala/collection/Traversable<TA3;>;>; -
 method public,static unzip (Lscala/Function1;)Lscala/Tuple2; <A1:Ljava/lang/Object;A2:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/MetaData;Lscala/Tuple2<TA1;TA2;>;>;)Lscala/Tuple2<Lscala/collection/Traversable<TA1;>;Lscala/collection/Traversable<TA2;>;>; -
 method public,static genericBuilder ()Lscala/collection/mutable/Builder; <B:Ljava/lang/Object;>()Lscala/collection/mutable/Builder<TB;Lscala/collection/Traversable<TB;>;>; -
 method public,static newBuilder ()Lscala/collection/mutable/Builder; ()Lscala/collection/mutable/Builder<Lscala/xml/MetaData;Lscala/collection/Traversable<Lscala/xml/MetaData;>;>; -
 method public,static seq ()Lscala/collection/Traversable; ()Lscala/collection/Traversable<Lscala/xml/MetaData;>; -
in 0
class scala/xml/Null$ 50 public,final,super scala/xml/MetaData scala/Product -
 field public,static,final MODULE$ Lscala/xml/Null$; -
 method public,static <clinit> ()V - -
 method public iterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/runtime/Nothing$;>; -
 method public size ()I - -
 method public append (Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/MetaData; - -
 method public append$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public filter (Lscala/Function1;)Lscala/xml/MetaData; (Lscala/Function1<Lscala/xml/MetaData;Ljava/lang/Object;>;)Lscala/xml/MetaData; -
 method public copy (Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public getNamespace (Lscala/xml/Node;)Lscala/runtime/Null$; - -
 method public hasNext ()Z - -
 method public next ()Lscala/runtime/Null$; - -
 method public key ()Lscala/runtime/Null$; - -
 method public value ()Lscala/runtime/Null$; - -
 method public isPrefixed ()Z - -
 method public length ()I - -
 method public length (I)I - -
 method public strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public apply (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/runtime/Null$; - -
 method public apply (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public toString1 (Lscala/collection/mutable/StringBuilder;)V - -
 method public toString1 ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public wellformed (Lscala/xml/NamespaceBinding;)Z - -
 method public remove (Ljava/lang/String;)Lscala/xml/Null$; - -
 method public remove (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/xml/Null$; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
in 0
class scala/xml/PCData 50 public,super scala/xml/Atom - Lscala/xml/Atom<Ljava/lang/String;>;
 method public,static unapply (Ljava/lang/Object;)Lscala/Option; (Ljava/lang/Object;)Lscala/Option<Ljava/lang/String;>; -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/PCData$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/PCData$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/lang/String;)Lscala/xml/PCData; - -
 method public unapply (Ljava/lang/Object;)Lscala/Option; (Ljava/lang/Object;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/PrefixedAttribute 50 public,super scala/xml/MetaData scala/xml/Attribute -
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public,static unapply (Lscala/xml/PrefixedAttribute;)Lscala/Some; (Lscala/xml/PrefixedAttribute;)Lscala/Some<Lscala/Tuple4<Ljava/lang/String;Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;>;>; -
 method public remove (Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public remove (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public isPrefixed ()Z - -
 method public wellformed (Lscala/xml/NamespaceBinding;)Z - -
 method public iterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/MetaData;>; -
 method public size ()I - -
 method public toString1 (Lscala/collection/mutable/StringBuilder;)V - -
 method public pre ()Ljava/lang/String; - -
 method public key ()Ljava/lang/String; - -
 method public value ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public next1 ()Lscala/xml/MetaData; - -
 method public next ()Lscala/xml/MetaData; - -
 method public copy (Lscala/xml/MetaData;)Lscala/xml/PrefixedAttribute; - -
 method public getNamespace (Lscala/xml/Node;)Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public apply (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lscala/collection/Seq;Lscala/xml/MetaData;)V (Ljava/lang/String;Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lscala/Option;Lscala/xml/MetaData;)V (Ljava/lang/String;Ljava/lang/String;Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>;Lscala/xml/MetaData;)V -
in 0
class scala/xml/PrefixedAttribute$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/PrefixedAttribute$; -
 method public,static <clinit> ()V - -
 method public unapply (Lscala/xml/PrefixedAttribute;)Lscala/Some; (Lscala/xml/PrefixedAttribute;)Lscala/Some<Lscala/Tuple4<Ljava/lang/String;Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;>;>; -
in 0
class scala/xml/PrettyPrinter 50 public,super java/lang/Object - -
 inner scala/xml/PrettyPrinter$Box$ scala/xml/PrettyPrinter Box$ public
 inner scala/xml/PrettyPrinter$Box scala/xml/PrettyPrinter Box public
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 inner scala/xml/PrettyPrinter$Para$ scala/xml/PrettyPrinter Para$ public
 inner scala/xml/PrettyPrinter$Para scala/xml/PrettyPrinter Para public
 inner scala/xml/PrettyPrinter$Item scala/xml/PrettyPrinter Item public
 inner scala/xml/PrettyPrinter$Break$ scala/xml/PrettyPrinter Break$ public
 inner scala/xml/PrettyPrinter$BrokenException scala/xml/PrettyPrinter BrokenException public
 method public Break ()Lscala/xml/PrettyPrinter$Break$; - -
 method public Box ()Lscala/xml/PrettyPrinter$Box$; - -
 method public Para ()Lscala/xml/PrettyPrinter$Para$; - -
 method public items ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/PrettyPrinter$Item;>; -
 method public items_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/xml/PrettyPrinter$Item;>;)V -
 method public cur ()I - -
 method public cur_$eq (I)V - -
 method public reset ()V - -
 method public cut (Ljava/lang/String;I)Lscala/collection/immutable/List; (Ljava/lang/String;I)Lscala/collection/immutable/List<Lscala/xml/PrettyPrinter$Item;>; -
 method public makeBox (ILjava/lang/String;)V - -
 method public makePara (ILjava/lang/String;)V - -
 method public makeBreak ()V - -
 method public leafTag (Lscala/xml/Node;)Ljava/lang/String; - -
 method public startTag (Lscala/xml/Node;Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Lscala/xml/Node;Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Ljava/lang/String;Ljava/lang/Object;>; -
 method public endTag (Lscala/xml/Node;)Ljava/lang/String; - -
 method public childrenAreLeaves (Lscala/xml/Node;)Z - -
 method public fits (Ljava/lang/String;)Z - -
 method public traverse (Lscala/xml/Node;Lscala/xml/NamespaceBinding;I)V - -
 method public traverse (Lscala/collection/Iterator;Lscala/xml/NamespaceBinding;I)V (Lscala/collection/Iterator<Lscala/xml/Node;>;Lscala/xml/NamespaceBinding;I)V -
 method public format (Lscala/xml/Node;Lscala/collection/mutable/StringBuilder;)V - -
 method public format (Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;)V - -
 method public format (Lscala/xml/Node;Lscala/xml/NamespaceBinding;)Ljava/lang/String; - -
 method public format$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public formatNodes (Lscala/collection/Seq;Lscala/xml/NamespaceBinding;)Ljava/lang/String; (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/NamespaceBinding;)Ljava/lang/String; -
 method public formatNodes (Lscala/collection/Seq;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;)V (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;)V -
 method public formatNodes$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,final scala$xml$PrettyPrinter$$mkLeaf$1 (Lscala/collection/mutable/StringBuilder;Lscala/xml/Node;)V - -
 method public,final scala$xml$PrettyPrinter$$mkStart$1 (Lscala/collection/mutable/StringBuilder;Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/runtime/IntRef;)V - -
 method public,final scala$xml$PrettyPrinter$$mkEnd$1 (Lscala/collection/mutable/StringBuilder;Lscala/xml/Node;)V - -
 method public,final scala$xml$PrettyPrinter$$isLeaf$1 (Lscala/xml/Node;)Z - -
 method public <init> (II)V - -
in 0
class scala/xml/PrettyPrinter$Box 50 public,super scala/xml/PrettyPrinter$Item scala/Product,scala/Serializable -
 inner scala/xml/PrettyPrinter$Box scala/xml/PrettyPrinter Box public
 inner scala/xml/PrettyPrinter$Item scala/xml/PrettyPrinter Item public
 method public col ()I - -
 method public s ()Ljava/lang/String; - -
 method public copy (ILjava/lang/String;)Lscala/xml/PrettyPrinter$Box; - -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/PrettyPrinter;ILjava/lang/String;)V - -
in 0
class scala/xml/PrettyPrinter$Box$ 50 public,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/Object;Ljava/lang/String;Lscala/xml/PrettyPrinter$Box;>;Lscala/Serializable;
 inner scala/xml/PrettyPrinter$Box$ scala/xml/PrettyPrinter Box$ public
 inner scala/xml/PrettyPrinter$Box scala/xml/PrettyPrinter Box public
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILjava/lang/String;)Lscala/xml/PrettyPrinter$Box; - -
 method public unapply (Lscala/xml/PrettyPrinter$Box;)Lscala/Option; (Lscala/xml/PrettyPrinter$Box;)Lscala/Option<Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/String;>;>; -
 method public <init> (Lscala/xml/PrettyPrinter;)V - -
in 0
class scala/xml/PrettyPrinter$Break$ 50 public,super scala/xml/PrettyPrinter$Item scala/Product,scala/Serializable -
 inner scala/xml/PrettyPrinter$Item scala/xml/PrettyPrinter Item public
 inner scala/xml/PrettyPrinter$Break$ scala/xml/PrettyPrinter Break$ public
 method public toString ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public <init> (Lscala/xml/PrettyPrinter;)V - -
in 0
class scala/xml/PrettyPrinter$BrokenException 50 public,super java/lang/Exception - -
 inner scala/xml/PrettyPrinter$BrokenException scala/xml/PrettyPrinter BrokenException public
 method public <init> (Lscala/xml/PrettyPrinter;)V - -
in 0
class scala/xml/PrettyPrinter$Item 50 public,super java/lang/Object - -
 inner scala/xml/PrettyPrinter$Item scala/xml/PrettyPrinter Item public
 method public <init> (Lscala/xml/PrettyPrinter;)V - -
in 0
class scala/xml/PrettyPrinter$Para 50 public,super scala/xml/PrettyPrinter$Item scala/Product,scala/Serializable -
 inner scala/xml/PrettyPrinter$Para scala/xml/PrettyPrinter Para public
 inner scala/xml/PrettyPrinter$Item scala/xml/PrettyPrinter Item public
 method public s ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/PrettyPrinter$Para; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/PrettyPrinter;Ljava/lang/String;)V - -
in 0
class scala/xml/PrettyPrinter$Para$ 50 public,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/PrettyPrinter$Para;>;Lscala/Serializable;
 inner scala/xml/PrettyPrinter$Para$ scala/xml/PrettyPrinter Para$ public
 inner scala/xml/PrettyPrinter$Para scala/xml/PrettyPrinter Para public
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/PrettyPrinter$Para; - -
 method public unapply (Lscala/xml/PrettyPrinter$Para;)Lscala/Option; (Lscala/xml/PrettyPrinter$Para;)Lscala/Option<Ljava/lang/String;>; -
 method public <init> (Lscala/xml/PrettyPrinter;)V - -
in 0
class scala/xml/ProcInstr 50 public,super scala/xml/SpecialNode scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/ProcInstr;)Lscala/Option; (Lscala/xml/ProcInstr;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;Lscala/xml/ProcInstr;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Lscala/xml/ProcInstr;>;>; -
 method public target ()Ljava/lang/String; - -
 method public proctext ()Ljava/lang/String; - -
 method public,final doCollectNamespaces ()Z - -
 method public,final doTransform ()Z - -
 method public,final label ()Ljava/lang/String; - -
 method public text ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/ProcInstr; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 0
class scala/xml/ProcInstr$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Ljava/lang/String;Lscala/xml/ProcInstr;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/ProcInstr$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/ProcInstr; - -
 method public unapply (Lscala/xml/ProcInstr;)Lscala/Option; (Lscala/xml/ProcInstr;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
in 0
class scala/xml/Properties 50 public,final,super java/lang/Object - -
 method public,static main ([Ljava/lang/String;)V - -
 method public,static isJavaAtLeast (Ljava/lang/String;)Z - -
 method public,static scalacCmd ()Ljava/lang/String; - -
 method public,static scalaCmd ()Ljava/lang/String; - -
 method public,static versionMsg ()Ljava/lang/String; - -
 method public,static jdkHome ()Ljava/lang/String; - -
 method public,static isMac ()Z - -
 method public,static isWin ()Z - -
 method public,static userName ()Ljava/lang/String; - -
 method public,static userHome ()Ljava/lang/String; - -
 method public,static userDir ()Ljava/lang/String; - -
 method public,static tmpDir ()Ljava/lang/String; - -
 method public,static scalaHome ()Ljava/lang/String; - -
 method public,static osName ()Ljava/lang/String; - -
 method public,static javaSpecName ()Ljava/lang/String; - -
 method public,static javaSpecVendor ()Ljava/lang/String; - -
 method public,static javaSpecVersion ()Ljava/lang/String; - -
 method public,static javaVmVersion ()Ljava/lang/String; - -
 method public,static javaVmVendor ()Ljava/lang/String; - -
 method public,static javaVmName ()Ljava/lang/String; - -
 method public,static javaVmInfo ()Ljava/lang/String; - -
 method public,static javaVersion ()Ljava/lang/String; - -
 method public,static javaVendor ()Ljava/lang/String; - -
 method public,static javaHome ()Ljava/lang/String; - -
 method public,static javaClassPath ()Ljava/lang/String; - -
 method public,static lineSeparator ()Ljava/lang/String; - -
 method public,static encodingString ()Ljava/lang/String; - -
 method public,static sourceReader ()Ljava/lang/String; - -
 method public,static sourceEncoding ()Ljava/lang/String; - -
 method public,static versionNumberString ()Ljava/lang/String; - -
 method public,static scalaPropOrNone (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public,static scalaPropOrEmpty (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static scalaPropOrElse (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static envOrSome (Ljava/lang/String;Lscala/Option;)Lscala/Option; (Ljava/lang/String;Lscala/Option<Ljava/lang/String;>;)Lscala/Option<Ljava/lang/String;>; -
 method public,static envOrNone (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public,static envOrElse (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static clearProp (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static setProp (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static propOrFalse (Ljava/lang/String;)Z - -
 method public,static propOrNone (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public,static propOrNull (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static propOrEmpty (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static propOrElse (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public,static propIsSetTo (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public,static propIsSet (Ljava/lang/String;)Z - -
 method public,static scala$util$PropertiesTrait$_setter_$copyrightString_$eq (Ljava/lang/String;)V - -
 method public,static scala$util$PropertiesTrait$_setter_$versionString_$eq (Ljava/lang/String;)V - -
 method public,static scala$util$PropertiesTrait$_setter_$developmentVersion_$eq (Lscala/Option;)V - -
 method public,static scala$util$PropertiesTrait$_setter_$releaseVersion_$eq (Lscala/Option;)V - -
 method public,static scala$util$PropertiesTrait$_setter_$propFilename_$eq (Ljava/lang/String;)V - -
 method public,static copyrightString ()Ljava/lang/String; - -
 method public,static versionString ()Ljava/lang/String; - -
 method public,static developmentVersion ()Lscala/Option; ()Lscala/Option<Ljava/lang/String;>; -
 method public,static releaseVersion ()Lscala/Option; ()Lscala/Option<Ljava/lang/String;>; -
 method public,static scalaProps ()Ljava/util/Properties; - -
 method public,static propFilename ()Ljava/lang/String; - -
in 0
class scala/xml/Properties$ 50 public,final,super java/lang/Object scala/util/PropertiesTrait -
 field public,static,final MODULE$ Lscala/xml/Properties$; -
 method public,static <clinit> ()V - -
 method public propFilename ()Ljava/lang/String; - -
 method public scalaProps ()Ljava/util/Properties; - -
 method public releaseVersion ()Lscala/Option; ()Lscala/Option<Ljava/lang/String;>; -
 method public developmentVersion ()Lscala/Option; ()Lscala/Option<Ljava/lang/String;>; -
 method public versionString ()Ljava/lang/String; - -
 method public copyrightString ()Ljava/lang/String; - -
 method public scala$util$PropertiesTrait$_setter_$propFilename_$eq (Ljava/lang/String;)V - -
 method public scala$util$PropertiesTrait$_setter_$releaseVersion_$eq (Lscala/Option;)V - -
 method public scala$util$PropertiesTrait$_setter_$developmentVersion_$eq (Lscala/Option;)V - -
 method public scala$util$PropertiesTrait$_setter_$versionString_$eq (Ljava/lang/String;)V - -
 method public scala$util$PropertiesTrait$_setter_$copyrightString_$eq (Ljava/lang/String;)V - -
 method public propIsSet (Ljava/lang/String;)Z - -
 method public propIsSetTo (Ljava/lang/String;Ljava/lang/String;)Z - -
 method public propOrElse (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public propOrEmpty (Ljava/lang/String;)Ljava/lang/String; - -
 method public propOrNull (Ljava/lang/String;)Ljava/lang/String; - -
 method public propOrNone (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public propOrFalse (Ljava/lang/String;)Z - -
 method public setProp (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public clearProp (Ljava/lang/String;)Ljava/lang/String; - -
 method public envOrElse (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public envOrNone (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public envOrSome (Ljava/lang/String;Lscala/Option;)Lscala/Option; (Ljava/lang/String;Lscala/Option<Ljava/lang/String;>;)Lscala/Option<Ljava/lang/String;>; -
 method public scalaPropOrElse (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String; - -
 method public scalaPropOrEmpty (Ljava/lang/String;)Ljava/lang/String; - -
 method public scalaPropOrNone (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public versionNumberString ()Ljava/lang/String; - -
 method public sourceEncoding ()Ljava/lang/String; - -
 method public sourceReader ()Ljava/lang/String; - -
 method public encodingString ()Ljava/lang/String; - -
 method public lineSeparator ()Ljava/lang/String; - -
 method public javaClassPath ()Ljava/lang/String; - -
 method public javaHome ()Ljava/lang/String; - -
 method public javaVendor ()Ljava/lang/String; - -
 method public javaVersion ()Ljava/lang/String; - -
 method public javaVmInfo ()Ljava/lang/String; - -
 method public javaVmName ()Ljava/lang/String; - -
 method public javaVmVendor ()Ljava/lang/String; - -
 method public javaVmVersion ()Ljava/lang/String; - -
 method public javaSpecVersion ()Ljava/lang/String; - -
 method public javaSpecVendor ()Ljava/lang/String; - -
 method public javaSpecName ()Ljava/lang/String; - -
 method public osName ()Ljava/lang/String; - -
 method public scalaHome ()Ljava/lang/String; - -
 method public tmpDir ()Ljava/lang/String; - -
 method public userDir ()Ljava/lang/String; - -
 method public userHome ()Ljava/lang/String; - -
 method public userName ()Ljava/lang/String; - -
 method public isWin ()Z - -
 method public isMac ()Z - -
 method public isAvian ()Z - -
 method public jdkHome ()Ljava/lang/String; - -
 method public versionMsg ()Ljava/lang/String; - -
 method public scalaCmd ()Ljava/lang/String; - -
 method public scalacCmd ()Ljava/lang/String; - -
 method public isJavaAtLeast (Ljava/lang/String;)Z - -
 method public main ([Ljava/lang/String;)V - -
 method public propCategory ()Ljava/lang/String; - -
 method public pickJarBasedOn ()Ljava/lang/Class; ()Ljava/lang/Class<Lscala/xml/pull/XMLEventReader;>; -
in 0
class scala/xml/QNode 50 public,final,super java/lang/Object - -
 method public,static unapplySeq (Lscala/xml/Node;)Lscala/Some; (Lscala/xml/Node;)Lscala/Some<Lscala/Tuple4<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/collection/Seq<Lscala/xml/Node;>;>;>; -
in 0
class scala/xml/QNode$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/QNode$; -
 method public,static <clinit> ()V - -
 method public unapplySeq (Lscala/xml/Node;)Lscala/Some; (Lscala/xml/Node;)Lscala/Some<Lscala/Tuple4<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/collection/Seq<Lscala/xml/Node;>;>;>; -
in 0
class scala/xml/Source 50 public,final,super java/lang/Object - -
 method public,static fromString (Ljava/lang/String;)Lorg/xml/sax/InputSource; - -
 method public,static fromSysId (Ljava/lang/String;)Lorg/xml/sax/InputSource; - -
 method public,static fromReader (Ljava/io/Reader;)Lorg/xml/sax/InputSource; - -
 method public,static fromInputStream (Ljava/io/InputStream;)Lorg/xml/sax/InputSource; - -
 method public,static fromFile (Ljava/lang/String;)Lorg/xml/sax/InputSource; - -
 method public,static fromFile (Ljava/io/FileDescriptor;)Lorg/xml/sax/InputSource; - -
 method public,static fromFile (Ljava/io/File;)Lorg/xml/sax/InputSource; - -
in 0
class scala/xml/Source$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/Source$; -
 method public,static <clinit> ()V - -
 method public fromFile (Ljava/io/File;)Lorg/xml/sax/InputSource; - -
 method public fromFile (Ljava/io/FileDescriptor;)Lorg/xml/sax/InputSource; - -
 method public fromFile (Ljava/lang/String;)Lorg/xml/sax/InputSource; - -
 method public fromInputStream (Ljava/io/InputStream;)Lorg/xml/sax/InputSource; - -
 method public fromReader (Ljava/io/Reader;)Lorg/xml/sax/InputSource; - -
 method public fromSysId (Ljava/lang/String;)Lorg/xml/sax/InputSource; - -
 method public fromString (Ljava/lang/String;)Lorg/xml/sax/InputSource; - -
in 0
class scala/xml/SpecialNode 50 public,super,abstract scala/xml/Node scala/xml/pull/XMLEvent -
 method public,final attributes ()Lscala/xml/Null$; - -
 method public,final namespace ()Lscala/runtime/Null$; - -
 method public,final child ()Lscala/collection/immutable/Nil$; - -
 method public,abstract buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> ()V - -
in 0
class scala/xml/Text 50 public,super scala/xml/Atom - Lscala/xml/Atom<Ljava/lang/String;>;
 method public,static unapply (Ljava/lang/Object;)Lscala/Option; (Ljava/lang/Object;)Lscala/Option<Ljava/lang/String;>; -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/Text$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/Text$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/lang/String;)Lscala/xml/Text; - -
 method public unapply (Ljava/lang/Object;)Lscala/Option; (Ljava/lang/Object;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/TextBuffer 50 public,super java/lang/Object - -
 method public,static fromString (Ljava/lang/String;)Lscala/xml/TextBuffer; - -
 method public sb ()Lscala/collection/mutable/StringBuilder; - -
 method public append (Lscala/collection/Seq;)Lscala/xml/TextBuffer; (Lscala/collection/Seq<Ljava/lang/Object;>;)Lscala/xml/TextBuffer; -
 method public toText ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Text;>; -
 method public <init> ()V - -
in 0
class scala/xml/TextBuffer$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/TextBuffer$; -
 method public,static <clinit> ()V - -
 method public fromString (Ljava/lang/String;)Lscala/xml/TextBuffer; - -
in 0
class scala/xml/TopScope 50 public,final,super java/lang/Object - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;Lscala/xml/NamespaceBinding;)V - -
 method public,static buildString (Lscala/xml/NamespaceBinding;)Ljava/lang/String; - -
 method public,static toString ()Ljava/lang/String; - -
 method public,static getPrefix (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getURI (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static xml_$bang$eq (Ljava/lang/Object;)Z - -
 method public,static xml_$eq$eq (Ljava/lang/Object;)Z - -
 method public,static equals (Ljava/lang/Object;)Z - -
 method public,static hashCode ()I - -
 method public,static strict_$bang$eq (Lscala/xml/Equality;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static copy$default$3 ()Lscala/xml/NamespaceBinding; - -
 method public,static copy$default$2 ()Ljava/lang/String; - -
 method public,static copy$default$1 ()Ljava/lang/String; - -
 method public,static copy (Ljava/lang/String;Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/xml/NamespaceBinding; - -
 method public,static basisForHashCode ()Lscala/collection/Seq; ()Lscala/collection/Seq<Ljava/lang/Object;>; -
 method public,static strict_$eq$eq (Lscala/xml/Equality;)Z - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static parent ()Lscala/xml/NamespaceBinding; - -
 method public,static uri ()Ljava/lang/String; - -
 method public,static prefix ()Ljava/lang/String; - -
in 0
class scala/xml/TopScope$ 50 public,final,super scala/xml/NamespaceBinding - -
 field public,static,final MODULE$ Lscala/xml/TopScope$; -
 method public,static <clinit> ()V - -
 method public getURI (Ljava/lang/String;)Ljava/lang/String; - -
 method public getPrefix (Ljava/lang/String;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/xml/NamespaceBinding;)Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;Lscala/xml/NamespaceBinding;)V - -
in 0
class scala/xml/TypeSymbol 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
in 0
class scala/xml/Unparsed 50 public,super scala/xml/Atom - Lscala/xml/Atom<Ljava/lang/String;>;
 method public,static unapply (Lscala/xml/Unparsed;)Lscala/Some; (Lscala/xml/Unparsed;)Lscala/Some<Ljava/lang/String;>; -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/Unparsed$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/Unparsed$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/lang/String;)Lscala/xml/Unparsed; - -
 method public unapply (Lscala/xml/Unparsed;)Lscala/Some; (Lscala/xml/Unparsed;)Lscala/Some<Ljava/lang/String;>; -
in 0
class scala/xml/UnprefixedAttribute 50 public,super scala/xml/MetaData scala/xml/Attribute -
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public,static unapply (Lscala/xml/UnprefixedAttribute;)Lscala/Some; (Lscala/xml/UnprefixedAttribute;)Lscala/Some<Lscala/Tuple3<Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;>;>; -
 method public remove (Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public remove (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/xml/MetaData; - -
 method public isPrefixed ()Z - -
 method public wellformed (Lscala/xml/NamespaceBinding;)Z - -
 method public iterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/MetaData;>; -
 method public size ()I - -
 method public toString1 (Lscala/collection/mutable/StringBuilder;)V - -
 method public key ()Ljava/lang/String; - -
 method public value ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,final pre ()Lscala/runtime/Null$; - -
 method public next ()Lscala/xml/MetaData; - -
 method public copy (Lscala/xml/MetaData;)Lscala/xml/UnprefixedAttribute; - -
 method public,final getNamespace (Lscala/xml/Node;)Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public apply (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Lscala/xml/NamespaceBinding;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public <init> (Ljava/lang/String;Lscala/collection/Seq;Lscala/xml/MetaData;)V (Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;)V - -
 method public <init> (Ljava/lang/String;Lscala/Option;Lscala/xml/MetaData;)V (Ljava/lang/String;Lscala/Option<Lscala/collection/Seq<Lscala/xml/Node;>;>;Lscala/xml/MetaData;)V -
in 0
class scala/xml/UnprefixedAttribute$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/UnprefixedAttribute$; -
 method public,static <clinit> ()V - -
 method public unapply (Lscala/xml/UnprefixedAttribute;)Lscala/Some; (Lscala/xml/UnprefixedAttribute;)Lscala/Some<Lscala/Tuple3<Ljava/lang/String;Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/MetaData;>;>; -
in 0
class scala/xml/Utility 50 public,final,super java/lang/Object - -
 inner scala/xml/Utility$Escapes$ scala/xml/Utility Escapes$ public,static
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 method public,static checkPubID (Ljava/lang/String;)Z - -
 method public,static checkSysID (Ljava/lang/String;)Z - -
 method public,static isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,static isPubIDChar (C)Z - -
 method public,static isName (Ljava/lang/String;)Z - -
 method public,static isNameStart (C)Z - -
 method public,static isNameChar (C)Z - -
 method public,static isAlphaDigit (C)Z - -
 method public,static isAlpha (C)Z - -
 method public,static isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,static isSpace (C)Z - -
 method public,static toXML$default$7 ()Z - -
 method public,static toXML$default$6 ()Z - -
 method public,static toXML$default$5 ()Z - -
 method public,static toXML$default$4 ()Z - -
 method public,static toXML$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public,static toXML$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,static serialize$default$7 ()Lscala/Enumeration$Value; - -
 method public,static serialize$default$6 ()Z - -
 method public,static serialize$default$5 ()Z - -
 method public,static serialize$default$4 ()Z - -
 method public,static serialize$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public,static serialize$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,static sequenceToXML$default$7 ()Lscala/Enumeration$Value; - -
 method public,static sequenceToXML$default$6 ()Z - -
 method public,static sequenceToXML$default$5 ()Z - -
 method public,static sequenceToXML$default$4 ()Z - -
 method public,static sequenceToXML$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public,static sequenceToXML$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,static parseCharRef (Lscala/Function0;Lscala/Function0;Lscala/Function1;Lscala/Function1;)Ljava/lang/String; (Lscala/Function0<Ljava/lang/Object;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;)Ljava/lang/String; -
 method public,static parseAttributeValue (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,static checkAttributeValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getName (Ljava/lang/String;I)Ljava/lang/String; - -
 method public,static appendEscapedQuoted (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static appendQuoted (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static appendQuoted (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static hashCode (Ljava/lang/String;Ljava/lang/String;IILscala/collection/Seq;)I (Ljava/lang/String;Ljava/lang/String;IILscala/collection/Seq<Lscala/xml/Node;>;)I -
 method public,static prefix (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public,static sequenceToXML (Lscala/collection/Seq;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZLscala/Enumeration$Value;)V (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZLscala/Enumeration$Value;)V -
 method public,static serialize (Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZLscala/Enumeration$Value;)Lscala/collection/mutable/StringBuilder; - -
 method public,static toXML (Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)Lscala/collection/mutable/StringBuilder; - -
 method public,static collectNamespaces (Lscala/xml/Node;Lscala/collection/mutable/Set;)V (Lscala/xml/Node;Lscala/collection/mutable/Set<Ljava/lang/String;>;)V -
 method public,static collectNamespaces (Lscala/collection/Seq;)Lscala/collection/mutable/Set; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/collection/mutable/Set<Ljava/lang/String;>; -
 method public,static unescape (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static escape (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static escape (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static sort (Lscala/xml/Node;)Lscala/xml/Node; - -
 method public,static sort (Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public,static trimProper (Lscala/xml/Node;)Lscala/collection/Seq; (Lscala/xml/Node;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public,static trim (Lscala/xml/Node;)Lscala/xml/Node; - -
 method public,static implicitSbToString (Lscala/collection/mutable/StringBuilder;)Ljava/lang/String; - -
 method public,static SU ()C - -
in 0
class scala/xml/Utility$ 50 public,final,super java/lang/Object scala/xml/parsing/TokenTests -
 inner scala/xml/Utility$Escapes$ scala/xml/Utility Escapes$ public,static
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 field public,static,final MODULE$ Lscala/xml/Utility$; -
 method public,static <clinit> ()V - -
 method public,final isSpace (C)Z - -
 method public,final isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public isAlpha (C)Z - -
 method public isAlphaDigit (C)Z - -
 method public isNameChar (C)Z - -
 method public isNameStart (C)Z - -
 method public isName (Ljava/lang/String;)Z - -
 method public isPubIDChar (C)Z - -
 method public isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public checkSysID (Ljava/lang/String;)Z - -
 method public checkPubID (Ljava/lang/String;)Z - -
 method public,final SU ()C - -
 method public implicitSbToString (Lscala/collection/mutable/StringBuilder;)Ljava/lang/String; - -
 method public sbToString (Lscala/Function1;)Ljava/lang/String; (Lscala/Function1<Lscala/collection/mutable/StringBuilder;Lscala/runtime/BoxedUnit;>;)Ljava/lang/String; -
 method public isAtomAndNotText (Lscala/xml/Node;)Z - -
 method public trim (Lscala/xml/Node;)Lscala/xml/Node; - -
 method public trimProper (Lscala/xml/Node;)Lscala/collection/Seq; (Lscala/xml/Node;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public sort (Lscala/xml/MetaData;)Lscala/xml/MetaData; - -
 method public sort (Lscala/xml/Node;)Lscala/xml/Node; - -
 method public,final escape (Ljava/lang/String;)Ljava/lang/String; - -
 method public,final escape (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,final unescape (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public collectNamespaces (Lscala/collection/Seq;)Lscala/collection/mutable/Set; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/collection/mutable/Set<Ljava/lang/String;>; -
 method public collectNamespaces (Lscala/xml/Node;Lscala/collection/mutable/Set;)V (Lscala/xml/Node;Lscala/collection/mutable/Set<Ljava/lang/String;>;)V -
 method public,deprecated toXML (Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)Lscala/collection/mutable/StringBuilder; - -
 method public toXML$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public toXML$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public toXML$default$4 ()Z - -
 method public toXML$default$5 ()Z - -
 method public toXML$default$6 ()Z - -
 method public toXML$default$7 ()Z - -
 method public serialize (Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZLscala/Enumeration$Value;)Lscala/collection/mutable/StringBuilder; - -
 method public serialize$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public serialize$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public serialize$default$4 ()Z - -
 method public serialize$default$5 ()Z - -
 method public serialize$default$6 ()Z - -
 method public serialize$default$7 ()Lscala/Enumeration$Value; - -
 method public sequenceToXML (Lscala/collection/Seq;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZLscala/Enumeration$Value;)V (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZLscala/Enumeration$Value;)V -
 method public sequenceToXML$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public sequenceToXML$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public sequenceToXML$default$4 ()Z - -
 method public sequenceToXML$default$5 ()Z - -
 method public sequenceToXML$default$6 ()Z - -
 method public sequenceToXML$default$7 ()Lscala/Enumeration$Value; - -
 method public,final prefix (Ljava/lang/String;)Lscala/Option; (Ljava/lang/String;)Lscala/Option<Ljava/lang/String;>; -
 method public hashCode (Ljava/lang/String;Ljava/lang/String;IILscala/collection/Seq;)I (Ljava/lang/String;Ljava/lang/String;IILscala/collection/Seq<Lscala/xml/Node;>;)I -
 method public appendQuoted (Ljava/lang/String;)Ljava/lang/String; - -
 method public appendQuoted (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public appendEscapedQuoted (Ljava/lang/String;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public getName (Ljava/lang/String;I)Ljava/lang/String; - -
 method public checkAttributeValue (Ljava/lang/String;)Ljava/lang/String; - -
 method public parseAttributeValue (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public parseCharRef (Lscala/Function0;Lscala/Function0;Lscala/Function1;Lscala/Function1;)Ljava/lang/String; (Lscala/Function0<Ljava/lang/Object;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;Lscala/Function1<Ljava/lang/String;Lscala/runtime/BoxedUnit;>;)Ljava/lang/String; -
in 0
class scala/xml/Utility$Escapes$ 50 public,super java/lang/Object - -
 inner scala/xml/Utility$Escapes$ scala/xml/Utility Escapes$ public,static
 inner scala/Predef$ArrowAssoc$ scala/Predef ArrowAssoc$ public,static
 field public,static,final MODULE$ Lscala/xml/Utility$Escapes$; -
 method public,static <clinit> ()V - -
 method public pairs ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public escMap ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/Object;Ljava/lang/String;>; -
 method public unescMap ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public <init> ()V - -
in 0
class scala/xml/XML 50 public,final,super java/lang/Object - -
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 method public,static loadString (Ljava/lang/String;)Lscala/xml/Node; - -
 method public,static load (Ljava/net/URL;)Lscala/xml/Node; - -
 method public,static load (Lorg/xml/sax/InputSource;)Lscala/xml/Node; - -
 method public,static load (Ljava/lang/String;)Lscala/xml/Node; - -
 method public,static load (Ljava/io/Reader;)Lscala/xml/Node; - -
 method public,static load (Ljava/io/InputStream;)Lscala/xml/Node; - -
 method public,static loadFile (Ljava/lang/String;)Lscala/xml/Node; - -
 method public,static loadFile (Ljava/io/FileDescriptor;)Lscala/xml/Node; - -
 method public,static loadFile (Ljava/io/File;)Lscala/xml/Node; - -
 method public,static loadXML (Lorg/xml/sax/InputSource;Ljavax/xml/parsers/SAXParser;)Lscala/xml/Node; - -
 method public,static parser ()Ljavax/xml/parsers/SAXParser; - -
 method public,static adapter ()Lscala/xml/parsing/FactoryAdapter; - -
 method public,static write$default$6 ()Lscala/Enumeration$Value; - -
 method public,static save$default$5 ()Lscala/xml/dtd/DocType; - -
 method public,static save$default$4 ()Z - -
 method public,static save$default$3 ()Ljava/lang/String; - -
 method public,static write (Ljava/io/Writer;Lscala/xml/Node;Ljava/lang/String;ZLscala/xml/dtd/DocType;Lscala/Enumeration$Value;)V - -
 method public,static save (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;ZLscala/xml/dtd/DocType;)V - -
 method public,static withSAXParser (Ljavax/xml/parsers/SAXParser;)Lscala/xml/factory/XMLLoader; (Ljavax/xml/parsers/SAXParser;)Lscala/xml/factory/XMLLoader<Lscala/xml/Elem;>; -
 method public,static encoding ()Ljava/lang/String; - -
 method public,static lang ()Ljava/lang/String; - -
 method public,static space ()Ljava/lang/String; - -
 method public,static preserve ()Ljava/lang/String; - -
 method public,static namespace ()Ljava/lang/String; - -
 method public,static xmlns ()Ljava/lang/String; - -
 method public,static xml ()Ljava/lang/String; - -
in 0
class scala/xml/XML$ 50 public,final,super java/lang/Object scala/xml/factory/XMLLoader Ljava/lang/Object;Lscala/xml/factory/XMLLoader<Lscala/xml/Elem;>;
 inner scala/util/control/Exception$Catch scala/util/control/Exception Catch public,static
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 field public,static,final MODULE$ Lscala/xml/XML$; -
 method public,static <clinit> ()V - -
 method public adapter ()Lscala/xml/parsing/FactoryAdapter; - -
 method public parser ()Ljavax/xml/parsers/SAXParser; - -
 method public loadXML (Lorg/xml/sax/InputSource;Ljavax/xml/parsers/SAXParser;)Lscala/xml/Node; - -
 method public loadFile (Ljava/io/File;)Lscala/xml/Node; - -
 method public loadFile (Ljava/io/FileDescriptor;)Lscala/xml/Node; - -
 method public loadFile (Ljava/lang/String;)Lscala/xml/Node; - -
 method public load (Ljava/io/InputStream;)Lscala/xml/Node; - -
 method public load (Ljava/io/Reader;)Lscala/xml/Node; - -
 method public load (Ljava/lang/String;)Lscala/xml/Node; - -
 method public load (Lorg/xml/sax/InputSource;)Lscala/xml/Node; - -
 method public load (Ljava/net/URL;)Lscala/xml/Node; - -
 method public loadString (Ljava/lang/String;)Lscala/xml/Node; - -
 method public xml ()Ljava/lang/String; - -
 method public xmlns ()Ljava/lang/String; - -
 method public namespace ()Ljava/lang/String; - -
 method public preserve ()Ljava/lang/String; - -
 method public space ()Ljava/lang/String; - -
 method public lang ()Ljava/lang/String; - -
 method public encoding ()Ljava/lang/String; - -
 method public withSAXParser (Ljavax/xml/parsers/SAXParser;)Lscala/xml/factory/XMLLoader; (Ljavax/xml/parsers/SAXParser;)Lscala/xml/factory/XMLLoader<Lscala/xml/Elem;>; -
 method public,final save (Ljava/lang/String;Lscala/xml/Node;Ljava/lang/String;ZLscala/xml/dtd/DocType;)V - -
 method public,final save$default$3 ()Ljava/lang/String; - -
 method public,final save$default$4 ()Z - -
 method public,final save$default$5 ()Lscala/xml/dtd/DocType; - -
 method public,final write (Ljava/io/Writer;Lscala/xml/Node;Ljava/lang/String;ZLscala/xml/dtd/DocType;Lscala/Enumeration$Value;)V - -
 method public,final write$default$6 ()Lscala/Enumeration$Value; - -
in 0
class scala/xml/Xhtml 50 public,final,super java/lang/Object - -
 method public,static sequenceToXML$default$7 ()Z - -
 method public,static sequenceToXML$default$6 ()Z - -
 method public,static sequenceToXML$default$5 ()Z - -
 method public,static sequenceToXML$default$4 ()Z - -
 method public,static sequenceToXML$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public,static sequenceToXML$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,static toXhtml$default$7 ()Z - -
 method public,static toXhtml$default$6 ()Z - -
 method public,static toXhtml$default$5 ()Z - -
 method public,static toXhtml$default$4 ()Z - -
 method public,static toXhtml$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public,static toXhtml$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public,static sequenceToXML (Lscala/collection/Seq;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)V (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)V -
 method public,static toXhtml (Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)V - -
 method public,static toXhtml (Lscala/xml/NodeSeq;)Ljava/lang/String; - -
 method public,static toXhtml (Lscala/xml/Node;)Ljava/lang/String; - -
in 0
class scala/xml/Xhtml$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/Xhtml$; -
 method public,static <clinit> ()V - -
 method public toXhtml (Lscala/xml/Node;)Ljava/lang/String; - -
 method public toXhtml (Lscala/xml/NodeSeq;)Ljava/lang/String; - -
 method public toXhtml (Lscala/xml/Node;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)V - -
 method public toXhtml$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public toXhtml$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public toXhtml$default$4 ()Z - -
 method public toXhtml$default$5 ()Z - -
 method public toXhtml$default$6 ()Z - -
 method public toXhtml$default$7 ()Z - -
 method public sequenceToXML (Lscala/collection/Seq;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)V (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/xml/NamespaceBinding;Lscala/collection/mutable/StringBuilder;ZZZZ)V -
 method public sequenceToXML$default$2 ()Lscala/xml/NamespaceBinding; - -
 method public sequenceToXML$default$3 ()Lscala/collection/mutable/StringBuilder; - -
 method public sequenceToXML$default$4 ()Z - -
 method public sequenceToXML$default$5 ()Z - -
 method public sequenceToXML$default$6 ()Z - -
 method public sequenceToXML$default$7 ()Z - -
in 0
class scala/xml/dtd/ANY 50 public,final,super java/lang/Object - -
 method public,static hashCode ()I - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static toString ()Ljava/lang/String; - -
in 0
class scala/xml/dtd/ANY$ 50 public,final,super scala/xml/dtd/ContentModel scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/dtd/ANY$; -
 method public,static <clinit> ()V - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 0
class scala/xml/dtd/AttListDecl 50 public,super scala/xml/dtd/MarkupDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/AttListDecl;)Lscala/Option; (Lscala/xml/dtd/AttListDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;>;>; -
 method public,static apply (Ljava/lang/String;Lscala/collection/immutable/List;)Lscala/xml/dtd/AttListDecl; (Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)Lscala/xml/dtd/AttListDecl; -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;>;Lscala/xml/dtd/AttListDecl;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;Lscala/xml/dtd/AttListDecl;>;>; -
 method public name ()Ljava/lang/String; - -
 method public attrs ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>; -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Lscala/collection/immutable/List;)Lscala/xml/dtd/AttListDecl; (Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)Lscala/xml/dtd/AttListDecl; -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Lscala/collection/immutable/List;)V (Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)V -
in 0
class scala/xml/dtd/AttListDecl$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;Lscala/xml/dtd/AttListDecl;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/AttListDecl$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Lscala/collection/immutable/List;)Lscala/xml/dtd/AttListDecl; (Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)Lscala/xml/dtd/AttListDecl; -
 method public unapply (Lscala/xml/dtd/AttListDecl;)Lscala/Option; (Lscala/xml/dtd/AttListDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;>;>; -
in 0
class scala/xml/dtd/AttrDecl 50 public,super java/lang/Object scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/AttrDecl;)Lscala/Option; (Lscala/xml/dtd/AttrDecl;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;>;>; -
 method public,static apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;)Lscala/xml/dtd/AttrDecl; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;>;Lscala/xml/dtd/AttrDecl;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/dtd/DefaultDecl;Lscala/xml/dtd/AttrDecl;>;>;>; -
 method public name ()Ljava/lang/String; - -
 method public tpe ()Ljava/lang/String; - -
 method public default ()Lscala/xml/dtd/DefaultDecl; - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;)Lscala/xml/dtd/AttrDecl; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public copy$default$3 ()Lscala/xml/dtd/DefaultDecl; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;)V - -
in 0
class scala/xml/dtd/AttrDecl$ 50 public,final,super scala/runtime/AbstractFunction3 scala/Serializable Lscala/runtime/AbstractFunction3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;Lscala/xml/dtd/AttrDecl;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/AttrDecl$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;)Lscala/xml/dtd/AttrDecl; - -
 method public unapply (Lscala/xml/dtd/AttrDecl;)Lscala/Option; (Lscala/xml/dtd/AttrDecl;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/DefaultDecl;>;>; -
in 0
class scala/xml/dtd/ContentModel 50 public,super,abstract java/lang/Object - -
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$Alt$ scala/xml/dtd/impl/Base Alt$ public
 inner scala/xml/dtd/impl/Base$Star$ scala/xml/dtd/impl/Base Star$ public
 inner scala/xml/dtd/impl/Base$Sequ$ scala/xml/dtd/impl/Base Sequ$ public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter$ scala/xml/dtd/impl/WordExp Letter$ public
 inner scala/xml/dtd/impl/WordExp$Wildcard$ scala/xml/dtd/impl/WordExp Wildcard$ public
 inner scala/xml/dtd/ContentModel$ElemName scala/xml/dtd/ContentModel ElemName public,static
 inner scala/xml/dtd/ContentModel$ElemName$ scala/xml/dtd/ContentModel ElemName$ public,static
 inner scala/xml/dtd/ContentModel$Translator$ scala/xml/dtd/ContentModel Translator$ public,static
 method public,static getLabels (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/String;>; -
 method public,static parse (Ljava/lang/String;)Lscala/xml/dtd/ContentModel; - -
 method public,static containsText (Lscala/xml/dtd/ContentModel;)Z - -
 method public,static isMixed (Lscala/xml/dtd/ContentModel;)Z - -
 method public,static Wildcard ()Lscala/xml/dtd/impl/WordExp$Wildcard$; - -
 method public,static Letter ()Lscala/xml/dtd/impl/WordExp$Letter$; - -
 method public,static Eps ()Lscala/xml/dtd/impl/Base$Eps$; - -
 method public,static Star ()Lscala/xml/dtd/impl/Base$Star$; - -
 method public,static Sequ ()Lscala/xml/dtd/impl/Base$Sequ$; - -
 method public,static Alt ()Lscala/xml/dtd/impl/Base$Alt$; - -
 method public toString ()Ljava/lang/String; - -
 method public,abstract buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/ContentModel$ 50 public,final,super scala/xml/dtd/impl/WordExp - -
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$Alt$ scala/xml/dtd/impl/Base Alt$ public
 inner scala/xml/dtd/impl/Base$Sequ scala/xml/dtd/impl/Base Sequ public
 inner scala/xml/dtd/impl/Base$Sequ$ scala/xml/dtd/impl/Base Sequ$ public
 inner scala/xml/dtd/impl/Base$Star scala/xml/dtd/impl/Base Star public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter scala/xml/dtd/impl/WordExp Letter public
 inner scala/xml/dtd/ContentModel$ElemName scala/xml/dtd/ContentModel ElemName public,static
 inner scala/xml/dtd/ContentModel$ElemName$ scala/xml/dtd/ContentModel ElemName$ public,static
 inner scala/xml/dtd/ContentModel$Translator$ scala/xml/dtd/ContentModel Translator$ public,static
 field public,static,final MODULE$ Lscala/xml/dtd/ContentModel$; -
 method public,static <clinit> ()V - -
 method public isMixed (Lscala/xml/dtd/ContentModel;)Z - -
 method public containsText (Lscala/xml/dtd/ContentModel;)Z - -
 method public parse (Ljava/lang/String;)Lscala/xml/dtd/ContentModel; - -
 method public getLabels (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/String;>; -
 method public buildString (Lscala/xml/dtd/impl/Base$RegExp;)Ljava/lang/String; - -
 method public buildString (Lscala/xml/dtd/ContentModel;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public buildString (Lscala/xml/dtd/impl/Base$RegExp;Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,final scala$xml$dtd$ContentModel$$traverse$1 (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; - -
in 0
class scala/xml/dtd/ContentModel$ElemName 50 public,super scala/xml/dtd/impl/WordExp$Label scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 inner scala/xml/dtd/ContentModel$ElemName scala/xml/dtd/ContentModel ElemName public,static
 method public name ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/dtd/ContentModel$ElemName; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/ContentModel$ElemName$ 50 public,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/dtd/ContentModel$ElemName;>;Lscala/Serializable;
 inner scala/xml/dtd/ContentModel$ElemName$ scala/xml/dtd/ContentModel ElemName$ public,static
 inner scala/xml/dtd/ContentModel$ElemName scala/xml/dtd/ContentModel ElemName public,static
 field public,static,final MODULE$ Lscala/xml/dtd/ContentModel$ElemName$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/dtd/ContentModel$ElemName; - -
 method public unapply (Lscala/xml/dtd/ContentModel$ElemName;)Lscala/Option; (Lscala/xml/dtd/ContentModel$ElemName;)Lscala/Option<Ljava/lang/String;>; -
 method public <init> ()V - -
in 0
class scala/xml/dtd/ContentModel$Translator$ 50 public,super scala/xml/dtd/impl/WordBerrySethi - -
 inner scala/xml/dtd/ContentModel$Translator$ scala/xml/dtd/ContentModel Translator$ public,static
 field public,static,final MODULE$ Lscala/xml/dtd/ContentModel$Translator$; -
 method public,static <clinit> ()V - -
 method public lang ()Lscala/xml/dtd/ContentModel$; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/ContentModelParser 50 public,final,super java/lang/Object - -
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter scala/xml/dtd/impl/WordExp Letter public
 method public,static atom ()Lscala/xml/dtd/impl/WordExp$Letter; - -
 method public,static particle ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public,static choiceRest (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$Alt; - -
 method public,static seqRest (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$RegExp; - -
 method public,static regexp ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public,static sOpt ()V - -
 method public,static contentspec ()Lscala/xml/dtd/ContentModel; - -
 method public,static maybeSuffix (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$RegExp; - -
 method public,static accept (I)V - -
 method public,static parse (Ljava/lang/String;)Lscala/xml/dtd/ContentModel; - -
 method public,static checkPubID (Ljava/lang/String;)Z - -
 method public,static checkSysID (Ljava/lang/String;)Z - -
 method public,static isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,static isPubIDChar (C)Z - -
 method public,static isName (Ljava/lang/String;)Z - -
 method public,static isNameStart (C)Z - -
 method public,static isNameChar (C)Z - -
 method public,static isAlphaDigit (C)Z - -
 method public,static isAlpha (C)Z - -
 method public,static isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,static isSpace (C)Z - -
 method public,static name ()I - -
 method public,static readToken ()I - -
 method public,static accS (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
 method public,static acc (C)V - -
 method public,static next ()V - -
 method public,static isIdentChar ()Z - -
 method public,static nextToken ()V - -
 method public,static initScanner (Ljava/lang/String;)V - -
 method public,static value_$eq (Ljava/lang/String;)V - -
 method public,static value ()Ljava/lang/String; - -
 method public,static token_$eq (I)V - -
 method public,static token ()I - -
 method public,static ENDCH ()C - -
 method public,static token2string (I)Ljava/lang/String; - -
 method public,static S ()I - -
 method public,static END ()I - -
 method public,static CHOICE ()I - -
 method public,static OPT ()I - -
 method public,static PLUS ()I - -
 method public,static STAR ()I - -
 method public,static COMMA ()I - -
 method public,static RPAREN ()I - -
 method public,static LPAREN ()I - -
 method public,static NAME ()I - -
 method public,static TOKEN_PCDATA ()I - -
in 0
class scala/xml/dtd/ContentModelParser$ 50 public,final,super scala/xml/dtd/Scanner - -
 inner scala/xml/dtd/impl/Base$Alt$ scala/xml/dtd/impl/Base Alt$ public
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$Sequ$ scala/xml/dtd/impl/Base Sequ$ public
 inner scala/xml/dtd/impl/Base$Star scala/xml/dtd/impl/Base Star public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter scala/xml/dtd/impl/WordExp Letter public
 inner scala/xml/dtd/ContentModel$ElemName scala/xml/dtd/ContentModel ElemName public,static
 field public,static,final MODULE$ Lscala/xml/dtd/ContentModelParser$; -
 method public,static <clinit> ()V - -
 method public parse (Ljava/lang/String;)Lscala/xml/dtd/ContentModel; - -
 method public accept (I)V - -
 method public maybeSuffix (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$RegExp; - -
 method public contentspec ()Lscala/xml/dtd/ContentModel; - -
 method public sOpt ()V - -
 method public regexp ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public seqRest (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$RegExp; - -
 method public choiceRest (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$Alt; - -
 method public particle ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public atom ()Lscala/xml/dtd/impl/WordExp$Letter; - -
in 0
class scala/xml/dtd/DEFAULT 50 public,super scala/xml/dtd/DefaultDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/DEFAULT;)Lscala/Option; (Lscala/xml/dtd/DEFAULT;)Lscala/Option<Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/String;>;>; -
 method public,static apply (ZLjava/lang/String;)Lscala/xml/dtd/DEFAULT; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/String;>;Lscala/xml/dtd/DEFAULT;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Ljava/lang/String;Lscala/xml/dtd/DEFAULT;>;>; -
 method public fixed ()Z - -
 method public attValue ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (ZLjava/lang/String;)Lscala/xml/dtd/DEFAULT; - -
 method public copy$default$1 ()Z - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ZLjava/lang/String;)V - -
in 0
class scala/xml/dtd/DEFAULT$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/Object;Ljava/lang/String;Lscala/xml/dtd/DEFAULT;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/DEFAULT$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ZLjava/lang/String;)Lscala/xml/dtd/DEFAULT; - -
 method public unapply (Lscala/xml/dtd/DEFAULT;)Lscala/Option; (Lscala/xml/dtd/DEFAULT;)Lscala/Option<Lscala/Tuple2<Ljava/lang/Object;Ljava/lang/String;>;>; -
in 0
class scala/xml/dtd/DFAContentModel 50 public,super,abstract scala/xml/dtd/ContentModel - -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/ContentModel$Translator$ scala/xml/dtd/ContentModel Translator$ public,static
 method public,abstract r ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public dfa ()Lscala/xml/dtd/impl/DetWordAutom; ()Lscala/xml/dtd/impl/DetWordAutom<Lscala/xml/dtd/ContentModel$ElemName;>; -
 method public <init> ()V - -
in 0
class scala/xml/dtd/DTD 50 public,super,abstract java/lang/Object - -
 method public externalID ()Lscala/xml/dtd/ExternalID; - -
 method public externalID_$eq (Lscala/xml/dtd/ExternalID;)V - -
 method public decls ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/dtd/Decl;>; -
 method public decls_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/xml/dtd/Decl;>;)V -
 method public notations ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/NotationDecl;>; -
 method public unparsedEntities ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/EntityDecl;>; -
 method public elem ()Lscala/collection/mutable/Map; ()Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/ElemDecl;>; -
 method public elem_$eq (Lscala/collection/mutable/Map;)V (Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/ElemDecl;>;)V -
 method public attr ()Lscala/collection/mutable/Map; ()Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/AttListDecl;>; -
 method public attr_$eq (Lscala/collection/mutable/Map;)V (Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/AttListDecl;>;)V -
 method public ent ()Lscala/collection/mutable/Map; ()Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/EntityDecl;>; -
 method public ent_$eq (Lscala/collection/mutable/Map;)V (Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/EntityDecl;>;)V -
 method public toString ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/Decl 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/DefaultDecl 50 public,super,abstract java/lang/Object - -
 method public,abstract toString ()Ljava/lang/String; - -
 method public,abstract buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/DocType 50 public,super java/lang/Object scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/DocType;)Lscala/Option; (Lscala/xml/dtd/DocType;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq<Lscala/xml/dtd/Decl;>;>;>; -
 method public,static apply (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq;)Lscala/xml/dtd/DocType; (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq<Lscala/xml/dtd/Decl;>;)Lscala/xml/dtd/DocType; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/dtd/DocType; - -
 method public name ()Ljava/lang/String; - -
 method public extID ()Lscala/xml/dtd/ExternalID; - -
 method public intSubset ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/Decl;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq;)Lscala/xml/dtd/DocType; (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq<Lscala/xml/dtd/Decl;>;)Lscala/xml/dtd/DocType; -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Lscala/xml/dtd/ExternalID; - -
 method public copy$default$3 ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/Decl;>; -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq;)V (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq<Lscala/xml/dtd/Decl;>;)V -
in 0
class scala/xml/dtd/DocType$ 50 public,final,super java/lang/Object scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/dtd/DocType$; -
 method public,static <clinit> ()V - -
 method public apply (Ljava/lang/String;)Lscala/xml/dtd/DocType; - -
 method public apply (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq;)Lscala/xml/dtd/DocType; (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq<Lscala/xml/dtd/Decl;>;)Lscala/xml/dtd/DocType; -
 method public unapply (Lscala/xml/dtd/DocType;)Lscala/Option; (Lscala/xml/dtd/DocType;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/collection/Seq<Lscala/xml/dtd/Decl;>;>;>; -
in 0
class scala/xml/dtd/ELEMENTS 50 public,super scala/xml/dtd/DFAContentModel scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public,static unapply (Lscala/xml/dtd/ELEMENTS;)Lscala/Option; (Lscala/xml/dtd/ELEMENTS;)Lscala/Option<Lscala/xml/dtd/impl/Base$RegExp;>; -
 method public,static apply (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/ELEMENTS; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/dtd/ELEMENTS;TA;>;)Lscala/Function1<Lscala/xml/dtd/impl/Base$RegExp;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/xml/dtd/impl/Base$RegExp;>;)Lscala/Function1<TA;Lscala/xml/dtd/ELEMENTS;>; -
 method public r ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/ELEMENTS; - -
 method public copy$default$1 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/impl/Base$RegExp;)V - -
in 0
class scala/xml/dtd/ELEMENTS$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/ELEMENTS;>;Lscala/Serializable;
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 field public,static,final MODULE$ Lscala/xml/dtd/ELEMENTS$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/ELEMENTS; - -
 method public unapply (Lscala/xml/dtd/ELEMENTS;)Lscala/Option; (Lscala/xml/dtd/ELEMENTS;)Lscala/Option<Lscala/xml/dtd/impl/Base$RegExp;>; -
in 0
class scala/xml/dtd/EMPTY 50 public,final,super java/lang/Object - -
 method public,static hashCode ()I - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static toString ()Ljava/lang/String; - -
in 0
class scala/xml/dtd/EMPTY$ 50 public,final,super scala/xml/dtd/ContentModel scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/dtd/EMPTY$; -
 method public,static <clinit> ()V - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 0
class scala/xml/dtd/ElemDecl 50 public,super scala/xml/dtd/MarkupDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/ElemDecl;)Lscala/Option; (Lscala/xml/dtd/ElemDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ContentModel;>;>; -
 method public,static apply (Ljava/lang/String;Lscala/xml/dtd/ContentModel;)Lscala/xml/dtd/ElemDecl; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ContentModel;>;Lscala/xml/dtd/ElemDecl;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/dtd/ContentModel;Lscala/xml/dtd/ElemDecl;>;>; -
 method public name ()Ljava/lang/String; - -
 method public contentModel ()Lscala/xml/dtd/ContentModel; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Lscala/xml/dtd/ContentModel;)Lscala/xml/dtd/ElemDecl; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Lscala/xml/dtd/ContentModel; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Lscala/xml/dtd/ContentModel;)V - -
in 0
class scala/xml/dtd/ElemDecl$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Lscala/xml/dtd/ContentModel;Lscala/xml/dtd/ElemDecl;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/ElemDecl$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Lscala/xml/dtd/ContentModel;)Lscala/xml/dtd/ElemDecl; - -
 method public unapply (Lscala/xml/dtd/ElemDecl;)Lscala/Option; (Lscala/xml/dtd/ElemDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ContentModel;>;>; -
in 0
class scala/xml/dtd/ElementValidator 50 public,super java/lang/Object scala/Function1 Ljava/lang/Object;Lscala/Function1<Lscala/xml/Node;Ljava/lang/Object;>;
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$Alt$ scala/xml/dtd/impl/Base Alt$ public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/ContentModel$Translator$ scala/xml/dtd/ContentModel Translator$ public,static
 method public apply$mcZD$sp (D)Z - -
 method public apply$mcDD$sp (D)D - -
 method public apply$mcFD$sp (D)F - -
 method public apply$mcID$sp (D)I - -
 method public apply$mcJD$sp (D)J - -
 method public apply$mcVD$sp (D)V - -
 method public apply$mcZF$sp (F)Z - -
 method public apply$mcDF$sp (F)D - -
 method public apply$mcFF$sp (F)F - -
 method public apply$mcIF$sp (F)I - -
 method public apply$mcJF$sp (F)J - -
 method public apply$mcVF$sp (F)V - -
 method public apply$mcZI$sp (I)Z - -
 method public apply$mcDI$sp (I)D - -
 method public apply$mcFI$sp (I)F - -
 method public apply$mcII$sp (I)I - -
 method public apply$mcJI$sp (I)J - -
 method public apply$mcVI$sp (I)V - -
 method public apply$mcZJ$sp (J)Z - -
 method public apply$mcDJ$sp (J)D - -
 method public apply$mcFJ$sp (J)F - -
 method public apply$mcIJ$sp (J)I - -
 method public apply$mcJJ$sp (J)J - -
 method public apply$mcVJ$sp (J)V - -
 method public compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/xml/Node;>;)Lscala/Function1<TA;Ljava/lang/Object;>; -
 method public andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Ljava/lang/Object;TA;>;)Lscala/Function1<Lscala/xml/Node;TA;>; -
 method public toString ()Ljava/lang/String; - -
 method public scala$xml$dtd$ElementValidator$$exc ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/dtd/ValidationException;>; -
 method public scala$xml$dtd$ElementValidator$$exc_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/xml/dtd/ValidationException;>;)V -
 method public contentModel ()Lscala/xml/dtd/ContentModel; - -
 method public contentModel_$eq (Lscala/xml/dtd/ContentModel;)V - -
 method public dfa ()Lscala/xml/dtd/impl/DetWordAutom; ()Lscala/xml/dtd/impl/DetWordAutom<Lscala/xml/dtd/ContentModel$ElemName;>; -
 method public dfa_$eq (Lscala/xml/dtd/impl/DetWordAutom;)V (Lscala/xml/dtd/impl/DetWordAutom<Lscala/xml/dtd/ContentModel$ElemName;>;)V -
 method public adecls ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>; -
 method public adecls_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)V -
 method public setContentModel (Lscala/xml/dtd/ContentModel;)V - -
 method public getContentModel ()Lscala/xml/dtd/ContentModel; - -
 method public setMetaData (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)V -
 method public getIterable (Lscala/collection/Seq;Z)Lscala/collection/Iterable; (Lscala/collection/Seq<Lscala/xml/Node;>;Z)Lscala/collection/Iterable<Lscala/xml/dtd/ContentModel$ElemName;>; -
 method public check (Lscala/xml/MetaData;)Z - -
 method public check (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Lscala/xml/Node;>;)Z -
 method public apply (Lscala/xml/Node;)Z - -
 method public,final scala$xml$dtd$ElementValidator$$isAllWhitespace$1 (Lscala/xml/Atom;)Z - -
 method public,final scala$xml$dtd$ElementValidator$$find$2 (Ljava/lang/String;Lscala/collection/Seq;)Z - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/EntityDecl 50 public,super,abstract scala/xml/dtd/MarkupDecl - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/EntityDef 50 public,super,abstract java/lang/Object - -
 method public,abstract buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/ExtDef 50 public,super scala/xml/dtd/EntityDef scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/ExtDef;)Lscala/Option; (Lscala/xml/dtd/ExtDef;)Lscala/Option<Lscala/xml/dtd/ExternalID;>; -
 method public,static apply (Lscala/xml/dtd/ExternalID;)Lscala/xml/dtd/ExtDef; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/dtd/ExtDef;TA;>;)Lscala/Function1<Lscala/xml/dtd/ExternalID;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/xml/dtd/ExternalID;>;)Lscala/Function1<TA;Lscala/xml/dtd/ExtDef;>; -
 method public extID ()Lscala/xml/dtd/ExternalID; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Lscala/xml/dtd/ExternalID;)Lscala/xml/dtd/ExtDef; - -
 method public copy$default$1 ()Lscala/xml/dtd/ExternalID; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/ExternalID;)V - -
in 0
class scala/xml/dtd/ExtDef$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/xml/dtd/ExternalID;Lscala/xml/dtd/ExtDef;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/ExtDef$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/xml/dtd/ExternalID;)Lscala/xml/dtd/ExtDef; - -
 method public unapply (Lscala/xml/dtd/ExtDef;)Lscala/Option; (Lscala/xml/dtd/ExtDef;)Lscala/Option<Lscala/xml/dtd/ExternalID;>; -
in 0
class scala/xml/dtd/ExternalID 50 public,super,abstract java/lang/Object scala/xml/parsing/TokenTests -
 method public,final isSpace (C)Z - -
 method public,final isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public isAlpha (C)Z - -
 method public isAlphaDigit (C)Z - -
 method public isNameChar (C)Z - -
 method public isNameStart (C)Z - -
 method public isName (Ljava/lang/String;)Z - -
 method public isPubIDChar (C)Z - -
 method public isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public checkSysID (Ljava/lang/String;)Z - -
 method public checkPubID (Ljava/lang/String;)Z - -
 method public quoted (Ljava/lang/String;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,abstract systemId ()Ljava/lang/String; - -
 method public,abstract publicId ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/IMPLIED 50 public,final,super java/lang/Object - -
 method public,static hashCode ()I - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static toString ()Ljava/lang/String; - -
in 0
class scala/xml/dtd/IMPLIED$ 50 public,final,super scala/xml/dtd/DefaultDecl scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/dtd/IMPLIED$; -
 method public,static <clinit> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 0
class scala/xml/dtd/IntDef 50 public,super scala/xml/dtd/EntityDef scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/IntDef;)Lscala/Option; (Lscala/xml/dtd/IntDef;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/dtd/IntDef; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/dtd/IntDef;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/dtd/IntDef;>; -
 method public value ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;)Lscala/xml/dtd/IntDef; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/IntDef$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/dtd/IntDef;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/IntDef$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/dtd/IntDef; - -
 method public unapply (Lscala/xml/dtd/IntDef;)Lscala/Option; (Lscala/xml/dtd/IntDef;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/dtd/MIXED 50 public,super scala/xml/dtd/DFAContentModel scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$Alt$ scala/xml/dtd/impl/Base Alt$ public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public,static unapply (Lscala/xml/dtd/MIXED;)Lscala/Option; (Lscala/xml/dtd/MIXED;)Lscala/Option<Lscala/xml/dtd/impl/Base$RegExp;>; -
 method public,static apply (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/MIXED; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/dtd/MIXED;TA;>;)Lscala/Function1<Lscala/xml/dtd/impl/Base$RegExp;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/xml/dtd/impl/Base$RegExp;>;)Lscala/Function1<TA;Lscala/xml/dtd/MIXED;>; -
 method public r ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/MIXED; - -
 method public copy$default$1 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/impl/Base$RegExp;)V - -
in 0
class scala/xml/dtd/MIXED$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/MIXED;>;Lscala/Serializable;
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 field public,static,final MODULE$ Lscala/xml/dtd/MIXED$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/MIXED; - -
 method public unapply (Lscala/xml/dtd/MIXED;)Lscala/Option; (Lscala/xml/dtd/MIXED;)Lscala/Option<Lscala/xml/dtd/impl/Base$RegExp;>; -
in 0
class scala/xml/dtd/MakeValidationException 50 public,final,super java/lang/Object - -
 method public,static fromMissingAttribute (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public,static fromMissingAttribute (Lscala/collection/immutable/Set;)Lscala/xml/dtd/ValidationException; (Lscala/collection/immutable/Set<Ljava/lang/String;>;)Lscala/xml/dtd/ValidationException; -
 method public,static fromUndefinedAttribute (Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public,static fromUndefinedElement (Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public,static fromNonEmptyElement ()Lscala/xml/dtd/ValidationException; - -
 method public,static fromFixedAttribute (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
in 0
class scala/xml/dtd/MakeValidationException$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/dtd/MakeValidationException$; -
 method public,static <clinit> ()V - -
 method public fromFixedAttribute (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public fromNonEmptyElement ()Lscala/xml/dtd/ValidationException; - -
 method public fromUndefinedElement (Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public fromUndefinedAttribute (Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public fromMissingAttribute (Lscala/collection/immutable/Set;)Lscala/xml/dtd/ValidationException; (Lscala/collection/immutable/Set<Ljava/lang/String;>;)Lscala/xml/dtd/ValidationException; -
 method public fromMissingAttribute (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
in 0
class scala/xml/dtd/MarkupDecl 50 public,super,abstract scala/xml/dtd/Decl - -
 method public,abstract buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/NoExternalID 50 public,final,super java/lang/Object - -
 method public,static toString ()Ljava/lang/String; - -
 method public,static systemId ()Lscala/runtime/Null$; - -
 method public,static publicId ()Lscala/runtime/Null$; - -
 method public,static checkPubID (Ljava/lang/String;)Z - -
 method public,static checkSysID (Ljava/lang/String;)Z - -
 method public,static isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,static isPubIDChar (C)Z - -
 method public,static isName (Ljava/lang/String;)Z - -
 method public,static isNameStart (C)Z - -
 method public,static isNameChar (C)Z - -
 method public,static isAlphaDigit (C)Z - -
 method public,static isAlpha (C)Z - -
 method public,static isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,static isSpace (C)Z - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static quoted (Ljava/lang/String;)Ljava/lang/String; - -
in 0
class scala/xml/dtd/NoExternalID$ 50 public,final,super scala/xml/dtd/ExternalID - -
 field public,static,final MODULE$ Lscala/xml/dtd/NoExternalID$; -
 method public,static <clinit> ()V - -
 method public publicId ()Lscala/runtime/Null$; - -
 method public systemId ()Lscala/runtime/Null$; - -
 method public toString ()Ljava/lang/String; - -
in 0
class scala/xml/dtd/NotationDecl 50 public,super scala/xml/dtd/MarkupDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/NotationDecl;)Lscala/Option; (Lscala/xml/dtd/NotationDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ExternalID;>;>; -
 method public,static apply (Ljava/lang/String;Lscala/xml/dtd/ExternalID;)Lscala/xml/dtd/NotationDecl; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ExternalID;>;Lscala/xml/dtd/NotationDecl;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/dtd/ExternalID;Lscala/xml/dtd/NotationDecl;>;>; -
 method public name ()Ljava/lang/String; - -
 method public extID ()Lscala/xml/dtd/ExternalID; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Lscala/xml/dtd/ExternalID;)Lscala/xml/dtd/NotationDecl; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Lscala/xml/dtd/ExternalID; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Lscala/xml/dtd/ExternalID;)V - -
in 0
class scala/xml/dtd/NotationDecl$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Lscala/xml/dtd/ExternalID;Lscala/xml/dtd/NotationDecl;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/NotationDecl$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Lscala/xml/dtd/ExternalID;)Lscala/xml/dtd/NotationDecl; - -
 method public unapply (Lscala/xml/dtd/NotationDecl;)Lscala/Option; (Lscala/xml/dtd/NotationDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ExternalID;>;>; -
in 0
class scala/xml/dtd/PCDATA 50 public,final,super java/lang/Object - -
 method public,static hashCode ()I - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static toString ()Ljava/lang/String; - -
in 0
class scala/xml/dtd/PCDATA$ 50 public,final,super scala/xml/dtd/ContentModel scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/dtd/PCDATA$; -
 method public,static <clinit> ()V - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 0
class scala/xml/dtd/PEReference 50 public,super scala/xml/dtd/MarkupDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/PEReference;)Lscala/Option; (Lscala/xml/dtd/PEReference;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/dtd/PEReference; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/dtd/PEReference;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/dtd/PEReference;>; -
 method public ent ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;)Lscala/xml/dtd/PEReference; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/PEReference$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/dtd/PEReference;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/PEReference$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/dtd/PEReference; - -
 method public unapply (Lscala/xml/dtd/PEReference;)Lscala/Option; (Lscala/xml/dtd/PEReference;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/dtd/ParameterEntityDecl 50 public,super scala/xml/dtd/EntityDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/ParameterEntityDecl;)Lscala/Option; (Lscala/xml/dtd/ParameterEntityDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;>;>; -
 method public,static apply (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)Lscala/xml/dtd/ParameterEntityDecl; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;>;Lscala/xml/dtd/ParameterEntityDecl;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/dtd/EntityDef;Lscala/xml/dtd/ParameterEntityDecl;>;>; -
 method public name ()Ljava/lang/String; - -
 method public entdef ()Lscala/xml/dtd/EntityDef; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)Lscala/xml/dtd/ParameterEntityDecl; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Lscala/xml/dtd/EntityDef; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)V - -
in 0
class scala/xml/dtd/ParameterEntityDecl$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;Lscala/xml/dtd/ParameterEntityDecl;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/ParameterEntityDecl$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)Lscala/xml/dtd/ParameterEntityDecl; - -
 method public unapply (Lscala/xml/dtd/ParameterEntityDecl;)Lscala/Option; (Lscala/xml/dtd/ParameterEntityDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;>;>; -
in 0
class scala/xml/dtd/ParsedEntityDecl 50 public,super scala/xml/dtd/EntityDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/ParsedEntityDecl;)Lscala/Option; (Lscala/xml/dtd/ParsedEntityDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;>;>; -
 method public,static apply (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)Lscala/xml/dtd/ParsedEntityDecl; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;>;Lscala/xml/dtd/ParsedEntityDecl;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/dtd/EntityDef;Lscala/xml/dtd/ParsedEntityDecl;>;>; -
 method public name ()Ljava/lang/String; - -
 method public entdef ()Lscala/xml/dtd/EntityDef; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)Lscala/xml/dtd/ParsedEntityDecl; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Lscala/xml/dtd/EntityDef; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)V - -
in 0
class scala/xml/dtd/ParsedEntityDecl$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;Lscala/xml/dtd/ParsedEntityDecl;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/ParsedEntityDecl$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)Lscala/xml/dtd/ParsedEntityDecl; - -
 method public unapply (Lscala/xml/dtd/ParsedEntityDecl;)Lscala/Option; (Lscala/xml/dtd/ParsedEntityDecl;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/EntityDef;>;>; -
in 0
class scala/xml/dtd/PublicID 50 public,super scala/xml/dtd/ExternalID scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/PublicID;)Lscala/Option; (Lscala/xml/dtd/PublicID;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static apply (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/dtd/PublicID; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;Lscala/xml/dtd/PublicID;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Lscala/xml/dtd/PublicID;>;>; -
 method public publicId ()Ljava/lang/String; - -
 method public systemId ()Ljava/lang/String; - -
 method public label ()Ljava/lang/String; - -
 method public attribute ()Lscala/xml/MetaData; - -
 method public child ()Lscala/collection/immutable/Nil$; - -
 method public copy (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/dtd/PublicID; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/PublicID$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Ljava/lang/String;Lscala/xml/dtd/PublicID;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/PublicID$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/dtd/PublicID; - -
 method public unapply (Lscala/xml/dtd/PublicID;)Lscala/Option; (Lscala/xml/dtd/PublicID;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
in 0
class scala/xml/dtd/REQUIRED 50 public,final,super java/lang/Object - -
 method public,static hashCode ()I - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public,static toString ()Ljava/lang/String; - -
in 0
class scala/xml/dtd/REQUIRED$ 50 public,final,super scala/xml/dtd/DefaultDecl scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lscala/xml/dtd/REQUIRED$; -
 method public,static <clinit> ()V - -
 method public toString ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 0
class scala/xml/dtd/Scanner 50 public,super scala/xml/dtd/Tokens scala/xml/parsing/TokenTests -
 method public,final isSpace (C)Z - -
 method public,final isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public isAlpha (C)Z - -
 method public isAlphaDigit (C)Z - -
 method public isNameChar (C)Z - -
 method public isNameStart (C)Z - -
 method public isName (Ljava/lang/String;)Z - -
 method public isPubIDChar (C)Z - -
 method public isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public checkSysID (Ljava/lang/String;)Z - -
 method public checkPubID (Ljava/lang/String;)Z - -
 method public,final ENDCH ()C - -
 method public token ()I - -
 method public token_$eq (I)V - -
 method public value ()Ljava/lang/String; - -
 method public value_$eq (Ljava/lang/String;)V - -
 method public,final initScanner (Ljava/lang/String;)V - -
 method public,final nextToken ()V - -
 method public,final isIdentChar ()Z - -
 method public,final next ()V - -
 method public,final acc (C)V - -
 method public,final accS (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
 method public,final readToken ()I - -
 method public,final name ()I - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/SystemID 50 public,super scala/xml/dtd/ExternalID scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/SystemID;)Lscala/Option; (Lscala/xml/dtd/SystemID;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/dtd/SystemID; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/dtd/SystemID;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/dtd/SystemID;>; -
 method public systemId ()Ljava/lang/String; - -
 method public publicId ()Lscala/runtime/Null$; - -
 method public copy (Ljava/lang/String;)Lscala/xml/dtd/SystemID; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/SystemID$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/dtd/SystemID;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/SystemID$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/dtd/SystemID; - -
 method public unapply (Lscala/xml/dtd/SystemID;)Lscala/Option; (Lscala/xml/dtd/SystemID;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/dtd/Tokens 50 public,super java/lang/Object - -
 method public,final TOKEN_PCDATA ()I - -
 method public,final NAME ()I - -
 method public,final LPAREN ()I - -
 method public,final RPAREN ()I - -
 method public,final COMMA ()I - -
 method public,final STAR ()I - -
 method public,final PLUS ()I - -
 method public,final OPT ()I - -
 method public,final CHOICE ()I - -
 method public,final END ()I - -
 method public,final S ()I - -
 method public,final token2string (I)Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/UnparsedEntityDecl 50 public,super scala/xml/dtd/EntityDecl scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/UnparsedEntityDecl;)Lscala/Option; (Lscala/xml/dtd/UnparsedEntityDecl;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;>;>; -
 method public,static apply (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;)Lscala/xml/dtd/UnparsedEntityDecl; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple3<Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;>;Lscala/xml/dtd/UnparsedEntityDecl;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/dtd/ExternalID;Lscala/Function1<Ljava/lang/String;Lscala/xml/dtd/UnparsedEntityDecl;>;>;>; -
 method public name ()Ljava/lang/String; - -
 method public extID ()Lscala/xml/dtd/ExternalID; - -
 method public notation ()Ljava/lang/String; - -
 method public buildString (Lscala/collection/mutable/StringBuilder;)Lscala/collection/mutable/StringBuilder; - -
 method public copy (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;)Lscala/xml/dtd/UnparsedEntityDecl; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Lscala/xml/dtd/ExternalID; - -
 method public copy$default$3 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/UnparsedEntityDecl$ 50 public,final,super scala/runtime/AbstractFunction3 scala/Serializable Lscala/runtime/AbstractFunction3<Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;Lscala/xml/dtd/UnparsedEntityDecl;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/UnparsedEntityDecl$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;)Lscala/xml/dtd/UnparsedEntityDecl; - -
 method public unapply (Lscala/xml/dtd/UnparsedEntityDecl;)Lscala/Option; (Lscala/xml/dtd/UnparsedEntityDecl;)Lscala/Option<Lscala/Tuple3<Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;>;>; -
in 0
class scala/xml/dtd/ValidationException 50 public,super java/lang/Exception scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/dtd/ValidationException;)Lscala/Option; (Lscala/xml/dtd/ValidationException;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/dtd/ValidationException;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/dtd/ValidationException;>; -
 method public e ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/ValidationException$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/dtd/ValidationException;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/dtd/ValidationException$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/dtd/ValidationException; - -
 method public unapply (Lscala/xml/dtd/ValidationException;)Lscala/Option; (Lscala/xml/dtd/ValidationException;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/dtd/impl/Base 50 public,super,abstract,deprecated java/lang/Object - -
 inner scala/xml/dtd/impl/Base$Alt$ scala/xml/dtd/impl/Base Alt$ public
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$Sequ$ scala/xml/dtd/impl/Base Sequ$ public
 inner scala/xml/dtd/impl/Base$Star$ scala/xml/dtd/impl/Base Star$ public
 inner scala/xml/dtd/impl/Base$Sequ scala/xml/dtd/impl/Base Sequ public
 inner scala/xml/dtd/impl/Base$Star scala/xml/dtd/impl/Base Star public
 inner scala/xml/dtd/impl/Base$Meta scala/xml/dtd/impl/Base Meta public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public Alt ()Lscala/xml/dtd/impl/Base$Alt$; - -
 method public Sequ ()Lscala/xml/dtd/impl/Base$Sequ$; - -
 method public Star ()Lscala/xml/dtd/impl/Base$Star$; - -
 method public Eps ()Lscala/xml/dtd/impl/Base$Eps$; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/impl/Base$Alt 50 public,super scala/xml/dtd/impl/Base$RegExp - -
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public rs ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>; -
 method public,final isNullable ()Z - -
 method public <init> (Lscala/xml/dtd/impl/Base;Lscala/collection/Seq;)V (Lscala/xml/dtd/impl/Base;Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;)V -
in 0
class scala/xml/dtd/impl/Base$Alt$ 50 public,super java/lang/Object - -
 inner scala/xml/dtd/impl/Base$Alt$ scala/xml/dtd/impl/Base Alt$ public
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 method public apply (Lscala/collection/Seq;)Lscala/xml/dtd/impl/Base$Alt; (Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;)Lscala/xml/dtd/impl/Base$Alt; -
 method public unapplySeq (Lscala/xml/dtd/impl/Base$Alt;)Lscala/Some; (Lscala/xml/dtd/impl/Base$Alt;)Lscala/Some<Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;>; -
 method public <init> (Lscala/xml/dtd/impl/Base;)V - -
in 0
class scala/xml/dtd/impl/Base$Eps$ 50 public,super scala/xml/dtd/impl/Base$RegExp scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public,final isNullable ()Z - -
 method public toString ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public <init> (Lscala/xml/dtd/impl/Base;)V - -
in 0
class scala/xml/dtd/impl/Base$Meta 50 public,super scala/xml/dtd/impl/Base$RegExp - -
 inner scala/xml/dtd/impl/Base$Meta scala/xml/dtd/impl/Base Meta public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public,final isNullable ()Z - -
 method public r ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public <init> (Lscala/xml/dtd/impl/Base;Lscala/xml/dtd/impl/Base$RegExp;)V - -
in 0
class scala/xml/dtd/impl/Base$RegExp 50 public,super,abstract java/lang/Object - -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public,abstract isNullable ()Z - -
 method public <init> (Lscala/xml/dtd/impl/Base;)V - -
in 0
class scala/xml/dtd/impl/Base$Sequ 50 public,super scala/xml/dtd/impl/Base$RegExp - -
 inner scala/xml/dtd/impl/Base$Sequ scala/xml/dtd/impl/Base Sequ public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public rs ()Lscala/collection/Seq; ()Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>; -
 method public,final isNullable ()Z - -
 method public <init> (Lscala/xml/dtd/impl/Base;Lscala/collection/Seq;)V (Lscala/xml/dtd/impl/Base;Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;)V -
in 0
class scala/xml/dtd/impl/Base$Sequ$ 50 public,super java/lang/Object - -
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$Sequ$ scala/xml/dtd/impl/Base Sequ$ public
 inner scala/xml/dtd/impl/Base$Sequ scala/xml/dtd/impl/Base Sequ public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public apply (Lscala/collection/Seq;)Lscala/xml/dtd/impl/Base$RegExp; (Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;)Lscala/xml/dtd/impl/Base$RegExp; -
 method public unapplySeq (Lscala/xml/dtd/impl/Base$Sequ;)Lscala/Some; (Lscala/xml/dtd/impl/Base$Sequ;)Lscala/Some<Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;>; -
 method public <init> (Lscala/xml/dtd/impl/Base;)V - -
in 0
class scala/xml/dtd/impl/Base$Star 50 public,super scala/xml/dtd/impl/Base$RegExp scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$Star scala/xml/dtd/impl/Base Star public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public r ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public,final isNullable ()Z - -
 method public copy (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$Star; - -
 method public copy$default$1 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/impl/Base;Lscala/xml/dtd/impl/Base$RegExp;)V - -
in 0
class scala/xml/dtd/impl/Base$Star$ 50 public,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/Base$Star;>;Lscala/Serializable;
 inner scala/xml/dtd/impl/Base$Star$ scala/xml/dtd/impl/Base Star$ public
 inner scala/xml/dtd/impl/Base$Star scala/xml/dtd/impl/Base Star public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/Base$Star; - -
 method public unapply (Lscala/xml/dtd/impl/Base$Star;)Lscala/Option; (Lscala/xml/dtd/impl/Base$Star;)Lscala/Option<Lscala/xml/dtd/impl/Base$RegExp;>; -
 method public <init> (Lscala/xml/dtd/impl/Base;)V - -
in 0
class scala/xml/dtd/impl/BaseBerrySethi 50 public,super,abstract,deprecated java/lang/Object - -
 inner scala/xml/dtd/impl/Base$Alt scala/xml/dtd/impl/Base Alt public
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$Meta scala/xml/dtd/impl/Base Meta public
 inner scala/xml/dtd/impl/Base$Sequ scala/xml/dtd/impl/Base Sequ public
 inner scala/xml/dtd/impl/Base$Star scala/xml/dtd/impl/Base Star public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/Predef$$less$colon$less scala/Predef $less$colon$less public,static,abstract
 method public,abstract lang ()Lscala/xml/dtd/impl/Base; - -
 method public pos ()I - -
 method public pos_$eq (I)V - -
 method public follow ()Lscala/collection/mutable/HashMap; ()Lscala/collection/mutable/HashMap<Ljava/lang/Object;Lscala/collection/immutable/Set<Ljava/lang/Object;>;>; -
 method public follow_$eq (Lscala/collection/mutable/HashMap;)V (Lscala/collection/mutable/HashMap<Ljava/lang/Object;Lscala/collection/immutable/Set<Ljava/lang/Object;>;>;)V -
 method public finalTag ()I - -
 method public finalTag_$eq (I)V - -
 method public finals ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/Object;Ljava/lang/Object;>; -
 method public finals_$eq (Lscala/collection/immutable/Map;)V (Lscala/collection/immutable/Map<Ljava/lang/Object;Ljava/lang/Object;>;)V -
 method public,final emptySet ()Lscala/collection/immutable/Set; ()Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public compFirst (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public compLast (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public compFollow (Lscala/collection/Seq;)Lscala/collection/immutable/Set; (Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;)Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public compFollow1 (Lscala/collection/immutable/Set;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/collection/immutable/Set<Ljava/lang/Object;>;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public traverse (Lscala/xml/dtd/impl/Base$RegExp;)V - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/impl/DetWordAutom 50 public,super,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract nstates ()I - -
 method public,abstract finals ()[I - -
 method public,abstract delta ()[Lscala/collection/mutable/Map; ()[Lscala/collection/mutable/Map<TT;Ljava/lang/Object;>; -
 method public,abstract default ()[I - -
 method public isFinal (I)Z - -
 method public isSink (I)Z - -
 method public next (ILjava/lang/Object;)I (ITT;)I -
 method public toString ()Ljava/lang/String; - -
 method public <init> ()V ()V -
in 0
class scala/xml/dtd/impl/Inclusion 50 public,interface,abstract,deprecated java/lang/Object - <A:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract labels ()Lscala/collection/Seq; ()Lscala/collection/Seq<TA;>; -
 method public,abstract inclusion (Lscala/xml/dtd/impl/DetWordAutom;Lscala/xml/dtd/impl/DetWordAutom;)Z (Lscala/xml/dtd/impl/DetWordAutom<TA;>;Lscala/xml/dtd/impl/DetWordAutom<TA;>;)Z -
in 0
class scala/xml/dtd/impl/Inclusion$class 50 public,super,abstract java/lang/Object - -
 method public,static inclusion (Lscala/xml/dtd/impl/Inclusion;Lscala/xml/dtd/impl/DetWordAutom;Lscala/xml/dtd/impl/DetWordAutom;)Z - -
 method public,static,final encode$1 (Lscala/xml/dtd/impl/Inclusion;IILscala/xml/dtd/impl/DetWordAutom;)I - -
 method public,static $init$ (Lscala/xml/dtd/impl/Inclusion;)V - -
in 0
class scala/xml/dtd/impl/NondetWordAutom 50 public,super,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 method public,abstract nstates ()I - -
 method public,abstract labels ()Lscala/collection/Seq; ()Lscala/collection/Seq<TT;>; -
 method public,abstract finals ()[I - -
 method public,abstract delta ()[Lscala/collection/mutable/Map; ()[Lscala/collection/mutable/Map<TT;Lscala/collection/immutable/BitSet;>; -
 method public,abstract default ()[Lscala/collection/immutable/BitSet; - -
 method public,final isFinal (I)Z - -
 method public,final finalTag (I)I - -
 method public,final containsFinal (Lscala/collection/immutable/BitSet;)Z - -
 method public,final isEmpty ()Z - -
 method public next (ILjava/lang/Object;)Lscala/collection/immutable/BitSet; (ITT;)Lscala/collection/immutable/BitSet; -
 method public next (Lscala/collection/immutable/BitSet;Ljava/lang/Object;)Lscala/collection/immutable/BitSet; (Lscala/collection/immutable/BitSet;TT;)Lscala/collection/immutable/BitSet; -
 method public nextDefault (Lscala/collection/immutable/BitSet;)Lscala/collection/immutable/BitSet; - -
 method public toString ()Ljava/lang/String; - -
 method public <init> ()V ()V -
in 0
class scala/xml/dtd/impl/PointedHedgeExp 50 public,super,abstract,deprecated scala/xml/dtd/impl/Base - -
 inner scala/xml/dtd/impl/PointedHedgeExp$Node$ scala/xml/dtd/impl/PointedHedgeExp Node$ public
 inner scala/xml/dtd/impl/PointedHedgeExp$Node scala/xml/dtd/impl/PointedHedgeExp Node public
 inner scala/xml/dtd/impl/PointedHedgeExp$Point$ scala/xml/dtd/impl/PointedHedgeExp Point$ public
 inner scala/xml/dtd/impl/PointedHedgeExp$TopIter$ scala/xml/dtd/impl/PointedHedgeExp TopIter$ public
 inner scala/xml/dtd/impl/PointedHedgeExp$TopIter scala/xml/dtd/impl/PointedHedgeExp TopIter public
 method public Node ()Lscala/xml/dtd/impl/PointedHedgeExp$Node$; - -
 method public TopIter ()Lscala/xml/dtd/impl/PointedHedgeExp$TopIter$; - -
 method public Point ()Lscala/xml/dtd/impl/PointedHedgeExp$Point$; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/impl/PointedHedgeExp$Node 50 public,super scala/xml/dtd/impl/Base$RegExp scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/PointedHedgeExp$Node scala/xml/dtd/impl/PointedHedgeExp Node public
 method public label ()Ljava/lang/Object; - -
 method public r ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public,final isNullable ()Z - -
 method public copy (Ljava/lang/Object;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/PointedHedgeExp$Node; - -
 method public copy$default$1 ()Ljava/lang/Object; - -
 method public copy$default$2 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/impl/PointedHedgeExp;Ljava/lang/Object;Lscala/xml/dtd/impl/Base$RegExp;)V - -
in 0
class scala/xml/dtd/impl/PointedHedgeExp$Node$ 50 public,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/Object;Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/PointedHedgeExp$Node;>;Lscala/Serializable;
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/PointedHedgeExp$Node$ scala/xml/dtd/impl/PointedHedgeExp Node$ public
 inner scala/xml/dtd/impl/PointedHedgeExp$Node scala/xml/dtd/impl/PointedHedgeExp Node public
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/Object;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/PointedHedgeExp$Node; - -
 method public unapply (Lscala/xml/dtd/impl/PointedHedgeExp$Node;)Lscala/Option; (Lscala/xml/dtd/impl/PointedHedgeExp$Node;)Lscala/Option<Lscala/Tuple2<Ljava/lang/Object;Lscala/xml/dtd/impl/Base$RegExp;>;>; -
 method public <init> (Lscala/xml/dtd/impl/PointedHedgeExp;)V - -
in 0
class scala/xml/dtd/impl/PointedHedgeExp$Point$ 50 public,super scala/xml/dtd/impl/Base$RegExp scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/PointedHedgeExp$Point$ scala/xml/dtd/impl/PointedHedgeExp Point$ public
 method public,final isNullable ()Z - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public <init> (Lscala/xml/dtd/impl/PointedHedgeExp;)V - -
in 0
class scala/xml/dtd/impl/PointedHedgeExp$TopIter 50 public,super scala/xml/dtd/impl/Base$RegExp scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/PointedHedgeExp$TopIter scala/xml/dtd/impl/PointedHedgeExp TopIter public
 method public r1 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public r2 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public,final isNullable ()Z - -
 method public copy (Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/PointedHedgeExp$TopIter; - -
 method public copy$default$1 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public copy$default$2 ()Lscala/xml/dtd/impl/Base$RegExp; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/impl/PointedHedgeExp;Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/Base$RegExp;)V - -
in 0
class scala/xml/dtd/impl/PointedHedgeExp$TopIter$ 50 public,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/PointedHedgeExp$TopIter;>;Lscala/Serializable;
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/PointedHedgeExp$TopIter$ scala/xml/dtd/impl/PointedHedgeExp TopIter$ public
 inner scala/xml/dtd/impl/PointedHedgeExp$TopIter scala/xml/dtd/impl/PointedHedgeExp TopIter public
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/xml/dtd/impl/PointedHedgeExp$TopIter; - -
 method public unapply (Lscala/xml/dtd/impl/PointedHedgeExp$TopIter;)Lscala/Option; (Lscala/xml/dtd/impl/PointedHedgeExp$TopIter;)Lscala/Option<Lscala/Tuple2<Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/Base$RegExp;>;>; -
 method public <init> (Lscala/xml/dtd/impl/PointedHedgeExp;)V - -
in 0
class scala/xml/dtd/impl/SubsetConstruction 50 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner scala/math/Ordering$Int$ scala/math/Ordering Int$ public,static
 inner scala/Predef$ArrowAssoc$ scala/Predef ArrowAssoc$ public,static
 method public nfa ()Lscala/xml/dtd/impl/NondetWordAutom; ()Lscala/xml/dtd/impl/NondetWordAutom<TT;>; -
 method public selectTag (Lscala/collection/immutable/BitSet;[I)I - -
 method public determinize ()Lscala/xml/dtd/impl/DetWordAutom; ()Lscala/xml/dtd/impl/DetWordAutom<TT;>; -
 method public,final scala$xml$dtd$impl$SubsetConstruction$$add$1 (Lscala/collection/immutable/BitSet;Lscala/runtime/ObjectRef;Lscala/runtime/ObjectRef;Lscala/collection/mutable/Stack;)V - -
 method public <init> (Lscala/xml/dtd/impl/NondetWordAutom;)V (Lscala/xml/dtd/impl/NondetWordAutom<TT;>;)V -
in 0
class scala/xml/dtd/impl/SyntaxError 50 public,super,deprecated java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/dtd/impl/WordBerrySethi 50 public,super,abstract scala/xml/dtd/impl/BaseBerrySethi - -
 inner scala/xml/dtd/impl/Base$Eps$ scala/xml/dtd/impl/Base Eps$ public
 inner scala/xml/dtd/impl/Base$Sequ scala/xml/dtd/impl/Base Sequ public
 inner scala/xml/dtd/impl/Base$Sequ$ scala/xml/dtd/impl/Base Sequ$ public
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter scala/xml/dtd/impl/WordExp Letter public
 method public,abstract lang ()Lscala/xml/dtd/impl/WordExp; - -
 method public labels ()Lscala/collection/mutable/HashSet; ()Lscala/collection/mutable/HashSet<Lscala/xml/dtd/impl/WordExp$Label;>; -
 method public labels_$eq (Lscala/collection/mutable/HashSet;)V (Lscala/collection/mutable/HashSet<Lscala/xml/dtd/impl/WordExp$Label;>;)V -
 method public labelAt ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/Object;Lscala/xml/dtd/impl/WordExp$Label;>; -
 method public labelAt_$eq (Lscala/collection/immutable/Map;)V (Lscala/collection/immutable/Map<Ljava/lang/Object;Lscala/xml/dtd/impl/WordExp$Label;>;)V -
 method public deltaq ()[Lscala/collection/mutable/HashMap; ()[Lscala/collection/mutable/HashMap<Lscala/xml/dtd/impl/WordExp$Label;Lscala/collection/immutable/List<Ljava/lang/Object;>;>; -
 method public deltaq_$eq ([Lscala/collection/mutable/HashMap;)V ([Lscala/collection/mutable/HashMap<Lscala/xml/dtd/impl/WordExp$Label;Lscala/collection/immutable/List<Ljava/lang/Object;>;>;)V -
 method public defaultq ()[Lscala/collection/immutable/List; ()[Lscala/collection/immutable/List<Ljava/lang/Object;>; -
 method public defaultq_$eq ([Lscala/collection/immutable/List;)V ([Lscala/collection/immutable/List<Ljava/lang/Object;>;)V -
 method public initials ()Lscala/collection/immutable/Set; ()Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public initials_$eq (Lscala/collection/immutable/Set;)V (Lscala/collection/immutable/Set<Ljava/lang/Object;>;)V -
 method public compFirst (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public compLast (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public compFollow1 (Lscala/collection/immutable/Set;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set; (Lscala/collection/immutable/Set<Ljava/lang/Object;>;Lscala/xml/dtd/impl/Base$RegExp;)Lscala/collection/immutable/Set<Ljava/lang/Object;>; -
 method public seenLabel (Lscala/xml/dtd/impl/Base$RegExp;ILscala/xml/dtd/impl/WordExp$Label;)V - -
 method public seenLabel (Lscala/xml/dtd/impl/Base$RegExp;Lscala/xml/dtd/impl/WordExp$Label;)I - -
 method public traverse (Lscala/xml/dtd/impl/Base$RegExp;)V - -
 method public makeTransition (IILscala/xml/dtd/impl/WordExp$Label;)V - -
 method public initialize (Lscala/collection/Seq;)V (Lscala/collection/Seq<Lscala/xml/dtd/impl/Base$RegExp;>;)V -
 method public initializeAutom ()V - -
 method public collectTransitions ()V - -
 method public automatonFrom (Lscala/xml/dtd/impl/Base$RegExp;I)Lscala/xml/dtd/impl/NondetWordAutom; (Lscala/xml/dtd/impl/Base$RegExp;I)Lscala/xml/dtd/impl/NondetWordAutom<Lscala/xml/dtd/impl/WordExp$Label;>; -
 method public <init> ()V - -
in 0
class scala/xml/dtd/impl/WordExp 50 public,super,abstract scala/xml/dtd/impl/Base - -
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter$ scala/xml/dtd/impl/WordExp Letter$ public
 inner scala/xml/dtd/impl/WordExp$Letter scala/xml/dtd/impl/WordExp Letter public
 inner scala/xml/dtd/impl/WordExp$Wildcard$ scala/xml/dtd/impl/WordExp Wildcard$ public
 inner scala/xml/dtd/impl/WordExp$Wildcard scala/xml/dtd/impl/WordExp Wildcard public
 method public Letter ()Lscala/xml/dtd/impl/WordExp$Letter$; - -
 method public Wildcard ()Lscala/xml/dtd/impl/WordExp$Wildcard$; - -
 method public <init> ()V - -
in 0
class scala/xml/dtd/impl/WordExp$Label 50 public,super,abstract java/lang/Object - -
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 method public <init> (Lscala/xml/dtd/impl/WordExp;)V - -
in 0
class scala/xml/dtd/impl/WordExp$Letter 50 public,super scala/xml/dtd/impl/Base$RegExp scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter scala/xml/dtd/impl/WordExp Letter public
 method public a ()Lscala/xml/dtd/impl/WordExp$Label; - -
 method public,final isNullable ()Z - -
 method public pos ()I - -
 method public pos_$eq (I)V - -
 method public copy (Lscala/xml/dtd/impl/WordExp$Label;)Lscala/xml/dtd/impl/WordExp$Letter; - -
 method public copy$default$1 ()Lscala/xml/dtd/impl/WordExp$Label; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/impl/WordExp;Lscala/xml/dtd/impl/WordExp$Label;)V - -
in 0
class scala/xml/dtd/impl/WordExp$Letter$ 50 public,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/xml/dtd/impl/WordExp$Label;Lscala/xml/dtd/impl/WordExp$Letter;>;Lscala/Serializable;
 inner scala/xml/dtd/impl/WordExp$Label scala/xml/dtd/impl/WordExp Label public,abstract
 inner scala/xml/dtd/impl/WordExp$Letter$ scala/xml/dtd/impl/WordExp Letter$ public
 inner scala/xml/dtd/impl/WordExp$Letter scala/xml/dtd/impl/WordExp Letter public
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/xml/dtd/impl/WordExp$Label;)Lscala/xml/dtd/impl/WordExp$Letter; - -
 method public unapply (Lscala/xml/dtd/impl/WordExp$Letter;)Lscala/Option; (Lscala/xml/dtd/impl/WordExp$Letter;)Lscala/Option<Lscala/xml/dtd/impl/WordExp$Label;>; -
 method public <init> (Lscala/xml/dtd/impl/WordExp;)V - -
in 0
class scala/xml/dtd/impl/WordExp$Wildcard 50 public,super scala/xml/dtd/impl/Base$RegExp scala/Product,scala/Serializable -
 inner scala/xml/dtd/impl/Base$RegExp scala/xml/dtd/impl/Base RegExp public,abstract
 inner scala/xml/dtd/impl/WordExp$Wildcard scala/xml/dtd/impl/WordExp Wildcard public
 method public,final isNullable ()Z - -
 method public pos ()I - -
 method public pos_$eq (I)V - -
 method public copy ()Lscala/xml/dtd/impl/WordExp$Wildcard; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/xml/dtd/impl/WordExp;)V - -
in 0
class scala/xml/dtd/impl/WordExp$Wildcard$ 50 public,super scala/runtime/AbstractFunction0 scala/Serializable Lscala/runtime/AbstractFunction0<Lscala/xml/dtd/impl/WordExp$Wildcard;>;Lscala/Serializable;
 inner scala/xml/dtd/impl/WordExp$Wildcard$ scala/xml/dtd/impl/WordExp Wildcard$ public
 inner scala/xml/dtd/impl/WordExp$Wildcard scala/xml/dtd/impl/WordExp Wildcard public
 method public,final toString ()Ljava/lang/String; - -
 method public apply ()Lscala/xml/dtd/impl/WordExp$Wildcard; - -
 method public unapply (Lscala/xml/dtd/impl/WordExp$Wildcard;)Z - -
 method public <init> (Lscala/xml/dtd/impl/WordExp;)V - -
in 0
class scala/xml/factory/Binder 50 public,super,abstract scala/xml/parsing/ValidatingMarkupHandler - -
 method public preserveWS ()Z - -
 method public result ()Lscala/xml/NodeBuffer; - -
 method public result_$eq (Lscala/xml/NodeBuffer;)V - -
 method public reportSyntaxError (ILjava/lang/String;)V - -
 method public,final procInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/ProcInstr; - -
 method public,final comment (ILjava/lang/String;)Lscala/xml/Comment; - -
 method public,final entityRef (ILjava/lang/String;)Lscala/xml/EntityRef; - -
 method public,final text (ILjava/lang/String;)Lscala/xml/Text; - -
 method public,final traverse (Lscala/xml/Node;)V - -
 method public,final validate (Lscala/xml/Node;)Lscala/xml/Node; - -
 method public <init> (Z)V - -
in 0
class scala/xml/factory/LoggedNodeFactory 50 public,interface,abstract,deprecated java/lang/Object scala/xml/factory/NodeFactory <A:Lscala/xml/Node;>Ljava/lang/Object;Lscala/xml/factory/NodeFactory<TA;>;
 method public,abstract scala$xml$factory$LoggedNodeFactory$_setter_$logNode_$eq (Z)V - -
 method public,abstract scala$xml$factory$LoggedNodeFactory$_setter_$logText_$eq (Z)V - -
 method public,abstract scala$xml$factory$LoggedNodeFactory$_setter_$logComment_$eq (Z)V - -
 method public,abstract scala$xml$factory$LoggedNodeFactory$_setter_$logProcInstr_$eq (Z)V - -
 method public,abstract scala$xml$factory$LoggedNodeFactory$_setter_$logCompressLevel_$eq (I)V - -
 method public,abstract logNode ()Z - -
 method public,abstract logText ()Z - -
 method public,abstract logComment ()Z - -
 method public,abstract logProcInstr ()Z - -
 method public,abstract NONE ()I - -
 method public,abstract CACHE ()I - -
 method public,abstract FULL ()I - -
 method public,abstract logCompressLevel ()I - -
 method public,abstract makeNode (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)TA; -
 method public,abstract makeText (Ljava/lang/String;)Lscala/xml/Text; - -
 method public,abstract makeComment (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Comment;>; -
 method public,abstract makeProcInstr (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/ProcInstr;>; -
 method public,abstract log (Ljava/lang/String;)V - -
in 0
class scala/xml/factory/LoggedNodeFactory$class 50 public,super,abstract java/lang/Object - -
 method public,static makeNode (Lscala/xml/factory/LoggedNodeFactory;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; - -
 method public,static makeText (Lscala/xml/factory/LoggedNodeFactory;Ljava/lang/String;)Lscala/xml/Text; - -
 method public,static makeComment (Lscala/xml/factory/LoggedNodeFactory;Ljava/lang/String;)Lscala/collection/Seq; - -
 method public,static makeProcInstr (Lscala/xml/factory/LoggedNodeFactory;Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq; - -
 method public,static log (Lscala/xml/factory/LoggedNodeFactory;Ljava/lang/String;)V - -
 method public,static $init$ (Lscala/xml/factory/LoggedNodeFactory;)V - -
in 0
class scala/xml/factory/NodeFactory 50 public,interface,abstract java/lang/Object - <A:Lscala/xml/Node;>Ljava/lang/Object;
 method public,abstract scala$xml$factory$NodeFactory$_setter_$ignoreComments_$eq (Z)V - -
 method public,abstract scala$xml$factory$NodeFactory$_setter_$ignoreProcInstr_$eq (Z)V - -
 method public,abstract scala$xml$factory$NodeFactory$_setter_$cache_$eq (Lscala/collection/mutable/HashMap;)V - -
 method public,abstract ignoreComments ()Z - -
 method public,abstract ignoreProcInstr ()Z - -
 method public,abstract cache ()Lscala/collection/mutable/HashMap; ()Lscala/collection/mutable/HashMap<Ljava/lang/Object;Lscala/collection/immutable/List<TA;>;>; -
 method public,abstract create (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)TA; -
 method public,abstract construct (ILscala/collection/immutable/List;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; (ILscala/collection/immutable/List<TA;>;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)TA; -
 method public,abstract eqElements (Lscala/collection/Seq;Lscala/collection/Seq;)Z (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/collection/Seq<Lscala/xml/Node;>;)Z -
 method public,abstract nodeEquals (Lscala/xml/Node;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Z (Lscala/xml/Node;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)Z -
 method public,abstract makeNode (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)TA; -
 method public,abstract makeText (Ljava/lang/String;)Lscala/xml/Text; - -
 method public,abstract makeComment (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Comment;>; -
 method public,abstract makeProcInstr (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/ProcInstr;>; -
in 0
class scala/xml/factory/NodeFactory$class 50 public,super,abstract java/lang/Object - -
 method public,static construct (Lscala/xml/factory/NodeFactory;ILscala/collection/immutable/List;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; - -
 method public,static eqElements (Lscala/xml/factory/NodeFactory;Lscala/collection/Seq;Lscala/collection/Seq;)Z - -
 method public,static nodeEquals (Lscala/xml/factory/NodeFactory;Lscala/xml/Node;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Z - -
 method public,static makeNode (Lscala/xml/factory/NodeFactory;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; - -
 method public,static makeText (Lscala/xml/factory/NodeFactory;Ljava/lang/String;)Lscala/xml/Text; - -
 method public,static makeComment (Lscala/xml/factory/NodeFactory;Ljava/lang/String;)Lscala/collection/Seq; - -
 method public,static makeProcInstr (Lscala/xml/factory/NodeFactory;Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq; - -
 method public,static $init$ (Lscala/xml/factory/NodeFactory;)V - -
in 0
class scala/xml/factory/XMLLoader 50 public,interface,abstract java/lang/Object - <T:Lscala/xml/Node;>Ljava/lang/Object;
 method public,abstract adapter ()Lscala/xml/parsing/FactoryAdapter; - -
 method public,abstract parser ()Ljavax/xml/parsers/SAXParser; - -
 method public,abstract loadXML (Lorg/xml/sax/InputSource;Ljavax/xml/parsers/SAXParser;)Lscala/xml/Node; (Lorg/xml/sax/InputSource;Ljavax/xml/parsers/SAXParser;)TT; -
 method public,abstract loadFile (Ljava/io/File;)Lscala/xml/Node; (Ljava/io/File;)TT; -
 method public,abstract loadFile (Ljava/io/FileDescriptor;)Lscala/xml/Node; (Ljava/io/FileDescriptor;)TT; -
 method public,abstract loadFile (Ljava/lang/String;)Lscala/xml/Node; (Ljava/lang/String;)TT; -
 method public,abstract load (Ljava/io/InputStream;)Lscala/xml/Node; (Ljava/io/InputStream;)TT; -
 method public,abstract load (Ljava/io/Reader;)Lscala/xml/Node; (Ljava/io/Reader;)TT; -
 method public,abstract load (Ljava/lang/String;)Lscala/xml/Node; (Ljava/lang/String;)TT; -
 method public,abstract load (Lorg/xml/sax/InputSource;)Lscala/xml/Node; (Lorg/xml/sax/InputSource;)TT; -
 method public,abstract load (Ljava/net/URL;)Lscala/xml/Node; (Ljava/net/URL;)TT; -
 method public,abstract loadString (Ljava/lang/String;)Lscala/xml/Node; (Ljava/lang/String;)TT; -
in 0
class scala/xml/factory/XMLLoader$class 50 public,super,abstract java/lang/Object - -
 method public,static adapter (Lscala/xml/factory/XMLLoader;)Lscala/xml/parsing/FactoryAdapter; - -
 method public,static parser (Lscala/xml/factory/XMLLoader;)Ljavax/xml/parsers/SAXParser; - -
 method public,static loadXML (Lscala/xml/factory/XMLLoader;Lorg/xml/sax/InputSource;Ljavax/xml/parsers/SAXParser;)Lscala/xml/Node; - -
 method public,static loadFile (Lscala/xml/factory/XMLLoader;Ljava/io/File;)Lscala/xml/Node; - -
 method public,static loadFile (Lscala/xml/factory/XMLLoader;Ljava/io/FileDescriptor;)Lscala/xml/Node; - -
 method public,static loadFile (Lscala/xml/factory/XMLLoader;Ljava/lang/String;)Lscala/xml/Node; - -
 method public,static load (Lscala/xml/factory/XMLLoader;Ljava/io/InputStream;)Lscala/xml/Node; - -
 method public,static load (Lscala/xml/factory/XMLLoader;Ljava/io/Reader;)Lscala/xml/Node; - -
 method public,static load (Lscala/xml/factory/XMLLoader;Ljava/lang/String;)Lscala/xml/Node; - -
 method public,static load (Lscala/xml/factory/XMLLoader;Lorg/xml/sax/InputSource;)Lscala/xml/Node; - -
 method public,static load (Lscala/xml/factory/XMLLoader;Ljava/net/URL;)Lscala/xml/Node; - -
 method public,static loadString (Lscala/xml/factory/XMLLoader;Ljava/lang/String;)Lscala/xml/Node; - -
 method public,static $init$ (Lscala/xml/factory/XMLLoader;)V - -
in 0
class scala/xml/include/CircularIncludeException 50 public,super scala/xml/include/XIncludeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> ()V - -
in 0
class scala/xml/include/UnavailableResourceException 50 public,super scala/xml/include/XIncludeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> ()V - -
in 0
class scala/xml/include/XIncludeException 50 public,super java/lang/Exception - -
 method public setRootCause (Ljava/lang/Throwable;)V - -
 method public getRootCause ()Ljava/lang/Throwable; - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> ()V - -
in 0
class scala/xml/include/sax/EncodingHeuristics 50 public,final,super java/lang/Object - -
 inner scala/xml/include/sax/EncodingHeuristics$EncodingNames$ scala/xml/include/sax/EncodingHeuristics EncodingNames$ public,static
 method public,static readEncodingFromStream (Ljava/io/InputStream;)Ljava/lang/String; - -
in 0
class scala/xml/include/sax/EncodingHeuristics$ 50 public,final,super java/lang/Object - -
 inner scala/util/matching/Regex$Match scala/util/matching/Regex Match public,static
 inner scala/xml/include/sax/EncodingHeuristics$EncodingNames$ scala/xml/include/sax/EncodingHeuristics EncodingNames$ public,static
 field public,static,final MODULE$ Lscala/xml/include/sax/EncodingHeuristics$; -
 method public,static <clinit> ()V - -
 method public readEncodingFromStream (Ljava/io/InputStream;)Ljava/lang/String; - -
in 0
class scala/xml/include/sax/EncodingHeuristics$EncodingNames$ 50 public,super java/lang/Object - -
 inner scala/xml/include/sax/EncodingHeuristics$EncodingNames$ scala/xml/include/sax/EncodingHeuristics EncodingNames$ public,static
 field public,static,final MODULE$ Lscala/xml/include/sax/EncodingHeuristics$EncodingNames$; -
 method public,static <clinit> ()V - -
 method public bigUCS4 ()Ljava/lang/String; - -
 method public littleUCS4 ()Ljava/lang/String; - -
 method public unusualUCS4 ()Ljava/lang/String; - -
 method public bigUTF16 ()Ljava/lang/String; - -
 method public littleUTF16 ()Ljava/lang/String; - -
 method public utf8 ()Ljava/lang/String; - -
 method public default ()Ljava/lang/String; - -
 method public <init> ()V - -
in 0
class scala/xml/include/sax/XIncludeFilter 50 public,super org/xml/sax/helpers/XMLFilterImpl - -
 method public,final XINCLUDE_NAMESPACE ()Ljava/lang/String; - -
 method public setDocumentLocator (Lorg/xml/sax/Locator;)V - -
 method public insideIncludeElement ()Z - -
 method public startElement (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/xml/sax/Attributes;)V - -
 method public endElement (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public startDocument ()V - -
 method public endDocument ()V - -
 method public startPrefixMapping (Ljava/lang/String;Ljava/lang/String;)V - -
 method public endPrefixMapping (Ljava/lang/String;)V - -
 method public characters ([CII)V - -
 method public ignorableWhitespace ([CII)V - -
 method public processingInstruction (Ljava/lang/String;Ljava/lang/String;)V - -
 method public skippedEntity (Ljava/lang/String;)V - -
 method public <init> ()V - -
in 0
class scala/xml/include/sax/XIncluder 50 public,super java/lang/Object org/xml/sax/ContentHandler,org/xml/sax/ext/LexicalHandler -
 method public out ()Ljava/io/OutputStreamWriter; - -
 method public out_$eq (Ljava/io/OutputStreamWriter;)V - -
 method public setDocumentLocator (Lorg/xml/sax/Locator;)V - -
 method public startDocument ()V - -
 method public endDocument ()V - -
 method public startPrefixMapping (Ljava/lang/String;Ljava/lang/String;)V - -
 method public endPrefixMapping (Ljava/lang/String;)V - -
 method public startElement (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/xml/sax/Attributes;)V - -
 method public endElement (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public characters ([CII)V - -
 method public ignorableWhitespace ([CII)V - -
 method public processingInstruction (Ljava/lang/String;Ljava/lang/String;)V - -
 method public skippedEntity (Ljava/lang/String;)V - -
 method public startDTD (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public endDTD ()V - -
 method public startEntity (Ljava/lang/String;)V - -
 method public endEntity (Ljava/lang/String;)V - -
 method public startCDATA ()V - -
 method public endCDATA ()V - -
 method public setFilter (Lscala/xml/include/sax/XIncludeFilter;)V - -
 method public comment ([CII)V - -
 method public <init> (Ljava/io/OutputStream;Ljava/lang/String;)V - -
in 0
class scala/xml/package 50 public,final,super java/lang/Object - -
 method public,static XercesClassName ()Ljava/lang/String; - -
in 0
class scala/xml/package$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/package$; -
 method public,static <clinit> ()V - -
 method public XercesClassName ()Ljava/lang/String; - -
in 0
class scala/xml/parsing/ConsoleErrorHandler 50 public,interface,abstract java/lang/Object - -
 method public,abstract warning (Lorg/xml/sax/SAXParseException;)V - -
 method public,abstract error (Lorg/xml/sax/SAXParseException;)V - -
 method public,abstract fatalError (Lorg/xml/sax/SAXParseException;)V - -
 method public,abstract printError (Ljava/lang/String;Lorg/xml/sax/SAXParseException;)V - -
in 0
class scala/xml/parsing/ConsoleErrorHandler$class 50 public,super,abstract java/lang/Object - -
 method public,static warning (Lscala/xml/parsing/ConsoleErrorHandler;Lorg/xml/sax/SAXParseException;)V - -
 method public,static error (Lscala/xml/parsing/ConsoleErrorHandler;Lorg/xml/sax/SAXParseException;)V - -
 method public,static fatalError (Lscala/xml/parsing/ConsoleErrorHandler;Lorg/xml/sax/SAXParseException;)V - -
 method public,static printError (Lscala/xml/parsing/ConsoleErrorHandler;Ljava/lang/String;Lorg/xml/sax/SAXParseException;)V - -
 method public,static $init$ (Lscala/xml/parsing/ConsoleErrorHandler;)V - -
in 0
class scala/xml/parsing/ConstructingHandler 50 public,super,abstract scala/xml/parsing/MarkupHandler - -
 method public,abstract preserveWS ()Z - -
 method public elem (ILjava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/xml/NodeSeq;)Lscala/xml/NodeSeq; - -
 method public procInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/ProcInstr; - -
 method public comment (ILjava/lang/String;)Lscala/xml/Comment; - -
 method public entityRef (ILjava/lang/String;)Lscala/xml/EntityRef; - -
 method public text (ILjava/lang/String;)Lscala/xml/Text; - -
 method public <init> ()V - -
in 0
class scala/xml/parsing/ConstructingParser 50 public,super scala/xml/parsing/ConstructingHandler scala/xml/parsing/ExternalSources,scala/xml/parsing/MarkupParser -
 method public,static fromSource (Lscala/io/Source;Z)Lscala/xml/parsing/ConstructingParser; - -
 method public,static fromFile (Ljava/io/File;Z)Lscala/xml/parsing/ConstructingParser; - -
 method public curInput ()Lscala/io/Source; - -
 method public curInput_$eq (Lscala/io/Source;)V - -
 method public scala$xml$parsing$MarkupParser$$handle ()Lscala/xml/parsing/MarkupHandler; - -
 method public inpStack ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/io/Source;>; -
 method public inpStack_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/io/Source;>;)V -
 method public pos ()I - -
 method public pos_$eq (I)V - -
 method public extIndex ()I - -
 method public extIndex_$eq (I)V - -
 method public tmppos ()I - -
 method public tmppos_$eq (I)V - -
 method public nextChNeeded ()Z - -
 method public nextChNeeded_$eq (Z)V - -
 method public reachedEof ()Z - -
 method public reachedEof_$eq (Z)V - -
 method public lastChRead ()C - -
 method public lastChRead_$eq (C)V - -
 method public cbuf ()Lscala/collection/mutable/StringBuilder; - -
 method public dtd ()Lscala/xml/dtd/DTD; - -
 method public dtd_$eq (Lscala/xml/dtd/DTD;)V - -
 method public doc ()Lscala/xml/Document; - -
 method public doc_$eq (Lscala/xml/Document;)V - -
 method public scala$xml$parsing$MarkupParser$_setter_$scala$xml$parsing$MarkupParser$$handle_$eq (Lscala/xml/parsing/MarkupHandler;)V - -
 method public scala$xml$parsing$MarkupParser$_setter_$cbuf_$eq (Lscala/collection/mutable/StringBuilder;)V - -
 method public truncatedError (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public errorNoEnd (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public xHandleError (CLjava/lang/String;)V - -
 method public lookahead ()Lscala/collection/BufferedIterator; ()Lscala/collection/BufferedIterator<Ljava/lang/Object;>; -
 method public ch ()C - -
 method public eof ()Z - -
 method public xmlProcInstr ()Lscala/xml/MetaData; - -
 method public prolog ()Lscala/Tuple3; ()Lscala/Tuple3<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/Object;>;>; -
 method public textDecl ()Lscala/Tuple2; ()Lscala/Tuple2<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;>; -
 method public document ()Lscala/xml/Document; - -
 method public putChar (C)Lscala/collection/mutable/StringBuilder; - -
 method public initialize ()Lscala/xml/parsing/MarkupHandler; - -
 method public ch_returning_nextch ()C - -
 method public mkAttributes (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public mkProcInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public nextch ()V - -
 method public xAttributes (Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public xEntityValue ()Ljava/lang/String; - -
 method public xCharData ()Lscala/xml/NodeSeq; - -
 method public xComment ()Lscala/xml/NodeSeq; - -
 method public appendText (ILscala/xml/NodeBuffer;Ljava/lang/String;)V - -
 method public content1 (Lscala/xml/NamespaceBinding;Lscala/xml/NodeBuffer;)V - -
 method public content (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public externalID ()Lscala/xml/dtd/ExternalID; - -
 method public parseDTD ()V - -
 method public element (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public element1 (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public systemLiteral ()Ljava/lang/String; - -
 method public pubidLiteral ()Ljava/lang/String; - -
 method public extSubset ()V - -
 method public markupDecl1 ()Ljava/lang/Object; - -
 method public markupDecl ()V - -
 method public intSubset ()V - -
 method public elementDecl ()V - -
 method public attrDecl ()V - -
 method public entityDecl ()V - -
 method public notationDecl ()V - -
 method public reportSyntaxError (ILjava/lang/String;)V - -
 method public reportSyntaxError (Ljava/lang/String;)V - -
 method public reportValidationError (ILjava/lang/String;)V - -
 method public push (Ljava/lang/String;)V - -
 method public pushExternal (Ljava/lang/String;)V - -
 method public pop ()V - -
 method public unreachable ()Lscala/runtime/Nothing$; - -
 method public xTag (Ljava/lang/Object;)Lscala/Tuple2; (Ljava/lang/Object;)Lscala/Tuple2<Ljava/lang/String;Ljava/lang/Object;>; -
 method public xProcInstr ()Ljava/lang/Object; - -
 method public xAttributeValue (C)Ljava/lang/String; - -
 method public xAttributeValue ()Ljava/lang/String; - -
 method public xEndTag (Ljava/lang/String;)V - -
 method public xName ()Ljava/lang/String; - -
 method public xCharRef (Lscala/Function0;Lscala/Function0;)Ljava/lang/String; (Lscala/Function0<Ljava/lang/Object;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Ljava/lang/String; -
 method public xCharRef (Lscala/collection/Iterator;)Ljava/lang/String; (Lscala/collection/Iterator<Ljava/lang/Object;>;)Ljava/lang/String; -
 method public xCharRef ()Ljava/lang/String; - -
 method public errorAndResult (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public xToken (C)V - -
 method public xToken (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
 method public xEQ ()V - -
 method public xSpaceOpt ()V - -
 method public xSpace ()V - -
 method public returning (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Lscala/Function1<TT;Lscala/runtime/BoxedUnit;>;)TT; -
 method public saving (Ljava/lang/Object;Lscala/Function1;Lscala/Function0;)Ljava/lang/Object; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(TA;Lscala/Function1<TA;Lscala/runtime/BoxedUnit;>;Lscala/Function0<TB;>;)TB; -
 method public xTakeUntil (Lscala/Function2;Lscala/Function0;Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Ljava/lang/String;TT;>;Lscala/Function0<Ljava/lang/Object;>;Ljava/lang/String;)TT; -
 method public,final isSpace (C)Z - -
 method public,final isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public isAlpha (C)Z - -
 method public isAlphaDigit (C)Z - -
 method public isNameChar (C)Z - -
 method public isNameStart (C)Z - -
 method public isName (Ljava/lang/String;)Z - -
 method public isPubIDChar (C)Z - -
 method public isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public checkSysID (Ljava/lang/String;)Z - -
 method public checkPubID (Ljava/lang/String;)Z - -
 method public externalSource (Ljava/lang/String;)Lscala/io/Source; - -
 method public input ()Lscala/io/Source; - -
 method public preserveWS ()Z - -
 method public <init> (Lscala/io/Source;Z)V - -
in 0
class scala/xml/parsing/ConstructingParser$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/parsing/ConstructingParser$; -
 method public,static <clinit> ()V - -
 method public fromFile (Ljava/io/File;Z)Lscala/xml/parsing/ConstructingParser; - -
 method public fromSource (Lscala/io/Source;Z)Lscala/xml/parsing/ConstructingParser; - -
in 0
class scala/xml/parsing/DefaultMarkupHandler 50 public,super,abstract scala/xml/parsing/MarkupHandler - -
 method public elem (ILjava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/xml/NodeSeq;)Lscala/xml/NodeSeq; - -
 method public procInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public comment (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public entityRef (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public text (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public <init> ()V - -
in 0
class scala/xml/parsing/ExternalSources 50 public,interface,abstract java/lang/Object - -
 method public,abstract externalSource (Ljava/lang/String;)Lscala/io/Source; - -
in 0
class scala/xml/parsing/ExternalSources$class 50 public,super,abstract java/lang/Object - -
 method public,static externalSource (Lscala/xml/parsing/MarkupHandler;Ljava/lang/String;)Lscala/io/Source; - -
 method public,static $init$ (Lscala/xml/parsing/MarkupHandler;)V - -
in 0
class scala/xml/parsing/FactoryAdapter 50 public,super,abstract org/xml/sax/helpers/DefaultHandler scala/xml/factory/XMLLoader Lorg/xml/sax/helpers/DefaultHandler;Lscala/xml/factory/XMLLoader<Lscala/xml/Node;>;
 method public adapter ()Lscala/xml/parsing/FactoryAdapter; - -
 method public parser ()Ljavax/xml/parsers/SAXParser; - -
 method public loadXML (Lorg/xml/sax/InputSource;Ljavax/xml/parsers/SAXParser;)Lscala/xml/Node; - -
 method public loadFile (Ljava/io/File;)Lscala/xml/Node; - -
 method public loadFile (Ljava/io/FileDescriptor;)Lscala/xml/Node; - -
 method public loadFile (Ljava/lang/String;)Lscala/xml/Node; - -
 method public load (Ljava/io/InputStream;)Lscala/xml/Node; - -
 method public load (Ljava/io/Reader;)Lscala/xml/Node; - -
 method public load (Ljava/lang/String;)Lscala/xml/Node; - -
 method public load (Lorg/xml/sax/InputSource;)Lscala/xml/Node; - -
 method public load (Ljava/net/URL;)Lscala/xml/Node; - -
 method public loadString (Ljava/lang/String;)Lscala/xml/Node; - -
 method public rootElem ()Lscala/xml/Node; - -
 method public rootElem_$eq (Lscala/xml/Node;)V - -
 method public buffer ()Lscala/collection/mutable/StringBuilder; - -
 method public attribStack ()Lscala/collection/mutable/Stack; ()Lscala/collection/mutable/Stack<Lscala/xml/MetaData;>; -
 method public hStack ()Lscala/collection/mutable/Stack; ()Lscala/collection/mutable/Stack<Lscala/xml/Node;>; -
 method public tagStack ()Lscala/collection/mutable/Stack; ()Lscala/collection/mutable/Stack<Ljava/lang/String;>; -
 method public scopeStack ()Lscala/collection/mutable/Stack; ()Lscala/collection/mutable/Stack<Lscala/xml/NamespaceBinding;>; -
 method public scopeStack_$eq (Lscala/collection/mutable/Stack;)V (Lscala/collection/mutable/Stack<Lscala/xml/NamespaceBinding;>;)V -
 method public curTag ()Ljava/lang/String; - -
 method public curTag_$eq (Ljava/lang/String;)V - -
 method public capture ()Z - -
 method public capture_$eq (Z)V - -
 method public,abstract nodeContainsText (Ljava/lang/String;)Z - -
 method public,abstract createNode (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/immutable/List;)Lscala/xml/Node; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/immutable/List<Lscala/xml/Node;>;)Lscala/xml/Node; -
 method public,abstract createText (Ljava/lang/String;)Lscala/xml/Text; - -
 method public,abstract createProcInstr (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/ProcInstr;>; -
 method public normalizeWhitespace ()Z - -
 method public characters ([CII)V - -
 method public scala$xml$parsing$FactoryAdapter$$splitName (Ljava/lang/String;)Lscala/Tuple2; (Ljava/lang/String;)Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>; -
 method public startElement (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/xml/sax/Attributes;)V - -
 method public captureText ()V - -
 method public endElement (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public processingInstruction (Ljava/lang/String;Ljava/lang/String;)V - -
 method public <init> ()V - -
in 0
class scala/xml/parsing/FatalError 50 public,super java/lang/RuntimeException scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/parsing/FatalError;)Lscala/Option; (Lscala/xml/parsing/FatalError;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/parsing/FatalError; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/parsing/FatalError;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/parsing/FatalError;>; -
 method public msg ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/parsing/FatalError; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/parsing/FatalError$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/parsing/FatalError;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/parsing/FatalError$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/parsing/FatalError; - -
 method public unapply (Lscala/xml/parsing/FatalError;)Lscala/Option; (Lscala/xml/parsing/FatalError;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/parsing/MarkupHandler 50 public,super,abstract java/lang/Object - -
 method public isValidating ()Z - -
 method public decls ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/dtd/Decl;>; -
 method public decls_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/xml/dtd/Decl;>;)V -
 method public ent ()Lscala/collection/mutable/Map; ()Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/EntityDecl;>; -
 method public ent_$eq (Lscala/collection/mutable/Map;)V (Lscala/collection/mutable/Map<Ljava/lang/String;Lscala/xml/dtd/EntityDecl;>;)V -
 method public lookupElemDecl (Ljava/lang/String;)Lscala/xml/dtd/ElemDecl; - -
 method public replacementText (Ljava/lang/String;)Lscala/io/Source; - -
 method public endDTD (Ljava/lang/String;)V - -
 method public elemStart (ILjava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)V - -
 method public elemEnd (ILjava/lang/String;Ljava/lang/String;)V - -
 method public,abstract elem (ILjava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/xml/NodeSeq;)Lscala/xml/NodeSeq; - -
 method public,abstract procInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public,abstract comment (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public,abstract entityRef (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public,abstract text (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public elemDecl (Ljava/lang/String;Ljava/lang/String;)V - -
 method public attListDecl (Ljava/lang/String;Lscala/collection/immutable/List;)V (Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)V -
 method public parameterEntityDecl (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)V - -
 method public parsedEntityDecl (Ljava/lang/String;Lscala/xml/dtd/EntityDef;)V - -
 method public peReference (Ljava/lang/String;)V - -
 method public unparsedEntityDecl (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;)V - -
 method public notationDecl (Ljava/lang/String;Lscala/xml/dtd/ExternalID;)V - -
 method public,abstract reportSyntaxError (ILjava/lang/String;)V - -
 method public,deprecated log (Ljava/lang/String;)V - -
 method public <init> ()V - -
in 0
class scala/xml/parsing/MarkupParser 50 public,interface,abstract java/lang/Object scala/xml/parsing/MarkupParserCommon -
 inner scala/xml/parsing/MarkupParser$WithLookAhead scala/xml/parsing/MarkupParser WithLookAhead public
 method public,abstract scala$xml$parsing$MarkupParser$_setter_$scala$xml$parsing$MarkupParser$$handle_$eq (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,abstract scala$xml$parsing$MarkupParser$_setter_$cbuf_$eq (Lscala/collection/mutable/StringBuilder;)V - -
 method public,abstract truncatedError (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public,abstract errorNoEnd (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public,abstract xHandleError (CLjava/lang/String;)V - -
 method public,abstract input ()Lscala/io/Source; - -
 method public,abstract preserveWS ()Z - -
 method public,abstract externalSource (Ljava/lang/String;)Lscala/io/Source; - -
 method public,abstract curInput ()Lscala/io/Source; - -
 method public,abstract curInput_$eq (Lscala/io/Source;)V - -
 method public,abstract lookahead ()Lscala/collection/BufferedIterator; ()Lscala/collection/BufferedIterator<Ljava/lang/Object;>; -
 method public,abstract scala$xml$parsing$MarkupParser$$handle ()Lscala/xml/parsing/MarkupHandler; - -
 method public,abstract inpStack ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/io/Source;>; -
 method public,abstract inpStack_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/io/Source;>;)V -
 method public,abstract pos ()I - -
 method public,abstract pos_$eq (I)V - -
 method public,abstract extIndex ()I - -
 method public,abstract extIndex_$eq (I)V - -
 method public,abstract tmppos ()I - -
 method public,abstract tmppos_$eq (I)V - -
 method public,abstract nextChNeeded ()Z - -
 method public,abstract nextChNeeded_$eq (Z)V - -
 method public,abstract reachedEof ()Z - -
 method public,abstract reachedEof_$eq (Z)V - -
 method public,abstract lastChRead ()C - -
 method public,abstract lastChRead_$eq (C)V - -
 method public,abstract ch ()C - -
 method public,abstract cbuf ()Lscala/collection/mutable/StringBuilder; - -
 method public,abstract dtd ()Lscala/xml/dtd/DTD; - -
 method public,abstract dtd_$eq (Lscala/xml/dtd/DTD;)V - -
 method public,abstract doc ()Lscala/xml/Document; - -
 method public,abstract doc_$eq (Lscala/xml/Document;)V - -
 method public,abstract eof ()Z - -
 method public,abstract xmlProcInstr ()Lscala/xml/MetaData; - -
 method public,abstract prolog ()Lscala/Tuple3; ()Lscala/Tuple3<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/Object;>;>; -
 method public,abstract textDecl ()Lscala/Tuple2; ()Lscala/Tuple2<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;>; -
 method public,abstract document ()Lscala/xml/Document; - -
 method public,abstract putChar (C)Lscala/collection/mutable/StringBuilder; - -
 method public,abstract initialize ()Lscala/xml/parsing/MarkupHandler; - -
 method public,abstract ch_returning_nextch ()C - -
 method public,abstract mkAttributes (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public,abstract mkProcInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public,abstract nextch ()V - -
 method public,abstract xAttributes (Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public,abstract xEntityValue ()Ljava/lang/String; - -
 method public,abstract xCharData ()Lscala/xml/NodeSeq; - -
 method public,abstract xComment ()Lscala/xml/NodeSeq; - -
 method public,abstract appendText (ILscala/xml/NodeBuffer;Ljava/lang/String;)V - -
 method public,abstract content1 (Lscala/xml/NamespaceBinding;Lscala/xml/NodeBuffer;)V - -
 method public,abstract content (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public,abstract externalID ()Lscala/xml/dtd/ExternalID; - -
 method public,abstract parseDTD ()V - -
 method public,abstract element (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public,abstract element1 (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public,abstract systemLiteral ()Ljava/lang/String; - -
 method public,abstract pubidLiteral ()Ljava/lang/String; - -
 method public,abstract extSubset ()V - -
 method public,abstract markupDecl1 ()Ljava/lang/Object; - -
 method public,abstract markupDecl ()V - -
 method public,abstract intSubset ()V - -
 method public,abstract elementDecl ()V - -
 method public,abstract attrDecl ()V - -
 method public,abstract entityDecl ()V - -
 method public,abstract notationDecl ()V - -
 method public,abstract reportSyntaxError (ILjava/lang/String;)V - -
 method public,abstract reportSyntaxError (Ljava/lang/String;)V - -
 method public,abstract reportValidationError (ILjava/lang/String;)V - -
 method public,abstract push (Ljava/lang/String;)V - -
 method public,abstract pushExternal (Ljava/lang/String;)V - -
 method public,abstract pop ()V - -
in 0
class scala/xml/parsing/MarkupParser$WithLookAhead 50 public,super scala/io/Source - -
 inner scala/xml/parsing/MarkupParser$WithLookAhead scala/xml/parsing/MarkupParser WithLookAhead public
 field public,final scala$xml$parsing$MarkupParser$WithLookAhead$$underlying Lscala/io/Source; -
 method public scala$xml$parsing$MarkupParser$WithLookAhead$$queue ()Lscala/collection/mutable/Queue; ()Lscala/collection/mutable/Queue<Ljava/lang/Object;>; -
 method public lookahead ()Lscala/collection/BufferedIterator; ()Lscala/collection/BufferedIterator<Ljava/lang/Object;>; -
 method public iter ()Lscala/collection/Iterator; ()Ljava/lang/Object; -
 method public <init> (Lscala/xml/parsing/MarkupHandler;Lscala/io/Source;)V - -
in 0
class scala/xml/parsing/MarkupParser$class 50 public,super,abstract java/lang/Object - -
 inner scala/xml/Utility$Escapes$ scala/xml/Utility Escapes$ public,static
 inner scala/xml/parsing/MarkupParser$WithLookAhead scala/xml/parsing/MarkupParser WithLookAhead public
 method public,static truncatedError (Lscala/xml/parsing/MarkupHandler;Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public,static errorNoEnd (Lscala/xml/parsing/MarkupHandler;Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public,static xHandleError (Lscala/xml/parsing/MarkupHandler;CLjava/lang/String;)V - -
 method public,static lookahead (Lscala/xml/parsing/MarkupHandler;)Lscala/collection/BufferedIterator; - -
 method public,static ch (Lscala/xml/parsing/MarkupHandler;)C - -
 method public,static eof (Lscala/xml/parsing/MarkupHandler;)Z - -
 method public,static xmlProcInstr (Lscala/xml/parsing/MarkupHandler;)Lscala/xml/MetaData; - -
 method public,static prolog (Lscala/xml/parsing/MarkupHandler;)Lscala/Tuple3; - -
 method public,static textDecl (Lscala/xml/parsing/MarkupHandler;)Lscala/Tuple2; - -
 method public,static document (Lscala/xml/parsing/MarkupHandler;)Lscala/xml/Document; - -
 method public,static putChar (Lscala/xml/parsing/MarkupHandler;C)Lscala/collection/mutable/StringBuilder; - -
 method public,static initialize (Lscala/xml/parsing/MarkupHandler;)Lscala/xml/parsing/MarkupHandler; - -
 method public,static ch_returning_nextch (Lscala/xml/parsing/MarkupHandler;)C - -
 method public,static mkAttributes (Lscala/xml/parsing/MarkupHandler;Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2; - -
 method public,static mkProcInstr (Lscala/xml/parsing/MarkupHandler;ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public,static nextch (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static xAttributes (Lscala/xml/parsing/MarkupHandler;Lscala/xml/NamespaceBinding;)Lscala/Tuple2; - -
 method public,static xEntityValue (Lscala/xml/parsing/MarkupHandler;)Ljava/lang/String; - -
 method public,static xCharData (Lscala/xml/parsing/MarkupHandler;)Lscala/xml/NodeSeq; - -
 method public,static xComment (Lscala/xml/parsing/MarkupHandler;)Lscala/xml/NodeSeq; - -
 method public,static appendText (Lscala/xml/parsing/MarkupHandler;ILscala/xml/NodeBuffer;Ljava/lang/String;)V - -
 method public,static content1 (Lscala/xml/parsing/MarkupHandler;Lscala/xml/NamespaceBinding;Lscala/xml/NodeBuffer;)V - -
 method public,static content (Lscala/xml/parsing/MarkupHandler;Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public,static externalID (Lscala/xml/parsing/MarkupHandler;)Lscala/xml/dtd/ExternalID; - -
 method public,static parseDTD (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static element (Lscala/xml/parsing/MarkupHandler;Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public,static element1 (Lscala/xml/parsing/MarkupHandler;Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public,static systemLiteral (Lscala/xml/parsing/MarkupHandler;)Ljava/lang/String; - -
 method public,static pubidLiteral (Lscala/xml/parsing/MarkupHandler;)Ljava/lang/String; - -
 method public,static extSubset (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static markupDecl1 (Lscala/xml/parsing/MarkupHandler;)Ljava/lang/Object; - -
 method public,static markupDecl (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static intSubset (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static elementDecl (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static attrDecl (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static entityDecl (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static notationDecl (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static reportSyntaxError (Lscala/xml/parsing/MarkupHandler;ILjava/lang/String;)V - -
 method public,static reportSyntaxError (Lscala/xml/parsing/MarkupHandler;Ljava/lang/String;)V - -
 method public,static reportValidationError (Lscala/xml/parsing/MarkupHandler;ILjava/lang/String;)V - -
 method public,static push (Lscala/xml/parsing/MarkupHandler;Ljava/lang/String;)V - -
 method public,static pushExternal (Lscala/xml/parsing/MarkupHandler;Ljava/lang/String;)V - -
 method public,static pop (Lscala/xml/parsing/MarkupHandler;)V - -
 method public,static,final mkResult$1 (Lscala/xml/parsing/MarkupHandler;ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public,static $init$ (Lscala/xml/parsing/MarkupHandler;)V - -
in 0
class scala/xml/parsing/MarkupParserCommon 50 public,interface,abstract java/lang/Object scala/xml/parsing/TokenTests -
 method public,abstract unreachable ()Lscala/runtime/Nothing$; - -
 method public,abstract mkAttributes (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,abstract mkProcInstr (Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object; - -
 method public,abstract xTag (Ljava/lang/Object;)Lscala/Tuple2; (Ljava/lang/Object;)Lscala/Tuple2<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,abstract xProcInstr ()Ljava/lang/Object; - -
 method public,abstract xAttributeValue (C)Ljava/lang/String; - -
 method public,abstract xAttributeValue ()Ljava/lang/String; - -
 method public,abstract xEndTag (Ljava/lang/String;)V - -
 method public,abstract xName ()Ljava/lang/String; - -
 method public,abstract xCharRef (Lscala/Function0;Lscala/Function0;)Ljava/lang/String; (Lscala/Function0<Ljava/lang/Object;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Ljava/lang/String; -
 method public,abstract xCharRef (Lscala/collection/Iterator;)Ljava/lang/String; (Lscala/collection/Iterator<Ljava/lang/Object;>;)Ljava/lang/String; -
 method public,abstract xCharRef ()Ljava/lang/String; - -
 method public,abstract lookahead ()Lscala/collection/BufferedIterator; ()Lscala/collection/BufferedIterator<Ljava/lang/Object;>; -
 method public,abstract ch ()C - -
 method public,abstract nextch ()V - -
 method public,abstract ch_returning_nextch ()C - -
 method public,abstract eof ()Z - -
 method public,abstract tmppos ()Ljava/lang/Object; - -
 method public,abstract tmppos_$eq (Ljava/lang/Object;)V - -
 method public,abstract xHandleError (CLjava/lang/String;)V - -
 method public,abstract reportSyntaxError (Ljava/lang/String;)V - -
 method public,abstract reportSyntaxError (ILjava/lang/String;)V - -
 method public,abstract truncatedError (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public,abstract errorNoEnd (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public,abstract errorAndResult (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public,abstract xToken (C)V - -
 method public,abstract xToken (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
 method public,abstract xEQ ()V - -
 method public,abstract xSpaceOpt ()V - -
 method public,abstract xSpace ()V - -
 method public,abstract returning (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Lscala/Function1<TT;Lscala/runtime/BoxedUnit;>;)TT; -
 method public,abstract saving (Ljava/lang/Object;Lscala/Function1;Lscala/Function0;)Ljava/lang/Object; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(TA;Lscala/Function1<TA;Lscala/runtime/BoxedUnit;>;Lscala/Function0<TB;>;)TB; -
 method public,abstract xTakeUntil (Lscala/Function2;Lscala/Function0;Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Ljava/lang/String;TT;>;Lscala/Function0<Ljava/lang/Object;>;Ljava/lang/String;)TT; -
in 0
class scala/xml/parsing/MarkupParserCommon$class 50 public,super,abstract java/lang/Object - -
 inner scala/collection/immutable/Range$Inclusive scala/collection/immutable/Range Inclusive public,static
 method public,static unreachable (Lscala/xml/parsing/MarkupParserCommon;)Lscala/runtime/Nothing$; - -
 method public,static xTag (Lscala/xml/parsing/MarkupParserCommon;Ljava/lang/Object;)Lscala/Tuple2; - -
 method public,static xProcInstr (Lscala/xml/parsing/MarkupParserCommon;)Ljava/lang/Object; - -
 method public,static xAttributeValue (Lscala/xml/parsing/MarkupParserCommon;C)Ljava/lang/String; - -
 method public,static xAttributeValue (Lscala/xml/parsing/MarkupParserCommon;)Ljava/lang/String; - -
 method public,static xEndTag (Lscala/xml/parsing/MarkupParserCommon;Ljava/lang/String;)V - -
 method public,static xName (Lscala/xml/parsing/MarkupParserCommon;)Ljava/lang/String; - -
 method public,static xCharRef (Lscala/xml/parsing/MarkupParserCommon;Lscala/Function0;Lscala/Function0;)Ljava/lang/String; - -
 method public,static xCharRef (Lscala/xml/parsing/MarkupParserCommon;Lscala/collection/Iterator;)Ljava/lang/String; - -
 method public,static xCharRef (Lscala/xml/parsing/MarkupParserCommon;)Ljava/lang/String; - -
 method public,static errorAndResult (Lscala/xml/parsing/MarkupParserCommon;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; - -
 method public,static xToken (Lscala/xml/parsing/MarkupParserCommon;C)V - -
 method public,static xToken (Lscala/xml/parsing/MarkupParserCommon;Lscala/collection/Seq;)V - -
 method public,static xEQ (Lscala/xml/parsing/MarkupParserCommon;)V - -
 method public,static xSpaceOpt (Lscala/xml/parsing/MarkupParserCommon;)V - -
 method public,static xSpace (Lscala/xml/parsing/MarkupParserCommon;)V - -
 method public,static returning (Lscala/xml/parsing/MarkupParserCommon;Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; - -
 method public,static saving (Lscala/xml/parsing/MarkupParserCommon;Ljava/lang/Object;Lscala/Function1;Lscala/Function0;)Ljava/lang/Object; - -
 method public,static xTakeUntil (Lscala/xml/parsing/MarkupParserCommon;Lscala/Function2;Lscala/Function0;Ljava/lang/String;)Ljava/lang/Object; - -
 method public,static $init$ (Lscala/xml/parsing/MarkupParserCommon;)V - -
in 0
class scala/xml/parsing/NoBindingFactoryAdapter 50 public,super scala/xml/parsing/FactoryAdapter scala/xml/factory/NodeFactory Lscala/xml/parsing/FactoryAdapter;Lscala/xml/factory/NodeFactory<Lscala/xml/Elem;>;
 method public ignoreComments ()Z - -
 method public ignoreProcInstr ()Z - -
 method public cache ()Lscala/collection/mutable/HashMap; ()Lscala/collection/mutable/HashMap<Ljava/lang/Object;Lscala/collection/immutable/List<Lscala/xml/Elem;>;>; -
 method public scala$xml$factory$NodeFactory$_setter_$ignoreComments_$eq (Z)V - -
 method public scala$xml$factory$NodeFactory$_setter_$ignoreProcInstr_$eq (Z)V - -
 method public scala$xml$factory$NodeFactory$_setter_$cache_$eq (Lscala/collection/mutable/HashMap;)V - -
 method public construct (ILscala/collection/immutable/List;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; - -
 method public eqElements (Lscala/collection/Seq;Lscala/collection/Seq;)Z (Lscala/collection/Seq<Lscala/xml/Node;>;Lscala/collection/Seq<Lscala/xml/Node;>;)Z -
 method public nodeEquals (Lscala/xml/Node;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Z (Lscala/xml/Node;Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)Z -
 method public makeNode (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Node; - -
 method public makeText (Ljava/lang/String;)Lscala/xml/Text; - -
 method public makeComment (Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/Comment;>; -
 method public makeProcInstr (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/ProcInstr;>; -
 method public nodeContainsText (Ljava/lang/String;)Z - -
 method public create (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq;)Lscala/xml/Elem; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/xml/Elem; -
 method public createNode (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/immutable/List;)Lscala/xml/Elem; (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/collection/immutable/List<Lscala/xml/Node;>;)Lscala/xml/Elem; -
 method public createText (Ljava/lang/String;)Lscala/xml/Text; - -
 method public createProcInstr (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq; (Ljava/lang/String;Ljava/lang/String;)Lscala/collection/Seq<Lscala/xml/ProcInstr;>; -
 method public <init> ()V - -
in 0
class scala/xml/parsing/TokenTests 50 public,interface,abstract java/lang/Object - -
 method public,abstract isSpace (C)Z - -
 method public,abstract isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,abstract isAlpha (C)Z - -
 method public,abstract isAlphaDigit (C)Z - -
 method public,abstract isNameChar (C)Z - -
 method public,abstract isNameStart (C)Z - -
 method public,abstract isName (Ljava/lang/String;)Z - -
 method public,abstract isPubIDChar (C)Z - -
 method public,abstract isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public,abstract checkSysID (Ljava/lang/String;)Z - -
 method public,abstract checkPubID (Ljava/lang/String;)Z - -
in 0
class scala/xml/parsing/TokenTests$class 50 public,super,abstract java/lang/Object - -
 method public,static,final isSpace (Lscala/xml/parsing/TokenTests;C)Z - -
 method public,static,final isSpace (Lscala/xml/parsing/TokenTests;Lscala/collection/Seq;)Z - -
 method public,static isAlpha (Lscala/xml/parsing/TokenTests;C)Z - -
 method public,static isAlphaDigit (Lscala/xml/parsing/TokenTests;C)Z - -
 method public,static isNameChar (Lscala/xml/parsing/TokenTests;C)Z - -
 method public,static isNameStart (Lscala/xml/parsing/TokenTests;C)Z - -
 method public,static isName (Lscala/xml/parsing/TokenTests;Ljava/lang/String;)Z - -
 method public,static isPubIDChar (Lscala/xml/parsing/TokenTests;C)Z - -
 method public,static isValidIANAEncoding (Lscala/xml/parsing/TokenTests;Lscala/collection/Seq;)Z - -
 method public,static checkSysID (Lscala/xml/parsing/TokenTests;Ljava/lang/String;)Z - -
 method public,static checkPubID (Lscala/xml/parsing/TokenTests;Ljava/lang/String;)Z - -
 method public,static,final charOK$1 (Lscala/xml/parsing/TokenTests;C)Z - -
 method public,static $init$ (Lscala/xml/parsing/TokenTests;)V - -
in 0
class scala/xml/parsing/ValidatingMarkupHandler 50 public,super,abstract scala/xml/parsing/MarkupHandler - -
 inner scala/xml/dtd/ContentModel$ElemName scala/xml/dtd/ContentModel ElemName public,static
 method public rootLabel ()Ljava/lang/String; - -
 method public rootLabel_$eq (Ljava/lang/String;)V - -
 method public qStack ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Ljava/lang/Object;>; -
 method public qStack_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Ljava/lang/Object;>;)V -
 method public qCurrent ()I - -
 method public qCurrent_$eq (I)V - -
 method public declStack ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/xml/dtd/ElemDecl;>; -
 method public declStack_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/xml/dtd/ElemDecl;>;)V -
 method public declCurrent ()Lscala/xml/dtd/ElemDecl; - -
 method public declCurrent_$eq (Lscala/xml/dtd/ElemDecl;)V - -
 method public,final isValidating ()Z - -
 method public endDTD (Ljava/lang/String;)V - -
 method public elemStart (ILjava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)V - -
 method public elemEnd (ILjava/lang/String;Ljava/lang/String;)V - -
 method public,final elemDecl (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,final attListDecl (Ljava/lang/String;Lscala/collection/immutable/List;)V (Ljava/lang/String;Lscala/collection/immutable/List<Lscala/xml/dtd/AttrDecl;>;)V -
 method public,final unparsedEntityDecl (Ljava/lang/String;Lscala/xml/dtd/ExternalID;Ljava/lang/String;)V - -
 method public,final notationDecl (Ljava/lang/String;Lscala/xml/dtd/ExternalID;)V - -
 method public,final peReference (Ljava/lang/String;)V - -
 method public,abstract reportValidationError (ILjava/lang/String;)V - -
 method public <init> ()V - -
in 0
class scala/xml/parsing/XhtmlEntities 50 public,final,super java/lang/Object - -
 method public,static apply ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ParsedEntityDecl;>;>; -
 method public,static entities ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ParsedEntityDecl;>;>; -
 method public,static entMap ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public,static entList ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/Object;>;>; -
in 0
class scala/xml/parsing/XhtmlEntities$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/parsing/XhtmlEntities$; -
 method public,static <clinit> ()V - -
 method public entList ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/Object;>;>; -
 method public entMap ()Lscala/collection/immutable/Map; ()Lscala/collection/immutable/Map<Ljava/lang/String;Ljava/lang/Object;>; -
 method public entities ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ParsedEntityDecl;>;>; -
 method public apply ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/Tuple2<Ljava/lang/String;Lscala/xml/dtd/ParsedEntityDecl;>;>; -
in 0
class scala/xml/parsing/XhtmlParser 50 public,super scala/xml/parsing/ConstructingHandler scala/xml/parsing/MarkupParser,scala/xml/parsing/ExternalSources -
 method public,static apply (Lscala/io/Source;)Lscala/xml/NodeSeq; - -
 method public externalSource (Ljava/lang/String;)Lscala/io/Source; - -
 method public curInput ()Lscala/io/Source; - -
 method public curInput_$eq (Lscala/io/Source;)V - -
 method public scala$xml$parsing$MarkupParser$$handle ()Lscala/xml/parsing/MarkupHandler; - -
 method public inpStack ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/io/Source;>; -
 method public inpStack_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/io/Source;>;)V -
 method public pos ()I - -
 method public pos_$eq (I)V - -
 method public extIndex ()I - -
 method public extIndex_$eq (I)V - -
 method public tmppos ()I - -
 method public tmppos_$eq (I)V - -
 method public nextChNeeded ()Z - -
 method public nextChNeeded_$eq (Z)V - -
 method public reachedEof ()Z - -
 method public reachedEof_$eq (Z)V - -
 method public lastChRead ()C - -
 method public lastChRead_$eq (C)V - -
 method public cbuf ()Lscala/collection/mutable/StringBuilder; - -
 method public dtd ()Lscala/xml/dtd/DTD; - -
 method public dtd_$eq (Lscala/xml/dtd/DTD;)V - -
 method public doc ()Lscala/xml/Document; - -
 method public doc_$eq (Lscala/xml/Document;)V - -
 method public scala$xml$parsing$MarkupParser$_setter_$scala$xml$parsing$MarkupParser$$handle_$eq (Lscala/xml/parsing/MarkupHandler;)V - -
 method public scala$xml$parsing$MarkupParser$_setter_$cbuf_$eq (Lscala/collection/mutable/StringBuilder;)V - -
 method public truncatedError (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public errorNoEnd (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public xHandleError (CLjava/lang/String;)V - -
 method public lookahead ()Lscala/collection/BufferedIterator; ()Lscala/collection/BufferedIterator<Ljava/lang/Object;>; -
 method public ch ()C - -
 method public eof ()Z - -
 method public xmlProcInstr ()Lscala/xml/MetaData; - -
 method public prolog ()Lscala/Tuple3; ()Lscala/Tuple3<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/Object;>;>; -
 method public textDecl ()Lscala/Tuple2; ()Lscala/Tuple2<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;>; -
 method public document ()Lscala/xml/Document; - -
 method public putChar (C)Lscala/collection/mutable/StringBuilder; - -
 method public initialize ()Lscala/xml/parsing/MarkupHandler; - -
 method public ch_returning_nextch ()C - -
 method public mkAttributes (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public mkProcInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public nextch ()V - -
 method public xAttributes (Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public xEntityValue ()Ljava/lang/String; - -
 method public xCharData ()Lscala/xml/NodeSeq; - -
 method public xComment ()Lscala/xml/NodeSeq; - -
 method public appendText (ILscala/xml/NodeBuffer;Ljava/lang/String;)V - -
 method public content1 (Lscala/xml/NamespaceBinding;Lscala/xml/NodeBuffer;)V - -
 method public content (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public externalID ()Lscala/xml/dtd/ExternalID; - -
 method public parseDTD ()V - -
 method public element (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public element1 (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public systemLiteral ()Ljava/lang/String; - -
 method public pubidLiteral ()Ljava/lang/String; - -
 method public extSubset ()V - -
 method public markupDecl1 ()Ljava/lang/Object; - -
 method public markupDecl ()V - -
 method public intSubset ()V - -
 method public elementDecl ()V - -
 method public attrDecl ()V - -
 method public entityDecl ()V - -
 method public notationDecl ()V - -
 method public reportSyntaxError (ILjava/lang/String;)V - -
 method public reportSyntaxError (Ljava/lang/String;)V - -
 method public reportValidationError (ILjava/lang/String;)V - -
 method public push (Ljava/lang/String;)V - -
 method public pushExternal (Ljava/lang/String;)V - -
 method public pop ()V - -
 method public unreachable ()Lscala/runtime/Nothing$; - -
 method public xTag (Ljava/lang/Object;)Lscala/Tuple2; (Ljava/lang/Object;)Lscala/Tuple2<Ljava/lang/String;Ljava/lang/Object;>; -
 method public xProcInstr ()Ljava/lang/Object; - -
 method public xAttributeValue (C)Ljava/lang/String; - -
 method public xAttributeValue ()Ljava/lang/String; - -
 method public xEndTag (Ljava/lang/String;)V - -
 method public xName ()Ljava/lang/String; - -
 method public xCharRef (Lscala/Function0;Lscala/Function0;)Ljava/lang/String; (Lscala/Function0<Ljava/lang/Object;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Ljava/lang/String; -
 method public xCharRef (Lscala/collection/Iterator;)Ljava/lang/String; (Lscala/collection/Iterator<Ljava/lang/Object;>;)Ljava/lang/String; -
 method public xCharRef ()Ljava/lang/String; - -
 method public errorAndResult (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public xToken (C)V - -
 method public xToken (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
 method public xEQ ()V - -
 method public xSpaceOpt ()V - -
 method public xSpace ()V - -
 method public returning (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Lscala/Function1<TT;Lscala/runtime/BoxedUnit;>;)TT; -
 method public saving (Ljava/lang/Object;Lscala/Function1;Lscala/Function0;)Ljava/lang/Object; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(TA;Lscala/Function1<TA;Lscala/runtime/BoxedUnit;>;Lscala/Function0<TB;>;)TB; -
 method public xTakeUntil (Lscala/Function2;Lscala/Function0;Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Ljava/lang/String;TT;>;Lscala/Function0<Ljava/lang/Object;>;Ljava/lang/String;)TT; -
 method public,final isSpace (C)Z - -
 method public,final isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public isAlpha (C)Z - -
 method public isAlphaDigit (C)Z - -
 method public isNameChar (C)Z - -
 method public isNameStart (C)Z - -
 method public isName (Ljava/lang/String;)Z - -
 method public isPubIDChar (C)Z - -
 method public isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public checkSysID (Ljava/lang/String;)Z - -
 method public checkPubID (Ljava/lang/String;)Z - -
 method public input ()Lscala/io/Source; - -
 method public preserveWS ()Z - -
 method public <init> (Lscala/io/Source;)V - -
in 0
class scala/xml/parsing/XhtmlParser$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/parsing/XhtmlParser$; -
 method public,static <clinit> ()V - -
 method public apply (Lscala/io/Source;)Lscala/xml/NodeSeq; - -
in 0
class scala/xml/persistent/CachedFileStorage 50 public,super,abstract java/lang/Thread - -
 inner scala/Enumeration$Value scala/Enumeration Value public,abstract
 method public dirty ()Z - -
 method public dirty_$eq (Z)V - -
 method public interval ()I - -
 method public initialNodes ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/Node;>; -
 method public,abstract nodes ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/Node;>; -
 method public,abstract $plus$eq (Lscala/xml/Node;)V - -
 method public,abstract $minus$eq (Lscala/xml/Node;)V - -
 method public run ()V - -
 method public flush ()V - -
 method public,deprecated log (Ljava/lang/String;)V - -
 method public <init> (Ljava/io/File;)V - -
in 0
class scala/xml/persistent/Index 50 public,super,abstract java/lang/Object scala/Function1 <A:Ljava/lang/Object;>Ljava/lang/Object;Lscala/Function1<Lscala/xml/Node;TA;>;
 method public apply$mcZD$sp (D)Z - -
 method public apply$mcDD$sp (D)D - -
 method public apply$mcFD$sp (D)F - -
 method public apply$mcID$sp (D)I - -
 method public apply$mcJD$sp (D)J - -
 method public apply$mcVD$sp (D)V - -
 method public apply$mcZF$sp (F)Z - -
 method public apply$mcDF$sp (F)D - -
 method public apply$mcFF$sp (F)F - -
 method public apply$mcIF$sp (F)I - -
 method public apply$mcJF$sp (F)J - -
 method public apply$mcVF$sp (F)V - -
 method public apply$mcZI$sp (I)Z - -
 method public apply$mcDI$sp (I)D - -
 method public apply$mcFI$sp (I)F - -
 method public apply$mcII$sp (I)I - -
 method public apply$mcJI$sp (I)J - -
 method public apply$mcVI$sp (I)V - -
 method public apply$mcZJ$sp (J)Z - -
 method public apply$mcDJ$sp (J)D - -
 method public apply$mcFJ$sp (J)F - -
 method public apply$mcIJ$sp (J)I - -
 method public apply$mcJJ$sp (J)J - -
 method public apply$mcVJ$sp (J)V - -
 method public compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/xml/Node;>;)Lscala/Function1<TA;TA;>; -
 method public andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;TA;>;)Lscala/Function1<Lscala/xml/Node;TA;>; -
 method public toString ()Ljava/lang/String; - -
 method public <init> ()V ()V -
in 0
class scala/xml/persistent/SetStorage 50 public,super scala/xml/persistent/CachedFileStorage - -
 method public $plus$eq (Lscala/xml/Node;)V - -
 method public $minus$eq (Lscala/xml/Node;)V - -
 method public,synchronized nodes ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Lscala/xml/Node;>; -
 method public <init> (Ljava/io/File;)V - -
in 0
class scala/xml/pull/EvComment 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/pull/EvComment;)Lscala/Option; (Lscala/xml/pull/EvComment;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/pull/EvComment; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/pull/EvComment;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/pull/EvComment;>; -
 method public text ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/pull/EvComment; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/pull/EvComment$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/pull/EvComment;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/pull/EvComment$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/pull/EvComment; - -
 method public unapply (Lscala/xml/pull/EvComment;)Lscala/Option; (Lscala/xml/pull/EvComment;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/pull/EvElemEnd 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/pull/EvElemEnd;)Lscala/Option; (Lscala/xml/pull/EvElemEnd;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static apply (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/pull/EvElemEnd; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;Lscala/xml/pull/EvElemEnd;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Lscala/xml/pull/EvElemEnd;>;>; -
 method public pre ()Ljava/lang/String; - -
 method public label ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/pull/EvElemEnd; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 0
class scala/xml/pull/EvElemEnd$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Ljava/lang/String;Lscala/xml/pull/EvElemEnd;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/pull/EvElemEnd$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/pull/EvElemEnd; - -
 method public unapply (Lscala/xml/pull/EvElemEnd;)Lscala/Option; (Lscala/xml/pull/EvElemEnd;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
in 0
class scala/xml/pull/EvElemStart 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/pull/EvElemStart;)Lscala/Option; (Lscala/xml/pull/EvElemStart;)Lscala/Option<Lscala/Tuple4<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>;>; -
 method public,static apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/pull/EvElemStart; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple4<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>;Lscala/xml/pull/EvElemStart;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Lscala/Function1<Lscala/xml/MetaData;Lscala/Function1<Lscala/xml/NamespaceBinding;Lscala/xml/pull/EvElemStart;>;>;>;>; -
 method public pre ()Ljava/lang/String; - -
 method public label ()Ljava/lang/String; - -
 method public attrs ()Lscala/xml/MetaData; - -
 method public scope ()Lscala/xml/NamespaceBinding; - -
 method public copy (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/pull/EvElemStart; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public copy$default$3 ()Lscala/xml/MetaData; - -
 method public copy$default$4 ()Lscala/xml/NamespaceBinding; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)V - -
in 0
class scala/xml/pull/EvElemStart$ 50 public,final,super scala/runtime/AbstractFunction4 scala/Serializable Lscala/runtime/AbstractFunction4<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;Lscala/xml/pull/EvElemStart;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/pull/EvElemStart$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)Lscala/xml/pull/EvElemStart; - -
 method public unapply (Lscala/xml/pull/EvElemStart;)Lscala/Option; (Lscala/xml/pull/EvElemStart;)Lscala/Option<Lscala/Tuple4<Ljava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>;>; -
in 0
class scala/xml/pull/EvEntityRef 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/pull/EvEntityRef;)Lscala/Option; (Lscala/xml/pull/EvEntityRef;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/pull/EvEntityRef; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/pull/EvEntityRef;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/pull/EvEntityRef;>; -
 method public entity ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/pull/EvEntityRef; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/pull/EvEntityRef$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/pull/EvEntityRef;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/pull/EvEntityRef$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/pull/EvEntityRef; - -
 method public unapply (Lscala/xml/pull/EvEntityRef;)Lscala/Option; (Lscala/xml/pull/EvEntityRef;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/pull/EvProcInstr 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/pull/EvProcInstr;)Lscala/Option; (Lscala/xml/pull/EvProcInstr;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
 method public,static apply (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/pull/EvProcInstr; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;Lscala/xml/pull/EvProcInstr;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/String;Lscala/Function1<Ljava/lang/String;Lscala/xml/pull/EvProcInstr;>;>; -
 method public target ()Ljava/lang/String; - -
 method public text ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/pull/EvProcInstr; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public copy$default$2 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
in 0
class scala/xml/pull/EvProcInstr$ 50 public,final,super scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/String;Ljava/lang/String;Lscala/xml/pull/EvProcInstr;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/pull/EvProcInstr$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;Ljava/lang/String;)Lscala/xml/pull/EvProcInstr; - -
 method public unapply (Lscala/xml/pull/EvProcInstr;)Lscala/Option; (Lscala/xml/pull/EvProcInstr;)Lscala/Option<Lscala/Tuple2<Ljava/lang/String;Ljava/lang/String;>;>; -
in 0
class scala/xml/pull/EvText 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/pull/EvText;)Lscala/Option; (Lscala/xml/pull/EvText;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/xml/pull/EvText; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/pull/EvText;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/xml/pull/EvText;>; -
 method public text ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/xml/pull/EvText; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/xml/pull/EvText$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/xml/pull/EvText;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/pull/EvText$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/xml/pull/EvText; - -
 method public unapply (Lscala/xml/pull/EvText;)Lscala/Option; (Lscala/xml/pull/EvText;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/xml/pull/ExceptionEvent 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 method public,static unapply (Lscala/xml/pull/ExceptionEvent;)Lscala/Option; (Lscala/xml/pull/ExceptionEvent;)Lscala/Option<Ljava/lang/Exception;>; -
 method public,static apply (Ljava/lang/Exception;)Lscala/xml/pull/ExceptionEvent; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/pull/ExceptionEvent;TA;>;)Lscala/Function1<Ljava/lang/Exception;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/Exception;>;)Lscala/Function1<TA;Lscala/xml/pull/ExceptionEvent;>; -
 method public exception ()Ljava/lang/Exception; - -
 method public copy (Ljava/lang/Exception;)Lscala/xml/pull/ExceptionEvent; - -
 method public copy$default$1 ()Ljava/lang/Exception; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/Exception;)V - -
in 0
class scala/xml/pull/ExceptionEvent$ 50 public,final,super scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/Exception;Lscala/xml/pull/ExceptionEvent;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/xml/pull/ExceptionEvent$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/Exception;)Lscala/xml/pull/ExceptionEvent; - -
 method public unapply (Lscala/xml/pull/ExceptionEvent;)Lscala/Option; (Lscala/xml/pull/ExceptionEvent;)Lscala/Option<Ljava/lang/Exception;>; -
in 0
class scala/xml/pull/ProducerConsumerIterator 50 public,interface,abstract java/lang/Object scala/collection/Iterator <T:Ljava/lang/Object;>Ljava/lang/Object;Lscala/collection/Iterator<TT;>;
 method public,abstract scala$xml$pull$ProducerConsumerIterator$_setter_$MaxQueueSize_$eq (I)V - -
 method public,abstract scala$xml$pull$ProducerConsumerIterator$$buffer ()Ljava/lang/Object; - -
 method public,abstract scala$xml$pull$ProducerConsumerIterator$$buffer_$eq (Ljava/lang/Object;)V - -
 method public,abstract EndOfStream ()Ljava/lang/Object; ()TT; -
 method public,abstract MaxQueueSize ()I - -
 method public,abstract interruptibly (Lscala/Function0;)Lscala/Option; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)Lscala/Option<TT;>; -
 method public,abstract scala$xml$pull$ProducerConsumerIterator$$queue ()Ljava/util/concurrent/LinkedBlockingQueue; ()Ljava/util/concurrent/LinkedBlockingQueue<TT;>; -
 method public,abstract produce (Ljava/lang/Object;)V (TT;)V -
 method public,abstract hasNext ()Z - -
 method public,abstract next ()Ljava/lang/Object; ()TT; -
 method public,abstract available ()Z - -
in 0
class scala/xml/pull/ProducerConsumerIterator$class 50 public,super,abstract java/lang/Object - -
 method public,static interruptibly (Lscala/xml/pull/ProducerConsumerIterator;Lscala/Function0;)Lscala/Option; - -
 method public,static scala$xml$pull$ProducerConsumerIterator$$queue (Lscala/xml/pull/ProducerConsumerIterator;)Ljava/util/concurrent/LinkedBlockingQueue; - -
 method public,static produce (Lscala/xml/pull/ProducerConsumerIterator;Ljava/lang/Object;)V - -
 method public,static hasNext (Lscala/xml/pull/ProducerConsumerIterator;)Z - -
 method public,static next (Lscala/xml/pull/ProducerConsumerIterator;)Ljava/lang/Object; - -
 method public,static available (Lscala/xml/pull/ProducerConsumerIterator;)Z - -
 method public,static $init$ (Lscala/xml/pull/ProducerConsumerIterator;)V - -
in 0
class scala/xml/pull/XMLEvent 50 public,interface,abstract java/lang/Object - -
in 0
class scala/xml/pull/XMLEventReader 50 public,super scala/collection/AbstractIterator scala/xml/pull/ProducerConsumerIterator Lscala/collection/AbstractIterator<Lscala/xml/pull/XMLEvent;>;Lscala/xml/pull/ProducerConsumerIterator<Lscala/xml/pull/XMLEvent;>;
 inner scala/xml/pull/XMLEventReader$POISON$ scala/xml/pull/XMLEventReader POISON$ public
 inner scala/xml/pull/XMLEventReader$Parser scala/xml/pull/XMLEventReader Parser public
 method public scala$xml$pull$ProducerConsumerIterator$$queue ()Ljava/util/concurrent/LinkedBlockingQueue; ()Ljava/util/concurrent/LinkedBlockingQueue<Lscala/xml/pull/XMLEvent;>; -
 method public scala$xml$pull$ProducerConsumerIterator$_setter_$MaxQueueSize_$eq (I)V - -
 method public scala$xml$pull$ProducerConsumerIterator$$buffer ()Ljava/lang/Object; - -
 method public scala$xml$pull$ProducerConsumerIterator$$buffer_$eq (Ljava/lang/Object;)V - -
 method public interruptibly (Lscala/Function0;)Lscala/Option; <T:Ljava/lang/Object;>(Lscala/Function0<TT;>;)Lscala/Option<TT;>; -
 method public produce (Ljava/lang/Object;)V - -
 method public hasNext ()Z - -
 method public next ()Ljava/lang/Object; - -
 method public available ()Z - -
 method public preserveWS ()Z - -
 method public MaxQueueSize ()I - -
 method public POISON ()Lscala/xml/pull/XMLEventReader$POISON$; - -
 method public EndOfStream ()Lscala/xml/pull/XMLEventReader$POISON$; - -
 method public stop ()V - -
 method public <init> (Lscala/io/Source;)V - -
in 0
class scala/xml/pull/XMLEventReader$POISON$ 50 public,super java/lang/Object scala/xml/pull/XMLEvent,scala/Product,scala/Serializable -
 inner scala/xml/pull/XMLEventReader$POISON$ scala/xml/pull/XMLEventReader POISON$ public
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public <init> (Lscala/xml/pull/XMLEventReader;)V - -
in 0
class scala/xml/pull/XMLEventReader$Parser 50 public,super scala/xml/parsing/MarkupHandler scala/xml/parsing/MarkupParser,scala/xml/parsing/ExternalSources,java/lang/Runnable -
 inner scala/xml/pull/XMLEventReader$Parser scala/xml/pull/XMLEventReader Parser public
 inner scala/xml/pull/XMLEventReader$POISON$ scala/xml/pull/XMLEventReader POISON$ public
 method public externalSource (Ljava/lang/String;)Lscala/io/Source; - -
 method public curInput ()Lscala/io/Source; - -
 method public curInput_$eq (Lscala/io/Source;)V - -
 method public scala$xml$parsing$MarkupParser$$handle ()Lscala/xml/parsing/MarkupHandler; - -
 method public inpStack ()Lscala/collection/immutable/List; ()Lscala/collection/immutable/List<Lscala/io/Source;>; -
 method public inpStack_$eq (Lscala/collection/immutable/List;)V (Lscala/collection/immutable/List<Lscala/io/Source;>;)V -
 method public pos ()I - -
 method public pos_$eq (I)V - -
 method public extIndex ()I - -
 method public extIndex_$eq (I)V - -
 method public tmppos ()I - -
 method public tmppos_$eq (I)V - -
 method public nextChNeeded ()Z - -
 method public nextChNeeded_$eq (Z)V - -
 method public reachedEof ()Z - -
 method public reachedEof_$eq (Z)V - -
 method public lastChRead ()C - -
 method public lastChRead_$eq (C)V - -
 method public cbuf ()Lscala/collection/mutable/StringBuilder; - -
 method public dtd ()Lscala/xml/dtd/DTD; - -
 method public dtd_$eq (Lscala/xml/dtd/DTD;)V - -
 method public doc ()Lscala/xml/Document; - -
 method public doc_$eq (Lscala/xml/Document;)V - -
 method public scala$xml$parsing$MarkupParser$_setter_$scala$xml$parsing$MarkupParser$$handle_$eq (Lscala/xml/parsing/MarkupHandler;)V - -
 method public scala$xml$parsing$MarkupParser$_setter_$cbuf_$eq (Lscala/collection/mutable/StringBuilder;)V - -
 method public truncatedError (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public errorNoEnd (Ljava/lang/String;)Lscala/runtime/Nothing$; - -
 method public xHandleError (CLjava/lang/String;)V - -
 method public lookahead ()Lscala/collection/BufferedIterator; ()Lscala/collection/BufferedIterator<Ljava/lang/Object;>; -
 method public ch ()C - -
 method public eof ()Z - -
 method public xmlProcInstr ()Lscala/xml/MetaData; - -
 method public prolog ()Lscala/Tuple3; ()Lscala/Tuple3<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/Object;>;>; -
 method public textDecl ()Lscala/Tuple2; ()Lscala/Tuple2<Lscala/Option<Ljava/lang/String;>;Lscala/Option<Ljava/lang/String;>;>; -
 method public document ()Lscala/xml/Document; - -
 method public putChar (C)Lscala/collection/mutable/StringBuilder; - -
 method public initialize ()Lscala/xml/parsing/MarkupHandler; - -
 method public ch_returning_nextch ()C - -
 method public mkAttributes (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Ljava/lang/String;Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public mkProcInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public nextch ()V - -
 method public xAttributes (Lscala/xml/NamespaceBinding;)Lscala/Tuple2; (Lscala/xml/NamespaceBinding;)Lscala/Tuple2<Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;>; -
 method public xEntityValue ()Ljava/lang/String; - -
 method public xCharData ()Lscala/xml/NodeSeq; - -
 method public xComment ()Lscala/xml/NodeSeq; - -
 method public appendText (ILscala/xml/NodeBuffer;Ljava/lang/String;)V - -
 method public content1 (Lscala/xml/NamespaceBinding;Lscala/xml/NodeBuffer;)V - -
 method public content (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public externalID ()Lscala/xml/dtd/ExternalID; - -
 method public parseDTD ()V - -
 method public element (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public element1 (Lscala/xml/NamespaceBinding;)Lscala/xml/NodeSeq; - -
 method public systemLiteral ()Ljava/lang/String; - -
 method public pubidLiteral ()Ljava/lang/String; - -
 method public extSubset ()V - -
 method public markupDecl1 ()Ljava/lang/Object; - -
 method public markupDecl ()V - -
 method public intSubset ()V - -
 method public elementDecl ()V - -
 method public attrDecl ()V - -
 method public entityDecl ()V - -
 method public notationDecl ()V - -
 method public reportSyntaxError (ILjava/lang/String;)V - -
 method public reportSyntaxError (Ljava/lang/String;)V - -
 method public reportValidationError (ILjava/lang/String;)V - -
 method public push (Ljava/lang/String;)V - -
 method public pushExternal (Ljava/lang/String;)V - -
 method public pop ()V - -
 method public unreachable ()Lscala/runtime/Nothing$; - -
 method public xTag (Ljava/lang/Object;)Lscala/Tuple2; (Ljava/lang/Object;)Lscala/Tuple2<Ljava/lang/String;Ljava/lang/Object;>; -
 method public xProcInstr ()Ljava/lang/Object; - -
 method public xAttributeValue (C)Ljava/lang/String; - -
 method public xAttributeValue ()Ljava/lang/String; - -
 method public xEndTag (Ljava/lang/String;)V - -
 method public xName ()Ljava/lang/String; - -
 method public xCharRef (Lscala/Function0;Lscala/Function0;)Ljava/lang/String; (Lscala/Function0<Ljava/lang/Object;>;Lscala/Function0<Lscala/runtime/BoxedUnit;>;)Ljava/lang/String; -
 method public xCharRef (Lscala/collection/Iterator;)Ljava/lang/String; (Lscala/collection/Iterator<Ljava/lang/Object;>;)Ljava/lang/String; -
 method public xCharRef ()Ljava/lang/String; - -
 method public errorAndResult (Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Ljava/lang/String;TT;)TT; -
 method public xToken (C)V - -
 method public xToken (Lscala/collection/Seq;)V (Lscala/collection/Seq<Ljava/lang/Object;>;)V -
 method public xEQ ()V - -
 method public xSpaceOpt ()V - -
 method public xSpace ()V - -
 method public returning (Ljava/lang/Object;Lscala/Function1;)Ljava/lang/Object; <T:Ljava/lang/Object;>(TT;Lscala/Function1<TT;Lscala/runtime/BoxedUnit;>;)TT; -
 method public saving (Ljava/lang/Object;Lscala/Function1;Lscala/Function0;)Ljava/lang/Object; <A:Ljava/lang/Object;B:Ljava/lang/Object;>(TA;Lscala/Function1<TA;Lscala/runtime/BoxedUnit;>;Lscala/Function0<TB;>;)TB; -
 method public xTakeUntil (Lscala/Function2;Lscala/Function0;Ljava/lang/String;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lscala/Function2<Ljava/lang/Object;Ljava/lang/String;TT;>;Lscala/Function0<Ljava/lang/Object;>;Ljava/lang/String;)TT; -
 method public,final isSpace (C)Z - -
 method public,final isSpace (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public isAlpha (C)Z - -
 method public isAlphaDigit (C)Z - -
 method public isNameChar (C)Z - -
 method public isNameStart (C)Z - -
 method public isName (Ljava/lang/String;)Z - -
 method public isPubIDChar (C)Z - -
 method public isValidIANAEncoding (Lscala/collection/Seq;)Z (Lscala/collection/Seq<Ljava/lang/Object;>;)Z -
 method public checkSysID (Ljava/lang/String;)Z - -
 method public checkPubID (Ljava/lang/String;)Z - -
 method public input ()Lscala/io/Source; - -
 method public preserveWS ()Z - -
 method public setEvent (Lscala/collection/Seq;)Lscala/xml/NodeSeq; (Lscala/collection/Seq<Lscala/xml/pull/XMLEvent;>;)Lscala/xml/NodeSeq; -
 method public elemStart (ILjava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;)V - -
 method public elemEnd (ILjava/lang/String;Ljava/lang/String;)V - -
 method public,final elem (ILjava/lang/String;Ljava/lang/String;Lscala/xml/MetaData;Lscala/xml/NamespaceBinding;ZLscala/xml/NodeSeq;)Lscala/xml/NodeSeq; - -
 method public procInstr (ILjava/lang/String;Ljava/lang/String;)Lscala/xml/NodeSeq; - -
 method public comment (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public entityRef (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public text (ILjava/lang/String;)Lscala/xml/NodeSeq; - -
 method public run ()V - -
 method public <init> (Lscala/xml/pull/XMLEventReader;Lscala/io/Source;)V - -
in 0
class scala/xml/pull/package 50 public,final,super java/lang/Object - -
in 0
class scala/xml/pull/package$ 50 public,final,super java/lang/Object - -
 field public,static,final MODULE$ Lscala/xml/pull/package$; -
 method public,static <clinit> ()V - -
in 0
class scala/xml/transform/BasicTransformer 50 public,super,abstract java/lang/Object scala/Function1 Ljava/lang/Object;Lscala/Function1<Lscala/xml/Node;Lscala/xml/Node;>;
 method public apply$mcZD$sp (D)Z - -
 method public apply$mcDD$sp (D)D - -
 method public apply$mcFD$sp (D)F - -
 method public apply$mcID$sp (D)I - -
 method public apply$mcJD$sp (D)J - -
 method public apply$mcVD$sp (D)V - -
 method public apply$mcZF$sp (F)Z - -
 method public apply$mcDF$sp (F)D - -
 method public apply$mcFF$sp (F)F - -
 method public apply$mcIF$sp (F)I - -
 method public apply$mcJF$sp (F)J - -
 method public apply$mcVF$sp (F)V - -
 method public apply$mcZI$sp (I)Z - -
 method public apply$mcDI$sp (I)D - -
 method public apply$mcFI$sp (I)F - -
 method public apply$mcII$sp (I)I - -
 method public apply$mcJI$sp (I)J - -
 method public apply$mcVI$sp (I)V - -
 method public apply$mcZJ$sp (J)Z - -
 method public apply$mcDJ$sp (J)D - -
 method public apply$mcFJ$sp (J)F - -
 method public apply$mcIJ$sp (J)I - -
 method public apply$mcJJ$sp (J)J - -
 method public apply$mcVJ$sp (J)V - -
 method public compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/xml/Node;>;)Lscala/Function1<TA;Lscala/xml/Node;>; -
 method public andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/xml/Node;TA;>;)Lscala/Function1<Lscala/xml/Node;TA;>; -
 method public toString ()Ljava/lang/String; - -
 method public unchanged (Lscala/xml/Node;Lscala/collection/Seq;)Z (Lscala/xml/Node;Lscala/collection/Seq<Lscala/xml/Node;>;)Z -
 method public transform (Lscala/collection/Iterator;Lscala/xml/NodeBuffer;)Lscala/collection/Seq; (Lscala/collection/Iterator<Lscala/xml/Node;>;Lscala/xml/NodeBuffer;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public transform (Lscala/collection/Seq;)Lscala/collection/Seq; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public transform (Lscala/xml/Node;)Lscala/collection/Seq; (Lscala/xml/Node;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public apply (Lscala/xml/Node;)Lscala/xml/Node; - -
 method public <init> ()V - -
in 0
class scala/xml/transform/RewriteRule 50 public,super,abstract scala/xml/transform/BasicTransformer - -
 method public name ()Ljava/lang/String; - -
 method public transform (Lscala/collection/Seq;)Lscala/collection/Seq; (Lscala/collection/Seq<Lscala/xml/Node;>;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public transform (Lscala/xml/Node;)Lscala/collection/Seq; (Lscala/xml/Node;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public <init> ()V - -
in 0
class scala/xml/transform/RuleTransformer 50 public,super scala/xml/transform/BasicTransformer - -
 method public transform (Lscala/xml/Node;)Lscala/collection/Seq; (Lscala/xml/Node;)Lscala/collection/Seq<Lscala/xml/Node;>; -
 method public <init> (Lscala/collection/Seq;)V (Lscala/collection/Seq<Lscala/xml/transform/RewriteRule;>;)V -
