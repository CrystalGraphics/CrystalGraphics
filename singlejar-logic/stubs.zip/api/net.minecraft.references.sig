cg-stub-db 1
in 116
class net/minecraft/references/Blocks 61 public,super java/lang/Object - -
 field public,static,final PUMPKIN Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final PUMPKIN_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ATTACHED_PUMPKIN_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final MELON Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final MELON_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ATTACHED_MELON_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 method public <init> ()V - -
in 60
class net/minecraft/references/Blocks 65 public,super java/lang/Object - -
 field public,static,final PUMPKIN Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final PUMPKIN_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ATTACHED_PUMPKIN_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final MELON Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final MELON_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 field public,static,final ATTACHED_MELON_STEM Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/block/Block;>;
 method public <init> ()V - -
in 116
class net/minecraft/references/Items 61 public,super java/lang/Object - -
 field public,static,final PUMPKIN_SEEDS Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/Item;>;
 field public,static,final MELON_SEEDS Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/Item;>;
 method public <init> ()V - -
in 60
class net/minecraft/references/Items 65 public,super java/lang/Object - -
 field public,static,final PUMPKIN_SEEDS Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/Item;>;
 field public,static,final MELON_SEEDS Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/item/Item;>;
 method public <init> ()V - -
