cg-stub-db 1
in 24
class net/java/games/input/AWTEnvironmentPlugin 48 public,super net/java/games/input/ControllerEnvironment net/java/games/util/plugins/Plugin -
 method public <init> ()V - -
 method public getControllers ()[Lnet/java/games/input/Controller; - -
 method public isSupported ()Z - -
in 24
class net/java/games/input/AWTKeyMap 48 final,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 method public,static,final mapKeyCode (I)Lnet/java/games/input/Component$Identifier$Key; - -
 method public,static,final map (Ljava/awt/event/KeyEvent;)Lnet/java/games/input/Component$Identifier$Key; - -
in 24
class net/java/games/input/AWTKeyboard 48 final,super net/java/games/input/Keyboard java/awt/event/AWTEventListener -
 inner net/java/games/input/AWTKeyboard$Key net/java/games/input/AWTKeyboard Key private,static,final
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 method protected <init> ()V - -
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
 method public,final,synchronized eventDispatched (Ljava/awt/AWTEvent;)V - -
 method public,final,synchronized pollDevice ()V - java/io/IOException
 method protected,final,synchronized getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
in 24
class net/java/games/input/AWTKeyboard$Key 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 inner net/java/games/input/AWTKeyboard$Key net/java/games/input/AWTKeyboard Key private,static,final
 method public <init> (Lnet/java/games/input/Component$Identifier$Key;)V - -
 method public,final setValue (F)V - -
 method protected,final poll ()F - -
 method public,final isAnalog ()Z - -
 method public,final isRelative ()Z - -
in 24
class net/java/games/input/AWTMouse 48 final,super net/java/games/input/Mouse java/awt/event/AWTEventListener -
 inner net/java/games/input/AWTMouse$Button net/java/games/input/AWTMouse Button static,final
 inner net/java/games/input/AWTMouse$Axis net/java/games/input/AWTMouse Axis static,final
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 method protected <init> ()V - -
 method public,final,synchronized pollDevice ()V - java/io/IOException
 method protected,final,synchronized getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public,final,synchronized eventDispatched (Ljava/awt/AWTEvent;)V - -
in 24
class net/java/games/input/AWTMouse$Axis 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 inner net/java/games/input/AWTMouse$Axis net/java/games/input/AWTMouse Axis static,final
 method public <init> (Lnet/java/games/input/Component$Identifier$Axis;)V - -
 method public,final isRelative ()Z - -
 method public,final isAnalog ()Z - -
 method protected,final setValue (F)V - -
 method protected,final poll ()F - java/io/IOException
in 24
class net/java/games/input/AWTMouse$Button 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/AWTMouse$Button net/java/games/input/AWTMouse Button static,final
 method public <init> (Lnet/java/games/input/Component$Identifier$Button;)V - -
 method protected,final setValue (F)V - -
 method protected,final poll ()F - java/io/IOException
 method public,final isAnalog ()Z - -
 method public,final isRelative ()Z - -
in 24
class net/java/games/input/AbstractComponent 48 public,super,abstract java/lang/Object net/java/games/input/Component -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method protected <init> (Ljava/lang/String;Lnet/java/games/input/Component$Identifier;)V - -
 method public getIdentifier ()Lnet/java/games/input/Component$Identifier; - -
 method public isAnalog ()Z - -
 method public getDeadZone ()F - -
 method public,final getPollData ()F - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method protected,abstract poll ()F - java/io/IOException
in 24
class net/java/games/input/AbstractController 48 public,super,abstract java/lang/Object net/java/games/input/Controller -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method protected <init> (Ljava/lang/String;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method public,final getControllers ()[Lnet/java/games/input/Controller; - -
 method public,final getComponents ()[Lnet/java/games/input/Component; - -
 method public,final getComponent (Lnet/java/games/input/Component$Identifier;)Lnet/java/games/input/Component; - -
 method public,final getRumblers ()[Lnet/java/games/input/Rumbler; - -
 method public getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method public getPortNumber ()I - -
 method public,final getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public getType ()Lnet/java/games/input/Controller$Type; - -
 method public,final setEventQueueSize (I)V - -
 method protected setDeviceEventQueueSize (I)V - java/io/IOException
 method public,final getEventQueue ()Lnet/java/games/input/EventQueue; - -
 method protected,abstract getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected pollDevice ()V - java/io/IOException
 method public,synchronized poll ()Z - -
in 24
class net/java/games/input/ButtonUsage 48 final,super java/lang/Object net/java/games/input/Usage -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 method public,static,final map (I)Lnet/java/games/input/ButtonUsage; - -
 method public,final getIdentifier ()Lnet/java/games/input/Component$Identifier$Button; - -
 method public,final toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/Component 48 public,interface,abstract java/lang/Object - -
 inner net/java/games/input/Component$POV net/java/games/input/Component POV public,static
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public,abstract getIdentifier ()Lnet/java/games/input/Component$Identifier; - -
 method public,abstract isRelative ()Z - -
 method public,abstract isAnalog ()Z - -
 method public,abstract getDeadZone ()F - -
 method public,abstract getPollData ()F - -
 method public,abstract getName ()Ljava/lang/String; - -
in 24
class net/java/games/input/Component$Identifier 48 public,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method protected <init> (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/Component$Identifier$Axis 48 public,super net/java/games/input/Component$Identifier - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 field public,static,final X Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Y Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Z Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RX Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RZ Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final SLIDER Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final SLIDER_ACCELERATION Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final SLIDER_FORCE Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final SLIDER_VELOCITY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final X_ACCELERATION Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final X_FORCE Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final X_VELOCITY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Y_ACCELERATION Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Y_FORCE Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Y_VELOCITY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Z_ACCELERATION Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Z_FORCE Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final Z_VELOCITY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RX_ACCELERATION Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RX_FORCE Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RX_VELOCITY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RY_ACCELERATION Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RY_FORCE Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RY_VELOCITY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RZ_ACCELERATION Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RZ_FORCE Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final RZ_VELOCITY Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final POV Lnet/java/games/input/Component$Identifier$Axis; -
 field public,static,final UNKNOWN Lnet/java/games/input/Component$Identifier$Axis; -
 method protected <init> (Ljava/lang/String;)V - -
in 24
class net/java/games/input/Component$Identifier$Button 48 public,super net/java/games/input/Component$Identifier - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 field public,static,final _0 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _1 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _2 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _3 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _4 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _5 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _6 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _7 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _8 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _9 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _10 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _11 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _12 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _13 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _14 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _15 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _16 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _17 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _18 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _19 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _20 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _21 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _22 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _23 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _24 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _25 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _26 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _27 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _28 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _29 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _30 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final _31 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TRIGGER Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final THUMB Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final THUMB2 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOP Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOP2 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final PINKIE Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final BASE Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final BASE2 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final BASE3 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final BASE4 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final BASE5 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final BASE6 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final DEAD Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final A Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final B Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final C Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final X Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final Y Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final Z Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final LEFT_THUMB Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final RIGHT_THUMB Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final LEFT_THUMB2 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final RIGHT_THUMB2 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final SELECT Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final MODE Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final LEFT_THUMB3 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final RIGHT_THUMB3 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_PEN Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_RUBBER Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_BRUSH Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_PENCIL Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_AIRBRUSH Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_FINGER Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_MOUSE Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOOL_LENS Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final TOUCH Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final STYLUS Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final STYLUS2 Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final UNKNOWN Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final BACK Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final EXTRA Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final FORWARD Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final LEFT Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final MIDDLE Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final RIGHT Lnet/java/games/input/Component$Identifier$Button; -
 field public,static,final SIDE Lnet/java/games/input/Component$Identifier$Button; -
 method public <init> (Ljava/lang/String;)V - -
in 24
class net/java/games/input/Component$Identifier$Key 48 public,super net/java/games/input/Component$Identifier - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 field public,static,final VOID Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final ESCAPE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _1 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _2 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _3 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _4 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _5 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _6 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _7 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _8 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _9 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final _0 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final MINUS Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final EQUALS Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final BACK Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final TAB Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final Q Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final W Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final E Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final R Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final T Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final Y Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final U Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final I Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final O Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final P Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final LBRACKET Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final RBRACKET Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final RETURN Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final LCONTROL Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final A Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final S Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final D Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final G Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final H Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final J Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final K Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final L Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final SEMICOLON Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final APOSTROPHE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final GRAVE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final LSHIFT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final BACKSLASH Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final Z Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final X Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final C Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final V Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final B Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final N Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final M Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final COMMA Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final PERIOD Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final SLASH Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final RSHIFT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final MULTIPLY Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final LALT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final SPACE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final CAPITAL Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F1 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F2 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F3 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F4 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F5 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F6 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F7 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F8 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F9 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F10 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMLOCK Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final SCROLL Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD7 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD8 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD9 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final SUBTRACT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD4 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD5 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD6 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final ADD Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD1 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD2 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD3 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPAD0 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final DECIMAL Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F11 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F12 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F13 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F14 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final F15 Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final KANA Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final CONVERT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NOCONVERT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final YEN Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPADEQUAL Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final CIRCUMFLEX Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final AT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final COLON Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final UNDERLINE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final KANJI Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final STOP Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final AX Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final UNLABELED Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPADENTER Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final RCONTROL Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final NUMPADCOMMA Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final DIVIDE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final SYSRQ Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final RALT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final PAUSE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final HOME Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final UP Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final PAGEUP Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final LEFT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final RIGHT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final END Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final DOWN Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final PAGEDOWN Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final INSERT Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final DELETE Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final LWIN Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final RWIN Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final APPS Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final POWER Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final SLEEP Lnet/java/games/input/Component$Identifier$Key; -
 field public,static,final UNKNOWN Lnet/java/games/input/Component$Identifier$Key; -
 method protected <init> (Ljava/lang/String;)V - -
in 24
class net/java/games/input/Component$POV 48 public,super java/lang/Object - -
 inner net/java/games/input/Component$POV net/java/games/input/Component POV public,static
 field public,static,final OFF F - F0.0
 field public,static,final CENTER F - F0.0
 field public,static,final UP_LEFT F - F0.125
 field public,static,final UP F - F0.25
 field public,static,final UP_RIGHT F - F0.375
 field public,static,final RIGHT F - F0.5
 field public,static,final DOWN_RIGHT F - F0.625
 field public,static,final DOWN F - F0.75
 field public,static,final DOWN_LEFT F - F0.875
 field public,static,final LEFT F - F1.0
 method public <init> ()V - -
in 24
class net/java/games/input/Controller 48 public,interface,abstract java/lang/Object - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public,abstract getControllers ()[Lnet/java/games/input/Controller; - -
 method public,abstract getType ()Lnet/java/games/input/Controller$Type; - -
 method public,abstract getComponents ()[Lnet/java/games/input/Component; - -
 method public,abstract getComponent (Lnet/java/games/input/Component$Identifier;)Lnet/java/games/input/Component; - -
 method public,abstract getRumblers ()[Lnet/java/games/input/Rumbler; - -
 method public,abstract poll ()Z - -
 method public,abstract setEventQueueSize (I)V - -
 method public,abstract getEventQueue ()Lnet/java/games/input/EventQueue; - -
 method public,abstract getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method public,abstract getPortNumber ()I - -
 method public,abstract getName ()Ljava/lang/String; - -
in 24
class net/java/games/input/Controller$PortType 48 public,final,super java/lang/Object - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 field public,static,final UNKNOWN Lnet/java/games/input/Controller$PortType; -
 field public,static,final USB Lnet/java/games/input/Controller$PortType; -
 field public,static,final GAME Lnet/java/games/input/Controller$PortType; -
 field public,static,final NETWORK Lnet/java/games/input/Controller$PortType; -
 field public,static,final SERIAL Lnet/java/games/input/Controller$PortType; -
 field public,static,final I8042 Lnet/java/games/input/Controller$PortType; -
 field public,static,final PARALLEL Lnet/java/games/input/Controller$PortType; -
 method protected <init> (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/Controller$Type 48 public,super java/lang/Object - -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 field public,static,final UNKNOWN Lnet/java/games/input/Controller$Type; -
 field public,static,final MOUSE Lnet/java/games/input/Controller$Type; -
 field public,static,final KEYBOARD Lnet/java/games/input/Controller$Type; -
 field public,static,final FINGERSTICK Lnet/java/games/input/Controller$Type; -
 field public,static,final GAMEPAD Lnet/java/games/input/Controller$Type; -
 field public,static,final HEADTRACKER Lnet/java/games/input/Controller$Type; -
 field public,static,final RUDDER Lnet/java/games/input/Controller$Type; -
 field public,static,final STICK Lnet/java/games/input/Controller$Type; -
 field public,static,final TRACKBALL Lnet/java/games/input/Controller$Type; -
 field public,static,final TRACKPAD Lnet/java/games/input/Controller$Type; -
 field public,static,final WHEEL Lnet/java/games/input/Controller$Type; -
 method protected <init> (Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/ControllerEnvironment 48 public,super,abstract java/lang/Object - -
 field protected,final controllerListeners Ljava/util/ArrayList; -
 method protected <init> ()V - -
 method public,abstract getControllers ()[Lnet/java/games/input/Controller; - -
 method public addControllerListener (Lnet/java/games/input/ControllerListener;)V - -
 method public,abstract isSupported ()Z - -
 method public removeControllerListener (Lnet/java/games/input/ControllerListener;)V - -
 method protected fireControllerAdded (Lnet/java/games/input/Controller;)V - -
 method protected fireControllerRemoved (Lnet/java/games/input/Controller;)V - -
 method public,static getDefaultEnvironment ()Lnet/java/games/input/ControllerEnvironment; - -
in 24
class net/java/games/input/ControllerEvent 48 public,super java/lang/Object - -
 method public <init> (Lnet/java/games/input/Controller;)V - -
 method public getController ()Lnet/java/games/input/Controller; - -
in 24
class net/java/games/input/ControllerListener 48 public,interface,abstract java/lang/Object - -
 method public,abstract controllerRemoved (Lnet/java/games/input/ControllerEvent;)V - -
 method public,abstract controllerAdded (Lnet/java/games/input/ControllerEvent;)V - -
in 24
class net/java/games/input/DIAbstractController 48 final,super net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method protected <init> (Lnet/java/games/input/IDirectInputDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;Lnet/java/games/input/Controller$Type;)V - -
 method public,final pollDevice ()V - java/io/IOException
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
 method public,final getType ()Lnet/java/games/input/Controller$Type; - -
in 24
class net/java/games/input/DIComponent 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public <init> (Lnet/java/games/input/Component$Identifier;Lnet/java/games/input/DIDeviceObject;)V - -
 method public,final isRelative ()Z - -
 method public,final isAnalog ()Z - -
 method public,final getDeadZone ()F - -
 method public,final getDeviceObject ()Lnet/java/games/input/DIDeviceObject; - -
 method protected,final poll ()F - java/io/IOException
in 24
class net/java/games/input/DIControllers 48 final,super java/lang/Object - -
 method public,static,final,synchronized getNextDeviceEvent (Lnet/java/games/input/Event;Lnet/java/games/input/IDirectInputDevice;)Z - java/io/IOException
 method public,static,final poll (Lnet/java/games/input/Component;Lnet/java/games/input/DIDeviceObject;)F - java/io/IOException
in 24
class net/java/games/input/DIDeviceObject 48 final,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method public <init> (Lnet/java/games/input/IDirectInputDevice;Lnet/java/games/input/Component$Identifier;[BIIIIILjava/lang/String;I)V - java/io/IOException
 method public,final,synchronized getRelativePollValue (I)I - -
 method public,final,synchronized getRelativeEventValue (I)I - -
 method public,final getGUIDType ()I - -
 method public,final getFormatOffset ()I - -
 method public,final getDevice ()Lnet/java/games/input/IDirectInputDevice; - -
 method public,final getDIIdentifier ()I - -
 method public,final getIdentifier ()Lnet/java/games/input/Component$Identifier; - -
 method public,final getName ()Ljava/lang/String; - -
 method public,final getInstance ()I - -
 method public,final getType ()I - -
 method public,final getGUID ()[B - -
 method public,final getFlags ()I - -
 method public,final getMin ()J - -
 method public,final getMax ()J - -
 method public,final getDeadzone ()F - -
 method public,final isButton ()Z - -
 method public,final isAxis ()Z - -
 method public,final isRelative ()Z - -
 method public,final isAnalog ()Z - -
 method public,final convertValue (F)F - -
in 24
class net/java/games/input/DIDeviceObjectData 48 final,super java/lang/Object - -
 method public,final set (IIII)V - -
 method public,final set (Lnet/java/games/input/DIDeviceObjectData;)V - -
 method public,final getData ()I - -
 method public,final getFormatOffset ()I - -
 method public,final getNanos ()J - -
in 24
class net/java/games/input/DIEffectInfo 48 final,super java/lang/Object - -
 method public <init> (Lnet/java/games/input/IDirectInputDevice;[BIIIILjava/lang/String;)V - -
 method public,final getGUID ()[B - -
 method public,final getGUIDId ()I - -
 method public,final getDynamicParams ()I - -
 method public,final getEffectType ()I - -
 method public,final getName ()Ljava/lang/String; - -
in 24
class net/java/games/input/DIIdentifierMap 48 final,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 field public,static,final DIK_ESCAPE I - I1
 field public,static,final DIK_1 I - I2
 field public,static,final DIK_2 I - I3
 field public,static,final DIK_3 I - I4
 field public,static,final DIK_4 I - I5
 field public,static,final DIK_5 I - I6
 field public,static,final DIK_6 I - I7
 field public,static,final DIK_7 I - I8
 field public,static,final DIK_8 I - I9
 field public,static,final DIK_9 I - I10
 field public,static,final DIK_0 I - I11
 field public,static,final DIK_MINUS I - I12
 field public,static,final DIK_EQUALS I - I13
 field public,static,final DIK_BACK I - I14
 field public,static,final DIK_TAB I - I15
 field public,static,final DIK_Q I - I16
 field public,static,final DIK_W I - I17
 field public,static,final DIK_E I - I18
 field public,static,final DIK_R I - I19
 field public,static,final DIK_T I - I20
 field public,static,final DIK_Y I - I21
 field public,static,final DIK_U I - I22
 field public,static,final DIK_I I - I23
 field public,static,final DIK_O I - I24
 field public,static,final DIK_P I - I25
 field public,static,final DIK_LBRACKET I - I26
 field public,static,final DIK_RBRACKET I - I27
 field public,static,final DIK_RETURN I - I28
 field public,static,final DIK_LCONTROL I - I29
 field public,static,final DIK_A I - I30
 field public,static,final DIK_S I - I31
 field public,static,final DIK_D I - I32
 field public,static,final DIK_F I - I33
 field public,static,final DIK_G I - I34
 field public,static,final DIK_H I - I35
 field public,static,final DIK_J I - I36
 field public,static,final DIK_K I - I37
 field public,static,final DIK_L I - I38
 field public,static,final DIK_SEMICOLON I - I39
 field public,static,final DIK_APOSTROPHE I - I40
 field public,static,final DIK_GRAVE I - I41
 field public,static,final DIK_LSHIFT I - I42
 field public,static,final DIK_BACKSLASH I - I43
 field public,static,final DIK_Z I - I44
 field public,static,final DIK_X I - I45
 field public,static,final DIK_C I - I46
 field public,static,final DIK_V I - I47
 field public,static,final DIK_B I - I48
 field public,static,final DIK_N I - I49
 field public,static,final DIK_M I - I50
 field public,static,final DIK_COMMA I - I51
 field public,static,final DIK_PERIOD I - I52
 field public,static,final DIK_SLASH I - I53
 field public,static,final DIK_RSHIFT I - I54
 field public,static,final DIK_MULTIPLY I - I55
 field public,static,final DIK_LMENU I - I56
 field public,static,final DIK_SPACE I - I57
 field public,static,final DIK_CAPITAL I - I58
 field public,static,final DIK_F1 I - I59
 field public,static,final DIK_F2 I - I60
 field public,static,final DIK_F3 I - I61
 field public,static,final DIK_F4 I - I62
 field public,static,final DIK_F5 I - I63
 field public,static,final DIK_F6 I - I64
 field public,static,final DIK_F7 I - I65
 field public,static,final DIK_F8 I - I66
 field public,static,final DIK_F9 I - I67
 field public,static,final DIK_F10 I - I68
 field public,static,final DIK_NUMLOCK I - I69
 field public,static,final DIK_SCROLL I - I70
 field public,static,final DIK_NUMPAD7 I - I71
 field public,static,final DIK_NUMPAD8 I - I72
 field public,static,final DIK_NUMPAD9 I - I73
 field public,static,final DIK_SUBTRACT I - I74
 field public,static,final DIK_NUMPAD4 I - I75
 field public,static,final DIK_NUMPAD5 I - I76
 field public,static,final DIK_NUMPAD6 I - I77
 field public,static,final DIK_ADD I - I78
 field public,static,final DIK_NUMPAD1 I - I79
 field public,static,final DIK_NUMPAD2 I - I80
 field public,static,final DIK_NUMPAD3 I - I81
 field public,static,final DIK_NUMPAD0 I - I82
 field public,static,final DIK_DECIMAL I - I83
 field public,static,final DIK_OEM_102 I - I86
 field public,static,final DIK_F11 I - I87
 field public,static,final DIK_F12 I - I88
 field public,static,final DIK_F13 I - I100
 field public,static,final DIK_F14 I - I101
 field public,static,final DIK_F15 I - I102
 field public,static,final DIK_KANA I - I112
 field public,static,final DIK_ABNT_C1 I - I115
 field public,static,final DIK_CONVERT I - I121
 field public,static,final DIK_NOCONVERT I - I123
 field public,static,final DIK_YEN I - I125
 field public,static,final DIK_ABNT_C2 I - I126
 field public,static,final DIK_NUMPADEQUALS I - I141
 field public,static,final DIK_PREVTRACK I - I144
 field public,static,final DIK_AT I - I145
 field public,static,final DIK_COLON I - I146
 field public,static,final DIK_UNDERLINE I - I147
 field public,static,final DIK_KANJI I - I148
 field public,static,final DIK_STOP I - I149
 field public,static,final DIK_AX I - I150
 field public,static,final DIK_UNLABELED I - I151
 field public,static,final DIK_NEXTTRACK I - I153
 field public,static,final DIK_NUMPADENTER I - I156
 field public,static,final DIK_RCONTROL I - I157
 field public,static,final DIK_MUTE I - I160
 field public,static,final DIK_CALCULATOR I - I161
 field public,static,final DIK_PLAYPAUSE I - I162
 field public,static,final DIK_MEDIASTOP I - I164
 field public,static,final DIK_VOLUMEDOWN I - I174
 field public,static,final DIK_VOLUMEUP I - I176
 field public,static,final DIK_WEBHOME I - I178
 field public,static,final DIK_NUMPADCOMMA I - I179
 field public,static,final DIK_DIVIDE I - I181
 field public,static,final DIK_SYSRQ I - I183
 field public,static,final DIK_RMENU I - I184
 field public,static,final DIK_PAUSE I - I197
 field public,static,final DIK_HOME I - I199
 field public,static,final DIK_UP I - I200
 field public,static,final DIK_PRIOR I - I201
 field public,static,final DIK_LEFT I - I203
 field public,static,final DIK_RIGHT I - I205
 field public,static,final DIK_END I - I207
 field public,static,final DIK_DOWN I - I208
 field public,static,final DIK_NEXT I - I209
 field public,static,final DIK_INSERT I - I210
 field public,static,final DIK_DELETE I - I211
 field public,static,final DIK_LWIN I - I219
 field public,static,final DIK_RWIN I - I220
 field public,static,final DIK_APPS I - I221
 field public,static,final DIK_POWER I - I222
 field public,static,final DIK_SLEEP I - I223
 field public,static,final DIK_WAKE I - I227
 field public,static,final DIK_WEBSEARCH I - I229
 field public,static,final DIK_WEBFAVORITES I - I230
 field public,static,final DIK_WEBREFRESH I - I231
 field public,static,final DIK_WEBSTOP I - I232
 field public,static,final DIK_WEBFORWARD I - I233
 field public,static,final DIK_WEBBACK I - I234
 field public,static,final DIK_MYCOMPUTER I - I235
 field public,static,final DIK_MAIL I - I236
 field public,static,final DIK_MEDIASELECT I - I237
 method public,static,final getKeyIdentifier (I)Lnet/java/games/input/Component$Identifier$Key; - -
 method public,static,final getButtonIdentifier (I)Lnet/java/games/input/Component$Identifier$Button; - -
 method public,static,final mapMouseButtonIdentifier (Lnet/java/games/input/Component$Identifier$Button;)Lnet/java/games/input/Component$Identifier$Button; - -
in 24
class net/java/games/input/DIKeyboard 48 final,super net/java/games/input/Keyboard - -
 method protected <init> (Lnet/java/games/input/IDirectInputDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public,final pollDevice ()V - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
in 24
class net/java/games/input/DIMouse 48 final,super net/java/games/input/Mouse - -
 method protected <init> (Lnet/java/games/input/IDirectInputDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method public,final pollDevice ()V - java/io/IOException
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
in 24
class net/java/games/input/DataQueue 48 final,super java/lang/Object - -
 method public <init> (ILjava/lang/Class;)V - -
 method public,final clear ()V - -
 method public,final position ()I - -
 method public,final limit ()I - -
 method public,final get (I)Ljava/lang/Object; - -
 method public,final get ()Ljava/lang/Object; - -
 method public,final compact ()V - -
 method public,final flip ()V - -
 method public,final hasRemaining ()Z - -
 method public,final remaining ()I - -
 method public,final position (I)V - -
 method public,final getElements ()[Ljava/lang/Object; - -
in 24
class net/java/games/input/DefaultControllerEnvironment 48 super net/java/games/input/ControllerEnvironment - -
 method public <init> ()V - -
 method public getControllers ()[Lnet/java/games/input/Controller; - -
 method public isSupported ()Z - -
in 24
class net/java/games/input/DirectAndRawInputEnvironmentPlugin 48 public,super net/java/games/input/ControllerEnvironment - -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method public <init> ()V - -
 method public getControllers ()[Lnet/java/games/input/Controller; - -
 method public isSupported ()Z - -
in 24
class net/java/games/input/DirectInputEnvironmentPlugin 48 public,final,super net/java/games/input/ControllerEnvironment net/java/games/util/plugins/Plugin -
 inner net/java/games/input/DirectInputEnvironmentPlugin$ShutdownHook net/java/games/input/DirectInputEnvironmentPlugin ShutdownHook private,final
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 method public <init> ()V - -
 method public,final getControllers ()[Lnet/java/games/input/Controller; - -
 method public isSupported ()Z - -
in 24
class net/java/games/input/DirectInputEnvironmentPlugin$ShutdownHook 48 final,super java/lang/Thread - -
 inner net/java/games/input/DirectInputEnvironmentPlugin$ShutdownHook net/java/games/input/DirectInputEnvironmentPlugin ShutdownHook private,final
 method public,final run ()V - -
in 24
class net/java/games/input/DummyWindow 48 final,super java/lang/Object - -
 method public <init> ()V - java/io/IOException
 method public,final destroy ()V - java/io/IOException
 method public,final getHwnd ()J - -
in 24
class net/java/games/input/ElementType 48 final,super java/lang/Object - -
 field public,static,final INPUT_MISC Lnet/java/games/input/ElementType; -
 field public,static,final INPUT_BUTTON Lnet/java/games/input/ElementType; -
 field public,static,final INPUT_AXIS Lnet/java/games/input/ElementType; -
 field public,static,final INPUT_SCANCODES Lnet/java/games/input/ElementType; -
 field public,static,final OUTPUT Lnet/java/games/input/ElementType; -
 field public,static,final FEATURE Lnet/java/games/input/ElementType; -
 field public,static,final COLLECTION Lnet/java/games/input/ElementType; -
 method public,static,final map (I)Lnet/java/games/input/ElementType; - -
 method public,final toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/Event 48 public,final,super java/lang/Object - -
 method public <init> ()V - -
 method public,final set (Lnet/java/games/input/Event;)V - -
 method public,final set (Lnet/java/games/input/Component;FJ)V - -
 method public,final getComponent ()Lnet/java/games/input/Component; - -
 method public,final getValue ()F - -
 method public,final getNanos ()J - -
 method public,final toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/EventQueue 48 public,final,super java/lang/Object - -
 method public <init> (I)V - -
 method public,final,synchronized getNextEvent (Lnet/java/games/input/Event;)Z - -
in 24
class net/java/games/input/GenericDesktopUsage 48 final,super java/lang/Object net/java/games/input/Usage -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 field public,static,final POINTER Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final MOUSE Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final JOYSTICK Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final GAME_PAD Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final KEYBOARD Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final KEYPAD Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final MULTI_AXIS_CONTROLLER Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final X Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final Y Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final Z Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final RX Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final RY Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final RZ Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SLIDER Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final DIAL Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final WHEEL Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final HATSWITCH Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final COUNTED_BUFFER Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final BYTE_COUNT Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final MOTION_WAKEUP Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final START Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SELECT Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final VX Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final VY Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final VZ Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final VBRX Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final VBRY Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final VBRZ Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final VNO Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_CONTROL Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_POWER_DOWN Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_SLEEP Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_WAKE_UP Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_CONTEXT_MENU Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MAIN_MENU Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_APP_MENU Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MENU_HELP Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MENU_EXIT Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MENU Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MENU_RIGHT Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MENU_LEFT Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MENU_UP Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final SYSTEM_MENU_DOWN Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final DPAD_UP Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final DPAD_DOWN Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final DPAD_RIGHT Lnet/java/games/input/GenericDesktopUsage; -
 field public,static,final DPAD_LEFT Lnet/java/games/input/GenericDesktopUsage; -
 method public,static,final map (I)Lnet/java/games/input/GenericDesktopUsage; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final getIdentifier ()Lnet/java/games/input/Component$Identifier; - -
in 24
class net/java/games/input/IDirectInput 48 final,super java/lang/Object - -
 method public <init> (Lnet/java/games/input/DummyWindow;)V - java/io/IOException
 method public,final getDevices ()Ljava/util/List; - -
 method public,final releaseDevices ()V - -
 method public,final release ()V - -
in 24
class net/java/games/input/IDirectInputDevice 48 final,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 field public,static,final GUID_XAxis I - I1
 field public,static,final GUID_YAxis I - I2
 field public,static,final GUID_ZAxis I - I3
 field public,static,final GUID_RxAxis I - I4
 field public,static,final GUID_RyAxis I - I5
 field public,static,final GUID_RzAxis I - I6
 field public,static,final GUID_Slider I - I7
 field public,static,final GUID_Button I - I8
 field public,static,final GUID_Key I - I9
 field public,static,final GUID_POV I - I10
 field public,static,final GUID_Unknown I - I11
 field public,static,final GUID_ConstantForce I - I12
 field public,static,final GUID_RampForce I - I13
 field public,static,final GUID_Square I - I14
 field public,static,final GUID_Sine I - I15
 field public,static,final GUID_Triangle I - I16
 field public,static,final GUID_SawtoothUp I - I17
 field public,static,final GUID_SawtoothDown I - I18
 field public,static,final GUID_Spring I - I19
 field public,static,final GUID_Damper I - I20
 field public,static,final GUID_Inertia I - I21
 field public,static,final GUID_Friction I - I22
 field public,static,final GUID_CustomForce I - I23
 field public,static,final DI8DEVTYPE_DEVICE I - I17
 field public,static,final DI8DEVTYPE_MOUSE I - I18
 field public,static,final DI8DEVTYPE_KEYBOARD I - I19
 field public,static,final DI8DEVTYPE_JOYSTICK I - I20
 field public,static,final DI8DEVTYPE_GAMEPAD I - I21
 field public,static,final DI8DEVTYPE_DRIVING I - I22
 field public,static,final DI8DEVTYPE_FLIGHT I - I23
 field public,static,final DI8DEVTYPE_1STPERSON I - I24
 field public,static,final DI8DEVTYPE_DEVICECTRL I - I25
 field public,static,final DI8DEVTYPE_SCREENPOINTER I - I26
 field public,static,final DI8DEVTYPE_REMOTE I - I27
 field public,static,final DI8DEVTYPE_SUPPLEMENTAL I - I28
 field public,static,final DISCL_EXCLUSIVE I - I1
 field public,static,final DISCL_NONEXCLUSIVE I - I2
 field public,static,final DISCL_FOREGROUND I - I4
 field public,static,final DISCL_BACKGROUND I - I8
 field public,static,final DISCL_NOWINKEY I - I16
 field public,static,final DIDFT_ALL I - I0
 field public,static,final DIDFT_RELAXIS I - I1
 field public,static,final DIDFT_ABSAXIS I - I2
 field public,static,final DIDFT_AXIS I - I3
 field public,static,final DIDFT_PSHBUTTON I - I4
 field public,static,final DIDFT_TGLBUTTON I - I8
 field public,static,final DIDFT_BUTTON I - I12
 field public,static,final DIDFT_POV I - I16
 field public,static,final DIDFT_COLLECTION I - I64
 field public,static,final DIDFT_NODATA I - I128
 field public,static,final DIDFT_FFACTUATOR I - I16777216
 field public,static,final DIDFT_FFEFFECTTRIGGER I - I33554432
 field public,static,final DIDFT_OUTPUT I - I268435456
 field public,static,final DIDFT_VENDORDEFINED I - I67108864
 field public,static,final DIDFT_ALIAS I - I134217728
 field public,static,final DIDFT_OPTIONAL I - I-2147483648
 field public,static,final DIDFT_NOCOLLECTION I - I16776960
 field public,static,final DIDF_ABSAXIS I - I1
 field public,static,final DIDF_RELAXIS I - I2
 field public,static,final DI_OK I - I0
 field public,static,final DI_NOEFFECT I - I1
 field public,static,final DI_PROPNOEFFECT I - I1
 field public,static,final DI_POLLEDDEVICE I - I2
 field public,static,final DI_DOWNLOADSKIPPED I - I3
 field public,static,final DI_EFFECTRESTARTED I - I4
 field public,static,final DI_TRUNCATED I - I8
 field public,static,final DI_SETTINGSNOTSAVED I - I11
 field public,static,final DI_TRUNCATEDANDRESTARTED I - I12
 field public,static,final DI_BUFFEROVERFLOW I - I1
 field public,static,final DIERR_INPUTLOST I - I-2147024866
 field public,static,final DIERR_NOTACQUIRED I - I-2147024868
 field public,static,final DIERR_OTHERAPPHASPRIO I - I-2147024891
 field public,static,final DIDOI_FFACTUATOR I - I1
 field public,static,final DIDOI_FFEFFECTTRIGGER I - I2
 field public,static,final DIDOI_POLLED I - I32768
 field public,static,final DIDOI_ASPECTPOSITION I - I256
 field public,static,final DIDOI_ASPECTVELOCITY I - I512
 field public,static,final DIDOI_ASPECTACCEL I - I768
 field public,static,final DIDOI_ASPECTFORCE I - I1024
 field public,static,final DIDOI_ASPECTMASK I - I3840
 field public,static,final DIDOI_GUIDISUSAGE I - I65536
 field public,static,final DIEFT_ALL I - I0
 field public,static,final DIEFT_CONSTANTFORCE I - I1
 field public,static,final DIEFT_RAMPFORCE I - I2
 field public,static,final DIEFT_PERIODIC I - I3
 field public,static,final DIEFT_CONDITION I - I4
 field public,static,final DIEFT_CUSTOMFORCE I - I5
 field public,static,final DIEFT_HARDWARE I - I255
 field public,static,final DIEFT_FFATTACK I - I512
 field public,static,final DIEFT_FFFADE I - I1024
 field public,static,final DIEFT_SATURATION I - I2048
 field public,static,final DIEFT_POSNEGCOEFFICIENTS I - I4096
 field public,static,final DIEFT_POSNEGSATURATION I - I8192
 field public,static,final DIEFT_DEADBAND I - I16384
 field public,static,final DIEFT_STARTDELAY I - I32768
 field public,static,final DIEFF_OBJECTIDS I - I1
 field public,static,final DIEFF_OBJECTOFFSETS I - I2
 field public,static,final DIEFF_CARTESIAN I - I16
 field public,static,final DIEFF_POLAR I - I32
 field public,static,final DIEFF_SPHERICAL I - I64
 field public,static,final DIEP_DURATION I - I1
 field public,static,final DIEP_SAMPLEPERIOD I - I2
 field public,static,final DIEP_GAIN I - I4
 field public,static,final DIEP_TRIGGERBUTTON I - I8
 field public,static,final DIEP_TRIGGERREPEATINTERVAL I - I16
 field public,static,final DIEP_AXES I - I32
 field public,static,final DIEP_DIRECTION I - I64
 field public,static,final DIEP_ENVELOPE I - I128
 field public,static,final DIEP_TYPESPECIFICPARAMS I - I256
 field public,static,final DIEP_STARTDELAY I - I512
 field public,static,final DIEP_ALLPARAMS_DX5 I - I511
 field public,static,final DIEP_ALLPARAMS I - I1023
 field public,static,final DIEP_START I - I536870912
 field public,static,final DIEP_NORESTART I - I1073741824
 field public,static,final DIEP_NODOWNLOAD I - I-2147483648
 field public,static,final DIEB_NOTRIGGER I - I-1
 field public,static,final INFINITE I - I-1
 field public,static,final DI_DEGREES I - I100
 field public,static,final DI_FFNOMINALMAX I - I10000
 field public,static,final DI_SECONDS I - I1000000
 field public,static,final DIPROPRANGE_NOMIN I - I-2147483648
 field public,static,final DIPROPRANGE_NOMAX I - I2147483647
 method public <init> (Lnet/java/games/input/DummyWindow;J[B[BIILjava/lang/String;Ljava/lang/String;)V - java/io/IOException
 method public,final areAxesRelative ()Z - -
 method public,final getRumblers ()[Lnet/java/games/input/Rumbler; - -
 method public,final getPollData (Lnet/java/games/input/DIDeviceObject;)I - -
 method public,final mapEvent (Lnet/java/games/input/DIDeviceObjectData;)Lnet/java/games/input/DIDeviceObject; - -
 method public,final mapObject (Lnet/java/games/input/DIDeviceObject;)Lnet/java/games/input/DIComponent; - -
 method public,final registerComponent (Lnet/java/games/input/DIDeviceObject;Lnet/java/games/input/DIComponent;)V - -
 method public,final,synchronized pollAll ()V - java/io/IOException
 method public,final,synchronized getNextEvent (Lnet/java/games/input/DIDeviceObjectData;)Z - -
 method public,final getProductName ()Ljava/lang/String; - -
 method public,final getType ()I - -
 method public,final getObjects ()Ljava/util/List; - -
 method public,final,synchronized getRangeProperty (I)[J - java/io/IOException
 method public,final,synchronized getDeadzoneProperty (I)I - java/io/IOException
 method public,final,synchronized setBufferSize (I)V - java/io/IOException
 method public,final,synchronized setCooperativeLevel (I)V - java/io/IOException
 method public,final,synchronized release ()V - -
 method protected finalize ()V - -
in 24
class net/java/games/input/IDirectInputEffect 48 final,super java/lang/Object net/java/games/input/Rumbler -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public <init> (JLnet/java/games/input/DIEffectInfo;)V - -
 method public,final,synchronized rumble (F)V - -
 method public,final getAxisIdentifier ()Lnet/java/games/input/Component$Identifier; - -
 method public,final getAxisName ()Ljava/lang/String; - -
 method public,final,synchronized release ()V - -
 method protected finalize ()V - -
in 24
class net/java/games/input/Keyboard 48 public,super,abstract net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 method protected <init> (Ljava/lang/String;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method public getType ()Lnet/java/games/input/Controller$Type; - -
 method public,final isKeyDown (Lnet/java/games/input/Component$Identifier$Key;)Z - -
in 24
class net/java/games/input/KeyboardUsage 48 final,super java/lang/Object net/java/games/input/Usage -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 field public,static,final ERRORROLLOVER Lnet/java/games/input/KeyboardUsage; -
 field public,static,final POSTFAIL Lnet/java/games/input/KeyboardUsage; -
 field public,static,final ERRORUNDEFINED Lnet/java/games/input/KeyboardUsage; -
 field public,static,final A Lnet/java/games/input/KeyboardUsage; -
 field public,static,final B Lnet/java/games/input/KeyboardUsage; -
 field public,static,final C Lnet/java/games/input/KeyboardUsage; -
 field public,static,final D Lnet/java/games/input/KeyboardUsage; -
 field public,static,final E Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F Lnet/java/games/input/KeyboardUsage; -
 field public,static,final G Lnet/java/games/input/KeyboardUsage; -
 field public,static,final H Lnet/java/games/input/KeyboardUsage; -
 field public,static,final I Lnet/java/games/input/KeyboardUsage; -
 field public,static,final J Lnet/java/games/input/KeyboardUsage; -
 field public,static,final K Lnet/java/games/input/KeyboardUsage; -
 field public,static,final L Lnet/java/games/input/KeyboardUsage; -
 field public,static,final M Lnet/java/games/input/KeyboardUsage; -
 field public,static,final N Lnet/java/games/input/KeyboardUsage; -
 field public,static,final O Lnet/java/games/input/KeyboardUsage; -
 field public,static,final P Lnet/java/games/input/KeyboardUsage; -
 field public,static,final Q Lnet/java/games/input/KeyboardUsage; -
 field public,static,final R Lnet/java/games/input/KeyboardUsage; -
 field public,static,final S Lnet/java/games/input/KeyboardUsage; -
 field public,static,final T Lnet/java/games/input/KeyboardUsage; -
 field public,static,final U Lnet/java/games/input/KeyboardUsage; -
 field public,static,final V Lnet/java/games/input/KeyboardUsage; -
 field public,static,final W Lnet/java/games/input/KeyboardUsage; -
 field public,static,final X Lnet/java/games/input/KeyboardUsage; -
 field public,static,final Y Lnet/java/games/input/KeyboardUsage; -
 field public,static,final Z Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _1 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _2 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _3 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _4 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _5 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _6 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _7 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _8 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _9 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final _0 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final ENTER Lnet/java/games/input/KeyboardUsage; -
 field public,static,final ESCAPE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final BACKSPACE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final TAB Lnet/java/games/input/KeyboardUsage; -
 field public,static,final SPACEBAR Lnet/java/games/input/KeyboardUsage; -
 field public,static,final HYPHEN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final EQUALSIGN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final OPENBRACKET Lnet/java/games/input/KeyboardUsage; -
 field public,static,final CLOSEBRACKET Lnet/java/games/input/KeyboardUsage; -
 field public,static,final BACKSLASH Lnet/java/games/input/KeyboardUsage; -
 field public,static,final NONUSPOUNT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final SEMICOLON Lnet/java/games/input/KeyboardUsage; -
 field public,static,final QUOTE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final TILDE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final COMMA Lnet/java/games/input/KeyboardUsage; -
 field public,static,final PERIOD Lnet/java/games/input/KeyboardUsage; -
 field public,static,final SLASH Lnet/java/games/input/KeyboardUsage; -
 field public,static,final CAPSLOCK Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F1 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F2 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F3 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F4 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F5 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F6 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F7 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F8 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F9 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F10 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F11 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F12 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final PRINTSCREEN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final SCROLLLOCK Lnet/java/games/input/KeyboardUsage; -
 field public,static,final PAUSE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INSERT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final HOME Lnet/java/games/input/KeyboardUsage; -
 field public,static,final PAGEUP Lnet/java/games/input/KeyboardUsage; -
 field public,static,final DELETE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final END Lnet/java/games/input/KeyboardUsage; -
 field public,static,final PAGEDOWN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final RIGHTARROW Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LEFTARROW Lnet/java/games/input/KeyboardUsage; -
 field public,static,final DOWNARROW Lnet/java/games/input/KeyboardUsage; -
 field public,static,final UPARROW Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_NUMLOCK Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_SLASH Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_ASTERICK Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_HYPHEN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_PLUS Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_ENTER Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_1 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_2 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_3 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_4 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_5 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_6 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_7 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_8 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_9 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_0 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_PERIOD Lnet/java/games/input/KeyboardUsage; -
 field public,static,final NONUSBACKSLASH Lnet/java/games/input/KeyboardUsage; -
 field public,static,final APPLICATION Lnet/java/games/input/KeyboardUsage; -
 field public,static,final POWER Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_EQUALSIGN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F13 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F14 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F15 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F16 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F17 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F18 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F19 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F20 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F21 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F22 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F23 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final F24 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final EXECUTE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final HELP Lnet/java/games/input/KeyboardUsage; -
 field public,static,final MENU Lnet/java/games/input/KeyboardUsage; -
 field public,static,final SELECT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final STOP Lnet/java/games/input/KeyboardUsage; -
 field public,static,final AGAIN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final UNDO Lnet/java/games/input/KeyboardUsage; -
 field public,static,final CUT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final COPY Lnet/java/games/input/KeyboardUsage; -
 field public,static,final PASTE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final FIND Lnet/java/games/input/KeyboardUsage; -
 field public,static,final MUTE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final VOLUMEUP Lnet/java/games/input/KeyboardUsage; -
 field public,static,final VOLUMEDOWN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LOCKINGCAPSLOCK Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LOCKINGNUMLOCK Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LOCKINGSCROLLLOCK Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_COMMA Lnet/java/games/input/KeyboardUsage; -
 field public,static,final KEYPAD_EQUALSSIGNAS400 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL1 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL2 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL3 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL4 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL5 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL6 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL7 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL8 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final INTERNATIONAL9 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG1 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG2 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG3 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG4 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG5 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG6 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG7 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG8 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LANG9 Lnet/java/games/input/KeyboardUsage; -
 field public,static,final ALTERNATEERASE Lnet/java/games/input/KeyboardUsage; -
 field public,static,final SYSREQORATTENTION Lnet/java/games/input/KeyboardUsage; -
 field public,static,final CANCEL Lnet/java/games/input/KeyboardUsage; -
 field public,static,final CLEAR Lnet/java/games/input/KeyboardUsage; -
 field public,static,final PRIOR Lnet/java/games/input/KeyboardUsage; -
 field public,static,final RETURN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final SEPARATOR Lnet/java/games/input/KeyboardUsage; -
 field public,static,final OUT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final OPER Lnet/java/games/input/KeyboardUsage; -
 field public,static,final CLEARORAGAIN Lnet/java/games/input/KeyboardUsage; -
 field public,static,final CRSELORPROPS Lnet/java/games/input/KeyboardUsage; -
 field public,static,final EXSEL Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LEFTCONTROL Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LEFTSHIFT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LEFTALT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final LEFTGUI Lnet/java/games/input/KeyboardUsage; -
 field public,static,final RIGHTCONTROL Lnet/java/games/input/KeyboardUsage; -
 field public,static,final RIGHTSHIFT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final RIGHTALT Lnet/java/games/input/KeyboardUsage; -
 field public,static,final RIGHTGUI Lnet/java/games/input/KeyboardUsage; -
 method public,final getIdentifier ()Lnet/java/games/input/Component$Identifier$Key; - -
 method public,static,final map (I)Lnet/java/games/input/KeyboardUsage; - -
 method public,final toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/LinuxAbsInfo 48 final,super java/lang/Object - -
 method public,final set (IIIII)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final getValue ()I - -
in 24
class net/java/games/input/LinuxAbstractController 48 final,super net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method protected <init> (Lnet/java/games/input/LinuxEventDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;Lnet/java/games/input/Controller$Type;)V - java/io/IOException
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method public,final pollDevice ()V - java/io/IOException
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public getType ()Lnet/java/games/input/Controller$Type; - -
in 24
class net/java/games/input/LinuxAxisDescriptor 48 final,super java/lang/Object - -
 method public,final set (II)V - -
 method public,final getType ()I - -
 method public,final getCode ()I - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public,final toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/LinuxCombinedController 48 public,super net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method protected getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method public,final pollDevice ()V - java/io/IOException
 method public getType ()Lnet/java/games/input/Controller$Type; - -
in 24
class net/java/games/input/LinuxComponent 48 super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public <init> (Lnet/java/games/input/LinuxEventComponent;)V - -
 method public,final isRelative ()Z - -
 method public,final isAnalog ()Z - -
 method protected poll ()F - java/io/IOException
 method public,final getDeadZone ()F - -
 method public,final getComponent ()Lnet/java/games/input/LinuxEventComponent; - -
in 24
class net/java/games/input/LinuxConstantFF 48 final,super net/java/games/input/LinuxForceFeedbackEffect - -
 method public <init> (Lnet/java/games/input/LinuxEventDevice;)V - java/io/IOException
 method protected,final upload (IF)I - java/io/IOException
in 24
class net/java/games/input/LinuxControllers 48 final,super java/lang/Object - -
 method public,static,final,synchronized getNextDeviceEvent (Lnet/java/games/input/Event;Lnet/java/games/input/LinuxEventDevice;)Z - java/io/IOException
 method public,static,final,synchronized poll (Lnet/java/games/input/LinuxEventComponent;)F - java/io/IOException
in 24
class net/java/games/input/LinuxDevice 48 interface,abstract java/lang/Object - -
 method public,abstract close ()V - java/io/IOException
in 24
class net/java/games/input/LinuxDeviceTask 48 super,abstract java/lang/Object - -
 field public,static,final INPROGRESS I - I1
 field public,static,final COMPLETED I - I2
 field public,static,final FAILED I - I3
 method public,final doExecute ()V - -
 method public,final getException ()Ljava/io/IOException; - -
 method public,final getResult ()Ljava/lang/Object; - -
 method public,final getState ()I - -
 method protected,abstract execute ()Ljava/lang/Object; - java/io/IOException
in 24
class net/java/games/input/LinuxDeviceThread 48 final,super java/lang/Thread - -
 method public <init> ()V - -
 method public,final,synchronized run ()V - -
 method public,final execute (Lnet/java/games/input/LinuxDeviceTask;)Ljava/lang/Object; - java/io/IOException
in 24
class net/java/games/input/LinuxEnvironmentPlugin 48 public,final,super net/java/games/input/ControllerEnvironment net/java/games/util/plugins/Plugin -
 inner net/java/games/input/LinuxEnvironmentPlugin$ShutdownHook net/java/games/input/LinuxEnvironmentPlugin ShutdownHook private,final
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method public,static,final execute (Lnet/java/games/input/LinuxDeviceTask;)Ljava/lang/Object; - java/io/IOException
 method public <init> ()V - -
 method public,final getControllers ()[Lnet/java/games/input/Controller; - -
 method public isSupported ()Z - -
in 24
class net/java/games/input/LinuxEnvironmentPlugin$ShutdownHook 48 final,super java/lang/Thread - -
 inner net/java/games/input/LinuxEnvironmentPlugin$ShutdownHook net/java/games/input/LinuxEnvironmentPlugin ShutdownHook private,final
 method public,final run ()V - -
in 24
class net/java/games/input/LinuxEvent 48 final,super java/lang/Object - -
 method public,final set (JJIII)V - -
 method public,final getValue ()I - -
 method public,final getDescriptor ()Lnet/java/games/input/LinuxAxisDescriptor; - -
 method public,final getNanos ()J - -
in 24
class net/java/games/input/LinuxEventComponent 48 final,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method public <init> (Lnet/java/games/input/LinuxEventDevice;Lnet/java/games/input/Component$Identifier;ZII)V - java/io/IOException
 method public,final getDevice ()Lnet/java/games/input/LinuxEventDevice; - -
 method public,final getAbsInfo (Lnet/java/games/input/LinuxAbsInfo;)V - java/io/IOException
 method public,final getButtonTrait ()Lnet/java/games/input/Controller$Type; - -
 method public,final getIdentifier ()Lnet/java/games/input/Component$Identifier; - -
 method public,final getDescriptor ()Lnet/java/games/input/LinuxAxisDescriptor; - -
 method public,final isRelative ()Z - -
 method public,final isAnalog ()Z - -
in 24
class net/java/games/input/LinuxEventDevice 48 final,super java/lang/Object net/java/games/input/LinuxDevice -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public <init> (Ljava/lang/String;)V - java/io/IOException
 method public,final getType ()Lnet/java/games/input/Controller$Type; - -
 method public,final getRumblers ()[Lnet/java/games/input/Rumbler; - -
 method public,final,synchronized uploadRumbleEffect (IIIIIIII)I - java/io/IOException
 method public,final,synchronized uploadConstantEffect (IIIIIIIIIII)I - java/io/IOException
 method public,final,synchronized writeEvent (III)V - java/io/IOException
 method public,final registerComponent (Lnet/java/games/input/LinuxAxisDescriptor;Lnet/java/games/input/LinuxComponent;)V - -
 method public,final mapDescriptor (Lnet/java/games/input/LinuxAxisDescriptor;)Lnet/java/games/input/LinuxComponent; - -
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - java/io/IOException
 method public,final getInputID ()Lnet/java/games/input/LinuxInputID; - -
 method public,final getNumEffects ()I - java/io/IOException
 method public,final,synchronized getNextEvent (Lnet/java/games/input/LinuxEvent;)Z - java/io/IOException
 method public,final,synchronized getAbsInfo (ILnet/java/games/input/LinuxAbsInfo;)V - java/io/IOException
 method public,final getComponents ()Ljava/util/List; - -
 method public,final,synchronized pollKeyStates ()V - java/io/IOException
 method public,final isKeySet (I)Z - -
 method public,static,final isBitSet ([BI)Z - -
 method public,final getName ()Ljava/lang/String; - -
 method public,final,synchronized close ()V - java/io/IOException
 method protected finalize ()V - java/io/IOException
in 24
class net/java/games/input/LinuxForceFeedbackEffect 48 super,abstract java/lang/Object net/java/games/input/Rumbler -
 inner net/java/games/input/LinuxForceFeedbackEffect$WriteTask net/java/games/input/LinuxForceFeedbackEffect WriteTask private,final
 inner net/java/games/input/LinuxForceFeedbackEffect$UploadTask net/java/games/input/LinuxForceFeedbackEffect UploadTask private,final
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public <init> (Lnet/java/games/input/LinuxEventDevice;)V - java/io/IOException
 method protected,abstract upload (IF)I - java/io/IOException
 method protected,final getDevice ()Lnet/java/games/input/LinuxEventDevice; - -
 method public,final,synchronized rumble (F)V - -
 method public,final getAxisName ()Ljava/lang/String; - -
 method public,final getAxisIdentifier ()Lnet/java/games/input/Component$Identifier; - -
in 24
class net/java/games/input/LinuxForceFeedbackEffect$UploadTask 48 final,super net/java/games/input/LinuxDeviceTask - -
 inner net/java/games/input/LinuxForceFeedbackEffect$UploadTask net/java/games/input/LinuxForceFeedbackEffect UploadTask private,final
 method public,final doUpload (IF)I - java/io/IOException
 method protected,final execute ()Ljava/lang/Object; - java/io/IOException
in 24
class net/java/games/input/LinuxForceFeedbackEffect$WriteTask 48 final,super net/java/games/input/LinuxDeviceTask - -
 inner net/java/games/input/LinuxForceFeedbackEffect$WriteTask net/java/games/input/LinuxForceFeedbackEffect WriteTask private,final
 method public,final write (I)V - java/io/IOException
 method protected,final execute ()Ljava/lang/Object; - java/io/IOException
in 24
class net/java/games/input/LinuxInputID 48 final,super java/lang/Object - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 method public <init> (IIII)V - -
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method public,final toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/LinuxJoystickAbstractController 48 final,super net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method protected <init> (Lnet/java/games/input/LinuxJoystickDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
 method public,final pollDevice ()V - java/io/IOException
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public getType ()Lnet/java/games/input/Controller$Type; - -
in 24
class net/java/games/input/LinuxJoystickAxis 48 super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method public <init> (Lnet/java/games/input/Component$Identifier$Axis;)V - -
 method public <init> (Lnet/java/games/input/Component$Identifier$Axis;Z)V - -
 method public,final isRelative ()Z - -
 method public,final isAnalog ()Z - -
 method protected,final poll ()F - java/io/IOException
in 24
class net/java/games/input/LinuxJoystickButton 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public <init> (Lnet/java/games/input/Component$Identifier;)V - -
 method public,final isRelative ()Z - -
 method protected,final poll ()F - java/io/IOException
in 24
class net/java/games/input/LinuxJoystickDevice 48 final,super java/lang/Object net/java/games/input/LinuxDevice -
 field public,static,final JS_EVENT_BUTTON I - I1
 field public,static,final JS_EVENT_AXIS I - I2
 field public,static,final JS_EVENT_INIT I - I128
 field public,static,final AXIS_MAX_VALUE I - I32767
 method public <init> (Ljava/lang/String;)V - java/io/IOException
 method public,final,synchronized setBufferSize (I)V - -
 method public,final registerAxis (ILnet/java/games/input/LinuxJoystickAxis;)V - -
 method public,final registerButton (ILnet/java/games/input/LinuxJoystickButton;)V - -
 method public,final registerPOV (Lnet/java/games/input/LinuxJoystickPOV;)V - -
 method public,final,synchronized getNextEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public,final,synchronized poll ()V - java/io/IOException
 method public,final getNumAxes ()I - -
 method public,final getNumButtons ()I - -
 method public,final getAxisMap ()[B - -
 method public,final getButtonMap ()[C - -
 method public,final getName ()Ljava/lang/String; - -
 method public,final,synchronized close ()V - java/io/IOException
 method protected finalize ()V - java/io/IOException
in 24
class net/java/games/input/LinuxJoystickEvent 48 final,super java/lang/Object - -
 method public,final set (JIII)V - -
 method public,final getValue ()I - -
 method public,final getType ()I - -
 method public,final getNumber ()I - -
 method public,final getNanos ()J - -
in 24
class net/java/games/input/LinuxJoystickPOV 48 public,super net/java/games/input/LinuxJoystickAxis - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method protected getXAxis ()Lnet/java/games/input/LinuxJoystickAxis; - -
 method protected getYAxis ()Lnet/java/games/input/LinuxJoystickAxis; - -
 method protected updateValue ()V - -
in 24
class net/java/games/input/LinuxKeyboard 48 final,super net/java/games/input/Keyboard - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 method protected <init> (Lnet/java/games/input/LinuxEventDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - java/io/IOException
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public,final pollDevice ()V - java/io/IOException
in 24
class net/java/games/input/LinuxMouse 48 final,super net/java/games/input/Mouse - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 method protected <init> (Lnet/java/games/input/LinuxEventDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - java/io/IOException
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method public,final pollDevice ()V - java/io/IOException
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
in 24
class net/java/games/input/LinuxNativeTypesMap 48 super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method public,static,final guessButtonTrait (I)Lnet/java/games/input/Controller$Type; - -
 method public,static getPortType (I)Lnet/java/games/input/Controller$PortType; - -
 method public,static getRelAxisID (I)Lnet/java/games/input/Component$Identifier; - -
 method public,static getAbsAxisID (I)Lnet/java/games/input/Component$Identifier; - -
 method public,static getButtonID (I)Lnet/java/games/input/Component$Identifier; - -
in 24
class net/java/games/input/LinuxPOV 48 final,super net/java/games/input/LinuxComponent - -
 method public <init> (Lnet/java/games/input/LinuxEventComponent;Lnet/java/games/input/LinuxEventComponent;)V - -
 method protected,final poll ()F - java/io/IOException
 method public convertValue (FLnet/java/games/input/LinuxAxisDescriptor;)F - -
in 24
class net/java/games/input/LinuxRumbleFF 48 final,super net/java/games/input/LinuxForceFeedbackEffect - -
 method public <init> (Lnet/java/games/input/LinuxEventDevice;)V - java/io/IOException
 method protected,final upload (IF)I - java/io/IOException
in 24
class net/java/games/input/Mouse 48 public,super,abstract net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 method protected <init> (Ljava/lang/String;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method public getType ()Lnet/java/games/input/Controller$Type; - -
 method public getX ()Lnet/java/games/input/Component; - -
 method public getY ()Lnet/java/games/input/Component; - -
 method public getWheel ()Lnet/java/games/input/Component; - -
 method public getPrimaryButton ()Lnet/java/games/input/Component; - -
 method public getSecondaryButton ()Lnet/java/games/input/Component; - -
 method public getTertiaryButton ()Lnet/java/games/input/Component; - -
 method public getLeft ()Lnet/java/games/input/Component; - -
 method public getRight ()Lnet/java/games/input/Component; - -
 method public getMiddle ()Lnet/java/games/input/Component; - -
 method public getSide ()Lnet/java/games/input/Component; - -
 method public getExtra ()Lnet/java/games/input/Component; - -
 method public getForward ()Lnet/java/games/input/Component; - -
 method public getBack ()Lnet/java/games/input/Component; - -
 method public getButton3 ()Lnet/java/games/input/Component; - -
 method public getButton4 ()Lnet/java/games/input/Component; - -
in 24
class net/java/games/input/NativeDefinitions 48 super java/lang/Object - -
 field public,static,final EV_VERSION I - I65537
 field public,static,final EV_SYN I - I0
 field public,static,final EV_KEY I - I1
 field public,static,final EV_REL I - I2
 field public,static,final EV_ABS I - I3
 field public,static,final EV_MSC I - I4
 field public,static,final EV_LED I - I17
 field public,static,final EV_SND I - I18
 field public,static,final EV_REP I - I20
 field public,static,final EV_FF I - I21
 field public,static,final EV_PWR I - I22
 field public,static,final EV_FF_STATUS I - I23
 field public,static,final EV_MAX I - I31
 field public,static,final KEY_RESERVED I - I0
 field public,static,final KEY_ESC I - I1
 field public,static,final KEY_1 I - I2
 field public,static,final KEY_2 I - I3
 field public,static,final KEY_3 I - I4
 field public,static,final KEY_4 I - I5
 field public,static,final KEY_5 I - I6
 field public,static,final KEY_6 I - I7
 field public,static,final KEY_7 I - I8
 field public,static,final KEY_8 I - I9
 field public,static,final KEY_9 I - I10
 field public,static,final KEY_0 I - I11
 field public,static,final KEY_MINUS I - I12
 field public,static,final KEY_EQUAL I - I13
 field public,static,final KEY_BACKSPACE I - I14
 field public,static,final KEY_TAB I - I15
 field public,static,final KEY_Q I - I16
 field public,static,final KEY_W I - I17
 field public,static,final KEY_E I - I18
 field public,static,final KEY_R I - I19
 field public,static,final KEY_T I - I20
 field public,static,final KEY_Y I - I21
 field public,static,final KEY_U I - I22
 field public,static,final KEY_I I - I23
 field public,static,final KEY_O I - I24
 field public,static,final KEY_P I - I25
 field public,static,final KEY_LEFTBRACE I - I26
 field public,static,final KEY_RIGHTBRACE I - I27
 field public,static,final KEY_ENTER I - I28
 field public,static,final KEY_LEFTCTRL I - I29
 field public,static,final KEY_A I - I30
 field public,static,final KEY_S I - I31
 field public,static,final KEY_D I - I32
 field public,static,final KEY_F I - I33
 field public,static,final KEY_G I - I34
 field public,static,final KEY_H I - I35
 field public,static,final KEY_J I - I36
 field public,static,final KEY_K I - I37
 field public,static,final KEY_L I - I38
 field public,static,final KEY_SEMICOLON I - I39
 field public,static,final KEY_APOSTROPHE I - I40
 field public,static,final KEY_GRAVE I - I41
 field public,static,final KEY_LEFTSHIFT I - I42
 field public,static,final KEY_BACKSLASH I - I43
 field public,static,final KEY_Z I - I44
 field public,static,final KEY_X I - I45
 field public,static,final KEY_C I - I46
 field public,static,final KEY_V I - I47
 field public,static,final KEY_B I - I48
 field public,static,final KEY_N I - I49
 field public,static,final KEY_M I - I50
 field public,static,final KEY_COMMA I - I51
 field public,static,final KEY_DOT I - I52
 field public,static,final KEY_SLASH I - I53
 field public,static,final KEY_RIGHTSHIFT I - I54
 field public,static,final KEY_KPASTERISK I - I55
 field public,static,final KEY_LEFTALT I - I56
 field public,static,final KEY_SPACE I - I57
 field public,static,final KEY_CAPSLOCK I - I58
 field public,static,final KEY_F1 I - I59
 field public,static,final KEY_F2 I - I60
 field public,static,final KEY_F3 I - I61
 field public,static,final KEY_F4 I - I62
 field public,static,final KEY_F5 I - I63
 field public,static,final KEY_F6 I - I64
 field public,static,final KEY_F7 I - I65
 field public,static,final KEY_F8 I - I66
 field public,static,final KEY_F9 I - I67
 field public,static,final KEY_F10 I - I68
 field public,static,final KEY_NUMLOCK I - I69
 field public,static,final KEY_SCROLLLOCK I - I70
 field public,static,final KEY_KP7 I - I71
 field public,static,final KEY_KP8 I - I72
 field public,static,final KEY_KP9 I - I73
 field public,static,final KEY_KPMINUS I - I74
 field public,static,final KEY_KP4 I - I75
 field public,static,final KEY_KP5 I - I76
 field public,static,final KEY_KP6 I - I77
 field public,static,final KEY_KPPLUS I - I78
 field public,static,final KEY_KP1 I - I79
 field public,static,final KEY_KP2 I - I80
 field public,static,final KEY_KP3 I - I81
 field public,static,final KEY_KP0 I - I82
 field public,static,final KEY_KPDOT I - I83
 field public,static,final KEY_ZENKAKUHANKAKU I - I85
 field public,static,final KEY_102ND I - I86
 field public,static,final KEY_F11 I - I87
 field public,static,final KEY_F12 I - I88
 field public,static,final KEY_RO I - I89
 field public,static,final KEY_KATAKANA I - I90
 field public,static,final KEY_HIRAGANA I - I91
 field public,static,final KEY_HENKAN I - I92
 field public,static,final KEY_KATAKANAHIRAGANA I - I93
 field public,static,final KEY_MUHENKAN I - I94
 field public,static,final KEY_KPJPCOMMA I - I95
 field public,static,final KEY_KPENTER I - I96
 field public,static,final KEY_RIGHTCTRL I - I97
 field public,static,final KEY_KPSLASH I - I98
 field public,static,final KEY_SYSRQ I - I99
 field public,static,final KEY_RIGHTALT I - I100
 field public,static,final KEY_LINEFEED I - I101
 field public,static,final KEY_HOME I - I102
 field public,static,final KEY_UP I - I103
 field public,static,final KEY_PAGEUP I - I104
 field public,static,final KEY_LEFT I - I105
 field public,static,final KEY_RIGHT I - I106
 field public,static,final KEY_END I - I107
 field public,static,final KEY_DOWN I - I108
 field public,static,final KEY_PAGEDOWN I - I109
 field public,static,final KEY_INSERT I - I110
 field public,static,final KEY_DELETE I - I111
 field public,static,final KEY_MACRO I - I112
 field public,static,final KEY_MUTE I - I113
 field public,static,final KEY_VOLUMEDOWN I - I114
 field public,static,final KEY_VOLUMEUP I - I115
 field public,static,final KEY_POWER I - I116
 field public,static,final KEY_KPEQUAL I - I117
 field public,static,final KEY_KPPLUSMINUS I - I118
 field public,static,final KEY_PAUSE I - I119
 field public,static,final KEY_KPCOMMA I - I121
 field public,static,final KEY_HANGUEL I - I122
 field public,static,final KEY_HANJA I - I123
 field public,static,final KEY_YEN I - I124
 field public,static,final KEY_LEFTMETA I - I125
 field public,static,final KEY_RIGHTMETA I - I126
 field public,static,final KEY_COMPOSE I - I127
 field public,static,final KEY_STOP I - I128
 field public,static,final KEY_AGAIN I - I129
 field public,static,final KEY_PROPS I - I130
 field public,static,final KEY_UNDO I - I131
 field public,static,final KEY_FRONT I - I132
 field public,static,final KEY_COPY I - I133
 field public,static,final KEY_OPEN I - I134
 field public,static,final KEY_PASTE I - I135
 field public,static,final KEY_FIND I - I136
 field public,static,final KEY_CUT I - I137
 field public,static,final KEY_HELP I - I138
 field public,static,final KEY_MENU I - I139
 field public,static,final KEY_CALC I - I140
 field public,static,final KEY_SETUP I - I141
 field public,static,final KEY_SLEEP I - I142
 field public,static,final KEY_WAKEUP I - I143
 field public,static,final KEY_FILE I - I144
 field public,static,final KEY_SENDFILE I - I145
 field public,static,final KEY_DELETEFILE I - I146
 field public,static,final KEY_XFER I - I147
 field public,static,final KEY_PROG1 I - I148
 field public,static,final KEY_PROG2 I - I149
 field public,static,final KEY_WWW I - I150
 field public,static,final KEY_MSDOS I - I151
 field public,static,final KEY_COFFEE I - I152
 field public,static,final KEY_DIRECTION I - I153
 field public,static,final KEY_CYCLEWINDOWS I - I154
 field public,static,final KEY_MAIL I - I155
 field public,static,final KEY_BOOKMARKS I - I156
 field public,static,final KEY_COMPUTER I - I157
 field public,static,final KEY_BACK I - I158
 field public,static,final KEY_FORWARD I - I159
 field public,static,final KEY_CLOSECD I - I160
 field public,static,final KEY_EJECTCD I - I161
 field public,static,final KEY_EJECTCLOSECD I - I162
 field public,static,final KEY_NEXTSONG I - I163
 field public,static,final KEY_PLAYPAUSE I - I164
 field public,static,final KEY_PREVIOUSSONG I - I165
 field public,static,final KEY_STOPCD I - I166
 field public,static,final KEY_RECORD I - I167
 field public,static,final KEY_REWIND I - I168
 field public,static,final KEY_PHONE I - I169
 field public,static,final KEY_ISO I - I170
 field public,static,final KEY_CONFIG I - I171
 field public,static,final KEY_HOMEPAGE I - I172
 field public,static,final KEY_REFRESH I - I173
 field public,static,final KEY_EXIT I - I174
 field public,static,final KEY_MOVE I - I175
 field public,static,final KEY_EDIT I - I176
 field public,static,final KEY_SCROLLUP I - I177
 field public,static,final KEY_SCROLLDOWN I - I178
 field public,static,final KEY_KPLEFTPAREN I - I179
 field public,static,final KEY_KPRIGHTPAREN I - I180
 field public,static,final KEY_F13 I - I183
 field public,static,final KEY_F14 I - I184
 field public,static,final KEY_F15 I - I185
 field public,static,final KEY_F16 I - I186
 field public,static,final KEY_F17 I - I187
 field public,static,final KEY_F18 I - I188
 field public,static,final KEY_F19 I - I189
 field public,static,final KEY_F20 I - I190
 field public,static,final KEY_F21 I - I191
 field public,static,final KEY_F22 I - I192
 field public,static,final KEY_F23 I - I193
 field public,static,final KEY_F24 I - I194
 field public,static,final KEY_PLAYCD I - I200
 field public,static,final KEY_PAUSECD I - I201
 field public,static,final KEY_PROG3 I - I202
 field public,static,final KEY_PROG4 I - I203
 field public,static,final KEY_SUSPEND I - I205
 field public,static,final KEY_CLOSE I - I206
 field public,static,final KEY_PLAY I - I207
 field public,static,final KEY_FASTFORWARD I - I208
 field public,static,final KEY_BASSBOOST I - I209
 field public,static,final KEY_PRINT I - I210
 field public,static,final KEY_HP I - I211
 field public,static,final KEY_CAMERA I - I212
 field public,static,final KEY_SOUND I - I213
 field public,static,final KEY_QUESTION I - I214
 field public,static,final KEY_EMAIL I - I215
 field public,static,final KEY_CHAT I - I216
 field public,static,final KEY_SEARCH I - I217
 field public,static,final KEY_CONNECT I - I218
 field public,static,final KEY_FINANCE I - I219
 field public,static,final KEY_SPORT I - I220
 field public,static,final KEY_SHOP I - I221
 field public,static,final KEY_ALTERASE I - I222
 field public,static,final KEY_CANCEL I - I223
 field public,static,final KEY_BRIGHTNESSDOWN I - I224
 field public,static,final KEY_BRIGHTNESSUP I - I225
 field public,static,final KEY_MEDIA I - I226
 field public,static,final KEY_SWITCHVIDEOMODE I - I227
 field public,static,final KEY_KBDILLUMTOGGLE I - I228
 field public,static,final KEY_KBDILLUMDOWN I - I229
 field public,static,final KEY_KBDILLUMUP I - I230
 field public,static,final KEY_UNKNOWN I - I240
 field public,static,final BTN_MISC I - I256
 field public,static,final BTN_0 I - I256
 field public,static,final BTN_1 I - I257
 field public,static,final BTN_2 I - I258
 field public,static,final BTN_3 I - I259
 field public,static,final BTN_4 I - I260
 field public,static,final BTN_5 I - I261
 field public,static,final BTN_6 I - I262
 field public,static,final BTN_7 I - I263
 field public,static,final BTN_8 I - I264
 field public,static,final BTN_9 I - I265
 field public,static,final BTN_MOUSE I - I272
 field public,static,final BTN_LEFT I - I272
 field public,static,final BTN_RIGHT I - I273
 field public,static,final BTN_MIDDLE I - I274
 field public,static,final BTN_SIDE I - I275
 field public,static,final BTN_EXTRA I - I276
 field public,static,final BTN_FORWARD I - I277
 field public,static,final BTN_BACK I - I278
 field public,static,final BTN_TASK I - I279
 field public,static,final BTN_JOYSTICK I - I288
 field public,static,final BTN_TRIGGER I - I288
 field public,static,final BTN_THUMB I - I289
 field public,static,final BTN_THUMB2 I - I290
 field public,static,final BTN_TOP I - I291
 field public,static,final BTN_TOP2 I - I292
 field public,static,final BTN_PINKIE I - I293
 field public,static,final BTN_BASE I - I294
 field public,static,final BTN_BASE2 I - I295
 field public,static,final BTN_BASE3 I - I296
 field public,static,final BTN_BASE4 I - I297
 field public,static,final BTN_BASE5 I - I298
 field public,static,final BTN_BASE6 I - I299
 field public,static,final BTN_DEAD I - I303
 field public,static,final BTN_GAMEPAD I - I304
 field public,static,final BTN_A I - I304
 field public,static,final BTN_B I - I305
 field public,static,final BTN_C I - I306
 field public,static,final BTN_X I - I307
 field public,static,final BTN_Y I - I308
 field public,static,final BTN_Z I - I309
 field public,static,final BTN_TL I - I310
 field public,static,final BTN_TR I - I311
 field public,static,final BTN_TL2 I - I312
 field public,static,final BTN_TR2 I - I313
 field public,static,final BTN_SELECT I - I314
 field public,static,final BTN_START I - I315
 field public,static,final BTN_MODE I - I316
 field public,static,final BTN_THUMBL I - I317
 field public,static,final BTN_THUMBR I - I318
 field public,static,final BTN_DIGI I - I320
 field public,static,final BTN_TOOL_PEN I - I320
 field public,static,final BTN_TOOL_RUBBER I - I321
 field public,static,final BTN_TOOL_BRUSH I - I322
 field public,static,final BTN_TOOL_PENCIL I - I323
 field public,static,final BTN_TOOL_AIRBRUSH I - I324
 field public,static,final BTN_TOOL_FINGER I - I325
 field public,static,final BTN_TOOL_MOUSE I - I326
 field public,static,final BTN_TOOL_LENS I - I327
 field public,static,final BTN_TOUCH I - I330
 field public,static,final BTN_STYLUS I - I331
 field public,static,final BTN_STYLUS2 I - I332
 field public,static,final BTN_TOOL_DOUBLETAP I - I333
 field public,static,final BTN_TOOL_TRIPLETAP I - I334
 field public,static,final BTN_WHEEL I - I336
 field public,static,final BTN_GEAR_DOWN I - I336
 field public,static,final BTN_GEAR_UP I - I337
 field public,static,final KEY_OK I - I352
 field public,static,final KEY_SELECT I - I353
 field public,static,final KEY_GOTO I - I354
 field public,static,final KEY_CLEAR I - I355
 field public,static,final KEY_POWER2 I - I356
 field public,static,final KEY_OPTION I - I357
 field public,static,final KEY_INFO I - I358
 field public,static,final KEY_TIME I - I359
 field public,static,final KEY_VENDOR I - I360
 field public,static,final KEY_ARCHIVE I - I361
 field public,static,final KEY_PROGRAM I - I362
 field public,static,final KEY_CHANNEL I - I363
 field public,static,final KEY_FAVORITES I - I364
 field public,static,final KEY_EPG I - I365
 field public,static,final KEY_PVR I - I366
 field public,static,final KEY_MHP I - I367
 field public,static,final KEY_LANGUAGE I - I368
 field public,static,final KEY_TITLE I - I369
 field public,static,final KEY_SUBTITLE I - I370
 field public,static,final KEY_ANGLE I - I371
 field public,static,final KEY_ZOOM I - I372
 field public,static,final KEY_MODE I - I373
 field public,static,final KEY_KEYBOARD I - I374
 field public,static,final KEY_SCREEN I - I375
 field public,static,final KEY_PC I - I376
 field public,static,final KEY_TV I - I377
 field public,static,final KEY_TV2 I - I378
 field public,static,final KEY_VCR I - I379
 field public,static,final KEY_VCR2 I - I380
 field public,static,final KEY_SAT I - I381
 field public,static,final KEY_SAT2 I - I382
 field public,static,final KEY_CD I - I383
 field public,static,final KEY_TAPE I - I384
 field public,static,final KEY_RADIO I - I385
 field public,static,final KEY_TUNER I - I386
 field public,static,final KEY_PLAYER I - I387
 field public,static,final KEY_TEXT I - I388
 field public,static,final KEY_DVD I - I389
 field public,static,final KEY_AUX I - I390
 field public,static,final KEY_MP3 I - I391
 field public,static,final KEY_AUDIO I - I392
 field public,static,final KEY_VIDEO I - I393
 field public,static,final KEY_DIRECTORY I - I394
 field public,static,final KEY_LIST I - I395
 field public,static,final KEY_MEMO I - I396
 field public,static,final KEY_CALENDAR I - I397
 field public,static,final KEY_RED I - I398
 field public,static,final KEY_GREEN I - I399
 field public,static,final KEY_YELLOW I - I400
 field public,static,final KEY_BLUE I - I401
 field public,static,final KEY_CHANNELUP I - I402
 field public,static,final KEY_CHANNELDOWN I - I403
 field public,static,final KEY_FIRST I - I404
 field public,static,final KEY_LAST I - I405
 field public,static,final KEY_AB I - I406
 field public,static,final KEY_NEXT I - I407
 field public,static,final KEY_RESTART I - I408
 field public,static,final KEY_SLOW I - I409
 field public,static,final KEY_SHUFFLE I - I410
 field public,static,final KEY_BREAK I - I411
 field public,static,final KEY_PREVIOUS I - I412
 field public,static,final KEY_DIGITS I - I413
 field public,static,final KEY_TEEN I - I414
 field public,static,final KEY_TWEN I - I415
 field public,static,final KEY_DEL_EOL I - I448
 field public,static,final KEY_DEL_EOS I - I449
 field public,static,final KEY_INS_LINE I - I450
 field public,static,final KEY_DEL_LINE I - I451
 field public,static,final KEY_FN I - I464
 field public,static,final KEY_FN_ESC I - I465
 field public,static,final KEY_FN_F1 I - I466
 field public,static,final KEY_FN_F2 I - I467
 field public,static,final KEY_FN_F3 I - I468
 field public,static,final KEY_FN_F4 I - I469
 field public,static,final KEY_FN_F5 I - I470
 field public,static,final KEY_FN_F6 I - I471
 field public,static,final KEY_FN_F7 I - I472
 field public,static,final KEY_FN_F8 I - I473
 field public,static,final KEY_FN_F9 I - I474
 field public,static,final KEY_FN_F10 I - I475
 field public,static,final KEY_FN_F11 I - I476
 field public,static,final KEY_FN_F12 I - I477
 field public,static,final KEY_FN_1 I - I478
 field public,static,final KEY_FN_2 I - I479
 field public,static,final KEY_FN_D I - I480
 field public,static,final KEY_FN_E I - I481
 field public,static,final KEY_FN_F I - I482
 field public,static,final KEY_FN_S I - I483
 field public,static,final KEY_FN_B I - I484
 field public,static,final KEY_MAX I - I511
 field public,static,final REL_X I - I0
 field public,static,final REL_Y I - I1
 field public,static,final REL_Z I - I2
 field public,static,final REL_RX I - I3
 field public,static,final REL_RY I - I4
 field public,static,final REL_RZ I - I5
 field public,static,final REL_HWHEEL I - I6
 field public,static,final REL_DIAL I - I7
 field public,static,final REL_WHEEL I - I8
 field public,static,final REL_MISC I - I9
 field public,static,final REL_MAX I - I15
 field public,static,final ABS_X I - I0
 field public,static,final ABS_Y I - I1
 field public,static,final ABS_Z I - I2
 field public,static,final ABS_RX I - I3
 field public,static,final ABS_RY I - I4
 field public,static,final ABS_RZ I - I5
 field public,static,final ABS_THROTTLE I - I6
 field public,static,final ABS_RUDDER I - I7
 field public,static,final ABS_WHEEL I - I8
 field public,static,final ABS_GAS I - I9
 field public,static,final ABS_BRAKE I - I10
 field public,static,final ABS_HAT0X I - I16
 field public,static,final ABS_HAT0Y I - I17
 field public,static,final ABS_HAT1X I - I18
 field public,static,final ABS_HAT1Y I - I19
 field public,static,final ABS_HAT2X I - I20
 field public,static,final ABS_HAT2Y I - I21
 field public,static,final ABS_HAT3X I - I22
 field public,static,final ABS_HAT3Y I - I23
 field public,static,final ABS_PRESSURE I - I24
 field public,static,final ABS_DISTANCE I - I25
 field public,static,final ABS_TILT_X I - I26
 field public,static,final ABS_TILT_Y I - I27
 field public,static,final ABS_TOOL_WIDTH I - I28
 field public,static,final ABS_VOLUME I - I32
 field public,static,final ABS_MISC I - I40
 field public,static,final ABS_MAX I - I63
 field public,static,final USAGE_MOUSE I - I0
 field public,static,final USAGE_JOYSTICK I - I1
 field public,static,final USAGE_GAMEPAD I - I2
 field public,static,final USAGE_KEYBOARD I - I3
 field public,static,final USAGE_MAX I - I15
 field public,static,final BUS_PCI I - I1
 field public,static,final BUS_ISAPNP I - I2
 field public,static,final BUS_USB I - I3
 field public,static,final BUS_HIL I - I4
 field public,static,final BUS_BLUETOOTH I - I5
 field public,static,final BUS_ISA I - I16
 field public,static,final BUS_I8042 I - I17
 field public,static,final BUS_XTKBD I - I18
 field public,static,final BUS_RS232 I - I19
 field public,static,final BUS_GAMEPORT I - I20
 field public,static,final BUS_PARPORT I - I21
 field public,static,final BUS_AMIGA I - I22
 field public,static,final BUS_ADB I - I23
 field public,static,final BUS_I2C I - I24
 field public,static,final BUS_HOST I - I25
 field public,static,final FF_STATUS_STOPPED I - I0
 field public,static,final FF_STATUS_PLAYING I - I1
 field public,static,final FF_STATUS_MAX I - I1
 field public,static,final FF_RUMBLE I - I80
 field public,static,final FF_PERIODIC I - I81
 field public,static,final FF_CONSTANT I - I82
 field public,static,final FF_SPRING I - I83
 field public,static,final FF_FRICTION I - I84
 field public,static,final FF_DAMPER I - I85
 field public,static,final FF_INERTIA I - I86
 field public,static,final FF_RAMP I - I87
 field public,static,final FF_SQUARE I - I88
 field public,static,final FF_TRIANGLE I - I89
 field public,static,final FF_SINE I - I90
 field public,static,final FF_SAW_UP I - I91
 field public,static,final FF_SAW_DOWN I - I92
 field public,static,final FF_CUSTOM I - I93
 field public,static,final FF_GAIN I - I96
 field public,static,final FF_AUTOCENTER I - I97
 field public,static,final FF_MAX I - I127
in 24
class net/java/games/input/OSXAbstractController 48 final,super net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method protected <init> (Lnet/java/games/input/OSXHIDDevice;Lnet/java/games/input/OSXHIDQueue;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;Lnet/java/games/input/Controller$Type;)V - -
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
 method public getType ()Lnet/java/games/input/Controller$Type; - -
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
in 24
class net/java/games/input/OSXComponent 48 super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public <init> (Lnet/java/games/input/Component$Identifier;Lnet/java/games/input/OSXHIDElement;)V - -
 method public,final isRelative ()Z - -
 method public isAnalog ()Z - -
 method public,final getElement ()Lnet/java/games/input/OSXHIDElement; - -
 method protected poll ()F - java/io/IOException
in 24
class net/java/games/input/OSXControllers 48 final,super java/lang/Object - -
 method public,static,final,synchronized poll (Lnet/java/games/input/OSXHIDElement;)F - java/io/IOException
 method public,static,final,synchronized getNextDeviceEvent (Lnet/java/games/input/Event;Lnet/java/games/input/OSXHIDQueue;)Z - java/io/IOException
in 24
class net/java/games/input/OSXEnvironmentPlugin 48 public,final,super net/java/games/input/ControllerEnvironment net/java/games/util/plugins/Plugin -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 method public <init> ()V - -
 method public,final getControllers ()[Lnet/java/games/input/Controller; - -
 method public isSupported ()Z - -
in 24
class net/java/games/input/OSXEvent 48 super java/lang/Object - -
 method public set (JJIJ)V - -
 method public getType ()J - -
 method public getCookie ()J - -
 method public getValue ()I - -
 method public getNanos ()J - -
in 24
class net/java/games/input/OSXHIDDevice 48 final,super java/lang/Object - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 method public <init> (JJ)V - java/io/IOException
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
 method public,final getProductName ()Ljava/lang/String; - -
 method public,final getElements ()Ljava/util/List; - -
 method public,final getUsagePair ()Lnet/java/games/input/UsagePair; - -
 method public,final,synchronized release ()V - java/io/IOException
 method public,final,synchronized getElementValue (JLnet/java/games/input/OSXEvent;)V - java/io/IOException
 method public,final,synchronized createQueue (I)Lnet/java/games/input/OSXHIDQueue; - java/io/IOException
in 24
class net/java/games/input/OSXHIDDeviceIterator 48 final,super java/lang/Object - -
 method public <init> ()V - java/io/IOException
 method public,final close ()V - -
 method public,final next ()Lnet/java/games/input/OSXHIDDevice; - java/io/IOException
in 24
class net/java/games/input/OSXHIDElement 48 final,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 method public <init> (Lnet/java/games/input/OSXHIDDevice;Lnet/java/games/input/UsagePair;JLnet/java/games/input/ElementType;IIZ)V - -
in 24
class net/java/games/input/OSXHIDQueue 48 final,super java/lang/Object - -
 method public <init> (JI)V - java/io/IOException
 method public,final,synchronized setQueueDepth (I)V - java/io/IOException
 method public,final mapEvent (Lnet/java/games/input/OSXEvent;)Lnet/java/games/input/OSXComponent; - -
 method public,final,synchronized release ()V - java/io/IOException
 method public,final addElement (Lnet/java/games/input/OSXHIDElement;Lnet/java/games/input/OSXComponent;)V - java/io/IOException
 method public,final removeElement (Lnet/java/games/input/OSXHIDElement;)V - java/io/IOException
 method public,final,synchronized getNextEvent (Lnet/java/games/input/OSXEvent;)Z - java/io/IOException
in 24
class net/java/games/input/OSXKeyboard 48 final,super net/java/games/input/Keyboard - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 method protected <init> (Lnet/java/games/input/OSXHIDDevice;Lnet/java/games/input/OSXHIDQueue;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
in 24
class net/java/games/input/OSXMouse 48 final,super net/java/games/input/Mouse - -
 inner net/java/games/input/Controller$PortType net/java/games/input/Controller PortType public,static,final
 method protected <init> (Lnet/java/games/input/OSXHIDDevice;Lnet/java/games/input/OSXHIDQueue;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - -
 method protected,final getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
 method public,final getPortType ()Lnet/java/games/input/Controller$PortType; - -
in 24
class net/java/games/input/PluginClassLoader 48 super java/lang/ClassLoader - -
 inner net/java/games/input/PluginClassLoader$JarFileFilter net/java/games/input/PluginClassLoader JarFileFilter private,static
 method public <init> ()V - -
 method protected findClass (Ljava/lang/String;)Ljava/lang/Class; - java/lang/ClassNotFoundException
in 24
class net/java/games/input/PluginClassLoader$JarFileFilter 48 super java/lang/Object java/io/FileFilter -
 inner net/java/games/input/PluginClassLoader$JarFileFilter net/java/games/input/PluginClassLoader JarFileFilter private,static
 method public accept (Ljava/io/File;)Z - -
in 24
class net/java/games/input/RawDevice 48 final,super java/lang/Object - -
 field public,static,final RI_MOUSE_LEFT_BUTTON_DOWN I - I1
 field public,static,final RI_MOUSE_LEFT_BUTTON_UP I - I2
 field public,static,final RI_MOUSE_RIGHT_BUTTON_DOWN I - I4
 field public,static,final RI_MOUSE_RIGHT_BUTTON_UP I - I8
 field public,static,final RI_MOUSE_MIDDLE_BUTTON_DOWN I - I16
 field public,static,final RI_MOUSE_MIDDLE_BUTTON_UP I - I32
 field public,static,final RI_MOUSE_BUTTON_1_DOWN I - I1
 field public,static,final RI_MOUSE_BUTTON_1_UP I - I2
 field public,static,final RI_MOUSE_BUTTON_2_DOWN I - I4
 field public,static,final RI_MOUSE_BUTTON_2_UP I - I8
 field public,static,final RI_MOUSE_BUTTON_3_DOWN I - I16
 field public,static,final RI_MOUSE_BUTTON_3_UP I - I32
 field public,static,final RI_MOUSE_BUTTON_4_DOWN I - I64
 field public,static,final RI_MOUSE_BUTTON_4_UP I - I128
 field public,static,final RI_MOUSE_BUTTON_5_DOWN I - I256
 field public,static,final RI_MOUSE_BUTTON_5_UP I - I512
 field public,static,final RI_MOUSE_WHEEL I - I1024
 field public,static,final MOUSE_MOVE_RELATIVE I - I0
 field public,static,final MOUSE_MOVE_ABSOLUTE I - I1
 field public,static,final MOUSE_VIRTUAL_DESKTOP I - I2
 field public,static,final MOUSE_ATTRIBUTES_CHANGED I - I4
 field public,static,final RIM_TYPEHID I - I2
 field public,static,final RIM_TYPEKEYBOARD I - I1
 field public,static,final RIM_TYPEMOUSE I - I0
 field public,static,final WM_KEYDOWN I - I256
 field public,static,final WM_KEYUP I - I257
 field public,static,final WM_SYSKEYDOWN I - I260
 field public,static,final WM_SYSKEYUP I - I261
 method public <init> (Lnet/java/games/input/RawInputEventQueue;JI)V - -
 method public,final,synchronized addMouseEvent (JIIIJJJJ)V - -
 method public,final,synchronized addKeyboardEvent (JIIIIJ)V - -
 method public,final,synchronized pollMouse ()V - -
 method public,final,synchronized pollKeyboard ()V - -
 method public,final isKeyDown (I)Z - -
 method public,final getWheel ()I - -
 method public,final getEventRelativeX ()I - -
 method public,final getEventRelativeY ()I - -
 method public,final getRelativeX ()I - -
 method public,final getRelativeY ()I - -
 method public,final,synchronized getNextKeyboardEvent (Lnet/java/games/input/RawKeyboardEvent;)Z - -
 method public,final,synchronized getNextMouseEvent (Lnet/java/games/input/RawMouseEvent;)Z - -
 method public,final getButtonState (I)Z - -
 method public,final setBufferSize (I)V - -
 method public,final getType ()I - -
 method public,final getHandle ()J - -
 method public,final getName ()Ljava/lang/String; - java/io/IOException
 method public,final getInfo ()Lnet/java/games/input/RawDeviceInfo; - java/io/IOException
in 24
class net/java/games/input/RawDeviceInfo 48 super,abstract java/lang/Object - -
 method public,abstract createControllerFromDevice (Lnet/java/games/input/RawDevice;Lnet/java/games/input/SetupAPIDevice;)Lnet/java/games/input/Controller; - java/io/IOException
 method public,abstract getUsage ()I - -
 method public,abstract getUsagePage ()I - -
 method public,abstract getHandle ()J - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public,final hashCode ()I - -
in 24
class net/java/games/input/RawHIDInfo 48 super net/java/games/input/RawDeviceInfo - -
 method public <init> (Lnet/java/games/input/RawDevice;IIIII)V - -
 method public,final getUsage ()I - -
 method public,final getUsagePage ()I - -
 method public,final getHandle ()J - -
 method public,final createControllerFromDevice (Lnet/java/games/input/RawDevice;Lnet/java/games/input/SetupAPIDevice;)Lnet/java/games/input/Controller; - java/io/IOException
in 24
class net/java/games/input/RawIdentifierMap 48 final,super java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 field public,static,final VK_LBUTTON I - I1
 field public,static,final VK_RBUTTON I - I2
 field public,static,final VK_CANCEL I - I3
 field public,static,final VK_MBUTTON I - I4
 field public,static,final VK_XBUTTON1 I - I5
 field public,static,final VK_XBUTTON2 I - I6
 field public,static,final VK_BACK I - I8
 field public,static,final VK_TAB I - I9
 field public,static,final VK_CLEAR I - I12
 field public,static,final VK_RETURN I - I13
 field public,static,final VK_SHIFT I - I16
 field public,static,final VK_CONTROL I - I17
 field public,static,final VK_MENU I - I18
 field public,static,final VK_PAUSE I - I19
 field public,static,final VK_CAPITAL I - I20
 field public,static,final VK_KANA I - I21
 field public,static,final VK_HANGEUL I - I21
 field public,static,final VK_HANGUL I - I21
 field public,static,final VK_JUNJA I - I23
 field public,static,final VK_FINAL I - I24
 field public,static,final VK_HANJA I - I25
 field public,static,final VK_KANJI I - I25
 field public,static,final VK_ESCAPE I - I27
 field public,static,final VK_CONVERT I - I28
 field public,static,final VK_NONCONVERT I - I29
 field public,static,final VK_ACCEPT I - I30
 field public,static,final VK_MODECHANGE I - I31
 field public,static,final VK_SPACE I - I32
 field public,static,final VK_PRIOR I - I33
 field public,static,final VK_NEXT I - I34
 field public,static,final VK_END I - I35
 field public,static,final VK_HOME I - I36
 field public,static,final VK_LEFT I - I37
 field public,static,final VK_UP I - I38
 field public,static,final VK_RIGHT I - I39
 field public,static,final VK_DOWN I - I40
 field public,static,final VK_SELECT I - I41
 field public,static,final VK_PRINT I - I42
 field public,static,final VK_EXECUTE I - I43
 field public,static,final VK_SNAPSHOT I - I44
 field public,static,final VK_INSERT I - I45
 field public,static,final VK_DELETE I - I46
 field public,static,final VK_HELP I - I47
 field public,static,final VK_0 I - I48
 field public,static,final VK_1 I - I49
 field public,static,final VK_2 I - I50
 field public,static,final VK_3 I - I51
 field public,static,final VK_4 I - I52
 field public,static,final VK_5 I - I53
 field public,static,final VK_6 I - I54
 field public,static,final VK_7 I - I55
 field public,static,final VK_8 I - I56
 field public,static,final VK_9 I - I57
 field public,static,final VK_A I - I65
 field public,static,final VK_B I - I66
 field public,static,final VK_C I - I67
 field public,static,final VK_D I - I68
 field public,static,final VK_E I - I69
 field public,static,final VK_F I - I70
 field public,static,final VK_G I - I71
 field public,static,final VK_H I - I72
 field public,static,final VK_I I - I73
 field public,static,final VK_J I - I74
 field public,static,final VK_K I - I75
 field public,static,final VK_L I - I76
 field public,static,final VK_M I - I77
 field public,static,final VK_N I - I78
 field public,static,final VK_O I - I79
 field public,static,final VK_P I - I80
 field public,static,final VK_Q I - I81
 field public,static,final VK_R I - I82
 field public,static,final VK_S I - I83
 field public,static,final VK_T I - I84
 field public,static,final VK_U I - I85
 field public,static,final VK_V I - I86
 field public,static,final VK_W I - I87
 field public,static,final VK_X I - I88
 field public,static,final VK_Y I - I89
 field public,static,final VK_Z I - I90
 field public,static,final VK_LWIN I - I91
 field public,static,final VK_RWIN I - I92
 field public,static,final VK_APPS I - I93
 field public,static,final VK_SLEEP I - I95
 field public,static,final VK_NUMPAD0 I - I96
 field public,static,final VK_NUMPAD1 I - I97
 field public,static,final VK_NUMPAD2 I - I98
 field public,static,final VK_NUMPAD3 I - I99
 field public,static,final VK_NUMPAD4 I - I100
 field public,static,final VK_NUMPAD5 I - I101
 field public,static,final VK_NUMPAD6 I - I102
 field public,static,final VK_NUMPAD7 I - I103
 field public,static,final VK_NUMPAD8 I - I104
 field public,static,final VK_NUMPAD9 I - I105
 field public,static,final VK_MULTIPLY I - I106
 field public,static,final VK_ADD I - I107
 field public,static,final VK_SEPARATOR I - I108
 field public,static,final VK_SUBTRACT I - I109
 field public,static,final VK_DECIMAL I - I110
 field public,static,final VK_DIVIDE I - I111
 field public,static,final VK_F1 I - I112
 field public,static,final VK_F2 I - I113
 field public,static,final VK_F3 I - I114
 field public,static,final VK_F4 I - I115
 field public,static,final VK_F5 I - I116
 field public,static,final VK_F6 I - I117
 field public,static,final VK_F7 I - I118
 field public,static,final VK_F8 I - I119
 field public,static,final VK_F9 I - I120
 field public,static,final VK_F10 I - I121
 field public,static,final VK_F11 I - I122
 field public,static,final VK_F12 I - I123
 field public,static,final VK_F13 I - I124
 field public,static,final VK_F14 I - I125
 field public,static,final VK_F15 I - I126
 field public,static,final VK_F16 I - I127
 field public,static,final VK_F17 I - I128
 field public,static,final VK_F18 I - I129
 field public,static,final VK_F19 I - I130
 field public,static,final VK_F20 I - I131
 field public,static,final VK_F21 I - I132
 field public,static,final VK_F22 I - I133
 field public,static,final VK_F23 I - I134
 field public,static,final VK_F24 I - I135
 field public,static,final VK_NUMLOCK I - I144
 field public,static,final VK_SCROLL I - I145
 field public,static,final VK_OEM_NEC_EQUAL I - I146
 field public,static,final VK_OEM_FJ_JISHO I - I146
 field public,static,final VK_OEM_FJ_MASSHOU I - I147
 field public,static,final VK_OEM_FJ_TOUROKU I - I148
 field public,static,final VK_OEM_FJ_LOYA I - I149
 field public,static,final VK_OEM_FJ_ROYA I - I150
 field public,static,final VK_LSHIFT I - I160
 field public,static,final VK_RSHIFT I - I161
 field public,static,final VK_LCONTROL I - I162
 field public,static,final VK_RCONTROL I - I163
 field public,static,final VK_LMENU I - I164
 field public,static,final VK_RMENU I - I165
 field public,static,final VK_BROWSER_BACK I - I166
 field public,static,final VK_BROWSER_FORWARD I - I167
 field public,static,final VK_BROWSER_REFRESH I - I168
 field public,static,final VK_BROWSER_STOP I - I169
 field public,static,final VK_BROWSER_SEARCH I - I170
 field public,static,final VK_BROWSER_FAVORITES I - I171
 field public,static,final VK_BROWSER_HOME I - I172
 field public,static,final VK_VOLUME_MUTE I - I173
 field public,static,final VK_VOLUME_DOWN I - I174
 field public,static,final VK_VOLUME_UP I - I175
 field public,static,final VK_MEDIA_NEXT_TRACK I - I176
 field public,static,final VK_MEDIA_PREV_TRACK I - I177
 field public,static,final VK_MEDIA_STOP I - I178
 field public,static,final VK_MEDIA_PLAY_PAUSE I - I179
 field public,static,final VK_LAUNCH_MAIL I - I180
 field public,static,final VK_LAUNCH_MEDIA_SELECT I - I181
 field public,static,final VK_LAUNCH_APP1 I - I182
 field public,static,final VK_LAUNCH_APP2 I - I183
 field public,static,final VK_OEM_1 I - I186
 field public,static,final VK_OEM_PLUS I - I187
 field public,static,final VK_OEM_COMMA I - I188
 field public,static,final VK_OEM_MINUS I - I189
 field public,static,final VK_OEM_PERIOD I - I190
 field public,static,final VK_OEM_2 I - I191
 field public,static,final VK_OEM_3 I - I192
 field public,static,final VK_OEM_4 I - I219
 field public,static,final VK_OEM_5 I - I220
 field public,static,final VK_OEM_6 I - I221
 field public,static,final VK_OEM_7 I - I222
 field public,static,final VK_OEM_8 I - I223
 field public,static,final VK_OEM_AX I - I225
 field public,static,final VK_OEM_102 I - I226
 field public,static,final VK_ICO_HELP I - I227
 field public,static,final VK_ICO_00 I - I228
 field public,static,final VK_PROCESSKEY I - I229
 field public,static,final VK_ICO_CLEAR I - I230
 field public,static,final VK_PACKET I - I231
 field public,static,final VK_OEM_RESET I - I233
 field public,static,final VK_OEM_JUMP I - I234
 field public,static,final VK_OEM_PA1 I - I235
 field public,static,final VK_OEM_PA2 I - I236
 field public,static,final VK_OEM_PA3 I - I237
 field public,static,final VK_OEM_WSCTRL I - I238
 field public,static,final VK_OEM_CUSEL I - I239
 field public,static,final VK_OEM_ATTN I - I240
 field public,static,final VK_OEM_FINISH I - I241
 field public,static,final VK_OEM_COPY I - I242
 field public,static,final VK_OEM_AUTO I - I243
 field public,static,final VK_OEM_ENLW I - I244
 field public,static,final VK_OEM_BACKTAB I - I245
 field public,static,final VK_ATTN I - I246
 field public,static,final VK_CRSEL I - I247
 field public,static,final VK_EXSEL I - I248
 field public,static,final VK_EREOF I - I249
 field public,static,final VK_PLAY I - I250
 field public,static,final VK_ZOOM I - I251
 field public,static,final VK_NONAME I - I252
 field public,static,final VK_PA1 I - I253
 field public,static,final VK_OEM_CLEAR I - I254
 method public,static,final mapVKey (I)Lnet/java/games/input/Component$Identifier$Key; - -
in 24
class net/java/games/input/RawInputEnvironmentPlugin 48 public,final,super net/java/games/input/ControllerEnvironment net/java/games/util/plugins/Plugin -
 method public <init> ()V - -
 method public,final getControllers ()[Lnet/java/games/input/Controller; - -
 method public isSupported ()Z - -
in 24
class net/java/games/input/RawInputEventQueue 48 final,super java/lang/Object - -
 inner net/java/games/input/RawInputEventQueue$QueueThread net/java/games/input/RawInputEventQueue QueueThread private,final
 method public,final start (Ljava/util/List;)V - java/io/IOException
in 24
class net/java/games/input/RawInputEventQueue$QueueThread 48 final,super java/lang/Thread - -
 inner net/java/games/input/RawInputEventQueue$QueueThread net/java/games/input/RawInputEventQueue QueueThread private,final
 method public <init> (Lnet/java/games/input/RawInputEventQueue;)V - -
 method public,final isInitialized ()Z - -
 method public,final getException ()Ljava/io/IOException; - -
 method public,final run ()V - -
in 24
class net/java/games/input/RawKeyboard 48 final,super net/java/games/input/Keyboard - -
 inner net/java/games/input/RawKeyboard$Key net/java/games/input/RawKeyboard Key static,final
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 method protected <init> (Ljava/lang/String;Lnet/java/games/input/RawDevice;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - java/io/IOException
 method protected,final,synchronized getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method public,final pollDevice ()V - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
in 24
class net/java/games/input/RawKeyboard$Key 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Key net/java/games/input/Component$Identifier Key public,static
 inner net/java/games/input/RawKeyboard$Key net/java/games/input/RawKeyboard Key static,final
 method public <init> (Lnet/java/games/input/RawDevice;ILnet/java/games/input/Component$Identifier$Key;)V - -
 method protected,final poll ()F - java/io/IOException
 method public,final isAnalog ()Z - -
 method public,final isRelative ()Z - -
in 24
class net/java/games/input/RawKeyboardEvent 48 final,super java/lang/Object - -
 method public,final set (JIIIIJ)V - -
 method public,final set (Lnet/java/games/input/RawKeyboardEvent;)V - -
 method public,final getVKey ()I - -
 method public,final getMessage ()I - -
 method public,final getNanos ()J - -
in 24
class net/java/games/input/RawKeyboardInfo 48 super net/java/games/input/RawDeviceInfo - -
 method public <init> (Lnet/java/games/input/RawDevice;IIIIII)V - -
 method public,final getUsage ()I - -
 method public,final getUsagePage ()I - -
 method public,final getHandle ()J - -
 method public,final createControllerFromDevice (Lnet/java/games/input/RawDevice;Lnet/java/games/input/SetupAPIDevice;)Lnet/java/games/input/Controller; - java/io/IOException
in 24
class net/java/games/input/RawMouse 48 final,super net/java/games/input/Mouse - -
 inner net/java/games/input/RawMouse$Button net/java/games/input/RawMouse Button static,final
 inner net/java/games/input/RawMouse$Axis net/java/games/input/RawMouse Axis static,final
 method protected <init> (Ljava/lang/String;Lnet/java/games/input/RawDevice;[Lnet/java/games/input/Component;[Lnet/java/games/input/Controller;[Lnet/java/games/input/Rumbler;)V - java/io/IOException
 method public,final pollDevice ()V - java/io/IOException
 method protected,final,synchronized getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected,final setDeviceEventQueueSize (I)V - java/io/IOException
in 24
class net/java/games/input/RawMouse$Axis 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 inner net/java/games/input/RawMouse$Axis net/java/games/input/RawMouse Axis static,final
 method public <init> (Lnet/java/games/input/RawDevice;Lnet/java/games/input/Component$Identifier$Axis;)V - -
 method public,final isRelative ()Z - -
 method public,final isAnalog ()Z - -
 method protected,final poll ()F - java/io/IOException
in 24
class net/java/games/input/RawMouse$Button 48 final,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/RawMouse$Button net/java/games/input/RawMouse Button static,final
 method public <init> (Lnet/java/games/input/RawDevice;Lnet/java/games/input/Component$Identifier$Button;I)V - -
 method protected,final poll ()F - java/io/IOException
 method public,final isAnalog ()Z - -
 method public,final isRelative ()Z - -
in 24
class net/java/games/input/RawMouseEvent 48 final,super java/lang/Object - -
 method public,final set (JIIIJJJJ)V - -
 method public,final set (Lnet/java/games/input/RawMouseEvent;)V - -
 method public,final getWheelDelta ()I - -
 method public,final getFlags ()I - -
 method public,final getButtonFlags ()I - -
 method public,final getLastX ()I - -
 method public,final getLastY ()I - -
 method public,final getRawButtons ()J - -
 method public,final getNanos ()J - -
in 24
class net/java/games/input/RawMouseInfo 48 super net/java/games/input/RawDeviceInfo - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 inner net/java/games/input/RawMouse$Axis net/java/games/input/RawMouse Axis static,final
 inner net/java/games/input/RawMouse$Button net/java/games/input/RawMouse Button static,final
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 method public <init> (Lnet/java/games/input/RawDevice;III)V - -
 method public,final getUsage ()I - -
 method public,final getUsagePage ()I - -
 method public,final getHandle ()J - -
 method public,final createControllerFromDevice (Lnet/java/games/input/RawDevice;Lnet/java/games/input/SetupAPIDevice;)Lnet/java/games/input/Controller; - java/io/IOException
in 24
class net/java/games/input/Rumbler 48 public,interface,abstract java/lang/Object - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method public,abstract rumble (F)V - -
 method public,abstract getAxisName ()Ljava/lang/String; - -
 method public,abstract getAxisIdentifier ()Lnet/java/games/input/Component$Identifier; - -
in 24
class net/java/games/input/SetupAPIDevice 48 final,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;)V - -
 method public,final getName ()Ljava/lang/String; - -
 method public,final getInstanceId ()Ljava/lang/String; - -
in 24
class net/java/games/input/Usage 48 public,interface,abstract java/lang/Object - -
in 24
class net/java/games/input/UsagePage 48 final,super java/lang/Object - -
 field public,static,final UNDEFINED Lnet/java/games/input/UsagePage; -
 field public,static,final GENERIC_DESKTOP Lnet/java/games/input/UsagePage; -
 field public,static,final SIMULATION Lnet/java/games/input/UsagePage; -
 field public,static,final VR Lnet/java/games/input/UsagePage; -
 field public,static,final SPORT Lnet/java/games/input/UsagePage; -
 field public,static,final GAME Lnet/java/games/input/UsagePage; -
 field public,static,final KEYBOARD_OR_KEYPAD Lnet/java/games/input/UsagePage; -
 field public,static,final LEDS Lnet/java/games/input/UsagePage; -
 field public,static,final BUTTON Lnet/java/games/input/UsagePage; -
 field public,static,final ORDINAL Lnet/java/games/input/UsagePage; -
 field public,static,final TELEPHONY Lnet/java/games/input/UsagePage; -
 field public,static,final CONSUMER Lnet/java/games/input/UsagePage; -
 field public,static,final DIGITIZER Lnet/java/games/input/UsagePage; -
 field public,static,final PID Lnet/java/games/input/UsagePage; -
 field public,static,final UNICODE Lnet/java/games/input/UsagePage; -
 field public,static,final ALPHANUMERIC_DISPLAY Lnet/java/games/input/UsagePage; -
 field public,static,final POWER_DEVICE Lnet/java/games/input/UsagePage; -
 field public,static,final BATTERY_SYSTEM Lnet/java/games/input/UsagePage; -
 field public,static,final BAR_CODE_SCANNER Lnet/java/games/input/UsagePage; -
 field public,static,final SCALE Lnet/java/games/input/UsagePage; -
 field public,static,final CAMERACONTROL Lnet/java/games/input/UsagePage; -
 field public,static,final ARCADE Lnet/java/games/input/UsagePage; -
 method public,static,final map (I)Lnet/java/games/input/UsagePage; - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final mapUsage (I)Lnet/java/games/input/Usage; - -
in 24
class net/java/games/input/UsagePair 48 super java/lang/Object - -
 method public <init> (Lnet/java/games/input/UsagePage;Lnet/java/games/input/Usage;)V - -
 method public,final getUsagePage ()Lnet/java/games/input/UsagePage; - -
 method public,final getUsage ()Lnet/java/games/input/Usage; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public,final toString ()Ljava/lang/String; - -
in 24
class net/java/games/input/Version 48 public,final,super java/lang/Object - -
 method public,static getVersion ()Ljava/lang/String; - -
in 24
class net/java/games/input/WinTabButtonComponent 48 public,super net/java/games/input/WinTabComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method protected <init> (Lnet/java/games/input/WinTabContext;ILjava/lang/String;Lnet/java/games/input/Component$Identifier;I)V - -
 method public processPacket (Lnet/java/games/input/WinTabPacket;)Lnet/java/games/input/Event; - -
in 24
class net/java/games/input/WinTabComponent 48 public,super net/java/games/input/AbstractComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 inner net/java/games/input/Component$Identifier$Axis net/java/games/input/Component$Identifier Axis public,static
 inner net/java/games/input/Component$Identifier$Button net/java/games/input/Component$Identifier Button public,static
 field public,static,final XAxis I - I1
 field public,static,final YAxis I - I2
 field public,static,final ZAxis I - I3
 field public,static,final NPressureAxis I - I4
 field public,static,final TPressureAxis I - I5
 field public,static,final OrientationAxis I - I6
 field public,static,final RotationAxis I - I7
 field protected lastKnownValue F -
 method protected <init> (Lnet/java/games/input/WinTabContext;ILjava/lang/String;Lnet/java/games/input/Component$Identifier;II)V - -
 method protected <init> (Lnet/java/games/input/WinTabContext;ILjava/lang/String;Lnet/java/games/input/Component$Identifier;)V - -
 method protected poll ()F - java/io/IOException
 method public isAnalog ()Z - -
 method public isRelative ()Z - -
 method public,static createComponents (Lnet/java/games/input/WinTabContext;II[I)Ljava/util/List; - -
 method public,static createButtons (Lnet/java/games/input/WinTabContext;II)Ljava/util/Collection; - -
 method public processPacket (Lnet/java/games/input/WinTabPacket;)Lnet/java/games/input/Event; - -
 method public,static createCursors (Lnet/java/games/input/WinTabContext;I[Ljava/lang/String;)Ljava/util/Collection; - -
in 24
class net/java/games/input/WinTabContext 48 public,super java/lang/Object - -
 method public <init> (Lnet/java/games/input/DummyWindow;)V - -
 method public getControllers ()[Lnet/java/games/input/Controller; - -
 method public,synchronized open ()V - -
 method public,synchronized close ()V - -
 method public,synchronized processEvents ()V - -
in 24
class net/java/games/input/WinTabCursorComponent 48 public,super net/java/games/input/WinTabComponent - -
 inner net/java/games/input/Component$Identifier net/java/games/input/Component Identifier public,static
 method protected <init> (Lnet/java/games/input/WinTabContext;ILjava/lang/String;Lnet/java/games/input/Component$Identifier;I)V - -
 method public processPacket (Lnet/java/games/input/WinTabPacket;)Lnet/java/games/input/Event; - -
in 24
class net/java/games/input/WinTabDevice 48 public,super net/java/games/input/AbstractController - -
 inner net/java/games/input/Controller$Type net/java/games/input/Controller Type public,static
 method protected getNextDeviceEvent (Lnet/java/games/input/Event;)Z - java/io/IOException
 method protected pollDevice ()V - java/io/IOException
 method public getType ()Lnet/java/games/input/Controller$Type; - -
 method public processPacket (Lnet/java/games/input/WinTabPacket;)V - -
 method public,static createDevice (Lnet/java/games/input/WinTabContext;I)Lnet/java/games/input/WinTabDevice; - -
in 24
class net/java/games/input/WinTabEnvironmentPlugin 48 public,super net/java/games/input/ControllerEnvironment net/java/games/util/plugins/Plugin -
 inner net/java/games/input/WinTabEnvironmentPlugin$ShutdownHook net/java/games/input/WinTabEnvironmentPlugin ShutdownHook private,final
 method public <init> ()V - -
 method public isSupported ()Z - -
 method public getControllers ()[Lnet/java/games/input/Controller; - -
in 24
class net/java/games/input/WinTabEnvironmentPlugin$ShutdownHook 48 final,super java/lang/Thread - -
 inner net/java/games/input/WinTabEnvironmentPlugin$ShutdownHook net/java/games/input/WinTabEnvironmentPlugin ShutdownHook private,final
 method public,final run ()V - -
in 24
class net/java/games/input/WinTabPacket 48 public,super java/lang/Object - -
 method public <init> ()V - -
in 24
class net/java/games/util/Version 48 public,final,super java/lang/Object - -
 method public,static getVersion ()Ljava/lang/String; - -
in 24
class net/java/games/util/plugins/Plugin 48 public,interface,abstract java/lang/Object - -
in 24
class net/java/games/util/plugins/PluginLoader 48 public,super java/net/URLClassLoader - -
 method public <init> (Ljava/io/File;)V - java/net/MalformedURLException
 method protected findLibrary (Ljava/lang/String;)Ljava/lang/String; - -
 method public attemptPluginDefine (Ljava/lang/Class;)Z - -
in 24
class net/java/games/util/plugins/Plugins 48 public,super java/lang/Object - -
 method public <init> (Ljava/io/File;)V - java/io/IOException
 method public get ()[Ljava/lang/Class; - -
 method public getImplementsAny ([Ljava/lang/Class;)[Ljava/lang/Class; - -
 method public getImplementsAll ([Ljava/lang/Class;)[Ljava/lang/Class; - -
 method public getExtends (Ljava/lang/Class;)[Ljava/lang/Class; - -
