cg-stub-db 1
in 290
class oshi/hardware/Baseboard 52 public,interface,abstract java/lang/Object - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getModel ()Ljava/lang/String; - -
 method public,abstract getVersion ()Ljava/lang/String; - -
 method public,abstract getSerialNumber ()Ljava/lang/String; - -
in 1183
class oshi/hardware/CentralProcessor 52 public,interface,abstract java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 method public,abstract getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public,abstract getMaxFreq ()J - -
 method public,abstract getCurrentFreq ()[J - -
 method public,abstract getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public,abstract getSystemCpuLoadBetweenTicks ([J)D - -
 method public,abstract getSystemCpuLoadTicks ()[J - -
 method public,abstract getSystemLoadAverage (I)[D - -
 method public,abstract getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public,abstract getProcessorCpuLoadTicks ()[[J - -
 method public,abstract getLogicalProcessorCount ()I - -
 method public,abstract getPhysicalProcessorCount ()I - -
 method public,abstract getPhysicalPackageCount ()I - -
 method public,abstract getContextSwitches ()J - -
 method public,abstract getInterrupts ()J - -
in 42
class oshi/hardware/CentralProcessor 52 public,interface,abstract java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 method public,abstract getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public,abstract getMaxFreq ()J - -
 method public,abstract getCurrentFreq ()[J - -
 method public,abstract getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public,abstract getPhysicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public,abstract getSystemCpuLoadBetweenTicks ([J)D - -
 method public,abstract getSystemCpuLoadTicks ()[J - -
 method public,abstract getSystemLoadAverage (I)[D - -
 method public getSystemCpuLoad (J)D - -
 method public getProcessorCpuLoad (J)[D - -
 method public,abstract getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public,abstract getProcessorCpuLoadTicks ()[[J - -
 method public,abstract getLogicalProcessorCount ()I - -
 method public,abstract getPhysicalProcessorCount ()I - -
 method public,abstract getPhysicalPackageCount ()I - -
 method public,abstract getContextSwitches ()J - -
 method public,abstract getInterrupts ()J - -
in 37
class oshi/hardware/CentralProcessor 52 public,interface,abstract java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 method public,abstract getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public,abstract getMaxFreq ()J - -
 method public,abstract getCurrentFreq ()[J - -
 method public,abstract getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public,abstract getPhysicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public,abstract getProcessorCaches ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>; -
 method public,abstract getSystemCpuLoadBetweenTicks ([J)D - -
 method public,abstract getSystemCpuLoadTicks ()[J - -
 method public,abstract getSystemLoadAverage (I)[D - -
 method public getSystemCpuLoad (J)D - -
 method public getProcessorCpuLoad (J)[D - -
 method public,abstract getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public,abstract getProcessorCpuLoadTicks ()[[J - -
 method public,abstract getLogicalProcessorCount ()I - -
 method public,abstract getPhysicalProcessorCount ()I - -
 method public,abstract getPhysicalPackageCount ()I - -
 method public,abstract getContextSwitches ()J - -
 method public,abstract getInterrupts ()J - -
in 28
class oshi/hardware/CentralProcessor 52 public,interface,abstract java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 method public,abstract getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public,abstract getMaxFreq ()J - -
 method public,abstract getCurrentFreq ()[J - -
 method public,abstract getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public,abstract getPhysicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public,abstract getProcessorCaches ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>; -
 method public,abstract getFeatureFlags ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,abstract getSystemCpuLoadBetweenTicks ([J)D - -
 method public,abstract getSystemCpuLoadTicks ()[J - -
 method public,abstract getSystemLoadAverage (I)[D - -
 method public getSystemCpuLoad (J)D - -
 method public getProcessorCpuLoad (J)[D - -
 method public,abstract getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public,abstract getProcessorCpuLoadTicks ()[[J - -
 method public,abstract getLogicalProcessorCount ()I - -
 method public,abstract getPhysicalProcessorCount ()I - -
 method public,abstract getPhysicalPackageCount ()I - -
 method public,abstract getContextSwitches ()J - -
 method public,abstract getInterrupts ()J - -
in 290
class oshi/hardware/CentralProcessor$LogicalProcessor 52 public,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 method public <init> (III)V - -
 method public <init> (IIII)V - -
 method public <init> (IIIII)V - -
 method public getProcessorNumber ()I - -
 method public getPhysicalProcessorNumber ()I - -
 method public getPhysicalPackageNumber ()I - -
 method public getNumaNode ()I - -
 method public getProcessorGroup ()I - -
 method public toString ()Ljava/lang/String; - -
in 39
class oshi/hardware/CentralProcessor$PhysicalProcessor 52 public,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 method public <init> (II)V - -
 method public <init> (IIILjava/lang/String;)V - -
 method public getPhysicalPackageNumber ()I - -
 method public getPhysicalProcessorNumber ()I - -
 method public getEfficiency ()I - -
 method public getIdString ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 23
class oshi/hardware/CentralProcessor$ProcessorCache 52 public,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 method public <init> (BBSILoshi/hardware/CentralProcessor$ProcessorCache$Type;)V - -
 method public <init> (IIIJLoshi/hardware/CentralProcessor$ProcessorCache$Type;)V - -
 method public getLevel ()B - -
 method public getAssociativity ()B - -
 method public getLineSize ()S - -
 method public getCacheSize ()I - -
 method public getType ()Loshi/hardware/CentralProcessor$ProcessorCache$Type; - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 23
class oshi/hardware/CentralProcessor$ProcessorCache$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/hardware/CentralProcessor$ProcessorCache$Type;>;
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 field public,static,final,enum UNIFIED Loshi/hardware/CentralProcessor$ProcessorCache$Type; -
 field public,static,final,enum INSTRUCTION Loshi/hardware/CentralProcessor$ProcessorCache$Type; -
 field public,static,final,enum DATA Loshi/hardware/CentralProcessor$ProcessorCache$Type; -
 field public,static,final,enum TRACE Loshi/hardware/CentralProcessor$ProcessorCache$Type; -
 method public,static values ()[Loshi/hardware/CentralProcessor$ProcessorCache$Type; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/hardware/CentralProcessor$ProcessorCache$Type; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/CentralProcessor$ProcessorIdentifier 52 public,final,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZJ)V - -
 method public getVendor ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getFamily ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getStepping ()Ljava/lang/String; - -
 method public getProcessorID ()Ljava/lang/String; - -
 method public getIdentifier ()Ljava/lang/String; - -
 method public isCpu64bit ()Z - -
 method public getVendorFreq ()J - -
 method public getMicroarchitecture ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/CentralProcessor$TickType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/hardware/CentralProcessor$TickType;>;
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 field public,static,final,enum USER Loshi/hardware/CentralProcessor$TickType; -
 field public,static,final,enum NICE Loshi/hardware/CentralProcessor$TickType; -
 field public,static,final,enum SYSTEM Loshi/hardware/CentralProcessor$TickType; -
 field public,static,final,enum IDLE Loshi/hardware/CentralProcessor$TickType; -
 field public,static,final,enum IOWAIT Loshi/hardware/CentralProcessor$TickType; -
 field public,static,final,enum IRQ Loshi/hardware/CentralProcessor$TickType; -
 field public,static,final,enum SOFTIRQ Loshi/hardware/CentralProcessor$TickType; -
 field public,static,final,enum STEAL Loshi/hardware/CentralProcessor$TickType; -
 method public,static values ()[Loshi/hardware/CentralProcessor$TickType; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/hardware/CentralProcessor$TickType; - -
 method public getIndex ()I - -
in 290
class oshi/hardware/ComputerSystem 52 public,interface,abstract java/lang/Object - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getModel ()Ljava/lang/String; - -
 method public,abstract getSerialNumber ()Ljava/lang/String; - -
 method public,abstract getHardwareUUID ()Ljava/lang/String; - -
 method public,abstract getFirmware ()Loshi/hardware/Firmware; - -
 method public,abstract getBaseboard ()Loshi/hardware/Baseboard; - -
in 290
class oshi/hardware/Display 52 public,interface,abstract java/lang/Object - -
 method public,abstract getEdid ()[B - -
in 290
class oshi/hardware/Firmware 52 public,interface,abstract java/lang/Object - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getDescription ()Ljava/lang/String; - -
 method public,abstract getVersion ()Ljava/lang/String; - -
 method public,abstract getReleaseDate ()Ljava/lang/String; - -
in 290
class oshi/hardware/GlobalMemory 52 public,interface,abstract java/lang/Object - -
 method public,abstract getTotal ()J - -
 method public,abstract getAvailable ()J - -
 method public,abstract getPageSize ()J - -
 method public,abstract getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
 method public,abstract getPhysicalMemory ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PhysicalMemory;>; -
in 290
class oshi/hardware/GraphicsCard 52 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getDeviceId ()Ljava/lang/String; - -
 method public,abstract getVendor ()Ljava/lang/String; - -
 method public,abstract getVersionInfo ()Ljava/lang/String; - -
 method public,abstract getVRam ()J - -
in 290
class oshi/hardware/HWDiskStore 52 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getModel ()Ljava/lang/String; - -
 method public,abstract getSerial ()Ljava/lang/String; - -
 method public,abstract getSize ()J - -
 method public,abstract getReads ()J - -
 method public,abstract getReadBytes ()J - -
 method public,abstract getWrites ()J - -
 method public,abstract getWriteBytes ()J - -
 method public,abstract getCurrentQueueLength ()J - -
 method public,abstract getTransferTime ()J - -
 method public,abstract getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public,abstract getTimeStamp ()J - -
 method public,abstract updateAttributes ()Z - -
in 290
class oshi/hardware/HWPartition 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JIILjava/lang/String;)V - -
 method public getIdentification ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getType ()Ljava/lang/String; - -
 method public getUuid ()Ljava/lang/String; - -
 method public getSize ()J - -
 method public getMajor ()I - -
 method public getMinor ()I - -
 method public getMountPoint ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 126
class oshi/hardware/HardwareAbstractionLayer 49 public,interface,abstract java/lang/Object - -
 method public,abstract getProcessors ()[Loshi/hardware/Processor; - -
 method public,abstract getMemory ()Loshi/hardware/Memory; - -
in 290
class oshi/hardware/HardwareAbstractionLayer 52 public,interface,abstract java/lang/Object - -
 method public,abstract getComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public,abstract getProcessor ()Loshi/hardware/CentralProcessor; - -
 method public,abstract getMemory ()Loshi/hardware/GlobalMemory; - -
 method public,abstract getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public,abstract getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getLogicalVolumeGroups ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/LogicalVolumeGroup;>; -
 method public,abstract getNetworkIFs ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public,abstract getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public,abstract getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public,abstract getSensors ()Loshi/hardware/Sensors; - -
 method public,abstract getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public,abstract getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public,abstract getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/LogicalVolumeGroup 52 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getPhysicalVolumes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public,abstract getLogicalVolumes ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;>; -
in 126
class oshi/hardware/Memory 49 public,interface,abstract java/lang/Object - -
 method public,abstract getTotal ()J - -
 method public,abstract getAvailable ()J - -
in 1183
class oshi/hardware/NetworkIF 52 public,interface,abstract java/lang/Object - -
 inner oshi/hardware/NetworkIF$IfOperStatus oshi/hardware/NetworkIF IfOperStatus public,static,final,enum
 method public,abstract queryNetworkInterface ()Ljava/net/NetworkInterface; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getIndex ()I - -
 method public,abstract getDisplayName ()Ljava/lang/String; - -
 method public getIfAlias ()Ljava/lang/String; - -
 method public getIfOperStatus ()Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public,abstract getMTU ()I - -
 method public,abstract getMacaddr ()Ljava/lang/String; - -
 method public,abstract getIPv4addr ()[Ljava/lang/String; - -
 method public,abstract getSubnetMasks ()[Ljava/lang/Short; - -
 method public,abstract getIPv6addr ()[Ljava/lang/String; - -
 method public,abstract getPrefixLengths ()[Ljava/lang/Short; - -
 method public getIfType ()I - -
 method public getNdisPhysicalMediumType ()I - -
 method public isConnectorPresent ()Z - -
 method public,abstract getBytesRecv ()J - -
 method public,abstract getBytesSent ()J - -
 method public,abstract getPacketsRecv ()J - -
 method public,abstract getPacketsSent ()J - -
 method public,abstract getInErrors ()J - -
 method public,abstract getOutErrors ()J - -
 method public,abstract getInDrops ()J - -
 method public,abstract getCollisions ()J - -
 method public,abstract getSpeed ()J - -
 method public,abstract getTimeStamp ()J - -
 method public,abstract isKnownVmMacAddr ()Z - -
 method public,abstract updateAttributes ()Z - -
in 39
class oshi/hardware/NetworkIF 52 public,interface,abstract java/lang/Object - -
 inner oshi/hardware/NetworkIF$IfOperStatus oshi/hardware/NetworkIF IfOperStatus public,static,final,enum
 method public,abstract queryNetworkInterface ()Ljava/net/NetworkInterface; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getIndex ()I - -
 method public,abstract getDisplayName ()Ljava/lang/String; - -
 method public getIfAlias ()Ljava/lang/String; - -
 method public getIfOperStatus ()Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public,abstract getMTU ()J - -
 method public,abstract getMacaddr ()Ljava/lang/String; - -
 method public,abstract getIPv4addr ()[Ljava/lang/String; - -
 method public,abstract getSubnetMasks ()[Ljava/lang/Short; - -
 method public,abstract getIPv6addr ()[Ljava/lang/String; - -
 method public,abstract getPrefixLengths ()[Ljava/lang/Short; - -
 method public getIfType ()I - -
 method public getNdisPhysicalMediumType ()I - -
 method public isConnectorPresent ()Z - -
 method public,abstract getBytesRecv ()J - -
 method public,abstract getBytesSent ()J - -
 method public,abstract getPacketsRecv ()J - -
 method public,abstract getPacketsSent ()J - -
 method public,abstract getInErrors ()J - -
 method public,abstract getOutErrors ()J - -
 method public,abstract getInDrops ()J - -
 method public,abstract getCollisions ()J - -
 method public,abstract getSpeed ()J - -
 method public,abstract getTimeStamp ()J - -
 method public,abstract isKnownVmMacAddr ()Z - -
 method public,abstract updateAttributes ()Z - -
in 290
class oshi/hardware/NetworkIF$IfOperStatus 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/hardware/NetworkIF$IfOperStatus;>;
 inner oshi/hardware/NetworkIF$IfOperStatus oshi/hardware/NetworkIF IfOperStatus public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum UP Loshi/hardware/NetworkIF$IfOperStatus; -
 field public,static,final,enum DOWN Loshi/hardware/NetworkIF$IfOperStatus; -
 field public,static,final,enum TESTING Loshi/hardware/NetworkIF$IfOperStatus; -
 field public,static,final,enum UNKNOWN Loshi/hardware/NetworkIF$IfOperStatus; -
 field public,static,final,enum DORMANT Loshi/hardware/NetworkIF$IfOperStatus; -
 field public,static,final,enum NOT_PRESENT Loshi/hardware/NetworkIF$IfOperStatus; -
 field public,static,final,enum LOWER_LAYER_DOWN Loshi/hardware/NetworkIF$IfOperStatus; -
 method public,static values ()[Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public getValue ()I - -
 method public,static byValue (I)Loshi/hardware/NetworkIF$IfOperStatus; - -
in 1184
class oshi/hardware/PhysicalMemory 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;)V - -
 method public getBankLabel ()Ljava/lang/String; - -
 method public getCapacity ()J - -
 method public getClockSpeed ()J - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getMemoryType ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 28
class oshi/hardware/PhysicalMemory 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;JJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getBankLabel ()Ljava/lang/String; - -
 method public getCapacity ()J - -
 method public getClockSpeed ()J - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getMemoryType ()Ljava/lang/String; - -
 method public getPartNumber ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/PowerSource 52 public,interface,abstract java/lang/Object - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getDeviceName ()Ljava/lang/String; - -
 method public,abstract getRemainingCapacityPercent ()D - -
 method public,abstract getTimeRemainingEstimated ()D - -
 method public,abstract getTimeRemainingInstant ()D - -
 method public,abstract getPowerUsageRate ()D - -
 method public,abstract getVoltage ()D - -
 method public,abstract getAmperage ()D - -
 method public,abstract isPowerOnLine ()Z - -
 method public,abstract isCharging ()Z - -
 method public,abstract isDischarging ()Z - -
 method public,abstract getCapacityUnits ()Loshi/hardware/PowerSource$CapacityUnits; - -
 method public,abstract getCurrentCapacity ()I - -
 method public,abstract getMaxCapacity ()I - -
 method public,abstract getDesignCapacity ()I - -
 method public,abstract getCycleCount ()I - -
 method public,abstract getChemistry ()Ljava/lang/String; - -
 method public,abstract getManufactureDate ()Ljava/time/LocalDate; - -
 method public,abstract getManufacturer ()Ljava/lang/String; - -
 method public,abstract getSerialNumber ()Ljava/lang/String; - -
 method public,abstract getTemperature ()D - -
 method public,abstract updateAttributes ()Z - -
in 290
class oshi/hardware/PowerSource$CapacityUnits 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/hardware/PowerSource$CapacityUnits;>;
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 field public,static,final,enum MWH Loshi/hardware/PowerSource$CapacityUnits; -
 field public,static,final,enum MAH Loshi/hardware/PowerSource$CapacityUnits; -
 field public,static,final,enum RELATIVE Loshi/hardware/PowerSource$CapacityUnits; -
 method public,static values ()[Loshi/hardware/PowerSource$CapacityUnits; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/hardware/PowerSource$CapacityUnits; - -
in 126
class oshi/hardware/Processor 49 public,interface,abstract java/lang/Object - -
 method public,abstract getVendor ()Ljava/lang/String; - -
 method public,abstract setVendor (Ljava/lang/String;)V - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract setName (Ljava/lang/String;)V - -
 method public,abstract getIdentifier ()Ljava/lang/String; - -
 method public,abstract setIdentifier (Ljava/lang/String;)V - -
 method public,abstract isCpu64bit ()Z - -
 method public,abstract setCpu64 (Z)V - -
 method public,abstract getStepping ()Ljava/lang/String; - -
 method public,abstract setStepping (Ljava/lang/String;)V - -
 method public,abstract getModel ()Ljava/lang/String; - -
 method public,abstract setModel (Ljava/lang/String;)V - -
 method public,abstract getFamily ()Ljava/lang/String; - -
 method public,abstract setFamily (Ljava/lang/String;)V - -
 method public,abstract getLoad ()F - -
in 290
class oshi/hardware/Sensors 52 public,interface,abstract java/lang/Object - -
 method public,abstract getCpuTemperature ()D - -
 method public,abstract getFanSpeeds ()[I - -
 method public,abstract getCpuVoltage ()D - -
in 290
class oshi/hardware/SoundCard 52 public,interface,abstract java/lang/Object - -
 method public,abstract getDriverVersion ()Ljava/lang/String; - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getCodec ()Ljava/lang/String; - -
in 290
class oshi/hardware/UsbDevice 52 public,interface,abstract java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Loshi/hardware/UsbDevice;>;
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract getVendor ()Ljava/lang/String; - -
 method public,abstract getVendorId ()Ljava/lang/String; - -
 method public,abstract getProductId ()Ljava/lang/String; - -
 method public,abstract getSerialNumber ()Ljava/lang/String; - -
 method public,abstract getUniqueDeviceId ()Ljava/lang/String; - -
 method public,abstract getConnectedDevices ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 290
class oshi/hardware/VirtualMemory 52 public,interface,abstract java/lang/Object - -
 method public,abstract getSwapTotal ()J - -
 method public,abstract getSwapUsed ()J - -
 method public,abstract getVirtualMax ()J - -
 method public,abstract getVirtualInUse ()J - -
 method public,abstract getSwapPagesIn ()J - -
 method public,abstract getSwapPagesOut ()J - -
in 290
class oshi/hardware/common/AbstractBaseboard 52 public,super,abstract java/lang/Object oshi/hardware/Baseboard -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
in 1183
class oshi/hardware/common/AbstractCentralProcessor 52 public,super,abstract java/lang/Object oshi/hardware/CentralProcessor -
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> ()V - -
 method protected,abstract initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method protected,abstract queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getMaxFreq ()J - -
 method protected,abstract queryMaxFreq ()J - -
 method public getCurrentFreq ()[J - -
 method protected,abstract queryCurrentFreq ()[J - -
 method public getContextSwitches ()J - -
 method protected,abstract queryContextSwitches ()J - -
 method public getInterrupts ()J - -
 method protected,abstract queryInterrupts ()J - -
 method public getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public getSystemCpuLoadTicks ()[J - -
 method protected,abstract querySystemCpuLoadTicks ()[J - -
 method public getProcessorCpuLoadTicks ()[[J - -
 method protected,abstract queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemCpuLoadBetweenTicks ([J)D - -
 method public getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public getLogicalProcessorCount ()I - -
 method public getPhysicalProcessorCount ()I - -
 method public getPhysicalPackageCount ()I - -
 method protected,static createProcessorID (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 42
class oshi/hardware/common/AbstractCentralProcessor 52 public,super,abstract java/lang/Object oshi/hardware/CentralProcessor -
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> ()V - -
 method protected,abstract initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method protected,abstract queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getMaxFreq ()J - -
 method protected,abstract queryMaxFreq ()J - -
 method public getCurrentFreq ()[J - -
 method protected,abstract queryCurrentFreq ()[J - -
 method public getContextSwitches ()J - -
 method protected,abstract queryContextSwitches ()J - -
 method public getInterrupts ()J - -
 method protected,abstract queryInterrupts ()J - -
 method public getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public getPhysicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public getSystemCpuLoadTicks ()[J - -
 method protected,abstract querySystemCpuLoadTicks ()[J - -
 method public getProcessorCpuLoadTicks ()[[J - -
 method protected,abstract queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemCpuLoadBetweenTicks ([J)D - -
 method public getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public getLogicalProcessorCount ()I - -
 method public getPhysicalProcessorCount ()I - -
 method public getPhysicalPackageCount ()I - -
 method protected,static createProcessorID (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String; - -
 method protected createProcListFromDmesg (Ljava/util/List;Ljava/util/Map;)Ljava/util/List; (Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;)Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public toString ()Ljava/lang/String; - -
in 37
class oshi/hardware/common/AbstractCentralProcessor 52 public,super,abstract java/lang/Object oshi/hardware/CentralProcessor -
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> ()V - -
 method protected,abstract initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method protected,abstract queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getMaxFreq ()J - -
 method protected queryMaxFreq ()J - -
 method public getCurrentFreq ()[J - -
 method protected,abstract queryCurrentFreq ()[J - -
 method public getContextSwitches ()J - -
 method protected,abstract queryContextSwitches ()J - -
 method public getInterrupts ()J - -
 method protected,abstract queryInterrupts ()J - -
 method public getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public getPhysicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public getProcessorCaches ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>; -
 method public getSystemCpuLoadTicks ()[J - -
 method protected,abstract querySystemCpuLoadTicks ()[J - -
 method public getProcessorCpuLoadTicks ()[[J - -
 method protected,abstract queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemCpuLoadBetweenTicks ([J)D - -
 method public getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public getLogicalProcessorCount ()I - -
 method public getPhysicalProcessorCount ()I - -
 method public getPhysicalPackageCount ()I - -
 method protected,static createProcessorID (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String; - -
 method protected createProcListFromDmesg (Ljava/util/List;Ljava/util/Map;)Ljava/util/List; (Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;)Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public,static orderedProcCaches (Ljava/util/Set;)Ljava/util/List; (Ljava/util/Set<Loshi/hardware/CentralProcessor$ProcessorCache;>;)Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>; -
 method public toString ()Ljava/lang/String; - -
in 28
class oshi/hardware/common/AbstractCentralProcessor 52 public,super,abstract java/lang/Object oshi/hardware/CentralProcessor -
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> ()V - -
 method protected,abstract initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method protected,abstract queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getProcessorIdentifier ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method public getMaxFreq ()J - -
 method protected queryMaxFreq ()J - -
 method public getCurrentFreq ()[J - -
 method protected,abstract queryCurrentFreq ()[J - -
 method public getContextSwitches ()J - -
 method protected,abstract queryContextSwitches ()J - -
 method public getInterrupts ()J - -
 method protected,abstract queryInterrupts ()J - -
 method public getLogicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public getPhysicalProcessors ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public getProcessorCaches ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>; -
 method public getFeatureFlags ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public getSystemCpuLoadTicks ()[J - -
 method protected,abstract querySystemCpuLoadTicks ()[J - -
 method public getProcessorCpuLoadTicks ()[[J - -
 method protected,abstract queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemCpuLoadBetweenTicks ([J)D - -
 method public getProcessorCpuLoadBetweenTicks ([[J)[D - -
 method public getLogicalProcessorCount ()I - -
 method public getPhysicalProcessorCount ()I - -
 method public getPhysicalPackageCount ()I - -
 method protected,static createProcessorID (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String; - -
 method protected createProcListFromDmesg (Ljava/util/List;Ljava/util/Map;)Ljava/util/List; (Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;)Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>; -
 method public,static orderedProcCaches (Ljava/util/Set;)Ljava/util/List; (Ljava/util/Set<Loshi/hardware/CentralProcessor$ProcessorCache;>;)Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>; -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractComputerSystem 52 public,super,abstract java/lang/Object oshi/hardware/ComputerSystem -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getFirmware ()Loshi/hardware/Firmware; - -
 method protected,abstract createFirmware ()Loshi/hardware/Firmware; - -
 method public getBaseboard ()Loshi/hardware/Baseboard; - -
 method protected,abstract createBaseboard ()Loshi/hardware/Baseboard; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractDisplay 52 public,super,abstract java/lang/Object oshi/hardware/Display -
 method protected <init> ([B)V - -
 method public getEdid ()[B - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractFirmware 52 public,super,abstract java/lang/Object oshi/hardware/Firmware -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getReleaseDate ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractGlobalMemory 52 public,super,abstract java/lang/Object oshi/hardware/GlobalMemory -
 method public <init> ()V - -
 method public getPhysicalMemory ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PhysicalMemory;>; -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractGraphicsCard 52 public,super,abstract java/lang/Object oshi/hardware/GraphicsCard -
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V - -
 method public getName ()Ljava/lang/String; - -
 method public getDeviceId ()Ljava/lang/String; - -
 method public getVendor ()Ljava/lang/String; - -
 method public getVersionInfo ()Ljava/lang/String; - -
 method public getVRam ()J - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractHWDiskStore 52 public,super,abstract java/lang/Object oshi/hardware/HWDiskStore -
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V - -
 method public getName ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerial ()Ljava/lang/String; - -
 method public getSize ()J - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractHardwareAbstractionLayer 52 public,super,abstract java/lang/Object oshi/hardware/HardwareAbstractionLayer -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method protected,abstract createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public getProcessor ()Loshi/hardware/CentralProcessor; - -
 method protected,abstract createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public getMemory ()Loshi/hardware/GlobalMemory; - -
 method protected,abstract createMemory ()Loshi/hardware/GlobalMemory; - -
 method public getSensors ()Loshi/hardware/Sensors; - -
 method protected,abstract createSensors ()Loshi/hardware/Sensors; - -
 method public getNetworkIFs ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/NetworkIF;>; -
in 290
class oshi/hardware/common/AbstractLogicalVolumeGroup 52 public,super java/lang/Object oshi/hardware/LogicalVolumeGroup -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method protected <init> (Ljava/lang/String;Ljava/util/Map;Ljava/util/Set;)V (Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;>;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getLogicalVolumes ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/Set<Ljava/lang/String;>;>; -
 method public getPhysicalVolumes ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public toString ()Ljava/lang/String; - -
in 1183
class oshi/hardware/common/AbstractNetworkIF 52 public,super,abstract java/lang/Object oshi/hardware/NetworkIF -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method protected <init> (Ljava/net/NetworkInterface;Ljava/lang/String;)V - java/lang/InstantiationException
 method protected,static getNetworkInterfaces (Z)Ljava/util/List; (Z)Ljava/util/List<Ljava/net/NetworkInterface;>; -
 method public queryNetworkInterface ()Ljava/net/NetworkInterface; - -
 method public getName ()Ljava/lang/String; - -
 method public getIndex ()I - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public getMTU ()I - -
 method public getMacaddr ()Ljava/lang/String; - -
 method public getIPv4addr ()[Ljava/lang/String; - -
 method public getSubnetMasks ()[Ljava/lang/Short; - -
 method public getIPv6addr ()[Ljava/lang/String; - -
 method public getPrefixLengths ()[Ljava/lang/Short; - -
 method public isKnownVmMacAddr ()Z - -
 method public toString ()Ljava/lang/String; - -
in 39
class oshi/hardware/common/AbstractNetworkIF 52 public,super,abstract java/lang/Object oshi/hardware/NetworkIF -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method protected <init> (Ljava/net/NetworkInterface;Ljava/lang/String;)V - java/lang/InstantiationException
 method protected,static getNetworkInterfaces (Z)Ljava/util/List; (Z)Ljava/util/List<Ljava/net/NetworkInterface;>; -
 method public queryNetworkInterface ()Ljava/net/NetworkInterface; - -
 method public getName ()Ljava/lang/String; - -
 method public getIndex ()I - -
 method public getDisplayName ()Ljava/lang/String; - -
 method public getMTU ()J - -
 method public getMacaddr ()Ljava/lang/String; - -
 method public getIPv4addr ()[Ljava/lang/String; - -
 method public getSubnetMasks ()[Ljava/lang/Short; - -
 method public getIPv6addr ()[Ljava/lang/String; - -
 method public getPrefixLengths ()[Ljava/lang/Short; - -
 method public isKnownVmMacAddr ()Z - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractPowerSource 52 public,super,abstract java/lang/Object oshi/hardware/PowerSource -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 method protected <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public getName ()Ljava/lang/String; - -
 method public getDeviceName ()Ljava/lang/String; - -
 method public getRemainingCapacityPercent ()D - -
 method public getTimeRemainingEstimated ()D - -
 method public getTimeRemainingInstant ()D - -
 method public getPowerUsageRate ()D - -
 method public getVoltage ()D - -
 method public getAmperage ()D - -
 method public isPowerOnLine ()Z - -
 method public isCharging ()Z - -
 method public isDischarging ()Z - -
 method public getCapacityUnits ()Loshi/hardware/PowerSource$CapacityUnits; - -
 method public getCurrentCapacity ()I - -
 method public getMaxCapacity ()I - -
 method public getDesignCapacity ()I - -
 method public getCycleCount ()I - -
 method public getChemistry ()Ljava/lang/String; - -
 method public getManufactureDate ()Ljava/time/LocalDate; - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getTemperature ()D - -
 method public updateAttributes ()Z - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractSensors 52 public,super,abstract java/lang/Object oshi/hardware/Sensors -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getCpuTemperature ()D - -
 method protected,abstract queryCpuTemperature ()D - -
 method public getFanSpeeds ()[I - -
 method protected,abstract queryFanSpeeds ()[I - -
 method public getCpuVoltage ()D - -
 method protected,abstract queryCpuVoltage ()D - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractSoundCard 52 public,super,abstract java/lang/Object oshi/hardware/SoundCard -
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getDriverVersion ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getCodec ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractUsbDevice 52 public,super,abstract java/lang/Object oshi/hardware/UsbDevice -
 method protected <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getVendor ()Ljava/lang/String; - -
 method public getVendorId ()Ljava/lang/String; - -
 method public getProductId ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getUniqueDeviceId ()Ljava/lang/String; - -
 method public getConnectedDevices ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public compareTo (Loshi/hardware/UsbDevice;)I - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/common/AbstractVirtualMemory 52 public,super,abstract java/lang/Object oshi/hardware/VirtualMemory -
 method public <init> ()V - -
 method public toString ()Ljava/lang/String; - -
in 290
class oshi/hardware/platform/linux/LinuxBaseboard 52 final,super oshi/hardware/common/AbstractBaseboard - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
in 1183
class oshi/hardware/platform/linux/LinuxCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 42
class oshi/hardware/platform/linux/LinuxCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevEnumerate com/sun/jna/platform/linux/Udev UdevEnumerate public,static
 inner com/sun/jna/platform/linux/Udev$UdevListEntry com/sun/jna/platform/linux/Udev UdevListEntry public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 37
class oshi/hardware/platform/linux/LinuxCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevEnumerate com/sun/jna/platform/linux/Udev UdevEnumerate public,static
 inner com/sun/jna/platform/linux/Udev$UdevListEntry com/sun/jna/platform/linux/Udev UdevListEntry public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 28
class oshi/hardware/platform/linux/LinuxCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevEnumerate com/sun/jna/platform/linux/Udev UdevEnumerate public,static
 inner com/sun/jna/platform/linux/Udev$UdevListEntry com/sun/jna/platform/linux/Udev UdevListEntry public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 290
class oshi/hardware/platform/linux/LinuxComputerSystem 52 final,super oshi/hardware/common/AbstractComputerSystem - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method public createFirmware ()Loshi/hardware/Firmware; - -
 method public createBaseboard ()Loshi/hardware/Baseboard; - -
in 290
class oshi/hardware/platform/linux/LinuxFirmware 52 final,super oshi/hardware/common/AbstractFirmware - -
 inner oshi/hardware/platform/linux/LinuxFirmware$VcGenCmdStrings oshi/hardware/platform/linux/LinuxFirmware VcGenCmdStrings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getReleaseDate ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
in 290
class oshi/hardware/platform/linux/LinuxFirmware$VcGenCmdStrings 52 final,super java/lang/Object - -
 inner oshi/hardware/platform/linux/LinuxFirmware$VcGenCmdStrings oshi/hardware/platform/linux/LinuxFirmware VcGenCmdStrings private,static,final
in 1183
class oshi/hardware/platform/linux/LinuxGlobalMemory 52 public,final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final PAGE_SIZE J -
 method public <init> ()V - -
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
in 39
class oshi/hardware/platform/linux/LinuxGlobalMemory 52 public,final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
in 290
class oshi/hardware/platform/linux/LinuxGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 method public,static getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/linux/LinuxHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevEnumerate com/sun/jna/platform/linux/Udev UdevEnumerate public,static
 inner com/sun/jna/platform/linux/Udev$UdevListEntry com/sun/jna/platform/linux/Udev UdevListEntry public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 inner oshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat oshi/hardware/platform/linux/LinuxHWDiskStore UdevStat static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getReads ()J - -
 method public getReadBytes ()J - -
 method public getWrites ()J - -
 method public getWriteBytes ()J - -
 method public getCurrentQueueLength ()J - -
 method public getTransferTime ()J - -
 method public getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public,static getDisks ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public updateAttributes ()Z - -
in 290
class oshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat;>;
 inner oshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat oshi/hardware/platform/linux/LinuxHWDiskStore UdevStat static,final,enum
 field public,static,final,enum READS Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; -
 field public,static,final,enum READ_BYTES Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; -
 field public,static,final,enum WRITES Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; -
 field public,static,final,enum WRITE_BYTES Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; -
 field public,static,final,enum QUEUE_LENGTH Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; -
 field public,static,final,enum ACTIVE_MS Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; -
 method public,static values ()[Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/hardware/platform/linux/LinuxHWDiskStore$UdevStat; - -
 method public getOrder ()I - -
in 290
class oshi/hardware/platform/linux/LinuxHardwareAbstractionLayer 52 public,final,super oshi/hardware/common/AbstractHardwareAbstractionLayer - -
 method public <init> ()V - -
 method public createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public createMemory ()Loshi/hardware/GlobalMemory; - -
 method public createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public createSensors ()Loshi/hardware/Sensors; - -
 method public getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getLogicalVolumeGroups ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/LogicalVolumeGroup;>; -
 method public getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/linux/LinuxLogicalVolumeGroup 52 final,super oshi/hardware/common/AbstractLogicalVolumeGroup - -
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevEnumerate com/sun/jna/platform/linux/Udev UdevEnumerate public,static
 inner com/sun/jna/platform/linux/Udev$UdevListEntry com/sun/jna/platform/linux/Udev UdevListEntry public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 1183
class oshi/hardware/platform/linux/LinuxNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 inner oshi/hardware/NetworkIF$IfOperStatus oshi/hardware/NetworkIF IfOperStatus public,static,final,enum
 method public <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getIfType ()I - -
 method public isConnectorPresent ()Z - -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public getIfAlias ()Ljava/lang/String; - -
 method public getIfOperStatus ()Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public updateAttributes ()Z - -
in 39
class oshi/hardware/platform/linux/LinuxNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 inner oshi/hardware/NetworkIF$IfOperStatus oshi/hardware/NetworkIF IfOperStatus public,static,final,enum
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 method public <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getIfType ()I - -
 method public isConnectorPresent ()Z - -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public getIfAlias ()Ljava/lang/String; - -
 method public getIfOperStatus ()Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public updateAttributes ()Z - -
in 1183
class oshi/hardware/platform/linux/LinuxPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 39
class oshi/hardware/platform/linux/LinuxPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevEnumerate com/sun/jna/platform/linux/Udev UdevEnumerate public,static
 inner com/sun/jna/platform/linux/Udev$UdevListEntry com/sun/jna/platform/linux/Udev UdevListEntry public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 1186
class oshi/hardware/platform/linux/LinuxSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 2
class oshi/hardware/platform/linux/LinuxSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final OSHI_HWMON_NAME_PRIORITY Ljava/lang/String; - "oshi.os.linux.sensors.hwmon.names"
 field public,static,final OSHI_THERMAL_ZONE_TYPE_PRIORITY Ljava/lang/String; - "oshi.os.linux.sensors.cpuTemperature.types"
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 290
class oshi/hardware/platform/linux/LinuxSoundCard 52 final,super oshi/hardware/common/AbstractSoundCard - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
in 290
class oshi/hardware/platform/linux/LinuxUsbDevice 52 public,super oshi/hardware/common/AbstractUsbDevice - -
 inner com/sun/jna/platform/linux/Udev$UdevContext com/sun/jna/platform/linux/Udev UdevContext public,static
 inner com/sun/jna/platform/linux/Udev$UdevEnumerate com/sun/jna/platform/linux/Udev UdevEnumerate public,static
 inner com/sun/jna/platform/linux/Udev$UdevListEntry com/sun/jna/platform/linux/Udev UdevListEntry public,static
 inner com/sun/jna/platform/linux/Udev$UdevDevice com/sun/jna/platform/linux/Udev UdevDevice public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public,static getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 290
class oshi/hardware/platform/linux/LinuxVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 290
class oshi/hardware/platform/mac/MacBaseboard 52 final,super oshi/hardware/common/AbstractBaseboard - -
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
in 1183
class oshi/hardware/platform/mac/MacCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner com/sun/jna/platform/mac/SystemB$HostCpuLoadInfo com/sun/jna/platform/mac/SystemB HostCpuLoadInfo public,static
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 42
class oshi/hardware/platform/mac/MacCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/Struct$CloseableHostCpuLoadInfo oshi/jna/Struct CloseableHostCpuLoadInfo public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 37
class oshi/hardware/platform/mac/MacCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/Struct$CloseableHostCpuLoadInfo oshi/jna/Struct CloseableHostCpuLoadInfo public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 28
class oshi/hardware/platform/mac/MacCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/Struct$CloseableHostCpuLoadInfo oshi/jna/Struct CloseableHostCpuLoadInfo public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 290
class oshi/hardware/platform/mac/MacComputerSystem 52 final,super oshi/hardware/common/AbstractComputerSystem - -
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method public createFirmware ()Loshi/hardware/Firmware; - -
 method public createBaseboard ()Loshi/hardware/Baseboard; - -
in 290
class oshi/hardware/platform/mac/MacDisplay 52 final,super oshi/hardware/common/AbstractDisplay - -
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDataRef com/sun/jna/platform/mac/CoreFoundation CFDataRef public,static
 method public,static getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
in 290
class oshi/hardware/platform/mac/MacFirmware 52 final,super oshi/hardware/common/AbstractFirmware - -
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getReleaseDate ()Ljava/lang/String; - -
in 1183
class oshi/hardware/platform/mac/MacGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner com/sun/jna/platform/mac/SystemB$VMStatistics com/sun/jna/platform/mac/SystemB VMStatistics public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
 method public getPhysicalMemory ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PhysicalMemory;>; -
in 39
class oshi/hardware/platform/mac/MacGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner oshi/jna/Struct$CloseableVMStatistics oshi/jna/Struct CloseableVMStatistics public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/jna/ByRef$CloseableLongByReference oshi/jna/ByRef CloseableLongByReference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
 method public getPhysicalMemory ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PhysicalMemory;>; -
in 290
class oshi/hardware/platform/mac/MacGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 method public,static getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/mac/MacHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner com/sun/jna/platform/mac/DiskArbitration$DASessionRef com/sun/jna/platform/mac/DiskArbitration DASessionRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef com/sun/jna/platform/mac/CoreFoundation CFAllocatorRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFMutableDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFMutableDictionaryRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner oshi/hardware/platform/mac/MacHWDiskStore$CFKey oshi/hardware/platform/mac/MacHWDiskStore CFKey private,static,final,enum
 inner com/sun/jna/platform/mac/CoreFoundation$CFNumberRef com/sun/jna/platform/mac/CoreFoundation CFNumberRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFBooleanRef com/sun/jna/platform/mac/CoreFoundation CFBooleanRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFIndex com/sun/jna/platform/mac/CoreFoundation CFIndex public,static
 inner com/sun/jna/platform/mac/DiskArbitration$DADiskRef com/sun/jna/platform/mac/DiskArbitration DADiskRef public,static
 inner com/sun/jna/platform/mac/IOKit$IOObject com/sun/jna/platform/mac/IOKit IOObject public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getReads ()J - -
 method public getReadBytes ()J - -
 method public getWrites ()J - -
 method public getWriteBytes ()J - -
 method public getCurrentQueueLength ()J - -
 method public getTransferTime ()J - -
 method public getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public updateAttributes ()Z - -
 method public,static getDisks ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
in 290
class oshi/hardware/platform/mac/MacHWDiskStore$CFKey 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/hardware/platform/mac/MacHWDiskStore$CFKey;>;
 inner oshi/hardware/platform/mac/MacHWDiskStore$CFKey oshi/hardware/platform/mac/MacHWDiskStore CFKey private,static,final,enum
 field public,static,final,enum IO_PROPERTY_MATCH Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum STATISTICS Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum READ_OPS Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum READ_BYTES Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum READ_TIME Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum WRITE_OPS Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum WRITE_BYTES Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum WRITE_TIME Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum BSD_UNIT Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum LEAF Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum WHOLE Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum DA_MEDIA_NAME Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum DA_VOLUME_NAME Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum DA_MEDIA_SIZE Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum DA_DEVICE_MODEL Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 field public,static,final,enum MODEL Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; -
 method public,static values ()[Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/hardware/platform/mac/MacHWDiskStore$CFKey; - -
 method public getKey ()Ljava/lang/String; - -
in 290
class oshi/hardware/platform/mac/MacHardwareAbstractionLayer 52 public,final,super oshi/hardware/common/AbstractHardwareAbstractionLayer - -
 method public <init> ()V - -
 method public createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public createMemory ()Loshi/hardware/GlobalMemory; - -
 method public createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public createSensors ()Loshi/hardware/Sensors; - -
 method public getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getLogicalVolumeGroups ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/LogicalVolumeGroup;>; -
 method public getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/mac/MacLogicalVolumeGroup 52 final,super oshi/hardware/common/AbstractLogicalVolumeGroup - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
in 290
class oshi/hardware/platform/mac/MacNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 inner com/sun/jna/platform/mac/CoreFoundation$CFArrayRef com/sun/jna/platform/mac/CoreFoundation CFArrayRef public,static
 inner oshi/jna/platform/mac/SystemConfiguration$SCNetworkInterfaceRef oshi/jna/platform/mac/SystemConfiguration SCNetworkInterfaceRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner oshi/driver/mac/net/NetStat$IFdata oshi/driver/mac/net/NetStat IFdata public,static
 method public <init> (Ljava/net/NetworkInterface;Ljava/util/Map;)V (Ljava/net/NetworkInterface;Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/mac/net/NetStat$IFdata;>;)V java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getIfType ()I - -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public updateAttributes ()Z - -
in 290
class oshi/hardware/platform/mac/MacPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 inner com/sun/jna/platform/mac/IOKit$IOService com/sun/jna/platform/mac/IOKit IOService public,static
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFArrayRef com/sun/jna/platform/mac/CoreFoundation CFArrayRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFBooleanRef com/sun/jna/platform/mac/CoreFoundation CFBooleanRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFNumberRef com/sun/jna/platform/mac/CoreFoundation CFNumberRef public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 290
class oshi/hardware/platform/mac/MacSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner com/sun/jna/platform/mac/IOKit$IOConnect com/sun/jna/platform/mac/IOKit IOConnect public,static
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 290
class oshi/hardware/platform/mac/MacSoundCard 52 final,super oshi/hardware/common/AbstractSoundCard - -
 method public,static getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
in 290
class oshi/hardware/platform/mac/MacUsbDevice 52 public,super oshi/hardware/common/AbstractUsbDevice - -
 inner com/sun/jna/platform/mac/IOKit$IORegistryEntry com/sun/jna/platform/mac/IOKit IORegistryEntry public,static
 inner com/sun/jna/platform/mac/IOKit$IOIterator com/sun/jna/platform/mac/IOKit IOIterator public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFTypeRef com/sun/jna/platform/mac/CoreFoundation CFTypeRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFAllocatorRef com/sun/jna/platform/mac/CoreFoundation CFAllocatorRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFIndex com/sun/jna/platform/mac/CoreFoundation CFIndex public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFMutableDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFMutableDictionaryRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public,static getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 1183
class oshi/hardware/platform/mac/MacVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner com/sun/jna/platform/mac/SystemB$XswUsage com/sun/jna/platform/mac/SystemB XswUsage public,static
 inner com/sun/jna/platform/mac/SystemB$VMStatistics com/sun/jna/platform/mac/SystemB VMStatistics public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 39
class oshi/hardware/platform/mac/MacVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner oshi/jna/Struct$CloseableXswUsage oshi/jna/Struct CloseableXswUsage public,static
 inner oshi/jna/Struct$CloseableVMStatistics oshi/jna/Struct CloseableVMStatistics public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 290
class oshi/hardware/platform/unix/BsdNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 method public <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public updateAttributes ()Z - -
in 290
class oshi/hardware/platform/unix/UnixBaseboard 52 public,final,super oshi/hardware/common/AbstractBaseboard - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
in 290
class oshi/hardware/platform/unix/UnixDisplay 52 public,final,super oshi/hardware/common/AbstractDisplay - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
in 290
class oshi/hardware/platform/unix/aix/AixBaseboard 52 final,super oshi/hardware/common/AbstractBaseboard - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
in 1183
class oshi/hardware/platform/unix/aix/AixCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_value_t com/sun/jna/platform/unix/aix/Perfstat perfstat_value_t public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_total_t public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method protected queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 42
class oshi/hardware/platform/unix/aix/AixCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_value_t com/sun/jna/platform/unix/aix/Perfstat perfstat_value_t public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_total_t public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_t public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method protected queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 37
class oshi/hardware/platform/unix/aix/AixCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_value_t com/sun/jna/platform/unix/aix/Perfstat perfstat_value_t public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_total_t public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_t public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method protected queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 28
class oshi/hardware/platform/unix/aix/AixCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_value_t com/sun/jna/platform/unix/aix/Perfstat perfstat_value_t public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_total_t public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_t public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method protected queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 290
class oshi/hardware/platform/unix/aix/AixComputerSystem 52 final,super oshi/hardware/common/AbstractComputerSystem - -
 inner oshi/hardware/platform/unix/aix/AixComputerSystem$LsattrStrings oshi/hardware/platform/unix/aix/AixComputerSystem LsattrStrings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method public createFirmware ()Loshi/hardware/Firmware; - -
 method public createBaseboard ()Loshi/hardware/Baseboard; - -
in 290
class oshi/hardware/platform/unix/aix/AixComputerSystem$LsattrStrings 52 final,super java/lang/Object - -
 inner oshi/hardware/platform/unix/aix/AixComputerSystem$LsattrStrings oshi/hardware/platform/unix/aix/AixComputerSystem LsattrStrings private,static,final
in 290
class oshi/hardware/platform/unix/aix/AixFirmware 52 final,super oshi/hardware/common/AbstractFirmware - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
in 290
class oshi/hardware/platform/unix/aix/AixGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_memory_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_memory_total_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
 method public getPhysicalMemory ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PhysicalMemory;>; -
in 290
class oshi/hardware/platform/unix/aix/AixGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 method public,static getGraphicsCards (Ljava/util/function/Supplier;)Ljava/util/List; (Ljava/util/function/Supplier<Ljava/util/List<Ljava/lang/String;>;>;)Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 1183
class oshi/hardware/platform/unix/aix/AixHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_disk_t com/sun/jna/platform/unix/aix/Perfstat perfstat_disk_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getReads ()J - -
 method public getReadBytes ()J - -
 method public getWrites ()J - -
 method public getWriteBytes ()J - -
 method public getCurrentQueueLength ()J - -
 method public getTransferTime ()J - -
 method public getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public updateAttributes ()Z - -
 method public,static getDisks (Ljava/util/function/Supplier;)Ljava/util/List; (Ljava/util/function/Supplier<[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_disk_t;>;)Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
in 39
class oshi/hardware/platform/unix/aix/AixHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_disk_t com/sun/jna/platform/unix/aix/Perfstat perfstat_disk_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,synchronized getReads ()J - -
 method public,synchronized getReadBytes ()J - -
 method public,synchronized getWrites ()J - -
 method public,synchronized getWriteBytes ()J - -
 method public,synchronized getCurrentQueueLength ()J - -
 method public,synchronized getTransferTime ()J - -
 method public,synchronized getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public,synchronized updateAttributes ()Z - -
 method public,static getDisks (Ljava/util/function/Supplier;)Ljava/util/List; (Ljava/util/function/Supplier<[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_disk_t;>;)Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
in 290
class oshi/hardware/platform/unix/aix/AixHardwareAbstractionLayer 52 public,final,super oshi/hardware/common/AbstractHardwareAbstractionLayer - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_disk_t com/sun/jna/platform/unix/aix/Perfstat perfstat_disk_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public createMemory ()Loshi/hardware/GlobalMemory; - -
 method public createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public createSensors ()Loshi/hardware/Sensors; - -
 method public getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/unix/aix/AixNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_netinterface_t com/sun/jna/platform/unix/aix/Perfstat perfstat_netinterface_t public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/net/NetworkInterface;Ljava/util/function/Supplier;)V (Ljava/net/NetworkInterface;Ljava/util/function/Supplier<[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_netinterface_t;>;)V java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public updateAttributes ()Z - -
in 290
class oshi/hardware/platform/unix/aix/AixPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 290
class oshi/hardware/platform/unix/aix/AixSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 290
class oshi/hardware/platform/unix/aix/AixSoundCard 52 final,super oshi/hardware/common/AbstractSoundCard - -
 method public,static getSoundCards (Ljava/util/function/Supplier;)Ljava/util/List; (Ljava/util/function/Supplier<Ljava/util/List<Ljava/lang/String;>;>;)Ljava/util/List<Loshi/hardware/SoundCard;>; -
in 290
class oshi/hardware/platform/unix/aix/AixUsbDevice 52 public,super oshi/hardware/common/AbstractUsbDevice - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public,static getUsbDevices (ZLjava/util/function/Supplier;)Ljava/util/List; (ZLjava/util/function/Supplier<Ljava/util/List<Ljava/lang/String;>;>;)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 290
class oshi/hardware/platform/unix/aix/AixVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_memory_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_memory_total_t public,static
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 82
class oshi/hardware/platform/unix/freebsd/FreeBsdCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$CpTime oshi/jna/platform/unix/freebsd/FreeBsdLibc CpTime public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 34
class oshi/hardware/platform/unix/freebsd/FreeBsdCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$CpTime oshi/jna/platform/unix/freebsd/FreeBsdLibc CpTime public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 42
class oshi/hardware/platform/unix/freebsd/FreeBsdCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/platform/unix/FreeBsdLibc$CpTime oshi/jna/platform/unix/FreeBsdLibc CpTime public,static
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 37
class oshi/hardware/platform/unix/freebsd/FreeBsdCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/platform/unix/FreeBsdLibc$CpTime oshi/jna/platform/unix/FreeBsdLibc CpTime public,static
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 28
class oshi/hardware/platform/unix/freebsd/FreeBsdCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/jna/platform/unix/FreeBsdLibc$CpTime oshi/jna/platform/unix/FreeBsdLibc CpTime public,static
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdComputerSystem 52 final,super oshi/hardware/common/AbstractComputerSystem - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method public createFirmware ()Loshi/hardware/Firmware; - -
 method public createBaseboard ()Loshi/hardware/Baseboard; - -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdFirmware 52 final,super oshi/hardware/common/AbstractFirmware - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getReleaseDate ()Ljava/lang/String; - -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 method public,static getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getReads ()J - -
 method public getReadBytes ()J - -
 method public getWrites ()J - -
 method public getWriteBytes ()J - -
 method public getCurrentQueueLength ()J - -
 method public getTransferTime ()J - -
 method public getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public updateAttributes ()Z - -
 method public,static getDisks ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdHardwareAbstractionLayer 52 public,final,super oshi/hardware/common/AbstractHardwareAbstractionLayer - -
 method public <init> ()V - -
 method public createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public createMemory ()Loshi/hardware/GlobalMemory; - -
 method public createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public createSensors ()Loshi/hardware/Sensors; - -
 method public getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 82
class oshi/hardware/platform/unix/freebsd/FreeBsdSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 34
class oshi/hardware/platform/unix/freebsd/FreeBsdSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 39
class oshi/hardware/platform/unix/freebsd/FreeBsdSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdSoundCard 52 final,super oshi/hardware/common/AbstractSoundCard - -
 method public,static getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdUsbDevice 52 public,super oshi/hardware/common/AbstractUsbDevice - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public,static getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 290
class oshi/hardware/platform/unix/freebsd/FreeBsdVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 1183
class oshi/hardware/platform/unix/openbsd/OpenBsdCentralProcessor 52 public,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected queryMaxFreq ()J - -
 method protected queryCurrentFreq ()[J - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method protected queryContextSwitches ()J - -
 method protected queryInterrupts ()J - -
 method protected querySystemCpuLoadTicks ()[J - -
 method protected queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemLoadAverage (I)[D - -
in 42
class oshi/hardware/platform/unix/openbsd/OpenBsdCentralProcessor 52 public,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected queryMaxFreq ()J - -
 method protected queryCurrentFreq ()[J - -
 method protected initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method protected queryContextSwitches ()J - -
 method protected queryInterrupts ()J - -
 method protected querySystemCpuLoadTicks ()[J - -
 method protected queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemLoadAverage (I)[D - -
in 37
class oshi/hardware/platform/unix/openbsd/OpenBsdCentralProcessor 52 public,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected queryCurrentFreq ()[J - -
 method protected initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method protected queryContextSwitches ()J - -
 method protected queryInterrupts ()J - -
 method protected querySystemCpuLoadTicks ()[J - -
 method protected queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemLoadAverage (I)[D - -
in 28
class oshi/hardware/platform/unix/openbsd/OpenBsdCentralProcessor 52 public,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected queryCurrentFreq ()[J - -
 method protected initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method protected queryContextSwitches ()J - -
 method protected queryInterrupts ()J - -
 method protected querySystemCpuLoadTicks ()[J - -
 method protected queryProcessorCpuLoadTicks ()[[J - -
 method public getSystemLoadAverage (I)[D - -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdComputerSystem 52 public,super oshi/hardware/common/AbstractComputerSystem - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method protected createFirmware ()Loshi/hardware/Firmware; - -
 method protected createBaseboard ()Loshi/hardware/Baseboard; - -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdFirmware 52 public,super oshi/hardware/common/AbstractFirmware - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getReleaseDate ()Ljava/lang/String; - -
in 1183
class oshi/hardware/platform/unix/openbsd/OpenBsdGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner oshi/jna/platform/unix/openbsd/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/openbsd/OpenBsdLibc Bcachestats public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
in 39
class oshi/hardware/platform/unix/openbsd/OpenBsdGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner oshi/jna/platform/unix/OpenBsdLibc$Bcachestats oshi/jna/platform/unix/OpenBsdLibc Bcachestats public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 method public,static getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getDisks ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getReads ()J - -
 method public getReadBytes ()J - -
 method public getWrites ()J - -
 method public getWriteBytes ()J - -
 method public getCurrentQueueLength ()J - -
 method public getTransferTime ()J - -
 method public getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public updateAttributes ()Z - -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdHardwareAbstractionLayer 52 public,final,super oshi/hardware/common/AbstractHardwareAbstractionLayer - -
 method public <init> ()V - -
 method public createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public createMemory ()Loshi/hardware/GlobalMemory; - -
 method public createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public createSensors ()Loshi/hardware/Sensors; - -
 method public getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdSoundCard 52 final,super oshi/hardware/common/AbstractSoundCard - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdUsbDevice 52 public,super oshi/hardware/common/AbstractUsbDevice - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public,static getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 290
class oshi/hardware/platform/unix/openbsd/OpenBsdVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 1183
class oshi/hardware/platform/unix/solaris/SolarisCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 42
class oshi/hardware/platform/unix/solaris/SolarisCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 37
class oshi/hardware/platform/unix/solaris/SolarisCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 28
class oshi/hardware/platform/unix/solaris/SolarisCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 371
class oshi/hardware/platform/unix/solaris/SolarisComputerSystem 52 final,super oshi/hardware/common/AbstractComputerSystem - -
 inner oshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbiosStrings oshi/hardware/platform/unix/solaris/SolarisComputerSystem SmbiosStrings private,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method public createFirmware ()Loshi/hardware/Firmware; - -
 method public createBaseboard ()Loshi/hardware/Baseboard; - -
in 23
class oshi/hardware/platform/unix/solaris/SolarisComputerSystem 52 final,super oshi/hardware/common/AbstractComputerSystem - -
 inner oshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbiosStrings oshi/hardware/platform/unix/solaris/SolarisComputerSystem SmbiosStrings private,static,final
 inner oshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType oshi/hardware/platform/unix/solaris/SolarisComputerSystem SmbType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method public createFirmware ()Loshi/hardware/Firmware; - -
 method public createBaseboard ()Loshi/hardware/Baseboard; - -
in 23
class oshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType;>;
 inner oshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType oshi/hardware/platform/unix/solaris/SolarisComputerSystem SmbType public,static,final,enum
 field public,static,final,enum SMB_TYPE_BIOS Loshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType; -
 field public,static,final,enum SMB_TYPE_SYSTEM Loshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType; -
 field public,static,final,enum SMB_TYPE_BASEBOARD Loshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType; -
 method public,static values ()[Loshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbType; - -
in 290
class oshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbiosStrings 52 final,super java/lang/Object - -
 inner oshi/hardware/platform/unix/solaris/SolarisComputerSystem$SmbiosStrings oshi/hardware/platform/unix/solaris/SolarisComputerSystem SmbiosStrings private,static,final
in 290
class oshi/hardware/platform/unix/solaris/SolarisFirmware 52 final,super oshi/hardware/common/AbstractFirmware - -
 method public getManufacturer ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getReleaseDate ()Ljava/lang/String; - -
in 290
class oshi/hardware/platform/unix/solaris/SolarisGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
in 290
class oshi/hardware/platform/unix/solaris/SolarisGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 method public,static getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/unix/solaris/SolarisHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 inner com/sun/jna/platform/unix/solaris/LibKstat$KstatIO com/sun/jna/platform/unix/solaris/LibKstat KstatIO public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getReads ()J - -
 method public getReadBytes ()J - -
 method public getWrites ()J - -
 method public getWriteBytes ()J - -
 method public getCurrentQueueLength ()J - -
 method public getTransferTime ()J - -
 method public getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public updateAttributes ()Z - -
 method public,static getDisks ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
in 290
class oshi/hardware/platform/unix/solaris/SolarisHardwareAbstractionLayer 52 public,final,super oshi/hardware/common/AbstractHardwareAbstractionLayer - -
 method public <init> ()V - -
 method public createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public createMemory ()Loshi/hardware/GlobalMemory; - -
 method public createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public createSensors ()Loshi/hardware/Sensors; - -
 method public getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/unix/solaris/SolarisNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 method public <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public updateAttributes ()Z - -
in 290
class oshi/hardware/platform/unix/solaris/SolarisPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 290
class oshi/hardware/platform/unix/solaris/SolarisSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 290
class oshi/hardware/platform/unix/solaris/SolarisSoundCard 52 final,super oshi/hardware/common/AbstractSoundCard - -
 method public,static getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
in 290
class oshi/hardware/platform/unix/solaris/SolarisUsbDevice 52 public,super oshi/hardware/common/AbstractUsbDevice - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public,static getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 290
class oshi/hardware/platform/unix/solaris/SolarisVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 290
class oshi/hardware/platform/windows/WindowsBaseboard 52 final,super oshi/hardware/common/AbstractBaseboard - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty oshi/driver/windows/wmi/Win32BaseBoard BaseBoardProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
in 1183
class oshi/hardware/platform/windows/WindowsCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$ProcessorPowerInformation oshi/jna/platform/windows/PowrProf ProcessorPowerInformation public,static
 inner com/sun/jna/platform/win32/PowrProf$POWER_INFORMATION_LEVEL com/sun/jna/platform/win32/PowrProf POWER_INFORMATION_LEVEL public,static,interface,abstract
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty oshi/driver/windows/perfmon/SystemInformation ContextSwitchProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 42
class oshi/hardware/platform/windows/WindowsCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$ProcessorPowerInformation oshi/jna/platform/windows/PowrProf ProcessorPowerInformation public,static
 inner com/sun/jna/platform/win32/PowrProf$POWER_INFORMATION_LEVEL com/sun/jna/platform/win32/PowrProf POWER_INFORMATION_LEVEL public,static,interface,abstract
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorUtilityTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty oshi/driver/windows/perfmon/SystemInformation ContextSwitchProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 37
class oshi/hardware/platform/windows/WindowsCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$ProcessorPowerInformation oshi/jna/platform/windows/PowrProf ProcessorPowerInformation public,static
 inner com/sun/jna/platform/win32/PowrProf$POWER_INFORMATION_LEVEL com/sun/jna/platform/win32/PowrProf POWER_INFORMATION_LEVEL public,static,interface,abstract
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorUtilityTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty oshi/driver/windows/perfmon/SystemInformation ContextSwitchProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 28
class oshi/hardware/platform/windows/WindowsCentralProcessor 52 final,super oshi/hardware/common/AbstractCentralProcessor - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner oshi/jna/Struct$CloseableSystemInfo oshi/jna/Struct CloseableSystemInfo public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO com/sun/jna/platform/win32/WinBase SYSTEM_INFO public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$UNION com/sun/jna/platform/win32/WinBase$SYSTEM_INFO UNION public,static
 inner com/sun/jna/platform/win32/WinBase$SYSTEM_INFO$PI com/sun/jna/platform/win32/WinBase$SYSTEM_INFO PI public,static
 inner com/sun/jna/platform/win32/WinDef$WORD com/sun/jna/platform/win32/WinDef WORD public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 inner oshi/hardware/CentralProcessor$ProcessorIdentifier oshi/hardware/CentralProcessor ProcessorIdentifier public,static,final
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/jna/platform/windows/Kernel32$ProcessorFeature oshi/jna/platform/windows/Kernel32 ProcessorFeature public,static,final,enum
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner oshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation SystemTickCountProperty public,static,final,enum
 inner com/sun/jna/platform/win32/WinDef$DWORDLONG com/sun/jna/platform/win32/WinDef DWORDLONG public,static
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$ProcessorPowerInformation oshi/jna/platform/windows/PowrProf ProcessorPowerInformation public,static
 inner com/sun/jna/platform/win32/PowrProf$POWER_INFORMATION_LEVEL com/sun/jna/platform/win32/PowrProf POWER_INFORMATION_LEVEL public,static,interface,abstract
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorUtilityTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty oshi/driver/windows/perfmon/SystemInformation ContextSwitchProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method protected queryProcessorId ()Loshi/hardware/CentralProcessor$ProcessorIdentifier; - -
 method protected initProcessorCounts ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;Ljava/util/List<Ljava/lang/String;>;>; -
 method public querySystemCpuLoadTicks ()[J - -
 method public queryCurrentFreq ()[J - -
 method public queryMaxFreq ()J - -
 method public getSystemLoadAverage (I)[D - -
 method public queryProcessorCpuLoadTicks ()[[J - -
 method public queryContextSwitches ()J - -
 method public queryInterrupts ()J - -
in 290
class oshi/hardware/platform/windows/WindowsComputerSystem 52 final,super oshi/hardware/common/AbstractComputerSystem - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty oshi/driver/windows/wmi/Win32ComputerSystem ComputerSystemProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty oshi/driver/windows/wmi/Win32ComputerSystemProduct ComputerSystemProductProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32Bios$BiosSerialProperty oshi/driver/windows/wmi/Win32Bios BiosSerialProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getModel ()Ljava/lang/String; - -
 method public getSerialNumber ()Ljava/lang/String; - -
 method public getHardwareUUID ()Ljava/lang/String; - -
 method public createFirmware ()Loshi/hardware/Firmware; - -
 method public createBaseboard ()Loshi/hardware/Baseboard; - -
in 1183
class oshi/hardware/platform/windows/WindowsDisplay 52 final,super oshi/hardware/common/AbstractDisplay - -
 inner com/sun/jna/platform/win32/Guid$GUID com/sun/jna/platform/win32/Guid GUID public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVICE_INTERFACE_DATA com/sun/jna/platform/win32/SetupApi SP_DEVICE_INTERFACE_DATA public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA com/sun/jna/platform/win32/SetupApi SP_DEVINFO_DATA public,static
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 method public,static getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
in 39
class oshi/hardware/platform/windows/WindowsDisplay 52 final,super oshi/hardware/common/AbstractDisplay - -
 inner com/sun/jna/platform/win32/Guid$GUID com/sun/jna/platform/win32/Guid GUID public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/Struct$CloseableSpDeviceInterfaceData oshi/jna/Struct CloseableSpDeviceInterfaceData public,static
 inner oshi/jna/Struct$CloseableSpDevinfoData oshi/jna/Struct CloseableSpDevinfoData public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA com/sun/jna/platform/win32/SetupApi SP_DEVINFO_DATA public,static
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 method public,static getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
in 290
class oshi/hardware/platform/windows/WindowsFirmware 52 final,super oshi/hardware/common/AbstractFirmware - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Bios$BiosProperty oshi/driver/windows/wmi/Win32Bios BiosProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getManufacturer ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public getDescription ()Ljava/lang/String; - -
 method public getVersion ()Ljava/lang/String; - -
 method public getReleaseDate ()Ljava/lang/String; - -
in 1183
class oshi/hardware/platform/windows/WindowsGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8 oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryPropertyWin8 public,static,final,enum
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner com/sun/jna/platform/win32/BaseTSD$SIZE_T com/sun/jna/platform/win32/BaseTSD SIZE_T public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
 method public getPhysicalMemory ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PhysicalMemory;>; -
in 39
class oshi/hardware/platform/windows/WindowsGlobalMemory 52 final,super oshi/hardware/common/AbstractGlobalMemory - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8 oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryPropertyWin8 public,static,final,enum
 inner oshi/jna/Struct$CloseablePerformanceInformation oshi/jna/Struct CloseablePerformanceInformation public,static
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner com/sun/jna/platform/win32/BaseTSD$SIZE_T com/sun/jna/platform/win32/BaseTSD SIZE_T public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getAvailable ()J - -
 method public getTotal ()J - -
 method public getPageSize ()J - -
 method public getVirtualMemory ()Loshi/hardware/VirtualMemory; - -
 method public getPhysicalMemory ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PhysicalMemory;>; -
in 368
class oshi/hardware/platform/windows/WindowsGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty oshi/driver/windows/wmi/Win32VideoController VideoControllerProperty public,static,final,enum
 method public,static getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 60
class oshi/hardware/platform/windows/WindowsGraphicsCard 52 final,super oshi/hardware/common/AbstractGraphicsCard - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty oshi/driver/windows/wmi/Win32VideoController VideoControllerProperty public,static,final,enum
 field public,static,final ADAPTER_STRING Ljava/lang/String; - "HardwareInformation.AdapterString"
 field public,static,final DRIVER_DESC Ljava/lang/String; - "DriverDesc"
 field public,static,final DRIVER_VERSION Ljava/lang/String; - "DriverVersion"
 field public,static,final VENDOR Ljava/lang/String; - "ProviderName"
 field public,static,final QW_MEMORY_SIZE Ljava/lang/String; - "HardwareInformation.qwMemorySize"
 field public,static,final MEMORY_SIZE Ljava/lang/String; - "HardwareInformation.MemorySize"
 field public,static,final DISPLAY_DEVICES_REGISTRY_PATH Ljava/lang/String; - "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\"
 method public,static getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/windows/WindowsHWDiskStore 52 public,final,super oshi/hardware/common/AbstractHWDiskStore - -
 inner oshi/hardware/platform/windows/WindowsHWDiskStore$DiskStats oshi/hardware/platform/windows/WindowsHWDiskStore DiskStats private,static,final
 inner oshi/hardware/platform/windows/WindowsHWDiskStore$PartitionMaps oshi/hardware/platform/windows/WindowsHWDiskStore PartitionMaps private,static,final
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty oshi/driver/windows/wmi/Win32DiskDrive DiskDriveProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty oshi/driver/windows/perfmon/PhysicalDisk PhysicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition DriveToPartitionProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty oshi/driver/windows/wmi/Win32LogicalDiskToPartition DiskToPartitionProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty oshi/driver/windows/wmi/Win32DiskPartition DiskPartitionProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getReads ()J - -
 method public getReadBytes ()J - -
 method public getWrites ()J - -
 method public getWriteBytes ()J - -
 method public getCurrentQueueLength ()J - -
 method public getTransferTime ()J - -
 method public getTimeStamp ()J - -
 method public getPartitions ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWPartition;>; -
 method public updateAttributes ()Z - -
 method public,static getDisks ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
in 290
class oshi/hardware/platform/windows/WindowsHWDiskStore$DiskStats 52 final,super java/lang/Object - -
 inner oshi/hardware/platform/windows/WindowsHWDiskStore$DiskStats oshi/hardware/platform/windows/WindowsHWDiskStore DiskStats private,static,final
in 290
class oshi/hardware/platform/windows/WindowsHWDiskStore$PartitionMaps 52 final,super java/lang/Object - -
 inner oshi/hardware/platform/windows/WindowsHWDiskStore$PartitionMaps oshi/hardware/platform/windows/WindowsHWDiskStore PartitionMaps private,static,final
in 290
class oshi/hardware/platform/windows/WindowsHardwareAbstractionLayer 52 public,final,super oshi/hardware/common/AbstractHardwareAbstractionLayer - -
 method public <init> ()V - -
 method public createComputerSystem ()Loshi/hardware/ComputerSystem; - -
 method public createMemory ()Loshi/hardware/GlobalMemory; - -
 method public createProcessor ()Loshi/hardware/CentralProcessor; - -
 method public createSensors ()Loshi/hardware/Sensors; - -
 method public getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
 method public getDiskStores ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/HWDiskStore;>; -
 method public getLogicalVolumeGroups ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/LogicalVolumeGroup;>; -
 method public getDisplays ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/Display;>; -
 method public getNetworkIFs (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
 method public getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
 method public getGraphicsCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/GraphicsCard;>; -
in 290
class oshi/hardware/platform/windows/WindowsLogicalVolumeGroup 52 final,super oshi/hardware/common/AbstractLogicalVolumeGroup - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty oshi/driver/windows/wmi/MSFTStorage VirtualDiskProperty public,static,final,enum
 inner oshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty oshi/driver/windows/wmi/MSFTStorage PhysicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty oshi/driver/windows/wmi/MSFTStorage StoragePoolToPhysicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty oshi/driver/windows/wmi/MSFTStorage StoragePoolProperty public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
in 1183
class oshi/hardware/platform/windows/WindowsNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 inner oshi/hardware/NetworkIF$IfOperStatus oshi/hardware/NetworkIF IfOperStatus public,static,final,enum
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_IF_ROW2 com/sun/jna/platform/win32/IPHlpAPI MIB_IF_ROW2 public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_IFROW com/sun/jna/platform/win32/IPHlpAPI MIB_IFROW public,static
 method public <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getIfType ()I - -
 method public getNdisPhysicalMediumType ()I - -
 method public isConnectorPresent ()Z - -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public getIfAlias ()Ljava/lang/String; - -
 method public getIfOperStatus ()Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public updateAttributes ()Z - -
in 39
class oshi/hardware/platform/windows/WindowsNetworkIF 52 public,final,super oshi/hardware/common/AbstractNetworkIF - -
 inner oshi/hardware/NetworkIF$IfOperStatus oshi/hardware/NetworkIF IfOperStatus public,static,final,enum
 inner oshi/jna/Struct$CloseableMibIfRow2 oshi/jna/Struct CloseableMibIfRow2 public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_IF_ROW2 com/sun/jna/platform/win32/IPHlpAPI MIB_IF_ROW2 public,static
 inner oshi/jna/Struct$CloseableMibIfRow oshi/jna/Struct CloseableMibIfRow public,static
 inner com/sun/jna/platform/win32/IPHlpAPI$MIB_IFROW com/sun/jna/platform/win32/IPHlpAPI MIB_IFROW public,static
 method public <init> (Ljava/net/NetworkInterface;)V - java/lang/InstantiationException
 method public,static getNetworks (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/NetworkIF;>; -
 method public getIfType ()I - -
 method public getNdisPhysicalMediumType ()I - -
 method public isConnectorPresent ()Z - -
 method public getBytesRecv ()J - -
 method public getBytesSent ()J - -
 method public getPacketsRecv ()J - -
 method public getPacketsSent ()J - -
 method public getInErrors ()J - -
 method public getOutErrors ()J - -
 method public getInDrops ()J - -
 method public getCollisions ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
 method public getIfAlias ()Ljava/lang/String; - -
 method public getIfOperStatus ()Loshi/hardware/NetworkIF$IfOperStatus; - -
 method public updateAttributes ()Z - -
in 1183
class oshi/hardware/platform/windows/WindowsPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$SystemBatteryState oshi/jna/platform/windows/PowrProf SystemBatteryState public,static
 inner com/sun/jna/platform/win32/PowrProf$POWER_INFORMATION_LEVEL com/sun/jna/platform/win32/PowrProf POWER_INFORMATION_LEVEL public,static,interface,abstract
 inner com/sun/jna/platform/win32/Guid$GUID com/sun/jna/platform/win32/Guid GUID public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVICE_INTERFACE_DATA com/sun/jna/platform/win32/SetupApi SP_DEVICE_INTERFACE_DATA public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA com/sun/jna/platform/win32/SetupApi SP_DEVINFO_DATA public,static
 inner com/sun/jna/platform/win32/WinBase$SECURITY_ATTRIBUTES com/sun/jna/platform/win32/WinBase SECURITY_ATTRIBUTES public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION_LEVEL public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$BATTERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_INFORMATION public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_WAIT_STATUS oshi/jna/platform/windows/PowrProf BATTERY_WAIT_STATUS public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_STATUS oshi/jna/platform/windows/PowrProf BATTERY_STATUS public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_MANUFACTURE_DATE oshi/jna/platform/windows/PowrProf BATTERY_MANUFACTURE_DATE public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 39
class oshi/hardware/platform/windows/WindowsPowerSource 52 public,final,super oshi/hardware/common/AbstractPowerSource - -
 inner oshi/hardware/PowerSource$CapacityUnits oshi/hardware/PowerSource CapacityUnits public,static,final,enum
 inner oshi/jna/platform/windows/PowrProf$SystemBatteryState oshi/jna/platform/windows/PowrProf SystemBatteryState public,static
 inner com/sun/jna/platform/win32/PowrProf$POWER_INFORMATION_LEVEL com/sun/jna/platform/win32/PowrProf POWER_INFORMATION_LEVEL public,static,interface,abstract
 inner com/sun/jna/platform/win32/Guid$GUID com/sun/jna/platform/win32/Guid GUID public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/Struct$CloseableSpDeviceInterfaceData oshi/jna/Struct CloseableSpDeviceInterfaceData public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVICE_INTERFACE_DATA com/sun/jna/platform/win32/SetupApi SP_DEVICE_INTERFACE_DATA public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA com/sun/jna/platform/win32/SetupApi SP_DEVINFO_DATA public,static
 inner com/sun/jna/platform/win32/WinBase$SECURITY_ATTRIBUTES com/sun/jna/platform/win32/WinBase SECURITY_ATTRIBUTES public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_INFORMATION oshi/jna/platform/windows/PowrProf BATTERY_INFORMATION public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_WAIT_STATUS oshi/jna/platform/windows/PowrProf BATTERY_WAIT_STATUS public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_STATUS oshi/jna/platform/windows/PowrProf BATTERY_STATUS public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_MANUFACTURE_DATE oshi/jna/platform/windows/PowrProf BATTERY_MANUFACTURE_DATE public,static
 inner oshi/jna/platform/windows/PowrProf$BATTERY_QUERY_INFORMATION_LEVEL oshi/jna/platform/windows/PowrProf BATTERY_QUERY_INFORMATION_LEVEL public,static,final,enum
 method public <init> (Ljava/lang/String;Ljava/lang/String;DDDDDDZZZLoshi/hardware/PowerSource$CapacityUnits;IIIILjava/lang/String;Ljava/time/LocalDate;Ljava/lang/String;Ljava/lang/String;D)V - -
 method public,static getPowerSources ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/PowerSource;>; -
in 1186
class oshi/hardware/platform/windows/WindowsSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/OhmHardware$IdentifierProperty oshi/driver/windows/wmi/OhmHardware IdentifierProperty public,static,final,enum
 inner oshi/driver/windows/wmi/OhmSensor$ValueProperty oshi/driver/windows/wmi/OhmSensor ValueProperty public,static,final,enum
 inner oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature TemperatureProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32Fan$SpeedProperty oshi/driver/windows/wmi/Win32Fan SpeedProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32Processor$VoltProperty oshi/driver/windows/wmi/Win32Processor VoltProperty public,static,final,enum
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 2
class oshi/hardware/platform/windows/WindowsSensors 52 final,super oshi/hardware/common/AbstractSensors - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/OhmSensor$ValueProperty oshi/driver/windows/wmi/OhmSensor ValueProperty public,static,final,enum
 inner oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature TemperatureProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32Fan$SpeedProperty oshi/driver/windows/wmi/Win32Fan SpeedProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32Processor$VoltProperty oshi/driver/windows/wmi/Win32Processor VoltProperty public,static,final,enum
 inner oshi/driver/windows/wmi/OhmHardware$IdentifierProperty oshi/driver/windows/wmi/OhmHardware IdentifierProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public queryCpuTemperature ()D - -
 method public queryFanSpeeds ()[I - -
 method public queryCpuVoltage ()D - -
in 290
class oshi/hardware/platform/windows/WindowsSoundCard 52 final,super oshi/hardware/common/AbstractSoundCard - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 method public,static getSoundCards ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/SoundCard;>; -
in 290
class oshi/hardware/platform/windows/WindowsUsbDevice 52 public,super oshi/hardware/common/AbstractUsbDevice - -
 inner com/sun/jna/platform/win32/Guid$GUID com/sun/jna/platform/win32/Guid GUID public,static
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List<Loshi/hardware/UsbDevice;>;)V -
 method public,static getUsbDevices (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/hardware/UsbDevice;>; -
in 1183
class oshi/hardware/platform/windows/WindowsVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner oshi/driver/windows/perfmon/PagingFile$PagingPercentProperty oshi/driver/windows/perfmon/PagingFile PagingPercentProperty public,static,final,enum
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner com/sun/jna/platform/win32/BaseTSD$SIZE_T com/sun/jna/platform/win32/BaseTSD SIZE_T public,static
 inner oshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty oshi/driver/windows/perfmon/MemoryInformation PageSwapProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
in 39
class oshi/hardware/platform/windows/WindowsVirtualMemory 52 final,super oshi/hardware/common/AbstractVirtualMemory - -
 inner oshi/driver/windows/perfmon/PagingFile$PagingPercentProperty oshi/driver/windows/perfmon/PagingFile PagingPercentProperty public,static,final,enum
 inner oshi/jna/Struct$CloseablePerformanceInformation oshi/jna/Struct CloseablePerformanceInformation public,static
 inner com/sun/jna/platform/win32/Psapi$PERFORMANCE_INFORMATION com/sun/jna/platform/win32/Psapi PERFORMANCE_INFORMATION public,static
 inner com/sun/jna/platform/win32/BaseTSD$SIZE_T com/sun/jna/platform/win32/BaseTSD SIZE_T public,static
 inner oshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty oshi/driver/windows/perfmon/MemoryInformation PageSwapProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getSwapUsed ()J - -
 method public getSwapTotal ()J - -
 method public getVirtualMax ()J - -
 method public getVirtualInUse ()J - -
 method public getSwapPagesIn ()J - -
 method public getSwapPagesOut ()J - -
