cg-stub-db 1
in 96
class net/minecraft/gametest/Main 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static main ([Ljava/lang/String;)V - java/lang/Exception
in 82
class net/minecraft/gametest/framework/AfterBatch 60 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract batch ()Ljava/lang/String; - -
in 93
class net/minecraft/gametest/framework/AfterBatch 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract batch ()Ljava/lang/String; - -
in 128
class net/minecraft/gametest/framework/AfterBatch 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract batch ()Ljava/lang/String; - -
in 82
class net/minecraft/gametest/framework/BeforeBatch 60 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract batch ()Ljava/lang/String; - -
in 93
class net/minecraft/gametest/framework/BeforeBatch 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract batch ()Ljava/lang/String; - -
in 128
class net/minecraft/gametest/framework/BeforeBatch 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract batch ()Ljava/lang/String; - -
in 96
class net/minecraft/gametest/framework/BlockBasedTestInstance 65 public,super net/minecraft/gametest/framework/GameTestInstance - -
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P1 com/mojang/datafixers/Products P1 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/BlockBasedTestInstance;>;
 method public <init> (Lnet/minecraft/gametest/framework/TestData;)V (Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)V -
 method public run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/BlockBasedTestInstance;>; -
 method protected typeDescription ()Lnet/minecraft/network/chat/MutableComponent; - -
in 96
class net/minecraft/gametest/framework/BuiltinTestFunctions 65 public,super net/minecraft/gametest/framework/TestFunctionLoader - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final ALWAYS_PASS Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;
 field public,static,final ALWAYS_PASS_INSTANCE Ljava/util/function/Consumer; Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;
 method public <init> ()V - -
 method public,static bootstrap (Lnet/minecraft/core/Registry;)Ljava/util/function/Consumer; (Lnet/minecraft/core/Registry<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;)Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>; -
 method public load (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;)V -
in 82
class net/minecraft/gametest/framework/ExhaustedAttemptsException 60 super java/lang/Throwable - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (IILnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 93
class net/minecraft/gametest/framework/ExhaustedAttemptsException 61 super java/lang/Throwable - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (IILnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 60
class net/minecraft/gametest/framework/ExhaustedAttemptsException 65 super java/lang/Throwable - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (IILnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 96
class net/minecraft/gametest/framework/FailedTestTracker 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 method public <init> ()V - -
 method public,static getLastFailedTests ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public,static rememberFailedTest (Lnet/minecraft/core/Holder$Reference;)V (Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;)V -
 method public,static forgetFailedTests ()V - -
in 96
class net/minecraft/gametest/framework/FunctionGameTestInstance 65 public,super net/minecraft/gametest/framework/GameTestInstance - -
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/FunctionGameTestInstance;>;
 method public <init> (Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/gametest/framework/TestData;)V (Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)V -
 method public run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/FunctionGameTestInstance;>; -
 method protected typeDescription ()Lnet/minecraft/network/chat/MutableComponent; - -
 method public describe ()Lnet/minecraft/network/chat/Component; - -
in 82
class net/minecraft/gametest/framework/GameTest 60 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract timeoutTicks ()I - - I100
 method public,abstract batch ()Ljava/lang/String; - - "defaultBatch"
 method public,abstract rotationSteps ()I - - I0
 method public,abstract required ()Z - - Z1
 method public,abstract template ()Ljava/lang/String; - - ""
 method public,abstract setupTicks ()J - - J0
 method public,abstract attempts ()I - - I1
 method public,abstract requiredSuccesses ()I - - I1
in 374
class net/minecraft/gametest/framework/GameTest 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract timeoutTicks ()I - - I100
 method public,abstract batch ()Ljava/lang/String; - - "defaultBatch"
 method public,abstract rotationSteps ()I - - I0
 method public,abstract required ()Z - - Z1
 method public,abstract templateNamespace ()Ljava/lang/String; - - ""
 method public,abstract template ()Ljava/lang/String; - - ""
 method public,abstract setupTicks ()J - - J0
 method public,abstract attempts ()I - - I1
 method public,abstract requiredSuccesses ()I - - I1
in 496
class net/minecraft/gametest/framework/GameTest 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract timeoutTicks ()I - - I100
 method public,abstract batch ()Ljava/lang/String; - - "defaultBatch"
 method public,abstract rotationSteps ()I - - I0
 method public,abstract required ()Z - - Z1
 method public,abstract template ()Ljava/lang/String; - - ""
 method public,abstract setupTicks ()J - - J0
 method public,abstract attempts ()I - - I1
 method public,abstract requiredSuccesses ()I - - I1
in 305
class net/minecraft/gametest/framework/GameTest 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract timeoutTicks ()I - - I100
 method public,abstract batch ()Ljava/lang/String; - - "defaultBatch"
 method public,abstract skyAccess ()Z - - Z0
 method public,abstract rotationSteps ()I - - I0
 method public,abstract required ()Z - - Z1
 method public,abstract manualOnly ()Z - - Z0
 method public,abstract template ()Ljava/lang/String; - - ""
 method public,abstract setupTicks ()J - - J0
 method public,abstract attempts ()I - - I1
 method public,abstract requiredSuccesses ()I - - I1
in 306
class net/minecraft/gametest/framework/GameTest 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
 method public,abstract timeoutTicks ()I - - I100
 method public,abstract batch ()Ljava/lang/String; - - "defaultBatch"
 method public,abstract skyAccess ()Z - - Z0
 method public,abstract rotationSteps ()I - - I0
 method public,abstract required ()Z - - Z1
 method public,abstract manualOnly ()Z - - Z0
 method public,abstract templateNamespace ()Ljava/lang/String; - - ""
 method public,abstract template ()Ljava/lang/String; - - ""
 method public,abstract setupTicks ()J - - J0
 method public,abstract attempts ()I - - I1
 method public,abstract requiredSuccesses ()I - - I1
in 175
class net/minecraft/gametest/framework/GameTestAssertException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 82
class net/minecraft/gametest/framework/GameTestAssertException 60 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 93
class net/minecraft/gametest/framework/GameTestAssertException 61 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 128
class net/minecraft/gametest/framework/GameTestAssertException 65 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 96
class net/minecraft/gametest/framework/GameTestAssertException 65 public,super net/minecraft/gametest/framework/GameTestException - -
 field protected,final message Lnet/minecraft/network/chat/Component; -
 field protected,final tick I -
 method public <init> (Lnet/minecraft/network/chat/Component;I)V - -
 method public getDescription ()Lnet/minecraft/network/chat/Component; - -
 method public getMessage ()Ljava/lang/String; - -
in 175
class net/minecraft/gametest/framework/GameTestAssertPosException 52 public,super net/minecraft/gametest/framework/GameTestAssertException - -
 method public getMessage ()Ljava/lang/String; - -
 method public getMessageToShowAtBlock ()Ljava/lang/String; - -
 method public getAbsolutePos ()Lnet/minecraft/core/BlockPos; - -
in 82
class net/minecraft/gametest/framework/GameTestAssertPosException 60 public,super net/minecraft/gametest/framework/GameTestAssertException - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;J)V - -
 method public getMessage ()Ljava/lang/String; - -
 method public getMessageToShowAtBlock ()Ljava/lang/String; - -
 method public getRelativePos ()Lnet/minecraft/core/BlockPos; - -
 method public getAbsolutePos ()Lnet/minecraft/core/BlockPos; - -
in 93
class net/minecraft/gametest/framework/GameTestAssertPosException 61 public,super net/minecraft/gametest/framework/GameTestAssertException - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;J)V - -
 method public getMessage ()Ljava/lang/String; - -
 method public getMessageToShowAtBlock ()Ljava/lang/String; - -
 method public getRelativePos ()Lnet/minecraft/core/BlockPos; - -
 method public getAbsolutePos ()Lnet/minecraft/core/BlockPos; - -
in 128
class net/minecraft/gametest/framework/GameTestAssertPosException 65 public,super net/minecraft/gametest/framework/GameTestAssertException - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;J)V - -
 method public getMessage ()Ljava/lang/String; - -
 method public getMessageToShowAtBlock ()Ljava/lang/String; - -
 method public getRelativePos ()Lnet/minecraft/core/BlockPos; - -
 method public getAbsolutePos ()Lnet/minecraft/core/BlockPos; - -
in 80
class net/minecraft/gametest/framework/GameTestAssertPosException 65 public,super net/minecraft/gametest/framework/GameTestAssertException - -
 method public <init> (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;I)V - -
 method public getDescription ()Lnet/minecraft/network/chat/Component; - -
 method public getMessageToShowAtBlock ()Ljava/lang/String; - -
 method public getRelativePos ()Lnet/minecraft/core/BlockPos; - -
 method public getAbsolutePos ()Lnet/minecraft/core/BlockPos; - -
in 74
class net/minecraft/gametest/framework/GameTestAssertPosException 65 public,super net/minecraft/gametest/framework/GameTestAssertException - -
 method public <init> (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;I)V - -
 method public getDescription ()Lnet/minecraft/network/chat/Component; - -
 method public getMessageToShowAtBlock ()Lnet/minecraft/network/chat/Component; - -
 method public getRelativePos ()Lnet/minecraft/core/BlockPos; - -
 method public getAbsolutePos ()Lnet/minecraft/core/BlockPos; - -
in 175
class net/minecraft/gametest/framework/GameTestBatch 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/util/Collection;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public runBeforeBatchFunction (Lnet/minecraft/server/level/ServerLevel;)V - -
in 82
class net/minecraft/gametest/framework/GameTestBatch 60 public,super java/lang/Object - -
 field public,static,final DEFAULT_BATCH_NAME Ljava/lang/String; - "defaultBatch"
 method public <init> (Ljava/lang/String;Ljava/util/Collection;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>;Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public runBeforeBatchFunction (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public runAfterBatchFunction (Lnet/minecraft/server/level/ServerLevel;)V - -
in 93
class net/minecraft/gametest/framework/GameTestBatch 61 public,super java/lang/Object - -
 field public,static,final DEFAULT_BATCH_NAME Ljava/lang/String; - "defaultBatch"
 method public <init> (Ljava/lang/String;Ljava/util/Collection;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>;Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>;)V -
 method public getName ()Ljava/lang/String; - -
 method public getTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public runBeforeBatchFunction (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public runAfterBatchFunction (Lnet/minecraft/server/level/ServerLevel;)V - -
in 128
class net/minecraft/gametest/framework/GameTestBatch 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_BATCH_NAME Ljava/lang/String; - "defaultBatch"
 method public <init> (Ljava/lang/String;Ljava/util/Collection;Ljava/util/function/Consumer;Ljava/util/function/Consumer;)V (Ljava/lang/String;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>;Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public name ()Ljava/lang/String; - -
 method public gameTestInfos ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public beforeBatchFunction ()Ljava/util/function/Consumer; ()Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public afterBatchFunction ()Ljava/util/function/Consumer; ()Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
in 96
class net/minecraft/gametest/framework/GameTestBatch 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILjava/util/Collection;Lnet/minecraft/core/Holder;)V (ILjava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public index ()I - -
 method public gameTestInfos ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public environment ()Lnet/minecraft/core/Holder; ()Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
in 224
class net/minecraft/gametest/framework/GameTestBatchFactory 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/google/common/collect/Streams$FunctionWithIndex com/google/common/collect/Streams FunctionWithIndex public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static fromTestFunction (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static toGameTestInfo (Lnet/minecraft/gametest/framework/TestFunction;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public,static fromGameTestInfo ()Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher; - -
in 282
class net/minecraft/gametest/framework/GameTestBatchFactory 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/google/common/collect/Streams$FunctionWithIndex com/google/common/collect/Streams FunctionWithIndex public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static fromTestFunction (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static toGameTestInfo (Lnet/minecraft/gametest/framework/TestFunction;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public,static fromGameTestInfo ()Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher; - -
 method public,static fromGameTestInfo (I)Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher; - -
 method public,static toGameTestBatch (Ljava/util/Collection;Ljava/lang/String;J)Lnet/minecraft/gametest/framework/GameTestBatch; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;Ljava/lang/String;J)Lnet/minecraft/gametest/framework/GameTestBatch; -
in 96
class net/minecraft/gametest/framework/GameTestBatchFactory 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/google/common/collect/Streams$FunctionWithIndex com/google/common/collect/Streams FunctionWithIndex public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DIRECT Lnet/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator; -
 method public <init> ()V - -
 method public,static divideIntoBatches (Ljava/util/Collection;Lnet/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/List; (Ljava/util/Collection<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>;Lnet/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static fromGameTestInfo ()Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher; - -
 method public,static fromGameTestInfo (I)Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher; - -
 method public,static toGameTestBatch (Ljava/util/Collection;Lnet/minecraft/core/Holder;I)Lnet/minecraft/gametest/framework/GameTestBatch; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;I)Lnet/minecraft/gametest/framework/GameTestBatch; -
in 96
class net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 method public,abstract decorate (Lnet/minecraft/core/Holder$Reference;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
in 60
class net/minecraft/gametest/framework/GameTestBatchListener 65 public,interface,abstract java/lang/Object - -
 method public,abstract testBatchStarting (Lnet/minecraft/gametest/framework/GameTestBatch;)V - -
 method public,abstract testBatchFinished (Lnet/minecraft/gametest/framework/GameTestBatch;)V - -
in 115
class net/minecraft/gametest/framework/GameTestBatchRunner 52 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;)V -
 method public getTestInfos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public start ()V - -
in 86
class net/minecraft/gametest/framework/GameTestBatchRunner 52 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)V -
 method public getTestInfos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public start ()V - -
in 82
class net/minecraft/gametest/framework/GameTestBatchRunner 60 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)V -
 method public getTestInfos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public start ()V - -
in 93
class net/minecraft/gametest/framework/GameTestBatchRunner 61 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)V -
 method public getTestInfos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public start ()V - -
in 96
class net/minecraft/gametest/framework/GameTestEnvironments 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf net/minecraft/gametest/framework/TestEnvironmentDefinition AllOf public,static,final
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 field public,static,final DEFAULT Ljava/lang/String; - "default"
 field public,static,final DEFAULT_KEY Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;
 method public,static bootstrap (Lnet/minecraft/data/worldgen/BootstrapContext;)V (Lnet/minecraft/data/worldgen/BootstrapContext<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;)V -
in 175
class net/minecraft/gametest/framework/GameTestEvent 52 super java/lang/Object - -
 field public,final expectedDelay Ljava/lang/Long; -
 field public,final assertion Ljava/lang/Runnable; -
in 82
class net/minecraft/gametest/framework/GameTestEvent 60 super java/lang/Object - -
 field public,final expectedDelay Ljava/lang/Long; -
 field public,final assertion Ljava/lang/Runnable; -
in 93
class net/minecraft/gametest/framework/GameTestEvent 61 super java/lang/Object - -
 field public,final expectedDelay Ljava/lang/Long; -
 field public,final assertion Ljava/lang/Runnable; -
in 60
class net/minecraft/gametest/framework/GameTestEvent 65 super java/lang/Object - -
 field public,final expectedDelay Ljava/lang/Long; -
 field public,final assertion Ljava/lang/Runnable; -
in 96
class net/minecraft/gametest/framework/GameTestException 65 public,super,abstract java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public,abstract getDescription ()Lnet/minecraft/network/chat/Component; - -
in 82
class net/minecraft/gametest/framework/GameTestGenerator 60 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 93
class net/minecraft/gametest/framework/GameTestGenerator 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 128
class net/minecraft/gametest/framework/GameTestGenerator 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Target;(value=[ELjava/lang/annotation/ElementType;#METHOD])
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#RUNTIME)
in 115
class net/minecraft/gametest/framework/GameTestHelper 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 86
class net/minecraft/gametest/framework/GameTestHelper 52 public,super java/lang/Object - -
 inner net/minecraft/tags/Tag$Named net/minecraft/tags/Tag Named public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 82
class net/minecraft/gametest/framework/GameTestHelper 60 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/tags/Tag$Named net/minecraft/tags/Tag Named public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTick ()J - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
in 84
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTick ()J - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
in 83
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTick ()J - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
in 90
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockSurvivalPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
in 233
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public continuouslyUse (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockSurvivalPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
in 76
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockSurvivalPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
in 72
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/network/ConnectionProtocol$CodecData net/minecraft/network/ConnectionProtocol CodecData public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockSurvivalPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/effect/MobEffect;I)V - -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
in 255
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/network/ConnectionProtocol$CodecData net/minecraft/network/ConnectionProtocol CodecData public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockSurvivalPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/effect/MobEffect;I)V - -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 184
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 185
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/lang/String;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 266
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/lang/String;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 497
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public assertionException (Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public,varargs assertionException (Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public assertionException (Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public,varargs assertionException (Lnet/minecraft/core/BlockPos;Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/world/entity/Entity;>;)V -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockTag (Lnet/minecraft/tags/TagKey;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/tags/TagKey<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContainsSingle (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;TT;Lnet/minecraft/network/chat/Component;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public assertTrue (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <N:Ljava/lang/Object;>(TN;TN;Lnet/minecraft/network/chat/Component;)V -
 method public assertFalse (ZLnet/minecraft/network/chat/Component;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 120
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public assertionException (Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public,varargs assertionException (Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public assertionException (Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public,varargs assertionException (Lnet/minecraft/core/BlockPos;Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/world/entity/Entity;>;)V -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockTag (Lnet/minecraft/tags/TagKey;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/tags/TagKey<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContainsSingle (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;TT;Lnet/minecraft/network/chat/Component;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestDirection ()Lnet/minecraft/core/Direction; - -
 method public assertTrue (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <N:Ljava/lang/Object;>(TN;TN;Lnet/minecraft/network/chat/Component;)V -
 method public assertFalse (ZLnet/minecraft/network/chat/Component;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 121
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public assertionException (Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public,varargs assertionException (Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public assertionException (Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public,varargs assertionException (Lnet/minecraft/core/BlockPos;Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/world/entity/Entity;>;)V -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/entity/EntitySpawnReason;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/entity/EntitySpawnReason;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;IIILnet/minecraft/world/entity/EntitySpawnReason;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIILnet/minecraft/world/entity/EntitySpawnReason;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockTag (Lnet/minecraft/tags/TagKey;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/tags/TagKey<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityData (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/world/phys/AABB;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContainsSingle (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;TT;Lnet/minecraft/network/chat/Component;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestDirection ()Lnet/minecraft/core/Direction; - -
 method public getAbsoluteDirection (Lnet/minecraft/core/Direction;)Lnet/minecraft/core/Direction; - -
 method public assertTrue (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <N:Ljava/lang/Object;>(TN;TN;Lnet/minecraft/network/chat/Component;)V -
 method public assertFalse (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getRelativeBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 191
class net/minecraft/gametest/framework/GameTestHelper 61 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/network/ConnectionProtocol$CodecData net/minecraft/network/ConnectionProtocol CodecData public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final testInfo Lnet/minecraft/gametest/framework/GameTestInfo; -
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockSurvivalPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/effect/MobEffect;I)V - -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 192
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final testInfo Lnet/minecraft/gametest/framework/GameTestInfo; -
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 193
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final testInfo Lnet/minecraft/gametest/framework/GameTestInfo; -
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/lang/String;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 17
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final testInfo Lnet/minecraft/gametest/framework/GameTestInfo; -
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/lang/String;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/lang/String;)V -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Ljava/lang/String;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/lang/String;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/lang/String;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Ljava/lang/String;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Ljava/lang/String;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/String;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;Ljava/lang/String;TT;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Ljava/lang/String;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Ljava/lang/String;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 146
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final testInfo Lnet/minecraft/gametest/framework/GameTestInfo; -
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public assertionException (Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public,varargs assertionException (Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public assertionException (Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public,varargs assertionException (Lnet/minecraft/core/BlockPos;Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/world/entity/Entity;>;)V -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockTag (Lnet/minecraft/tags/TagKey;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/tags/TagKey<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContainsSingle (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;TT;Lnet/minecraft/network/chat/Component;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public assertTrue (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <N:Ljava/lang/Object;>(TN;TN;Lnet/minecraft/network/chat/Component;)V -
 method public assertFalse (ZLnet/minecraft/network/chat/Component;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 123
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final testInfo Lnet/minecraft/gametest/framework/GameTestInfo; -
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public assertionException (Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public,varargs assertionException (Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public assertionException (Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public,varargs assertionException (Lnet/minecraft/core/BlockPos;Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/world/entity/Entity;>;)V -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)V - -
 method public setNight ()V - -
 method public setDayTime (I)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockTag (Lnet/minecraft/tags/TagKey;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/tags/TagKey<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContainsSingle (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityPosition (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V - -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;TT;Lnet/minecraft/network/chat/Component;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestDirection ()Lnet/minecraft/core/Direction; - -
 method public assertTrue (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <N:Ljava/lang/Object;>(TN;TN;Lnet/minecraft/network/chat/Component;)V -
 method public assertFalse (ZLnet/minecraft/network/chat/Component;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 48
class net/minecraft/gametest/framework/GameTestHelper 65 public,super java/lang/Object net/neoforged/neoforge/common/extensions/GameTestHelperExtension -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/InteractionResult$TryEmptyHandInteraction net/minecraft/world/InteractionResult TryEmptyHandInteraction public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final testInfo Lnet/minecraft/gametest/framework/GameTestInfo; -
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public assertionException (Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public,varargs assertionException (Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertException; - -
 method public assertionException (Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/chat/Component;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public,varargs assertionException (Lnet/minecraft/core/BlockPos;Ljava/lang/String;[Ljava/lang/Object;)Lnet/minecraft/gametest/framework/GameTestAssertPosException; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public getBlockState (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getBlockEntity (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;)Lnet/minecraft/world/level/block/entity/BlockEntity; <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;)TT; -
 method public killAllEntities ()V - -
 method public killAllEntitiesOfClass (Ljava/lang/Class;)V (Ljava/lang/Class<+Lnet/minecraft/world/entity/Entity;>;)V -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;FFF)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawnItem (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/item/ItemEntity; - -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;I)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/entity/EntitySpawnReason;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/entity/EntitySpawnReason;)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;IIILnet/minecraft/world/entity/EntitySpawnReason;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIILnet/minecraft/world/entity/EntitySpawnReason;)TE; -
 method public hurt (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;F)V - -
 method public kill (Lnet/minecraft/world/entity/Entity;)V - -
 method public findOneEntity (Lnet/minecraft/world/entity/EntityType;)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;)TE; -
 method public findClosestEntity (Lnet/minecraft/world/entity/EntityType;IIID)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)TE; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;IIID)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;IIID)Ljava/util/List<TE;>; -
 method public findEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;D)Ljava/util/List<TE;>; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawn (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Entity; <E:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/core/BlockPos;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;III)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;III)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/phys/Vec3;)TE; -
 method public spawnWithNoFreeWill (Lnet/minecraft/world/entity/EntityType;FFF)Lnet/minecraft/world/entity/Mob; <E:Lnet/minecraft/world/entity/Mob;>(Lnet/minecraft/world/entity/EntityType<TE;>;FFF)TE; -
 method public moveTo (Lnet/minecraft/world/entity/Mob;FFF)V - -
 method public walkTo (Lnet/minecraft/world/entity/Mob;Lnet/minecraft/core/BlockPos;F)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public pressButton (III)V - -
 method public pressButton (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V - -
 method public useBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/BlockHitResult;)V - -
 method public makeAboutToDrown (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public withLowHealth (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public makeMockPlayer (Lnet/minecraft/world/level/GameType;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated makeMockServerPlayerInLevel ()Lnet/minecraft/server/level/ServerPlayer; - -
 method public pullLever (III)V - -
 method public pullLever (Lnet/minecraft/core/BlockPos;)V - -
 method public pulseRedstone (Lnet/minecraft/core/BlockPos;J)V - -
 method public destroyBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (IIILnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/Direction;)V - -
 method public setBlock (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public assertBlockNotPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlockTag (Lnet/minecraft/tags/TagKey;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/tags/TagKey<Lnet/minecraft/world/level/block/Block;>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;III)V - -
 method public succeedWhenBlockPresent (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/core/BlockPos;)V - -
 method public assertBlock (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/Block;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/lang/Comparable;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;TT;)V -
 method public assertBlockProperty (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <T::Ljava/lang/Comparable<TT;>;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/properties/Property<TT;>;Ljava/util/function/Predicate<TT;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public assertBlockState (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate;Ljava/util/function/Function;)V (Lnet/minecraft/core/BlockPos;Ljava/util/function/Predicate<Lnet/minecraft/world/level/block/state/BlockState;>;Ljava/util/function/Function<Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/network/chat/Component;>;)V -
 method public assertBlockEntityData (Lnet/minecraft/core/BlockPos;Ljava/lang/Class;Ljava/util/function/Predicate;Ljava/util/function/Supplier;)V <T:Lnet/minecraft/world/level/block/entity/BlockEntity;>(Lnet/minecraft/core/BlockPos;Ljava/lang/Class<TT;>;Ljava/util/function/Predicate<TT;>;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertRedstoneSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier;)V (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;Ljava/util/function/IntPredicate;Ljava/util/function/Supplier<Lnet/minecraft/network/chat/Component;>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;I)V (Lnet/minecraft/world/entity/EntityType<*>;I)V -
 method public assertEntitiesPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;ID)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;ID)V -
 method public assertEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;D)V -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;D)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;Lnet/minecraft/core/BlockPos;D)Ljava/util/List<TT;>; -
 method public getEntities (Lnet/minecraft/world/entity/EntityType;)Ljava/util/List; <T:Lnet/minecraft/world/entity/Entity;>(Lnet/minecraft/world/entity/EntityType<TT;>;)Ljava/util/List<TT;>; -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;III)V - -
 method public assertEntityInstancePresent (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/BlockPos;)V - -
 method public assertItemEntityCountIs (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;DI)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;Lnet/minecraft/core/BlockPos;D)V - -
 method public assertItemEntityPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertItemEntityNotPresent (Lnet/minecraft/world/item/Item;)V - -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;)V (Lnet/minecraft/world/entity/EntityType<*>;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public assertEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/phys/AABB;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/phys/AABB;)V -
 method public assertEntityTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityNotTouching (Lnet/minecraft/world/entity/EntityType;DDD)V (Lnet/minecraft/world/entity/EntityType<*>;DDD)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Predicate;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Predicate<TE;>;)V -
 method public assertEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityData (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/world/phys/AABB;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<-TE;TT;>;TT;)V -
 method public assertEntityIsHolding (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/LivingEntity;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertEntityInventoryContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/item/Item;)V <E:Lnet/minecraft/world/entity/Entity;:Lnet/minecraft/world/entity/npc/InventoryCarrier;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Lnet/minecraft/world/item/Item;)V -
 method public assertContainerEmpty (Lnet/minecraft/core/BlockPos;)V - -
 method public assertContainerContainsSingle (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertContainerContains (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertSameBlockStates (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/core/BlockPos;)V - -
 method public assertSameBlockState (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)V - -
 method public assertAtTickTimeContainerContains (JLnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/Item;)V - -
 method public assertAtTickTimeContainerEmpty (JLnet/minecraft/core/BlockPos;)V - -
 method public succeedWhenEntityData (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType;Ljava/util/function/Function;Ljava/lang/Object;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/EntityType<TE;>;Ljava/util/function/Function<TE;TT;>;TT;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;>(TE;Ljava/util/function/Predicate<TE;>;Lnet/minecraft/network/chat/Component;)V -
 method public assertEntityProperty (Lnet/minecraft/world/entity/Entity;Ljava/util/function/Function;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <E:Lnet/minecraft/world/entity/Entity;T:Ljava/lang/Object;>(TE;Ljava/util/function/Function<TE;TT;>;TT;Lnet/minecraft/network/chat/Component;)V -
 method public assertLivingEntityHasMobEffect (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder;I)V (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/core/Holder<Lnet/minecraft/world/effect/MobEffect;>;I)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;III)V (Lnet/minecraft/world/entity/EntityType<*>;III)V -
 method public succeedWhenEntityNotPresent (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/core/BlockPos;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/core/BlockPos;)V -
 method public succeed ()V - -
 method public succeedIf (Ljava/lang/Runnable;)V - -
 method public succeedWhen (Ljava/lang/Runnable;)V - -
 method public succeedOnTickWhen (ILjava/lang/Runnable;)V - -
 method public runAtTickTime (JLjava/lang/Runnable;)V - -
 method public runAfterDelay (JLjava/lang/Runnable;)V - -
 method public randomTick (Lnet/minecraft/core/BlockPos;)V - -
 method public tickBlock (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation (Lnet/minecraft/core/BlockPos;)V - -
 method public tickPrecipitation ()V - -
 method public getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/BlockPos;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;Lnet/minecraft/world/entity/Entity;)V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Ljava/lang/String;)V - -
 method public failIf (Ljava/lang/Runnable;)V - -
 method public failIfEver (Ljava/lang/Runnable;)V - -
 method public startSequence ()Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public absolutePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public relativePos (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public absoluteAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public relativeAABB (Lnet/minecraft/world/phys/AABB;)Lnet/minecraft/world/phys/AABB; - -
 method public absoluteVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public relativeVec (Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3; - -
 method public getTestRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestDirection ()Lnet/minecraft/core/Direction; - -
 method public getAbsoluteDirection (Lnet/minecraft/core/Direction;)Lnet/minecraft/core/Direction; - -
 method public assertTrue (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertTrue (ZLjava/lang/String;)V - -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V <N:Ljava/lang/Object;>(TN;TN;Ljava/lang/String;)V -
 method public assertValueEqual (Ljava/lang/Object;Ljava/lang/Object;Lnet/minecraft/network/chat/Component;)V <N:Ljava/lang/Object;>(TN;TN;Lnet/minecraft/network/chat/Component;)V -
 method public assertFalse (ZLnet/minecraft/network/chat/Component;)V - -
 method public assertFalse (ZLjava/lang/String;)V - -
 method public getTick ()J - -
 method public getBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getRelativeBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public forEveryBlockInStructure (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/core/BlockPos;>;)V -
 method public onEachTick (Ljava/lang/Runnable;)V - -
 method public placeAt (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V - -
 method public setBiome (Lnet/minecraft/resources/ResourceKey;)V (Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/world/level/biome/Biome;>;)V -
in 115
class net/minecraft/gametest/framework/GameTestInfo 52 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public tick ()V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getTestPos ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureSize ()Lnet/minecraft/core/BlockPos; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public spawnStructure (I)V - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
in 86
class net/minecraft/gametest/framework/GameTestInfo 52 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public tick ()V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public spawnStructure (Lnet/minecraft/core/BlockPos;I)V - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
in 82
class net/minecraft/gametest/framework/GameTestInfo 60 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public tick ()V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureSize ()Lnet/minecraft/core/Vec3i; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public spawnStructure (Lnet/minecraft/core/BlockPos;I)V - -
 method public clearStructure ()V - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
in 223
class net/minecraft/gametest/framework/GameTestInfo 61 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public tick ()V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureSize ()Lnet/minecraft/core/Vec3i; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public spawnStructure (Lnet/minecraft/core/BlockPos;I)V - -
 method public clearStructure ()V - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
in 255
class net/minecraft/gametest/framework/GameTestInfo 61 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public tick ()V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureSize ()Lnet/minecraft/core/Vec3i; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure (Lnet/minecraft/core/BlockPos;)V - -
 method public clearStructure ()V - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public setRerunUntilFailed (Z)V - -
 method public rerunUntilFailed ()Z - -
in 265
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getStructureBlockEntity ()Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public setNorthWestCorner (Lnet/minecraft/core/BlockPos;)V - -
in 266
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getTestOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getStructureBlockEntity ()Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public getOrCalculateNorthwestCorner ()Lnet/minecraft/core/BlockPos; - -
 method public setNorthWestCorner (Lnet/minecraft/core/BlockPos;)V - -
in 149
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Data net/minecraft/world/level/block/entity/TestInstanceBlockEntity Data public,static,final
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Status net/minecraft/world/level/block/entity/TestInstanceBlockEntity Status public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Holder$Reference;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V (Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V -
 method public setTestBlockPos (Lnet/minecraft/core/BlockPos;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()V - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public id ()Lnet/minecraft/resources/ResourceLocation; - -
 method public getTestBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getTestOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getTestInstanceBlockEntity ()Lnet/minecraft/world/level/block/entity/TestInstanceBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Lnet/minecraft/gametest/framework/GameTestException;)V - -
 method public getError ()Lnet/minecraft/gametest/framework/GameTestException; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructure ()Lnet/minecraft/resources/ResourceLocation; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTest ()Lnet/minecraft/gametest/framework/GameTestInstance; - -
 method public getTestHolder ()Lnet/minecraft/core/Holder$Reference; ()Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
in 121
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Data net/minecraft/world/level/block/entity/TestInstanceBlockEntity Data public,static,final
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Status net/minecraft/world/level/block/entity/TestInstanceBlockEntity Status public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/Holder$Reference;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V (Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V -
 method public setTestBlockPos (Lnet/minecraft/core/BlockPos;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()V - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public id ()Lnet/minecraft/resources/Identifier; - -
 method public getTestBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getTestOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getTestInstanceBlockEntity ()Lnet/minecraft/world/level/block/entity/TestInstanceBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Lnet/minecraft/gametest/framework/GameTestException;)V - -
 method public getError ()Lnet/minecraft/gametest/framework/GameTestException; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructure ()Lnet/minecraft/resources/Identifier; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTest ()Lnet/minecraft/gametest/framework/GameTestInstance; - -
 method public getTestHolder ()Lnet/minecraft/core/Holder$Reference; ()Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
in 191
class net/minecraft/gametest/framework/GameTestInfo 61 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final sequences Ljava/util/Collection; Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestSequence;>;
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public tick ()V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureSize ()Lnet/minecraft/core/Vec3i; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure (Lnet/minecraft/core/BlockPos;)V - -
 method public clearStructure ()V - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public setRerunUntilFailed (Z)V - -
 method public rerunUntilFailed ()Z - -
in 209
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final sequences Ljava/util/Collection; Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestSequence;>;
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getStructureBlockEntity ()Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public setNorthWestCorner (Lnet/minecraft/core/BlockPos;)V - -
in 17
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final sequences Ljava/util/Collection; Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestSequence;>;
 method public <init> (Lnet/minecraft/gametest/framework/TestFunction;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getTestOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getStructureBlockEntity ()Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Ljava/lang/Throwable;)V - -
 method public getError ()Ljava/lang/Throwable; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructureName ()Ljava/lang/String; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTestFunction ()Lnet/minecraft/gametest/framework/TestFunction; - -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public getOrCalculateNorthwestCorner ()Lnet/minecraft/core/BlockPos; - -
 method public setNorthWestCorner (Lnet/minecraft/core/BlockPos;)V - -
in 150
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Data net/minecraft/world/level/block/entity/TestInstanceBlockEntity Data public,static,final
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Status net/minecraft/world/level/block/entity/TestInstanceBlockEntity Status public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final sequences Ljava/util/Collection; Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestSequence;>;
 method public <init> (Lnet/minecraft/core/Holder$Reference;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V (Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V -
 method public setTestBlockPos (Lnet/minecraft/core/BlockPos;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()V - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public id ()Lnet/minecraft/resources/ResourceLocation; - -
 method public getTestBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getTestOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getTestInstanceBlockEntity ()Lnet/minecraft/world/level/block/entity/TestInstanceBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Lnet/minecraft/gametest/framework/GameTestException;)V - -
 method public getError ()Lnet/minecraft/gametest/framework/GameTestException; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructure ()Lnet/minecraft/resources/ResourceLocation; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTest ()Lnet/minecraft/gametest/framework/GameTestInstance; - -
 method public getTestHolder ()Lnet/minecraft/core/Holder$Reference; ()Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
in 48
class net/minecraft/gametest/framework/GameTestInfo 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner it/unimi/dsi/fastutil/objects/Object2LongMap$Entry it/unimi/dsi/fastutil/objects/Object2LongMap Entry public,static,interface,abstract
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Data net/minecraft/world/level/block/entity/TestInstanceBlockEntity Data public,static,final
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Status net/minecraft/world/level/block/entity/TestInstanceBlockEntity Status public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final sequences Ljava/util/Collection; Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestSequence;>;
 method public <init> (Lnet/minecraft/core/Holder$Reference;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V (Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/RetryOptions;)V -
 method public setTestBlockPos (Lnet/minecraft/core/BlockPos;)V - -
 method public startExecution (I)Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public placeStructure ()V - -
 method public tick (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public setRunAtTickTime (JLjava/lang/Runnable;)V - -
 method public id ()Lnet/minecraft/resources/Identifier; - -
 method public getTestBlockPos ()Lnet/minecraft/core/BlockPos; - -
 method public getTestOrigin ()Lnet/minecraft/core/BlockPos; - -
 method public getStructureBounds ()Lnet/minecraft/world/phys/AABB; - -
 method public getTestInstanceBlockEntity ()Lnet/minecraft/world/level/block/entity/TestInstanceBlockEntity; - -
 method public getLevel ()Lnet/minecraft/server/level/ServerLevel; - -
 method public hasSucceeded ()Z - -
 method public hasFailed ()Z - -
 method public hasStarted ()Z - -
 method public isDone ()Z - -
 method public getRunTime ()J - -
 method public succeed ()V - -
 method public fail (Lnet/minecraft/network/chat/Component;)V - -
 method public fail (Lnet/minecraft/gametest/framework/GameTestException;)V - -
 method public getError ()Lnet/minecraft/gametest/framework/GameTestException; - -
 method public toString ()Ljava/lang/String; - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public prepareTestStructure ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
 method public isRequired ()Z - -
 method public isOptional ()Z - -
 method public getStructure ()Lnet/minecraft/resources/Identifier; - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public getTest ()Lnet/minecraft/gametest/framework/GameTestInstance; - -
 method public getTestHolder ()Lnet/minecraft/core/Holder$Reference; ()Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method public getTimeoutTicks ()I - -
 method public isFlaky ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public retryOptions ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public getListeners ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/GameTestListener;>; -
 method public copyReset ()Lnet/minecraft/gametest/framework/GameTestInfo; - -
in 167
class net/minecraft/gametest/framework/GameTestInstance 65 public,super,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DIRECT_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/gametest/framework/GameTestInstance;>;
 method public,static bootstrap (Lnet/minecraft/core/Registry;)Lcom/mojang/serialization/MapCodec; (Lnet/minecraft/core/Registry<Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/GameTestInstance;>;>;)Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method protected <init> (Lnet/minecraft/gametest/framework/TestData;)V (Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)V -
 method public,abstract run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public,abstract codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method public batch ()Lnet/minecraft/core/Holder; ()Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
 method public structure ()Lnet/minecraft/resources/ResourceLocation; - -
 method public maxTicks ()I - -
 method public setupTicks ()I - -
 method public required ()Z - -
 method public manualOnly ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public skyAccess ()Z - -
 method public rotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method protected info ()Lnet/minecraft/gametest/framework/TestData; ()Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>; -
 method protected,abstract typeDescription ()Lnet/minecraft/network/chat/MutableComponent; - -
 method public describe ()Lnet/minecraft/network/chat/Component; - -
 method protected describeType ()Lnet/minecraft/network/chat/MutableComponent; - -
 method protected describeInfo ()Lnet/minecraft/network/chat/Component; - -
 method protected descriptionRow (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/network/chat/MutableComponent; - -
 method protected descriptionRow (Ljava/lang/String;Lnet/minecraft/network/chat/MutableComponent;)Lnet/minecraft/network/chat/MutableComponent; - -
in 2
class net/minecraft/gametest/framework/GameTestInstance 65 public,super,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DIRECT_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/gametest/framework/GameTestInstance;>;
 method public,static bootstrap (Lnet/minecraft/core/Registry;)Lcom/mojang/serialization/MapCodec; (Lnet/minecraft/core/Registry<Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/GameTestInstance;>;>;)Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method protected <init> (Lnet/minecraft/gametest/framework/TestData;)V (Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)V -
 method public,abstract run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public,abstract codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/GameTestInstance;>; -
 method public batch ()Lnet/minecraft/core/Holder; ()Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
 method public structure ()Lnet/minecraft/resources/Identifier; - -
 method public maxTicks ()I - -
 method public setupTicks ()I - -
 method public required ()Z - -
 method public manualOnly ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public skyAccess ()Z - -
 method public rotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method protected info ()Lnet/minecraft/gametest/framework/TestData; ()Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>; -
 method protected,abstract typeDescription ()Lnet/minecraft/network/chat/MutableComponent; - -
 method public describe ()Lnet/minecraft/network/chat/Component; - -
 method protected describeType ()Lnet/minecraft/network/chat/MutableComponent; - -
 method protected describeInfo ()Lnet/minecraft/network/chat/Component; - -
 method protected descriptionRow (Ljava/lang/String;Ljava/lang/String;)Lnet/minecraft/network/chat/MutableComponent; - -
 method protected descriptionRow (Ljava/lang/String;Lnet/minecraft/network/chat/MutableComponent;)Lnet/minecraft/network/chat/MutableComponent; - -
in 96
class net/minecraft/gametest/framework/GameTestInstances 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 field public,static,final ALWAYS_PASS Lnet/minecraft/resources/ResourceKey; Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/GameTestInstance;>;
 method public,static bootstrap (Lnet/minecraft/data/worldgen/BootstrapContext;)V (Lnet/minecraft/data/worldgen/BootstrapContext<Lnet/minecraft/gametest/framework/GameTestInstance;>;)V -
in 175
class net/minecraft/gametest/framework/GameTestListener 52 public,interface,abstract java/lang/Object - -
 method public,abstract testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 82
class net/minecraft/gametest/framework/GameTestListener 60 public,interface,abstract java/lang/Object - -
 method public,abstract testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 93
class net/minecraft/gametest/framework/GameTestListener 61 public,interface,abstract java/lang/Object - -
 method public,abstract testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 60
class net/minecraft/gametest/framework/GameTestListener 65 public,interface,abstract java/lang/Object - -
 method public,abstract testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public,abstract testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public,abstract testAddedForRerun (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
in 96
class net/minecraft/gametest/framework/GameTestMainUtil 65 public,super java/lang/Object - -
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static runGameTestServer ([Ljava/lang/String;Ljava/util/function/Consumer;)V ([Ljava/lang/String;Ljava/util/function/Consumer<Ljava/lang/String;>;)V java/lang/Exception
in 115
class net/minecraft/gametest/framework/GameTestRegistry 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getTestFunctionsForClassName (Ljava/lang/String;)Ljava/util/Collection; (Ljava/lang/String;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestClassNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,static isTestClass (Ljava/lang/String;)Z - -
 method public,static getBeforeBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static findTestFunction (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getTestFunction (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; - -
in 86
class net/minecraft/gametest/framework/GameTestRegistry 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getTestFunctionsForClassName (Ljava/lang/String;)Ljava/util/Collection; (Ljava/lang/String;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestClassNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,static isTestClass (Ljava/lang/String;)Z - -
 method public,static getBeforeBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static findTestFunction (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getTestFunction (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; - -
 method public,static getLastFailedTests ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static rememberFailedTest (Lnet/minecraft/gametest/framework/TestFunction;)V - -
 method public,static forgetFailedTests ()V - -
in 82
class net/minecraft/gametest/framework/GameTestRegistry 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public,static register (Ljava/lang/reflect/Method;)V - -
 method public,static getTestFunctionsForClassName (Ljava/lang/String;)Ljava/util/Collection; (Ljava/lang/String;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestClassNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,static isTestClass (Ljava/lang/String;)Z - -
 method public,static getBeforeBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static getAfterBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static findTestFunction (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getTestFunction (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; - -
 method public,static getLastFailedTests ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static rememberFailedTest (Lnet/minecraft/gametest/framework/TestFunction;)V - -
 method public,static forgetFailedTests ()V - -
in 374
class net/minecraft/gametest/framework/GameTestRegistry 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static,deprecated register (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public,static,deprecated register (Ljava/lang/reflect/Method;)V - -
 method public,static,deprecated register (Ljava/lang/reflect/Method;Ljava/util/Set;)V (Ljava/lang/reflect/Method;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public,static getTestFunctionsForClassName (Ljava/lang/String;)Ljava/util/Collection; (Ljava/lang/String;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestClassNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,static isTestClass (Ljava/lang/String;)Z - -
 method public,static getBeforeBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static getAfterBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static findTestFunction (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getTestFunction (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; - -
 method public,static getLastFailedTests ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static rememberFailedTest (Lnet/minecraft/gametest/framework/TestFunction;)V - -
 method public,static forgetFailedTests ()V - -
in 496
class net/minecraft/gametest/framework/GameTestRegistry 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public,static register (Ljava/lang/reflect/Method;)V - -
 method public,static getTestFunctionsForClassName (Ljava/lang/String;)Ljava/util/Collection; (Ljava/lang/String;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestClassNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,static isTestClass (Ljava/lang/String;)Z - -
 method public,static getBeforeBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static getAfterBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static findTestFunction (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getTestFunction (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; - -
 method public,static getLastFailedTests ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static rememberFailedTest (Lnet/minecraft/gametest/framework/TestFunction;)V - -
 method public,static forgetFailedTests ()V - -
in 305
class net/minecraft/gametest/framework/GameTestRegistry 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public,static register (Ljava/lang/reflect/Method;)V - -
 method public,static getTestFunctionsForClassName (Ljava/lang/String;)Ljava/util/stream/Stream; (Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestClassNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,static isTestClass (Ljava/lang/String;)Z - -
 method public,static getBeforeBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static getAfterBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static findTestFunction (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getTestFunction (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; - -
 method public,static getLastFailedTests ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static rememberFailedTest (Lnet/minecraft/gametest/framework/TestFunction;)V - -
 method public,static forgetFailedTests ()V - -
in 306
class net/minecraft/gametest/framework/GameTestRegistry 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static,deprecated register (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
 method public,static,deprecated register (Ljava/lang/reflect/Method;)V - -
 method public,static,deprecated register (Ljava/lang/reflect/Method;Ljava/util/Set;)V (Ljava/lang/reflect/Method;Ljava/util/Set<Ljava/lang/String;>;)V -
 method public,static getTestFunctionsForClassName (Ljava/lang/String;)Ljava/util/stream/Stream; (Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestFunctions ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getAllTestClassNames ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public,static isTestClass (Ljava/lang/String;)Z - -
 method public,static getBeforeBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static getAfterBatchFunction (Ljava/lang/String;)Ljava/util/function/Consumer; (Ljava/lang/String;)Ljava/util/function/Consumer<Lnet/minecraft/server/level/ServerLevel;>; -
 method public,static findTestFunction (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static getTestFunction (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; - -
 method public,static getLastFailedTests ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/TestFunction;>; -
 method public,static rememberFailedTest (Lnet/minecraft/gametest/framework/TestFunction;)V - -
 method public,static forgetFailedTests ()V - -
in 115
class net/minecraft/gametest/framework/GameTestRunner 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static TEST_REPORTER Lnet/minecraft/gametest/framework/TestReporter; -
 method public,static runTest (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestTicker;)V - -
 method public,static runTestBatches (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static runTests (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static groupTestsIntoBatches (Ljava/util/Collection;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static clearMarkers (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static clearAllTests (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;I)V - -
in 86
class net/minecraft/gametest/framework/GameTestRunner 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static TEST_REPORTER Lnet/minecraft/gametest/framework/TestReporter; -
 method public,static runTest (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;)V - -
 method public,static runTestBatches (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static runTests (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static groupTestsIntoBatches (Ljava/util/Collection;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static clearMarkers (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static clearAllTests (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;I)V - -
in 82
class net/minecraft/gametest/framework/GameTestRunner 60 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final PADDING_AROUND_EACH_STRUCTURE I - I2
 field public,static,final SPACE_BETWEEN_COLUMNS I - I5
 field public,static,final SPACE_BETWEEN_ROWS I - I6
 field public,static,final DEFAULT_TESTS_PER_ROW I - I8
 method public <init> ()V - -
 method public,static runTest (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;)V - -
 method public,static runTestBatches (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static runTests (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static groupTestsIntoBatches (Ljava/util/Collection;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static clearAllTests (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;I)V - -
 method public,static clearMarkers (Lnet/minecraft/server/level/ServerLevel;)V - -
in 223
class net/minecraft/gametest/framework/GameTestRunner 61 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final PADDING_AROUND_EACH_STRUCTURE I - I2
 field public,static,final SPACE_BETWEEN_COLUMNS I - I5
 field public,static,final SPACE_BETWEEN_ROWS I - I6
 field public,static,final DEFAULT_TESTS_PER_ROW I - I8
 method public <init> ()V - -
 method public,static runTest (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;)V - -
 method public,static runTestBatches (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static runTests (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static groupTestsIntoBatches (Ljava/util/Collection;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static clearAllTests (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;I)V - -
 method public,static clearMarkers (Lnet/minecraft/server/level/ServerLevel;)V - -
in 116
class net/minecraft/gametest/framework/GameTestRunner 61 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SPACE_BETWEEN_COLUMNS I - I5
 field public,static,final SPACE_BETWEEN_ROWS I - I6
 field public,static,final DEFAULT_TESTS_PER_ROW I - I8
 method public <init> ()V - -
 method public,static runTest (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;)V - -
 method public,static runTestBatches (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static runTests (Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;I)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public,static groupTestsIntoBatches (Ljava/util/Collection;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
 method public,static clearAllTests (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/gametest/framework/GameTestTicker;I)V - -
 method public,static clearMarkers (Lnet/minecraft/server/level/ServerLevel;)V - -
in 224
class net/minecraft/gametest/framework/GameTestRunner 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TESTS_PER_ROW I - I8
 method protected <init> (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;)V (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;)V -
 method public getTestInfos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public start ()V - -
 method public stop ()V - -
 method public rerunTest (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestBatchListener;)V - -
 method public,static clearMarkers (Lnet/minecraft/server/level/ServerLevel;)V - -
in 261
class net/minecraft/gametest/framework/GameTestRunner 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TESTS_PER_ROW I - I8
 method protected <init> (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Z)V (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Z)V -
 method public getTestInfos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public start ()V - -
 method public stop ()V - -
 method public rerunTest (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestBatchListener;)V - -
 method public,static clearMarkers (Lnet/minecraft/server/level/ServerLevel;)V - -
in 74
class net/minecraft/gametest/framework/GameTestRunner 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TESTS_PER_ROW I - I8
 method protected <init> (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;ZZ)V (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;ZZ)V -
 method public getTestInfos ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public start ()V - -
 method public stop ()V - -
 method public rerunTest (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestBatchListener;)V - -
in 224
class net/minecraft/gametest/framework/GameTestRunner$Builder 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 method public,static fromBatches (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; -
 method public,static fromInfo (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; -
 method public newStructureSpawner (Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public build ()Lnet/minecraft/gametest/framework/GameTestRunner; - -
in 261
class net/minecraft/gametest/framework/GameTestRunner$Builder 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 method public,static fromBatches (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; -
 method public,static fromInfo (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; -
 method public haltOnError (Z)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public newStructureSpawner (Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public existingStructureSpawner (Lnet/minecraft/gametest/framework/StructureGridSpawner;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public batcher (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public build ()Lnet/minecraft/gametest/framework/GameTestRunner; - -
in 74
class net/minecraft/gametest/framework/GameTestRunner$Builder 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 method public,static fromBatches (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; -
 method public,static fromInfo (Ljava/util/Collection;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; -
 method public haltOnError ()Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public clearBetweenBatches ()Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public newStructureSpawner (Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public existingStructureSpawner (Lnet/minecraft/gametest/framework/StructureGridSpawner;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public batcher (Lnet/minecraft/gametest/framework/GameTestRunner$GameTestBatcher;)Lnet/minecraft/gametest/framework/GameTestRunner$Builder; - -
 method public build ()Lnet/minecraft/gametest/framework/GameTestRunner; - -
in 60
class net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 method public,abstract batch (Ljava/util/Collection;)Ljava/util/Collection; (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;)Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>; -
in 224
class net/minecraft/gametest/framework/GameTestRunner$StructureSpawner 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final IN_PLACE Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner; -
 field public,static,final NOT_SET Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner; -
 method public,abstract spawnStructure (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional; (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
in 260
class net/minecraft/gametest/framework/GameTestRunner$StructureSpawner 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final IN_PLACE Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner; -
 field public,static,final NOT_SET Lnet/minecraft/gametest/framework/GameTestRunner$StructureSpawner; -
 method public,abstract spawnStructure (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional; (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public onBatchStart (Lnet/minecraft/server/level/ServerLevel;)V - -
in 175
class net/minecraft/gametest/framework/GameTestSequence 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public tickAndContinue (J)V - -
 method public tickAndFailIfNotComplete (J)V - -
in 82
class net/minecraft/gametest/framework/GameTestSequence 60 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public thenWaitUntil (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenWaitUntil (JLjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenIdle (I)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecute (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteAfter (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteFor (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenSucceed ()V - -
 method public thenFail (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/lang/Exception;>;)V -
 method public thenTrigger ()Lnet/minecraft/gametest/framework/GameTestSequence$Condition; - -
 method public tickAndContinue (J)V - -
 method public tickAndFailIfNotComplete (J)V - -
in 284
class net/minecraft/gametest/framework/GameTestSequence 61 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public thenWaitUntil (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenWaitUntil (JLjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenIdle (I)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecute (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteAfter (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteFor (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenSucceed ()V - -
 method public thenFail (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/lang/Exception;>;)V -
 method public thenTrigger ()Lnet/minecraft/gametest/framework/GameTestSequence$Condition; - -
 method public tickAndContinue (J)V - -
 method public tickAndFailIfNotComplete (J)V - -
in 305
class net/minecraft/gametest/framework/GameTestSequence 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public thenWaitUntil (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenWaitUntil (JLjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenIdle (I)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecute (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteAfter (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteFor (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenSucceed ()V - -
 method public thenFail (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/lang/Exception;>;)V -
 method public thenTrigger ()Lnet/minecraft/gametest/framework/GameTestSequence$Condition; - -
 method public tickAndContinue (J)V - -
 method public tickAndFailIfNotComplete (J)V - -
in 195
class net/minecraft/gametest/framework/GameTestSequence 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public thenWaitUntil (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenWaitUntil (JLjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenIdle (I)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecute (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteAfter (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteFor (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenSucceed ()V - -
 method public thenFail (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Lnet/minecraft/gametest/framework/GameTestException;>;)V -
 method public thenTrigger ()Lnet/minecraft/gametest/framework/GameTestSequence$Condition; - -
 method public tickAndContinue (I)V - -
 method public tickAndFailIfNotComplete (I)V - -
in 191
class net/minecraft/gametest/framework/GameTestSequence 61 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public thenWaitUntil (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenWaitUntil (JLjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenIdle (I)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecute (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteAfter (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteFor (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenSucceed ()V - -
 method public thenFail (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/lang/Exception;>;)V -
 method public thenTrigger ()Lnet/minecraft/gametest/framework/GameTestSequence$Condition; - -
 method public tickAndContinue (J)V - -
 method public tickAndFailIfNotComplete (J)V - -
in 306
class net/minecraft/gametest/framework/GameTestSequence 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public thenWaitUntil (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenWaitUntil (JLjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenIdle (I)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecute (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteAfter (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteFor (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenSucceed ()V - -
 method public thenFail (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/lang/Exception;>;)V -
 method public thenTrigger ()Lnet/minecraft/gametest/framework/GameTestSequence$Condition; - -
 method public tickAndContinue (J)V - -
 method public tickAndFailIfNotComplete (J)V - -
in 168
class net/minecraft/gametest/framework/GameTestSequence 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public thenWaitUntil (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenWaitUntil (JLjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenIdle (I)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecute (Ljava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteAfter (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenExecuteFor (ILjava/lang/Runnable;)Lnet/minecraft/gametest/framework/GameTestSequence; - -
 method public thenSucceed ()V - -
 method public thenFail (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Lnet/minecraft/gametest/framework/GameTestException;>;)V -
 method public thenTrigger ()Lnet/minecraft/gametest/framework/GameTestSequence$Condition; - -
 method public tickAndContinue (I)V - -
 method public tickAndFailIfNotComplete (I)V - -
in 82
class net/minecraft/gametest/framework/GameTestSequence$Condition 60 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestSequence;)V - -
 method public assertTriggeredThisTick ()V - -
in 93
class net/minecraft/gametest/framework/GameTestSequence$Condition 61 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestSequence;)V - -
 method public assertTriggeredThisTick ()V - -
in 60
class net/minecraft/gametest/framework/GameTestSequence$Condition 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestSequence$Condition net/minecraft/gametest/framework/GameTestSequence Condition public
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestSequence;)V - -
 method public assertTriggeredThisTick ()V - -
in 82
class net/minecraft/gametest/framework/GameTestServer 60 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/core/RegistryAccess$RegistryHolder net/minecraft/core/RegistryAccess RegistryHolder public,static,final
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/ServerResources;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)V (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/ServerResources;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/RegistryAccess$RegistryHolder;)V -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
 method public getModdedStatus ()Ljava/util/Optional; ()Ljava/util/Optional<Ljava/lang/String;>; -
in 105
class net/minecraft/gametest/framework/GameTestServer 61 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldStem$InitConfig net/minecraft/server/WorldStem InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/server/WorldStem$DataPackConfigSupplier net/minecraft/server/WorldStem DataPackConfigSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldStem$WorldDataSupplier net/minecraft/server/WorldStem WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public <init> (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)V (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)V -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 231
class net/minecraft/gametest/framework/GameTestServer 61 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public <init> (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)V (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)V -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 537
class net/minecraft/gametest/framework/GameTestServer 61 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public <init> (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)V (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)V -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 270
class net/minecraft/gametest/framework/GameTestServer 61 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 687
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner net/minecraft/world/level/GameRules$IntegerValue net/minecraft/world/level/GameRules IntegerValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 101
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner net/minecraft/world/level/GameRules$IntegerValue net/minecraft/world/level/GameRules IntegerValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 497
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner java/util/stream/Stream$Builder java/util/stream/Stream Builder public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional;Z)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional<Ljava/lang/String;>;Z)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public,static getTestsForSelection (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 144
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner java/util/stream/Stream$Builder java/util/stream/Stream Builder public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/storage/LevelData$RespawnData net/minecraft/world/level/storage/LevelData RespawnData public,static,final
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestServer$MockUserNameToIdResolver net/minecraft/gametest/framework/GameTestServer MockUserNameToIdResolver static
 inner net/minecraft/gametest/framework/GameTestServer$MockProfileResolver net/minecraft/gametest/framework/GameTestServer MockProfileResolver static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional;Z)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional<Ljava/lang/String;>;Z)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public,static getTestsForSelection (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public operatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isSpawnerBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lnet/minecraft/server/players/NameAndId;)Z - -
 method public getMaxPlayers ()I - -
in 140
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gizmos/Gizmos$TemporaryCollection net/minecraft/gizmos/Gizmos TemporaryCollection public,static
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner java/util/stream/Stream$Builder java/util/stream/Stream Builder public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/storage/LevelData$RespawnData net/minecraft/world/level/storage/LevelData RespawnData public,static,final
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestServer$MockUserNameToIdResolver net/minecraft/gametest/framework/GameTestServer MockUserNameToIdResolver static
 inner net/minecraft/gametest/framework/GameTestServer$MockProfileResolver net/minecraft/gametest/framework/GameTestServer MockProfileResolver static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional;Z)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional<Ljava/lang/String;>;Z)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public,static getTestsForSelection (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public operatorUserPermissions ()Lnet/minecraft/server/permissions/LevelBasedPermissionSet; - -
 method public getFunctionCompilationPermissions ()Lnet/minecraft/server/permissions/PermissionSet; - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public useNativeTransport ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lnet/minecraft/server/players/NameAndId;)Z - -
 method public getMaxPlayers ()I - -
in 192
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner net/minecraft/world/level/GameRules$IntegerValue net/minecraft/world/level/GameRules IntegerValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public <init> (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)V (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/server/WorldStem;Ljava/util/Collection<Lnet/minecraft/gametest/framework/TestFunction;>;Lnet/minecraft/core/BlockPos;)V -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 146
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner java/util/stream/Stream$Builder java/util/stream/Stream Builder public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional;Z)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional<Ljava/lang/String;>;Z)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public,static getTestsForSelection (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 123
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner java/util/stream/Stream$Builder java/util/stream/Stream Builder public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/storage/LevelData$RespawnData net/minecraft/world/level/storage/LevelData RespawnData public,static,final
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner net/minecraft/gametest/framework/GameTestServer$MockUserNameToIdResolver net/minecraft/gametest/framework/GameTestServer MockUserNameToIdResolver static
 inner net/minecraft/gametest/framework/GameTestServer$MockProfileResolver net/minecraft/gametest/framework/GameTestServer MockProfileResolver static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional;Z)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional<Ljava/lang/String;>;Z)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public,static getTestsForSelection (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public operatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isSpawnerBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lnet/minecraft/server/players/NameAndId;)Z - -
 method public getMaxPlayers ()I - -
in 109
class net/minecraft/gametest/framework/GameTestServer 61 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldStem$InitConfig net/minecraft/server/WorldStem InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/server/WorldStem$DataPackConfigSupplier net/minecraft/server/WorldStem DataPackConfigSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldStem$WorldDataSupplier net/minecraft/server/WorldStem WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 232
class net/minecraft/gametest/framework/GameTestServer 61 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestBatch;>;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public getOperatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lcom/mojang/authlib/GameProfile;)Z - -
in 148
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner java/util/stream/Stream$Builder java/util/stream/Stream Builder public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/storage/LevelData$RespawnData net/minecraft/world/level/storage/LevelData RespawnData public,static,final
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestServer$MockUserNameToIdResolver net/minecraft/gametest/framework/GameTestServer MockUserNameToIdResolver private,static
 inner net/minecraft/gametest/framework/GameTestServer$MockProfileResolver net/minecraft/gametest/framework/GameTestServer MockProfileResolver private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional;Z)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional<Ljava/lang/String;>;Z)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public,static getTestsForSelection (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public operatorUserPermissionLevel ()I - -
 method public getFunctionCompilationLevel ()I - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public isEpollEnabled ()Z - -
 method public isCommandBlockEnabled ()Z - -
 method public isSpawnerBlockEnabled ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lnet/minecraft/server/players/NameAndId;)Z - -
 method public getMaxPlayers ()I - -
in 142
class net/minecraft/gametest/framework/GameTestServer 65 public,super net/minecraft/server/MinecraftServer - -
 inner net/minecraft/server/WorldLoader$PackConfig net/minecraft/server/WorldLoader PackConfig public,static,final
 inner net/minecraft/server/WorldLoader$InitConfig net/minecraft/server/WorldLoader InitConfig public,static,final
 inner net/minecraft/commands/Commands$CommandSelection net/minecraft/commands/Commands CommandSelection public,static,final,enum
 inner net/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess net/minecraft/world/level/storage/LevelStorageSource LevelStorageAccess public
 inner net/minecraft/gizmos/Gizmos$TemporaryCollection net/minecraft/gizmos/Gizmos TemporaryCollection public,static
 inner net/minecraft/gametest/framework/GameTestBatchFactory$TestDecorator net/minecraft/gametest/framework/GameTestBatchFactory TestDecorator public,static,interface,abstract
 inner java/util/stream/Stream$Builder java/util/stream/Stream Builder public,static,interface,abstract
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/world/level/storage/LevelData$RespawnData net/minecraft/world/level/storage/LevelData RespawnData public,static,final
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$WorldDataSupplier net/minecraft/server/WorldLoader WorldDataSupplier public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$ResultFactory net/minecraft/server/WorldLoader ResultFactory public,static,interface,abstract
 inner net/minecraft/server/WorldLoader$DataLoadContext net/minecraft/server/WorldLoader DataLoadContext public,static,final
 inner net/minecraft/core/HolderLookup$Provider net/minecraft/core/HolderLookup Provider public,static,interface,abstract
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/WorldDimensions$Complete net/minecraft/world/level/levelgen/WorldDimensions Complete public,static,final
 inner net/minecraft/server/WorldLoader$DataLoadOutput net/minecraft/server/WorldLoader DataLoadOutput public,static,final
 inner net/minecraft/world/level/storage/PrimaryLevelData$SpecialWorldProperty net/minecraft/world/level/storage/PrimaryLevelData SpecialWorldProperty public,static,final,enum
 inner net/minecraft/core/RegistryAccess$Frozen net/minecraft/core/RegistryAccess Frozen public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestServer$MockUserNameToIdResolver net/minecraft/gametest/framework/GameTestServer MockUserNameToIdResolver private,static
 inner net/minecraft/gametest/framework/GameTestServer$MockProfileResolver net/minecraft/gametest/framework/GameTestServer MockProfileResolver private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static create (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional;Z)Lnet/minecraft/gametest/framework/GameTestServer; (Ljava/lang/Thread;Lnet/minecraft/world/level/storage/LevelStorageSource$LevelStorageAccess;Lnet/minecraft/server/packs/repository/PackRepository;Ljava/util/Optional<Ljava/lang/String;>;Z)Lnet/minecraft/gametest/framework/GameTestServer; -
 method public initServer ()Z - -
 method public,static getTestsForSelection (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/RegistryAccess;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
 method public tickServer (Ljava/util/function/BooleanSupplier;)V - -
 method public getTickTimeLogger ()Lnet/minecraft/util/debugchart/SampleLogger; - -
 method public isTickTimeLoggingEnabled ()Z - -
 method public waitUntilNextTick ()V - -
 method public fillServerSystemReport (Lnet/minecraft/SystemReport;)Lnet/minecraft/SystemReport; - -
 method public onServerExit ()V - -
 method public onServerCrash (Lnet/minecraft/CrashReport;)V - -
 method public isHardcore ()Z - -
 method public operatorUserPermissions ()Lnet/minecraft/server/permissions/LevelBasedPermissionSet; - -
 method public getFunctionCompilationPermissions ()Lnet/minecraft/server/permissions/PermissionSet; - -
 method public shouldRconBroadcast ()Z - -
 method public isDedicatedServer ()Z - -
 method public getRateLimitPacketsPerSecond ()I - -
 method public useNativeTransport ()Z - -
 method public isPublished ()Z - -
 method public shouldInformAdmins ()Z - -
 method public isSingleplayerOwner (Lnet/minecraft/server/players/NameAndId;)Z - -
 method public getMaxPlayers ()I - -
in 74
class net/minecraft/gametest/framework/GameTestServer$MockProfileResolver 65 super java/lang/Object net/minecraft/server/players/ProfileResolver -
 inner net/minecraft/gametest/framework/GameTestServer$MockProfileResolver net/minecraft/gametest/framework/GameTestServer MockProfileResolver static
 method public fetchByName (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lcom/mojang/authlib/GameProfile;>; -
 method public fetchById (Ljava/util/UUID;)Ljava/util/Optional; (Ljava/util/UUID;)Ljava/util/Optional<Lcom/mojang/authlib/GameProfile;>; -
in 74
class net/minecraft/gametest/framework/GameTestServer$MockUserNameToIdResolver 65 super java/lang/Object net/minecraft/server/players/UserNameToIdResolver -
 inner net/minecraft/gametest/framework/GameTestServer$MockUserNameToIdResolver net/minecraft/gametest/framework/GameTestServer MockUserNameToIdResolver static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public add (Lnet/minecraft/server/players/NameAndId;)V - -
 method public get (Ljava/lang/String;)Ljava/util/Optional; (Ljava/lang/String;)Ljava/util/Optional<Lnet/minecraft/server/players/NameAndId;>; -
 method public get (Ljava/util/UUID;)Ljava/util/Optional; (Ljava/util/UUID;)Ljava/util/Optional<Lnet/minecraft/server/players/NameAndId;>; -
 method public resolveOfflineUsers (Z)V - -
 method public save ()V - -
in 175
class net/minecraft/gametest/framework/GameTestTicker 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final singleton Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public <init> ()V - -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public tick ()V - -
in 82
class net/minecraft/gametest/framework/GameTestTicker 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SINGLETON Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public <init> ()V - -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public tick ()V - -
in 93
class net/minecraft/gametest/framework/GameTestTicker 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SINGLETON Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public <init> ()V - -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public tick ()V - -
in 128
class net/minecraft/gametest/framework/GameTestTicker 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SINGLETON Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public setRunner (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public tick ()V - -
in 688
class net/minecraft/gametest/framework/GameTestTicker 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestTicker$State net/minecraft/gametest/framework/GameTestTicker State static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SINGLETON Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public setRunner (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public tick ()V - -
in 318
class net/minecraft/gametest/framework/GameTestTicker 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestTicker$State net/minecraft/gametest/framework/GameTestTicker State static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SINGLETON Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public setRunner (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public startTicking ()V - -
 method public tick ()V - -
in 689
class net/minecraft/gametest/framework/GameTestTicker 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestTicker$State net/minecraft/gametest/framework/GameTestTicker State private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SINGLETON Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public setRunner (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public tick ()V - -
in 246
class net/minecraft/gametest/framework/GameTestTicker 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/GameTestTicker$State net/minecraft/gametest/framework/GameTestTicker State private,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final SINGLETON Lnet/minecraft/gametest/framework/GameTestTicker; -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public clear ()V - -
 method public setRunner (Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public startTicking ()V - -
 method public tick ()V - -
in 96
class net/minecraft/gametest/framework/GameTestTicker$State 65 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/gametest/framework/GameTestTicker$State;>;
 inner net/minecraft/gametest/framework/GameTestTicker$State net/minecraft/gametest/framework/GameTestTicker State static,final,enum
 field public,static,final,enum IDLE Lnet/minecraft/gametest/framework/GameTestTicker$State; -
 field public,static,final,enum RUNNING Lnet/minecraft/gametest/framework/GameTestTicker$State; -
 field public,static,final,enum HALTING Lnet/minecraft/gametest/framework/GameTestTicker$State; -
 method public,static values ()[Lnet/minecraft/gametest/framework/GameTestTicker$State; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/gametest/framework/GameTestTicker$State; - -
in 175
class net/minecraft/gametest/framework/GameTestTimeoutException 52 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 82
class net/minecraft/gametest/framework/GameTestTimeoutException 60 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 93
class net/minecraft/gametest/framework/GameTestTimeoutException 61 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 128
class net/minecraft/gametest/framework/GameTestTimeoutException 65 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
in 96
class net/minecraft/gametest/framework/GameTestTimeoutException 65 public,super net/minecraft/gametest/framework/GameTestException - -
 field protected,final message Lnet/minecraft/network/chat/Component; -
 method public <init> (Lnet/minecraft/network/chat/Component;)V - -
 method public getDescription ()Lnet/minecraft/network/chat/Component; - -
in 167
class net/minecraft/gametest/framework/GeneratedTest 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Map;Lnet/minecraft/resources/ResourceLocation;Ljava/util/function/Consumer;)V (Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>;Lnet/minecraft/resources/ResourceLocation;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/gametest/framework/TestData;Ljava/util/function/Consumer;)V (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/util/Map;Lnet/minecraft/resources/ResourceKey;Ljava/util/function/Consumer;)V (Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>;Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public tests ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>; -
 method public functionKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>; -
 method public function ()Ljava/util/function/Consumer; ()Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>; -
in 2
class net/minecraft/gametest/framework/GeneratedTest 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/Map;Lnet/minecraft/resources/Identifier;Ljava/util/function/Consumer;)V (Ljava/util/Map<Lnet/minecraft/resources/Identifier;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>;Lnet/minecraft/resources/Identifier;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Lnet/minecraft/resources/Identifier;Lnet/minecraft/gametest/framework/TestData;Ljava/util/function/Consumer;)V (Lnet/minecraft/resources/Identifier;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/util/Map;Lnet/minecraft/resources/ResourceKey;Ljava/util/function/Consumer;)V (Ljava/util/Map<Lnet/minecraft/resources/Identifier;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>;Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public tests ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/resources/Identifier;Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/resources/ResourceKey<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>; -
 method public functionKey ()Lnet/minecraft/resources/ResourceKey; ()Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>; -
 method public function ()Ljava/util/function/Consumer; ()Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>; -
in 82
class net/minecraft/gametest/framework/GlobalTestReporter 60 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static replaceWith (Lnet/minecraft/gametest/framework/TestReporter;)V - -
 method public,static onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static finish ()V - -
in 93
class net/minecraft/gametest/framework/GlobalTestReporter 61 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static replaceWith (Lnet/minecraft/gametest/framework/TestReporter;)V - -
 method public,static onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static finish ()V - -
in 60
class net/minecraft/gametest/framework/GlobalTestReporter 65 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static replaceWith (Lnet/minecraft/gametest/framework/TestReporter;)V - -
 method public,static onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static finish ()V - -
in 82
class net/minecraft/gametest/framework/JUnitLikeTestReporter 60 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 method public <init> (Ljava/io/File;)V - javax/xml/parsers/ParserConfigurationException
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public finish ()V - -
 method public save (Ljava/io/File;)V - javax/xml/transform/TransformerException
in 223
class net/minecraft/gametest/framework/JUnitLikeTestReporter 61 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 method public <init> (Ljava/io/File;)V - javax/xml/parsers/ParserConfigurationException
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public finish ()V - -
 method public save (Ljava/io/File;)V - javax/xml/transform/TransformerException
in 116
class net/minecraft/gametest/framework/JUnitLikeTestReporter 61 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/io/File;)V - javax/xml/parsers/ParserConfigurationException
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public finish ()V - -
 method public save (Ljava/io/File;)V - javax/xml/transform/TransformerException
in 60
class net/minecraft/gametest/framework/JUnitLikeTestReporter 65 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/io/File;)V - javax/xml/parsers/ParserConfigurationException
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public finish ()V - -
 method public save (Ljava/io/File;)V - javax/xml/transform/TransformerException
in 175
class net/minecraft/gametest/framework/LogTestReporter 52 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 method public <init> ()V - -
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 82
class net/minecraft/gametest/framework/LogTestReporter 60 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 method public <init> ()V - -
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 93
class net/minecraft/gametest/framework/LogTestReporter 61 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 method public <init> ()V - -
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 60
class net/minecraft/gametest/framework/LogTestReporter 65 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 method public <init> ()V - -
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 115
class net/minecraft/gametest/framework/MultipleTestTracker 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public add (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public setListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public getFailedRequiredCount ()I - -
 method public getFailedOptionalCount ()I - -
 method public getDoneCount ()I - -
 method public hasFailedRequired ()Z - -
 method public hasFailedOptional ()Z - -
 method public getTotalCount ()I - -
 method public isDone ()Z - -
 method public getProgressBar ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 86
class net/minecraft/gametest/framework/MultipleTestTracker 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public addTestToTrack (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public addFailureListener (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public getFailedRequiredCount ()I - -
 method public getFailedOptionalCount ()I - -
 method public getDoneCount ()I - -
 method public hasFailedRequired ()Z - -
 method public hasFailedOptional ()Z - -
 method public getTotalCount ()I - -
 method public isDone ()Z - -
 method public getProgressBar ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 82
class net/minecraft/gametest/framework/MultipleTestTracker 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public addTestToTrack (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public addFailureListener (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public getFailedRequiredCount ()I - -
 method public getFailedOptionalCount ()I - -
 method public getDoneCount ()I - -
 method public hasFailedRequired ()Z - -
 method public hasFailedOptional ()Z - -
 method public getFailedRequired ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public getFailedOptional ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public getTotalCount ()I - -
 method public isDone ()Z - -
 method public getProgressBar ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 93
class net/minecraft/gametest/framework/MultipleTestTracker 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public addTestToTrack (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public addFailureListener (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public getFailedRequiredCount ()I - -
 method public getFailedOptionalCount ()I - -
 method public getDoneCount ()I - -
 method public hasFailedRequired ()Z - -
 method public hasFailedOptional ()Z - -
 method public getFailedRequired ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public getFailedOptional ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public getTotalCount ()I - -
 method public isDone ()Z - -
 method public getProgressBar ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/minecraft/gametest/framework/MultipleTestTracker 65 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public addTestToTrack (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public addListener (Lnet/minecraft/gametest/framework/GameTestListener;)V - -
 method public addFailureListener (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestInfo;>;)V -
 method public getFailedRequiredCount ()I - -
 method public getFailedOptionalCount ()I - -
 method public getDoneCount ()I - -
 method public hasFailedRequired ()Z - -
 method public hasFailedOptional ()Z - -
 method public getFailedRequired ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public getFailedOptional ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
 method public getTotalCount ()I - -
 method public isDone ()Z - -
 method public getProgressBar ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public remove (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 82
class net/minecraft/gametest/framework/ReportGameListener 60 super java/lang/Object net/minecraft/gametest/framework/GameTestListener -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/core/BlockPos;)V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static reportPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/String;)V - -
 method protected,static reportFailure (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static visualizeFailedTest (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static spawnBeacon (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/world/level/block/Block;)V - -
 method protected,static say (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/ChatFormatting;Ljava/lang/String;)V - -
in 93
class net/minecraft/gametest/framework/ReportGameListener 61 super java/lang/Object net/minecraft/gametest/framework/GameTestListener -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestTicker;Lnet/minecraft/core/BlockPos;)V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,static reportPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/String;)V - -
 method protected,static reportFailure (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static visualizeFailedTest (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static spawnBeacon (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/world/level/block/Block;)V - -
 method protected,static say (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/ChatFormatting;Ljava/lang/String;)V - -
in 128
class net/minecraft/gametest/framework/ReportGameListener 65 super java/lang/Object net/minecraft/gametest/framework/GameTestListener -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testAddedForRerun (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public,static reportPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/String;)V - -
 method protected,static reportFailure (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static visualizeFailedTest (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static spawnBeacon (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/world/level/block/Block;)V - -
 method protected,static say (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/ChatFormatting;Ljava/lang/String;)V - -
in 96
class net/minecraft/gametest/framework/ReportGameListener 65 super java/lang/Object net/minecraft/gametest/framework/GameTestListener -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testAddedForRerun (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public,static reportPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/String;)V - -
 method protected,static reportFailure (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static visualizeFailedTest (Lnet/minecraft/gametest/framework/GameTestInfo;Ljava/lang/Throwable;)V - -
 method protected,static say (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/ChatFormatting;Ljava/lang/String;)V - -
in 60
class net/minecraft/gametest/framework/RetryOptions 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (IZ)V - -
 method public,static noRetries ()Lnet/minecraft/gametest/framework/RetryOptions; - -
 method public unlimitedTries ()Z - -
 method public hasTriesLeft (II)Z - -
 method public hasRetries ()Z - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public numberOfTries ()I - -
 method public haltOnFailure ()Z - -
in 128
class net/minecraft/gametest/framework/StructureBlockPosFinder 65 public,interface,abstract java/lang/Object - -
 method public,abstract findStructureBlockPos ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
in 224
class net/minecraft/gametest/framework/StructureGridSpawner 65 public,super java/lang/Object net/minecraft/gametest/framework/GameTestRunner$StructureSpawner -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 method public <init> (Lnet/minecraft/core/BlockPos;I)V - -
 method public spawnStructure (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional; (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
in 260
class net/minecraft/gametest/framework/StructureGridSpawner 65 public,super java/lang/Object net/minecraft/gametest/framework/GameTestRunner$StructureSpawner -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/core/BlockPos;IZ)V - -
 method public onBatchStart (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public spawnStructure (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional; (Lnet/minecraft/gametest/framework/GameTestInfo;)Ljava/util/Optional<Lnet/minecraft/gametest/framework/GameTestInfo;>; -
in 115
class net/minecraft/gametest/framework/StructureUtils 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static testStructuresDir Ljava/lang/String; -
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)V - -
 method public,static spawnStructure (Ljava/lang/String;Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;Z)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;ILnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/core/BlockPos;>; -
in 86
class net/minecraft/gametest/framework/StructureUtils 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static testStructuresDir Ljava/lang/String; -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static spawnStructure (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;ILnet/minecraft/server/level/ServerLevel;Z)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;ILnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/core/BlockPos;>; -
in 82
class net/minecraft/gametest/framework/StructureUtils 60 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "gameteststructures"
 field public,static testStructuresDir Ljava/lang/String; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static main ([Ljava/lang/String;)V - java/io/IOException
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static spawnStructure (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;ILnet/minecraft/server/level/ServerLevel;Z)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;ILnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/core/BlockPos;>; -
in 34
class net/minecraft/gametest/framework/StructureUtils 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "gameteststructures"
 field public,static testStructuresDir Ljava/lang/String; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static main ([Ljava/lang/String;)V - java/io/IOException
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static spawnStructure (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;ILnet/minecraft/server/level/ServerLevel;Z)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;ILnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/core/BlockPos;>; -
in 42
class net/minecraft/gametest/framework/StructureUtils 61 public,super java/lang/Object - -
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "gameteststructures"
 field public,static testStructuresDir Ljava/lang/String; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static main ([Ljava/lang/String;)V - java/io/IOException
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static spawnStructure (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;ILnet/minecraft/server/level/ServerLevel;Z)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;ILnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/core/BlockPos;>; -
in 72
class net/minecraft/gametest/framework/StructureUtils 61 public,super java/lang/Object - -
 inner net/minecraft/core/HolderLookup$RegistryLookup net/minecraft/core/HolderLookup RegistryLookup public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "gameteststructures"
 field public,static testStructuresDir Ljava/lang/String; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static spawnStructure (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;ILnet/minecraft/server/level/ServerLevel;Z)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;ILnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/core/BlockPos;>; -
in 116
class net/minecraft/gametest/framework/StructureUtils 61 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "gameteststructures"
 field public,static testStructuresDir Ljava/lang/String; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static getStructureOrigin (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/core/BlockPos; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static prepareTestStructure (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getTransformedFarCorner (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/core/BlockPos; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Collection<Lnet/minecraft/core/BlockPos;>; -
in 94
class net/minecraft/gametest/framework/StructureUtils 65 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_Y_SEARCH_RADIUS I - I10
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "gameteststructures"
 field public,static testStructuresDir Ljava/lang/String; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static getStructureOrigin (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/core/BlockPos; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static prepareTestStructure (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static encaseStructure (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/server/level/ServerLevel;Z)V - -
 method public,static removeBarriers (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getTransformedFarCorner (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/core/BlockPos; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findStructureByTestFunction (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static lookedAtStructureBlockPos (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
in 101
class net/minecraft/gametest/framework/StructureUtils 65 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_Y_SEARCH_RADIUS I - I10
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "gameteststructures"
 field public,static testStructuresDir Ljava/lang/String; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static getStructureBounds (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/phys/AABB; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static getStructureOrigin (Lnet/minecraft/world/level/block/entity/StructureBlockEntity;)Lnet/minecraft/core/BlockPos; - -
 method public,static addCommandBlockAndButtonToStartTest (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static createNewEmptyStructureBlock (Ljava/lang/String;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getStartCorner (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/core/BlockPos; - -
 method public,static prepareTestStructure (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/world/level/block/entity/StructureBlockEntity; - -
 method public,static encaseStructure (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/server/level/ServerLevel;Z)V - -
 method public,static removeBarriers (Lnet/minecraft/world/phys/AABB;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getTransformedFarCorner (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/core/BlockPos; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findStructureBlockContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestStructureBlock (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findStructureByTestFunction (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;Ljava/lang/String;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;Ljava/lang/String;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static findStructureBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static lookedAtStructureBlockPos (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
in 102
class net/minecraft/gametest/framework/StructureUtils 65 public,super java/lang/Object - -
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Data net/minecraft/world/level/block/entity/TestInstanceBlockEntity Data public,static,final
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Status net/minecraft/world/level/block/entity/TestInstanceBlockEntity Status public,static,final,enum
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_Y_SEARCH_RADIUS I - I10
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "Minecraft.Server/src/test/convertables/data"
 field public,static testStructuresDir Ljava/nio/file/Path; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static createNewEmptyTest (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/world/level/block/entity/TestInstanceBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getTransformedFarCorner (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/core/BlockPos; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findTestContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestTest (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findTestBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static lookedAtTestPos (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
in 125
class net/minecraft/gametest/framework/StructureUtils 65 public,super java/lang/Object - -
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Data net/minecraft/world/level/block/entity/TestInstanceBlockEntity Data public,static,final
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Status net/minecraft/world/level/block/entity/TestInstanceBlockEntity Status public,static,final,enum
 inner net/minecraft/world/entity/ai/village/poi/PoiManager$Occupancy net/minecraft/world/entity/ai/village/poi/PoiManager Occupancy public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_Y_SEARCH_RADIUS I - I10
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "Minecraft.Server/src/test/convertables/data"
 field public,static testStructuresDir Ljava/nio/file/Path; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static createNewEmptyTest (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/world/level/block/entity/TestInstanceBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getTransformedFarCorner (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/core/BlockPos; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findTestContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestTest (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findTestBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static lookedAtTestPos (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
in 2
class net/minecraft/gametest/framework/StructureUtils 65 public,super java/lang/Object - -
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Data net/minecraft/world/level/block/entity/TestInstanceBlockEntity Data public,static,final
 inner net/minecraft/world/level/block/entity/TestInstanceBlockEntity$Status net/minecraft/world/level/block/entity/TestInstanceBlockEntity Status public,static,final,enum
 inner net/minecraft/world/entity/ai/village/poi/PoiManager$Occupancy net/minecraft/world/entity/ai/village/poi/PoiManager Occupancy public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DEFAULT_Y_SEARCH_RADIUS I - I10
 field public,static,final DEFAULT_TEST_STRUCTURES_DIR Ljava/lang/String; - "Minecraft.Server/src/test/convertables/data"
 field public,static testStructuresDir Ljava/nio/file/Path; -
 method public <init> ()V - -
 method public,static getRotationForRotationSteps (I)Lnet/minecraft/world/level/block/Rotation; - -
 method public,static getRotationStepsForRotation (Lnet/minecraft/world/level/block/Rotation;)I - -
 method public,static createNewEmptyTest (Lnet/minecraft/resources/Identifier;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/server/level/ServerLevel;)Lnet/minecraft/world/level/block/entity/TestInstanceBlockEntity; - -
 method public,static clearSpaceForStructure (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,static getTransformedFarCorner (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/core/BlockPos; - -
 method public,static getStructureBoundingBox (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Vec3i;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/levelgen/structure/BoundingBox; - -
 method public,static findTestContainingPos (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findNearestTest (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/Optional<Lnet/minecraft/core/BlockPos;>; -
 method public,static findTestBlocks (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;ILnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static lookedAtTestPos (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream; (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/server/level/ServerLevel;)Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
in 82
class net/minecraft/gametest/framework/TeamcityTestReporter 60 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 inner com/google/common/escape/Escapers$Builder com/google/common/escape/Escapers Builder public,static,final
 method public <init> ()V - -
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 223
class net/minecraft/gametest/framework/TeamcityTestReporter 61 public,super java/lang/Object net/minecraft/gametest/framework/TestReporter -
 inner com/google/common/escape/Escapers$Builder com/google/common/escape/Escapers Builder public,static,final
 method public <init> ()V - -
 method public onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 175
class net/minecraft/gametest/framework/TestClassNameArgument 52 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Ljava/lang/String;>;
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testClassName ()Lnet/minecraft/gametest/framework/TestClassNameArgument; - -
 method public,static getTestClassName (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Ljava/lang/String; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Ljava/lang/String; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 82
class net/minecraft/gametest/framework/TestClassNameArgument 60 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Ljava/lang/String;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testClassName ()Lnet/minecraft/gametest/framework/TestClassNameArgument; - -
 method public,static getTestClassName (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Ljava/lang/String; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Ljava/lang/String; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 93
class net/minecraft/gametest/framework/TestClassNameArgument 61 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Ljava/lang/String;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testClassName ()Lnet/minecraft/gametest/framework/TestClassNameArgument; - -
 method public,static getTestClassName (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Ljava/lang/String; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Ljava/lang/String; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 128
class net/minecraft/gametest/framework/TestClassNameArgument 65 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Ljava/lang/String;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Ljava/lang/String; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testClassName ()Lnet/minecraft/gametest/framework/TestClassNameArgument; - -
 method public,static getTestClassName (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Ljava/lang/String; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Ljava/lang/String; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 115
class net/minecraft/gametest/framework/TestCommand 52 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static,final,enum
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 86
class net/minecraft/gametest/framework/TestCommand 52 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 104
class net/minecraft/gametest/framework/TestCommand 60 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 690
class net/minecraft/gametest/framework/TestCommand 61 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 311
class net/minecraft/gametest/framework/TestCommand 61 public,super java/lang/Object - -
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 132
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$Runner net/minecraft/gametest/framework/TestCommand Runner public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STRUCTURE_BLOCK_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final STRUCTURE_BLOCK_FULL_SEARCH_RADIUS I - I200
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 480
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$Runner net/minecraft/gametest/framework/TestCommand Runner public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STRUCTURE_BLOCK_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final STRUCTURE_BLOCK_FULL_SEARCH_RADIUS I - I200
 field public,static,final VERIFY_TEST_GRID_AXIS_SIZE I - I10
 field public,static,final VERIFY_TEST_BATCH_SIZE I - I100
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 483
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$ShowText net/minecraft/network/chat/HoverEvent ShowText public,static,final
 inner net/minecraft/network/chat/ClickEvent$CopyToClipboard net/minecraft/network/chat/ClickEvent CopyToClipboard public,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/ClickEvent$SuggestCommand net/minecraft/network/chat/ClickEvent SuggestCommand public,static,final
 inner com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TEST_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final TEST_FULL_SEARCH_RADIUS I - I200
 field public,static,final VERIFY_TEST_GRID_AXIS_SIZE I - I10
 field public,static,final VERIFY_TEST_BATCH_SIZE I - I100
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;Lnet/minecraft/commands/CommandBuildContext;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;Lnet/minecraft/commands/CommandBuildContext;)V -
 method public,static suggestTestFunction (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public,static trackAndStartRunner (Lnet/minecraft/commands/CommandSourceStack;Lnet/minecraft/gametest/framework/GameTestRunner;)I - -
in 134
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$ShowText net/minecraft/network/chat/HoverEvent ShowText public,static,final
 inner net/minecraft/network/chat/ClickEvent$CopyToClipboard net/minecraft/network/chat/ClickEvent CopyToClipboard public,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/ClickEvent$SuggestCommand net/minecraft/network/chat/ClickEvent SuggestCommand public,static,final
 inner com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TEST_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final TEST_FULL_SEARCH_RADIUS I - I250
 field public,static,final VERIFY_TEST_GRID_AXIS_SIZE I - I10
 field public,static,final VERIFY_TEST_BATCH_SIZE I - I100
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;Lnet/minecraft/commands/CommandBuildContext;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;Lnet/minecraft/commands/CommandBuildContext;)V -
 method public,static suggestTestFunction (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public,static trackAndStartRunner (Lnet/minecraft/commands/CommandSourceStack;Lnet/minecraft/gametest/framework/GameTestRunner;)I - -
in 108
class net/minecraft/gametest/framework/TestCommand 60 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 421
class net/minecraft/gametest/framework/TestCommand 61 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer private,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 316
class net/minecraft/gametest/framework/TestCommand 61 public,super java/lang/Object - -
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer private,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 136
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer private,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$Runner net/minecraft/gametest/framework/TestCommand Runner public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STRUCTURE_BLOCK_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final STRUCTURE_BLOCK_FULL_SEARCH_RADIUS I - I200
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 213
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer private,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/entity/Entity$RemovalReason net/minecraft/world/entity/Entity RemovalReason public,static,final,enum
 inner net/minecraft/gametest/framework/TestCommand$Runner net/minecraft/gametest/framework/TestCommand Runner public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final STRUCTURE_BLOCK_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final STRUCTURE_BLOCK_FULL_SEARCH_RADIUS I - I200
 field public,static,final VERIFY_TEST_GRID_AXIS_SIZE I - I10
 field public,static,final VERIFY_TEST_BATCH_SIZE I - I100
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;)V -
in 147
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$ShowText net/minecraft/network/chat/HoverEvent ShowText public,static,final
 inner net/minecraft/network/chat/ClickEvent$CopyToClipboard net/minecraft/network/chat/ClickEvent CopyToClipboard public,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer private,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/ClickEvent$SuggestCommand net/minecraft/network/chat/ClickEvent SuggestCommand public,static,final
 inner com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TEST_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final TEST_FULL_SEARCH_RADIUS I - I200
 field public,static,final VERIFY_TEST_GRID_AXIS_SIZE I - I10
 field public,static,final VERIFY_TEST_BATCH_SIZE I - I100
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;Lnet/minecraft/commands/CommandBuildContext;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;Lnet/minecraft/commands/CommandBuildContext;)V -
 method public,static suggestTestFunction (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public,static trackAndStartRunner (Lnet/minecraft/commands/CommandSourceStack;Lnet/minecraft/gametest/framework/GameTestRunner;)I - -
in 138
class net/minecraft/gametest/framework/TestCommand 65 public,super java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/network/chat/HoverEvent$ShowText net/minecraft/network/chat/HoverEvent ShowText public,static,final
 inner net/minecraft/network/chat/ClickEvent$CopyToClipboard net/minecraft/network/chat/ClickEvent CopyToClipboard public,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer private,static,final
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/network/chat/ClickEvent$SuggestCommand net/minecraft/network/chat/ClickEvent SuggestCommand public,static,final
 inner com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType$Function com/mojang/brigadier/exceptions/Dynamic3CommandExceptionType Function public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final TEST_NEARBY_SEARCH_RADIUS I - I15
 field public,static,final TEST_FULL_SEARCH_RADIUS I - I250
 field public,static,final VERIFY_TEST_GRID_AXIS_SIZE I - I10
 field public,static,final VERIFY_TEST_BATCH_SIZE I - I100
 method public <init> ()V - -
 method public,static register (Lcom/mojang/brigadier/CommandDispatcher;Lnet/minecraft/commands/CommandBuildContext;)V (Lcom/mojang/brigadier/CommandDispatcher<Lnet/minecraft/commands/CommandSourceStack;>;Lnet/minecraft/commands/CommandBuildContext;)V -
 method public,static suggestTestFunction (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public,static trackAndStartRunner (Lnet/minecraft/commands/CommandSourceStack;Lnet/minecraft/gametest/framework/GameTestRunner;)I - -
in 224
class net/minecraft/gametest/framework/TestCommand$Runner 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestCommand$Runner net/minecraft/gametest/framework/TestCommand Runner public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFinder;)V (Lnet/minecraft/gametest/framework/TestFinder<Lnet/minecraft/gametest/framework/TestCommand$Runner;>;)V -
 method public reset ()I - -
 method public clear ()I - -
 method public export ()I - -
 method public run (Lnet/minecraft/gametest/framework/RetryOptions;II)I - -
 method public run (II)I - -
 method public run (I)I - -
 method public run (Lnet/minecraft/gametest/framework/RetryOptions;I)I - -
 method public run (Lnet/minecraft/gametest/framework/RetryOptions;)I - -
 method public run ()I - -
 method public locate ()I - -
in 282
class net/minecraft/gametest/framework/TestCommand$Runner 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestCommand$Runner net/minecraft/gametest/framework/TestCommand Runner public,static
 inner net/minecraft/gametest/framework/GameTestRunner$Builder net/minecraft/gametest/framework/GameTestRunner Builder public,static
 inner net/minecraft/gametest/framework/GameTestRunner$GameTestBatcher net/minecraft/gametest/framework/GameTestRunner GameTestBatcher public,static,interface,abstract
 inner net/minecraft/gametest/framework/GameTestRunner$StructureSpawner net/minecraft/gametest/framework/GameTestRunner StructureSpawner public,static,interface,abstract
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 inner net/minecraft/network/chat/HoverEvent$Action net/minecraft/network/chat/HoverEvent Action public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/gametest/framework/TestFinder;)V (Lnet/minecraft/gametest/framework/TestFinder<Lnet/minecraft/gametest/framework/TestCommand$Runner;>;)V -
 method public reset ()I - -
 method public clear ()I - -
 method public export ()I - -
 method public run (Lnet/minecraft/gametest/framework/RetryOptions;II)I - -
 method public run (II)I - -
 method public run (I)I - -
 method public run (Lnet/minecraft/gametest/framework/RetryOptions;I)I - -
 method public run (Lnet/minecraft/gametest/framework/RetryOptions;)I - -
 method public run ()I - -
 method public locate ()I - -
in 60
class net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer 65 final,super java/lang/Record net/minecraft/gametest/framework/GameTestBatchListener -
 inner net/minecraft/gametest/framework/TestCommand$TestBatchSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestBatchSummaryDisplayer static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public testBatchStarting (Lnet/minecraft/gametest/framework/GameTestBatch;)V - -
 method public testBatchFinished (Lnet/minecraft/gametest/framework/GameTestBatch;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public source ()Lnet/minecraft/commands/CommandSourceStack; - -
in 175
class net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer 52 super java/lang/Object net/minecraft/gametest/framework/GameTestListener -
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 method public <init> (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/MultipleTestTracker;)V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 82
class net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer 60 super java/lang/Object net/minecraft/gametest/framework/GameTestListener -
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 method public <init> (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/MultipleTestTracker;)V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 93
class net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer 61 super java/lang/Object net/minecraft/gametest/framework/GameTestListener -
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer static
 method public <init> (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/MultipleTestTracker;)V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 128
class net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer 65 public,final,super java/lang/Record net/minecraft/gametest/framework/GameTestListener -
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/gametest/framework/MultipleTestTracker;)V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testAddedForRerun (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public level ()Lnet/minecraft/server/level/ServerLevel; - -
 method public tracker ()Lnet/minecraft/gametest/framework/MultipleTestTracker; - -
in 96
class net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer 65 public,final,super java/lang/Record net/minecraft/gametest/framework/GameTestListener -
 inner net/minecraft/gametest/framework/TestCommand$TestSummaryDisplayer net/minecraft/gametest/framework/TestCommand TestSummaryDisplayer public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/commands/CommandSourceStack;Lnet/minecraft/gametest/framework/MultipleTestTracker;)V - -
 method public testStructureLoaded (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public testPassed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testFailed (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public testAddedForRerun (Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestInfo;Lnet/minecraft/gametest/framework/GameTestRunner;)V - -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public source ()Lnet/minecraft/commands/CommandSourceStack; - -
 method public tracker ()Lnet/minecraft/gametest/framework/MultipleTestTracker; - -
in 167
class net/minecraft/gametest/framework/TestData 65 public,final,super java/lang/Record - <EnvironmentType:Ljava/lang/Object;>Ljava/lang/Record;
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P10 com/mojang/datafixers/Products P10 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>;
 method public <init> (Ljava/lang/Object;Lnet/minecraft/resources/ResourceLocation;IIZLnet/minecraft/world/level/block/Rotation;)V (TEnvironmentType;Lnet/minecraft/resources/ResourceLocation;IIZLnet/minecraft/world/level/block/Rotation;)V -
 method public <init> (Ljava/lang/Object;Lnet/minecraft/resources/ResourceLocation;IIZ)V (TEnvironmentType;Lnet/minecraft/resources/ResourceLocation;IIZ)V -
 method public <init> (Ljava/lang/Object;Lnet/minecraft/resources/ResourceLocation;IIZLnet/minecraft/world/level/block/Rotation;ZIIZ)V (TEnvironmentType;Lnet/minecraft/resources/ResourceLocation;IIZLnet/minecraft/world/level/block/Rotation;ZIIZ)V -
 method public map (Ljava/util/function/Function;)Lnet/minecraft/gametest/framework/TestData; <T:Ljava/lang/Object;>(Ljava/util/function/Function<TEnvironmentType;TT;>;)Lnet/minecraft/gametest/framework/TestData<TT;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public environment ()Ljava/lang/Object; ()TEnvironmentType; -
 method public structure ()Lnet/minecraft/resources/ResourceLocation; - -
 method public maxTicks ()I - -
 method public setupTicks ()I - -
 method public required ()Z - -
 method public rotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public manualOnly ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public skyAccess ()Z - -
in 2
class net/minecraft/gametest/framework/TestData 65 public,final,super java/lang/Record - <EnvironmentType:Ljava/lang/Object;>Ljava/lang/Record;
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P10 com/mojang/datafixers/Products P10 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestData<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;>;
 method public <init> (Ljava/lang/Object;Lnet/minecraft/resources/Identifier;IIZLnet/minecraft/world/level/block/Rotation;)V (TEnvironmentType;Lnet/minecraft/resources/Identifier;IIZLnet/minecraft/world/level/block/Rotation;)V -
 method public <init> (Ljava/lang/Object;Lnet/minecraft/resources/Identifier;IIZ)V (TEnvironmentType;Lnet/minecraft/resources/Identifier;IIZ)V -
 method public <init> (Ljava/lang/Object;Lnet/minecraft/resources/Identifier;IIZLnet/minecraft/world/level/block/Rotation;ZIIZ)V (TEnvironmentType;Lnet/minecraft/resources/Identifier;IIZLnet/minecraft/world/level/block/Rotation;ZIIZ)V -
 method public map (Ljava/util/function/Function;)Lnet/minecraft/gametest/framework/TestData; <T:Ljava/lang/Object;>(Ljava/util/function/Function<TEnvironmentType;TT;>;)Lnet/minecraft/gametest/framework/TestData<TT;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public environment ()Ljava/lang/Object; ()TEnvironmentType; -
 method public structure ()Lnet/minecraft/resources/Identifier; - -
 method public maxTicks ()I - -
 method public setupTicks ()I - -
 method public required ()Z - -
 method public rotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public manualOnly ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public skyAccess ()Z - -
in 610
class net/minecraft/gametest/framework/TestEnvironmentDefinition 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf net/minecraft/gametest/framework/TestEnvironmentDefinition AllOf public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules net/minecraft/gametest/framework/TestEnvironmentDefinition SetGameRules public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$TimeOfDay net/minecraft/gametest/framework/TestEnvironmentDefinition TimeOfDay public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather net/minecraft/gametest/framework/TestEnvironmentDefinition Weather public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Functions net/minecraft/gametest/framework/TestEnvironmentDefinition Functions public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather Type public,static,final,enum
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules Entry public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DIRECT_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;
 method public,static bootstrap (Lnet/minecraft/core/Registry;)Lcom/mojang/serialization/MapCodec; (Lnet/minecraft/core/Registry<Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
 method public,abstract setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,abstract codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
in 2
class net/minecraft/gametest/framework/TestEnvironmentDefinition 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf net/minecraft/gametest/framework/TestEnvironmentDefinition AllOf public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules net/minecraft/gametest/framework/TestEnvironmentDefinition SetGameRules public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$TimeOfDay net/minecraft/gametest/framework/TestEnvironmentDefinition TimeOfDay public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather net/minecraft/gametest/framework/TestEnvironmentDefinition Weather public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Functions net/minecraft/gametest/framework/TestEnvironmentDefinition Functions public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DIRECT_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;
 method public,static bootstrap (Lnet/minecraft/core/Registry;)Lcom/mojang/serialization/MapCodec; (Lnet/minecraft/core/Registry<Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
 method public,abstract setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,abstract codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
in 281
class net/minecraft/gametest/framework/TestEnvironmentDefinition 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf net/minecraft/gametest/framework/TestEnvironmentDefinition AllOf public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules net/minecraft/gametest/framework/TestEnvironmentDefinition SetGameRules public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$TimeOfDay net/minecraft/gametest/framework/TestEnvironmentDefinition TimeOfDay public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather net/minecraft/gametest/framework/TestEnvironmentDefinition Weather public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Functions net/minecraft/gametest/framework/TestEnvironmentDefinition Functions public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules Entry public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather Type public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DIRECT_CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;
 method public,static bootstrap (Lnet/minecraft/core/Registry;)Lcom/mojang/serialization/MapCodec; (Lnet/minecraft/core/Registry<Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
 method public,abstract setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public,abstract codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<+Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>; -
in 96
class net/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf 65 public,final,super java/lang/Record net/minecraft/gametest/framework/TestEnvironmentDefinition -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf net/minecraft/gametest/framework/TestEnvironmentDefinition AllOf public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P1 com/mojang/datafixers/Products P1 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf;>;
 method public,varargs <init> ([Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>;)V -
 method public setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$AllOf;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public definitions ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/core/Holder<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition;>;>; -
in 167
class net/minecraft/gametest/framework/TestEnvironmentDefinition$Functions 65 public,final,super java/lang/Record net/minecraft/gametest/framework/TestEnvironmentDefinition -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Functions net/minecraft/gametest/framework/TestEnvironmentDefinition Functions public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Functions;>;
 method public <init> (Ljava/util/Optional;Ljava/util/Optional;)V (Ljava/util/Optional<Lnet/minecraft/resources/ResourceLocation;>;Ljava/util/Optional<Lnet/minecraft/resources/ResourceLocation;>;)V -
 method public setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Functions;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public setupFunction ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/resources/ResourceLocation;>; -
 method public teardownFunction ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/resources/ResourceLocation;>; -
in 2
class net/minecraft/gametest/framework/TestEnvironmentDefinition$Functions 65 public,final,super java/lang/Record net/minecraft/gametest/framework/TestEnvironmentDefinition -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Functions net/minecraft/gametest/framework/TestEnvironmentDefinition Functions public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Functions;>;
 method public <init> (Ljava/util/Optional;Ljava/util/Optional;)V (Ljava/util/Optional<Lnet/minecraft/resources/Identifier;>;Ljava/util/Optional<Lnet/minecraft/resources/Identifier;>;)V -
 method public setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Functions;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public setupFunction ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/resources/Identifier;>; -
 method public teardownFunction ()Ljava/util/Optional; ()Ljava/util/Optional<Lnet/minecraft/resources/Identifier;>; -
in 167
class net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules 65 public,final,super java/lang/Record net/minecraft/gametest/framework/TestEnvironmentDefinition -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules net/minecraft/gametest/framework/TestEnvironmentDefinition SetGameRules public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules Entry public,static,final
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner net/minecraft/world/level/GameRules$BooleanValue net/minecraft/world/level/GameRules BooleanValue public,static
 inner net/minecraft/world/level/GameRules$IntegerValue net/minecraft/world/level/GameRules IntegerValue public,static
 inner net/minecraft/world/level/GameRules$Type net/minecraft/world/level/GameRules Type public,static
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules;>;
 method public <init> (Ljava/util/List;Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry<Ljava/lang/Boolean;Lnet/minecraft/world/level/GameRules$BooleanValue;>;>;Ljava/util/List<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry<Ljava/lang/Integer;Lnet/minecraft/world/level/GameRules$IntegerValue;>;>;)V -
 method public setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules;>; -
 method public,static entry (Lnet/minecraft/world/level/GameRules$Key;Ljava/lang/Object;)Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry; <S:Ljava/lang/Object;T:Lnet/minecraft/world/level/GameRules$Value<TT;>;>(Lnet/minecraft/world/level/GameRules$Key<TT;>;TS;)Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry<TS;TT;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public boolRules ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry<Ljava/lang/Boolean;Lnet/minecraft/world/level/GameRules$BooleanValue;>;>; -
 method public intRules ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry<Ljava/lang/Integer;Lnet/minecraft/world/level/GameRules$IntegerValue;>;>; -
in 2
class net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules 65 public,final,super java/lang/Record net/minecraft/gametest/framework/TestEnvironmentDefinition -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules net/minecraft/gametest/framework/TestEnvironmentDefinition SetGameRules public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P1 com/mojang/datafixers/Products P1 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules;>;
 method public <init> (Lnet/minecraft/world/level/gamerules/GameRuleMap;)V - -
 method public setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public gameRulesMap ()Lnet/minecraft/world/level/gamerules/GameRuleMap; - -
in 167
class net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry 65 public,final,super java/lang/Record - <S:Ljava/lang/Object;T:Lnet/minecraft/world/level/GameRules$Value<TT;>;>Ljava/lang/Record;
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules net/minecraft/gametest/framework/TestEnvironmentDefinition SetGameRules public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry net/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules Entry public,static,final
 inner net/minecraft/world/level/GameRules$Key net/minecraft/world/level/GameRules Key public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P2 com/mojang/datafixers/Products P2 public,static,final
 inner net/minecraft/world/level/GameRules$Value net/minecraft/world/level/GameRules Value public,static,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/level/GameRules$Key;Ljava/lang/Object;)V (Lnet/minecraft/world/level/GameRules$Key<TT;>;TS;)V -
 method public,static codec (Ljava/lang/Class;Lcom/mojang/serialization/Codec;)Lcom/mojang/serialization/Codec; <S:Ljava/lang/Object;T:Lnet/minecraft/world/level/GameRules$Value<TT;>;>(Ljava/lang/Class<TT;>;Lcom/mojang/serialization/Codec<TS;>;)Lcom/mojang/serialization/Codec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$SetGameRules$Entry<TS;TT;>;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public key ()Lnet/minecraft/world/level/GameRules$Key; ()Lnet/minecraft/world/level/GameRules$Key<TT;>; -
 method public value ()Ljava/lang/Object; ()TS; -
in 96
class net/minecraft/gametest/framework/TestEnvironmentDefinition$TimeOfDay 65 public,final,super java/lang/Record net/minecraft/gametest/framework/TestEnvironmentDefinition -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$TimeOfDay net/minecraft/gametest/framework/TestEnvironmentDefinition TimeOfDay public,static,final
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P1 com/mojang/datafixers/Products P1 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$TimeOfDay;>;
 method public <init> (I)V - -
 method public setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$TimeOfDay;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public time ()I - -
in 96
class net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather 65 public,final,super java/lang/Record net/minecraft/gametest/framework/TestEnvironmentDefinition -
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather net/minecraft/gametest/framework/TestEnvironmentDefinition Weather public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather Type public,static,final,enum
 inner com/mojang/serialization/codecs/RecordCodecBuilder$Instance com/mojang/serialization/codecs/RecordCodecBuilder Instance public,static,final
 inner com/mojang/datafixers/Products$P1 com/mojang/datafixers/Products P1 public,static,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final CODEC Lcom/mojang/serialization/MapCodec; Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather;>;
 method public <init> (Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type;)V - -
 method public setup (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public teardown (Lnet/minecraft/server/level/ServerLevel;)V - -
 method public codec ()Lcom/mojang/serialization/MapCodec; ()Lcom/mojang/serialization/MapCodec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather;>; -
 method public,final toString ()Ljava/lang/String; - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public weather ()Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type; - -
in 96
class net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type 65 public,final,super,enum java/lang/Enum net/minecraft/util/StringRepresentable Ljava/lang/Enum<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type;>;Lnet/minecraft/util/StringRepresentable;
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather net/minecraft/gametest/framework/TestEnvironmentDefinition Weather public,static,final
 inner net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type net/minecraft/gametest/framework/TestEnvironmentDefinition$Weather Type public,static,final,enum
 inner net/minecraft/util/StringRepresentable$EnumCodec net/minecraft/util/StringRepresentable EnumCodec public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final,enum CLEAR Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type; -
 field public,static,final,enum RAIN Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type; -
 field public,static,final,enum THUNDER Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type; -
 field public,static,final CODEC Lcom/mojang/serialization/Codec; Lcom/mojang/serialization/Codec<Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type;>;
 method public,static values ()[Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestEnvironmentDefinition$Weather$Type; - -
 method public getSerializedName ()Ljava/lang/String; - -
in 128
class net/minecraft/gametest/framework/TestFinder 65 public,super java/lang/Object net/minecraft/gametest/framework/StructureBlockPosFinder,net/minecraft/gametest/framework/TestFunctionFinder <T:Ljava/lang/Object;>Ljava/lang/Object;Lnet/minecraft/gametest/framework/StructureBlockPosFinder;Lnet/minecraft/gametest/framework/TestFunctionFinder;
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public findStructureBlockPos ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public source ()Lnet/minecraft/commands/CommandSourceStack; - -
 method public findTestFunctions ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/TestFunction;>; -
in 96
class net/minecraft/gametest/framework/TestFinder 65 public,super java/lang/Object net/minecraft/gametest/framework/TestInstanceFinder,net/minecraft/gametest/framework/TestPosFinder -
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public findTestPos ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
 method public,static builder ()Lnet/minecraft/gametest/framework/TestFinder$Builder; - -
 method public source ()Lnet/minecraft/commands/CommandSourceStack; - -
 method public findTests ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
in 128
class net/minecraft/gametest/framework/TestFinder$Builder 65 public,super java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/util/function/Function;)V (Ljava/util/function/Function<Lnet/minecraft/gametest/framework/TestFinder<TT;>;TT;>;)V -
 method public createMultipleCopies (I)Lnet/minecraft/gametest/framework/TestFinder$Builder; (I)Lnet/minecraft/gametest/framework/TestFinder$Builder<TT;>; -
 method public radius (Lcom/mojang/brigadier/context/CommandContext;I)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;I)TT; -
 method public nearest (Lcom/mojang/brigadier/context/CommandContext;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)TT; -
 method public allNearby (Lcom/mojang/brigadier/context/CommandContext;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)TT; -
 method public lookedAt (Lcom/mojang/brigadier/context/CommandContext;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)TT; -
 method public allTests (Lcom/mojang/brigadier/context/CommandContext;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)TT; -
 method public allTestsInClass (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)TT; -
 method public failedTests (Lcom/mojang/brigadier/context/CommandContext;Z)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Z)TT; -
 method public byArgument (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)TT; -
 method public locateByName (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)TT; -
 method public failedTests (Lcom/mojang/brigadier/context/CommandContext;)Ljava/lang/Object; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)TT; -
in 96
class net/minecraft/gametest/framework/TestFinder$Builder 65 public,super java/lang/Object - -
 inner net/minecraft/gametest/framework/TestFinder$Builder net/minecraft/gametest/framework/TestFinder Builder public,static
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public createMultipleCopies (I)Lnet/minecraft/gametest/framework/TestFinder$Builder; - -
 method public radius (Lcom/mojang/brigadier/context/CommandContext;I)Lnet/minecraft/gametest/framework/TestFinder; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;I)Lnet/minecraft/gametest/framework/TestFinder; -
 method public nearest (Lcom/mojang/brigadier/context/CommandContext;)Lnet/minecraft/gametest/framework/TestFinder; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)Lnet/minecraft/gametest/framework/TestFinder; -
 method public allNearby (Lcom/mojang/brigadier/context/CommandContext;)Lnet/minecraft/gametest/framework/TestFinder; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)Lnet/minecraft/gametest/framework/TestFinder; -
 method public lookedAt (Lcom/mojang/brigadier/context/CommandContext;)Lnet/minecraft/gametest/framework/TestFinder; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)Lnet/minecraft/gametest/framework/TestFinder; -
 method public failedTests (Lcom/mojang/brigadier/context/CommandContext;Z)Lnet/minecraft/gametest/framework/TestFinder; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Z)Lnet/minecraft/gametest/framework/TestFinder; -
 method public byResourceSelection (Lcom/mojang/brigadier/context/CommandContext;Ljava/util/Collection;)Lnet/minecraft/gametest/framework/TestFinder; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/util/Collection<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>;)Lnet/minecraft/gametest/framework/TestFinder; -
 method public failedTests (Lcom/mojang/brigadier/context/CommandContext;)Lnet/minecraft/gametest/framework/TestFinder; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;)Lnet/minecraft/gametest/framework/TestFinder; -
in 115
class net/minecraft/gametest/framework/TestFunction 52 public,super java/lang/Object - -
 method public run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public getMaxTicks ()I - -
 method public isRequired ()Z - -
 method public getBatchName ()Ljava/lang/String; - -
 method public getSetupTicks ()J - -
in 86
class net/minecraft/gametest/framework/TestFunction 52 public,super java/lang/Object - -
 method public run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public getMaxTicks ()I - -
 method public isRequired ()Z - -
 method public getBatchName ()Ljava/lang/String; - -
 method public getSetupTicks ()J - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
in 82
class net/minecraft/gametest/framework/TestFunction 60 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJZLjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJZLjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZLjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZLjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZIILjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZIILjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public getMaxTicks ()I - -
 method public isRequired ()Z - -
 method public getBatchName ()Ljava/lang/String; - -
 method public getSetupTicks ()J - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public isFlaky ()Z - -
 method public getMaxAttempts ()I - -
 method public getRequiredSuccesses ()I - -
in 93
class net/minecraft/gametest/framework/TestFunction 61 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJZLjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJZLjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZLjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZLjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZIILjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZIILjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public getTestName ()Ljava/lang/String; - -
 method public getStructureName ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
 method public getMaxTicks ()I - -
 method public isRequired ()Z - -
 method public getBatchName ()Ljava/lang/String; - -
 method public getSetupTicks ()J - -
 method public getRotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public isFlaky ()Z - -
 method public getMaxAttempts ()I - -
 method public getRequiredSuccesses ()I - -
in 128
class net/minecraft/gametest/framework/TestFunction 65 public,final,super java/lang/Record - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJZLjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJZLjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZLjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZLjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public <init> (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZZIIZLjava/util/function/Consumer;)V (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lnet/minecraft/world/level/block/Rotation;IJZZIIZLjava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;)V -
 method public run (Lnet/minecraft/gametest/framework/GameTestHelper;)V - -
 method public toString ()Ljava/lang/String; - -
 method public isFlaky ()Z - -
 method public,final hashCode ()I - -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public batchName ()Ljava/lang/String; - -
 method public testName ()Ljava/lang/String; - -
 method public structureName ()Ljava/lang/String; - -
 method public rotation ()Lnet/minecraft/world/level/block/Rotation; - -
 method public maxTicks ()I - -
 method public setupTicks ()J - -
 method public required ()Z - -
 method public manualOnly ()Z - -
 method public maxAttempts ()I - -
 method public requiredSuccesses ()I - -
 method public skyAccess ()Z - -
 method public function ()Ljava/util/function/Consumer; ()Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>; -
in 175
class net/minecraft/gametest/framework/TestFunctionArgument 52 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Lnet/minecraft/gametest/framework/TestFunction;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/gametest/framework/TestFunction; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testFunctionArgument ()Lnet/minecraft/gametest/framework/TestFunctionArgument; - -
 method public,static getTestFunction (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 82
class net/minecraft/gametest/framework/TestFunctionArgument 60 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Lnet/minecraft/gametest/framework/TestFunction;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/gametest/framework/TestFunction; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testFunctionArgument ()Lnet/minecraft/gametest/framework/TestFunctionArgument; - -
 method public,static getTestFunction (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 93
class net/minecraft/gametest/framework/TestFunctionArgument 61 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Lnet/minecraft/gametest/framework/TestFunction;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/gametest/framework/TestFunction; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testFunctionArgument ()Lnet/minecraft/gametest/framework/TestFunctionArgument; - -
 method public,static getTestFunction (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 128
class net/minecraft/gametest/framework/TestFunctionArgument 65 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Lnet/minecraft/gametest/framework/TestFunction;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public parse (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/gametest/framework/TestFunction; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public,static testFunctionArgument ()Lnet/minecraft/gametest/framework/TestFunctionArgument; - -
 method public,static getTestFunction (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; (Lcom/mojang/brigadier/context/CommandContext<Lnet/minecraft/commands/CommandSourceStack;>;Ljava/lang/String;)Lnet/minecraft/gametest/framework/TestFunction; -
 method public listSuggestions (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public,static suggestTestFunction (Lcom/mojang/brigadier/context/CommandContext;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Lcom/mojang/brigadier/suggestion/SuggestionsBuilder;)Ljava/util/concurrent/CompletableFuture<Lcom/mojang/brigadier/suggestion/Suggestions;>; -
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 128
class net/minecraft/gametest/framework/TestFunctionFinder 65 public,interface,abstract java/lang/Object - -
 method public,abstract findTestFunctions ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/gametest/framework/TestFunction;>; -
in 96
class net/minecraft/gametest/framework/TestFunctionLoader 65 public,super,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> ()V - -
 method public,static registerLoader (Lnet/minecraft/gametest/framework/TestFunctionLoader;)V - -
 method public,static runLoaders (Lnet/minecraft/core/Registry;)V (Lnet/minecraft/core/Registry<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;)V -
 method public,abstract load (Ljava/util/function/BiConsumer;)V (Ljava/util/function/BiConsumer<Lnet/minecraft/resources/ResourceKey<Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;Ljava/util/function/Consumer<Lnet/minecraft/gametest/framework/GameTestHelper;>;>;)V -
in 96
class net/minecraft/gametest/framework/TestInstanceFinder 65 public,interface,abstract java/lang/Object - -
 inner net/minecraft/core/Holder$Reference net/minecraft/core/Holder Reference public,static
 method public,abstract findTests ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/core/Holder$Reference<Lnet/minecraft/gametest/framework/GameTestInstance;>;>; -
in 96
class net/minecraft/gametest/framework/TestPosFinder 65 public,interface,abstract java/lang/Object - -
 method public,abstract findTestPos ()Ljava/util/stream/Stream; ()Ljava/util/stream/Stream<Lnet/minecraft/core/BlockPos;>; -
in 175
class net/minecraft/gametest/framework/TestReporter 52 public,interface,abstract java/lang/Object - -
 method public,abstract onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
in 82
class net/minecraft/gametest/framework/TestReporter 60 public,interface,abstract java/lang/Object - -
 method public,abstract onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public finish ()V - -
in 93
class net/minecraft/gametest/framework/TestReporter 61 public,interface,abstract java/lang/Object - -
 method public,abstract onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public finish ()V - -
in 60
class net/minecraft/gametest/framework/TestReporter 65 public,interface,abstract java/lang/Object - -
 method public,abstract onTestFailed (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public,abstract onTestSuccess (Lnet/minecraft/gametest/framework/GameTestInfo;)V - -
 method public finish ()V - -
in 96
class net/minecraft/gametest/framework/UnknownGameTestException 65 public,super net/minecraft/gametest/framework/GameTestException - -
 method public <init> (Ljava/lang/Throwable;)V - -
 method public getDescription ()Lnet/minecraft/network/chat/Component; - -
