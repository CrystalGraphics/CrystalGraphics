cg-stub-db 1
in 24
class net/minecraft/village/MerchantRecipe 50 public,super java/lang/Object - -
 method public compensateToolUses ()V - -
 method public <init> (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;II)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/Item;)V - -
 method public getItemToBuy ()Lnet/minecraft/item/ItemStack; - -
 method public getSecondItemToBuy ()Lnet/minecraft/item/ItemStack; - -
 method public hasSecondItemToBuy ()Z - -
 method public getItemToSell ()Lnet/minecraft/item/ItemStack; - -
 method public getToolUses ()I - -
 method public getMaxTradeUses ()I - -
 method public incrementToolUses ()V - -
 method public increaseMaxTradeUses (I)V - -
 method public isRecipeDisabled ()Z - -
 method public getRewardsExp ()Z - -
 method public readFromTags (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToTags ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 326
class net/minecraft/village/MerchantRecipe 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;II)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/Item;)V - -
 method public getItemToBuy ()Lnet/minecraft/item/ItemStack; - -
 method public getSecondItemToBuy ()Lnet/minecraft/item/ItemStack; - -
 method public hasSecondItemToBuy ()Z - -
 method public getItemToSell ()Lnet/minecraft/item/ItemStack; - -
 method public getToolUses ()I - -
 method public getMaxTradeUses ()I - -
 method public incrementToolUses ()V - -
 method public increaseMaxTradeUses (I)V - -
 method public isRecipeDisabled ()Z - -
 method public compensateToolUses ()V - -
 method public getRewardsExp ()Z - -
 method public readFromTags (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToTags ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 24
class net/minecraft/village/MerchantRecipeList 50 public,super java/util/ArrayList - Ljava/util/ArrayList<Lnet/minecraft/village/MerchantRecipe;>;
 method public,static readFromBuf (Lnet/minecraft/network/PacketBuffer;)Lnet/minecraft/village/MerchantRecipeList; - java/io/IOException
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canRecipeBeUsed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;I)Lnet/minecraft/village/MerchantRecipe; - -
 method public writeToBuf (Lnet/minecraft/network/PacketBuffer;)V - -
 method public readRecipiesFromTags (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getRecipiesAsTags ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 326
class net/minecraft/village/MerchantRecipeList 52 public,super java/util/ArrayList - Ljava/util/ArrayList<Lnet/minecraft/village/MerchantRecipe;>;
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canRecipeBeUsed (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;I)Lnet/minecraft/village/MerchantRecipe; - -
 method public writeToBuf (Lnet/minecraft/network/PacketBuffer;)V - -
 method public readRecipiesFromTags (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getRecipiesAsTags ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static readFromBuf (Lnet/minecraft/network/PacketBuffer;)Lnet/minecraft/village/MerchantRecipeList; - java/io/IOException
in 90
class net/minecraft/village/Village 50 public,super java/lang/Object - -
 inner net/minecraft/village/Village$VillageAggressor net/minecraft/village/Village VillageAggressor -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public tick (I)V - -
 method public getCenter ()Lnet/minecraft/util/BlockPos; - -
 method public getVillageRadius ()I - -
 method public getNumVillageDoors ()I - -
 method public getTicksSinceLastDoorAdding ()I - -
 method public getNumVillagers ()I - -
 method public func_179866_a (Lnet/minecraft/util/BlockPos;)Z - -
 method public getVillageDoorInfoList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/village/VillageDoorInfo;>; -
 method public getNearestDoor (Lnet/minecraft/util/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public getDoorInfo (Lnet/minecraft/util/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public getExistedDoor (Lnet/minecraft/util/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public addVillageDoorInfo (Lnet/minecraft/village/VillageDoorInfo;)V - -
 method public isAnnihilated ()Z - -
 method public addOrRenewAgressor (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public findNearestVillageAggressor (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/EntityLivingBase; - -
 method public getNearestTargetPlayer (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/player/EntityPlayer; - -
 method public getReputationForPlayer (Ljava/lang/String;)I - -
 method public setReputationForPlayer (Ljava/lang/String;I)I - -
 method public isPlayerReputationTooLow (Ljava/lang/String;)Z - -
 method public readVillageDataFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeVillageDataToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public endMatingSeason ()V - -
 method public isMatingSeason ()Z - -
 method public setDefaultPlayerReputation (I)V - -
in 91
class net/minecraft/village/Village 50 public,super java/lang/Object - -
 inner net/minecraft/village/Village$VillageAggressor net/minecraft/village/Village VillageAggressor -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public tick (I)V - -
 method public getCenter ()Lnet/minecraft/util/math/BlockPos; - -
 method public getVillageRadius ()I - -
 method public getNumVillageDoors ()I - -
 method public getTicksSinceLastDoorAdding ()I - -
 method public getNumVillagers ()I - -
 method public isBlockPosWithinSqVillageRadius (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public getVillageDoorInfoList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/village/VillageDoorInfo;>; -
 method public getNearestDoor (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public getDoorInfo (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public getExistedDoor (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public addVillageDoorInfo (Lnet/minecraft/village/VillageDoorInfo;)V - -
 method public isAnnihilated ()Z - -
 method public addOrRenewAgressor (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public findNearestVillageAggressor (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/EntityLivingBase; - -
 method public getNearestTargetPlayer (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/player/EntityPlayer; - -
 method public getPlayerReputation (Ljava/lang/String;)I - -
 method public modifyPlayerReputation (Ljava/lang/String;I)I - -
 method public isPlayerReputationTooLow (Ljava/lang/String;)Z - -
 method public readVillageDataFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeVillageDataToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public endMatingSeason ()V - -
 method public isMatingSeason ()Z - -
 method public setDefaultPlayerReputation (I)V - -
in 326
class net/minecraft/village/Village 52 public,super java/lang/Object net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner net/minecraft/village/Village$VillageAggressor net/minecraft/village/Village VillageAggressor -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public tick (I)V - -
 method public getCenter ()Lnet/minecraft/util/math/BlockPos; - -
 method public getVillageRadius ()I - -
 method public getNumVillageDoors ()I - -
 method public getTicksSinceLastDoorAdding ()I - -
 method public getNumVillagers ()I - -
 method public isBlockPosWithinSqVillageRadius (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public getVillageDoorInfoList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/village/VillageDoorInfo;>; -
 method public getNearestDoor (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public getDoorInfo (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public getExistedDoor (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/village/VillageDoorInfo; - -
 method public addVillageDoorInfo (Lnet/minecraft/village/VillageDoorInfo;)V - -
 method public isAnnihilated ()Z - -
 method public addOrRenewAgressor (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public findNearestVillageAggressor (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/EntityLivingBase; - -
 method public getNearestTargetPlayer (Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/entity/player/EntityPlayer; - -
 method public,deprecated getPlayerReputation (Ljava/lang/String;)I - -
 method public getPlayerReputation (Ljava/util/UUID;)I - -
 method public,deprecated modifyPlayerReputation (Ljava/lang/String;I)I - -
 method public modifyPlayerReputation (Ljava/util/UUID;I)I - -
 method public,deprecated isPlayerReputationTooLow (Ljava/lang/String;)Z - -
 method public isPlayerReputationTooLow (Ljava/util/UUID;)Z - -
 method public readVillageDataFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeVillageDataToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public endMatingSeason ()V - -
 method public isMatingSeason ()Z - -
 method public setDefaultPlayerReputation (I)V - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 24
class net/minecraft/village/Village$VillageAggressor 50 super java/lang/Object - -
 inner net/minecraft/village/Village$VillageAggressor net/minecraft/village/Village VillageAggressor -
 field public agressor Lnet/minecraft/entity/EntityLivingBase; -
 field public agressionTime I -
in 326
class net/minecraft/village/Village$VillageAggressor 52 super java/lang/Object - -
 inner net/minecraft/village/Village$VillageAggressor net/minecraft/village/Village VillageAggressor -
 field public agressor Lnet/minecraft/entity/EntityLivingBase; -
 field public agressionTime I -
in 90
class net/minecraft/village/VillageCollection 50 public,super net/minecraft/world/WorldSavedData - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setWorldsForAll (Lnet/minecraft/world/World;)V - -
 method public addToVillagerPositionList (Lnet/minecraft/util/BlockPos;)V - -
 method public tick ()V - -
 method public getVillageList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/village/Village;>; -
 method public getNearestVillage (Lnet/minecraft/util/BlockPos;I)Lnet/minecraft/village/Village; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static fileNameForProvider (Lnet/minecraft/world/WorldProvider;)Ljava/lang/String; - -
in 91
class net/minecraft/village/VillageCollection 50 public,super net/minecraft/world/WorldSavedData - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setWorldsForAll (Lnet/minecraft/world/World;)V - -
 method public addToVillagerPositionList (Lnet/minecraft/util/math/BlockPos;)V - -
 method public tick ()V - -
 method public getVillageList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/village/Village;>; -
 method public getNearestVillage (Lnet/minecraft/util/math/BlockPos;I)Lnet/minecraft/village/Village; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static fileNameForProvider (Lnet/minecraft/world/WorldProvider;)Ljava/lang/String; - -
in 326
class net/minecraft/village/VillageCollection 52 public,super net/minecraft/world/storage/WorldSavedData - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setWorldsForAll (Lnet/minecraft/world/World;)V - -
 method public addToVillagerPositionList (Lnet/minecraft/util/math/BlockPos;)V - -
 method public tick ()V - -
 method public getVillageList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/village/Village;>; -
 method public getNearestVillage (Lnet/minecraft/util/math/BlockPos;I)Lnet/minecraft/village/Village; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static fileNameForProvider (Lnet/minecraft/world/WorldProvider;)Ljava/lang/String; - -
in 90
class net/minecraft/village/VillageDoorInfo 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/util/BlockPos;III)V - -
 method public <init> (Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;I)V - -
 method public getDistanceSquared (III)I - -
 method public getDistanceToDoorBlockSq (Lnet/minecraft/util/BlockPos;)I - -
 method public getDistanceToInsideBlockSq (Lnet/minecraft/util/BlockPos;)I - -
 method public func_179850_c (Lnet/minecraft/util/BlockPos;)Z - -
 method public resetDoorOpeningRestrictionCounter ()V - -
 method public incrementDoorOpeningRestrictionCounter ()V - -
 method public getDoorOpeningRestrictionCounter ()I - -
 method public getDoorBlockPos ()Lnet/minecraft/util/BlockPos; - -
 method public getInsideBlockPos ()Lnet/minecraft/util/BlockPos; - -
 method public getInsideOffsetX ()I - -
 method public getInsideOffsetZ ()I - -
 method public getInsidePosY ()I - -
 method public func_179849_a (I)V - -
 method public getIsDetachedFromVillageFlag ()Z - -
 method public setIsDetachedFromVillageFlag (Z)V - -
in 91
class net/minecraft/village/VillageDoorInfo 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/util/math/BlockPos;III)V - -
 method public <init> (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;I)V - -
 method public getDistanceSquared (III)I - -
 method public getDistanceToDoorBlockSq (Lnet/minecraft/util/math/BlockPos;)I - -
 method public getDistanceToInsideBlockSq (Lnet/minecraft/util/math/BlockPos;)I - -
 method public isInsideSide (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public resetDoorOpeningRestrictionCounter ()V - -
 method public incrementDoorOpeningRestrictionCounter ()V - -
 method public getDoorOpeningRestrictionCounter ()I - -
 method public getDoorBlockPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getInsideBlockPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getInsideOffsetX ()I - -
 method public getInsideOffsetZ ()I - -
 method public getInsidePosY ()I - -
 method public setLastActivityTimestamp (I)V - -
 method public getIsDetachedFromVillageFlag ()Z - -
 method public setIsDetachedFromVillageFlag (Z)V - -
 method public getInsideDirection ()Lnet/minecraft/util/EnumFacing; - -
in 326
class net/minecraft/village/VillageDoorInfo 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/util/math/BlockPos;III)V - -
 method public <init> (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;I)V - -
 method public getDistanceSquared (III)I - -
 method public getDistanceToDoorBlockSq (Lnet/minecraft/util/math/BlockPos;)I - -
 method public getDistanceToInsideBlockSq (Lnet/minecraft/util/math/BlockPos;)I - -
 method public isInsideSide (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public resetDoorOpeningRestrictionCounter ()V - -
 method public incrementDoorOpeningRestrictionCounter ()V - -
 method public getDoorOpeningRestrictionCounter ()I - -
 method public getDoorBlockPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getInsideBlockPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getInsideOffsetX ()I - -
 method public getInsideOffsetZ ()I - -
 method public getLastActivityTimestamp ()I - -
 method public setLastActivityTimestamp (I)V - -
 method public getIsDetachedFromVillageFlag ()Z - -
 method public setIsDetachedFromVillageFlag (Z)V - -
 method public getInsideDirection ()Lnet/minecraft/util/EnumFacing; - -
in 24
class net/minecraft/village/VillageSiege 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public tick ()V - -
in 326
class net/minecraft/village/VillageSiege 52 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public tick ()V - -
