cg-stub-db 1
in 1023
class net/minecrell/terminalconsole/HighlightErrorConverter 52 public,final,super org/apache/logging/log4j/core/pattern/LogEventPatternConverter - -
 method protected <init> (Ljava/util/List;)V (Ljava/util/List<Lorg/apache/logging/log4j/core/pattern/PatternFormatter;>;)V -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public handlesThrowable ()Z - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lnet/minecrell/terminalconsole/HighlightErrorConverter; - -
in 384
class net/minecrell/terminalconsole/HighlightErrorConverter 52 public,super org/apache/logging/log4j/core/pattern/LogEventPatternConverter - -
 method protected <init> (Ljava/util/List;)V (Ljava/util/List<Lorg/apache/logging/log4j/core/pattern/PatternFormatter;>;)V -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public handlesThrowable ()Z - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lnet/minecrell/terminalconsole/HighlightErrorConverter; - -
in 1024
class net/minecrell/terminalconsole/MinecraftFormattingConverter 52 public,final,super org/apache/logging/log4j/core/pattern/LogEventPatternConverter - -
 field public,static,final KEEP_FORMATTING_PROPERTY Ljava/lang/String; - "terminal.keepMinecraftFormatting"
 method protected <init> (Ljava/util/List;Z)V (Ljava/util/List<Lorg/apache/logging/log4j/core/pattern/PatternFormatter;>;Z)V -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lnet/minecrell/terminalconsole/MinecraftFormattingConverter; - -
in 384
class net/minecrell/terminalconsole/MinecraftFormattingConverter 52 public,super org/apache/logging/log4j/core/pattern/LogEventPatternConverter - -
 field public,static,final KEEP_FORMATTING_PROPERTY Ljava/lang/String; - "terminal.keepMinecraftFormatting"
 method protected <init> (Ljava/util/List;Z)V (Ljava/util/List<Lorg/apache/logging/log4j/core/pattern/PatternFormatter;>;Z)V -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lnet/minecrell/terminalconsole/MinecraftFormattingConverter; - -
in 15
class net/minecrell/terminalconsole/MinecraftFormattingConverter 52 public,final,super,deprecated org/apache/logging/log4j/core/pattern/LogEventPatternConverter - -
 field public,static,final KEEP_FORMATTING_PROPERTY Ljava/lang/String; - "terminal.keepMinecraftFormatting"
 method protected <init> (Ljava/util/List;Z)V (Ljava/util/List<Lorg/apache/logging/log4j/core/pattern/PatternFormatter;>;Z)V -
 method public format (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/StringBuilder;)V - -
 method public,static newInstance (Lorg/apache/logging/log4j/core/config/Configuration;[Ljava/lang/String;)Lnet/minecrell/terminalconsole/MinecraftFormattingConverter; - -
in 1025
class net/minecrell/terminalconsole/SimpleTerminalConsole 52 public,super,abstract java/lang/Object - -
 inner org/jline/reader/LineReader$Option org/jline/reader/LineReader Option public,static,final,enum
 method public <init> ()V - -
 method protected,abstract isRunning ()Z - -
 method protected,abstract runCommand (Ljava/lang/String;)V - -
 method protected,abstract shutdown ()V - -
 method protected processInput (Ljava/lang/String;)V - -
 method protected buildReader (Lorg/jline/reader/LineReaderBuilder;)Lorg/jline/reader/LineReader; - -
 method public start ()V - -
in 15
class net/minecrell/terminalconsole/TCALookup 52 public,final,super org/apache/logging/log4j/core/lookup/AbstractLookup - -
 field public,static,final KEY_DISABLE_ANSI Ljava/lang/String; - "disableAnsi"
 method public <init> ()V - -
 method public lookup (Lorg/apache/logging/log4j/core/LogEvent;Ljava/lang/String;)Ljava/lang/String; - -
in 1023
class net/minecrell/terminalconsole/TerminalConsoleAppender 52 public,final,super org/apache/logging/log4j/core/appender/AbstractAppender - -
 field public,static,final PLUGIN_NAME Ljava/lang/String; - "TerminalConsole"
 field public,static,final JLINE_OVERRIDE_PROPERTY Ljava/lang/String; - "terminal.jline"
 field public,static,final ANSI_OVERRIDE_PROPERTY Ljava/lang/String; - "terminal.ansi"
 method public,static,synchronized getTerminal ()Lorg/jline/terminal/Terminal; - -
 method public,static,synchronized getReader ()Lorg/jline/reader/LineReader; - -
 method public,static,synchronized setReader (Lorg/jline/reader/LineReader;)V - -
 method public,static isAnsiSupported ()Z - -
 method protected <init> (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout;Z)V (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout<+Ljava/io/Serializable;>;Z)V -
 method public append (Lorg/apache/logging/log4j/core/LogEvent;)V - -
 method public,static,synchronized close ()V - java/io/IOException
 method public,static createAppender (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout;Z)Lnet/minecrell/terminalconsole/TerminalConsoleAppender; (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout<+Ljava/io/Serializable;>;Z)Lnet/minecrell/terminalconsole/TerminalConsoleAppender; -
in 384
class net/minecrell/terminalconsole/TerminalConsoleAppender 52 public,super org/apache/logging/log4j/core/appender/AbstractAppender - -
 field public,static,final PLUGIN_NAME Ljava/lang/String; - "TerminalConsole"
 field public,static,final JLINE_OVERRIDE_PROPERTY Ljava/lang/String; - "terminal.jline"
 field public,static,final ANSI_OVERRIDE_PROPERTY Ljava/lang/String; - "terminal.ansi"
 method public,static,synchronized getTerminal ()Lorg/jline/terminal/Terminal; - -
 method public,static,synchronized getReader ()Lorg/jline/reader/LineReader; - -
 method public,static,synchronized setReader (Lorg/jline/reader/LineReader;)V - -
 method public,static isAnsiSupported ()Z - -
 method protected <init> (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout;Z)V (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout<+Ljava/io/Serializable;>;Z)V -
 method public append (Lorg/apache/logging/log4j/core/LogEvent;)V - -
 method public,static,synchronized close ()V - java/io/IOException
 method public,static createAppender (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout;Z)Lnet/minecrell/terminalconsole/TerminalConsoleAppender; (Ljava/lang/String;Lorg/apache/logging/log4j/core/Filter;Lorg/apache/logging/log4j/core/Layout<+Ljava/io/Serializable;>;Z)Lnet/minecrell/terminalconsole/TerminalConsoleAppender; -
in 1023
class net/minecrell/terminalconsole/util/LoggerNamePatternSelector 52 public,final,super java/lang/Object org/apache/logging/log4j/core/layout/PatternSelector -
 inner net/minecrell/terminalconsole/util/LoggerNamePatternSelector$LoggerNameSelector net/minecrell/terminalconsole/util/LoggerNamePatternSelector LoggerNameSelector private,static
 method protected <init> (Ljava/lang/String;[Lorg/apache/logging/log4j/core/layout/PatternMatch;ZZZLorg/apache/logging/log4j/core/config/Configuration;)V - -
 method public getFormatters (Lorg/apache/logging/log4j/core/LogEvent;)[Lorg/apache/logging/log4j/core/pattern/PatternFormatter; - -
 method public,static createSelector (Ljava/lang/String;[Lorg/apache/logging/log4j/core/layout/PatternMatch;ZZZLorg/apache/logging/log4j/core/config/Configuration;)Lnet/minecrell/terminalconsole/util/LoggerNamePatternSelector; - -
in 384
class net/minecrell/terminalconsole/util/LoggerNamePatternSelector 52 public,super java/lang/Object org/apache/logging/log4j/core/layout/PatternSelector -
 inner net/minecrell/terminalconsole/util/LoggerNamePatternSelector$LoggerNameSelector net/minecrell/terminalconsole/util/LoggerNamePatternSelector LoggerNameSelector private,static
 method protected <init> (Ljava/lang/String;[Lorg/apache/logging/log4j/core/layout/PatternMatch;ZZZLorg/apache/logging/log4j/core/config/Configuration;)V - -
 method public getFormatters (Lorg/apache/logging/log4j/core/LogEvent;)[Lorg/apache/logging/log4j/core/pattern/PatternFormatter; - -
 method public,static createSelector (Ljava/lang/String;[Lorg/apache/logging/log4j/core/layout/PatternMatch;ZZZLorg/apache/logging/log4j/core/config/Configuration;)Lnet/minecrell/terminalconsole/util/LoggerNamePatternSelector; - -
in 1025
class net/minecrell/terminalconsole/util/LoggerNamePatternSelector$LoggerNameSelector 52 super java/lang/Object - -
 inner net/minecrell/terminalconsole/util/LoggerNamePatternSelector$LoggerNameSelector net/minecrell/terminalconsole/util/LoggerNamePatternSelector LoggerNameSelector private,static
