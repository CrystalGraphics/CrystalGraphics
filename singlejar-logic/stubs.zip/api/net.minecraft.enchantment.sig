cg-stub-db 1
in 90
class net/minecraft/enchantment/Enchantment 50 public,super,abstract java/lang/Object - -
 field public,static,final enchantmentsBookList [Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final protection Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final fireProtection Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final featherFalling Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final blastProtection Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final projectileProtection Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final respiration Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final aquaAffinity Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final thorns Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final depthStrider Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final sharpness Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final smite Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final baneOfArthropods Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final knockback Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final fireAspect Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final looting Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final efficiency Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final silkTouch Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final unbreaking Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final fortune Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final power Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final punch Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final flame Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final infinity Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final luckOfTheSea Lnet/minecraft/enchantment/Enchantment; -
 field public,static,final lure Lnet/minecraft/enchantment/Enchantment; -
 field public,final effectId I -
 field public type Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field protected name Ljava/lang/String; -
 method public,static getEnchantmentById (I)Lnet/minecraft/enchantment/Enchantment; - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;ILnet/minecraft/enchantment/EnumEnchantmentType;)V - -
 method public,static getEnchantmentByLocation (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment; - -
 method public,static func_181077_c ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/util/ResourceLocation;>; -
 method public getWeight ()I - -
 method public getMinLevel ()I - -
 method public getMaxLevel ()I - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public calcModifierDamage (ILnet/minecraft/util/DamageSource;)I - -
 method public calcDamageByCreature (ILnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public setName (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment; - -
 method public getName ()Ljava/lang/String; - -
 method public getTranslatedName (I)Ljava/lang/String; - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onEntityDamaged (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public onUserHurt (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public canApplyAtEnchantingTable (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static addToBookList (Lnet/minecraft/enchantment/Enchantment;)V - -
 method public isAllowedOnBooks ()Z - -
in 91
class net/minecraft/enchantment/Enchantment 50 public,super,abstract net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl - Lnet/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl<Lnet/minecraft/enchantment/Enchantment;>;
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 inner net/minecraftforge/fml/common/registry/IForgeRegistryEntry$Impl net/minecraftforge/fml/common/registry/IForgeRegistryEntry Impl public,static
 inner net/minecraft/enchantment/EnchantmentProtection$Type net/minecraft/enchantment/EnchantmentProtection Type public,static,final,enum
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespaced; Lnet/minecraft/util/registry/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/enchantment/Enchantment;>;
 field public type Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field protected name Ljava/lang/String; -
 method public,static getEnchantmentByID (I)Lnet/minecraft/enchantment/Enchantment; - -
 method public,static getEnchantmentID (Lnet/minecraft/enchantment/Enchantment;)I - -
 method public,static getEnchantmentByLocation (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment; - -
 method protected <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnumEnchantmentType;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getEntityEquipment (Lnet/minecraft/entity/EntityLivingBase;)Ljava/lang/Iterable; (Lnet/minecraft/entity/EntityLivingBase;)Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getRarity ()Lnet/minecraft/enchantment/Enchantment$Rarity; - -
 method public getMinLevel ()I - -
 method public getMaxLevel ()I - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public calcModifierDamage (ILnet/minecraft/util/DamageSource;)I - -
 method public calcDamageByCreature (ILnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public setName (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment; - -
 method public getName ()Ljava/lang/String; - -
 method public getTranslatedName (I)Ljava/lang/String; - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onEntityDamaged (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public onUserHurt (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public isTreasureEnchantment ()Z - -
 method public canApplyAtEnchantingTable (Lnet/minecraft/item/ItemStack;)Z - -
 method public isAllowedOnBooks ()Z - -
 method public,static registerEnchantments ()V - -
in 326
class net/minecraft/enchantment/Enchantment 52 public,super,abstract net/minecraftforge/registries/IForgeRegistryEntry$Impl - Lnet/minecraftforge/registries/IForgeRegistryEntry$Impl<Lnet/minecraft/enchantment/Enchantment;>;
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 inner net/minecraftforge/registries/IForgeRegistryEntry$Impl net/minecraftforge/registries/IForgeRegistryEntry Impl public,static
 inner net/minecraft/enchantment/EnchantmentProtection$Type net/minecraft/enchantment/EnchantmentProtection Type public,static,final,enum
 field public,static,final REGISTRY Lnet/minecraft/util/registry/RegistryNamespaced; Lnet/minecraft/util/registry/RegistryNamespaced<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/enchantment/Enchantment;>;
 field public type Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field protected name Ljava/lang/String; -
 method public,static getEnchantmentByID (I)Lnet/minecraft/enchantment/Enchantment; - -
 method public,static getEnchantmentID (Lnet/minecraft/enchantment/Enchantment;)I - -
 method public,static getEnchantmentByLocation (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment; - -
 method protected <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnumEnchantmentType;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getEntityEquipment (Lnet/minecraft/entity/EntityLivingBase;)Ljava/util/List; (Lnet/minecraft/entity/EntityLivingBase;)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public getRarity ()Lnet/minecraft/enchantment/Enchantment$Rarity; - -
 method public getMinLevel ()I - -
 method public getMaxLevel ()I - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public calcModifierDamage (ILnet/minecraft/util/DamageSource;)I - -
 method public calcDamageByCreature (ILnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public,final isCompatibleWith (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method protected canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public setName (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment; - -
 method public getName ()Ljava/lang/String; - -
 method public getTranslatedName (I)Ljava/lang/String; - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onEntityDamaged (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public onUserHurt (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public isTreasureEnchantment ()Z - -
 method public isCurse ()Z - -
 method public canApplyAtEnchantingTable (Lnet/minecraft/item/ItemStack;)Z - -
 method public isAllowedOnBooks ()Z - -
 method public,static registerEnchantments ()V - -
in 91
class net/minecraft/enchantment/Enchantment$Rarity 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/enchantment/Enchantment$Rarity;>;
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,static,final,enum COMMON Lnet/minecraft/enchantment/Enchantment$Rarity; -
 field public,static,final,enum UNCOMMON Lnet/minecraft/enchantment/Enchantment$Rarity; -
 field public,static,final,enum RARE Lnet/minecraft/enchantment/Enchantment$Rarity; -
 field public,static,final,enum VERY_RARE Lnet/minecraft/enchantment/Enchantment$Rarity; -
 method public,static values ()[Lnet/minecraft/enchantment/Enchantment$Rarity; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment$Rarity; - -
 method public getWeight ()I - -
in 326
class net/minecraft/enchantment/Enchantment$Rarity 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/enchantment/Enchantment$Rarity;>;
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,static,final,enum COMMON Lnet/minecraft/enchantment/Enchantment$Rarity; -
 field public,static,final,enum UNCOMMON Lnet/minecraft/enchantment/Enchantment$Rarity; -
 field public,static,final,enum RARE Lnet/minecraft/enchantment/Enchantment$Rarity; -
 field public,static,final,enum VERY_RARE Lnet/minecraft/enchantment/Enchantment$Rarity; -
 method public,static values ()[Lnet/minecraft/enchantment/Enchantment$Rarity; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/enchantment/Enchantment$Rarity; - -
 method public getWeight ()I - -
in 90
class net/minecraft/enchantment/EnchantmentArrowDamage 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentArrowDamage 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentArrowDamage 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 90
class net/minecraft/enchantment/EnchantmentArrowFire 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentArrowFire 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentArrowFire 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 90
class net/minecraft/enchantment/EnchantmentArrowInfinite 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentArrowInfinite 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentArrowInfinite 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 90
class net/minecraft/enchantment/EnchantmentArrowKnockback 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentArrowKnockback 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentArrowKnockback 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentBindingCurse 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public isTreasureEnchantment ()Z - -
 method public isCurse ()Z - -
in 90
class net/minecraft/enchantment/EnchantmentDamage 50 public,super net/minecraft/enchantment/Enchantment - -
 field public,final damageType I -
 method public <init> (ILnet/minecraft/util/ResourceLocation;II)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public calcDamageByCreature (ILnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public getName ()Ljava/lang/String; - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onEntityDamaged (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
in 91
class net/minecraft/enchantment/EnchantmentDamage 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,final damageType I -
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;I[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public calcDamageByCreature (ILnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public getName ()Ljava/lang/String; - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onEntityDamaged (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
in 326
class net/minecraft/enchantment/EnchantmentDamage 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,final damageType I -
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;I[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public calcDamageByCreature (ILnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public getName ()Ljava/lang/String; - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onEntityDamaged (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
in 90
class net/minecraft/enchantment/EnchantmentData 50 public,super net/minecraft/util/WeightedRandom$Item - -
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 field public,final enchantmentobj Lnet/minecraft/enchantment/Enchantment; -
 field public,final enchantmentLevel I -
 method public <init> (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 91
class net/minecraft/enchantment/EnchantmentData 50 public,super net/minecraft/util/WeightedRandom$Item - -
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,final enchantmentobj Lnet/minecraft/enchantment/Enchantment; -
 field public,final enchantmentLevel I -
 method public <init> (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 326
class net/minecraft/enchantment/EnchantmentData 52 public,super net/minecraft/util/WeightedRandom$Item - -
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,final enchantment Lnet/minecraft/enchantment/Enchantment; -
 field public,final enchantmentLevel I -
 method public <init> (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 90
class net/minecraft/enchantment/EnchantmentDigging 50 public,super net/minecraft/enchantment/Enchantment - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
in 91
class net/minecraft/enchantment/EnchantmentDigging 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/enchantment/EnchantmentDigging 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/enchantment/EnchantmentDurability 50 public,super net/minecraft/enchantment/Enchantment - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static negateDamage (Lnet/minecraft/item/ItemStack;ILjava/util/Random;)Z - -
in 91
class net/minecraft/enchantment/EnchantmentDurability 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static negateDamage (Lnet/minecraft/item/ItemStack;ILjava/util/Random;)Z - -
in 326
class net/minecraft/enchantment/EnchantmentDurability 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static negateDamage (Lnet/minecraft/item/ItemStack;ILjava/util/Random;)Z - -
in 90
class net/minecraft/enchantment/EnchantmentFireAspect 50 public,super net/minecraft/enchantment/Enchantment - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentFireAspect 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentFireAspect 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 90
class net/minecraft/enchantment/EnchantmentFishingSpeed 50 public,super net/minecraft/enchantment/Enchantment - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;ILnet/minecraft/enchantment/EnumEnchantmentType;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentFishingSpeed 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnumEnchantmentType;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentFishingSpeed 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnumEnchantmentType;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentFrostWalker 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public isTreasureEnchantment ()Z - -
 method public getMaxLevel ()I - -
 method public,static freezeNearby (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;I)V - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 326
class net/minecraft/enchantment/EnchantmentFrostWalker 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public isTreasureEnchantment ()Z - -
 method public getMaxLevel ()I - -
 method public,static freezeNearby (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;I)V - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 90
class net/minecraft/enchantment/EnchantmentHelper 50 public,super java/lang/Object - -
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierLiving net/minecraft/enchantment/EnchantmentHelper ModifierLiving static,final
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierDamage net/minecraft/enchantment/EnchantmentHelper ModifierDamage static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 inner net/minecraft/enchantment/EnchantmentHelper$HurtIterator net/minecraft/enchantment/EnchantmentHelper HurtIterator static,final
 inner net/minecraft/enchantment/EnchantmentHelper$DamageIterator net/minecraft/enchantment/EnchantmentHelper DamageIterator static,final
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 method public <init> ()V - -
 method public,static getEnchantmentLevel (ILnet/minecraft/item/ItemStack;)I - -
 method public,static getEnchantments (Lnet/minecraft/item/ItemStack;)Ljava/util/Map; (Lnet/minecraft/item/ItemStack;)Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>; -
 method public,static setEnchantments (Ljava/util/Map;Lnet/minecraft/item/ItemStack;)V (Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>;Lnet/minecraft/item/ItemStack;)V -
 method public,static getMaxEnchantmentLevel (I[Lnet/minecraft/item/ItemStack;)I - -
 method public,static getEnchantmentModifierDamage ([Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/DamageSource;)I - -
 method public,static getModifierForCreature (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public,static applyThornEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public,static applyArthropodEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public,static getKnockbackModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getFireAspectModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getRespiration (Lnet/minecraft/entity/Entity;)I - -
 method public,static getDepthStriderModifier (Lnet/minecraft/entity/Entity;)I - -
 method public,static getEfficiencyModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getSilkTouchModifier (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public,static getFortuneModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getLuckOfSeaModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getLureModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getLootingModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getAquaAffinityModifier (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public,static getEnchantedItem (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public,static calcItemStackEnchantability (Ljava/util/Random;IILnet/minecraft/item/ItemStack;)I - -
 method public,static addRandomEnchantment (Ljava/util/Random;Lnet/minecraft/item/ItemStack;I)Lnet/minecraft/item/ItemStack; - -
 method public,static buildEnchantmentList (Ljava/util/Random;Lnet/minecraft/item/ItemStack;I)Ljava/util/List; (Ljava/util/Random;Lnet/minecraft/item/ItemStack;I)Ljava/util/List<Lnet/minecraft/enchantment/EnchantmentData;>; -
 method public,static mapEnchantmentData (ILnet/minecraft/item/ItemStack;)Ljava/util/Map; (ILnet/minecraft/item/ItemStack;)Ljava/util/Map<Ljava/lang/Integer;Lnet/minecraft/enchantment/EnchantmentData;>; -
in 91
class net/minecraft/enchantment/EnchantmentHelper 50 public,super java/lang/Object - -
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierLiving net/minecraft/enchantment/EnchantmentHelper ModifierLiving static,final
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierDamage net/minecraft/enchantment/EnchantmentHelper ModifierDamage static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 inner net/minecraft/enchantment/EnchantmentHelper$HurtIterator net/minecraft/enchantment/EnchantmentHelper HurtIterator static,final
 inner net/minecraft/enchantment/EnchantmentHelper$DamageIterator net/minecraft/enchantment/EnchantmentHelper DamageIterator static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 method public <init> ()V - -
 method public,static getEnchantmentLevel (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/item/ItemStack;)I - -
 method public,static getEnchantments (Lnet/minecraft/item/ItemStack;)Ljava/util/Map; (Lnet/minecraft/item/ItemStack;)Ljava/util/Map<Lnet/minecraft/enchantment/Enchantment;Ljava/lang/Integer;>; -
 method public,static setEnchantments (Ljava/util/Map;Lnet/minecraft/item/ItemStack;)V (Ljava/util/Map<Lnet/minecraft/enchantment/Enchantment;Ljava/lang/Integer;>;Lnet/minecraft/item/ItemStack;)V -
 method public,static getEnchantmentModifierDamage (Ljava/lang/Iterable;Lnet/minecraft/util/DamageSource;)I (Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>;Lnet/minecraft/util/DamageSource;)I -
 method public,static getModifierForCreature (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public,static applyThornEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public,static applyArthropodEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public,static getMaxEnchantmentLevel (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getKnockbackModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getFireAspectModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getRespirationModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getDepthStriderModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getEfficiencyModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getLuckOfSeaModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getLureModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getLootingModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getAquaAffinityModifier (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public,static hasFrostWalkerEnchantment (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public,static getEnchantedItem (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public,static calcItemStackEnchantability (Ljava/util/Random;IILnet/minecraft/item/ItemStack;)I - -
 method public,static addRandomEnchantment (Ljava/util/Random;Lnet/minecraft/item/ItemStack;IZ)Lnet/minecraft/item/ItemStack; - -
 method public,static buildEnchantmentList (Ljava/util/Random;Lnet/minecraft/item/ItemStack;IZ)Ljava/util/List; (Ljava/util/Random;Lnet/minecraft/item/ItemStack;IZ)Ljava/util/List<Lnet/minecraft/enchantment/EnchantmentData;>; -
 method public,static removeIncompatible (Ljava/util/List;Lnet/minecraft/enchantment/EnchantmentData;)V (Ljava/util/List<Lnet/minecraft/enchantment/EnchantmentData;>;Lnet/minecraft/enchantment/EnchantmentData;)V -
 method public,static getEnchantmentDatas (ILnet/minecraft/item/ItemStack;Z)Ljava/util/List; (ILnet/minecraft/item/ItemStack;Z)Ljava/util/List<Lnet/minecraft/enchantment/EnchantmentData;>; -
in 326
class net/minecraft/enchantment/EnchantmentHelper 52 public,super java/lang/Object - -
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierLiving net/minecraft/enchantment/EnchantmentHelper ModifierLiving static,final
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierDamage net/minecraft/enchantment/EnchantmentHelper ModifierDamage static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 inner net/minecraft/enchantment/EnchantmentHelper$HurtIterator net/minecraft/enchantment/EnchantmentHelper HurtIterator static,final
 inner net/minecraft/enchantment/EnchantmentHelper$DamageIterator net/minecraft/enchantment/EnchantmentHelper DamageIterator static,final
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 method public <init> ()V - -
 method public,static getEnchantmentLevel (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/item/ItemStack;)I - -
 method public,static getEnchantments (Lnet/minecraft/item/ItemStack;)Ljava/util/Map; (Lnet/minecraft/item/ItemStack;)Ljava/util/Map<Lnet/minecraft/enchantment/Enchantment;Ljava/lang/Integer;>; -
 method public,static setEnchantments (Ljava/util/Map;Lnet/minecraft/item/ItemStack;)V (Ljava/util/Map<Lnet/minecraft/enchantment/Enchantment;Ljava/lang/Integer;>;Lnet/minecraft/item/ItemStack;)V -
 method public,static getEnchantmentModifierDamage (Ljava/lang/Iterable;Lnet/minecraft/util/DamageSource;)I (Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>;Lnet/minecraft/util/DamageSource;)I -
 method public,static getModifierForCreature (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EnumCreatureAttribute;)F - -
 method public,static getSweepingDamageRatio (Lnet/minecraft/entity/EntityLivingBase;)F - -
 method public,static applyThornEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public,static applyArthropodEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public,static getMaxEnchantmentLevel (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getKnockbackModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getFireAspectModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getRespirationModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getDepthStriderModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getEfficiencyModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getFishingLuckBonus (Lnet/minecraft/item/ItemStack;)I - -
 method public,static getFishingSpeedBonus (Lnet/minecraft/item/ItemStack;)I - -
 method public,static getLootingModifier (Lnet/minecraft/entity/EntityLivingBase;)I - -
 method public,static getAquaAffinityModifier (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public,static hasFrostWalkerEnchantment (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public,static hasBindingCurse (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static hasVanishingCurse (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static getEnchantedItem (Lnet/minecraft/enchantment/Enchantment;Lnet/minecraft/entity/EntityLivingBase;)Lnet/minecraft/item/ItemStack; - -
 method public,static calcItemStackEnchantability (Ljava/util/Random;IILnet/minecraft/item/ItemStack;)I - -
 method public,static addRandomEnchantment (Ljava/util/Random;Lnet/minecraft/item/ItemStack;IZ)Lnet/minecraft/item/ItemStack; - -
 method public,static buildEnchantmentList (Ljava/util/Random;Lnet/minecraft/item/ItemStack;IZ)Ljava/util/List; (Ljava/util/Random;Lnet/minecraft/item/ItemStack;IZ)Ljava/util/List<Lnet/minecraft/enchantment/EnchantmentData;>; -
 method public,static removeIncompatible (Ljava/util/List;Lnet/minecraft/enchantment/EnchantmentData;)V (Ljava/util/List<Lnet/minecraft/enchantment/EnchantmentData;>;Lnet/minecraft/enchantment/EnchantmentData;)V -
 method public,static getEnchantmentDatas (ILnet/minecraft/item/ItemStack;Z)Ljava/util/List; (ILnet/minecraft/item/ItemStack;Z)Ljava/util/List<Lnet/minecraft/enchantment/EnchantmentData;>; -
in 24
class net/minecraft/enchantment/EnchantmentHelper$DamageIterator 50 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$DamageIterator net/minecraft/enchantment/EnchantmentHelper DamageIterator static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public user Lnet/minecraft/entity/EntityLivingBase; -
 field public target Lnet/minecraft/entity/Entity; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 326
class net/minecraft/enchantment/EnchantmentHelper$DamageIterator 52 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$DamageIterator net/minecraft/enchantment/EnchantmentHelper DamageIterator static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public user Lnet/minecraft/entity/EntityLivingBase; -
 field public target Lnet/minecraft/entity/Entity; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 24
class net/minecraft/enchantment/EnchantmentHelper$HurtIterator 50 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$HurtIterator net/minecraft/enchantment/EnchantmentHelper HurtIterator static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public user Lnet/minecraft/entity/EntityLivingBase; -
 field public attacker Lnet/minecraft/entity/Entity; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 326
class net/minecraft/enchantment/EnchantmentHelper$HurtIterator 52 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$HurtIterator net/minecraft/enchantment/EnchantmentHelper HurtIterator static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public user Lnet/minecraft/entity/EntityLivingBase; -
 field public attacker Lnet/minecraft/entity/Entity; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 24
class net/minecraft/enchantment/EnchantmentHelper$IModifier 50 interface,abstract java/lang/Object - -
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 method public,abstract calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 326
class net/minecraft/enchantment/EnchantmentHelper$IModifier 52 interface,abstract java/lang/Object - -
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 method public,abstract calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 24
class net/minecraft/enchantment/EnchantmentHelper$ModifierDamage 50 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierDamage net/minecraft/enchantment/EnchantmentHelper ModifierDamage static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public damageModifier I -
 field public source Lnet/minecraft/util/DamageSource; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 326
class net/minecraft/enchantment/EnchantmentHelper$ModifierDamage 52 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierDamage net/minecraft/enchantment/EnchantmentHelper ModifierDamage static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public damageModifier I -
 field public source Lnet/minecraft/util/DamageSource; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 24
class net/minecraft/enchantment/EnchantmentHelper$ModifierLiving 50 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierLiving net/minecraft/enchantment/EnchantmentHelper ModifierLiving static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public livingModifier F -
 field public entityLiving Lnet/minecraft/entity/EnumCreatureAttribute; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 326
class net/minecraft/enchantment/EnchantmentHelper$ModifierLiving 52 final,super java/lang/Object net/minecraft/enchantment/EnchantmentHelper$IModifier -
 inner net/minecraft/enchantment/EnchantmentHelper$ModifierLiving net/minecraft/enchantment/EnchantmentHelper ModifierLiving static,final
 inner net/minecraft/enchantment/EnchantmentHelper$IModifier net/minecraft/enchantment/EnchantmentHelper IModifier static,interface,abstract
 field public livingModifier F -
 field public entityLiving Lnet/minecraft/entity/EnumCreatureAttribute; -
 method public calculateModifier (Lnet/minecraft/enchantment/Enchantment;I)V - -
in 90
class net/minecraft/enchantment/EnchantmentKnockback 50 public,super net/minecraft/enchantment/Enchantment - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentKnockback 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentKnockback 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 90
class net/minecraft/enchantment/EnchantmentLootBonus 50 public,super net/minecraft/enchantment/Enchantment - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;ILnet/minecraft/enchantment/EnumEnchantmentType;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 91
class net/minecraft/enchantment/EnchantmentLootBonus 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnumEnchantmentType;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 326
class net/minecraft/enchantment/EnchantmentLootBonus 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnumEnchantmentType;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 91
class net/minecraft/enchantment/EnchantmentMending 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public isTreasureEnchantment ()Z - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentMending 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public isTreasureEnchantment ()Z - -
 method public getMaxLevel ()I - -
in 90
class net/minecraft/enchantment/EnchantmentOxygen 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentOxygen 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentOxygen 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 90
class net/minecraft/enchantment/EnchantmentProtection 50 public,super net/minecraft/enchantment/Enchantment - -
 field public,final protectionType I -
 method public <init> (ILnet/minecraft/util/ResourceLocation;II)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public calcModifierDamage (ILnet/minecraft/util/DamageSource;)I - -
 method public getName ()Ljava/lang/String; - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public,static getFireTimeForEntity (Lnet/minecraft/entity/Entity;I)I - -
 method public,static func_92092_a (Lnet/minecraft/entity/Entity;D)D - -
in 91
class net/minecraft/enchantment/EnchantmentProtection 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/EnchantmentProtection$Type net/minecraft/enchantment/EnchantmentProtection Type public,static,final,enum
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,final protectionType Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnchantmentProtection$Type;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public calcModifierDamage (ILnet/minecraft/util/DamageSource;)I - -
 method public getName ()Ljava/lang/String; - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public,static getFireTimeForEntity (Lnet/minecraft/entity/EntityLivingBase;I)I - -
 method public,static getBlastDamageReduction (Lnet/minecraft/entity/EntityLivingBase;D)D - -
in 326
class net/minecraft/enchantment/EnchantmentProtection 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/EnchantmentProtection$Type net/minecraft/enchantment/EnchantmentProtection Type public,static,final,enum
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public,final protectionType Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;Lnet/minecraft/enchantment/EnchantmentProtection$Type;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public calcModifierDamage (ILnet/minecraft/util/DamageSource;)I - -
 method public getName ()Ljava/lang/String; - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public,static getFireTimeForEntity (Lnet/minecraft/entity/EntityLivingBase;I)I - -
 method public,static getBlastDamageReduction (Lnet/minecraft/entity/EntityLivingBase;D)D - -
in 91
class net/minecraft/enchantment/EnchantmentProtection$Type 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/enchantment/EnchantmentProtection$Type;>;
 inner net/minecraft/enchantment/EnchantmentProtection$Type net/minecraft/enchantment/EnchantmentProtection Type public,static,final,enum
 field public,static,final,enum ALL Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum FIRE Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum FALL Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum EXPLOSION Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum PROJECTILE Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 method public,static values ()[Lnet/minecraft/enchantment/EnchantmentProtection$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/enchantment/EnchantmentProtection$Type; - -
 method public getTypeName ()Ljava/lang/String; - -
 method public getMinimalEnchantability ()I - -
 method public getEnchantIncreasePerLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentProtection$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/enchantment/EnchantmentProtection$Type;>;
 inner net/minecraft/enchantment/EnchantmentProtection$Type net/minecraft/enchantment/EnchantmentProtection Type public,static,final,enum
 field public,static,final,enum ALL Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum FIRE Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum FALL Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum EXPLOSION Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 field public,static,final,enum PROJECTILE Lnet/minecraft/enchantment/EnchantmentProtection$Type; -
 method public,static values ()[Lnet/minecraft/enchantment/EnchantmentProtection$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/enchantment/EnchantmentProtection$Type; - -
 method public getTypeName ()Ljava/lang/String; - -
 method public getMinimalEnchantability ()I - -
 method public getEnchantIncreasePerLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentSweepingEdge 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public,static getSweepingDamageRatio (I)F - -
 method public getName ()Ljava/lang/String; - -
in 90
class net/minecraft/enchantment/EnchantmentThorns 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onUserHurt (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public,static func_92094_a (ILjava/util/Random;)Z - -
 method public,static func_92095_b (ILjava/util/Random;)I - -
in 91
class net/minecraft/enchantment/EnchantmentThorns 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onUserHurt (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public,static shouldHit (ILjava/util/Random;)Z - -
 method public,static getDamage (ILjava/util/Random;)I - -
in 326
class net/minecraft/enchantment/EnchantmentThorns 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
 method public onUserHurt (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;I)V - -
 method public,static shouldHit (ILjava/util/Random;)Z - -
 method public,static getDamage (ILjava/util/Random;)I - -
in 90
class net/minecraft/enchantment/EnchantmentUntouching 50 public,super net/minecraft/enchantment/Enchantment - -
 method protected <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
 method public canApply (Lnet/minecraft/item/ItemStack;)Z - -
in 91
class net/minecraft/enchantment/EnchantmentUntouching 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 326
class net/minecraft/enchantment/EnchantmentUntouching 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method protected,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 326
class net/minecraft/enchantment/EnchantmentVanishingCurse 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public isTreasureEnchantment ()Z - -
 method public isCurse ()Z - -
in 90
class net/minecraft/enchantment/EnchantmentWaterWalker 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentWaterWalker 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 326
class net/minecraft/enchantment/EnchantmentWaterWalker 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
 method public canApplyTogether (Lnet/minecraft/enchantment/Enchantment;)Z - -
in 90
class net/minecraft/enchantment/EnchantmentWaterWorker 50 public,super net/minecraft/enchantment/Enchantment - -
 method public <init> (ILnet/minecraft/util/ResourceLocation;I)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 91
class net/minecraft/enchantment/EnchantmentWaterWorker 50 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 326
class net/minecraft/enchantment/EnchantmentWaterWorker 52 public,super net/minecraft/enchantment/Enchantment - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/enchantment/Enchantment$Rarity;[Lnet/minecraft/inventory/EntityEquipmentSlot;)V - -
 method public getMinEnchantability (I)I - -
 method public getMaxEnchantability (I)I - -
 method public getMaxLevel ()I - -
in 90
class net/minecraft/enchantment/EnumEnchantmentType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/enchantment/EnumEnchantmentType;>;
 field public,static,final,enum ALL Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_FEET Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_LEGS Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_TORSO Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_HEAD Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum WEAPON Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum DIGGER Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum FISHING_ROD Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum BREAKABLE Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum BOW Lnet/minecraft/enchantment/EnumEnchantmentType; -
 method public,static values ()[Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public canEnchantItem (Lnet/minecraft/item/Item;)Z - -
in 91
class net/minecraft/enchantment/EnumEnchantmentType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/enchantment/EnumEnchantmentType;>;
 field public,static,final,enum ALL Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_FEET Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_LEGS Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_CHEST Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_HEAD Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum WEAPON Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum DIGGER Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum FISHING_ROD Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum BREAKABLE Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum BOW Lnet/minecraft/enchantment/EnumEnchantmentType; -
 method public,static values ()[Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public canEnchantItem (Lnet/minecraft/item/Item;)Z - -
in 326
class net/minecraft/enchantment/EnumEnchantmentType 52 public,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/enchantment/EnumEnchantmentType;>;
 field public,static,final,enum ALL Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_FEET Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_LEGS Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_CHEST Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum ARMOR_HEAD Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum WEAPON Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum DIGGER Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum FISHING_ROD Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum BREAKABLE Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum BOW Lnet/minecraft/enchantment/EnumEnchantmentType; -
 field public,static,final,enum WEARABLE Lnet/minecraft/enchantment/EnumEnchantmentType; -
 method public,static values ()[Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/enchantment/EnumEnchantmentType; - -
 method public canEnchantItem (Lnet/minecraft/item/Item;)Z - -
