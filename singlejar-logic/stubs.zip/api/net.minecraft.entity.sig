cg-stub-db 1
in 90
class net/minecraft/entity/DataWatcher 50 public,super java/lang/Object - -
 inner net/minecraft/entity/DataWatcher$WatchableObject net/minecraft/entity/DataWatcher WatchableObject public,static
 method public updateWatchedObjectsFromList (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/DataWatcher$WatchableObject;>;)V -
 method public <init> (Lnet/minecraft/entity/Entity;)V - -
 method public addObject (ILjava/lang/Object;)V <T:Ljava/lang/Object;>(ITT;)V -
 method public addObjectByDataType (II)V - -
 method public getWatchableObjectByte (I)B - -
 method public getWatchableObjectShort (I)S - -
 method public getWatchableObjectInt (I)I - -
 method public getWatchableObjectFloat (I)F - -
 method public getWatchableObjectString (I)Ljava/lang/String; - -
 method public getWatchableObjectItemStack (I)Lnet/minecraft/item/ItemStack; - -
 method public getWatchableObjectRotations (I)Lnet/minecraft/util/Rotations; - -
 method public updateObject (ILjava/lang/Object;)V <T:Ljava/lang/Object;>(ITT;)V -
 method public setObjectWatched (I)V - -
 method public hasObjectChanged ()Z - -
 method public,static writeWatchedListToPacketBuffer (Ljava/util/List;Lnet/minecraft/network/PacketBuffer;)V (Ljava/util/List<Lnet/minecraft/entity/DataWatcher$WatchableObject;>;Lnet/minecraft/network/PacketBuffer;)V java/io/IOException
 method public getChanged ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/entity/DataWatcher$WatchableObject;>; -
 method public writeTo (Lnet/minecraft/network/PacketBuffer;)V - java/io/IOException
 method public getAllWatched ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/entity/DataWatcher$WatchableObject;>; -
 method public,static readWatchedListFromPacketBuffer (Lnet/minecraft/network/PacketBuffer;)Ljava/util/List; (Lnet/minecraft/network/PacketBuffer;)Ljava/util/List<Lnet/minecraft/entity/DataWatcher$WatchableObject;>; java/io/IOException
 method public getIsBlank ()Z - -
 method public func_111144_e ()V - -
in 90
class net/minecraft/entity/DataWatcher$WatchableObject 50 public,super java/lang/Object - -
 inner net/minecraft/entity/DataWatcher$WatchableObject net/minecraft/entity/DataWatcher WatchableObject public,static
 method public <init> (IILjava/lang/Object;)V - -
 method public getDataValueId ()I - -
 method public setObject (Ljava/lang/Object;)V - -
 method public getObject ()Ljava/lang/Object; - -
 method public getObjectType ()I - -
 method public isWatched ()Z - -
 method public setWatched (Z)V - -
in 90
class net/minecraft/entity/Entity 50 public,super,abstract java/lang/Object net/minecraft/command/ICommandSender,net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraft/command/ICommandSender;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 inner net/minecraft/util/BlockPos$MutableBlockPos net/minecraft/util/BlockPos MutableBlockPos public,static,final
 inner net/minecraft/block/state/pattern/BlockPattern$PatternHelper net/minecraft/block/state/pattern/BlockPattern PatternHelper public,static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraftforge/event/entity/EntityEvent$EntityConstructing net/minecraftforge/event/entity/EntityEvent EntityConstructing public,static
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 inner net/minecraft/util/EnumFacing$AxisDirection net/minecraft/util/EnumFacing AxisDirection public,static,final,enum
 inner net/minecraft/event/HoverEvent$Action net/minecraft/event/HoverEvent Action public,static,final,enum
 field public renderDistanceWeight D -
 field public preventEntitySpawning Z -
 field public riddenByEntity Lnet/minecraft/entity/Entity; -
 field public ridingEntity Lnet/minecraft/entity/Entity; -
 field public forceSpawn Z -
 field public worldObj Lnet/minecraft/world/World; -
 field public prevPosX D -
 field public prevPosY D -
 field public prevPosZ D -
 field public posX D -
 field public posY D -
 field public posZ D -
 field public motionX D -
 field public motionY D -
 field public motionZ D -
 field public rotationYaw F -
 field public rotationPitch F -
 field public prevRotationYaw F -
 field public prevRotationPitch F -
 field public onGround Z -
 field public isCollidedHorizontally Z -
 field public isCollidedVertically Z -
 field public isCollided Z -
 field public velocityChanged Z -
 field protected isInWeb Z -
 field public isDead Z -
 field public width F -
 field public height F -
 field public prevDistanceWalkedModified F -
 field public distanceWalkedModified F -
 field public distanceWalkedOnStepModified F -
 field public fallDistance F -
 field public lastTickPosX D -
 field public lastTickPosY D -
 field public lastTickPosZ D -
 field public stepHeight F -
 field public noClip Z -
 field public entityCollisionReduction F -
 field protected rand Ljava/util/Random; -
 field public ticksExisted I -
 field public fireResistance I -
 field protected inWater Z -
 field public hurtResistantTime I -
 field protected firstUpdate Z -
 field protected isImmuneToFire Z -
 field protected dataWatcher Lnet/minecraft/entity/DataWatcher; -
 field public addedToChunk Z -
 field public chunkCoordX I -
 field public chunkCoordY I -
 field public chunkCoordZ I -
 field public serverPosX I -
 field public serverPosY I -
 field public serverPosZ I -
 field public ignoreFrustumCheck Z -
 field public isAirBorne Z -
 field public timeUntilPortal I -
 field protected inPortal Z -
 field protected portalCounter I -
 field public dimension I -
 field protected lastPortalPos Lnet/minecraft/util/BlockPos; -
 field protected lastPortalVec Lnet/minecraft/util/Vec3; -
 field protected teleportDirection Lnet/minecraft/util/EnumFacing; -
 field protected entityUniqueID Ljava/util/UUID; -
 field public captureDrops Z -
 field public capturedDrops Ljava/util/ArrayList; Ljava/util/ArrayList<Lnet/minecraft/entity/item/EntityItem;>;
 field protected,deprecated extendedProperties Ljava/util/HashMap; Ljava/util/HashMap<Ljava/lang/String;Lnet/minecraftforge/common/IExtendedEntityProperties;>;
 method public getEntityId ()I - -
 method public setEntityId (I)V - -
 method public onKillCommand ()V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected,abstract entityInit ()V - -
 method public getDataWatcher ()Lnet/minecraft/entity/DataWatcher; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method protected preparePlayerToSpawn ()V - -
 method public setDead ()V - -
 method protected setSize (FF)V - -
 method protected setRotation (FF)V - -
 method public setPosition (DDD)V - -
 method public setAngles (FF)V - -
 method public onUpdate ()V - -
 method public onEntityUpdate ()V - -
 method public getMaxInPortalTime ()I - -
 method protected setOnFireFromLava ()V - -
 method public setFire (I)V - -
 method public extinguish ()V - -
 method protected kill ()V - -
 method public isOffsetPositionInLiquid (DDD)Z - -
 method public moveEntity (DDD)V - -
 method protected getSwimSound ()Ljava/lang/String; - -
 method protected doBlockCollisions ()V - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public playSound (Ljava/lang/String;FF)V - -
 method public isSilent ()Z - -
 method public setSilent (Z)V - -
 method protected canTriggerWalking ()Z - -
 method protected updateFallState (DZLnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;)V - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/AxisAlignedBB; - -
 method protected dealFireDamage (I)V - -
 method public,final isImmuneToFire ()Z - -
 method public fall (FF)V - -
 method public isWet ()Z - -
 method public isInWater ()Z - -
 method public handleWaterMovement ()Z - -
 method protected resetHeight ()V - -
 method public spawnRunningParticles ()V - -
 method protected createRunningParticles ()V - -
 method protected getSplashSound ()Ljava/lang/String; - -
 method public isInsideOfMaterial (Lnet/minecraft/block/material/Material;)Z - -
 method public isInLava ()Z - -
 method public moveFlying (FFF)V - -
 method public getBrightnessForRender (F)I - -
 method public getBrightness (F)F - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public setPositionAndRotation (DDDFF)V - -
 method public moveToBlockPosAndAngles (Lnet/minecraft/util/BlockPos;FF)V - -
 method public setLocationAndAngles (DDDFF)V - -
 method public getDistanceToEntity (Lnet/minecraft/entity/Entity;)F - -
 method public getDistanceSq (DDD)D - -
 method public getDistanceSq (Lnet/minecraft/util/BlockPos;)D - -
 method public getDistanceSqToCenter (Lnet/minecraft/util/BlockPos;)D - -
 method public getDistance (DDD)D - -
 method public getDistanceSqToEntity (Lnet/minecraft/entity/Entity;)D - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public addVelocity (DDD)V - -
 method protected setBeenAttacked ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getLook (F)Lnet/minecraft/util/Vec3; - -
 method protected,final getVectorForRotation (FF)Lnet/minecraft/util/Vec3; - -
 method public getPositionEyes (F)Lnet/minecraft/util/Vec3; - -
 method public rayTrace (DF)Lnet/minecraft/util/MovingObjectPosition; - -
 method public canBeCollidedWith ()Z - -
 method public canBePushed ()Z - -
 method public addToPlayerScore (Lnet/minecraft/entity/Entity;I)V - -
 method public isInRangeToRender3d (DDD)Z - -
 method public isInRangeToRenderDist (D)Z - -
 method public writeMountToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeToNBTOptional (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected shouldSetPosAfterLoading ()Z - -
 method protected,final getEntityString ()Ljava/lang/String; - -
 method protected,abstract readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected,abstract writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onChunkLoad ()V - -
 method protected,varargs newDoubleNBTList ([D)Lnet/minecraft/nbt/NBTTagList; - -
 method protected,varargs newFloatNBTList ([F)Lnet/minecraft/nbt/NBTTagList; - -
 method public dropItem (Lnet/minecraft/item/Item;I)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItemWithOffset (Lnet/minecraft/item/Item;IF)Lnet/minecraft/entity/item/EntityItem; - -
 method public entityDropItem (Lnet/minecraft/item/ItemStack;F)Lnet/minecraft/entity/item/EntityItem; - -
 method public isEntityAlive ()Z - -
 method public isEntityInsideOpaqueBlock ()Z - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/AxisAlignedBB; - -
 method public updateRidden ()V - -
 method public updateRiderPosition ()V - -
 method public getYOffset ()D - -
 method public getMountedYOffset ()D - -
 method public mountEntity (Lnet/minecraft/entity/Entity;)V - -
 method public setPositionAndRotation2 (DDDFFIZ)V - -
 method public getCollisionBorderSize ()F - -
 method public getLookVec ()Lnet/minecraft/util/Vec3; - -
 method public setPortal (Lnet/minecraft/util/BlockPos;)V - -
 method public getPortalCooldown ()I - -
 method public setVelocity (DDD)V - -
 method public handleStatusUpdate (B)V - -
 method public performHurtAnimation ()V - -
 method public getInventory ()[Lnet/minecraft/item/ItemStack; - -
 method public setCurrentItemOrArmor (ILnet/minecraft/item/ItemStack;)V - -
 method public isBurning ()Z - -
 method public isRiding ()Z - -
 method public isSneaking ()Z - -
 method public setSneaking (Z)V - -
 method public isSprinting ()Z - -
 method public setSprinting (Z)V - -
 method public isInvisible ()Z - -
 method public isInvisibleToPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public setInvisible (Z)V - -
 method public isEating ()Z - -
 method public setEating (Z)V - -
 method protected getFlag (I)Z - -
 method protected setFlag (IZ)V - -
 method public getAir ()I - -
 method public setAir (I)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected pushOutOfBlocks (DDD)Z - -
 method public setInWeb ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getParts ()[Lnet/minecraft/entity/Entity; - -
 method public isEntityEqual (Lnet/minecraft/entity/Entity;)Z - -
 method public getRotationYawHead ()F - -
 method public setRotationYawHead (F)V - -
 method public setRenderYawOffset (F)V - -
 method public canAttackWithItem ()Z - -
 method public hitByEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public isEntityInvulnerable (Lnet/minecraft/util/DamageSource;)Z - -
 method public copyLocationAndAnglesFrom (Lnet/minecraft/entity/Entity;)V - -
 method public copyDataFromOld (Lnet/minecraft/entity/Entity;)V - -
 method public travelToDimension (I)V - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method public verifyExplosion (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;F)Z - -
 method public getMaxFallHeight ()I - -
 method public func_181014_aG ()Lnet/minecraft/util/Vec3; - -
 method public getTeleportDirection ()Lnet/minecraft/util/EnumFacing; - -
 method public doesEntityNotTriggerPressurePlate ()Z - -
 method public addEntityCrashInfo (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public canRenderOnFire ()Z - -
 method public getUniqueID ()Ljava/util/UUID; - -
 method public isPushedByWater ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public setCustomNameTag (Ljava/lang/String;)V - -
 method public getCustomNameTag ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setAlwaysRenderNameTag (Z)V - -
 method public getAlwaysRenderNameTag ()Z - -
 method public setPositionAndUpdate (DDD)V - -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method public onDataWatcherUpdate (I)V - -
 method public getHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method protected getHoverEvent ()Lnet/minecraft/event/HoverEvent; - -
 method public isSpectatedByPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public getEntityBoundingBox ()Lnet/minecraft/util/AxisAlignedBB; - -
 method public setEntityBoundingBox (Lnet/minecraft/util/AxisAlignedBB;)V - -
 method public getEyeHeight ()F - -
 method public isOutsideBorder ()Z - -
 method public setOutsideBorder (Z)V - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public addChatMessage (Lnet/minecraft/util/IChatComponent;)V - -
 method public canCommandSenderUseCommand (ILjava/lang/String;)Z - -
 method public getPosition ()Lnet/minecraft/util/BlockPos; - -
 method public getPositionVector ()Lnet/minecraft/util/Vec3; - -
 method public getEntityWorld ()Lnet/minecraft/world/World; - -
 method public getCommandSenderEntity ()Lnet/minecraft/entity/Entity; - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public getCommandStats ()Lnet/minecraft/command/CommandResultStats; - -
 method public setCommandStats (Lnet/minecraft/entity/Entity;)V - -
 method public getNBTTagCompound ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public clientUpdateEntityNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public interactAt (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/Vec3;)Z - -
 method public isImmuneToExplosions ()Z - -
 method protected applyEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public getEntityData ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public shouldRiderSit ()Z - -
 method public getPickedResult (Lnet/minecraft/util/MovingObjectPosition;)Lnet/minecraft/item/ItemStack; - -
 method public getPersistentID ()Ljava/util/UUID; - -
 method public,final resetEntityId ()V - -
 method public shouldRenderInPass (I)Z - -
 method public isCreatureType (Lnet/minecraft/entity/EnumCreatureType;Z)Z - -
 method public registerExtendedProperties (Ljava/lang/String;Lnet/minecraftforge/common/IExtendedEntityProperties;)Ljava/lang/String; - -
 method public getExtendedProperties (Ljava/lang/String;)Lnet/minecraftforge/common/IExtendedEntityProperties; - -
 method public canRiderInteract ()Z - -
 method public shouldDismountInWater (Lnet/minecraft/entity/Entity;)Z - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 91
class net/minecraft/entity/Entity 50 public,super,abstract java/lang/Object net/minecraft/command/ICommandSender,net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraft/command/ICommandSender;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/block/state/pattern/BlockPattern$PatternHelper net/minecraft/block/state/pattern/BlockPattern PatternHelper public,static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraftforge/event/entity/EntityEvent$EntityConstructing net/minecraftforge/event/entity/EntityEvent EntityConstructing public,static
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 inner net/minecraft/util/EnumFacing$AxisDirection net/minecraft/util/EnumFacing AxisDirection public,static,final,enum
 inner net/minecraft/util/text/event/HoverEvent$Action net/minecraft/util/text/event/HoverEvent Action public,static,final,enum
 field public preventEntitySpawning Z -
 field protected rideCooldown I -
 field public forceSpawn Z -
 field public world Lnet/minecraft/world/World; -
 field public prevPosX D -
 field public prevPosY D -
 field public prevPosZ D -
 field public posX D -
 field public posY D -
 field public posZ D -
 field public motionX D -
 field public motionY D -
 field public motionZ D -
 field public rotationYaw F -
 field public rotationPitch F -
 field public prevRotationYaw F -
 field public prevRotationPitch F -
 field public onGround Z -
 field public isCollidedHorizontally Z -
 field public isCollidedVertically Z -
 field public isCollided Z -
 field public velocityChanged Z -
 field protected isInWeb Z -
 field public isDead Z -
 field public width F -
 field public height F -
 field public prevDistanceWalkedModified F -
 field public distanceWalkedModified F -
 field public distanceWalkedOnStepModified F -
 field public fallDistance F -
 field public lastTickPosX D -
 field public lastTickPosY D -
 field public lastTickPosZ D -
 field public stepHeight F -
 field public noClip Z -
 field public entityCollisionReduction F -
 field protected rand Ljava/util/Random; -
 field public ticksExisted I -
 field public fireResistance I -
 field protected inWater Z -
 field public hurtResistantTime I -
 field protected firstUpdate Z -
 field protected isImmuneToFire Z -
 field protected dataManager Lnet/minecraft/network/datasync/EntityDataManager; -
 field protected,static,final FLAGS Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public addedToChunk Z -
 field public chunkCoordX I -
 field public chunkCoordY I -
 field public chunkCoordZ I -
 field public serverPosX J -
 field public serverPosY J -
 field public serverPosZ J -
 field public ignoreFrustumCheck Z -
 field public isAirBorne Z -
 field public timeUntilPortal I -
 field protected inPortal Z -
 field protected portalCounter I -
 field public dimension I -
 field protected lastPortalPos Lnet/minecraft/util/math/BlockPos; -
 field protected lastPortalVec Lnet/minecraft/util/math/Vec3d; -
 field protected teleportDirection Lnet/minecraft/util/EnumFacing; -
 field protected entityUniqueID Ljava/util/UUID; -
 field protected cachedUniqueIdString Ljava/lang/String; -
 field protected glowing Z -
 field public captureDrops Z -
 field public capturedDrops Ljava/util/ArrayList; Ljava/util/ArrayList<Lnet/minecraft/entity/item/EntityItem;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getEntityId ()I - -
 method public setEntityId (I)V - -
 method public getTags ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public addTag (Ljava/lang/String;)Z - -
 method public removeTag (Ljava/lang/String;)Z - -
 method public onKillCommand ()V - -
 method protected,abstract entityInit ()V - -
 method public getDataManager ()Lnet/minecraft/network/datasync/EntityDataManager; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method protected preparePlayerToSpawn ()V - -
 method public setDead ()V - -
 method public setDropItemsWhenDead (Z)V - -
 method protected setSize (FF)V - -
 method protected setRotation (FF)V - -
 method public setPosition (DDD)V - -
 method public turn (FF)V - -
 method public onUpdate ()V - -
 method public onEntityUpdate ()V - -
 method protected decrementTimeUntilPortal ()V - -
 method public getMaxInPortalTime ()I - -
 method protected setOnFireFromLava ()V - -
 method public setFire (I)V - -
 method public extinguish ()V - -
 method protected kill ()V - -
 method public isOffsetPositionInLiquid (DDD)Z - -
 method public move (DDD)V - -
 method public resetPositionToBB ()V - -
 method protected getSwimSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSplashSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected doBlockCollisions ()V - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public playSound (Lnet/minecraft/util/SoundEvent;FF)V - -
 method public isSilent ()Z - -
 method public setSilent (Z)V - -
 method public hasNoGravity ()Z - -
 method public setNoGravity (Z)V - -
 method protected canTriggerWalking ()Z - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method protected dealFireDamage (I)V - -
 method public,final isImmuneToFire ()Z - -
 method public fall (FF)V - -
 method public isWet ()Z - -
 method public isInWater ()Z - -
 method public handleWaterMovement ()Z - -
 method protected resetHeight ()V - -
 method public spawnRunningParticles ()V - -
 method protected createRunningParticles ()V - -
 method public isInsideOfMaterial (Lnet/minecraft/block/material/Material;)Z - -
 method public isInLava ()Z - -
 method public moveRelative (FFF)V - -
 method public getBrightnessForRender (F)I - -
 method public getBrightness (F)F - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public setPositionAndRotation (DDDFF)V - -
 method public moveToBlockPosAndAngles (Lnet/minecraft/util/math/BlockPos;FF)V - -
 method public setLocationAndAngles (DDDFF)V - -
 method public getDistanceToEntity (Lnet/minecraft/entity/Entity;)F - -
 method public getDistanceSq (DDD)D - -
 method public getDistanceSq (Lnet/minecraft/util/math/BlockPos;)D - -
 method public getDistanceSqToCenter (Lnet/minecraft/util/math/BlockPos;)D - -
 method public getDistance (DDD)D - -
 method public getDistanceSqToEntity (Lnet/minecraft/entity/Entity;)D - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public addVelocity (DDD)V - -
 method protected setBeenAttacked ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getLook (F)Lnet/minecraft/util/math/Vec3d; - -
 method protected,final getVectorForRotation (FF)Lnet/minecraft/util/math/Vec3d; - -
 method public getPositionEyes (F)Lnet/minecraft/util/math/Vec3d; - -
 method public rayTrace (DF)Lnet/minecraft/util/math/RayTraceResult; - -
 method public canBeCollidedWith ()Z - -
 method public canBePushed ()Z - -
 method public addToPlayerScore (Lnet/minecraft/entity/Entity;I)V - -
 method public isInRangeToRender3d (DDD)Z - -
 method public isInRangeToRenderDist (D)Z - -
 method public writeToNBTAtomically (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeToNBTOptional (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected shouldSetPosAfterLoading ()Z - -
 method protected,final getEntityString ()Ljava/lang/String; - -
 method protected,abstract readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected,abstract writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected,varargs newDoubleNBTList ([D)Lnet/minecraft/nbt/NBTTagList; - -
 method protected,varargs newFloatNBTList ([F)Lnet/minecraft/nbt/NBTTagList; - -
 method public dropItem (Lnet/minecraft/item/Item;I)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItemWithOffset (Lnet/minecraft/item/Item;IF)Lnet/minecraft/entity/item/EntityItem; - -
 method public entityDropItem (Lnet/minecraft/item/ItemStack;F)Lnet/minecraft/entity/item/EntityItem; - -
 method public isEntityAlive ()Z - -
 method public isEntityInsideOpaqueBlock ()Z - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public updateRidden ()V - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method public applyOrientationToEntity (Lnet/minecraft/entity/Entity;)V - -
 method public getYOffset ()D - -
 method public getMountedYOffset ()D - -
 method public startRiding (Lnet/minecraft/entity/Entity;)Z - -
 method public startRiding (Lnet/minecraft/entity/Entity;Z)Z - -
 method protected canBeRidden (Lnet/minecraft/entity/Entity;)Z - -
 method public removePassengers ()V - -
 method public dismountRidingEntity ()V - -
 method protected addPassenger (Lnet/minecraft/entity/Entity;)V - -
 method protected removePassenger (Lnet/minecraft/entity/Entity;)V - -
 method protected canFitPassenger (Lnet/minecraft/entity/Entity;)Z - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public getCollisionBorderSize ()F - -
 method public getLookVec ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPitchYaw ()Lnet/minecraft/util/math/Vec2f; - -
 method public getForward ()Lnet/minecraft/util/math/Vec3d; - -
 method public setPortal (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getPortalCooldown ()I - -
 method public setVelocity (DDD)V - -
 method public handleStatusUpdate (B)V - -
 method public performHurtAnimation ()V - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getEquipmentAndArmor ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public isBurning ()Z - -
 method public isRiding ()Z - -
 method public isBeingRidden ()Z - -
 method public isSneaking ()Z - -
 method public setSneaking (Z)V - -
 method public isSprinting ()Z - -
 method public setSprinting (Z)V - -
 method public isGlowing ()Z - -
 method public setGlowing (Z)V - -
 method public isInvisible ()Z - -
 method public isInvisibleToPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public isOnSameTeam (Lnet/minecraft/entity/Entity;)Z - -
 method public isOnScoreboardTeam (Lnet/minecraft/scoreboard/Team;)Z - -
 method public setInvisible (Z)V - -
 method protected getFlag (I)Z - -
 method protected setFlag (IZ)V - -
 method public getAir ()I - -
 method public setAir (I)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected pushOutOfBlocks (DDD)Z - -
 method public setInWeb ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getParts ()[Lnet/minecraft/entity/Entity; - -
 method public isEntityEqual (Lnet/minecraft/entity/Entity;)Z - -
 method public getRotationYawHead ()F - -
 method public setRotationYawHead (F)V - -
 method public setRenderYawOffset (F)V - -
 method public canBeAttackedWithItem ()Z - -
 method public hitByEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public isEntityInvulnerable (Lnet/minecraft/util/DamageSource;)Z - -
 method public setEntityInvulnerable (Z)V - -
 method public copyLocationAndAnglesFrom (Lnet/minecraft/entity/Entity;)V - -
 method public changeDimension (I)Lnet/minecraft/entity/Entity; - -
 method public isNonBoss ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method public verifyExplosion (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;F)Z - -
 method public getMaxFallHeight ()I - -
 method public getLastPortalVec ()Lnet/minecraft/util/math/Vec3d; - -
 method public getTeleportDirection ()Lnet/minecraft/util/EnumFacing; - -
 method public doesEntityNotTriggerPressurePlate ()Z - -
 method public addEntityCrashInfo (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public setUniqueId (Ljava/util/UUID;)V - -
 method public canRenderOnFire ()Z - -
 method public getUniqueID ()Ljava/util/UUID; - -
 method public getCachedUniqueIdString ()Ljava/lang/String; - -
 method public isPushedByWater ()Z - -
 method public,static getRenderDistanceWeight ()D - -
 method public,static setRenderDistanceWeight (D)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public setCustomNameTag (Ljava/lang/String;)V - -
 method public getCustomNameTag ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setAlwaysRenderNameTag (Z)V - -
 method public getAlwaysRenderNameTag ()Z - -
 method public setPositionAndUpdate (DDD)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method public getHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public getAdjustedHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method protected getHoverEvent ()Lnet/minecraft/util/text/event/HoverEvent; - -
 method public isSpectatedByPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public getEntityBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public setEntityBoundingBox (Lnet/minecraft/util/math/AxisAlignedBB;)V - -
 method public getEyeHeight ()F - -
 method public isOutsideBorder ()Z - -
 method public setOutsideBorder (Z)V - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public canUseCommand (ILjava/lang/String;)Z - -
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getPositionVector ()Lnet/minecraft/util/math/Vec3d; - -
 method public getEntityWorld ()Lnet/minecraft/world/World; - -
 method public getCommandSenderEntity ()Lnet/minecraft/entity/Entity; - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public getServer ()Lnet/minecraft/server/MinecraftServer; - -
 method public getCommandStats ()Lnet/minecraft/command/CommandResultStats; - -
 method public setCommandStats (Lnet/minecraft/entity/Entity;)V - -
 method public applyPlayerInteraction (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method public isImmuneToExplosions ()Z - -
 method protected applyEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public getEntityData ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public shouldRiderSit ()Z - -
 method public getPickedResult (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/item/ItemStack; - -
 method public getPersistentID ()Ljava/util/UUID; - -
 method public,final resetEntityId ()V - -
 method public shouldRenderInPass (I)Z - -
 method public isCreatureType (Lnet/minecraft/entity/EnumCreatureType;Z)Z - -
 method public canRiderInteract ()Z - -
 method public shouldDismountInWater (Lnet/minecraft/entity/Entity;)Z - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public addTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public removeTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public getRotatedYaw (Lnet/minecraft/util/Rotation;)F - -
 method public getMirroredYaw (Lnet/minecraft/util/Mirror;)F - -
 method public ignoreItemEntityData ()Z - -
 method public setPositionNonDirty ()Z - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
 method public getPassengers ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/entity/Entity;>; -
 method public isPassenger (Lnet/minecraft/entity/Entity;)Z - -
 method public getRecursivePassengers ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/Entity;>; -
 method public getRecursivePassengersByType (Ljava/lang/Class;)Ljava/util/Collection; <T:Lnet/minecraft/entity/Entity;>(Ljava/lang/Class<TT;>;)Ljava/util/Collection<TT;>; -
 method public getLowestRidingEntity ()Lnet/minecraft/entity/Entity; - -
 method public isRidingSameEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public isRidingOrBeingRiddenBy (Lnet/minecraft/entity/Entity;)Z - -
 method public canPassengerSteer ()Z - -
 method public getRidingEntity ()Lnet/minecraft/entity/Entity; - -
 method public getPushReaction ()Lnet/minecraft/block/material/EnumPushReaction; - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
in 326
class net/minecraft/entity/Entity 52 public,super,abstract java/lang/Object net/minecraft/command/ICommandSender,net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraft/command/ICommandSender;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/block/state/pattern/BlockPattern$PatternHelper net/minecraft/block/state/pattern/BlockPattern PatternHelper public,static
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraftforge/event/entity/EntityEvent$EntityConstructing net/minecraftforge/event/entity/EntityEvent EntityConstructing public,static
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 inner net/minecraft/util/EnumFacing$AxisDirection net/minecraft/util/EnumFacing AxisDirection public,static,final,enum
 inner net/minecraft/util/text/event/HoverEvent$Action net/minecraft/util/text/event/HoverEvent Action public,static,final,enum
 field public preventEntitySpawning Z -
 field protected rideCooldown I -
 field public forceSpawn Z -
 field public world Lnet/minecraft/world/World; -
 field public prevPosX D -
 field public prevPosY D -
 field public prevPosZ D -
 field public posX D -
 field public posY D -
 field public posZ D -
 field public motionX D -
 field public motionY D -
 field public motionZ D -
 field public rotationYaw F -
 field public rotationPitch F -
 field public prevRotationYaw F -
 field public prevRotationPitch F -
 field public onGround Z -
 field public collidedHorizontally Z -
 field public collidedVertically Z -
 field public collided Z -
 field public velocityChanged Z -
 field protected isInWeb Z -
 field public isDead Z -
 field public width F -
 field public height F -
 field public prevDistanceWalkedModified F -
 field public distanceWalkedModified F -
 field public distanceWalkedOnStepModified F -
 field public fallDistance F -
 field public lastTickPosX D -
 field public lastTickPosY D -
 field public lastTickPosZ D -
 field public stepHeight F -
 field public noClip Z -
 field public entityCollisionReduction F -
 field protected rand Ljava/util/Random; -
 field public ticksExisted I -
 field protected inWater Z -
 field public hurtResistantTime I -
 field protected firstUpdate Z -
 field protected isImmuneToFire Z -
 field protected dataManager Lnet/minecraft/network/datasync/EntityDataManager; -
 field protected,static,final FLAGS Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public addedToChunk Z -
 field public chunkCoordX I -
 field public chunkCoordY I -
 field public chunkCoordZ I -
 field public serverPosX J -
 field public serverPosY J -
 field public serverPosZ J -
 field public ignoreFrustumCheck Z -
 field public isAirBorne Z -
 field public timeUntilPortal I -
 field protected inPortal Z -
 field protected portalCounter I -
 field public dimension I -
 field protected lastPortalPos Lnet/minecraft/util/math/BlockPos; -
 field protected lastPortalVec Lnet/minecraft/util/math/Vec3d; -
 field protected teleportDirection Lnet/minecraft/util/EnumFacing; -
 field protected entityUniqueID Ljava/util/UUID; -
 field protected cachedUniqueIdString Ljava/lang/String; -
 field protected glowing Z -
 field public updateBlocked Z -
 field public captureDrops Z -
 field public capturedDrops Ljava/util/ArrayList; Ljava/util/ArrayList<Lnet/minecraft/entity/item/EntityItem;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getEntityId ()I - -
 method public setEntityId (I)V - -
 method public getTags ()Ljava/util/Set; ()Ljava/util/Set<Ljava/lang/String;>; -
 method public addTag (Ljava/lang/String;)Z - -
 method public removeTag (Ljava/lang/String;)Z - -
 method public onKillCommand ()V - -
 method protected,abstract entityInit ()V - -
 method public getDataManager ()Lnet/minecraft/network/datasync/EntityDataManager; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method protected preparePlayerToSpawn ()V - -
 method public setDead ()V - -
 method public setDropItemsWhenDead (Z)V - -
 method protected setSize (FF)V - -
 method protected setRotation (FF)V - -
 method public setPosition (DDD)V - -
 method public turn (FF)V - -
 method public onUpdate ()V - -
 method public onEntityUpdate ()V - -
 method protected decrementTimeUntilPortal ()V - -
 method public getMaxInPortalTime ()I - -
 method protected setOnFireFromLava ()V - -
 method public setFire (I)V - -
 method public extinguish ()V - -
 method protected outOfWorld ()V - -
 method public isOffsetPositionInLiquid (DDD)Z - -
 method public move (Lnet/minecraft/entity/MoverType;DDD)V - -
 method public resetPositionToBB ()V - -
 method protected getSwimSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSplashSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected doBlockCollisions ()V - -
 method protected onInsideBlock (Lnet/minecraft/block/state/IBlockState;)V - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected playFlySound (F)F - -
 method protected makeFlySound ()Z - -
 method public playSound (Lnet/minecraft/util/SoundEvent;FF)V - -
 method public isSilent ()Z - -
 method public setSilent (Z)V - -
 method public hasNoGravity ()Z - -
 method public setNoGravity (Z)V - -
 method protected canTriggerWalking ()Z - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method protected dealFireDamage (I)V - -
 method public,final isImmuneToFire ()Z - -
 method public fall (FF)V - -
 method public isWet ()Z - -
 method public isInWater ()Z - -
 method public isOverWater ()Z - -
 method public handleWaterMovement ()Z - -
 method protected doWaterSplashEffect ()V - -
 method public spawnRunningParticles ()V - -
 method protected createRunningParticles ()V - -
 method public isInsideOfMaterial (Lnet/minecraft/block/material/Material;)Z - -
 method public isInLava ()Z - -
 method public moveRelative (FFFF)V - -
 method public getBrightnessForRender ()I - -
 method public getBrightness ()F - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public setPositionAndRotation (DDDFF)V - -
 method public moveToBlockPosAndAngles (Lnet/minecraft/util/math/BlockPos;FF)V - -
 method public setLocationAndAngles (DDDFF)V - -
 method public getDistance (Lnet/minecraft/entity/Entity;)F - -
 method public getDistanceSq (DDD)D - -
 method public getDistanceSq (Lnet/minecraft/util/math/BlockPos;)D - -
 method public getDistanceSqToCenter (Lnet/minecraft/util/math/BlockPos;)D - -
 method public getDistance (DDD)D - -
 method public getDistanceSq (Lnet/minecraft/entity/Entity;)D - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public addVelocity (DDD)V - -
 method protected markVelocityChanged ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getLook (F)Lnet/minecraft/util/math/Vec3d; - -
 method protected,final getVectorForRotation (FF)Lnet/minecraft/util/math/Vec3d; - -
 method public getPositionEyes (F)Lnet/minecraft/util/math/Vec3d; - -
 method public rayTrace (DF)Lnet/minecraft/util/math/RayTraceResult; - -
 method public canBeCollidedWith ()Z - -
 method public canBePushed ()Z - -
 method public awardKillScore (Lnet/minecraft/entity/Entity;ILnet/minecraft/util/DamageSource;)V - -
 method public isInRangeToRender3d (DDD)Z - -
 method public isInRangeToRenderDist (D)Z - -
 method public writeToNBTAtomically (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeToNBTOptional (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public,static registerFixes (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected shouldSetPosAfterLoading ()Z - -
 method protected,final getEntityString ()Ljava/lang/String; - -
 method protected,abstract readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected,abstract writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected,varargs newDoubleNBTList ([D)Lnet/minecraft/nbt/NBTTagList; - -
 method protected,varargs newFloatNBTList ([F)Lnet/minecraft/nbt/NBTTagList; - -
 method public dropItem (Lnet/minecraft/item/Item;I)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItemWithOffset (Lnet/minecraft/item/Item;IF)Lnet/minecraft/entity/item/EntityItem; - -
 method public entityDropItem (Lnet/minecraft/item/ItemStack;F)Lnet/minecraft/entity/item/EntityItem; - -
 method public isEntityAlive ()Z - -
 method public isEntityInsideOpaqueBlock ()Z - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public updateRidden ()V - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method public applyOrientationToEntity (Lnet/minecraft/entity/Entity;)V - -
 method public getYOffset ()D - -
 method public getMountedYOffset ()D - -
 method public startRiding (Lnet/minecraft/entity/Entity;)Z - -
 method public startRiding (Lnet/minecraft/entity/Entity;Z)Z - -
 method protected canBeRidden (Lnet/minecraft/entity/Entity;)Z - -
 method public removePassengers ()V - -
 method public dismountRidingEntity ()V - -
 method protected addPassenger (Lnet/minecraft/entity/Entity;)V - -
 method protected removePassenger (Lnet/minecraft/entity/Entity;)V - -
 method protected canFitPassenger (Lnet/minecraft/entity/Entity;)Z - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public getCollisionBorderSize ()F - -
 method public getLookVec ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPitchYaw ()Lnet/minecraft/util/math/Vec2f; - -
 method public getForward ()Lnet/minecraft/util/math/Vec3d; - -
 method public setPortal (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getPortalCooldown ()I - -
 method public setVelocity (DDD)V - -
 method public handleStatusUpdate (B)V - -
 method public performHurtAnimation ()V - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getEquipmentAndArmor ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public isBurning ()Z - -
 method public isRiding ()Z - -
 method public isBeingRidden ()Z - -
 method public isSneaking ()Z - -
 method public setSneaking (Z)V - -
 method public isSprinting ()Z - -
 method public setSprinting (Z)V - -
 method public isGlowing ()Z - -
 method public setGlowing (Z)V - -
 method public isInvisible ()Z - -
 method public isInvisibleToPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public isOnSameTeam (Lnet/minecraft/entity/Entity;)Z - -
 method public isOnScoreboardTeam (Lnet/minecraft/scoreboard/Team;)Z - -
 method public setInvisible (Z)V - -
 method protected getFlag (I)Z - -
 method protected setFlag (IZ)V - -
 method public getAir ()I - -
 method public setAir (I)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected pushOutOfBlocks (DDD)Z - -
 method public setInWeb ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getParts ()[Lnet/minecraft/entity/Entity; - -
 method public isEntityEqual (Lnet/minecraft/entity/Entity;)Z - -
 method public getRotationYawHead ()F - -
 method public setRotationYawHead (F)V - -
 method public setRenderYawOffset (F)V - -
 method public canBeAttackedWithItem ()Z - -
 method public hitByEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public toString ()Ljava/lang/String; - -
 method public isEntityInvulnerable (Lnet/minecraft/util/DamageSource;)Z - -
 method public getIsInvulnerable ()Z - -
 method public setEntityInvulnerable (Z)V - -
 method public copyLocationAndAnglesFrom (Lnet/minecraft/entity/Entity;)V - -
 method public changeDimension (I)Lnet/minecraft/entity/Entity; - -
 method public changeDimension (ILnet/minecraftforge/common/util/ITeleporter;)Lnet/minecraft/entity/Entity; - -
 method public isNonBoss ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method public canExplosionDestroyBlock (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;F)Z - -
 method public getMaxFallHeight ()I - -
 method public getLastPortalVec ()Lnet/minecraft/util/math/Vec3d; - -
 method public getTeleportDirection ()Lnet/minecraft/util/EnumFacing; - -
 method public doesEntityNotTriggerPressurePlate ()Z - -
 method public addEntityCrashInfo (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public setUniqueId (Ljava/util/UUID;)V - -
 method public canRenderOnFire ()Z - -
 method public getUniqueID ()Ljava/util/UUID; - -
 method public getCachedUniqueIdString ()Ljava/lang/String; - -
 method public isPushedByWater ()Z - -
 method public,static getRenderDistanceWeight ()D - -
 method public,static setRenderDistanceWeight (D)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public setCustomNameTag (Ljava/lang/String;)V - -
 method public getCustomNameTag ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setAlwaysRenderNameTag (Z)V - -
 method public getAlwaysRenderNameTag ()Z - -
 method public setPositionAndUpdate (DDD)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method public getHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public getAdjustedHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method protected getHoverEvent ()Lnet/minecraft/util/text/event/HoverEvent; - -
 method public isSpectatedByPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public getEntityBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public setEntityBoundingBox (Lnet/minecraft/util/math/AxisAlignedBB;)V - -
 method public getEyeHeight ()F - -
 method public isOutsideBorder ()Z - -
 method public setOutsideBorder (Z)V - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public canUseCommand (ILjava/lang/String;)Z - -
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getPositionVector ()Lnet/minecraft/util/math/Vec3d; - -
 method public getEntityWorld ()Lnet/minecraft/world/World; - -
 method public getCommandSenderEntity ()Lnet/minecraft/entity/Entity; - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public getServer ()Lnet/minecraft/server/MinecraftServer; - -
 method public getCommandStats ()Lnet/minecraft/command/CommandResultStats; - -
 method public setCommandStats (Lnet/minecraft/entity/Entity;)V - -
 method public applyPlayerInteraction (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method public isImmuneToExplosions ()Z - -
 method protected applyEnchantments (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;)V - -
 method public,final isAddedToWorld ()Z - -
 method public onAddedToWorld ()V - -
 method public onRemovedFromWorld ()V - -
 method public getEntityData ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public shouldRiderSit ()Z - -
 method public getPickedResult (Lnet/minecraft/util/math/RayTraceResult;)Lnet/minecraft/item/ItemStack; - -
 method public getPersistentID ()Ljava/util/UUID; - -
 method public,final,deprecated resetEntityId ()V - -
 method public shouldRenderInPass (I)Z - -
 method public isCreatureType (Lnet/minecraft/entity/EnumCreatureType;Z)Z - -
 method public canRiderInteract ()Z - -
 method public shouldDismountInWater (Lnet/minecraft/entity/Entity;)Z - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public canTrample (Lnet/minecraft/world/World;Lnet/minecraft/block/Block;Lnet/minecraft/util/math/BlockPos;F)Z - -
 method public addTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public removeTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public getRotatedYaw (Lnet/minecraft/util/Rotation;)F - -
 method public getMirroredYaw (Lnet/minecraft/util/Mirror;)F - -
 method public ignoreItemEntityData ()Z - -
 method public setPositionNonDirty ()Z - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
 method public getPassengers ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/entity/Entity;>; -
 method public isPassenger (Lnet/minecraft/entity/Entity;)Z - -
 method public getRecursivePassengers ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/Entity;>; -
 method public getRecursivePassengersByType (Ljava/lang/Class;)Ljava/util/Collection; <T:Lnet/minecraft/entity/Entity;>(Ljava/lang/Class<TT;>;)Ljava/util/Collection<TT;>; -
 method public getLowestRidingEntity ()Lnet/minecraft/entity/Entity; - -
 method public isRidingSameEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public isRidingOrBeingRiddenBy (Lnet/minecraft/entity/Entity;)Z - -
 method public canPassengerSteer ()Z - -
 method public getRidingEntity ()Lnet/minecraft/entity/Entity; - -
 method public getPushReaction ()Lnet/minecraft/block/material/EnumPushReaction; - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getFireImmuneTicks ()I - -
in 90
class net/minecraft/entity/EntityAgeable 50 public,super,abstract net/minecraft/entity/EntityCreature - -
 field protected growingAge I -
 field protected field_175502_b I -
 field protected field_175503_c I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,abstract createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected entityInit ()V - -
 method public getGrowingAge ()I - -
 method public func_175501_a (IZ)V - -
 method public addGrowth (I)V - -
 method public setGrowingAge (I)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onLivingUpdate ()V - -
 method protected onGrowingAdult ()V - -
 method public isChild ()Z - -
 method public setScaleForAge (Z)V - -
 method protected,final setSize (FF)V - -
 method protected,final setScale (F)V - -
in 91
class net/minecraft/entity/EntityAgeable 50 public,super,abstract net/minecraft/entity/EntityCreature - -
 field protected growingAge I -
 field protected forcedAge I -
 field protected forcedAgeTimer I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,abstract createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected entityInit ()V - -
 method public getGrowingAge ()I - -
 method public ageUp (IZ)V - -
 method public addGrowth (I)V - -
 method public setGrowingAge (I)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public onLivingUpdate ()V - -
 method protected onGrowingAdult ()V - -
 method public isChild ()Z - -
 method public setScaleForAge (Z)V - -
 method protected,final setSize (FF)V - -
 method protected,final setScale (F)V - -
in 326
class net/minecraft/entity/EntityAgeable 52 public,super,abstract net/minecraft/entity/EntityCreature - -
 field protected growingAge I -
 field protected forcedAge I -
 field protected forcedAgeTimer I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,abstract createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected holdingSpawnEggOfClass (Lnet/minecraft/item/ItemStack;Ljava/lang/Class;)Z (Lnet/minecraft/item/ItemStack;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;)Z -
 method protected entityInit ()V - -
 method public getGrowingAge ()I - -
 method public ageUp (IZ)V - -
 method public addGrowth (I)V - -
 method public setGrowingAge (I)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public onLivingUpdate ()V - -
 method protected onGrowingAdult ()V - -
 method public isChild ()Z - -
 method public setScaleForAge (Z)V - -
 method protected,final setSize (FF)V - -
 method protected,final setScale (F)V - -
in 91
class net/minecraft/entity/EntityAreaEffectCloud 50 public,super net/minecraft/entity/Entity - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected entityInit ()V - -
 method public setRadius (F)V - -
 method public getRadius ()F - -
 method public setPotion (Lnet/minecraft/potion/PotionType;)V - -
 method public addEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public getColor ()I - -
 method public setColor (I)V - -
 method public getParticle ()Lnet/minecraft/util/EnumParticleTypes; - -
 method public setParticle (Lnet/minecraft/util/EnumParticleTypes;)V - -
 method public getParticleParam1 ()I - -
 method public setParticleParam1 (I)V - -
 method public getParticleParam2 ()I - -
 method public setParticleParam2 (I)V - -
 method protected setIgnoreRadius (Z)V - -
 method public shouldIgnoreRadius ()Z - -
 method public getDuration ()I - -
 method public setDuration (I)V - -
 method public onUpdate ()V - -
 method public setRadiusOnUse (F)V - -
 method public setRadiusPerTick (F)V - -
 method public setWaitTime (I)V - -
 method public setOwner (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getOwner ()Lnet/minecraft/entity/EntityLivingBase; - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getPushReaction ()Lnet/minecraft/block/material/EnumPushReaction; - -
in 326
class net/minecraft/entity/EntityAreaEffectCloud 52 public,super net/minecraft/entity/Entity - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected entityInit ()V - -
 method public setRadius (F)V - -
 method public getRadius ()F - -
 method public setPotion (Lnet/minecraft/potion/PotionType;)V - -
 method public addEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public getColor ()I - -
 method public setColor (I)V - -
 method public getParticle ()Lnet/minecraft/util/EnumParticleTypes; - -
 method public setParticle (Lnet/minecraft/util/EnumParticleTypes;)V - -
 method public getParticleParam1 ()I - -
 method public setParticleParam1 (I)V - -
 method public getParticleParam2 ()I - -
 method public setParticleParam2 (I)V - -
 method protected setIgnoreRadius (Z)V - -
 method public shouldIgnoreRadius ()Z - -
 method public getDuration ()I - -
 method public setDuration (I)V - -
 method public onUpdate ()V - -
 method public setRadiusOnUse (F)V - -
 method public setRadiusPerTick (F)V - -
 method public setWaitTime (I)V - -
 method public setOwner (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getOwner ()Lnet/minecraft/entity/EntityLivingBase; - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getPushReaction ()Lnet/minecraft/block/material/EnumPushReaction; - -
in 24
class net/minecraft/entity/EntityBodyHelper 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public updateRenderAngles ()V - -
in 326
class net/minecraft/entity/EntityBodyHelper 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public updateRenderAngles ()V - -
in 90
class net/minecraft/entity/EntityCreature 50 public,super,abstract net/minecraft/entity/EntityLiving - -
 field public,static,final FLEEING_SPEED_MODIFIER_UUID Ljava/util/UUID; -
 field public,static,final FLEEING_SPEED_MODIFIER Lnet/minecraft/entity/ai/attributes/AttributeModifier; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getBlockPathWeight (Lnet/minecraft/util/BlockPos;)F - -
 method public getCanSpawnHere ()Z - -
 method public hasPath ()Z - -
 method public isWithinHomeDistanceCurrentPosition ()Z - -
 method public isWithinHomeDistanceFromPosition (Lnet/minecraft/util/BlockPos;)Z - -
 method public setHomePosAndDistance (Lnet/minecraft/util/BlockPos;I)V - -
 method public getHomePosition ()Lnet/minecraft/util/BlockPos; - -
 method public getMaximumHomeDistance ()F - -
 method public detachHome ()V - -
 method public hasHome ()Z - -
 method protected updateLeashedState ()V - -
 method protected func_142017_o (F)V - -
in 91
class net/minecraft/entity/EntityCreature 50 public,super,abstract net/minecraft/entity/EntityLiving - -
 field public,static,final FLEEING_SPEED_MODIFIER_UUID Ljava/util/UUID; -
 field public,static,final FLEEING_SPEED_MODIFIER Lnet/minecraft/entity/ai/attributes/AttributeModifier; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method public getCanSpawnHere ()Z - -
 method public hasPath ()Z - -
 method public isWithinHomeDistanceCurrentPosition ()Z - -
 method public isWithinHomeDistanceFromPosition (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public setHomePosAndDistance (Lnet/minecraft/util/math/BlockPos;I)V - -
 method public getHomePosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getMaximumHomeDistance ()F - -
 method public detachHome ()V - -
 method public hasHome ()Z - -
 method protected updateLeashedState ()V - -
 method protected onLeashDistance (F)V - -
in 326
class net/minecraft/entity/EntityCreature 52 public,super,abstract net/minecraft/entity/EntityLiving - -
 field public,static,final FLEEING_SPEED_MODIFIER_UUID Ljava/util/UUID; -
 field public,static,final FLEEING_SPEED_MODIFIER Lnet/minecraft/entity/ai/attributes/AttributeModifier; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method public getCanSpawnHere ()Z - -
 method public hasPath ()Z - -
 method public isWithinHomeDistanceCurrentPosition ()Z - -
 method public isWithinHomeDistanceFromPosition (Lnet/minecraft/util/math/BlockPos;)Z - -
 method public setHomePosAndDistance (Lnet/minecraft/util/math/BlockPos;I)V - -
 method public getHomePosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getMaximumHomeDistance ()F - -
 method public detachHome ()V - -
 method public hasHome ()Z - -
 method protected updateLeashedState ()V - -
 method protected followLeashSpeed ()D - -
 method protected onLeashDistance (F)V - -
in 90
class net/minecraft/entity/EntityFlying 50 public,super,abstract net/minecraft/entity/EntityLiving - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public fall (FF)V - -
 method protected updateFallState (DZLnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;)V - -
 method public moveEntityWithHeading (FF)V - -
 method public isOnLadder ()Z - -
in 91
class net/minecraft/entity/EntityFlying 50 public,super,abstract net/minecraft/entity/EntityLiving - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public fall (FF)V - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public moveEntityWithHeading (FF)V - -
 method public isOnLadder ()Z - -
in 326
class net/minecraft/entity/EntityFlying 52 public,super,abstract net/minecraft/entity/EntityLiving - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public fall (FF)V - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public travel (FFF)V - -
 method public isOnLadder ()Z - -
in 90
class net/minecraft/entity/EntityHanging 50 public,super,abstract net/minecraft/entity/Entity - -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 field protected hangingPosition Lnet/minecraft/util/BlockPos; -
 field public facingDirection Lnet/minecraft/util/EnumFacing; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)V - -
 method protected entityInit ()V - -
 method protected updateFacingWithBoundingBox (Lnet/minecraft/util/EnumFacing;)V - -
 method public onUpdate ()V - -
 method public onValidSurface ()Z - -
 method public canBeCollidedWith ()Z - -
 method public hitByEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public getHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public moveEntity (DDD)V - -
 method public addVelocity (DDD)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,abstract getWidthPixels ()I - -
 method public,abstract getHeightPixels ()I - -
 method public,abstract onBroken (Lnet/minecraft/entity/Entity;)V - -
 method protected shouldSetPosAfterLoading ()Z - -
 method public setPosition (DDD)V - -
 method public getHangingPosition ()Lnet/minecraft/util/BlockPos; - -
in 91
class net/minecraft/entity/EntityHanging 50 public,super,abstract net/minecraft/entity/Entity - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 field protected hangingPosition Lnet/minecraft/util/math/BlockPos; -
 field public facingDirection Lnet/minecraft/util/EnumFacing; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method protected entityInit ()V - -
 method protected updateFacingWithBoundingBox (Lnet/minecraft/util/EnumFacing;)V - -
 method protected updateBoundingBox ()V - -
 method public onUpdate ()V - -
 method public onValidSurface ()Z - -
 method public canBeCollidedWith ()Z - -
 method public hitByEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public getHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public move (DDD)V - -
 method public addVelocity (DDD)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,abstract getWidthPixels ()I - -
 method public,abstract getHeightPixels ()I - -
 method public,abstract onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public,abstract playPlaceSound ()V - -
 method public entityDropItem (Lnet/minecraft/item/ItemStack;F)Lnet/minecraft/entity/item/EntityItem; - -
 method protected shouldSetPosAfterLoading ()Z - -
 method public setPosition (DDD)V - -
 method public getHangingPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getRotatedYaw (Lnet/minecraft/util/Rotation;)F - -
 method public getMirroredYaw (Lnet/minecraft/util/Mirror;)F - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
in 326
class net/minecraft/entity/EntityHanging 52 public,super,abstract net/minecraft/entity/Entity - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 field protected hangingPosition Lnet/minecraft/util/math/BlockPos; -
 field public facingDirection Lnet/minecraft/util/EnumFacing; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method protected entityInit ()V - -
 method protected updateFacingWithBoundingBox (Lnet/minecraft/util/EnumFacing;)V - -
 method protected updateBoundingBox ()V - -
 method public onUpdate ()V - -
 method public onValidSurface ()Z - -
 method public canBeCollidedWith ()Z - -
 method public hitByEntity (Lnet/minecraft/entity/Entity;)Z - -
 method public getHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public move (Lnet/minecraft/entity/MoverType;DDD)V - -
 method public addVelocity (DDD)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,abstract getWidthPixels ()I - -
 method public,abstract getHeightPixels ()I - -
 method public,abstract onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public,abstract playPlaceSound ()V - -
 method public entityDropItem (Lnet/minecraft/item/ItemStack;F)Lnet/minecraft/entity/item/EntityItem; - -
 method protected shouldSetPosAfterLoading ()Z - -
 method public setPosition (DDD)V - -
 method public getHangingPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getRotatedYaw (Lnet/minecraft/util/Rotation;)F - -
 method public getMirroredYaw (Lnet/minecraft/util/Mirror;)F - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
in 90
class net/minecraft/entity/EntityLeashKnot 50 public,super net/minecraft/entity/EntityHanging - -
 method public isInRangeToRenderDist (D)Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)V - -
 method protected entityInit ()V - -
 method public updateFacingWithBoundingBox (Lnet/minecraft/util/EnumFacing;)V - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public getEyeHeight ()F - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public writeToNBTOptional (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onValidSurface ()Z - -
 method public,static createKnot (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Lnet/minecraft/entity/EntityLeashKnot; - -
 method public,static getKnotForPosition (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Lnet/minecraft/entity/EntityLeashKnot; - -
in 91
class net/minecraft/entity/EntityLeashKnot 50 public,super net/minecraft/entity/EntityHanging - -
 method public isInRangeToRenderDist (D)Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method public setPosition (DDD)V - -
 method protected updateBoundingBox ()V - -
 method public updateFacingWithBoundingBox (Lnet/minecraft/util/EnumFacing;)V - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public getEyeHeight ()F - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public writeToNBTOptional (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method public onValidSurface ()Z - -
 method public,static createKnot (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/EntityLeashKnot; - -
 method public,static getKnotForPosition (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/EntityLeashKnot; - -
 method public playPlaceSound ()V - -
in 326
class net/minecraft/entity/EntityLeashKnot 52 public,super net/minecraft/entity/EntityHanging - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method public setPosition (DDD)V - -
 method protected updateBoundingBox ()V - -
 method public updateFacingWithBoundingBox (Lnet/minecraft/util/EnumFacing;)V - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public getEyeHeight ()F - -
 method public isInRangeToRenderDist (D)Z - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public writeToNBTOptional (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public onValidSurface ()Z - -
 method public,static createKnot (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/EntityLeashKnot; - -
 method public,static getKnotForPosition (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/EntityLeashKnot; - -
 method public playPlaceSound ()V - -
in 90
class net/minecraft/entity/EntityList 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 field public,static,final stringToClassMapping Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;>;
 field public,static,final classToStringMapping Ljava/util/Map; Ljava/util/Map<Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Ljava/lang/String;>;
 field public,static,final idToClassMapping Ljava/util/Map; Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;>;
 field public,static,final entityEggs Ljava/util/Map; Ljava/util/Map<Ljava/lang/Integer;Lnet/minecraft/entity/EntityList$EntityEggInfo;>;
 method public <init> ()V - -
 method public,static addMapping (Ljava/lang/Class;Ljava/lang/String;I)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Ljava/lang/String;I)V -
 method public,static addMapping (Ljava/lang/Class;Ljava/lang/String;III)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Ljava/lang/String;III)V -
 method public,static createEntityByName (Ljava/lang/String;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static createEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static createEntityByID (ILnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static getEntityID (Lnet/minecraft/entity/Entity;)I - -
 method public,static getClassFromID (I)Ljava/lang/Class; (I)Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>; -
 method public,static getEntityString (Lnet/minecraft/entity/Entity;)Ljava/lang/String; - -
 method public,static getStringFromID (I)Ljava/lang/String; - -
 method public,static getIDFromString (Ljava/lang/String;)I - -
 method public,static func_151514_a ()V - -
 method public,static getEntityNameList ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,static isStringEntityName (Lnet/minecraft/entity/Entity;Ljava/lang/String;)Z - -
 method public,static isStringValidEntityName (Ljava/lang/String;)Z - -
in 91
class net/minecraft/entity/EntityList 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public,static,final NAME_TO_CLASS Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;>;
 field public,static,final CLASS_TO_NAME Ljava/util/Map; Ljava/util/Map<Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Ljava/lang/String;>;
 field public,static,final ID_TO_CLASS Ljava/util/Map; Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;>;
 field public,static,final ENTITY_EGGS Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/entity/EntityList$EntityEggInfo;>;
 method public <init> ()V - -
 method public,static addMapping (Ljava/lang/Class;Ljava/lang/String;I)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Ljava/lang/String;I)V -
 method public,static addMapping (Ljava/lang/Class;Ljava/lang/String;III)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Ljava/lang/String;III)V -
 method public,static createEntityByName (Ljava/lang/String;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static createEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static createEntityByID (ILnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static createEntityByIDFromName (Ljava/lang/String;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static getEntityID (Lnet/minecraft/entity/Entity;)I - -
 method public,static getClassFromID (I)Ljava/lang/Class; (I)Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>; -
 method public,static getEntityString (Lnet/minecraft/entity/Entity;)Ljava/lang/String; - -
 method public,static getEntityStringFromClass (Ljava/lang/Class;)Ljava/lang/String; (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;)Ljava/lang/String; -
 method public,static getIDFromString (Ljava/lang/String;)I - -
 method public,static init ()V - -
 method public,static getEntityNameList ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,static isStringEntityName (Lnet/minecraft/entity/Entity;Ljava/lang/String;)Z - -
 method public,static isStringValidEntityName (Ljava/lang/String;)Z - -
in 326
class net/minecraft/entity/EntityList 52 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner com/google/common/collect/Sets$SetView com/google/common/collect/Sets SetView public,static,abstract
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public,static,final LIGHTNING_BOLT Lnet/minecraft/util/ResourceLocation; -
 field public,static,final ENTITY_EGGS Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/entity/EntityList$EntityEggInfo;>;
 method public <init> ()V - -
 method public,static getKey (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/ResourceLocation; - -
 method public,static getKey (Ljava/lang/Class;)Lnet/minecraft/util/ResourceLocation; (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;)Lnet/minecraft/util/ResourceLocation; -
 method public,static getEntityString (Lnet/minecraft/entity/Entity;)Ljava/lang/String; - -
 method public,static getTranslationName (Lnet/minecraft/util/ResourceLocation;)Ljava/lang/String; - -
 method public,static getClassFromID (I)Ljava/lang/Class; (I)Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>; -
 method public,static getClassFromName (Ljava/lang/String;)Ljava/lang/Class; (Ljava/lang/String;)Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>; -
 method public,static getID (Ljava/lang/Class;)I (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;)I -
 method public,static getClass (Lnet/minecraft/util/ResourceLocation;)Ljava/lang/Class; (Lnet/minecraft/util/ResourceLocation;)Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>; -
 method public,static newEntity (Ljava/lang/Class;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; -
 method public,static createEntityByID (ILnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static createEntityByIDFromName (Lnet/minecraft/util/ResourceLocation;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static createEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public,static getEntityNameList ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/util/ResourceLocation;>; -
 method public,static isMatchingName (Lnet/minecraft/entity/Entity;Lnet/minecraft/util/ResourceLocation;)Z - -
 method public,static isRegistered (Lnet/minecraft/util/ResourceLocation;)Z - -
 method public,static getValidTypeNames ()Ljava/lang/String; - -
 method public,static init ()V - -
 method protected,static addSpawnInfo (Ljava/lang/String;II)Lnet/minecraft/entity/EntityList$EntityEggInfo; - -
in 90
class net/minecraft/entity/EntityList$EntityEggInfo 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 field public,final,deprecated spawnedID I -
 field public,final name Ljava/lang/String; -
 field public,final primaryColor I -
 field public,final secondaryColor I -
 field public,final field_151512_d Lnet/minecraft/stats/StatBase; -
 field public,final field_151513_e Lnet/minecraft/stats/StatBase; -
 method public <init> (III)V - -
 method public <init> (Ljava/lang/String;II)V - -
in 91
class net/minecraft/entity/EntityList$EntityEggInfo 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 field public,final spawnedID Ljava/lang/String; -
 field public,final primaryColor I -
 field public,final secondaryColor I -
 field public,final killEntityStat Lnet/minecraft/stats/StatBase; -
 field public,final entityKilledByStat Lnet/minecraft/stats/StatBase; -
 method public <init> (Ljava/lang/String;II)V - -
in 326
class net/minecraft/entity/EntityList$EntityEggInfo 52 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 field public,final spawnedID Lnet/minecraft/util/ResourceLocation; -
 field public,final primaryColor I -
 field public,final secondaryColor I -
 field public,final killEntityStat Lnet/minecraft/stats/StatBase; -
 field public,final entityKilledByStat Lnet/minecraft/stats/StatBase; -
 method public <init> (Lnet/minecraft/util/ResourceLocation;II)V - -
 method public <init> (Lnet/minecraft/util/ResourceLocation;IILnet/minecraft/stats/StatBase;Lnet/minecraft/stats/StatBase;)V - -
in 90
class net/minecraft/entity/EntityLiving 50 public,super,abstract net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 field public livingSoundTime I -
 field protected experienceValue I -
 field protected moveHelper Lnet/minecraft/entity/ai/EntityMoveHelper; -
 field protected jumpHelper Lnet/minecraft/entity/ai/EntityJumpHelper; -
 field protected navigator Lnet/minecraft/pathfinding/PathNavigate; -
 field public,final tasks Lnet/minecraft/entity/ai/EntityAITasks; -
 field public,final targetTasks Lnet/minecraft/entity/ai/EntityAITasks; -
 field protected equipmentDropChances [F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected getNewNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method public getLookHelper ()Lnet/minecraft/entity/ai/EntityLookHelper; - -
 method public getMoveHelper ()Lnet/minecraft/entity/ai/EntityMoveHelper; - -
 method public getJumpHelper ()Lnet/minecraft/entity/ai/EntityJumpHelper; - -
 method public getNavigator ()Lnet/minecraft/pathfinding/PathNavigate; - -
 method public getEntitySenses ()Lnet/minecraft/entity/ai/EntitySenses; - -
 method public getAttackTarget ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public canAttackClass (Ljava/lang/Class;)Z (Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)Z -
 method public eatGrassBonus ()V - -
 method protected entityInit ()V - -
 method public getTalkInterval ()I - -
 method public playLivingSound ()V - -
 method public onEntityUpdate ()V - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public spawnExplosionParticle ()V - -
 method public handleStatusUpdate (B)V - -
 method public onUpdate ()V - -
 method protected updateDistance (FF)F - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setMoveForward (F)V - -
 method public setAIMoveSpeed (F)V - -
 method public onLivingUpdate ()V - -
 method protected updateEquipmentIfNeeded (Lnet/minecraft/entity/item/EntityItem;)V - -
 method protected func_175448_a (Lnet/minecraft/item/ItemStack;)Z - -
 method protected canDespawn ()Z - -
 method protected despawnEntity ()V - -
 method protected,final updateEntityActionState ()V - -
 method protected updateAITasks ()V - -
 method public getVerticalFaceSpeed ()I - -
 method public faceEntity (Lnet/minecraft/entity/Entity;FF)V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getRenderSizeModifier ()F - -
 method public getMaxSpawnedInChunk ()I - -
 method public getMaxFallHeight ()I - -
 method public getHeldItem ()Lnet/minecraft/item/ItemStack; - -
 method public getEquipmentInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getCurrentArmor (I)Lnet/minecraft/item/ItemStack; - -
 method public setCurrentItemOrArmor (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventory ()[Lnet/minecraft/item/ItemStack; - -
 method protected dropEquipment (ZI)V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public,static getArmorPosition (Lnet/minecraft/item/ItemStack;)I - -
 method public,static getArmorItemForSlot (II)Lnet/minecraft/item/Item; - -
 method protected setEnchantmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public canBeSteered ()Z - -
 method public enablePersistence ()V - -
 method public setEquipmentDropChance (IF)V - -
 method public canPickUpLoot ()Z - -
 method public setCanPickUpLoot (Z)V - -
 method public isNoDespawnRequired ()Z - -
 method public,final interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected updateLeashedState ()V - -
 method public clearLeashed (ZZ)V - -
 method public allowLeashing ()Z - -
 method public getLeashed ()Z - -
 method public getLeashedToEntity ()Lnet/minecraft/entity/Entity; - -
 method public setLeashedToEntity (Lnet/minecraft/entity/Entity;Z)V - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public isServerWorld ()Z - -
 method public setNoAI (Z)V - -
 method public isAIDisabled ()Z - -
in 91
class net/minecraft/entity/EntityLiving 50 public,super,abstract net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public livingSoundTime I -
 field protected experienceValue I -
 field protected moveHelper Lnet/minecraft/entity/ai/EntityMoveHelper; -
 field protected jumpHelper Lnet/minecraft/entity/ai/EntityJumpHelper; -
 field protected navigator Lnet/minecraft/pathfinding/PathNavigate; -
 field public,final tasks Lnet/minecraft/entity/ai/EntityAITasks; -
 field public,final targetTasks Lnet/minecraft/entity/ai/EntityAITasks; -
 field protected inventoryHandsDropChances [F -
 field protected inventoryArmorDropChances [F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected createNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method public getPathPriority (Lnet/minecraft/pathfinding/PathNodeType;)F - -
 method public setPathPriority (Lnet/minecraft/pathfinding/PathNodeType;F)V - -
 method protected createBodyHelper ()Lnet/minecraft/entity/EntityBodyHelper; - -
 method public getLookHelper ()Lnet/minecraft/entity/ai/EntityLookHelper; - -
 method public getMoveHelper ()Lnet/minecraft/entity/ai/EntityMoveHelper; - -
 method public getJumpHelper ()Lnet/minecraft/entity/ai/EntityJumpHelper; - -
 method public getNavigator ()Lnet/minecraft/pathfinding/PathNavigate; - -
 method public getEntitySenses ()Lnet/minecraft/entity/ai/EntitySenses; - -
 method public getAttackTarget ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public canAttackClass (Ljava/lang/Class;)Z (Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)Z -
 method public eatGrassBonus ()V - -
 method protected entityInit ()V - -
 method public getTalkInterval ()I - -
 method public playLivingSound ()V - -
 method public onEntityUpdate ()V - -
 method protected playHurtSound (Lnet/minecraft/util/DamageSource;)V - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public spawnExplosionParticle ()V - -
 method public handleStatusUpdate (B)V - -
 method public onUpdate ()V - -
 method protected updateDistance (FF)F - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public,static registerFixesMob (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method public,static registerFixesMob (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected dropLoot (ZILnet/minecraft/util/DamageSource;)V - -
 method public setMoveForward (F)V - -
 method public setMoveStrafing (F)V - -
 method public setAIMoveSpeed (F)V - -
 method public onLivingUpdate ()V - -
 method protected updateEquipmentIfNeeded (Lnet/minecraft/entity/item/EntityItem;)V - -
 method protected canEquipItem (Lnet/minecraft/item/ItemStack;)Z - -
 method protected canDespawn ()Z - -
 method protected despawnEntity ()V - -
 method protected,final updateEntityActionState ()V - -
 method protected updateAITasks ()V - -
 method public getVerticalFaceSpeed ()I - -
 method public getHorizontalFaceSpeed ()I - -
 method public faceEntity (Lnet/minecraft/entity/Entity;FF)V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getRenderSizeModifier ()F - -
 method public getMaxSpawnedInChunk ()I - -
 method public getMaxFallHeight ()I - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method protected dropEquipment (ZI)V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public,static getSlotForItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public,static getArmorByChance (Lnet/minecraft/inventory/EntityEquipmentSlot;I)Lnet/minecraft/item/Item; - -
 method protected setEnchantmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public canBeSteered ()Z - -
 method public enablePersistence ()V - -
 method public setDropChance (Lnet/minecraft/inventory/EntityEquipmentSlot;F)V - -
 method public canPickUpLoot ()Z - -
 method public setCanPickUpLoot (Z)V - -
 method public isNoDespawnRequired ()Z - -
 method public,final processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method protected processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected updateLeashedState ()V - -
 method public clearLeashed (ZZ)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getLeashed ()Z - -
 method public getLeashedToEntity ()Lnet/minecraft/entity/Entity; - -
 method public setLeashedToEntity (Lnet/minecraft/entity/Entity;Z)V - -
 method public startRiding (Lnet/minecraft/entity/Entity;Z)Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public,static isItemStackInSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)Z - -
 method public isServerWorld ()Z - -
 method public setNoAI (Z)V - -
 method public setLeftHanded (Z)V - -
 method public isAIDisabled ()Z - -
 method public isLeftHanded ()Z - -
 method public getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
in 326
class net/minecraft/entity/EntityLiving 52 public,super,abstract net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public livingSoundTime I -
 field protected experienceValue I -
 field protected moveHelper Lnet/minecraft/entity/ai/EntityMoveHelper; -
 field protected jumpHelper Lnet/minecraft/entity/ai/EntityJumpHelper; -
 field protected navigator Lnet/minecraft/pathfinding/PathNavigate; -
 field public,final tasks Lnet/minecraft/entity/ai/EntityAITasks; -
 field public,final targetTasks Lnet/minecraft/entity/ai/EntityAITasks; -
 field protected inventoryHandsDropChances [F -
 field protected inventoryArmorDropChances [F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected createNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method public getPathPriority (Lnet/minecraft/pathfinding/PathNodeType;)F - -
 method public setPathPriority (Lnet/minecraft/pathfinding/PathNodeType;F)V - -
 method protected createBodyHelper ()Lnet/minecraft/entity/EntityBodyHelper; - -
 method public getLookHelper ()Lnet/minecraft/entity/ai/EntityLookHelper; - -
 method public getMoveHelper ()Lnet/minecraft/entity/ai/EntityMoveHelper; - -
 method public getJumpHelper ()Lnet/minecraft/entity/ai/EntityJumpHelper; - -
 method public getNavigator ()Lnet/minecraft/pathfinding/PathNavigate; - -
 method public getEntitySenses ()Lnet/minecraft/entity/ai/EntitySenses; - -
 method public getAttackTarget ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public canAttackClass (Ljava/lang/Class;)Z (Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)Z -
 method public eatGrassBonus ()V - -
 method protected entityInit ()V - -
 method public getTalkInterval ()I - -
 method public playLivingSound ()V - -
 method public onEntityUpdate ()V - -
 method protected playHurtSound (Lnet/minecraft/util/DamageSource;)V - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public spawnExplosionParticle ()V - -
 method public handleStatusUpdate (B)V - -
 method public onUpdate ()V - -
 method protected updateDistance (FF)F - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public,static registerFixesMob (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class;)V (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class<*>;)V -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected dropLoot (ZILnet/minecraft/util/DamageSource;)V - -
 method public setMoveForward (F)V - -
 method public setMoveVertical (F)V - -
 method public setMoveStrafing (F)V - -
 method public setAIMoveSpeed (F)V - -
 method public onLivingUpdate ()V - -
 method protected updateEquipmentIfNeeded (Lnet/minecraft/entity/item/EntityItem;)V - -
 method protected canEquipItem (Lnet/minecraft/item/ItemStack;)Z - -
 method protected canDespawn ()Z - -
 method protected despawnEntity ()V - -
 method protected,final updateEntityActionState ()V - -
 method protected updateAITasks ()V - -
 method public getVerticalFaceSpeed ()I - -
 method public getHorizontalFaceSpeed ()I - -
 method public faceEntity (Lnet/minecraft/entity/Entity;FF)V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getRenderSizeModifier ()F - -
 method public getMaxSpawnedInChunk ()I - -
 method public getMaxFallHeight ()I - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method protected dropEquipment (ZI)V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public,static getSlotForItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public,static getArmorByChance (Lnet/minecraft/inventory/EntityEquipmentSlot;I)Lnet/minecraft/item/Item; - -
 method protected setEnchantmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public canBeSteered ()Z - -
 method public enablePersistence ()V - -
 method public setDropChance (Lnet/minecraft/inventory/EntityEquipmentSlot;F)V - -
 method public canPickUpLoot ()Z - -
 method public setCanPickUpLoot (Z)V - -
 method public isNoDespawnRequired ()Z - -
 method public,final processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected updateLeashedState ()V - -
 method public clearLeashed (ZZ)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getLeashed ()Z - -
 method public getLeashHolder ()Lnet/minecraft/entity/Entity; - -
 method public setLeashHolder (Lnet/minecraft/entity/Entity;Z)V - -
 method public startRiding (Lnet/minecraft/entity/Entity;Z)Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public canPassengerSteer ()Z - -
 method public,static isItemStackInSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)Z - -
 method public isServerWorld ()Z - -
 method public setNoAI (Z)V - -
 method public setLeftHanded (Z)V - -
 method public isAIDisabled ()Z - -
 method public isLeftHanded ()Z - -
 method public getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
in 24
class net/minecraft/entity/EntityLiving$SpawnPlacementType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;>;
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 field public,static,final,enum ON_GROUND Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 field public,static,final,enum IN_AIR Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 field public,static,final,enum IN_WATER Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 method public,static values ()[Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; - -
in 326
class net/minecraft/entity/EntityLiving$SpawnPlacementType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;>;
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 field public,static,final,enum ON_GROUND Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 field public,static,final,enum IN_AIR Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 field public,static,final,enum IN_WATER Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 method public,static values ()[Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; - -
 method public canSpawnAt (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 90
class net/minecraft/entity/EntityLivingBase 50 public,super,abstract net/minecraft/entity/Entity - -
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 field public isSwingInProgress Z -
 field public swingProgressInt I -
 field public arrowHitTimer I -
 field public hurtTime I -
 field public maxHurtTime I -
 field public attackedAtYaw F -
 field public deathTime I -
 field public prevSwingProgress F -
 field public swingProgress F -
 field public prevLimbSwingAmount F -
 field public limbSwingAmount F -
 field public limbSwing F -
 field public maxHurtResistantTime I -
 field public prevCameraPitch F -
 field public cameraPitch F -
 field public randomUnused2 F -
 field public randomUnused1 F -
 field public renderYawOffset F -
 field public prevRenderYawOffset F -
 field public rotationYawHead F -
 field public prevRotationYawHead F -
 field public jumpMovementFactor F -
 field protected attackingPlayer Lnet/minecraft/entity/player/EntityPlayer; -
 field protected recentlyHit I -
 field protected dead Z -
 field protected entityAge I -
 field protected prevOnGroundSpeedFactor F -
 field protected onGroundSpeedFactor F -
 field protected movedDistance F -
 field protected prevMovedDistance F -
 field protected unused180 F -
 field protected scoreValue I -
 field protected lastDamage F -
 field protected isJumping Z -
 field public moveStrafing F -
 field public moveForward F -
 field protected randomYawVelocity F -
 field protected newPosRotationIncrements I -
 field protected newPosX D -
 field protected newPosY D -
 field protected newPosZ D -
 field protected newRotationYaw D -
 field protected newRotationPitch D -
 method public onKillCommand ()V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method protected updateFallState (DZLnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;)V - -
 method public canBreatheUnderwater ()Z - -
 method public onEntityUpdate ()V - -
 method public isChild ()Z - -
 method protected onDeathUpdate ()V - -
 method protected canDropLoot ()Z - -
 method protected decreaseAirSupply (I)I - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method protected isPlayer ()Z - -
 method public getRNG ()Ljava/util/Random; - -
 method public getAITarget ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getRevengeTimer ()I - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getLastAttacker ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getLastAttackerTime ()I - -
 method public setLastAttacker (Lnet/minecraft/entity/Entity;)V - -
 method public getAge ()I - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected updatePotionEffects ()V - -
 method protected updatePotionMetadata ()V - -
 method protected resetPotionEffectMetadata ()V - -
 method public clearActivePotions ()V - -
 method public getActivePotionEffects ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>; -
 method public isPotionActive (I)Z - -
 method public isPotionActive (Lnet/minecraft/potion/Potion;)Z - -
 method public getActivePotionEffect (Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect; - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public isPotionApplicable (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public isEntityUndead ()Z - -
 method public removePotionEffectClient (I)V - -
 method public removePotionEffect (I)V - -
 method protected onNewPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected onChangedPotionEffect (Lnet/minecraft/potion/PotionEffect;Z)V - -
 method protected onFinishedPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public heal (F)V - -
 method public,final getHealth ()F - -
 method public setHealth (F)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public renderBrokenItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected dropEquipment (ZI)V - -
 method public knockBack (Lnet/minecraft/entity/Entity;FDD)V - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected addRandomDrop ()V - -
 method protected dropFewItems (ZI)V - -
 method public isOnLadder ()Z - -
 method public isEntityAlive ()Z - -
 method public fall (FF)V - -
 method protected getFallSoundString (I)Ljava/lang/String; - -
 method public performHurtAnimation ()V - -
 method public getTotalArmorValue ()I - -
 method protected damageArmor (F)V - -
 method protected applyArmorCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected applyPotionDamageCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected damageEntity (Lnet/minecraft/util/DamageSource;F)V - -
 method public getCombatTracker ()Lnet/minecraft/util/CombatTracker; - -
 method public getAttackingEntity ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public,final getMaxHealth ()F - -
 method public,final getArrowCountInEntity ()I - -
 method public,final setArrowCountInEntity (I)V - -
 method public swingItem ()V - -
 method public handleStatusUpdate (B)V - -
 method protected kill ()V - -
 method protected updateArmSwingProgress ()V - -
 method public getEntityAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAttributeMap ()Lnet/minecraft/entity/ai/attributes/BaseAttributeMap; - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public,abstract getHeldItem ()Lnet/minecraft/item/ItemStack; - -
 method public,abstract getEquipmentInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract getCurrentArmor (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract setCurrentItemOrArmor (ILnet/minecraft/item/ItemStack;)V - -
 method public setSprinting (Z)V - -
 method public,abstract getInventory ()[Lnet/minecraft/item/ItemStack; - -
 method protected getSoundVolume ()F - -
 method protected getSoundPitch ()F - -
 method protected isMovementBlocked ()Z - -
 method public dismountEntity (Lnet/minecraft/entity/Entity;)V - -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method protected getJumpUpwardsMotion ()F - -
 method protected jump ()V - -
 method protected updateAITick ()V - -
 method protected handleJumpLava ()V - -
 method public moveEntityWithHeading (FF)V - -
 method public getAIMoveSpeed ()F - -
 method public setAIMoveSpeed (F)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public isPlayerSleeping ()Z - -
 method public onUpdate ()V - -
 method protected updateDistance (FF)F - -
 method public onLivingUpdate ()V - -
 method protected updateEntityActionState ()V - -
 method protected collideWithNearbyEntities ()V - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method public mountEntity (Lnet/minecraft/entity/Entity;)V - -
 method public updateRidden ()V - -
 method public setPositionAndRotation2 (DDDFFIZ)V - -
 method public setJumping (Z)V - -
 method public onItemPickup (Lnet/minecraft/entity/Entity;I)V - -
 method public canEntityBeSeen (Lnet/minecraft/entity/Entity;)Z - -
 method public getLookVec ()Lnet/minecraft/util/Vec3; - -
 method public getLook (F)Lnet/minecraft/util/Vec3; - -
 method public getSwingProgress (F)F - -
 method public isServerWorld ()Z - -
 method public canBeCollidedWith ()Z - -
 method public canBePushed ()Z - -
 method protected setBeenAttacked ()V - -
 method public getRotationYawHead ()F - -
 method public setRotationYawHead (F)V - -
 method public setRenderYawOffset (F)V - -
 method public getAbsorptionAmount ()F - -
 method public setAbsorptionAmount (F)V - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public isOnSameTeam (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public isOnTeam (Lnet/minecraft/scoreboard/Team;)Z - -
 method public sendEnterCombat ()V - -
 method public sendEndCombat ()V - -
 method protected markPotionsDirty ()V - -
 method public curePotionEffects (Lnet/minecraft/item/ItemStack;)V - -
 method public shouldRiderFaceForward (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 91
class net/minecraft/entity/EntityLivingBase 50 public,super,abstract net/minecraft/entity/Entity - -
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 field protected,static,final HAND_STATES Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public isSwingInProgress Z -
 field public swingingHand Lnet/minecraft/util/EnumHand; -
 field public swingProgressInt I -
 field public arrowHitTimer I -
 field public hurtTime I -
 field public maxHurtTime I -
 field public attackedAtYaw F -
 field public deathTime I -
 field public prevSwingProgress F -
 field public swingProgress F -
 field protected ticksSinceLastSwing I -
 field public prevLimbSwingAmount F -
 field public limbSwingAmount F -
 field public limbSwing F -
 field public maxHurtResistantTime I -
 field public prevCameraPitch F -
 field public cameraPitch F -
 field public randomUnused2 F -
 field public randomUnused1 F -
 field public renderYawOffset F -
 field public prevRenderYawOffset F -
 field public rotationYawHead F -
 field public prevRotationYawHead F -
 field public jumpMovementFactor F -
 field protected attackingPlayer Lnet/minecraft/entity/player/EntityPlayer; -
 field protected recentlyHit I -
 field protected dead Z -
 field protected entityAge I -
 field protected prevOnGroundSpeedFactor F -
 field protected onGroundSpeedFactor F -
 field protected movedDistance F -
 field protected prevMovedDistance F -
 field protected unused180 F -
 field protected scoreValue I -
 field protected lastDamage F -
 field protected isJumping Z -
 field public moveStrafing F -
 field public moveForward F -
 field public randomYawVelocity F -
 field protected newPosRotationIncrements I -
 field protected interpTargetX D -
 field protected interpTargetY D -
 field protected interpTargetZ D -
 field protected interpTargetYaw D -
 field protected interpTargetPitch D -
 field protected activeItemStack Lnet/minecraft/item/ItemStack; -
 field protected activeItemStackUseCount I -
 field protected ticksElytraFlying I -
 method public onKillCommand ()V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public canBreatheUnderwater ()Z - -
 method public onEntityUpdate ()V - -
 method protected frostWalk (Lnet/minecraft/util/math/BlockPos;)V - -
 method public isChild ()Z - -
 method protected onDeathUpdate ()V - -
 method protected canDropLoot ()Z - -
 method protected decreaseAirSupply (I)I - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method protected isPlayer ()Z - -
 method public getRNG ()Ljava/util/Random; - -
 method public getAITarget ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getRevengeTimer ()I - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getLastAttacker ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getLastAttackerTime ()I - -
 method public setLastAttacker (Lnet/minecraft/entity/Entity;)V - -
 method public getAge ()I - -
 method protected playEquipSound (Lnet/minecraft/item/ItemStack;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected updatePotionEffects ()V - -
 method protected updatePotionMetadata ()V - -
 method public,static areAllPotionsAmbient (Ljava/util/Collection;)Z (Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)Z -
 method protected resetPotionEffectMetadata ()V - -
 method public clearActivePotions ()V - -
 method public getActivePotionEffects ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>; -
 method public isPotionActive (Lnet/minecraft/potion/Potion;)Z - -
 method public getActivePotionEffect (Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect; - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public isPotionApplicable (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public isEntityUndead ()Z - -
 method public removeActivePotionEffect (Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect; - -
 method public removePotionEffect (Lnet/minecraft/potion/Potion;)V - -
 method protected onNewPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected onChangedPotionEffect (Lnet/minecraft/potion/PotionEffect;Z)V - -
 method protected onFinishedPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public heal (F)V - -
 method public,final getHealth ()F - -
 method public setHealth (F)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getLastDamageSource ()Lnet/minecraft/util/DamageSource; - -
 method protected playHurtSound (Lnet/minecraft/util/DamageSource;)V - -
 method public renderBrokenItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected dropLoot (ZILnet/minecraft/util/DamageSource;)V - -
 method protected dropEquipment (ZI)V - -
 method public knockBack (Lnet/minecraft/entity/Entity;FDD)V - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method protected dropFewItems (ZI)V - -
 method public isOnLadder ()Z - -
 method public isEntityAlive ()Z - -
 method public fall (FF)V - -
 method public performHurtAnimation ()V - -
 method public getTotalArmorValue ()I - -
 method protected damageArmor (F)V - -
 method protected damageShield (F)V - -
 method protected applyArmorCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected applyPotionDamageCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected damageEntity (Lnet/minecraft/util/DamageSource;F)V - -
 method public getCombatTracker ()Lnet/minecraft/util/CombatTracker; - -
 method public getAttackingEntity ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public,final getMaxHealth ()F - -
 method public,final getArrowCountInEntity ()I - -
 method public,final setArrowCountInEntity (I)V - -
 method public swingArm (Lnet/minecraft/util/EnumHand;)V - -
 method public handleStatusUpdate (B)V - -
 method protected kill ()V - -
 method protected updateArmSwingProgress ()V - -
 method public getEntityAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAttributeMap ()Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap; - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public getHeldItemMainhand ()Lnet/minecraft/item/ItemStack; - -
 method public getHeldItemOffhand ()Lnet/minecraft/item/ItemStack; - -
 method public getHeldItem (Lnet/minecraft/util/EnumHand;)Lnet/minecraft/item/ItemStack; - -
 method public setHeldItem (Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)V - -
 method public,abstract getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public,abstract getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public,abstract setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public setSprinting (Z)V - -
 method protected getSoundVolume ()F - -
 method protected getSoundPitch ()F - -
 method protected isMovementBlocked ()Z - -
 method public dismountEntity (Lnet/minecraft/entity/Entity;)V - -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method protected getJumpUpwardsMotion ()F - -
 method protected jump ()V - -
 method protected handleJumpWater ()V - -
 method protected handleJumpLava ()V - -
 method protected getWaterSlowDown ()F - -
 method public moveEntityWithHeading (FF)V - -
 method public getAIMoveSpeed ()F - -
 method public setAIMoveSpeed (F)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public isPlayerSleeping ()Z - -
 method public onUpdate ()V - -
 method protected updateDistance (FF)F - -
 method public onLivingUpdate ()V - -
 method protected updateEntityActionState ()V - -
 method protected collideWithNearbyEntities ()V - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method public dismountRidingEntity ()V - -
 method public updateRidden ()V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public setJumping (Z)V - -
 method public onItemPickup (Lnet/minecraft/entity/Entity;I)V - -
 method public canEntityBeSeen (Lnet/minecraft/entity/Entity;)Z - -
 method public getLookVec ()Lnet/minecraft/util/math/Vec3d; - -
 method public getLook (F)Lnet/minecraft/util/math/Vec3d; - -
 method public getSwingProgress (F)F - -
 method public isServerWorld ()Z - -
 method public canBeCollidedWith ()Z - -
 method public canBePushed ()Z - -
 method protected setBeenAttacked ()V - -
 method public getRotationYawHead ()F - -
 method public setRotationYawHead (F)V - -
 method public setRenderYawOffset (F)V - -
 method public getAbsorptionAmount ()F - -
 method public setAbsorptionAmount (F)V - -
 method public sendEnterCombat ()V - -
 method public sendEndCombat ()V - -
 method protected markPotionsDirty ()V - -
 method public curePotionEffects (Lnet/minecraft/item/ItemStack;)V - -
 method public shouldRiderFaceForward (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
 method public isHandActive ()Z - -
 method public getActiveHand ()Lnet/minecraft/util/EnumHand; - -
 method protected updateActiveHand ()V - -
 method public setActiveHand (Lnet/minecraft/util/EnumHand;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method protected updateItemUse (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onItemUseFinish ()V - -
 method public getActiveItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public getItemInUseCount ()I - -
 method public getItemInUseMaxCount ()I - -
 method public stopActiveHand ()V - -
 method public resetActiveHand ()V - -
 method public isActiveItemStackBlocking ()Z - -
 method public isElytraFlying ()Z - -
 method public getTicksElytraFlying ()I - -
 method public attemptTeleport (DDD)Z - -
 method public canBeHitWithPotion ()Z - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 326
class net/minecraft/entity/EntityLivingBase 52 public,super,abstract net/minecraft/entity/Entity - -
 inner net/minecraftforge/event/entity/living/PotionEvent$PotionApplicableEvent net/minecraftforge/event/entity/living/PotionEvent PotionApplicableEvent public,static
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 inner net/minecraftforge/event/entity/living/PotionEvent$PotionExpiryEvent net/minecraftforge/event/entity/living/PotionEvent PotionExpiryEvent public,static
 inner net/minecraftforge/event/entity/living/PotionEvent$PotionRemoveEvent net/minecraftforge/event/entity/living/PotionEvent PotionRemoveEvent public,static
 inner net/minecraftforge/event/entity/living/PotionEvent$PotionAddedEvent net/minecraftforge/event/entity/living/PotionEvent PotionAddedEvent public,static
 inner net/minecraft/item/ItemArmor$ArmorMaterial net/minecraft/item/ItemArmor ArmorMaterial public,static,final,enum
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 field public,static,final SWIM_SPEED Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field protected,static,final HAND_STATES Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public isSwingInProgress Z -
 field public swingingHand Lnet/minecraft/util/EnumHand; -
 field public swingProgressInt I -
 field public arrowHitTimer I -
 field public hurtTime I -
 field public maxHurtTime I -
 field public attackedAtYaw F -
 field public deathTime I -
 field public prevSwingProgress F -
 field public swingProgress F -
 field protected ticksSinceLastSwing I -
 field public prevLimbSwingAmount F -
 field public limbSwingAmount F -
 field public limbSwing F -
 field public maxHurtResistantTime I -
 field public prevCameraPitch F -
 field public cameraPitch F -
 field public randomUnused2 F -
 field public randomUnused1 F -
 field public renderYawOffset F -
 field public prevRenderYawOffset F -
 field public rotationYawHead F -
 field public prevRotationYawHead F -
 field public jumpMovementFactor F -
 field protected attackingPlayer Lnet/minecraft/entity/player/EntityPlayer; -
 field protected recentlyHit I -
 field protected dead Z -
 field protected idleTime I -
 field protected prevOnGroundSpeedFactor F -
 field protected onGroundSpeedFactor F -
 field protected movedDistance F -
 field protected prevMovedDistance F -
 field protected unused180 F -
 field protected scoreValue I -
 field protected lastDamage F -
 field protected isJumping Z -
 field public moveStrafing F -
 field public moveVertical F -
 field public moveForward F -
 field public randomYawVelocity F -
 field protected newPosRotationIncrements I -
 field protected interpTargetX D -
 field protected interpTargetY D -
 field protected interpTargetZ D -
 field protected interpTargetYaw D -
 field protected interpTargetPitch D -
 field protected activeItemStack Lnet/minecraft/item/ItemStack; -
 field protected activeItemStackUseCount I -
 field protected ticksElytraFlying I -
 method public onKillCommand ()V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public canBreatheUnderwater ()Z - -
 method public onEntityUpdate ()V - -
 method protected frostWalk (Lnet/minecraft/util/math/BlockPos;)V - -
 method public isChild ()Z - -
 method protected onDeathUpdate ()V - -
 method protected canDropLoot ()Z - -
 method protected decreaseAirSupply (I)I - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method protected isPlayer ()Z - -
 method public getRNG ()Ljava/util/Random; - -
 method public getRevengeTarget ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getRevengeTimer ()I - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getLastAttackedEntity ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getLastAttackedEntityTime ()I - -
 method public setLastAttackedEntity (Lnet/minecraft/entity/Entity;)V - -
 method public getIdleTime ()I - -
 method protected playEquipSound (Lnet/minecraft/item/ItemStack;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected updatePotionEffects ()V - -
 method protected updatePotionMetadata ()V - -
 method public,static areAllPotionsAmbient (Ljava/util/Collection;)Z (Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>;)Z -
 method protected resetPotionEffectMetadata ()V - -
 method public clearActivePotions ()V - -
 method public getActivePotionEffects ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/potion/PotionEffect;>; -
 method public getActivePotionMap ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/potion/Potion;Lnet/minecraft/potion/PotionEffect;>; -
 method public isPotionActive (Lnet/minecraft/potion/Potion;)Z - -
 method public getActivePotionEffect (Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect; - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public isPotionApplicable (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public isEntityUndead ()Z - -
 method public removeActivePotionEffect (Lnet/minecraft/potion/Potion;)Lnet/minecraft/potion/PotionEffect; - -
 method public removePotionEffect (Lnet/minecraft/potion/Potion;)V - -
 method protected onNewPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected onChangedPotionEffect (Lnet/minecraft/potion/PotionEffect;Z)V - -
 method protected onFinishedPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public heal (F)V - -
 method public,final getHealth ()F - -
 method public setHealth (F)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected blockUsingShield (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getLastDamageSource ()Lnet/minecraft/util/DamageSource; - -
 method protected playHurtSound (Lnet/minecraft/util/DamageSource;)V - -
 method public renderBrokenItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected dropLoot (ZILnet/minecraft/util/DamageSource;)V - -
 method protected dropEquipment (ZI)V - -
 method public knockBack (Lnet/minecraft/entity/Entity;FDD)V - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method protected dropFewItems (ZI)V - -
 method public isOnLadder ()Z - -
 method public isEntityAlive ()Z - -
 method public fall (FF)V - -
 method public performHurtAnimation ()V - -
 method public getTotalArmorValue ()I - -
 method protected damageArmor (F)V - -
 method protected damageShield (F)V - -
 method protected applyArmorCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected applyPotionDamageCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected damageEntity (Lnet/minecraft/util/DamageSource;F)V - -
 method public getCombatTracker ()Lnet/minecraft/util/CombatTracker; - -
 method public getAttackingEntity ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public,final getMaxHealth ()F - -
 method public,final getArrowCountInEntity ()I - -
 method public,final setArrowCountInEntity (I)V - -
 method public swingArm (Lnet/minecraft/util/EnumHand;)V - -
 method public handleStatusUpdate (B)V - -
 method protected outOfWorld ()V - -
 method protected updateArmSwingProgress ()V - -
 method public getEntityAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAttributeMap ()Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap; - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public getHeldItemMainhand ()Lnet/minecraft/item/ItemStack; - -
 method public getHeldItemOffhand ()Lnet/minecraft/item/ItemStack; - -
 method public getHeldItem (Lnet/minecraft/util/EnumHand;)Lnet/minecraft/item/ItemStack; - -
 method public setHeldItem (Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)V - -
 method public hasItemInSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Z - -
 method public,abstract getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public,abstract getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public,abstract setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public setSprinting (Z)V - -
 method protected getSoundVolume ()F - -
 method protected getSoundPitch ()F - -
 method protected isMovementBlocked ()Z - -
 method public dismountEntity (Lnet/minecraft/entity/Entity;)V - -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method protected getJumpUpwardsMotion ()F - -
 method protected jump ()V - -
 method protected handleJumpWater ()V - -
 method protected handleJumpLava ()V - -
 method protected getWaterSlowDown ()F - -
 method public travel (FFF)V - -
 method public getAIMoveSpeed ()F - -
 method public setAIMoveSpeed (F)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public isPlayerSleeping ()Z - -
 method public onUpdate ()V - -
 method protected updateDistance (FF)F - -
 method public onLivingUpdate ()V - -
 method protected updateEntityActionState ()V - -
 method protected collideWithNearbyEntities ()V - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method public dismountRidingEntity ()V - -
 method public updateRidden ()V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public setJumping (Z)V - -
 method public onItemPickup (Lnet/minecraft/entity/Entity;I)V - -
 method public canEntityBeSeen (Lnet/minecraft/entity/Entity;)Z - -
 method public getLook (F)Lnet/minecraft/util/math/Vec3d; - -
 method public getSwingProgress (F)F - -
 method public isServerWorld ()Z - -
 method public canBeCollidedWith ()Z - -
 method public canBePushed ()Z - -
 method protected markVelocityChanged ()V - -
 method public getRotationYawHead ()F - -
 method public setRotationYawHead (F)V - -
 method public setRenderYawOffset (F)V - -
 method public getAbsorptionAmount ()F - -
 method public setAbsorptionAmount (F)V - -
 method public sendEnterCombat ()V - -
 method public sendEndCombat ()V - -
 method protected markPotionsDirty ()V - -
 method public curePotionEffects (Lnet/minecraft/item/ItemStack;)V - -
 method public shouldRiderFaceForward (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
 method public isHandActive ()Z - -
 method public getActiveHand ()Lnet/minecraft/util/EnumHand; - -
 method protected updateActiveHand ()V - -
 method public setActiveHand (Lnet/minecraft/util/EnumHand;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method protected updateItemUse (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onItemUseFinish ()V - -
 method public getActiveItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public getItemInUseCount ()I - -
 method public getItemInUseMaxCount ()I - -
 method public stopActiveHand ()V - -
 method public resetActiveHand ()V - -
 method public isActiveItemStackBlocking ()Z - -
 method public isElytraFlying ()Z - -
 method public getTicksElytraFlying ()I - -
 method public attemptTeleport (DDD)Z - -
 method public canBeHitWithPotion ()Z - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public attackable ()Z - -
 method public setPartying (Lnet/minecraft/util/math/BlockPos;Z)V - -
 method public moveRelative (FFFF)V - -
in 90
class net/minecraft/entity/EntityMinecartCommandBlock 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 inner net/minecraft/util/IChatComponent$Serializer net/minecraft/util/IChatComponent Serializer public,static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getCommandBlockLogic ()Lnet/minecraft/command/server/CommandBlockLogic; - -
 method public onActivatorRailPass (IIIZ)V - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onDataWatcherUpdate (I)V - -
in 90
class net/minecraft/entity/EntitySpawnPlacementRegistry 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 method public <init> ()V - -
 method public,static getPlacementForEntity (Ljava/lang/Class;)Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; - -
 method public,static setPlacementType (Ljava/lang/Class;Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;)V -
in 91
class net/minecraft/entity/EntitySpawnPlacementRegistry 50 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 method public <init> ()V - -
 method public,static getPlacementForEntity (Ljava/lang/Class;)Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; (Ljava/lang/Class<*>;)Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 method public,static setPlacementType (Ljava/lang/Class;Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;)V -
in 326
class net/minecraft/entity/EntitySpawnPlacementRegistry 52 public,super java/lang/Object - -
 inner net/minecraft/entity/EntityLiving$SpawnPlacementType net/minecraft/entity/EntityLiving SpawnPlacementType public,static,final,enum
 method public <init> ()V - -
 method public,static getPlacementForEntity (Ljava/lang/Class;)Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; (Ljava/lang/Class<*>;)Lnet/minecraft/entity/EntityLiving$SpawnPlacementType; -
 method public,static setPlacementType (Ljava/lang/Class;Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Lnet/minecraft/entity/EntityLiving$SpawnPlacementType;)V -
in 90
class net/minecraft/entity/EntityTracker 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/world/WorldServer;)V - -
 method public trackEntity (Lnet/minecraft/entity/Entity;)V - -
 method public trackEntity (Lnet/minecraft/entity/Entity;II)V - -
 method public addEntityToTracker (Lnet/minecraft/entity/Entity;IIZ)V - -
 method public untrackEntity (Lnet/minecraft/entity/Entity;)V - -
 method public updateTrackedEntities ()V - -
 method public func_180245_a (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public sendToAllTrackingEntity (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet;)V - -
 method public func_151248_b (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet;)V - -
 method public removePlayerFromTrackers (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public func_85172_a (Lnet/minecraft/entity/player/EntityPlayerMP;Lnet/minecraft/world/chunk/Chunk;)V - -
 method public getTrackingPlayers (Lnet/minecraft/entity/Entity;)Ljava/util/Set; (Lnet/minecraft/entity/Entity;)Ljava/util/Set<+Lnet/minecraft/entity/player/EntityPlayer;>; -
in 91
class net/minecraft/entity/EntityTracker 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/world/WorldServer;)V - -
 method public,static getPositionLong (D)J - -
 method public,static updateServerPosition (Lnet/minecraft/entity/Entity;DDD)V - -
 method public track (Lnet/minecraft/entity/Entity;)V - -
 method public track (Lnet/minecraft/entity/Entity;II)V - -
 method public track (Lnet/minecraft/entity/Entity;IIZ)V - -
 method public untrack (Lnet/minecraft/entity/Entity;)V - -
 method public tick ()V - -
 method public updateVisibility (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public sendToTracking (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet;)V (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet<*>;)V -
 method public getTrackingPlayers (Lnet/minecraft/entity/Entity;)Ljava/util/Set; (Lnet/minecraft/entity/Entity;)Ljava/util/Set<+Lnet/minecraft/entity/player/EntityPlayer;>; -
 method public sendToTrackingAndSelf (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet;)V (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet<*>;)V -
 method public removePlayerFromTrackers (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public sendLeashedEntitiesInChunk (Lnet/minecraft/entity/player/EntityPlayerMP;Lnet/minecraft/world/chunk/Chunk;)V - -
 method public setViewDistance (I)V - -
in 326
class net/minecraft/entity/EntityTracker 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/world/WorldServer;)V - -
 method public,static getPositionLong (D)J - -
 method public,static updateServerPosition (Lnet/minecraft/entity/Entity;DDD)V - -
 method public track (Lnet/minecraft/entity/Entity;)V - -
 method public track (Lnet/minecraft/entity/Entity;II)V - -
 method public track (Lnet/minecraft/entity/Entity;IIZ)V - -
 method public untrack (Lnet/minecraft/entity/Entity;)V - -
 method public tick ()V - -
 method public updateVisibility (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public sendToTracking (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet;)V (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet<*>;)V -
 method public getTrackingPlayers (Lnet/minecraft/entity/Entity;)Ljava/util/Set; (Lnet/minecraft/entity/Entity;)Ljava/util/Set<+Lnet/minecraft/entity/player/EntityPlayer;>; -
 method public sendToTrackingAndSelf (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet;)V (Lnet/minecraft/entity/Entity;Lnet/minecraft/network/Packet<*>;)V -
 method public removePlayerFromTrackers (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public sendLeashedEntitiesInChunk (Lnet/minecraft/entity/player/EntityPlayerMP;Lnet/minecraft/world/chunk/Chunk;)V - -
 method public setViewDistance (I)V - -
in 90
class net/minecraft/entity/EntityTrackerEntry 50 public,super java/lang/Object - -
 inner net/minecraft/network/play/server/S14PacketEntity$S15PacketEntityRelMove net/minecraft/network/play/server/S14PacketEntity S15PacketEntityRelMove public,static
 inner net/minecraft/network/play/server/S14PacketEntity$S16PacketEntityLook net/minecraft/network/play/server/S14PacketEntity S16PacketEntityLook public,static
 inner net/minecraft/network/play/server/S14PacketEntity$S17PacketEntityLookMove net/minecraft/network/play/server/S14PacketEntity S17PacketEntityLookMove public,static
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 field public trackedEntity Lnet/minecraft/entity/Entity; -
 field public trackingDistanceThreshold I -
 field public updateFrequency I -
 field public encodedPosX I -
 field public encodedPosY I -
 field public encodedPosZ I -
 field public encodedRotationYaw I -
 field public encodedRotationPitch I -
 field public lastHeadMotion I -
 field public lastTrackedEntityMotionX D -
 field public lastTrackedEntityMotionY D -
 field public motionZ D -
 field public updateCounter I -
 field public playerEntitiesUpdated Z -
 field public trackingPlayers Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/entity/player/EntityPlayerMP;>;
 method public <init> (Lnet/minecraft/entity/Entity;IIZ)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public updatePlayerList (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)V -
 method public sendPacketToTrackedPlayers (Lnet/minecraft/network/Packet;)V - -
 method public func_151261_b (Lnet/minecraft/network/Packet;)V - -
 method public sendDestroyEntityPacketToTrackedPlayers ()V - -
 method public removeFromTrackedPlayers (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public updatePlayerEntity (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public func_180233_c (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public updatePlayerEntities (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)V -
 method public removeTrackedPlayerSymmetric (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
in 91
class net/minecraft/entity/EntityTrackerEntry 50 public,super java/lang/Object - -
 inner net/minecraft/network/play/server/SPacketEntity$S16PacketEntityLook net/minecraft/network/play/server/SPacketEntity S16PacketEntityLook public,static
 inner net/minecraft/network/play/server/SPacketEntity$S15PacketEntityRelMove net/minecraft/network/play/server/SPacketEntity S15PacketEntityRelMove public,static
 inner net/minecraft/network/play/server/SPacketEntity$S17PacketEntityLookMove net/minecraft/network/play/server/SPacketEntity S17PacketEntityLookMove public,static
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public updateCounter I -
 field public playerEntitiesUpdated Z -
 field public,final trackingPlayers Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/entity/player/EntityPlayerMP;>;
 method public <init> (Lnet/minecraft/entity/Entity;IIIZ)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public updatePlayerList (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)V -
 method public sendPacketToTrackedPlayers (Lnet/minecraft/network/Packet;)V (Lnet/minecraft/network/Packet<*>;)V -
 method public sendToTrackingAndSelf (Lnet/minecraft/network/Packet;)V (Lnet/minecraft/network/Packet<*>;)V -
 method public sendDestroyEntityPacketToTrackedPlayers ()V - -
 method public removeFromTrackedPlayers (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public updatePlayerEntity (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public isVisibleTo (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public updatePlayerEntities (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)V -
 method public removeTrackedPlayerSymmetric (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public getTrackedEntity ()Lnet/minecraft/entity/Entity; - -
 method public setMaxRange (I)V - -
 method public resetPlayerVisibility ()V - -
in 326
class net/minecraft/entity/EntityTrackerEntry 52 public,super java/lang/Object - -
 inner net/minecraft/network/play/server/SPacketEntity$S16PacketEntityLook net/minecraft/network/play/server/SPacketEntity S16PacketEntityLook public,static
 inner net/minecraft/network/play/server/SPacketEntity$S15PacketEntityRelMove net/minecraft/network/play/server/SPacketEntity S15PacketEntityRelMove public,static
 inner net/minecraft/network/play/server/SPacketEntity$S17PacketEntityLookMove net/minecraft/network/play/server/SPacketEntity S17PacketEntityLookMove public,static
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public updateCounter I -
 field public playerEntitiesUpdated Z -
 field public,final trackingPlayers Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/entity/player/EntityPlayerMP;>;
 method public <init> (Lnet/minecraft/entity/Entity;IIIZ)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public updatePlayerList (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)V -
 method public sendPacketToTrackedPlayers (Lnet/minecraft/network/Packet;)V (Lnet/minecraft/network/Packet<*>;)V -
 method public sendToTrackingAndSelf (Lnet/minecraft/network/Packet;)V (Lnet/minecraft/network/Packet<*>;)V -
 method public sendDestroyEntityPacketToTrackedPlayers ()V - -
 method public removeFromTrackedPlayers (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public updatePlayerEntity (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public isVisibleTo (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public updatePlayerEntities (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/entity/player/EntityPlayer;>;)V -
 method public removeTrackedPlayerSymmetric (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public getTrackedEntity ()Lnet/minecraft/entity/Entity; - -
 method public setMaxRange (I)V - -
 method public resetPlayerVisibility ()V - -
in 24
class net/minecraft/entity/EnumCreatureAttribute 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/EnumCreatureAttribute;>;
 field public,static,final,enum UNDEFINED Lnet/minecraft/entity/EnumCreatureAttribute; -
 field public,static,final,enum UNDEAD Lnet/minecraft/entity/EnumCreatureAttribute; -
 field public,static,final,enum ARTHROPOD Lnet/minecraft/entity/EnumCreatureAttribute; -
 method public,static values ()[Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 326
class net/minecraft/entity/EnumCreatureAttribute 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/EnumCreatureAttribute;>;
 field public,static,final,enum UNDEFINED Lnet/minecraft/entity/EnumCreatureAttribute; -
 field public,static,final,enum UNDEAD Lnet/minecraft/entity/EnumCreatureAttribute; -
 field public,static,final,enum ARTHROPOD Lnet/minecraft/entity/EnumCreatureAttribute; -
 field public,static,final,enum ILLAGER Lnet/minecraft/entity/EnumCreatureAttribute; -
 method public,static values ()[Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 24
class net/minecraft/entity/EnumCreatureType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/EnumCreatureType;>;
 field public,static,final,enum MONSTER Lnet/minecraft/entity/EnumCreatureType; -
 field public,static,final,enum CREATURE Lnet/minecraft/entity/EnumCreatureType; -
 field public,static,final,enum AMBIENT Lnet/minecraft/entity/EnumCreatureType; -
 field public,static,final,enum WATER_CREATURE Lnet/minecraft/entity/EnumCreatureType; -
 method public,static values ()[Lnet/minecraft/entity/EnumCreatureType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/EnumCreatureType; - -
 method public getCreatureClass ()Ljava/lang/Class; ()Ljava/lang/Class<+Lnet/minecraft/entity/passive/IAnimals;>; -
 method public getMaxNumberOfCreature ()I - -
 method public getPeacefulCreature ()Z - -
 method public getAnimal ()Z - -
in 326
class net/minecraft/entity/EnumCreatureType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/EnumCreatureType;>;
 field public,static,final,enum MONSTER Lnet/minecraft/entity/EnumCreatureType; -
 field public,static,final,enum CREATURE Lnet/minecraft/entity/EnumCreatureType; -
 field public,static,final,enum AMBIENT Lnet/minecraft/entity/EnumCreatureType; -
 field public,static,final,enum WATER_CREATURE Lnet/minecraft/entity/EnumCreatureType; -
 method public,static values ()[Lnet/minecraft/entity/EnumCreatureType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/EnumCreatureType; - -
 method public getCreatureClass ()Ljava/lang/Class; ()Ljava/lang/Class<+Lnet/minecraft/entity/passive/IAnimals;>; -
 method public getMaxNumberOfCreature ()I - -
 method public getPeacefulCreature ()Z - -
 method public getAnimal ()Z - -
in 24
class net/minecraft/entity/IEntityLivingData 50 public,interface,abstract java/lang/Object - -
in 326
class net/minecraft/entity/IEntityLivingData 52 public,interface,abstract java/lang/Object - -
in 24
class net/minecraft/entity/IEntityMultiPart 50 public,interface,abstract java/lang/Object - -
 method public,abstract getWorld ()Lnet/minecraft/world/World; - -
 method public,abstract attackEntityFromPart (Lnet/minecraft/entity/boss/EntityDragonPart;Lnet/minecraft/util/DamageSource;F)Z - -
in 326
class net/minecraft/entity/IEntityMultiPart 52 public,interface,abstract java/lang/Object - -
 method public,abstract getWorld ()Lnet/minecraft/world/World; - -
 method public,abstract attackEntityFromPart (Lnet/minecraft/entity/MultiPartEntityPart;Lnet/minecraft/util/DamageSource;F)Z - -
in 90
class net/minecraft/entity/IEntityOwnable 50 public,interface,abstract java/lang/Object - -
 method public,abstract getOwnerId ()Ljava/lang/String; - -
 method public,abstract getOwner ()Lnet/minecraft/entity/Entity; - -
in 91
class net/minecraft/entity/IEntityOwnable 50 public,interface,abstract java/lang/Object - -
 method public,abstract getOwnerId ()Ljava/util/UUID; - -
 method public,abstract getOwner ()Lnet/minecraft/entity/Entity; - -
in 326
class net/minecraft/entity/IEntityOwnable 52 public,interface,abstract java/lang/Object - -
 method public,abstract getOwnerId ()Ljava/util/UUID; - -
 method public,abstract getOwner ()Lnet/minecraft/entity/Entity; - -
in 91
class net/minecraft/entity/IJumpingMount 50 public,interface,abstract java/lang/Object - -
 method public,abstract setJumpPower (I)V - -
 method public,abstract canJump ()Z - -
 method public,abstract handleStartJump (I)V - -
 method public,abstract handleStopJump ()V - -
in 326
class net/minecraft/entity/IJumpingMount 52 public,interface,abstract java/lang/Object - -
 method public,abstract setJumpPower (I)V - -
 method public,abstract canJump ()Z - -
 method public,abstract handleStartJump (I)V - -
 method public,abstract handleStopJump ()V - -
in 90
class net/minecraft/entity/IMerchant 50 public,interface,abstract java/lang/Object - -
 method public,abstract setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public,abstract setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public,abstract getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public,abstract useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public,abstract verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public,abstract getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
in 91
class net/minecraft/entity/IMerchant 50 public,interface,abstract java/lang/Object - -
 method public,abstract setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public,abstract setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public,abstract getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public,abstract useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public,abstract verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public,abstract getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
in 326
class net/minecraft/entity/IMerchant 52 public,interface,abstract java/lang/Object - -
 method public,abstract setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public,abstract getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public,abstract setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public,abstract useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public,abstract verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public,abstract getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public,abstract getWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getPos ()Lnet/minecraft/util/math/BlockPos; - -
in 24
class net/minecraft/entity/INpc 50 public,interface,abstract java/lang/Object net/minecraft/entity/passive/IAnimals -
in 326
class net/minecraft/entity/INpc 52 public,interface,abstract java/lang/Object net/minecraft/entity/passive/IAnimals -
in 24
class net/minecraft/entity/IProjectile 50 public,interface,abstract java/lang/Object - -
 method public,abstract setThrowableHeading (DDDFF)V - -
in 326
class net/minecraft/entity/IProjectile 52 public,interface,abstract java/lang/Object - -
 method public,abstract shoot (DDDFF)V - -
in 24
class net/minecraft/entity/IRangedAttackMob 50 public,interface,abstract java/lang/Object - -
 method public,abstract attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
in 326
class net/minecraft/entity/IRangedAttackMob 52 public,interface,abstract java/lang/Object - -
 method public,abstract attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public,abstract setSwingingArms (Z)V - -
in 326
class net/minecraft/entity/MoverType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/MoverType;>;
 field public,static,final,enum SELF Lnet/minecraft/entity/MoverType; -
 field public,static,final,enum PLAYER Lnet/minecraft/entity/MoverType; -
 field public,static,final,enum PISTON Lnet/minecraft/entity/MoverType; -
 field public,static,final,enum SHULKER_BOX Lnet/minecraft/entity/MoverType; -
 field public,static,final,enum SHULKER Lnet/minecraft/entity/MoverType; -
 method public,static values ()[Lnet/minecraft/entity/MoverType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/MoverType; - -
in 326
class net/minecraft/entity/MultiPartEntityPart 52 public,super net/minecraft/entity/Entity - -
 field public,final parent Lnet/minecraft/entity/IEntityMultiPart; -
 field public,final partName Ljava/lang/String; -
 method public <init> (Lnet/minecraft/entity/IEntityMultiPart;Ljava/lang/String;FF)V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public isEntityEqual (Lnet/minecraft/entity/Entity;)Z - -
in 90
class net/minecraft/entity/NpcMerchant 50 public,super java/lang/Object net/minecraft/entity/IMerchant -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/IChatComponent;)V - -
 method public getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
in 91
class net/minecraft/entity/NpcMerchant 50 public,super java/lang/Object net/minecraft/entity/IMerchant -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/text/ITextComponent;)V - -
 method public getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
in 326
class net/minecraft/entity/NpcMerchant 52 public,super java/lang/Object net/minecraft/entity/IMerchant -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/text/ITextComponent;)V - -
 method public getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public getPos ()Lnet/minecraft/util/math/BlockPos; - -
in 90
class net/minecraft/entity/SharedMonsterAttributes 50 public,super java/lang/Object - -
 field public,static,final maxHealth Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final followRange Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final knockbackResistance Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final movementSpeed Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final attackDamage Lnet/minecraft/entity/ai/attributes/IAttribute; -
 method public,static writeBaseAttributeMapToNBT (Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;)Lnet/minecraft/nbt/NBTTagList; - -
 method public,static setAttributeModifiers (Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;Lnet/minecraft/nbt/NBTTagList;)V - -
 method public,static readAttributeModifierFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
in 91
class net/minecraft/entity/SharedMonsterAttributes 50 public,super java/lang/Object - -
 field public,static,final MAX_HEALTH Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final FOLLOW_RANGE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final KNOCKBACK_RESISTANCE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final MOVEMENT_SPEED Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ATTACK_DAMAGE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ATTACK_SPEED Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ARMOR Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ARMOR_TOUGHNESS Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final LUCK Lnet/minecraft/entity/ai/attributes/IAttribute; -
 method public <init> ()V - -
 method public,static writeBaseAttributeMapToNBT (Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;)Lnet/minecraft/nbt/NBTTagList; - -
 method public,static writeAttributeModifierToNBT (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static setAttributeModifiers (Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;Lnet/minecraft/nbt/NBTTagList;)V - -
 method public,static readAttributeModifierFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
in 326
class net/minecraft/entity/SharedMonsterAttributes 52 public,super java/lang/Object - -
 field public,static,final MAX_HEALTH Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final FOLLOW_RANGE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final KNOCKBACK_RESISTANCE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final MOVEMENT_SPEED Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final FLYING_SPEED Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ATTACK_DAMAGE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ATTACK_SPEED Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ARMOR Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final ARMOR_TOUGHNESS Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public,static,final LUCK Lnet/minecraft/entity/ai/attributes/IAttribute; -
 method public <init> ()V - -
 method public,static writeBaseAttributeMapToNBT (Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;)Lnet/minecraft/nbt/NBTTagList; - -
 method public,static writeAttributeModifierToNBT (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static setAttributeModifiers (Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;Lnet/minecraft/nbt/NBTTagList;)V - -
 method public,static readAttributeModifierFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
in 90
class net/minecraft/entity/ai/EntityAIArrowAttack 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/IRangedAttackMob;DIF)V - -
 method public <init> (Lnet/minecraft/entity/IRangedAttackMob;DIIF)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/ai/EntityAIAttackMelee 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 field protected attacker Lnet/minecraft/entity/EntityCreature; -
 field protected attackTick I -
 field protected,final attackInterval I - I20
 method public <init> (Lnet/minecraft/entity/EntityCreature;DZ)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected checkAndPerformAttack (Lnet/minecraft/entity/EntityLivingBase;D)V - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 326
class net/minecraft/entity/ai/EntityAIAttackMelee 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 field protected attacker Lnet/minecraft/entity/EntityCreature; -
 field protected attackTick I -
 field protected,final attackInterval I - I20
 method public <init> (Lnet/minecraft/entity/EntityCreature;DZ)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected checkAndPerformAttack (Lnet/minecraft/entity/EntityLivingBase;D)V - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 90
class net/minecraft/entity/ai/EntityAIAttackOnCollide 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 field protected attacker Lnet/minecraft/entity/EntityCreature; -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;DZ)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;DZ)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DZ)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected func_179512_a (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 91
class net/minecraft/entity/ai/EntityAIAttackRanged 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/IRangedAttackMob;DIF)V - -
 method public <init> (Lnet/minecraft/entity/IRangedAttackMob;DIIF)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIAttackRanged 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/IRangedAttackMob;DIF)V - -
 method public <init> (Lnet/minecraft/entity/IRangedAttackMob;DIIF)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/ai/EntityAIAttackRangedBow 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/monster/EntitySkeleton;DIF)V - -
 method public setAttackCooldown (I)V - -
 method public shouldExecute ()Z - -
 method protected isBowInMainhand ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIAttackRangedBow 52 public,super net/minecraft/entity/ai/EntityAIBase - <T:Lnet/minecraft/entity/monster/EntityMob;:Lnet/minecraft/entity/IRangedAttackMob;>Lnet/minecraft/entity/ai/EntityAIBase;
 method public <init> (Lnet/minecraft/entity/monster/EntityMob;DIF)V (TT;DIF)V -
 method public setAttackCooldown (I)V - -
 method public shouldExecute ()Z - -
 method protected isBowInMainhand ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIAvoidEntity 50 public,super net/minecraft/entity/ai/EntityAIBase - <T:Lnet/minecraft/entity/Entity;>Lnet/minecraft/entity/ai/EntityAIBase;
 field protected theEntity Lnet/minecraft/entity/EntityCreature; -
 field protected closestLivingEntity Lnet/minecraft/entity/Entity; TT;
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;FDD)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;FDD)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;Lcom/google/common/base/Predicate;FDD)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;Lcom/google/common/base/Predicate<-TT;>;FDD)V -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIAvoidEntity 52 public,super net/minecraft/entity/ai/EntityAIBase - <T:Lnet/minecraft/entity/Entity;>Lnet/minecraft/entity/ai/EntityAIBase;
 field protected entity Lnet/minecraft/entity/EntityCreature; -
 field protected closestLivingEntity Lnet/minecraft/entity/Entity; TT;
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;FDD)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;FDD)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;Lcom/google/common/base/Predicate;FDD)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;Lcom/google/common/base/Predicate<-TT;>;FDD)V -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIBase 50 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public isInterruptible ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method public setMutexBits (I)V - -
 method public getMutexBits ()I - -
in 326
class net/minecraft/entity/ai/EntityAIBase 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public isInterruptible ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method public setMutexBits (I)V - -
 method public getMutexBits ()I - -
in 24
class net/minecraft/entity/ai/EntityAIBeg 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityWolf;F)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIBeg 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityWolf;F)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIBreakDoor 50 public,super net/minecraft/entity/ai/EntityAIDoorInteract - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public continueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIBreakDoor 52 public,super net/minecraft/entity/ai/EntityAIDoorInteract - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public shouldContinueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/ai/EntityAIControlledByPlayer 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;F)V - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
 method public isSpeedBoosted ()Z - -
 method public boostSpeed ()V - -
 method public isControlledByPlayer ()Z - -
in 24
class net/minecraft/entity/ai/EntityAICreeperSwell 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/monster/EntityCreeper;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAICreeperSwell 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/monster/EntityCreeper;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIDefendVillage 50 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public <init> (Lnet/minecraft/entity/monster/EntityIronGolem;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAIDefendVillage 52 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public <init> (Lnet/minecraft/entity/monster/EntityIronGolem;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 90
class net/minecraft/entity/ai/EntityAIDoorInteract 50 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected theEntity Lnet/minecraft/entity/EntityLiving; -
 field protected doorPosition Lnet/minecraft/util/BlockPos; -
 field protected doorBlock Lnet/minecraft/block/BlockDoor; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/ai/EntityAIDoorInteract 50 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected theEntity Lnet/minecraft/entity/EntityLiving; -
 field protected doorPosition Lnet/minecraft/util/math/BlockPos; -
 field protected doorBlock Lnet/minecraft/block/BlockDoor; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIDoorInteract 52 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected entity Lnet/minecraft/entity/EntityLiving; -
 field protected doorPosition Lnet/minecraft/util/math/BlockPos; -
 field protected doorBlock Lnet/minecraft/block/BlockDoor; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIEatGrass 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/block/BlockTallGrass$EnumType net/minecraft/block/BlockTallGrass EnumType public,static,final,enum
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public continueExecuting ()Z - -
 method public getEatingGrassTimer ()I - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIEatGrass 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/block/BlockTallGrass$EnumType net/minecraft/block/BlockTallGrass EnumType public,static,final,enum
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public shouldContinueExecuting ()Z - -
 method public getEatingGrassTimer ()I - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIFindEntityNearest 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)V -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method protected getFollowRange ()D - -
in 326
class net/minecraft/entity/ai/EntityAIFindEntityNearest 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)V -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method protected getFollowRange ()D - -
in 24
class net/minecraft/entity/ai/EntityAIFindEntityNearestPlayer 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method protected maxTargetRange ()D - -
in 326
class net/minecraft/entity/ai/EntityAIFindEntityNearestPlayer 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method protected maxTargetRange ()D - -
in 24
class net/minecraft/entity/ai/EntityAIFleeSun 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAIFleeSun 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAIFollow 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;DFF)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIFollowGolem 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIFollowGolem 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIFollowOwner 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;DFF)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIFollowOwner 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;DFF)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected isTeleportFriendlyBlock (IIIII)Z - -
in 326
class net/minecraft/entity/ai/EntityAIFollowOwnerFlying 52 public,super net/minecraft/entity/ai/EntityAIFollowOwner - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;DFF)V - -
 method protected isTeleportFriendlyBlock (IIIII)Z - -
in 24
class net/minecraft/entity/ai/EntityAIFollowParent 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityAnimal;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIFollowParent 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityAnimal;D)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/ai/EntityAIHarvestFarmland 50 public,super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Z - -
in 91
class net/minecraft/entity/ai/EntityAIHarvestFarmland 50 public,super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 326
class net/minecraft/entity/ai/EntityAIHarvestFarmland 52 public,super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;D)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 90
class net/minecraft/entity/ai/EntityAIHurtByTarget 50 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public,varargs <init> (Lnet/minecraft/entity/EntityCreature;Z[Ljava/lang/Class;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method protected setEntityAttackTarget (Lnet/minecraft/entity/EntityCreature;Lnet/minecraft/entity/EntityLivingBase;)V - -
in 91
class net/minecraft/entity/ai/EntityAIHurtByTarget 50 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public,varargs <init> (Lnet/minecraft/entity/EntityCreature;Z[Ljava/lang/Class;)V (Lnet/minecraft/entity/EntityCreature;Z[Ljava/lang/Class<*>;)V -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method protected alertOthers ()V - -
 method protected setEntityAttackTarget (Lnet/minecraft/entity/EntityCreature;Lnet/minecraft/entity/EntityLivingBase;)V - -
in 326
class net/minecraft/entity/ai/EntityAIHurtByTarget 52 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public,varargs <init> (Lnet/minecraft/entity/EntityCreature;Z[Ljava/lang/Class;)V (Lnet/minecraft/entity/EntityCreature;Z[Ljava/lang/Class<*>;)V -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method protected alertOthers ()V - -
 method protected setEntityAttackTarget (Lnet/minecraft/entity/EntityCreature;Lnet/minecraft/entity/EntityLivingBase;)V - -
in 326
class net/minecraft/entity/ai/EntityAILandOnOwnersShoulder 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityShoulderRiding;)V - -
 method public shouldExecute ()Z - -
 method public isInterruptible ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAILeapAtTarget 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;F)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAILeapAtTarget 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;F)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAILlamaFollowCaravan 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 field public llama Lnet/minecraft/entity/passive/EntityLlama; -
 method public <init> (Lnet/minecraft/entity/passive/EntityLlama;D)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAILookAtTradePlayer 50 public,super net/minecraft/entity/ai/EntityAIWatchClosest - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
in 326
class net/minecraft/entity/ai/EntityAILookAtTradePlayer 52 public,super net/minecraft/entity/ai/EntityAIWatchClosest - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
in 24
class net/minecraft/entity/ai/EntityAILookAtVillager 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/monster/EntityIronGolem;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAILookAtVillager 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/monster/EntityIronGolem;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAILookIdle 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAILookIdle 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIMate 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityAnimal;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIMate 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityAnimal;D)V - -
 method public <init> (Lnet/minecraft/entity/passive/EntityAnimal;DLjava/lang/Class;)V (Lnet/minecraft/entity/passive/EntityAnimal;DLjava/lang/Class<+Lnet/minecraft/entity/passive/EntityAnimal;>;)V -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIMoveIndoors 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIMoveIndoors 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIMoveThroughVillage 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DZ)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIMoveThroughVillage 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DZ)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 90
class net/minecraft/entity/ai/EntityAIMoveToBlock 50 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected runDelay I -
 field protected destinationBlock Lnet/minecraft/util/BlockPos; -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DI)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected getIsAboveDestination ()Z - -
 method protected,abstract shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Z - -
in 91
class net/minecraft/entity/ai/EntityAIMoveToBlock 50 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected runDelay I -
 field protected destinationBlock Lnet/minecraft/util/math/BlockPos; -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DI)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected getIsAboveDestination ()Z - -
 method protected,abstract shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 326
class net/minecraft/entity/ai/EntityAIMoveToBlock 52 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected runDelay I -
 field protected destinationBlock Lnet/minecraft/util/math/BlockPos; -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DI)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
 method protected getIsAboveDestination ()Z - -
 method protected,abstract shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 24
class net/minecraft/entity/ai/EntityAIMoveTowardsRestriction 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAIMoveTowardsRestriction 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
in 24
class net/minecraft/entity/ai/EntityAIMoveTowardsTarget 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DF)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public resetTask ()V - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAIMoveTowardsTarget 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DF)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public resetTask ()V - -
 method public startExecuting ()V - -
in 90
class net/minecraft/entity/ai/EntityAINearestAttackableTarget 50 public,super net/minecraft/entity/ai/EntityAITarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAITarget;
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 field protected,final targetClass Ljava/lang/Class; Ljava/lang/Class<TT;>;
 field protected,final theNearestAttackableTargetSorter Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter; -
 field protected targetEntitySelector Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<-TT;>;
 field protected targetEntity Lnet/minecraft/entity/EntityLivingBase; -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;Z)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;Z)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;ZZ)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;ZZ)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;IZZLcom/google/common/base/Predicate;)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;IZZLcom/google/common/base/Predicate<-TT;>;)V -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 91
class net/minecraft/entity/ai/EntityAINearestAttackableTarget 50 public,super net/minecraft/entity/ai/EntityAITarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAITarget;
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 field protected,final targetClass Ljava/lang/Class; Ljava/lang/Class<TT;>;
 field protected,final theNearestAttackableTargetSorter Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter; -
 field protected,final targetEntitySelector Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<-TT;>;
 field protected targetEntity Lnet/minecraft/entity/EntityLivingBase; TT;
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;Z)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;Z)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;ZZ)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;ZZ)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;IZZLcom/google/common/base/Predicate;)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;IZZLcom/google/common/base/Predicate<-TT;>;)V -
 method public shouldExecute ()Z - -
 method protected getTargetableArea (D)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAINearestAttackableTarget 52 public,super net/minecraft/entity/ai/EntityAITarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAITarget;
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 field protected,final targetClass Ljava/lang/Class; Ljava/lang/Class<TT;>;
 field protected,final sorter Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter; -
 field protected,final targetEntitySelector Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<-TT;>;
 field protected targetEntity Lnet/minecraft/entity/EntityLivingBase; TT;
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;Z)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;Z)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;ZZ)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;ZZ)V -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;IZZLcom/google/common/base/Predicate;)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;IZZLcom/google/common/base/Predicate<-TT;>;)V -
 method public shouldExecute ()Z - -
 method protected getTargetableArea (D)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public startExecuting ()V - -
in 24
class net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter 50 public,super java/lang/Object java/util/Comparator Ljava/lang/Object;Ljava/util/Comparator<Lnet/minecraft/entity/Entity;>;
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 method public <init> (Lnet/minecraft/entity/Entity;)V - -
 method public compare (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/Entity;)I - -
in 326
class net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter 52 public,super java/lang/Object java/util/Comparator Ljava/lang/Object;Ljava/util/Comparator<Lnet/minecraft/entity/Entity;>;
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 method public <init> (Lnet/minecraft/entity/Entity;)V - -
 method public compare (Lnet/minecraft/entity/Entity;Lnet/minecraft/entity/Entity;)I - -
in 24
class net/minecraft/entity/ai/EntityAIOcelotAttack 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIOcelotAttack 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/ai/EntityAIOcelotSit 50 public,super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 inner net/minecraft/block/BlockBed$EnumPartType net/minecraft/block/BlockBed EnumPartType public,static,final,enum
 method public <init> (Lnet/minecraft/entity/passive/EntityOcelot;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Z - -
in 91
class net/minecraft/entity/ai/EntityAIOcelotSit 50 public,super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 inner net/minecraft/block/BlockBed$EnumPartType net/minecraft/block/BlockBed EnumPartType public,static,final,enum
 method public <init> (Lnet/minecraft/entity/passive/EntityOcelot;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 326
class net/minecraft/entity/ai/EntityAIOcelotSit 52 public,super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 inner net/minecraft/block/BlockBed$EnumPartType net/minecraft/block/BlockBed EnumPartType public,static,final,enum
 method public <init> (Lnet/minecraft/entity/passive/EntityOcelot;D)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 24
class net/minecraft/entity/ai/EntityAIOpenDoor 50 public,super net/minecraft/entity/ai/EntityAIDoorInteract - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Z)V - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIOpenDoor 52 public,super net/minecraft/entity/ai/EntityAIDoorInteract - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Z)V - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIOwnerHurtByTarget 50 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAIOwnerHurtByTarget 52 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 24
class net/minecraft/entity/ai/EntityAIOwnerHurtTarget 50 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/ai/EntityAIOwnerHurtTarget 52 public,super net/minecraft/entity/ai/EntityAITarget - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 90
class net/minecraft/entity/ai/EntityAIPanic 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 field protected speed D -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public continueExecuting ()Z - -
in 91
class net/minecraft/entity/ai/EntityAIPanic 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 field protected speed D -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public continueExecuting ()Z - -
in 326
class net/minecraft/entity/ai/EntityAIPanic 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 field protected,final creature Lnet/minecraft/entity/EntityCreature; -
 field protected speed D -
 field protected randPosX D -
 field protected randPosY D -
 field protected randPosZ D -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public shouldExecute ()Z - -
 method protected findRandomPosition ()Z - -
 method public startExecuting ()V - -
 method public shouldContinueExecuting ()Z - -
in 24
class net/minecraft/entity/ai/EntityAIPlay 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;D)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIPlay 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;D)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIRestrictOpenDoor 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIRestrictOpenDoor 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIRestrictSun 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIRestrictSun 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIRunAroundLikeCrazy 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityHorse;D)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public continueExecuting ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIRunAroundLikeCrazy 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/AbstractHorse;D)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public shouldContinueExecuting ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAISit 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public setSitting (Z)V - -
in 326
class net/minecraft/entity/ai/EntityAISit 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public setSitting (Z)V - -
in 91
class net/minecraft/entity/ai/EntityAISkeletonRiders 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityHorse;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAISkeletonRiders 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntitySkeletonHorse;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAISwimming 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAISwimming 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/ai/EntityAITarget 50 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected,final taskOwner Lnet/minecraft/entity/EntityCreature; -
 field protected shouldCheckSight Z -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Z)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;ZZ)V - -
 method public continueExecuting ()Z - -
 method protected getTargetDistance ()D - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public,static isSuitableTarget (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/entity/EntityLivingBase;ZZ)Z - -
 method protected isSuitableTarget (Lnet/minecraft/entity/EntityLivingBase;Z)Z - -
in 91
class net/minecraft/entity/ai/EntityAITarget 50 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected,final taskOwner Lnet/minecraft/entity/EntityCreature; -
 field protected shouldCheckSight Z -
 field protected target Lnet/minecraft/entity/EntityLivingBase; -
 field protected unseenMemoryTicks I -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Z)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;ZZ)V - -
 method public continueExecuting ()Z - -
 method protected getTargetDistance ()D - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public,static isSuitableTarget (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/entity/EntityLivingBase;ZZ)Z - -
 method protected isSuitableTarget (Lnet/minecraft/entity/EntityLivingBase;Z)Z - -
in 326
class net/minecraft/entity/ai/EntityAITarget 52 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 field protected,final taskOwner Lnet/minecraft/entity/EntityCreature; -
 field protected shouldCheckSight Z -
 field protected target Lnet/minecraft/entity/EntityLivingBase; -
 field protected unseenMemoryTicks I -
 method public <init> (Lnet/minecraft/entity/EntityCreature;Z)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;ZZ)V - -
 method public shouldContinueExecuting ()Z - -
 method protected getTargetDistance ()D - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public,static isSuitableTarget (Lnet/minecraft/entity/EntityLiving;Lnet/minecraft/entity/EntityLivingBase;ZZ)Z - -
 method protected isSuitableTarget (Lnet/minecraft/entity/EntityLivingBase;Z)Z - -
 method public setUnseenMemoryTicks (I)Lnet/minecraft/entity/ai/EntityAITarget; - -
in 90
class net/minecraft/entity/ai/EntityAITargetNonTamed 50 public,super net/minecraft/entity/ai/EntityAINearestAttackableTarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget;
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;Ljava/lang/Class;ZLcom/google/common/base/Predicate;)V (Lnet/minecraft/entity/passive/EntityTameable;Ljava/lang/Class<TT;>;ZLcom/google/common/base/Predicate<-TT;>;)V -
 method public shouldExecute ()Z - -
in 91
class net/minecraft/entity/ai/EntityAITargetNonTamed 50 public,super net/minecraft/entity/ai/EntityAINearestAttackableTarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<TT;>;
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;Ljava/lang/Class;ZLcom/google/common/base/Predicate;)V (Lnet/minecraft/entity/passive/EntityTameable;Ljava/lang/Class<TT;>;ZLcom/google/common/base/Predicate<-TT;>;)V -
 method public shouldExecute ()Z - -
in 326
class net/minecraft/entity/ai/EntityAITargetNonTamed 52 public,super net/minecraft/entity/ai/EntityAINearestAttackableTarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<TT;>;
 method public <init> (Lnet/minecraft/entity/passive/EntityTameable;Ljava/lang/Class;ZLcom/google/common/base/Predicate;)V (Lnet/minecraft/entity/passive/EntityTameable;Ljava/lang/Class<TT;>;ZLcom/google/common/base/Predicate<-TT;>;)V -
 method public shouldExecute ()Z - -
in 90
class net/minecraft/entity/ai/EntityAITasks 50 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry net/minecraft/entity/ai/EntityAITasks EntityAITaskEntry public
 field public taskEntries Ljava/util/List; Ljava/util/List<Lnet/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry;>;
 method public <init> (Lnet/minecraft/profiler/Profiler;)V - -
 method public addTask (ILnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public removeTask (Lnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public onUpdateTasks ()V - -
in 91
class net/minecraft/entity/ai/EntityAITasks 50 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry net/minecraft/entity/ai/EntityAITasks EntityAITaskEntry public
 field public,final taskEntries Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry;>;
 method public <init> (Lnet/minecraft/profiler/Profiler;)V - -
 method public addTask (ILnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public removeTask (Lnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public onUpdateTasks ()V - -
 method public isControlFlagDisabled (I)Z - -
 method public disableControlFlag (I)V - -
 method public enableControlFlag (I)V - -
 method public setControlFlag (IZ)V - -
in 326
class net/minecraft/entity/ai/EntityAITasks 52 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry net/minecraft/entity/ai/EntityAITasks EntityAITaskEntry public
 field public,final taskEntries Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry;>;
 method public <init> (Lnet/minecraft/profiler/Profiler;)V - -
 method public addTask (ILnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public removeTask (Lnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public onUpdateTasks ()V - -
 method public isControlFlagDisabled (I)Z - -
 method public disableControlFlag (I)V - -
 method public enableControlFlag (I)V - -
 method public setControlFlag (IZ)V - -
in 90
class net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry 50 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry net/minecraft/entity/ai/EntityAITasks EntityAITaskEntry public
 field public action Lnet/minecraft/entity/ai/EntityAIBase; -
 field public priority I -
 method public <init> (Lnet/minecraft/entity/ai/EntityAITasks;ILnet/minecraft/entity/ai/EntityAIBase;)V - -
in 91
class net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry 50 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry net/minecraft/entity/ai/EntityAITasks EntityAITaskEntry public
 field public,final action Lnet/minecraft/entity/ai/EntityAIBase; -
 field public,final priority I -
 field public using Z -
 method public <init> (Lnet/minecraft/entity/ai/EntityAITasks;ILnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 326
class net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry 52 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityAITasks$EntityAITaskEntry net/minecraft/entity/ai/EntityAITasks EntityAITaskEntry public
 field public,final action Lnet/minecraft/entity/ai/EntityAIBase; -
 field public,final priority I -
 field public using Z -
 method public <init> (Lnet/minecraft/entity/ai/EntityAITasks;ILnet/minecraft/entity/ai/EntityAIBase;)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 90
class net/minecraft/entity/ai/EntityAITempt 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DLnet/minecraft/item/Item;Z)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method public isRunning ()Z - -
in 91
class net/minecraft/entity/ai/EntityAITempt 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DLnet/minecraft/item/Item;Z)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DZLjava/util/Set;)V (Lnet/minecraft/entity/EntityCreature;DZLjava/util/Set<Lnet/minecraft/item/Item;>;)V -
 method public shouldExecute ()Z - -
 method protected isTempting (Lnet/minecraft/item/ItemStack;)Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method public isRunning ()Z - -
in 326
class net/minecraft/entity/ai/EntityAITempt 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DLnet/minecraft/item/Item;Z)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DZLjava/util/Set;)V (Lnet/minecraft/entity/EntityCreature;DZLjava/util/Set<Lnet/minecraft/item/Item;>;)V -
 method public shouldExecute ()Z - -
 method protected isTempting (Lnet/minecraft/item/ItemStack;)Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method public isRunning ()Z - -
in 24
class net/minecraft/entity/ai/EntityAITradePlayer 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAITradePlayer 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIVillagerInteract 50 public,super net/minecraft/entity/ai/EntityAIWatchClosest2 - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIVillagerInteract 52 public,super net/minecraft/entity/ai/EntityAIWatchClosest2 - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIVillagerMate 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public continueExecuting ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIVillagerMate 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public shouldContinueExecuting ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIWander 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DI)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public makeUpdate ()V - -
 method public setExecutionChance (I)V - -
in 326
class net/minecraft/entity/ai/EntityAIWander 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 field protected,final entity Lnet/minecraft/entity/EntityCreature; -
 field protected x D -
 field protected y D -
 field protected z D -
 field protected,final speed D -
 field protected executionChance I -
 field protected mustUpdate Z -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DI)V - -
 method public shouldExecute ()Z - -
 method protected getPosition ()Lnet/minecraft/util/math/Vec3d; - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public makeUpdate ()V - -
 method public setExecutionChance (I)V - -
in 326
class net/minecraft/entity/ai/EntityAIWanderAvoidWater 52 public,super net/minecraft/entity/ai/EntityAIWander - -
 field protected,final probability F -
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method public <init> (Lnet/minecraft/entity/EntityCreature;DF)V - -
 method protected getPosition ()Lnet/minecraft/util/math/Vec3d; - -
in 326
class net/minecraft/entity/ai/EntityAIWanderAvoidWaterFlying 52 public,super net/minecraft/entity/ai/EntityAIWanderAvoidWater - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> (Lnet/minecraft/entity/EntityCreature;D)V - -
 method protected getPosition ()Lnet/minecraft/util/math/Vec3d; - -
in 24
class net/minecraft/entity/ai/EntityAIWatchClosest 50 public,super net/minecraft/entity/ai/EntityAIBase - -
 field protected theWatcher Lnet/minecraft/entity/EntityLiving; -
 field protected closestEntity Lnet/minecraft/entity/Entity; -
 field protected maxDistanceForPlayer F -
 field protected watchedClass Ljava/lang/Class; Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;F)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;F)V -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;FF)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;FF)V -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIWatchClosest 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 field protected entity Lnet/minecraft/entity/EntityLiving; -
 field protected closestEntity Lnet/minecraft/entity/Entity; -
 field protected maxDistance F -
 field protected watchedClass Ljava/lang/Class; Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;F)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;F)V -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;FF)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;FF)V -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/ai/EntityAIWatchClosest2 50 public,super net/minecraft/entity/ai/EntityAIWatchClosest - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;FF)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;FF)V -
in 326
class net/minecraft/entity/ai/EntityAIWatchClosest2 52 public,super net/minecraft/entity/ai/EntityAIWatchClosest - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class;FF)V (Lnet/minecraft/entity/EntityLiving;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;FF)V -
in 91
class net/minecraft/entity/ai/EntityAIZombieAttack 50 public,super net/minecraft/entity/ai/EntityAIAttackMelee - -
 method public <init> (Lnet/minecraft/entity/monster/EntityZombie;DZ)V - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityAIZombieAttack 52 public,super net/minecraft/entity/ai/EntityAIAttackMelee - -
 method public <init> (Lnet/minecraft/entity/monster/EntityZombie;DZ)V - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/ai/EntityFlyHelper 52 public,super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public onUpdateMoveHelper ()V - -
in 24
class net/minecraft/entity/ai/EntityJumpHelper 50 public,super java/lang/Object - -
 field protected isJumping Z -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public setJumping ()V - -
 method public doJump ()V - -
in 326
class net/minecraft/entity/ai/EntityJumpHelper 52 public,super java/lang/Object - -
 field protected isJumping Z -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public setJumping ()V - -
 method public doJump ()V - -
in 24
class net/minecraft/entity/ai/EntityLookHelper 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public setLookPositionWithEntity (Lnet/minecraft/entity/Entity;FF)V - -
 method public setLookPosition (DDDFF)V - -
 method public onUpdateLook ()V - -
 method public getIsLooking ()Z - -
 method public getLookPosX ()D - -
 method public getLookPosY ()D - -
 method public getLookPosZ ()D - -
in 326
class net/minecraft/entity/ai/EntityLookHelper 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public setLookPositionWithEntity (Lnet/minecraft/entity/Entity;FF)V - -
 method public setLookPosition (DDDFF)V - -
 method public onUpdateLook ()V - -
 method public getIsLooking ()Z - -
 method public getLookPosX ()D - -
 method public getLookPosY ()D - -
 method public getLookPosZ ()D - -
in 90
class net/minecraft/entity/ai/EntityMinecartMobSpawner 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 method public handleStatusUpdate (B)V - -
 method public func_98039_d ()Lnet/minecraft/tileentity/MobSpawnerBaseLogic; - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
in 90
class net/minecraft/entity/ai/EntityMoveHelper 50 public,super java/lang/Object - -
 field protected entity Lnet/minecraft/entity/EntityLiving; -
 field protected posX D -
 field protected posY D -
 field protected posZ D -
 field protected speed D -
 field protected update Z -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public isUpdating ()Z - -
 method public getSpeed ()D - -
 method public setMoveTo (DDDD)V - -
 method public onUpdateMoveHelper ()V - -
 method protected limitAngle (FFF)F - -
 method public getX ()D - -
 method public getY ()D - -
 method public getZ ()D - -
in 91
class net/minecraft/entity/ai/EntityMoveHelper 50 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 field protected,final entity Lnet/minecraft/entity/EntityLiving; -
 field protected posX D -
 field protected posY D -
 field protected posZ D -
 field protected speed D -
 field protected moveForward F -
 field protected moveStrafe F -
 field protected action Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public isUpdating ()Z - -
 method public getSpeed ()D - -
 method public setMoveTo (DDDD)V - -
 method public strafe (FF)V - -
 method public read (Lnet/minecraft/entity/ai/EntityMoveHelper;)V - -
 method public onUpdateMoveHelper ()V - -
 method protected limitAngle (FFF)F - -
 method public getX ()D - -
 method public getY ()D - -
 method public getZ ()D - -
in 326
class net/minecraft/entity/ai/EntityMoveHelper 52 public,super java/lang/Object - -
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 field protected,final entity Lnet/minecraft/entity/EntityLiving; -
 field protected posX D -
 field protected posY D -
 field protected posZ D -
 field protected speed D -
 field protected moveForward F -
 field protected moveStrafe F -
 field public action Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public isUpdating ()Z - -
 method public getSpeed ()D - -
 method public setMoveTo (DDDD)V - -
 method public strafe (FF)V - -
 method public read (Lnet/minecraft/entity/ai/EntityMoveHelper;)V - -
 method public onUpdateMoveHelper ()V - -
 method protected limitAngle (FFF)F - -
 method public getX ()D - -
 method public getY ()D - -
 method public getZ ()D - -
in 91
class net/minecraft/entity/ai/EntityMoveHelper$Action 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/ai/EntityMoveHelper$Action;>;
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 field public,static,final,enum WAIT Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 field public,static,final,enum MOVE_TO Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 field public,static,final,enum STRAFE Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 method public,static values ()[Lnet/minecraft/entity/ai/EntityMoveHelper$Action; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/ai/EntityMoveHelper$Action; - -
in 326
class net/minecraft/entity/ai/EntityMoveHelper$Action 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/ai/EntityMoveHelper$Action;>;
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 field public,static,final,enum WAIT Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 field public,static,final,enum MOVE_TO Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 field public,static,final,enum STRAFE Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 field public,static,final,enum JUMPING Lnet/minecraft/entity/ai/EntityMoveHelper$Action; -
 method public,static values ()[Lnet/minecraft/entity/ai/EntityMoveHelper$Action; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/ai/EntityMoveHelper$Action; - -
in 24
class net/minecraft/entity/ai/EntitySenses 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public clearSensingCache ()V - -
 method public canSee (Lnet/minecraft/entity/Entity;)Z - -
in 326
class net/minecraft/entity/ai/EntitySenses 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/EntityLiving;)V - -
 method public clearSensingCache ()V - -
 method public canSee (Lnet/minecraft/entity/Entity;)Z - -
in 90
class net/minecraft/entity/ai/RandomPositionGenerator 50 public,super java/lang/Object - -
 method public,static findRandomTarget (Lnet/minecraft/entity/EntityCreature;II)Lnet/minecraft/util/Vec3; - -
 method public,static findRandomTargetBlockTowards (Lnet/minecraft/entity/EntityCreature;IILnet/minecraft/util/Vec3;)Lnet/minecraft/util/Vec3; - -
 method public,static findRandomTargetBlockAwayFrom (Lnet/minecraft/entity/EntityCreature;IILnet/minecraft/util/Vec3;)Lnet/minecraft/util/Vec3; - -
in 91
class net/minecraft/entity/ai/RandomPositionGenerator 50 public,super java/lang/Object - -
 method public,static findRandomTarget (Lnet/minecraft/entity/EntityCreature;II)Lnet/minecraft/util/math/Vec3d; - -
 method public,static findRandomTargetBlockTowards (Lnet/minecraft/entity/EntityCreature;IILnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d; - -
 method public,static findRandomTargetBlockAwayFrom (Lnet/minecraft/entity/EntityCreature;IILnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d; - -
in 326
class net/minecraft/entity/ai/RandomPositionGenerator 52 public,super java/lang/Object - -
 method public,static findRandomTarget (Lnet/minecraft/entity/EntityCreature;II)Lnet/minecraft/util/math/Vec3d; - -
 method public,static getLandPos (Lnet/minecraft/entity/EntityCreature;II)Lnet/minecraft/util/math/Vec3d; - -
 method public,static findRandomTargetBlockTowards (Lnet/minecraft/entity/EntityCreature;IILnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d; - -
 method public,static findRandomTargetBlockAwayFrom (Lnet/minecraft/entity/EntityCreature;IILnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d; - -
in 91
class net/minecraft/entity/ai/attributes/AbstractAttributeMap 50 public,super,abstract java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field protected,final attributes Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 field protected,final attributesByName Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 field protected,final descendantsByParent Lcom/google/common/collect/Multimap; Lcom/google/common/collect/Multimap<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/IAttribute;>;
 method public <init> ()V - -
 method public getAttributeInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAttributeInstanceByName (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public registerAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method protected,abstract createInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAllAttributes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
 method public onAttributeModified (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)V - -
 method public removeAttributeModifiers (Lcom/google/common/collect/Multimap;)V (Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>;)V -
 method public applyAttributeModifiers (Lcom/google/common/collect/Multimap;)V (Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>;)V -
in 326
class net/minecraft/entity/ai/attributes/AbstractAttributeMap 52 public,super,abstract java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field protected,final attributes Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 field protected,final attributesByName Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 field protected,final descendantsByParent Lcom/google/common/collect/Multimap; Lcom/google/common/collect/Multimap<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/IAttribute;>;
 method public <init> ()V - -
 method public getAttributeInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAttributeInstanceByName (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public registerAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method protected,abstract createInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAllAttributes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
 method public onAttributeModified (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)V - -
 method public removeAttributeModifiers (Lcom/google/common/collect/Multimap;)V (Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>;)V -
 method public applyAttributeModifiers (Lcom/google/common/collect/Multimap;)V (Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>;)V -
in 91
class net/minecraft/entity/ai/attributes/AttributeMap 50 public,super net/minecraft/entity/ai/attributes/AbstractAttributeMap - -
 field protected,final descriptionToAttributeInstanceMap Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 method public <init> ()V - -
 method public getAttributeInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/ModifiableAttributeInstance; - -
 method public getAttributeInstanceByName (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/ModifiableAttributeInstance; - -
 method public registerAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method protected createInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public onAttributeModified (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)V - -
 method public getAttributeInstanceSet ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
 method public getWatchedAttributes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
in 326
class net/minecraft/entity/ai/attributes/AttributeMap 52 public,super net/minecraft/entity/ai/attributes/AbstractAttributeMap - -
 field protected,final instancesByName Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 method public <init> ()V - -
 method public getAttributeInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/ModifiableAttributeInstance; - -
 method public getAttributeInstanceByName (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/ModifiableAttributeInstance; - -
 method public registerAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method protected createInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public onAttributeModified (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)V - -
 method public getDirtyInstances ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
 method public getWatchedAttributes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
in 24
class net/minecraft/entity/ai/attributes/AttributeModifier 50 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;DI)V - -
 method public <init> (Ljava/util/UUID;Ljava/lang/String;DI)V - -
 method public getID ()Ljava/util/UUID; - -
 method public getName ()Ljava/lang/String; - -
 method public getOperation ()I - -
 method public getAmount ()D - -
 method public isSaved ()Z - -
 method public setSaved (Z)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 326
class net/minecraft/entity/ai/attributes/AttributeModifier 52 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;DI)V - -
 method public <init> (Ljava/util/UUID;Ljava/lang/String;DI)V - -
 method public getID ()Ljava/util/UUID; - -
 method public getName ()Ljava/lang/String; - -
 method public getOperation ()I - -
 method public getAmount ()D - -
 method public isSaved ()Z - -
 method public setSaved (Z)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 90
class net/minecraft/entity/ai/attributes/BaseAttribute 50 public,super,abstract java/lang/Object net/minecraft/entity/ai/attributes/IAttribute -
 method protected <init> (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;D)V - -
 method public getAttributeUnlocalizedName ()Ljava/lang/String; - -
 method public getDefaultValue ()D - -
 method public getShouldWatch ()Z - -
 method public setShouldWatch (Z)Lnet/minecraft/entity/ai/attributes/BaseAttribute; - -
 method public func_180372_d ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 91
class net/minecraft/entity/ai/attributes/BaseAttribute 50 public,super,abstract java/lang/Object net/minecraft/entity/ai/attributes/IAttribute -
 method protected <init> (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;D)V - -
 method public getName ()Ljava/lang/String; - -
 method public getDefaultValue ()D - -
 method public getShouldWatch ()Z - -
 method public setShouldWatch (Z)Lnet/minecraft/entity/ai/attributes/BaseAttribute; - -
 method public getParent ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 326
class net/minecraft/entity/ai/attributes/BaseAttribute 52 public,super,abstract java/lang/Object net/minecraft/entity/ai/attributes/IAttribute -
 method protected <init> (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;D)V - -
 method public getName ()Ljava/lang/String; - -
 method public getDefaultValue ()D - -
 method public getShouldWatch ()Z - -
 method public setShouldWatch (Z)Lnet/minecraft/entity/ai/attributes/BaseAttribute; - -
 method public getParent ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public hashCode ()I - -
 method public equals (Ljava/lang/Object;)Z - -
in 90
class net/minecraft/entity/ai/attributes/BaseAttributeMap 50 public,super,abstract java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 field protected,final attributes Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 field protected,final attributesByName Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 field protected,final field_180377_c Lcom/google/common/collect/Multimap; Lcom/google/common/collect/Multimap<Lnet/minecraft/entity/ai/attributes/IAttribute;Lnet/minecraft/entity/ai/attributes/IAttribute;>;
 method public <init> ()V - -
 method public getAttributeInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAttributeInstanceByName (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public registerAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method protected,abstract func_180376_c (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public getAllAttributes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
 method public func_180794_a (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)V - -
 method public removeAttributeModifiers (Lcom/google/common/collect/Multimap;)V (Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>;)V -
 method public applyAttributeModifiers (Lcom/google/common/collect/Multimap;)V (Lcom/google/common/collect/Multimap<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/AttributeModifier;>;)V -
in 90
class net/minecraft/entity/ai/attributes/IAttribute 50 public,interface,abstract java/lang/Object - -
 method public,abstract getAttributeUnlocalizedName ()Ljava/lang/String; - -
 method public,abstract clampValue (D)D - -
 method public,abstract getDefaultValue ()D - -
 method public,abstract getShouldWatch ()Z - -
 method public,abstract func_180372_d ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
in 91
class net/minecraft/entity/ai/attributes/IAttribute 50 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract clampValue (D)D - -
 method public,abstract getDefaultValue ()D - -
 method public,abstract getShouldWatch ()Z - -
 method public,abstract getParent ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
in 326
class net/minecraft/entity/ai/attributes/IAttribute 52 public,interface,abstract java/lang/Object - -
 method public,abstract getName ()Ljava/lang/String; - -
 method public,abstract clampValue (D)D - -
 method public,abstract getDefaultValue ()D - -
 method public,abstract getShouldWatch ()Z - -
 method public,abstract getParent ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
in 90
class net/minecraft/entity/ai/attributes/IAttributeInstance 50 public,interface,abstract java/lang/Object - -
 method public,abstract removeAllModifiers ()V - -
 method public,abstract getAttribute ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public,abstract getBaseValue ()D - -
 method public,abstract setBaseValue (D)V - -
 method public,abstract getModifiersByOperation (I)Ljava/util/Collection; (I)Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public,abstract func_111122_c ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public,abstract hasModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Z - -
 method public,abstract getModifier (Ljava/util/UUID;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public,abstract applyModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public,abstract removeModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public,abstract getAttributeValue ()D - -
in 91
class net/minecraft/entity/ai/attributes/IAttributeInstance 50 public,interface,abstract java/lang/Object - -
 method public,abstract removeAllModifiers ()V - -
 method public,abstract getAttribute ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public,abstract getBaseValue ()D - -
 method public,abstract setBaseValue (D)V - -
 method public,abstract getModifiersByOperation (I)Ljava/util/Collection; (I)Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public,abstract getModifiers ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public,abstract hasModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Z - -
 method public,abstract getModifier (Ljava/util/UUID;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public,abstract applyModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public,abstract removeModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public,abstract removeModifier (Ljava/util/UUID;)V - -
 method public,abstract getAttributeValue ()D - -
in 326
class net/minecraft/entity/ai/attributes/IAttributeInstance 52 public,interface,abstract java/lang/Object - -
 method public,abstract getAttribute ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public,abstract getBaseValue ()D - -
 method public,abstract setBaseValue (D)V - -
 method public,abstract getModifiersByOperation (I)Ljava/util/Collection; (I)Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public,abstract getModifiers ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public,abstract hasModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Z - -
 method public,abstract getModifier (Ljava/util/UUID;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public,abstract applyModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public,abstract removeModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public,abstract removeModifier (Ljava/util/UUID;)V - -
 method public,abstract removeAllModifiers ()V - -
 method public,abstract getAttributeValue ()D - -
in 90
class net/minecraft/entity/ai/attributes/ModifiableAttributeInstance 50 public,super java/lang/Object net/minecraft/entity/ai/attributes/IAttributeInstance -
 method public removeAllModifiers ()V - -
 method public <init> (Lnet/minecraft/entity/ai/attributes/BaseAttributeMap;Lnet/minecraft/entity/ai/attributes/IAttribute;)V - -
 method public getAttribute ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public getBaseValue ()D - -
 method public setBaseValue (D)V - -
 method public getModifiersByOperation (I)Ljava/util/Collection; (I)Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public func_111122_c ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getModifier (Ljava/util/UUID;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public hasModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Z - -
 method public applyModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method protected flagForUpdate ()V - -
 method public removeModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public getAttributeValue ()D - -
in 91
class net/minecraft/entity/ai/attributes/ModifiableAttributeInstance 50 public,super java/lang/Object net/minecraft/entity/ai/attributes/IAttributeInstance -
 method public removeAllModifiers ()V - -
 method public <init> (Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;Lnet/minecraft/entity/ai/attributes/IAttribute;)V - -
 method public getAttribute ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public getBaseValue ()D - -
 method public setBaseValue (D)V - -
 method public getModifiersByOperation (I)Ljava/util/Collection; (I)Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getModifiers ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getModifier (Ljava/util/UUID;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public hasModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Z - -
 method public applyModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method protected flagForUpdate ()V - -
 method public removeModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public removeModifier (Ljava/util/UUID;)V - -
 method public getAttributeValue ()D - -
in 326
class net/minecraft/entity/ai/attributes/ModifiableAttributeInstance 52 public,super java/lang/Object net/minecraft/entity/ai/attributes/IAttributeInstance -
 method public <init> (Lnet/minecraft/entity/ai/attributes/AbstractAttributeMap;Lnet/minecraft/entity/ai/attributes/IAttribute;)V - -
 method public getAttribute ()Lnet/minecraft/entity/ai/attributes/IAttribute; - -
 method public getBaseValue ()D - -
 method public setBaseValue (D)V - -
 method public getModifiersByOperation (I)Ljava/util/Collection; (I)Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getModifiers ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/AttributeModifier;>; -
 method public getModifier (Ljava/util/UUID;)Lnet/minecraft/entity/ai/attributes/AttributeModifier; - -
 method public hasModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)Z - -
 method public applyModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method protected flagForUpdate ()V - -
 method public removeModifier (Lnet/minecraft/entity/ai/attributes/AttributeModifier;)V - -
 method public removeModifier (Ljava/util/UUID;)V - -
 method public removeAllModifiers ()V - -
 method public getAttributeValue ()D - -
in 24
class net/minecraft/entity/ai/attributes/RangedAttribute 50 public,super net/minecraft/entity/ai/attributes/BaseAttribute - -
 method public <init> (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;DDD)V - -
 method public setDescription (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/RangedAttribute; - -
 method public getDescription ()Ljava/lang/String; - -
 method public clampValue (D)D - -
in 326
class net/minecraft/entity/ai/attributes/RangedAttribute 52 public,super net/minecraft/entity/ai/attributes/BaseAttribute - -
 method public <init> (Lnet/minecraft/entity/ai/attributes/IAttribute;Ljava/lang/String;DDD)V - -
 method public setDescription (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/RangedAttribute; - -
 method public getDescription ()Ljava/lang/String; - -
 method public clampValue (D)D - -
in 90
class net/minecraft/entity/ai/attributes/ServersideAttributeMap 50 public,super net/minecraft/entity/ai/attributes/BaseAttributeMap - -
 field protected,final descriptionToAttributeInstanceMap Ljava/util/Map; Ljava/util/Map<Ljava/lang/String;Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>;
 method public <init> ()V - -
 method public getAttributeInstance (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/ModifiableAttributeInstance; - -
 method public getAttributeInstanceByName (Ljava/lang/String;)Lnet/minecraft/entity/ai/attributes/ModifiableAttributeInstance; - -
 method public registerAttribute (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method protected func_180376_c (Lnet/minecraft/entity/ai/attributes/IAttribute;)Lnet/minecraft/entity/ai/attributes/IAttributeInstance; - -
 method public func_180794_a (Lnet/minecraft/entity/ai/attributes/IAttributeInstance;)V - -
 method public getAttributeInstanceSet ()Ljava/util/Set; ()Ljava/util/Set<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
 method public getWatchedAttributes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/entity/ai/attributes/IAttributeInstance;>; -
in 90
class net/minecraft/entity/boss/BossStatus 50 public,final,super java/lang/Object - -
 field public,static healthScale F -
 field public,static statusBarTime I -
 field public,static bossName Ljava/lang/String; -
 field public,static hasColorModifier Z -
 method public,static setBossStatus (Lnet/minecraft/entity/boss/IBossDisplayData;Z)V - -
in 90
class net/minecraft/entity/boss/EntityDragon 50 public,super net/minecraft/entity/EntityLiving net/minecraft/entity/boss/IBossDisplayData,net/minecraft/entity/IEntityMultiPart,net/minecraft/entity/monster/IMob -
 field public targetX D -
 field public targetY D -
 field public targetZ D -
 field public ringBuffer [[D -
 field public ringBufferIndex I -
 field public dragonPartArray [Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartHead Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartBody Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartTail1 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartTail2 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartTail3 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartWing1 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartWing2 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public prevAnimTime F -
 field public animTime F -
 field public forceNewTarget Z -
 field public slowed Z -
 field public deathTicks I -
 field public healingEnderCrystal Lnet/minecraft/entity/item/EntityEnderCrystal; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public getMovementOffsets (IF)[D - -
 method public onLivingUpdate ()V - -
 method public attackEntityFromPart (Lnet/minecraft/entity/boss/EntityDragonPart;Lnet/minecraft/util/DamageSource;F)Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected attackDragonFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public onKillCommand ()V - -
 method protected onDeathUpdate ()V - -
 method protected despawnEntity ()V - -
 method public getParts ()[Lnet/minecraft/entity/Entity; - -
 method public canBeCollidedWith ()Z - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getSoundVolume ()F - -
in 91
class net/minecraft/entity/boss/EntityDragon 50 public,super net/minecraft/entity/EntityLiving net/minecraft/entity/IEntityMultiPart,net/minecraft/entity/monster/IMob -
 field public,static,final PHASE Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Integer;>;
 field public ringBuffer [[D -
 field public ringBufferIndex I -
 field public dragonPartArray [Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartHead Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartNeck Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartBody Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartTail1 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartTail2 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartTail3 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartWing1 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public dragonPartWing2 Lnet/minecraft/entity/boss/EntityDragonPart; -
 field public prevAnimTime F -
 field public animTime F -
 field public slowed Z -
 field public deathTicks I -
 field public healingEnderCrystal Lnet/minecraft/entity/item/EntityEnderCrystal; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public getMovementOffsets (IF)[D - -
 method public onLivingUpdate ()V - -
 method public attackEntityFromPart (Lnet/minecraft/entity/boss/EntityDragonPart;Lnet/minecraft/util/DamageSource;F)Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected attackDragonFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public onKillCommand ()V - -
 method protected onDeathUpdate ()V - -
 method public initPathPoints ()I - -
 method public getNearestPpIdx (DDD)I - -
 method public findPath (IILnet/minecraft/pathfinding/PathPoint;)Lnet/minecraft/pathfinding/Path; - -
 method public,static registerFixesDragon (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected despawnEntity ()V - -
 method public getParts ()[Lnet/minecraft/entity/Entity; - -
 method public canBeCollidedWith ()Z - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method public getHeadPartYOffset (I[D[D)F - -
 method public getHeadLookVec (F)Lnet/minecraft/util/math/Vec3d; - -
 method public onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getPhaseManager ()Lnet/minecraft/entity/boss/dragon/phase/PhaseManager; - -
 method public getFightManager ()Lnet/minecraft/world/end/DragonFightManager; - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected canBeRidden (Lnet/minecraft/entity/Entity;)Z - -
 method public isNonBoss ()Z - -
in 326
class net/minecraft/entity/boss/EntityDragon 52 public,super net/minecraft/entity/EntityLiving net/minecraft/entity/IEntityMultiPart,net/minecraft/entity/monster/IMob -
 field public,static,final PHASE Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Integer;>;
 field public ringBuffer [[D -
 field public ringBufferIndex I -
 field public dragonPartArray [Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartHead Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartNeck Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartBody Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartTail1 Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartTail2 Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartTail3 Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartWing1 Lnet/minecraft/entity/MultiPartEntityPart; -
 field public dragonPartWing2 Lnet/minecraft/entity/MultiPartEntityPart; -
 field public prevAnimTime F -
 field public animTime F -
 field public slowed Z -
 field public deathTicks I -
 field public healingEnderCrystal Lnet/minecraft/entity/item/EntityEnderCrystal; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public getMovementOffsets (IF)[D - -
 method public onLivingUpdate ()V - -
 method public attackEntityFromPart (Lnet/minecraft/entity/MultiPartEntityPart;Lnet/minecraft/util/DamageSource;F)Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected attackDragonFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public onKillCommand ()V - -
 method protected onDeathUpdate ()V - -
 method public initPathPoints ()I - -
 method public getNearestPpIdx (DDD)I - -
 method public findPath (IILnet/minecraft/pathfinding/PathPoint;)Lnet/minecraft/pathfinding/Path; - -
 method public,static registerFixesDragon (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected despawnEntity ()V - -
 method public getParts ()[Lnet/minecraft/entity/Entity; - -
 method public canBeCollidedWith ()Z - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getHeadPartYOffset (I[D[D)F - -
 method public getHeadLookVec (F)Lnet/minecraft/util/math/Vec3d; - -
 method public onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getPhaseManager ()Lnet/minecraft/entity/boss/dragon/phase/PhaseManager; - -
 method public getFightManager ()Lnet/minecraft/world/end/DragonFightManager; - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected canBeRidden (Lnet/minecraft/entity/Entity;)Z - -
 method public isNonBoss ()Z - -
in 24
class net/minecraft/entity/boss/EntityDragonPart 50 public,super net/minecraft/entity/Entity - -
 field public,final entityDragonObj Lnet/minecraft/entity/IEntityMultiPart; -
 field public,final partName Ljava/lang/String; -
 method public <init> (Lnet/minecraft/entity/IEntityMultiPart;Ljava/lang/String;FF)V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public isEntityEqual (Lnet/minecraft/entity/Entity;)Z - -
in 90
class net/minecraft/entity/boss/EntityWither 50 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/boss/IBossDisplayData,net/minecraft/entity/IRangedAttackMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method public,static canDestroyBlock (Lnet/minecraft/block/Block;)Z - -
 method public func_82206_m ()V - -
 method public setInWeb ()V - -
 method public getTotalArmorValue ()I - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected dropFewItems (ZI)V - -
 method protected despawnEntity ()V - -
 method public getBrightnessForRender (F)I - -
 method public fall (FF)V - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected applyEntityAttributes ()V - -
 method public func_82207_a (I)F - -
 method public func_82210_r (I)F - -
 method public getInvulTime ()I - -
 method public setInvulTime (I)V - -
 method public getWatchedTargetId (I)I - -
 method public updateWatchedTargetId (II)V - -
 method public isArmored ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public mountEntity (Lnet/minecraft/entity/Entity;)V - -
in 91
class net/minecraft/entity/boss/EntityWither 50 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 inner net/minecraft/entity/boss/EntityWither$AIDoNothing net/minecraft/entity/boss/EntityWither AIDoNothing -
 inner net/minecraft/world/BossInfo$Color net/minecraft/world/BossInfo Color public,static,final,enum
 inner net/minecraft/world/BossInfo$Overlay net/minecraft/world/BossInfo Overlay public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method public,static registerFixesWither (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method public,static canDestroyBlock (Lnet/minecraft/block/Block;)Z - -
 method public ignite ()V - -
 method public setInWeb ()V - -
 method public addTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public removeTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected dropFewItems (ZI)V - -
 method protected despawnEntity ()V - -
 method public getBrightnessForRender (F)I - -
 method public fall (FF)V - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected applyEntityAttributes ()V - -
 method public getHeadYRotation (I)F - -
 method public getHeadXRotation (I)F - -
 method public getInvulTime ()I - -
 method public setInvulTime (I)V - -
 method public getWatchedTargetId (I)I - -
 method public updateWatchedTargetId (II)V - -
 method public isArmored ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method protected canBeRidden (Lnet/minecraft/entity/Entity;)Z - -
 method public isNonBoss ()Z - -
in 326
class net/minecraft/entity/boss/EntityWither 52 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 inner net/minecraft/entity/boss/EntityWither$AIDoNothing net/minecraft/entity/boss/EntityWither AIDoNothing -
 inner net/minecraft/world/BossInfo$Color net/minecraft/world/BossInfo Color public,static,final,enum
 inner net/minecraft/world/BossInfo$Overlay net/minecraft/world/BossInfo Overlay public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method public,static registerFixesWither (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setCustomNameTag (Ljava/lang/String;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method public,static canDestroyBlock (Lnet/minecraft/block/Block;)Z - -
 method public ignite ()V - -
 method public setInWeb ()V - -
 method public addTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public removeTrackingPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)V - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected dropFewItems (ZI)V - -
 method protected despawnEntity ()V - -
 method public getBrightnessForRender ()I - -
 method public fall (FF)V - -
 method public addPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected applyEntityAttributes ()V - -
 method public getHeadYRotation (I)F - -
 method public getHeadXRotation (I)F - -
 method public getInvulTime ()I - -
 method public setInvulTime (I)V - -
 method public getWatchedTargetId (I)I - -
 method public updateWatchedTargetId (II)V - -
 method public isArmored ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method protected canBeRidden (Lnet/minecraft/entity/Entity;)Z - -
 method public isNonBoss ()Z - -
 method public setSwingingArms (Z)V - -
in 91
class net/minecraft/entity/boss/EntityWither$AIDoNothing 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/boss/EntityWither$AIDoNothing net/minecraft/entity/boss/EntityWither AIDoNothing -
 method public <init> (Lnet/minecraft/entity/boss/EntityWither;)V - -
 method public shouldExecute ()Z - -
in 326
class net/minecraft/entity/boss/EntityWither$AIDoNothing 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/boss/EntityWither$AIDoNothing net/minecraft/entity/boss/EntityWither AIDoNothing -
 method public <init> (Lnet/minecraft/entity/boss/EntityWither;)V - -
 method public shouldExecute ()Z - -
in 90
class net/minecraft/entity/boss/IBossDisplayData 50 public,interface,abstract java/lang/Object - -
 method public,abstract getMaxHealth ()F - -
 method public,abstract getHealth ()F - -
 method public,abstract getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
in 91
class net/minecraft/entity/boss/dragon/phase/IPhase 50 public,interface,abstract java/lang/Object - -
 method public,abstract getIsStationary ()Z - -
 method public,abstract doClientRenderEffects ()V - -
 method public,abstract doLocalUpdate ()V - -
 method public,abstract onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract initPhase ()V - -
 method public,abstract removeAreaEffect ()V - -
 method public,abstract getMaxRiseOrFall ()F - -
 method public,abstract getYawFactor ()F - -
 method public,abstract getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<+Lnet/minecraft/entity/boss/dragon/phase/IPhase;>; -
 method public,abstract getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public,abstract getAdjustedDamage (Lnet/minecraft/entity/boss/EntityDragonPart;Lnet/minecraft/util/DamageSource;F)F - -
in 326
class net/minecraft/entity/boss/dragon/phase/IPhase 52 public,interface,abstract java/lang/Object - -
 method public,abstract getIsStationary ()Z - -
 method public,abstract doClientRenderEffects ()V - -
 method public,abstract doLocalUpdate ()V - -
 method public,abstract onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract initPhase ()V - -
 method public,abstract removeAreaEffect ()V - -
 method public,abstract getMaxRiseOrFall ()F - -
 method public,abstract getYawFactor ()F - -
 method public,abstract getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<+Lnet/minecraft/entity/boss/dragon/phase/IPhase;>; -
 method public,abstract getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public,abstract getAdjustedDamage (Lnet/minecraft/entity/MultiPartEntityPart;Lnet/minecraft/util/DamageSource;F)F - -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseBase 50 public,super,abstract java/lang/Object net/minecraft/entity/boss/dragon/phase/IPhase -
 field protected,final dragon Lnet/minecraft/entity/boss/EntityDragon; -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getIsStationary ()Z - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public initPhase ()V - -
 method public removeAreaEffect ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getAdjustedDamage (Lnet/minecraft/entity/boss/EntityDragonPart;Lnet/minecraft/util/DamageSource;F)F - -
 method public getYawFactor ()F - -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseBase 52 public,super,abstract java/lang/Object net/minecraft/entity/boss/dragon/phase/IPhase -
 field protected,final dragon Lnet/minecraft/entity/boss/EntityDragon; -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getIsStationary ()Z - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public initPhase ()V - -
 method public removeAreaEffect ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getAdjustedDamage (Lnet/minecraft/entity/MultiPartEntityPart;Lnet/minecraft/util/DamageSource;F)F - -
 method public getYawFactor ()F - -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseChargingPlayer 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public setTarget (Lnet/minecraft/util/math/Vec3d;)V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseChargingPlayer;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseChargingPlayer 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public setTarget (Lnet/minecraft/util/math/Vec3d;)V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseChargingPlayer;>; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseDying 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseDying;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseDying 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseDying;>; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseHoldingPattern 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHoldingPattern;>; -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseHoldingPattern 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHoldingPattern;>; -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public onCrystalDestroyed (Lnet/minecraft/entity/item/EntityEnderCrystal;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/DamageSource;Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseHover 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public getIsStationary ()Z - -
 method public initPhase ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHover;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseHover 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public getIsStationary ()Z - -
 method public initPhase ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHover;>; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseLanding 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getYawFactor ()F - -
 method public initPhase ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLanding;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseLanding 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public getMaxRiseOrFall ()F - -
 method public getYawFactor ()F - -
 method public initPhase ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLanding;>; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseLandingApproach 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLandingApproach;>; -
 method public initPhase ()V - -
 method public doLocalUpdate ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseLandingApproach 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLandingApproach;>; -
 method public initPhase ()V - -
 method public doLocalUpdate ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseList 50 public,super java/lang/Object - <T::Lnet/minecraft/entity/boss/dragon/phase/IPhase;>Ljava/lang/Object;
 field public,static,final HOLDING_PATTERN Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHoldingPattern;>;
 field public,static,final STRAFE_PLAYER Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseStrafePlayer;>;
 field public,static,final LANDING_APPROACH Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLandingApproach;>;
 field public,static,final LANDING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLanding;>;
 field public,static,final TAKEOFF Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseTakeoff;>;
 field public,static,final SITTING_FLAMING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingFlaming;>;
 field public,static,final SITTING_SCANNING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingScanning;>;
 field public,static,final SITTING_ATTACKING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingAttacking;>;
 field public,static,final CHARGING_PLAYER Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseChargingPlayer;>;
 field public,static,final DYING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseDying;>;
 field public,static,final HOVER Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHover;>;
 method public createPhase (Lnet/minecraft/entity/boss/EntityDragon;)Lnet/minecraft/entity/boss/dragon/phase/IPhase; - -
 method protected getConstructor ()Ljava/lang/reflect/Constructor; ()Ljava/lang/reflect/Constructor<+Lnet/minecraft/entity/boss/dragon/phase/IPhase;>; java/lang/NoSuchMethodException
 method public getId ()I - -
 method public toString ()Ljava/lang/String; - -
 method public,static getById (I)Lnet/minecraft/entity/boss/dragon/phase/PhaseList; (I)Lnet/minecraft/entity/boss/dragon/phase/PhaseList<*>; -
 method public,static getTotalPhases ()I - -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseList 52 public,super java/lang/Object - <T::Lnet/minecraft/entity/boss/dragon/phase/IPhase;>Ljava/lang/Object;
 field public,static,final HOLDING_PATTERN Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHoldingPattern;>;
 field public,static,final STRAFE_PLAYER Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseStrafePlayer;>;
 field public,static,final LANDING_APPROACH Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLandingApproach;>;
 field public,static,final LANDING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseLanding;>;
 field public,static,final TAKEOFF Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseTakeoff;>;
 field public,static,final SITTING_FLAMING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingFlaming;>;
 field public,static,final SITTING_SCANNING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingScanning;>;
 field public,static,final SITTING_ATTACKING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingAttacking;>;
 field public,static,final CHARGING_PLAYER Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseChargingPlayer;>;
 field public,static,final DYING Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseDying;>;
 field public,static,final HOVER Lnet/minecraft/entity/boss/dragon/phase/PhaseList; Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseHover;>;
 method public createPhase (Lnet/minecraft/entity/boss/EntityDragon;)Lnet/minecraft/entity/boss/dragon/phase/IPhase; - -
 method protected getConstructor ()Ljava/lang/reflect/Constructor; ()Ljava/lang/reflect/Constructor<+Lnet/minecraft/entity/boss/dragon/phase/IPhase;>; java/lang/NoSuchMethodException
 method public getId ()I - -
 method public toString ()Ljava/lang/String; - -
 method public,static getById (I)Lnet/minecraft/entity/boss/dragon/phase/PhaseList; (I)Lnet/minecraft/entity/boss/dragon/phase/PhaseList<*>; -
 method public,static getTotalPhases ()I - -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseManager 50 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public setPhase (Lnet/minecraft/entity/boss/dragon/phase/PhaseList;)V (Lnet/minecraft/entity/boss/dragon/phase/PhaseList<*>;)V -
 method public getCurrentPhase ()Lnet/minecraft/entity/boss/dragon/phase/IPhase; - -
 method public getPhase (Lnet/minecraft/entity/boss/dragon/phase/PhaseList;)Lnet/minecraft/entity/boss/dragon/phase/IPhase; <T::Lnet/minecraft/entity/boss/dragon/phase/IPhase;>(Lnet/minecraft/entity/boss/dragon/phase/PhaseList<TT;>;)TT; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseManager 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public setPhase (Lnet/minecraft/entity/boss/dragon/phase/PhaseList;)V (Lnet/minecraft/entity/boss/dragon/phase/PhaseList<*>;)V -
 method public getCurrentPhase ()Lnet/minecraft/entity/boss/dragon/phase/IPhase; - -
 method public getPhase (Lnet/minecraft/entity/boss/dragon/phase/PhaseList;)Lnet/minecraft/entity/boss/dragon/phase/IPhase; <T::Lnet/minecraft/entity/boss/dragon/phase/IPhase;>(Lnet/minecraft/entity/boss/dragon/phase/PhaseList<TT;>;)TT; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseSittingAttacking 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseSittingBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingAttacking;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseSittingAttacking 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseSittingBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingAttacking;>; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseSittingBase 50 public,super,abstract net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getIsStationary ()Z - -
 method public getAdjustedDamage (Lnet/minecraft/entity/boss/EntityDragonPart;Lnet/minecraft/util/DamageSource;F)F - -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseSittingBase 52 public,super,abstract net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public getIsStationary ()Z - -
 method public getAdjustedDamage (Lnet/minecraft/entity/MultiPartEntityPart;Lnet/minecraft/util/DamageSource;F)F - -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseSittingFlaming 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseSittingBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public removeAreaEffect ()V - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingFlaming;>; -
 method public resetFlameCount ()V - -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseSittingFlaming 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseSittingBase - -
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doClientRenderEffects ()V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public removeAreaEffect ()V - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingFlaming;>; -
 method public resetFlameCount ()V - -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseSittingScanning 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseSittingBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingScanning;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseSittingScanning 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseSittingBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseSittingScanning;>; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseStrafePlayer 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public setTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseStrafePlayer;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseStrafePlayer 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public setTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseStrafePlayer;>; -
in 91
class net/minecraft/entity/boss/dragon/phase/PhaseTakeoff 50 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getPhaseList ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseTakeoff;>; -
in 326
class net/minecraft/entity/boss/dragon/phase/PhaseTakeoff 52 public,super net/minecraft/entity/boss/dragon/phase/PhaseBase - -
 method public <init> (Lnet/minecraft/entity/boss/EntityDragon;)V - -
 method public doLocalUpdate ()V - -
 method public initPhase ()V - -
 method public getTargetLocation ()Lnet/minecraft/util/math/Vec3d; - -
 method public getType ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList; ()Lnet/minecraft/entity/boss/dragon/phase/PhaseList<Lnet/minecraft/entity/boss/dragon/phase/PhaseTakeoff;>; -
in 90
class net/minecraft/entity/effect/EntityLightningBolt 50 public,super net/minecraft/entity/effect/EntityWeatherEffect - -
 field public boltVertex J -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public onUpdate ()V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/entity/effect/EntityLightningBolt 50 public,super net/minecraft/entity/effect/EntityWeatherEffect - -
 field public boltVertex J -
 method public <init> (Lnet/minecraft/world/World;DDDZ)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public onUpdate ()V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/entity/effect/EntityLightningBolt 52 public,super net/minecraft/entity/effect/EntityWeatherEffect - -
 field public boltVertex J -
 method public <init> (Lnet/minecraft/world/World;DDDZ)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public onUpdate ()V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 24
class net/minecraft/entity/effect/EntityWeatherEffect 50 public,super,abstract net/minecraft/entity/Entity - -
 method public <init> (Lnet/minecraft/world/World;)V - -
in 326
class net/minecraft/entity/effect/EntityWeatherEffect 52 public,super,abstract net/minecraft/entity/Entity - -
 method public <init> (Lnet/minecraft/world/World;)V - -
in 90
class net/minecraft/entity/item/EntityArmorStand 50 public,super net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 method public getCurrentArmor (I)Lnet/minecraft/item/ItemStack; - -
 method public isInRangeToRenderDist (D)Z - -
 method public getLeftArmRotation ()Lnet/minecraft/util/Rotations; - -
 method public getRightArmRotation ()Lnet/minecraft/util/Rotations; - -
 method public getLeftLegRotation ()Lnet/minecraft/util/Rotations; - -
 method public getRightLegRotation ()Lnet/minecraft/util/Rotations; - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public isServerWorld ()Z - -
 method protected entityInit ()V - -
 method public getHeldItem ()Lnet/minecraft/item/ItemStack; - -
 method public getEquipmentInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setCurrentItemOrArmor (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventory ()[Lnet/minecraft/item/ItemStack; - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBePushed ()Z - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected collideWithNearbyEntities ()V - -
 method public interactAt (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/Vec3;)Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected updateDistance (FF)F - -
 method public getEyeHeight ()F - -
 method public moveEntityWithHeading (FF)V - -
 method public onUpdate ()V - -
 method protected updatePotionMetadata ()V - -
 method public setInvisible (Z)V - -
 method public isChild ()Z - -
 method public onKillCommand ()V - -
 method public isImmuneToExplosions ()Z - -
 method public isSmall ()Z - -
 method public hasNoGravity ()Z - -
 method public getShowArms ()Z - -
 method public hasNoBasePlate ()Z - -
 method public hasMarker ()Z - -
 method public setHeadRotation (Lnet/minecraft/util/Rotations;)V - -
 method public setBodyRotation (Lnet/minecraft/util/Rotations;)V - -
 method public setLeftArmRotation (Lnet/minecraft/util/Rotations;)V - -
 method public setRightArmRotation (Lnet/minecraft/util/Rotations;)V - -
 method public setLeftLegRotation (Lnet/minecraft/util/Rotations;)V - -
 method public setRightLegRotation (Lnet/minecraft/util/Rotations;)V - -
 method public getHeadRotation ()Lnet/minecraft/util/Rotations; - -
 method public getBodyRotation ()Lnet/minecraft/util/Rotations; - -
 method public canBeCollidedWith ()Z - -
in 91
class net/minecraft/entity/item/EntityArmorStand 50 public,super net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public,static,final STATUS Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public,static,final HEAD_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final BODY_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final LEFT_ARM_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final RIGHT_ARM_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final LEFT_LEG_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final RIGHT_LEG_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public punchCooldown J -
 method public handleStatusUpdate (B)V - -
 method public isInRangeToRenderDist (D)Z - -
 method public getLeftArmRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getRightArmRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getLeftLegRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getRightLegRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public isServerWorld ()Z - -
 method protected entityInit ()V - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public,static registerFixesArmorStand (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBePushed ()Z - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected collideWithNearbyEntities ()V - -
 method public applyPlayerInteraction (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected updateDistance (FF)F - -
 method public getEyeHeight ()F - -
 method public getYOffset ()D - -
 method public moveEntityWithHeading (FF)V - -
 method public onUpdate ()V - -
 method protected updatePotionMetadata ()V - -
 method public setInvisible (Z)V - -
 method public isChild ()Z - -
 method public onKillCommand ()V - -
 method public isImmuneToExplosions ()Z - -
 method public isSmall ()Z - -
 method public getShowArms ()Z - -
 method public hasNoBasePlate ()Z - -
 method public hasMarker ()Z - -
 method public setHeadRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setBodyRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setLeftArmRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setRightArmRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setLeftLegRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setRightLegRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public getHeadRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getBodyRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public canBeCollidedWith ()Z - -
 method public getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public canBeHitWithPotion ()Z - -
in 326
class net/minecraft/entity/item/EntityArmorStand 52 public,super net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public,static,final STATUS Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public,static,final HEAD_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final BODY_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final LEFT_ARM_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final RIGHT_ARM_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final LEFT_LEG_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public,static,final RIGHT_LEG_ROTATION Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/Rotations;>;
 field public punchCooldown J -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected,final setSize (FF)V - -
 method public isServerWorld ()Z - -
 method protected entityInit ()V - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public,static registerFixesArmorStand (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBePushed ()Z - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected collideWithNearbyEntities ()V - -
 method public applyPlayerInteraction (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method protected getClickedSlot (Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public handleStatusUpdate (B)V - -
 method public isInRangeToRenderDist (D)Z - -
 method protected updateDistance (FF)F - -
 method public getEyeHeight ()F - -
 method public getYOffset ()D - -
 method public travel (FFF)V - -
 method public setRenderYawOffset (F)V - -
 method public setRotationYawHead (F)V - -
 method public onUpdate ()V - -
 method protected updatePotionMetadata ()V - -
 method public setInvisible (Z)V - -
 method public isChild ()Z - -
 method public onKillCommand ()V - -
 method public isImmuneToExplosions ()Z - -
 method public getPushReaction ()Lnet/minecraft/block/material/EnumPushReaction; - -
 method public isSmall ()Z - -
 method public getShowArms ()Z - -
 method public hasNoBasePlate ()Z - -
 method public hasMarker ()Z - -
 method public setHeadRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setBodyRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setLeftArmRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setRightArmRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setLeftLegRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public setRightLegRotation (Lnet/minecraft/util/math/Rotations;)V - -
 method public getHeadRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getBodyRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getLeftArmRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getRightArmRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getLeftLegRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public getRightLegRotation ()Lnet/minecraft/util/math/Rotations; - -
 method public canBeCollidedWith ()Z - -
 method public getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public canBeHitWithPotion ()Z - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public attackable ()Z - -
in 90
class net/minecraft/entity/item/EntityBoat 50 public,super net/minecraft/entity/Entity - -
 method public performHurtAnimation ()V - -
 method public setPositionAndRotation2 (DDDFFIZ)V - -
 method public setVelocity (DDD)V - -
 method public setIsBoatEmpty (Z)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/AxisAlignedBB; - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/AxisAlignedBB; - -
 method public canBePushed ()Z - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMountedYOffset ()D - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canBeCollidedWith ()Z - -
 method public onUpdate ()V - -
 method public updateRiderPosition ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected updateFallState (DZLnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;)V - -
 method public setDamageTaken (F)V - -
 method public getDamageTaken ()F - -
 method public setTimeSinceHit (I)V - -
 method public getTimeSinceHit ()I - -
 method public setForwardDirection (I)V - -
 method public getForwardDirection ()I - -
in 91
class net/minecraft/entity/item/EntityBoat 50 public,super net/minecraft/entity/Entity - -
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 inner net/minecraft/entity/item/EntityBoat$Status net/minecraft/entity/item/EntityBoat Status public,static,final,enum
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 method public performHurtAnimation ()V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public getRowingTime (IF)F - -
 method public applyOrientationToEntity (Lnet/minecraft/entity/Entity;)V - -
 method public updateInputs (ZZZZ)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public canBePushed ()Z - -
 method public getMountedYOffset ()D - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public getItemBoat ()Lnet/minecraft/item/Item; - -
 method public canBeCollidedWith ()Z - -
 method public getAdjustedHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public onUpdate ()V - -
 method public setPaddleState (ZZ)V - -
 method public getWaterLevelAbove ()F - -
 method public getBoatGlide ()F - -
 method public,static getBlockLiquidHeight (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)F - -
 method public,static getLiquidHeight (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)F - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method protected applyYawToEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public getPaddleState (I)Z - -
 method public setDamageTaken (F)V - -
 method public getDamageTaken ()F - -
 method public setTimeSinceHit (I)V - -
 method public getTimeSinceHit ()I - -
 method public setForwardDirection (I)V - -
 method public getForwardDirection ()I - -
 method public setBoatType (Lnet/minecraft/entity/item/EntityBoat$Type;)V - -
 method public getBoatType ()Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method protected canFitPassenger (Lnet/minecraft/entity/Entity;)Z - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
in 326
class net/minecraft/entity/item/EntityBoat 52 public,super net/minecraft/entity/Entity - -
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 inner net/minecraft/entity/item/EntityBoat$Status net/minecraft/entity/item/EntityBoat Status public,static,final,enum
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public canBePushed ()Z - -
 method public getMountedYOffset ()D - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public getItemBoat ()Lnet/minecraft/item/Item; - -
 method public performHurtAnimation ()V - -
 method public canBeCollidedWith ()Z - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public getAdjustedHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public onUpdate ()V - -
 method protected getPaddleSound ()Lnet/minecraft/util/SoundEvent; - -
 method public setPaddleState (ZZ)V - -
 method public getRowingTime (IF)F - -
 method public getWaterLevelAbove ()F - -
 method public getBoatGlide ()F - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method protected applyYawToEntity (Lnet/minecraft/entity/Entity;)V - -
 method public applyOrientationToEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public getPaddleState (I)Z - -
 method public setDamageTaken (F)V - -
 method public getDamageTaken ()F - -
 method public setTimeSinceHit (I)V - -
 method public getTimeSinceHit ()I - -
 method public setForwardDirection (I)V - -
 method public getForwardDirection ()I - -
 method public setBoatType (Lnet/minecraft/entity/item/EntityBoat$Type;)V - -
 method public getBoatType ()Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method protected canFitPassenger (Lnet/minecraft/entity/Entity;)Z - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
 method public updateInputs (ZZZZ)V - -
 method protected addPassenger (Lnet/minecraft/entity/Entity;)V - -
in 91
class net/minecraft/entity/item/EntityBoat$Status 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityBoat$Status;>;
 inner net/minecraft/entity/item/EntityBoat$Status net/minecraft/entity/item/EntityBoat Status public,static,final,enum
 field public,static,final,enum IN_WATER Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum UNDER_WATER Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum UNDER_FLOWING_WATER Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum ON_LAND Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum IN_AIR Lnet/minecraft/entity/item/EntityBoat$Status; -
 method public,static values ()[Lnet/minecraft/entity/item/EntityBoat$Status; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityBoat$Status; - -
in 326
class net/minecraft/entity/item/EntityBoat$Status 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityBoat$Status;>;
 inner net/minecraft/entity/item/EntityBoat$Status net/minecraft/entity/item/EntityBoat Status public,static,final,enum
 field public,static,final,enum IN_WATER Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum UNDER_WATER Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum UNDER_FLOWING_WATER Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum ON_LAND Lnet/minecraft/entity/item/EntityBoat$Status; -
 field public,static,final,enum IN_AIR Lnet/minecraft/entity/item/EntityBoat$Status; -
 method public,static values ()[Lnet/minecraft/entity/item/EntityBoat$Status; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityBoat$Status; - -
in 91
class net/minecraft/entity/item/EntityBoat$Type 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityBoat$Type;>;
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 field public,static,final,enum OAK Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum SPRUCE Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum BIRCH Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum JUNGLE Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum ACACIA Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum DARK_OAK Lnet/minecraft/entity/item/EntityBoat$Type; -
 method public,static values ()[Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method public getName ()Ljava/lang/String; - -
 method public getMetadata ()I - -
 method public toString ()Ljava/lang/String; - -
 method public,static byId (I)Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method public,static getTypeFromString (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityBoat$Type; - -
in 326
class net/minecraft/entity/item/EntityBoat$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityBoat$Type;>;
 inner net/minecraft/entity/item/EntityBoat$Type net/minecraft/entity/item/EntityBoat Type public,static,final,enum
 inner net/minecraft/block/BlockPlanks$EnumType net/minecraft/block/BlockPlanks EnumType public,static,final,enum
 field public,static,final,enum OAK Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum SPRUCE Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum BIRCH Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum JUNGLE Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum ACACIA Lnet/minecraft/entity/item/EntityBoat$Type; -
 field public,static,final,enum DARK_OAK Lnet/minecraft/entity/item/EntityBoat$Type; -
 method public,static values ()[Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method public getName ()Ljava/lang/String; - -
 method public getMetadata ()I - -
 method public toString ()Ljava/lang/String; - -
 method public,static byId (I)Lnet/minecraft/entity/item/EntityBoat$Type; - -
 method public,static getTypeFromString (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityBoat$Type; - -
in 90
class net/minecraft/entity/item/EntityEnderCrystal 50 public,super net/minecraft/entity/Entity - -
 field public innerRotation I -
 field public health I -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
in 91
class net/minecraft/entity/item/EntityEnderCrystal 50 public,super net/minecraft/entity/Entity - -
 field public innerRotation I -
 method public isInRangeToRenderDist (D)Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public onKillCommand ()V - -
 method public setBeamTarget (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getBeamTarget ()Lnet/minecraft/util/math/BlockPos; - -
 method public setShowBottom (Z)V - -
 method public shouldShowBottom ()Z - -
in 326
class net/minecraft/entity/item/EntityEnderCrystal 52 public,super net/minecraft/entity/Entity - -
 field public innerRotation I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public onKillCommand ()V - -
 method public setBeamTarget (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getBeamTarget ()Lnet/minecraft/util/math/BlockPos; - -
 method public setShowBottom (Z)V - -
 method public shouldShowBottom ()Z - -
 method public isInRangeToRenderDist (D)Z - -
in 90
class net/minecraft/entity/item/EntityEnderEye 50 public,super net/minecraft/entity/Entity - -
 method public isInRangeToRenderDist (D)Z - -
 method public setVelocity (DDD)V - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public moveTowards (Lnet/minecraft/util/BlockPos;)V - -
 method public onUpdate ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getBrightness (F)F - -
 method public canAttackWithItem ()Z - -
in 91
class net/minecraft/entity/item/EntityEnderEye 50 public,super net/minecraft/entity/Entity - -
 method public isInRangeToRenderDist (D)Z - -
 method public setVelocity (DDD)V - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public moveTowards (Lnet/minecraft/util/math/BlockPos;)V - -
 method public onUpdate ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getBrightness (F)F - -
 method public canBeAttackedWithItem ()Z - -
in 326
class net/minecraft/entity/item/EntityEnderEye 52 public,super net/minecraft/entity/Entity - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public isInRangeToRenderDist (D)Z - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public moveTowards (Lnet/minecraft/util/math/BlockPos;)V - -
 method public setVelocity (DDD)V - -
 method public onUpdate ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getBrightness ()F - -
 method public getBrightnessForRender ()I - -
 method public canBeAttackedWithItem ()Z - -
in 90
class net/minecraft/entity/item/EntityEnderPearl 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
 method public onUpdate ()V - -
in 91
class net/minecraft/entity/item/EntityEnderPearl 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesEnderPearl (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public onUpdate ()V - -
in 326
class net/minecraft/entity/item/EntityEnderPearl 52 public,super net/minecraft/entity/projectile/EntityThrowable - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesEnderPearl (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public onUpdate ()V - -
 method public changeDimension (ILnet/minecraftforge/common/util/ITeleporter;)Lnet/minecraft/entity/Entity; - -
in 90
class net/minecraft/entity/item/EntityExpBottle 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected getGravityVelocity ()F - -
 method protected getVelocity ()F - -
 method protected getInaccuracy ()F - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
in 91
class net/minecraft/entity/item/EntityExpBottle 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesExpBottle (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getGravityVelocity ()F - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
in 326
class net/minecraft/entity/item/EntityExpBottle 52 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesExpBottle (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getGravityVelocity ()F - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
in 90
class net/minecraft/entity/item/EntityFallingBlock 50 public,super net/minecraft/entity/Entity - -
 field public fallTime I -
 field public shouldDropItem Z -
 field public tileEntityData Lnet/minecraft/nbt/NBTTagCompound; -
 method public getWorldObj ()Lnet/minecraft/world/World; - -
 method public canRenderOnFire ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/block/state/IBlockState;)V - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public canBeCollidedWith ()Z - -
 method public onUpdate ()V - -
 method public fall (FF)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setHurtEntities (Z)V - -
 method public addEntityCrashInfo (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public getBlock ()Lnet/minecraft/block/state/IBlockState; - -
in 91
class net/minecraft/entity/item/EntityFallingBlock 50 public,super net/minecraft/entity/Entity - -
 field public fallTime I -
 field public shouldDropItem Z -
 field public tileEntityData Lnet/minecraft/nbt/NBTTagCompound; -
 field protected,static,final ORIGIN Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/BlockPos;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/block/state/IBlockState;)V - -
 method public setOrigin (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getOrigin ()Lnet/minecraft/util/math/BlockPos; - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public canBeCollidedWith ()Z - -
 method public onUpdate ()V - -
 method public fall (FF)V - -
 method public,static registerFixesFallingBlock (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setHurtEntities (Z)V - -
 method public addEntityCrashInfo (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public getWorldObj ()Lnet/minecraft/world/World; - -
 method public canRenderOnFire ()Z - -
 method public getBlock ()Lnet/minecraft/block/state/IBlockState; - -
 method public ignoreItemEntityData ()Z - -
in 326
class net/minecraft/entity/item/EntityFallingBlock 52 public,super net/minecraft/entity/Entity - -
 field public fallTime I -
 field public shouldDropItem Z -
 field public tileEntityData Lnet/minecraft/nbt/NBTTagCompound; -
 field protected,static,final ORIGIN Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/math/BlockPos;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/block/state/IBlockState;)V - -
 method public canBeAttackedWithItem ()Z - -
 method public setOrigin (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getOrigin ()Lnet/minecraft/util/math/BlockPos; - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public canBeCollidedWith ()Z - -
 method public onUpdate ()V - -
 method public fall (FF)V - -
 method public,static registerFixesFallingBlock (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setHurtEntities (Z)V - -
 method public addEntityCrashInfo (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public getWorldObj ()Lnet/minecraft/world/World; - -
 method public canRenderOnFire ()Z - -
 method public getBlock ()Lnet/minecraft/block/state/IBlockState; - -
 method public ignoreItemEntityData ()Z - -
in 90
class net/minecraft/entity/item/EntityFireworkRocket 50 public,super net/minecraft/entity/Entity - -
 method public isInRangeToRenderDist (D)Z - -
 method public setVelocity (DDD)V - -
 method public handleStatusUpdate (B)V - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method public onUpdate ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getBrightness (F)F - -
 method public canAttackWithItem ()Z - -
in 91
class net/minecraft/entity/item/EntityFireworkRocket 50 public,super net/minecraft/entity/Entity - -
 method public isInRangeToRenderDist (D)Z - -
 method public setVelocity (DDD)V - -
 method public handleStatusUpdate (B)V - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method public onUpdate ()V - -
 method public,static registerFixesFireworkRocket (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getBrightness (F)F - -
 method public canBeAttackedWithItem ()Z - -
in 326
class net/minecraft/entity/item/EntityFireworkRocket 52 public,super net/minecraft/entity/Entity - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public isInRangeToRenderDist (D)Z - -
 method public isInRangeToRender3d (DDD)Z - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public setVelocity (DDD)V - -
 method public onUpdate ()V - -
 method public isAttachedToEntity ()Z - -
 method public handleStatusUpdate (B)V - -
 method public,static registerFixesFireworkRocket (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeAttackedWithItem ()Z - -
in 90
class net/minecraft/entity/item/EntityItem 50 public,super net/minecraft/entity/Entity - -
 field public hoverStart F -
 field public lifespan I -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method protected canTriggerWalking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public setAgeToCreativeDespawnTime ()V - -
 method public handleWaterMovement ()Z - -
 method protected dealFireDamage (I)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getName ()Ljava/lang/String; - -
 method public canAttackWithItem ()Z - -
 method public travelToDimension (I)V - -
 method public getEntityItem ()Lnet/minecraft/item/ItemStack; - -
 method public setEntityItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public getOwner ()Ljava/lang/String; - -
 method public setOwner (Ljava/lang/String;)V - -
 method public getThrower ()Ljava/lang/String; - -
 method public setThrower (Ljava/lang/String;)V - -
 method public getAge ()I - -
 method public setDefaultPickupDelay ()V - -
 method public setNoPickupDelay ()V - -
 method public setInfinitePickupDelay ()V - -
 method public setPickupDelay (I)V - -
 method public cannotPickup ()Z - -
 method public setNoDespawn ()V - -
 method public func_174870_v ()V - -
in 91
class net/minecraft/entity/item/EntityItem 50 public,super net/minecraft/entity/Entity - -
 field public hoverStart F -
 field public lifespan I -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method protected canTriggerWalking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public setAgeToCreativeDespawnTime ()V - -
 method public handleWaterMovement ()Z - -
 method protected dealFireDamage (I)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public,static registerFixesItem (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getName ()Ljava/lang/String; - -
 method public canBeAttackedWithItem ()Z - -
 method public changeDimension (I)Lnet/minecraft/entity/Entity; - -
 method public getEntityItem ()Lnet/minecraft/item/ItemStack; - -
 method public setEntityItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public getOwner ()Ljava/lang/String; - -
 method public setOwner (Ljava/lang/String;)V - -
 method public getThrower ()Ljava/lang/String; - -
 method public setThrower (Ljava/lang/String;)V - -
 method public getAge ()I - -
 method public setDefaultPickupDelay ()V - -
 method public setNoPickupDelay ()V - -
 method public setInfinitePickupDelay ()V - -
 method public setPickupDelay (I)V - -
 method public cannotPickup ()Z - -
 method public setNoDespawn ()V - -
 method public makeFakeItem ()V - -
in 326
class net/minecraft/entity/item/EntityItem 52 public,super net/minecraft/entity/Entity - -
 field public hoverStart F -
 field public lifespan I -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method protected canTriggerWalking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public setAgeToCreativeDespawnTime ()V - -
 method public handleWaterMovement ()Z - -
 method protected dealFireDamage (I)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public,static registerFixesItem (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getName ()Ljava/lang/String; - -
 method public canBeAttackedWithItem ()Z - -
 method public changeDimension (ILnet/minecraftforge/common/util/ITeleporter;)Lnet/minecraft/entity/Entity; - -
 method public getItem ()Lnet/minecraft/item/ItemStack; - -
 method public setItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getOwner ()Ljava/lang/String; - -
 method public setOwner (Ljava/lang/String;)V - -
 method public getThrower ()Ljava/lang/String; - -
 method public setThrower (Ljava/lang/String;)V - -
 method public getAge ()I - -
 method public setDefaultPickupDelay ()V - -
 method public setNoPickupDelay ()V - -
 method public setInfinitePickupDelay ()V - -
 method public setPickupDelay (I)V - -
 method public cannotPickup ()Z - -
 method public setNoDespawn ()V - -
 method public makeFakeItem ()V - -
in 90
class net/minecraft/entity/item/EntityItemFrame 50 public,super net/minecraft/entity/EntityHanging - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;)V - -
 method protected entityInit ()V - -
 method public getCollisionBorderSize ()F - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public isInRangeToRenderDist (D)Z - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public dropItemOrSelf (Lnet/minecraft/entity/Entity;Z)V - -
 method public getDisplayedItem ()Lnet/minecraft/item/ItemStack; - -
 method public setDisplayedItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getRotation ()I - -
 method public setItemRotation (I)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public func_174866_q ()I - -
in 91
class net/minecraft/entity/item/EntityItemFrame 50 public,super net/minecraft/entity/EntityHanging - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V - -
 method protected entityInit ()V - -
 method public getCollisionBorderSize ()F - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public isInRangeToRenderDist (D)Z - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public playPlaceSound ()V - -
 method public dropItemOrSelf (Lnet/minecraft/entity/Entity;Z)V - -
 method public getDisplayedItem ()Lnet/minecraft/item/ItemStack; - -
 method public setDisplayedItem (Lnet/minecraft/item/ItemStack;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getRotation ()I - -
 method public setItemRotation (I)V - -
 method public,static registerFixesItemFrame (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method public getAnalogOutput ()I - -
in 326
class net/minecraft/entity/item/EntityItemFrame 52 public,super net/minecraft/entity/EntityHanging - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V - -
 method protected entityInit ()V - -
 method public getCollisionBorderSize ()F - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public isInRangeToRenderDist (D)Z - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public playPlaceSound ()V - -
 method public dropItemOrSelf (Lnet/minecraft/entity/Entity;Z)V - -
 method public getDisplayedItem ()Lnet/minecraft/item/ItemStack; - -
 method public setDisplayedItem (Lnet/minecraft/item/ItemStack;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getRotation ()I - -
 method public setItemRotation (I)V - -
 method public,static registerFixesItemFrame (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public getAnalogOutput ()I - -
in 90
class net/minecraft/entity/item/EntityMinecart 50 public,super,abstract net/minecraft/entity/Entity net/minecraft/world/IWorldNameable -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 inner net/minecraft/block/BlockRailBase$EnumRailDirection net/minecraft/block/BlockRailBase EnumRailDirection public,static,final,enum
 field public,static defaultMaxSpeedAirLateral F -
 field public,static defaultMaxSpeedAirVertical F -
 field public,static defaultDragAir D -
 field protected canUseRail Z -
 field protected canBePushed Z -
 field protected maxSpeedAirLateral F -
 field protected maxSpeedAirVertical F -
 field protected dragAir D -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static getMinecart (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/item/EntityMinecart$EnumMinecartType;)Lnet/minecraft/entity/item/EntityMinecart; - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/AxisAlignedBB; - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/AxisAlignedBB; - -
 method public canBePushed ()Z - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMountedYOffset ()D - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public performHurtAnimation ()V - -
 method public canBeCollidedWith ()Z - -
 method public setDead ()V - -
 method public onUpdate ()V - -
 method protected getMaximumSpeed ()D - -
 method public onActivatorRailPass (IIIZ)V - -
 method protected moveDerailedMinecart ()V - -
 method protected func_180460_a (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method protected applyDrag ()V - -
 method public setPosition (DDD)V - -
 method public func_70495_a (DDDD)Lnet/minecraft/util/Vec3; - -
 method public func_70489_a (DDD)Lnet/minecraft/util/Vec3; - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public setPositionAndRotation2 (DDDFFIZ)V - -
 method public setDamage (F)V - -
 method public setVelocity (DDD)V - -
 method public getDamage ()F - -
 method public setRollingAmplitude (I)V - -
 method public getRollingAmplitude ()I - -
 method public setRollingDirection (I)V - -
 method public getRollingDirection ()I - -
 method public,abstract getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public getDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDisplayTileOffset ()I - -
 method public getDefaultDisplayTileOffset ()I - -
 method public func_174899_a (Lnet/minecraft/block/state/IBlockState;)V - -
 method public setDisplayTileOffset (I)V - -
 method public hasDisplayTile ()Z - -
 method public setHasDisplayTile (Z)V - -
 method public setCustomNameTag (Ljava/lang/String;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getCustomNameTag ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method protected getMaxSpeed ()D - -
 method public moveMinecartOnRail (Lnet/minecraft/util/BlockPos;)V - -
 method public,static getCollisionHandler ()Lnet/minecraftforge/common/IMinecartCollisionHandler; - -
 method public,static setCollisionHandler (Lnet/minecraftforge/common/IMinecartCollisionHandler;)V - -
 method public getCartItem ()Lnet/minecraft/item/ItemStack; - -
 method public canUseRail ()Z - -
 method public setCanUseRail (Z)V - -
 method public shouldDoRailFunctions ()Z - -
 method public isPoweredCart ()Z - -
 method public canBeRidden ()Z - -
 method public getMaxCartSpeedOnRail ()F - -
 method public,final getCurrentCartSpeedCapOnRail ()F - -
 method public,final setCurrentCartSpeedCapOnRail (F)V - -
 method public getMaxSpeedAirLateral ()F - -
 method public setMaxSpeedAirLateral (F)V - -
 method public getMaxSpeedAirVertical ()F - -
 method public setMaxSpeedAirVertical (F)V - -
 method public getDragAir ()D - -
 method public setDragAir (D)V - -
 method public getSlopeAdjustment ()D - -
in 91
class net/minecraft/entity/item/EntityMinecart 50 public,super,abstract net/minecraft/entity/Entity net/minecraft/world/IWorldNameable -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 inner net/minecraft/block/BlockRailBase$EnumRailDirection net/minecraft/block/BlockRailBase EnumRailDirection public,static,final,enum
 field public,static defaultMaxSpeedAirLateral F -
 field public,static defaultMaxSpeedAirVertical F -
 field public,static defaultDragAir D -
 field protected canUseRail Z -
 field protected canBePushed Z -
 field protected maxSpeedAirLateral F -
 field protected maxSpeedAirVertical F -
 field protected dragAir D -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static create (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/item/EntityMinecart$Type;)Lnet/minecraft/entity/item/EntityMinecart; - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public canBePushed ()Z - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMountedYOffset ()D - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public performHurtAnimation ()V - -
 method public canBeCollidedWith ()Z - -
 method public setDead ()V - -
 method public getAdjustedHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public onUpdate ()V - -
 method protected getMaximumSpeed ()D - -
 method public onActivatorRailPass (IIIZ)V - -
 method protected moveDerailedMinecart ()V - -
 method protected moveAlongTrack (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method protected applyDrag ()V - -
 method public setPosition (DDD)V - -
 method public getPosOffset (DDDD)Lnet/minecraft/util/math/Vec3d; - -
 method public getPos (DDD)Lnet/minecraft/util/math/Vec3d; - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public,static registerFixesMinecart (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public setDamage (F)V - -
 method public setVelocity (DDD)V - -
 method public getDamage ()F - -
 method public setRollingAmplitude (I)V - -
 method public getRollingAmplitude ()I - -
 method public setRollingDirection (I)V - -
 method public getRollingDirection ()I - -
 method public,abstract getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDisplayTileOffset ()I - -
 method public getDefaultDisplayTileOffset ()I - -
 method public setDisplayTile (Lnet/minecraft/block/state/IBlockState;)V - -
 method public setDisplayTileOffset (I)V - -
 method public hasDisplayTile ()Z - -
 method public setHasDisplayTile (Z)V - -
 method protected getMaxSpeed ()D - -
 method public moveMinecartOnRail (Lnet/minecraft/util/math/BlockPos;)V - -
 method public,static getCollisionHandler ()Lnet/minecraftforge/common/IMinecartCollisionHandler; - -
 method public,static setCollisionHandler (Lnet/minecraftforge/common/IMinecartCollisionHandler;)V - -
 method public getCartItem ()Lnet/minecraft/item/ItemStack; - -
 method public canUseRail ()Z - -
 method public setCanUseRail (Z)V - -
 method public shouldDoRailFunctions ()Z - -
 method public isPoweredCart ()Z - -
 method public canBeRidden ()Z - -
 method public getMaxCartSpeedOnRail ()F - -
 method public,final getCurrentCartSpeedCapOnRail ()F - -
 method public,final setCurrentCartSpeedCapOnRail (F)V - -
 method public getMaxSpeedAirLateral ()F - -
 method public setMaxSpeedAirLateral (F)V - -
 method public getMaxSpeedAirVertical ()F - -
 method public setMaxSpeedAirVertical (F)V - -
 method public getDragAir ()D - -
 method public setDragAir (D)V - -
 method public getSlopeAdjustment ()D - -
 method public getComparatorLevel ()I - -
in 326
class net/minecraft/entity/item/EntityMinecart 52 public,super,abstract net/minecraft/entity/Entity net/minecraft/world/IWorldNameable -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 inner net/minecraft/block/BlockRailBase$EnumRailDirection net/minecraft/block/BlockRailBase EnumRailDirection public,static,final,enum
 field public,static defaultMaxSpeedAirLateral F -
 field public,static defaultMaxSpeedAirVertical F -
 field public,static defaultDragAir D -
 field protected canUseRail Z -
 field protected canBePushed Z -
 field protected maxSpeedAirLateral F -
 field protected maxSpeedAirVertical F -
 field protected dragAir D -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static create (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/item/EntityMinecart$Type;)Lnet/minecraft/entity/item/EntityMinecart; - -
 method protected canTriggerWalking ()Z - -
 method protected entityInit ()V - -
 method public getCollisionBox (Lnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public canBePushed ()Z - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMountedYOffset ()D - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public performHurtAnimation ()V - -
 method public canBeCollidedWith ()Z - -
 method public getAdjustedHorizontalFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public onUpdate ()V - -
 method protected getMaximumSpeed ()D - -
 method public onActivatorRailPass (IIIZ)V - -
 method protected moveDerailedMinecart ()V - -
 method protected moveAlongTrack (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method protected applyDrag ()V - -
 method public setPosition (DDD)V - -
 method public getPosOffset (DDDD)Lnet/minecraft/util/math/Vec3d; - -
 method public getPos (DDD)Lnet/minecraft/util/math/Vec3d; - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public,static registerFixesMinecart (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class;)V (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class<*>;)V -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public setDamage (F)V - -
 method public setVelocity (DDD)V - -
 method public getDamage ()F - -
 method public setRollingAmplitude (I)V - -
 method public getRollingAmplitude ()I - -
 method public setRollingDirection (I)V - -
 method public getRollingDirection ()I - -
 method public,abstract getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDisplayTileOffset ()I - -
 method public getDefaultDisplayTileOffset ()I - -
 method public setDisplayTile (Lnet/minecraft/block/state/IBlockState;)V - -
 method public setDisplayTileOffset (I)V - -
 method public hasDisplayTile ()Z - -
 method public setHasDisplayTile (Z)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected getMaxSpeed ()D - -
 method public moveMinecartOnRail (Lnet/minecraft/util/math/BlockPos;)V - -
 method public,static getCollisionHandler ()Lnet/minecraftforge/common/IMinecartCollisionHandler; - -
 method public,static setCollisionHandler (Lnet/minecraftforge/common/IMinecartCollisionHandler;)V - -
 method public getCartItem ()Lnet/minecraft/item/ItemStack; - -
 method public canUseRail ()Z - -
 method public setCanUseRail (Z)V - -
 method public shouldDoRailFunctions ()Z - -
 method public isPoweredCart ()Z - -
 method public canBeRidden ()Z - -
 method public getMaxCartSpeedOnRail ()F - -
 method public,final getCurrentCartSpeedCapOnRail ()F - -
 method public,final setCurrentCartSpeedCapOnRail (F)V - -
 method public getMaxSpeedAirLateral ()F - -
 method public setMaxSpeedAirLateral (F)V - -
 method public getMaxSpeedAirVertical ()F - -
 method public setMaxSpeedAirVertical (F)V - -
 method public getDragAir ()D - -
 method public setDragAir (D)V - -
 method public getSlopeAdjustment ()D - -
 method public getComparatorLevel ()I - -
in 90
class net/minecraft/entity/item/EntityMinecart$EnumMinecartType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType;>;
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 field public,static,final,enum RIDEABLE Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; -
 field public,static,final,enum CHEST Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; -
 field public,static,final,enum FURNACE Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; -
 field public,static,final,enum TNT Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; -
 field public,static,final,enum SPAWNER Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; -
 field public,static,final,enum HOPPER Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; -
 field public,static,final,enum COMMAND_BLOCK Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; -
 method public,static values ()[Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public getNetworkID ()I - -
 method public getName ()Ljava/lang/String; - -
 method public,static byNetworkID (I)Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
in 91
class net/minecraft/entity/item/EntityMinecart$Type 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityMinecart$Type;>;
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public,static,final,enum RIDEABLE Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum CHEST Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum FURNACE Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum TNT Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum SPAWNER Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum HOPPER Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum COMMAND_BLOCK Lnet/minecraft/entity/item/EntityMinecart$Type; -
 method public,static values ()[Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public,static getById (I)Lnet/minecraft/entity/item/EntityMinecart$Type; - -
in 326
class net/minecraft/entity/item/EntityMinecart$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityMinecart$Type;>;
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public,static,final,enum RIDEABLE Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum CHEST Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum FURNACE Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum TNT Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum SPAWNER Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum HOPPER Lnet/minecraft/entity/item/EntityMinecart$Type; -
 field public,static,final,enum COMMAND_BLOCK Lnet/minecraft/entity/item/EntityMinecart$Type; -
 method public,static values ()[Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getId ()I - -
 method public getName ()Ljava/lang/String; - -
 method public,static getById (I)Lnet/minecraft/entity/item/EntityMinecart$Type; - -
in 90
class net/minecraft/entity/item/EntityMinecartChest 50 public,super net/minecraft/entity/item/EntityMinecartContainer - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public getSizeInventory ()I - -
 method public getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTileOffset ()I - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
in 91
class net/minecraft/entity/item/EntityMinecartChest 50 public,super net/minecraft/entity/item/EntityMinecartContainer - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartChest (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public getSizeInventory ()I - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTileOffset ()I - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
in 326
class net/minecraft/entity/item/EntityMinecartChest 52 public,super net/minecraft/entity/item/EntityMinecartContainer - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartChest (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public getSizeInventory ()I - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTileOffset ()I - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
in 91
class net/minecraft/entity/item/EntityMinecartCommandBlock 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartCommand (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getCommandBlockLogic ()Lnet/minecraft/tileentity/CommandBlockBaseLogic; - -
 method public onActivatorRailPass (IIIZ)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public ignoreItemEntityData ()Z - -
in 326
class net/minecraft/entity/item/EntityMinecartCommandBlock 52 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartCommand (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getCommandBlockLogic ()Lnet/minecraft/tileentity/CommandBlockBaseLogic; - -
 method public onActivatorRailPass (IIIZ)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public ignoreItemEntityData ()Z - -
in 90
class net/minecraft/entity/item/EntityMinecartContainer 50 public,super,abstract net/minecraft/entity/item/EntityMinecart net/minecraft/world/ILockableContainer -
 field public dropContentsWhenDead Z -
 field public itemHandler Lnet/minecraftforge/items/IItemHandler; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public markDirty ()V - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public getInventoryStackLimit ()I - -
 method public travelToDimension (I)V - -
 method public setDead ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected applyDrag ()V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public isLocked ()Z - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public clear ()V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 91
class net/minecraft/entity/item/EntityMinecartContainer 50 public,super,abstract net/minecraft/entity/item/EntityMinecart net/minecraft/world/ILockableContainer,net/minecraft/world/storage/loot/ILootContainer -
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 field public dropContentsWhenDead Z -
 field public itemHandler Lnet/minecraftforge/items/IItemHandler; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getInventoryStackLimit ()I - -
 method public changeDimension (I)Lnet/minecraft/entity/Entity; - -
 method public setDead ()V - -
 method public setDropItemsWhenDead (Z)V - -
 method public,static registerFixesMinecartContainer (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method protected applyDrag ()V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public isLocked ()Z - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public addLoot (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public clear ()V - -
 method public setLootTable (Lnet/minecraft/util/ResourceLocation;J)V - -
 method public getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 326
class net/minecraft/entity/item/EntityMinecartContainer 52 public,super,abstract net/minecraft/entity/item/EntityMinecart net/minecraft/world/ILockableContainer,net/minecraft/world/storage/loot/ILootContainer -
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 field public dropContentsWhenDead Z -
 field public itemHandler Lnet/minecraftforge/items/IItemHandler; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public isEmpty ()Z - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getInventoryStackLimit ()I - -
 method public changeDimension (ILnet/minecraftforge/common/util/ITeleporter;)Lnet/minecraft/entity/Entity; - -
 method public setDead ()V - -
 method public setDropItemsWhenDead (Z)V - -
 method public,static addDataFixers (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class;)V (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class<*>;)V -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected applyDrag ()V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public isLocked ()Z - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public addLoot (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public clear ()V - -
 method public setLootTable (Lnet/minecraft/util/ResourceLocation;J)V - -
 method public getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 90
class net/minecraft/entity/item/EntityMinecartEmpty 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onActivatorRailPass (IIIZ)V - -
 method public getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
in 91
class net/minecraft/entity/item/EntityMinecartEmpty 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartEmpty (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method public onActivatorRailPass (IIIZ)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
in 326
class net/minecraft/entity/item/EntityMinecartEmpty 52 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartEmpty (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public onActivatorRailPass (IIIZ)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
in 90
class net/minecraft/entity/item/EntityMinecartFurnace 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 field public pushX D -
 field public pushZ D -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected getMaximumSpeed ()D - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method protected func_180460_a (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method protected applyDrag ()V - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected isMinecartPowered ()Z - -
 method protected setMinecartPowered (Z)V - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
in 91
class net/minecraft/entity/item/EntityMinecartFurnace 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public pushX D -
 field public pushZ D -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartFurnace (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected getMaximumSpeed ()D - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method protected moveAlongTrack (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method protected applyDrag ()V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected isMinecartPowered ()Z - -
 method protected setMinecartPowered (Z)V - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
in 326
class net/minecraft/entity/item/EntityMinecartFurnace 52 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 field public pushX D -
 field public pushZ D -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartFurnace (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected getMaximumSpeed ()D - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method protected moveAlongTrack (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)V - -
 method protected applyDrag ()V - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected isMinecartPowered ()Z - -
 method protected setMinecartPowered (Z)V - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
in 90
class net/minecraft/entity/item/EntityMinecartHopper 50 public,super net/minecraft/entity/item/EntityMinecartContainer net/minecraft/tileentity/IHopper -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTileOffset ()I - -
 method public getSizeInventory ()I - -
 method public interactFirst (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onActivatorRailPass (IIIZ)V - -
 method public getBlocked ()Z - -
 method public setBlocked (Z)V - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public getXPos ()D - -
 method public getYPos ()D - -
 method public getZPos ()D - -
 method public onUpdate ()V - -
 method public func_96112_aD ()Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setTransferTicker (I)V - -
 method public canTransfer ()Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
in 91
class net/minecraft/entity/item/EntityMinecartHopper 50 public,super net/minecraft/entity/item/EntityMinecartContainer net/minecraft/tileentity/IHopper -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTileOffset ()I - -
 method public getSizeInventory ()I - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Z - -
 method public onActivatorRailPass (IIIZ)V - -
 method public getBlocked ()Z - -
 method public setBlocked (Z)V - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public getXPos ()D - -
 method public getYPos ()D - -
 method public getZPos ()D - -
 method public onUpdate ()V - -
 method public captureDroppedItems ()Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public,static registerFixesMinecartHopper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setTransferTicker (I)V - -
 method public canTransfer ()Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
in 326
class net/minecraft/entity/item/EntityMinecartHopper 52 public,super net/minecraft/entity/item/EntityMinecartContainer net/minecraft/tileentity/IHopper -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public getDefaultDisplayTileOffset ()I - -
 method public getSizeInventory ()I - -
 method public processInitialInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public onActivatorRailPass (IIIZ)V - -
 method public getBlocked ()Z - -
 method public setBlocked (Z)V - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public getXPos ()D - -
 method public getYPos ()D - -
 method public getZPos ()D - -
 method public onUpdate ()V - -
 method public captureDroppedItems ()Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method public,static registerFixesMinecartHopper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setTransferTicker (I)V - -
 method public canTransfer ()Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
in 91
class net/minecraft/entity/item/EntityMinecartMobSpawner 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartMobSpawner (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
in 326
class net/minecraft/entity/item/EntityMinecartMobSpawner 52 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartMobSpawner (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public handleStatusUpdate (B)V - -
 method public onUpdate ()V - -
in 90
class net/minecraft/entity/item/EntityMinecartTNT 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 method public handleStatusUpdate (B)V - -
 method public getFuseTicks ()I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public getMinecartType ()Lnet/minecraft/entity/item/EntityMinecart$EnumMinecartType; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public onUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method protected explodeCart (D)V - -
 method public fall (FF)V - -
 method public onActivatorRailPass (IIIZ)V - -
 method public ignite ()V - -
 method public isIgnited ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method public verifyExplosion (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;F)Z - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/entity/item/EntityMinecartTNT 50 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public handleStatusUpdate (B)V - -
 method public getFuseTicks ()I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartTNT (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public onUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method protected explodeCart (D)V - -
 method public fall (FF)V - -
 method public onActivatorRailPass (IIIZ)V - -
 method public ignite ()V - -
 method public isIgnited ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method public verifyExplosion (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;F)Z - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/entity/item/EntityMinecartTNT 52 public,super net/minecraft/entity/item/EntityMinecart - -
 inner net/minecraft/entity/item/EntityMinecart$Type net/minecraft/entity/item/EntityMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesMinecartTNT (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getType ()Lnet/minecraft/entity/item/EntityMinecart$Type; - -
 method public getDefaultDisplayTile ()Lnet/minecraft/block/state/IBlockState; - -
 method public onUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public killMinecart (Lnet/minecraft/util/DamageSource;)V - -
 method protected explodeCart (D)V - -
 method public fall (FF)V - -
 method public onActivatorRailPass (IIIZ)V - -
 method public handleStatusUpdate (B)V - -
 method public ignite ()V - -
 method public getFuseTicks ()I - -
 method public isIgnited ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method public canExplosionDestroyBlock (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;F)Z - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 90
class net/minecraft/entity/item/EntityPainting 50 public,super net/minecraft/entity/EntityHanging - -
 inner net/minecraft/entity/item/EntityPainting$EnumArt net/minecraft/entity/item/EntityPainting EnumArt public,static,final,enum
 field public art Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;Ljava/lang/String;)V - -
 method public setPositionAndRotation2 (DDDFFIZ)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public setLocationAndAngles (DDDFF)V - -
in 91
class net/minecraft/entity/item/EntityPainting 50 public,super net/minecraft/entity/EntityHanging - -
 inner net/minecraft/entity/item/EntityPainting$EnumArt net/minecraft/entity/item/EntityPainting EnumArt public,static,final,enum
 field public art Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Ljava/lang/String;)V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public playPlaceSound ()V - -
 method public setLocationAndAngles (DDDFF)V - -
in 326
class net/minecraft/entity/item/EntityPainting 52 public,super net/minecraft/entity/EntityHanging - -
 inner net/minecraft/entity/item/EntityPainting$EnumArt net/minecraft/entity/item/EntityPainting EnumArt public,static,final,enum
 field public art Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Ljava/lang/String;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getWidthPixels ()I - -
 method public getHeightPixels ()I - -
 method public onBroken (Lnet/minecraft/entity/Entity;)V - -
 method public playPlaceSound ()V - -
 method public setLocationAndAngles (DDDFF)V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
in 90
class net/minecraft/entity/item/EntityPainting$EnumArt 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityPainting$EnumArt;>;
 inner net/minecraft/entity/item/EntityPainting$EnumArt net/minecraft/entity/item/EntityPainting EnumArt public,static,final,enum
 field public,static,final,enum KEBAB Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum AZTEC Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum ALBAN Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum AZTEC_2 Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BOMB Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum PLANT Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WASTELAND Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum POOL Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum COURBET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SEA Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SUNSET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum CREEBET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WANDERER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum GRAHAM Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum MATCH Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BUST Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum STAGE Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum VOID Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SKULL_AND_ROSES Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WITHER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum FIGHTERS Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum POINTER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum PIGSCENE Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BURNING_SKULL Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SKELETON Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum DONKEY_KONG Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final field_180001_A I -
 field public,final title Ljava/lang/String; -
 field public,final sizeX I -
 field public,final sizeY I -
 field public,final offsetX I -
 field public,final offsetY I -
 method public,static values ()[Lnet/minecraft/entity/item/EntityPainting$EnumArt; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityPainting$EnumArt; - -
in 91
class net/minecraft/entity/item/EntityPainting$EnumArt 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityPainting$EnumArt;>;
 inner net/minecraft/entity/item/EntityPainting$EnumArt net/minecraft/entity/item/EntityPainting EnumArt public,static,final,enum
 field public,static,final,enum KEBAB Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum AZTEC Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum ALBAN Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum AZTEC_2 Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BOMB Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum PLANT Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WASTELAND Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum POOL Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum COURBET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SEA Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SUNSET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum CREEBET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WANDERER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum GRAHAM Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum MATCH Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BUST Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum STAGE Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum VOID Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SKULL_AND_ROSES Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WITHER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum FIGHTERS Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum POINTER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum PIGSCENE Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BURNING_SKULL Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SKELETON Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum DONKEY_KONG Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final MAX_NAME_LENGTH I -
 field public,final title Ljava/lang/String; -
 field public,final sizeX I -
 field public,final sizeY I -
 field public,final offsetX I -
 field public,final offsetY I -
 method public,static values ()[Lnet/minecraft/entity/item/EntityPainting$EnumArt; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityPainting$EnumArt; - -
in 326
class net/minecraft/entity/item/EntityPainting$EnumArt 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/item/EntityPainting$EnumArt;>;
 inner net/minecraft/entity/item/EntityPainting$EnumArt net/minecraft/entity/item/EntityPainting EnumArt public,static,final,enum
 field public,static,final,enum KEBAB Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum AZTEC Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum ALBAN Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum AZTEC_2 Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BOMB Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum PLANT Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WASTELAND Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum POOL Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum COURBET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SEA Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SUNSET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum CREEBET Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WANDERER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum GRAHAM Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum MATCH Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BUST Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum STAGE Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum VOID Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SKULL_AND_ROSES Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum WITHER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum FIGHTERS Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum POINTER Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum PIGSCENE Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum BURNING_SKULL Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum SKELETON Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final,enum DONKEY_KONG Lnet/minecraft/entity/item/EntityPainting$EnumArt; -
 field public,static,final MAX_NAME_LENGTH I -
 field public,final title Ljava/lang/String; -
 field public,final sizeX I -
 field public,final sizeY I -
 field public,final offsetX I -
 field public,final offsetY I -
 method public,static values ()[Lnet/minecraft/entity/item/EntityPainting$EnumArt; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/item/EntityPainting$EnumArt; - -
in 90
class net/minecraft/entity/item/EntityTNTPrimed 50 public,super net/minecraft/entity/Entity - -
 field public fuse I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method protected canTriggerWalking ()Z - -
 method public canBeCollidedWith ()Z - -
 method public onUpdate ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getTntPlacedBy ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/item/EntityTNTPrimed 50 public,super net/minecraft/entity/Entity - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method protected canTriggerWalking ()Z - -
 method public canBeCollidedWith ()Z - -
 method public onUpdate ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getTntPlacedBy ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getEyeHeight ()F - -
 method public setFuse (I)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getFuseDataManager ()I - -
 method public getFuse ()I - -
in 326
class net/minecraft/entity/item/EntityTNTPrimed 52 public,super net/minecraft/entity/Entity - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method protected canTriggerWalking ()Z - -
 method public canBeCollidedWith ()Z - -
 method public onUpdate ()V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getTntPlacedBy ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public getEyeHeight ()F - -
 method public setFuse (I)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getFuseDataManager ()I - -
 method public getFuse ()I - -
in 90
class net/minecraft/entity/item/EntityXPOrb 50 public,super net/minecraft/entity/Entity - -
 field public xpColor I -
 field public xpOrbAge I -
 field public delayBeforeCanPickup I -
 field public xpValue I -
 method public <init> (Lnet/minecraft/world/World;DDDI)V - -
 method protected canTriggerWalking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public getBrightnessForRender (F)I - -
 method public onUpdate ()V - -
 method public handleWaterMovement ()Z - -
 method protected dealFireDamage (I)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getXpValue ()I - -
 method public getTextureByXP ()I - -
 method public,static getXPSplit (I)I - -
 method public canAttackWithItem ()Z - -
in 91
class net/minecraft/entity/item/EntityXPOrb 50 public,super net/minecraft/entity/Entity - -
 field public xpColor I -
 field public xpOrbAge I -
 field public delayBeforeCanPickup I -
 field public xpValue I -
 method public <init> (Lnet/minecraft/world/World;DDDI)V - -
 method protected canTriggerWalking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public getBrightnessForRender (F)I - -
 method public onUpdate ()V - -
 method public handleWaterMovement ()Z - -
 method protected dealFireDamage (I)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getXpValue ()I - -
 method public getTextureByXP ()I - -
 method public,static getXPSplit (I)I - -
 method public canBeAttackedWithItem ()Z - -
in 326
class net/minecraft/entity/item/EntityXPOrb 52 public,super net/minecraft/entity/Entity - -
 field public xpColor I -
 field public xpOrbAge I -
 field public delayBeforeCanPickup I -
 field public xpValue I -
 method public <init> (Lnet/minecraft/world/World;DDDI)V - -
 method protected canTriggerWalking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public getBrightnessForRender ()I - -
 method public onUpdate ()V - -
 method public handleWaterMovement ()Z - -
 method protected dealFireDamage (I)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getXpValue ()I - -
 method public getTextureByXP ()I - -
 method public,static getXPSplit (I)I - -
 method public canBeAttackedWithItem ()Z - -
in 326
class net/minecraft/entity/monster/AbstractIllager 52 public,super,abstract net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/AbstractIllager$IllagerArmPose net/minecraft/entity/monster/AbstractIllager IllagerArmPose public,static,final,enum
 field protected,static,final AGGRESSIVE Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected isAggressive (I)Z - -
 method protected setAggressive (IZ)V - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public getArmPose ()Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; - -
in 326
class net/minecraft/entity/monster/AbstractIllager$IllagerArmPose 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose;>;
 inner net/minecraft/entity/monster/AbstractIllager$IllagerArmPose net/minecraft/entity/monster/AbstractIllager IllagerArmPose public,static,final,enum
 field public,static,final,enum CROSSED Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; -
 field public,static,final,enum ATTACKING Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; -
 field public,static,final,enum SPELLCASTING Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; -
 field public,static,final,enum BOW_AND_ARROW Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; -
 method public,static values ()[Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; - -
in 326
class net/minecraft/entity/monster/AbstractSkeleton 52 public,super,abstract net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected,abstract getStepSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public onLivingUpdate ()V - -
 method public updateRidden ()V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public setCombatTask ()V - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method protected getArrow (F)Lnet/minecraft/entity/projectile/EntityArrow; - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public getEyeHeight ()F - -
 method public getYOffset ()D - -
 method public isSwingingArms ()Z - -
 method public setSwingingArms (Z)V - -
in 90
class net/minecraft/entity/monster/EntityBlaze 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityBlaze$AIFireballAttack net/minecraft/entity/monster/EntityBlaze AIFireballAttack static
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public getBrightness (F)F - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method public fall (FF)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public isBurning ()Z - -
 method protected dropFewItems (ZI)V - -
 method public func_70845_n ()Z - -
 method public setOnFire (Z)V - -
 method protected isValidLightLevel ()Z - -
in 91
class net/minecraft/entity/monster/EntityBlaze 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityBlaze$AIFireballAttack net/minecraft/entity/monster/EntityBlaze AIFireballAttack static
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesBlaze (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getBrightness (F)F - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method public fall (FF)V - -
 method public isBurning ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isCharged ()Z - -
 method public setOnFire (Z)V - -
 method protected isValidLightLevel ()Z - -
in 326
class net/minecraft/entity/monster/EntityBlaze 52 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityBlaze$AIFireballAttack net/minecraft/entity/monster/EntityBlaze AIFireballAttack static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesBlaze (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getBrightnessForRender ()I - -
 method public getBrightness ()F - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method public fall (FF)V - -
 method public isBurning ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isCharged ()Z - -
 method public setOnFire (Z)V - -
 method protected isValidLightLevel ()Z - -
in 24
class net/minecraft/entity/monster/EntityBlaze$AIFireballAttack 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityBlaze$AIFireballAttack net/minecraft/entity/monster/EntityBlaze AIFireballAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntityBlaze;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityBlaze$AIFireballAttack 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityBlaze$AIFireballAttack net/minecraft/entity/monster/EntityBlaze AIFireballAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntityBlaze;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/monster/EntityCaveSpider 50 public,super net/minecraft/entity/monster/EntitySpider - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/monster/EntityCaveSpider 50 public,super net/minecraft/entity/monster/EntitySpider - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesCaveSpider (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected applyEntityAttributes ()V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 326
class net/minecraft/entity/monster/EntityCaveSpider 52 public,super net/minecraft/entity/monster/EntitySpider - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesCaveSpider (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected applyEntityAttributes ()V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 90
class net/minecraft/entity/monster/EntityCreeper 50 public,super net/minecraft/entity/monster/EntityMob - -
 method public getCreeperFlashIntensity (F)F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public getMaxFallHeight ()I - -
 method public fall (FF)V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getPowered ()Z - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public getCreeperState ()I - -
 method public setCreeperState (I)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method protected interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public hasIgnited ()Z - -
 method public ignite ()V - -
 method public isAIEnabled ()Z - -
 method public func_175493_co ()V - -
in 91
class net/minecraft/entity/monster/EntityCreeper 50 public,super net/minecraft/entity/monster/EntityMob - -
 method public getCreeperFlashIntensity (F)F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public getMaxFallHeight ()I - -
 method public fall (FF)V - -
 method protected entityInit ()V - -
 method public,static registerFixesCreeper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getPowered ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getCreeperState ()I - -
 method public setCreeperState (I)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method protected processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method public hasIgnited ()Z - -
 method public ignite ()V - -
 method public isAIEnabled ()Z - -
 method public incrementDroppedSkulls ()V - -
in 326
class net/minecraft/entity/monster/EntityCreeper 52 public,super net/minecraft/entity/monster/EntityMob - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public getMaxFallHeight ()I - -
 method public fall (FF)V - -
 method protected entityInit ()V - -
 method public,static registerFixesCreeper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getPowered ()Z - -
 method public getCreeperFlashIntensity (F)F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getCreeperState ()I - -
 method public setCreeperState (I)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method protected processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public hasIgnited ()Z - -
 method public ignite ()V - -
 method public ableToCauseSkullDrop ()Z - -
 method public incrementDroppedSkulls ()V - -
in 326
class net/minecraft/entity/monster/EntityElderGuardian 52 public,super net/minecraft/entity/monster/EntityGuardian - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public,static registerFixesElderGuardian (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getAttackDuration ()I - -
 method public setGhost ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getFlopSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected updateAITasks ()V - -
in 90
class net/minecraft/entity/monster/EntityEnderman 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityEnderman$AITakeBlock net/minecraft/entity/monster/EntityEnderman AITakeBlock static
 inner net/minecraft/entity/monster/EntityEnderman$AIPlaceBlock net/minecraft/entity/monster/EntityEnderman AIPlaceBlock static
 inner net/minecraft/entity/monster/EntityEnderman$AIFindPlayer net/minecraft/entity/monster/EntityEnderman AIFindPlayer static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getEyeHeight ()F - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method protected teleportRandomly ()Z - -
 method protected teleportToEntity (Lnet/minecraft/entity/Entity;)Z - -
 method protected teleportTo (DDD)Z - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public setHeldBlockState (Lnet/minecraft/block/state/IBlockState;)V - -
 method public getHeldBlockState ()Lnet/minecraft/block/state/IBlockState; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public,static setCarriable (Lnet/minecraft/block/Block;Z)V - -
 method public,static getCarriable (Lnet/minecraft/block/Block;)Z - -
 method public isScreaming ()Z - -
 method public setScreaming (Z)V - -
in 91
class net/minecraft/entity/monster/EntityEnderman 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityEnderman$AITakeBlock net/minecraft/entity/monster/EntityEnderman AITakeBlock static
 inner net/minecraft/entity/monster/EntityEnderman$AIPlaceBlock net/minecraft/entity/monster/EntityEnderman AIPlaceBlock static
 inner net/minecraft/entity/monster/EntityEnderman$AIFindPlayer net/minecraft/entity/monster/EntityEnderman AIFindPlayer static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method public playEndermanSound ()V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public,static registerFixesEnderman (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getEyeHeight ()F - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method protected teleportRandomly ()Z - -
 method protected teleportToEntity (Lnet/minecraft/entity/Entity;)Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected dropEquipment (ZI)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public setHeldBlockState (Lnet/minecraft/block/state/IBlockState;)V - -
 method public getHeldBlockState ()Lnet/minecraft/block/state/IBlockState; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public,static setCarriable (Lnet/minecraft/block/Block;Z)V - -
 method public,static getCarriable (Lnet/minecraft/block/Block;)Z - -
 method public isScreaming ()Z - -
in 326
class net/minecraft/entity/monster/EntityEnderman 52 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityEnderman$AITakeBlock net/minecraft/entity/monster/EntityEnderman AITakeBlock static
 inner net/minecraft/entity/monster/EntityEnderman$AIPlaceBlock net/minecraft/entity/monster/EntityEnderman AIPlaceBlock static
 inner net/minecraft/entity/monster/EntityEnderman$AIFindPlayer net/minecraft/entity/monster/EntityEnderman AIFindPlayer static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method public playEndermanSound ()V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public,static registerFixesEnderman (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getEyeHeight ()F - -
 method public onLivingUpdate ()V - -
 method protected updateAITasks ()V - -
 method protected teleportRandomly ()Z - -
 method protected teleportToEntity (Lnet/minecraft/entity/Entity;)Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected dropEquipment (ZI)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public setHeldBlockState (Lnet/minecraft/block/state/IBlockState;)V - -
 method public getHeldBlockState ()Lnet/minecraft/block/state/IBlockState; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public,static setCarriable (Lnet/minecraft/block/Block;Z)V - -
 method public,static getCarriable (Lnet/minecraft/block/Block;)Z - -
 method public isScreaming ()Z - -
in 90
class net/minecraft/entity/monster/EntityEnderman$AIFindPlayer 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - -
 inner net/minecraft/entity/monster/EntityEnderman$AIFindPlayer net/minecraft/entity/monster/EntityEnderman AIFindPlayer static
 inner net/minecraft/entity/ai/EntityAINearestAttackableTarget$Sorter net/minecraft/entity/ai/EntityAINearestAttackableTarget Sorter public,static
 method public <init> (Lnet/minecraft/entity/monster/EntityEnderman;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public continueExecuting ()Z - -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/monster/EntityEnderman$AIFindPlayer 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityEnderman$AIFindPlayer net/minecraft/entity/monster/EntityEnderman AIFindPlayer static
 method public <init> (Lnet/minecraft/entity/monster/EntityEnderman;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public continueExecuting ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityEnderman$AIFindPlayer 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityEnderman$AIFindPlayer net/minecraft/entity/monster/EntityEnderman AIFindPlayer static
 method public <init> (Lnet/minecraft/entity/monster/EntityEnderman;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public shouldContinueExecuting ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/monster/EntityEnderman$AIPlaceBlock 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityEnderman$AIPlaceBlock net/minecraft/entity/monster/EntityEnderman AIPlaceBlock static
 method public <init> (Lnet/minecraft/entity/monster/EntityEnderman;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityEnderman$AIPlaceBlock 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityEnderman$AIPlaceBlock net/minecraft/entity/monster/EntityEnderman AIPlaceBlock static
 inner net/minecraftforge/event/world/BlockEvent$EntityPlaceEvent net/minecraftforge/event/world/BlockEvent EntityPlaceEvent public,static
 method public <init> (Lnet/minecraft/entity/monster/EntityEnderman;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/monster/EntityEnderman$AITakeBlock 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityEnderman$AITakeBlock net/minecraft/entity/monster/EntityEnderman AITakeBlock static
 method public <init> (Lnet/minecraft/entity/monster/EntityEnderman;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityEnderman$AITakeBlock 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityEnderman$AITakeBlock net/minecraft/entity/monster/EntityEnderman AITakeBlock static
 method public <init> (Lnet/minecraft/entity/monster/EntityEnderman;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/monster/EntityEndermite 50 public,super net/minecraft/entity/monster/EntityMob - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method protected canTriggerWalking ()Z - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method public isSpawnedByPlayer ()Z - -
 method public setSpawnedByPlayer (Z)V - -
 method public onLivingUpdate ()V - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 91
class net/minecraft/entity/monster/EntityEndermite 50 public,super net/minecraft/entity/monster/EntityMob - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method protected canTriggerWalking ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public,static registerFixesEndermite (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method public getYOffset ()D - -
 method public isSpawnedByPlayer ()Z - -
 method public setSpawnedByPlayer (Z)V - -
 method public onLivingUpdate ()V - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 326
class net/minecraft/entity/monster/EntityEndermite 52 public,super net/minecraft/entity/monster/EntityMob - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method protected canTriggerWalking ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public,static registerFixesEndermite (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method public setRenderYawOffset (F)V - -
 method public getYOffset ()D - -
 method public isSpawnedByPlayer ()Z - -
 method public setSpawnedByPlayer (Z)V - -
 method public onLivingUpdate ()V - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 326
class net/minecraft/entity/monster/EntityEvoker 52 public,super net/minecraft/entity/monster/EntitySpellcasterIllager - -
 inner net/minecraft/entity/monster/EntityEvoker$AIWololoSpell net/minecraft/entity/monster/EntityEvoker AIWololoSpell public
 inner net/minecraft/entity/monster/EntityEvoker$AISummonSpell net/minecraft/entity/monster/EntityEvoker AISummonSpell -
 inner net/minecraft/entity/monster/EntityEvoker$AICastingSpell net/minecraft/entity/monster/EntityEvoker AICastingSpell -
 inner net/minecraft/entity/monster/EntityEvoker$AIAttackSpell net/minecraft/entity/monster/EntityEvoker AIAttackSpell -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public,static registerFixesEvoker (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected updateAITasks ()V - -
 method public onUpdate ()V - -
 method public isOnSameTeam (Lnet/minecraft/entity/Entity;)Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getSpellSound ()Lnet/minecraft/util/SoundEvent; - -
in 326
class net/minecraft/entity/monster/EntityEvoker$AIAttackSpell 52 super net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell - -
 inner net/minecraft/entity/monster/EntityEvoker$AIAttackSpell net/minecraft/entity/monster/EntityEvoker AIAttackSpell -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell net/minecraft/entity/monster/EntitySpellcasterIllager AIUseSpell public,abstract
 method protected getCastingTime ()I - -
 method protected getCastingInterval ()I - -
 method protected castSpell ()V - -
 method protected getSpellPrepareSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSpellType ()Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
in 326
class net/minecraft/entity/monster/EntityEvoker$AICastingSpell 52 super net/minecraft/entity/monster/EntitySpellcasterIllager$AICastingApell - -
 inner net/minecraft/entity/monster/EntityEvoker$AICastingSpell net/minecraft/entity/monster/EntityEvoker AICastingSpell -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AICastingApell net/minecraft/entity/monster/EntitySpellcasterIllager AICastingApell public
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityEvoker$AISummonSpell 52 super net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell - -
 inner net/minecraft/entity/monster/EntityEvoker$AISummonSpell net/minecraft/entity/monster/EntityEvoker AISummonSpell -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell net/minecraft/entity/monster/EntitySpellcasterIllager AIUseSpell public,abstract
 method public shouldExecute ()Z - -
 method protected getCastingTime ()I - -
 method protected getCastingInterval ()I - -
 method protected castSpell ()V - -
 method protected getSpellPrepareSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSpellType ()Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
in 326
class net/minecraft/entity/monster/EntityEvoker$AIWololoSpell 52 public,super net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell - -
 inner net/minecraft/entity/monster/EntityEvoker$AIWololoSpell net/minecraft/entity/monster/EntityEvoker AIWololoSpell public
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell net/minecraft/entity/monster/EntitySpellcasterIllager AIUseSpell public,abstract
 method public <init> (Lnet/minecraft/entity/monster/EntityEvoker;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public resetTask ()V - -
 method protected castSpell ()V - -
 method protected getCastWarmupTime ()I - -
 method protected getCastingTime ()I - -
 method protected getCastingInterval ()I - -
 method protected getSpellPrepareSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSpellType ()Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
in 90
class net/minecraft/entity/monster/EntityGhast 50 public,super net/minecraft/entity/EntityFlying net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntityGhast$AIFireballAttack net/minecraft/entity/monster/EntityGhast AIFireballAttack static
 inner net/minecraft/entity/monster/EntityGhast$AILookAround net/minecraft/entity/monster/EntityGhast AILookAround static
 inner net/minecraft/entity/monster/EntityGhast$AIRandomFly net/minecraft/entity/monster/EntityGhast AIRandomFly static
 inner net/minecraft/entity/monster/EntityGhast$GhastMoveHelper net/minecraft/entity/monster/EntityGhast GhastMoveHelper static
 method public isAttacking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setAttacking (Z)V - -
 method public getFireballStrength ()I - -
 method public onUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method protected getSoundVolume ()F - -
 method public getCanSpawnHere ()Z - -
 method public getMaxSpawnedInChunk ()I - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/monster/EntityGhast 50 public,super net/minecraft/entity/EntityFlying net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntityGhast$AIFireballAttack net/minecraft/entity/monster/EntityGhast AIFireballAttack static
 inner net/minecraft/entity/monster/EntityGhast$AILookAround net/minecraft/entity/monster/EntityGhast AILookAround static
 inner net/minecraft/entity/monster/EntityGhast$AIRandomFly net/minecraft/entity/monster/EntityGhast AIRandomFly static
 inner net/minecraft/entity/monster/EntityGhast$GhastMoveHelper net/minecraft/entity/monster/EntityGhast GhastMoveHelper static
 method public isAttacking ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method public setAttacking (Z)V - -
 method public getFireballStrength ()I - -
 method public onUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getSoundVolume ()F - -
 method public getCanSpawnHere ()Z - -
 method public getMaxSpawnedInChunk ()I - -
 method public,static registerFixesGhast (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getEyeHeight ()F - -
in 326
class net/minecraft/entity/monster/EntityGhast 52 public,super net/minecraft/entity/EntityFlying net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntityGhast$AIFireballAttack net/minecraft/entity/monster/EntityGhast AIFireballAttack static
 inner net/minecraft/entity/monster/EntityGhast$AILookAround net/minecraft/entity/monster/EntityGhast AILookAround static
 inner net/minecraft/entity/monster/EntityGhast$AIRandomFly net/minecraft/entity/monster/EntityGhast AIRandomFly static
 inner net/minecraft/entity/monster/EntityGhast$GhastMoveHelper net/minecraft/entity/monster/EntityGhast GhastMoveHelper static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method public isAttacking ()Z - -
 method public setAttacking (Z)V - -
 method public getFireballStrength ()I - -
 method public onUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getSoundVolume ()F - -
 method public getCanSpawnHere ()Z - -
 method public getMaxSpawnedInChunk ()I - -
 method public,static registerFixesGhast (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getEyeHeight ()F - -
in 24
class net/minecraft/entity/monster/EntityGhast$AIFireballAttack 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGhast$AIFireballAttack net/minecraft/entity/monster/EntityGhast AIFireballAttack static
 field public attackTimer I -
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityGhast$AIFireballAttack 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGhast$AIFireballAttack net/minecraft/entity/monster/EntityGhast AIFireballAttack static
 field public attackTimer I -
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/monster/EntityGhast$AILookAround 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGhast$AILookAround net/minecraft/entity/monster/EntityGhast AILookAround static
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityGhast$AILookAround 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGhast$AILookAround net/minecraft/entity/monster/EntityGhast AILookAround static
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/monster/EntityGhast$AIRandomFly 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGhast$AIRandomFly net/minecraft/entity/monster/EntityGhast AIRandomFly static
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/monster/EntityGhast$AIRandomFly 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGhast$AIRandomFly net/minecraft/entity/monster/EntityGhast AIRandomFly static
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
in 90
class net/minecraft/entity/monster/EntityGhast$GhastMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntityGhast$GhastMoveHelper net/minecraft/entity/monster/EntityGhast GhastMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public onUpdateMoveHelper ()V - -
in 91
class net/minecraft/entity/monster/EntityGhast$GhastMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntityGhast$GhastMoveHelper net/minecraft/entity/monster/EntityGhast GhastMoveHelper static
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public onUpdateMoveHelper ()V - -
in 326
class net/minecraft/entity/monster/EntityGhast$GhastMoveHelper 52 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntityGhast$GhastMoveHelper net/minecraft/entity/monster/EntityGhast GhastMoveHelper static
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityGhast;)V - -
 method public onUpdateMoveHelper ()V - -
in 90
class net/minecraft/entity/monster/EntityGiantZombie 50 public,super net/minecraft/entity/monster/EntityMob - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method public getBlockPathWeight (Lnet/minecraft/util/BlockPos;)F - -
in 91
class net/minecraft/entity/monster/EntityGiantZombie 50 public,super net/minecraft/entity/monster/EntityMob - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesGiantZombie (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 326
class net/minecraft/entity/monster/EntityGiantZombie 52 public,super net/minecraft/entity/monster/EntityMob - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesGiantZombie (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 90
class net/minecraft/entity/monster/EntityGolem 50 public,super,abstract net/minecraft/entity/EntityCreature net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public fall (FF)V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
in 91
class net/minecraft/entity/monster/EntityGolem 50 public,super,abstract net/minecraft/entity/EntityCreature net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public fall (FF)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
in 326
class net/minecraft/entity/monster/EntityGolem 52 public,super,abstract net/minecraft/entity/EntityCreature net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public fall (FF)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
in 90
class net/minecraft/entity/monster/EntityGuardian 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper net/minecraft/entity/monster/EntityGuardian GuardianMoveHelper static
 inner net/minecraft/entity/monster/EntityGuardian$AIGuardianAttack net/minecraft/entity/monster/EntityGuardian AIGuardianAttack static
 inner net/minecraft/entity/monster/EntityGuardian$GuardianTargetSelector net/minecraft/entity/monster/EntityGuardian GuardianTargetSelector static
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 method public setElder ()V - -
 method public func_175471_a (F)F - -
 method public func_175469_o (F)F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getNewNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method protected entityInit ()V - -
 method public func_175472_n ()Z - -
 method public func_175464_ck ()I - -
 method public isElder ()Z - -
 method public setElder (Z)V - -
 method public hasTargetedEntity ()Z - -
 method public getTargetedEntity ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public onDataWatcherUpdate (I)V - -
 method public getTalkInterval ()I - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected canTriggerWalking ()Z - -
 method public getEyeHeight ()F - -
 method public getBlockPathWeight (Lnet/minecraft/util/BlockPos;)F - -
 method public onLivingUpdate ()V - -
 method public func_175477_p (F)F - -
 method protected updateAITasks ()V - -
 method protected dropFewItems (ZI)V - -
 method protected addRandomDrop ()V - -
 method protected isValidLightLevel ()Z - -
 method public isNotColliding ()Z - -
 method public getCanSpawnHere ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getVerticalFaceSpeed ()I - -
 method public moveEntityWithHeading (FF)V - -
in 91
class net/minecraft/entity/monster/EntityGuardian 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper net/minecraft/entity/monster/EntityGuardian GuardianMoveHelper static
 inner net/minecraft/entity/monster/EntityGuardian$AIGuardianAttack net/minecraft/entity/monster/EntityGuardian AIGuardianAttack static
 inner net/minecraft/entity/monster/EntityGuardian$GuardianTargetSelector net/minecraft/entity/monster/EntityGuardian GuardianTargetSelector static
 method public setElder ()V - -
 method public getTailAnimation (F)F - -
 method public getSpikesAnimation (F)F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public,static registerFixesGuardian (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected createNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method protected entityInit ()V - -
 method public isMoving ()Z - -
 method public getAttackDuration ()I - -
 method public isElder ()Z - -
 method public setElder (Z)V - -
 method public hasTargetedEntity ()Z - -
 method public getTargetedEntity ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getTalkInterval ()I - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected canTriggerWalking ()Z - -
 method public getEyeHeight ()F - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method public onLivingUpdate ()V - -
 method public getAttackAnimationScale (F)F - -
 method protected updateAITasks ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected isValidLightLevel ()Z - -
 method public isNotColliding ()Z - -
 method public getCanSpawnHere ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getVerticalFaceSpeed ()I - -
 method public moveEntityWithHeading (FF)V - -
in 326
class net/minecraft/entity/monster/EntityGuardian 52 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper net/minecraft/entity/monster/EntityGuardian GuardianMoveHelper static
 inner net/minecraft/entity/monster/EntityGuardian$AIGuardianAttack net/minecraft/entity/monster/EntityGuardian AIGuardianAttack static
 inner net/minecraft/entity/monster/EntityGuardian$GuardianTargetSelector net/minecraft/entity/monster/EntityGuardian GuardianTargetSelector static
 field protected clientSideTailAnimation F -
 field protected clientSideTailAnimationO F -
 field protected clientSideTailAnimationSpeed F -
 field protected clientSideSpikesAnimation F -
 field protected clientSideSpikesAnimationO F -
 field protected wander Lnet/minecraft/entity/ai/EntityAIWander; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public,static registerFixesGuardian (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected createNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method protected entityInit ()V - -
 method public isMoving ()Z - -
 method public getAttackDuration ()I - -
 method public hasTargetedEntity ()Z - -
 method public getTargetedEntity ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public getTalkInterval ()I - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected canTriggerWalking ()Z - -
 method public getEyeHeight ()F - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method public onLivingUpdate ()V - -
 method protected getFlopSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getTailAnimation (F)F - -
 method public getSpikesAnimation (F)F - -
 method public getAttackAnimationScale (F)F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected isValidLightLevel ()Z - -
 method public isNotColliding ()Z - -
 method public getCanSpawnHere ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getVerticalFaceSpeed ()I - -
 method public travel (FFF)V - -
in 24
class net/minecraft/entity/monster/EntityGuardian$AIGuardianAttack 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGuardian$AIGuardianAttack net/minecraft/entity/monster/EntityGuardian AIGuardianAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntityGuardian;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityGuardian$AIGuardianAttack 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityGuardian$AIGuardianAttack net/minecraft/entity/monster/EntityGuardian AIGuardianAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntityGuardian;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper net/minecraft/entity/monster/EntityGuardian GuardianMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntityGuardian;)V - -
 method public onUpdateMoveHelper ()V - -
in 91
class net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper net/minecraft/entity/monster/EntityGuardian GuardianMoveHelper static
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityGuardian;)V - -
 method public onUpdateMoveHelper ()V - -
in 326
class net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper 52 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntityGuardian$GuardianMoveHelper net/minecraft/entity/monster/EntityGuardian GuardianMoveHelper static
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityGuardian;)V - -
 method public onUpdateMoveHelper ()V - -
in 24
class net/minecraft/entity/monster/EntityGuardian$GuardianTargetSelector 50 super java/lang/Object com/google/common/base/Predicate Ljava/lang/Object;Lcom/google/common/base/Predicate<Lnet/minecraft/entity/EntityLivingBase;>;
 inner net/minecraft/entity/monster/EntityGuardian$GuardianTargetSelector net/minecraft/entity/monster/EntityGuardian GuardianTargetSelector static
 method public <init> (Lnet/minecraft/entity/monster/EntityGuardian;)V - -
 method public apply (Lnet/minecraft/entity/EntityLivingBase;)Z - -
in 326
class net/minecraft/entity/monster/EntityGuardian$GuardianTargetSelector 52 super java/lang/Object com/google/common/base/Predicate Ljava/lang/Object;Lcom/google/common/base/Predicate<Lnet/minecraft/entity/EntityLivingBase;>;
 inner net/minecraft/entity/monster/EntityGuardian$GuardianTargetSelector net/minecraft/entity/monster/EntityGuardian GuardianTargetSelector static
 method public <init> (Lnet/minecraft/entity/monster/EntityGuardian;)V - -
 method public apply (Lnet/minecraft/entity/EntityLivingBase;)Z - -
in 326
class net/minecraft/entity/monster/EntityHusk 52 public,super net/minecraft/entity/monster/EntityZombie - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesHusk (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getCanSpawnHere ()Z - -
 method protected shouldBurnInDay ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method protected getSkullDrop ()Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/entity/monster/EntityIllusionIllager 52 public,super net/minecraft/entity/monster/EntitySpellcasterIllager net/minecraft/entity/IRangedAttackMob -
 inner net/minecraft/entity/monster/EntityIllusionIllager$AIMirriorSpell net/minecraft/entity/monster/EntityIllusionIllager AIMirriorSpell -
 inner net/minecraft/entity/monster/EntityIllusionIllager$AIBlindnessSpell net/minecraft/entity/monster/EntityIllusionIllager AIBlindnessSpell -
 inner net/minecraft/entity/monster/AbstractIllager$IllagerArmPose net/minecraft/entity/monster/AbstractIllager IllagerArmPose public,static,final,enum
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AICastingApell net/minecraft/entity/monster/EntitySpellcasterIllager AICastingApell public
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected entityInit ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public onLivingUpdate ()V - -
 method public getRenderLocations (F)[Lnet/minecraft/util/math/Vec3d; - -
 method public isOnSameTeam (Lnet/minecraft/entity/Entity;)Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getSpellSound ()Lnet/minecraft/util/SoundEvent; - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method protected createArrowEntity (F)Lnet/minecraft/entity/projectile/EntityArrow; - -
 method public isAggressive ()Z - -
 method public setSwingingArms (Z)V - -
 method public getArmPose ()Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; - -
in 326
class net/minecraft/entity/monster/EntityIllusionIllager$AIBlindnessSpell 52 super net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell - -
 inner net/minecraft/entity/monster/EntityIllusionIllager$AIBlindnessSpell net/minecraft/entity/monster/EntityIllusionIllager AIBlindnessSpell -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell net/minecraft/entity/monster/EntitySpellcasterIllager AIUseSpell public,abstract
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method protected getCastingTime ()I - -
 method protected getCastingInterval ()I - -
 method protected castSpell ()V - -
 method protected getSpellPrepareSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSpellType ()Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
in 326
class net/minecraft/entity/monster/EntityIllusionIllager$AIMirriorSpell 52 super net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell - -
 inner net/minecraft/entity/monster/EntityIllusionIllager$AIMirriorSpell net/minecraft/entity/monster/EntityIllusionIllager AIMirriorSpell -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell net/minecraft/entity/monster/EntitySpellcasterIllager AIUseSpell public,abstract
 method public shouldExecute ()Z - -
 method protected getCastingTime ()I - -
 method protected getCastingInterval ()I - -
 method protected castSpell ()V - -
 method protected getSpellPrepareSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSpellType ()Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
in 90
class net/minecraft/entity/monster/EntityIronGolem 50 public,super net/minecraft/entity/monster/EntityGolem - -
 inner net/minecraft/entity/monster/EntityIronGolem$AINearestAttackableTargetNonCreeper net/minecraft/entity/monster/EntityIronGolem AINearestAttackableTargetNonCreeper static
 inner net/minecraft/block/BlockFlower$EnumFlowerType net/minecraft/block/BlockFlower EnumFlowerType public,static,final,enum
 method public handleStatusUpdate (B)V - -
 method public getAttackTimer ()I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected updateAITasks ()V - -
 method protected applyEntityAttributes ()V - -
 method protected decreaseAirSupply (I)I - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method public onLivingUpdate ()V - -
 method public canAttackClass (Ljava/lang/Class;)Z (Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)Z -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getVillage ()Lnet/minecraft/village/Village; - -
 method public setHoldingRose (Z)V - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected dropFewItems (ZI)V - -
 method public getHoldRoseTick ()I - -
 method public isPlayerCreated ()Z - -
 method public setPlayerCreated (Z)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
in 91
class net/minecraft/entity/monster/EntityIronGolem 50 public,super net/minecraft/entity/monster/EntityGolem - -
 field protected,static,final PLAYER_CREATED Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 method public handleStatusUpdate (B)V - -
 method public getAttackTimer ()I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method protected updateAITasks ()V - -
 method protected applyEntityAttributes ()V - -
 method protected decreaseAirSupply (I)I - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method public onLivingUpdate ()V - -
 method public canAttackClass (Ljava/lang/Class;)Z (Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)Z -
 method public,static registerFixesIronGolem (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getVillage ()Lnet/minecraft/village/Village; - -
 method public setHoldingRose (Z)V - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getHoldRoseTick ()I - -
 method public isPlayerCreated ()Z - -
 method public setPlayerCreated (Z)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
in 326
class net/minecraft/entity/monster/EntityIronGolem 52 public,super net/minecraft/entity/monster/EntityGolem - -
 field protected,static,final PLAYER_CREATED Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method protected updateAITasks ()V - -
 method protected applyEntityAttributes ()V - -
 method protected decreaseAirSupply (I)I - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method public onLivingUpdate ()V - -
 method public canAttackClass (Ljava/lang/Class;)Z (Ljava/lang/Class<+Lnet/minecraft/entity/EntityLivingBase;>;)Z -
 method public,static registerFixesIronGolem (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public handleStatusUpdate (B)V - -
 method public getVillage ()Lnet/minecraft/village/Village; - -
 method public getAttackTimer ()I - -
 method public setHoldingRose (Z)V - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getHoldRoseTick ()I - -
 method public isPlayerCreated ()Z - -
 method public setPlayerCreated (Z)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
in 90
class net/minecraft/entity/monster/EntityIronGolem$AINearestAttackableTargetNonCreeper 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<TT;>;
 inner net/minecraft/entity/monster/EntityIronGolem$AINearestAttackableTargetNonCreeper net/minecraft/entity/monster/EntityIronGolem AINearestAttackableTargetNonCreeper static
 method public <init> (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class;IZZLcom/google/common/base/Predicate;)V (Lnet/minecraft/entity/EntityCreature;Ljava/lang/Class<TT;>;IZZLcom/google/common/base/Predicate<-TT;>;)V -
in 90
class net/minecraft/entity/monster/EntityMagmaCube 50 public,super net/minecraft/entity/monster/EntitySlime - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getTotalArmorValue ()I - -
 method public getBrightnessForRender (F)I - -
 method public getBrightness (F)F - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected createInstance ()Lnet/minecraft/entity/monster/EntitySlime; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public isBurning ()Z - -
 method protected getJumpDelay ()I - -
 method protected alterSquishAmount ()V - -
 method protected jump ()V - -
 method protected handleJumpLava ()V - -
 method public fall (FF)V - -
 method protected canDamagePlayer ()Z - -
 method protected getAttackStrength ()I - -
 method protected getJumpSound ()Ljava/lang/String; - -
 method protected makesSoundOnLand ()Z - -
in 91
class net/minecraft/entity/monster/EntityMagmaCube 50 public,super net/minecraft/entity/monster/EntitySlime - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesMagmaCube (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected applyEntityAttributes ()V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method protected setSlimeSize (I)V - -
 method public getBrightnessForRender (F)I - -
 method public getBrightness (F)F - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected createInstance ()Lnet/minecraft/entity/monster/EntitySlime; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isBurning ()Z - -
 method protected getJumpDelay ()I - -
 method protected alterSquishAmount ()V - -
 method protected jump ()V - -
 method protected handleJumpLava ()V - -
 method public fall (FF)V - -
 method protected canDamagePlayer ()Z - -
 method protected getAttackStrength ()I - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSquishSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getJumpSound ()Lnet/minecraft/util/SoundEvent; - -
in 326
class net/minecraft/entity/monster/EntityMagmaCube 52 public,super net/minecraft/entity/monster/EntitySlime - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesMagmaCube (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected applyEntityAttributes ()V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method protected setSlimeSize (IZ)V - -
 method public getBrightnessForRender ()I - -
 method public getBrightness ()F - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected createInstance ()Lnet/minecraft/entity/monster/EntitySlime; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isBurning ()Z - -
 method protected getJumpDelay ()I - -
 method protected alterSquishAmount ()V - -
 method protected jump ()V - -
 method protected handleJumpLava ()V - -
 method public fall (FF)V - -
 method protected canDamagePlayer ()Z - -
 method protected getAttackStrength ()I - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSquishSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getJumpSound ()Lnet/minecraft/util/SoundEvent; - -
in 90
class net/minecraft/entity/monster/EntityMob 50 public,super,abstract net/minecraft/entity/EntityCreature net/minecraft/entity/monster/IMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method protected getSwimSound ()Ljava/lang/String; - -
 method protected getSplashSound ()Ljava/lang/String; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getFallSoundString (I)Ljava/lang/String; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getBlockPathWeight (Lnet/minecraft/util/BlockPos;)F - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method protected applyEntityAttributes ()V - -
 method protected canDropLoot ()Z - -
in 91
class net/minecraft/entity/monster/EntityMob 50 public,super,abstract net/minecraft/entity/EntityCreature net/minecraft/entity/monster/IMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesMonster (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method protected getSwimSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSplashSound ()Lnet/minecraft/util/SoundEvent; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method protected applyEntityAttributes ()V - -
 method protected canDropLoot ()Z - -
in 326
class net/minecraft/entity/monster/EntityMob 52 public,super,abstract net/minecraft/entity/EntityCreature net/minecraft/entity/monster/IMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method protected getSwimSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSplashSound ()Lnet/minecraft/util/SoundEvent; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method protected applyEntityAttributes ()V - -
 method protected canDropLoot ()Z - -
 method public isPreventingPlayerRest (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 90
class net/minecraft/entity/monster/EntityPigZombie 50 public,super net/minecraft/entity/monster/EntityZombie - -
 inner net/minecraft/entity/monster/EntityPigZombie$AITargetAggressor net/minecraft/entity/monster/EntityPigZombie AITargetAggressor static
 inner net/minecraft/entity/monster/EntityPigZombie$AIHurtByAggressor net/minecraft/entity/monster/EntityPigZombie AIHurtByAggressor static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected applyEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public onUpdate ()V - -
 method protected updateAITasks ()V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public isAngry ()Z - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected dropFewItems (ZI)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected addRandomDrop ()V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 91
class net/minecraft/entity/monster/EntityPigZombie 50 public,super net/minecraft/entity/monster/EntityZombie - -
 inner net/minecraft/entity/monster/EntityPigZombie$AITargetAggressor net/minecraft/entity/monster/EntityPigZombie AITargetAggressor static
 inner net/minecraft/entity/monster/EntityPigZombie$AIHurtByAggressor net/minecraft/entity/monster/EntityPigZombie AIHurtByAggressor static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected applyEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public onUpdate ()V - -
 method protected updateAITasks ()V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public,static registerFixesPigZombie (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public isAngry ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 326
class net/minecraft/entity/monster/EntityPigZombie 52 public,super net/minecraft/entity/monster/EntityZombie - -
 inner net/minecraft/entity/monster/EntityPigZombie$AITargetAggressor net/minecraft/entity/monster/EntityPigZombie AITargetAggressor static
 inner net/minecraft/entity/monster/EntityPigZombie$AIHurtByAggressor net/minecraft/entity/monster/EntityPigZombie AIHurtByAggressor static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected applyEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected updateAITasks ()V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public,static registerFixesPigZombie (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public isAngry ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method protected getSkullDrop ()Lnet/minecraft/item/ItemStack; - -
 method public isPreventingPlayerRest (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 24
class net/minecraft/entity/monster/EntityPigZombie$AIHurtByAggressor 50 super net/minecraft/entity/ai/EntityAIHurtByTarget - -
 inner net/minecraft/entity/monster/EntityPigZombie$AIHurtByAggressor net/minecraft/entity/monster/EntityPigZombie AIHurtByAggressor static
 method public <init> (Lnet/minecraft/entity/monster/EntityPigZombie;)V - -
 method protected setEntityAttackTarget (Lnet/minecraft/entity/EntityCreature;Lnet/minecraft/entity/EntityLivingBase;)V - -
in 326
class net/minecraft/entity/monster/EntityPigZombie$AIHurtByAggressor 52 super net/minecraft/entity/ai/EntityAIHurtByTarget - -
 inner net/minecraft/entity/monster/EntityPigZombie$AIHurtByAggressor net/minecraft/entity/monster/EntityPigZombie AIHurtByAggressor static
 method public <init> (Lnet/minecraft/entity/monster/EntityPigZombie;)V - -
 method protected setEntityAttackTarget (Lnet/minecraft/entity/EntityCreature;Lnet/minecraft/entity/EntityLivingBase;)V - -
in 24
class net/minecraft/entity/monster/EntityPigZombie$AITargetAggressor 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityPigZombie$AITargetAggressor net/minecraft/entity/monster/EntityPigZombie AITargetAggressor static
 method public <init> (Lnet/minecraft/entity/monster/EntityPigZombie;)V - -
 method public shouldExecute ()Z - -
in 326
class net/minecraft/entity/monster/EntityPigZombie$AITargetAggressor 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityPigZombie$AITargetAggressor net/minecraft/entity/monster/EntityPigZombie AITargetAggressor static
 method public <init> (Lnet/minecraft/entity/monster/EntityPigZombie;)V - -
 method public shouldExecute ()Z - -
in 91
class net/minecraft/entity/monster/EntityPolarBear 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIPanic net/minecraft/entity/monster/EntityPolarBear AIPanic -
 inner net/minecraft/entity/monster/EntityPolarBear$AIMeleeAttack net/minecraft/entity/monster/EntityPolarBear AIMeleeAttack -
 inner net/minecraft/entity/monster/EntityPolarBear$AIAttackPlayer net/minecraft/entity/monster/EntityPolarBear AIAttackPlayer -
 inner net/minecraft/entity/monster/EntityPolarBear$AIHurtByTarget net/minecraft/entity/monster/EntityPolarBear AIHurtByTarget -
 inner net/minecraft/entity/monster/EntityPolarBear$GroupData net/minecraft/entity/monster/EntityPolarBear GroupData static
 method public getStandingAnimationScale (F)F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected playWarningSound ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected entityInit ()V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public isStanding ()Z - -
 method public setStanding (Z)V - -
 method protected getWaterSlowDown ()F - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 326
class net/minecraft/entity/monster/EntityPolarBear 52 public,super net/minecraft/entity/passive/EntityAnimal - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIPanic net/minecraft/entity/monster/EntityPolarBear AIPanic -
 inner net/minecraft/entity/monster/EntityPolarBear$AIMeleeAttack net/minecraft/entity/monster/EntityPolarBear AIMeleeAttack -
 inner net/minecraft/entity/monster/EntityPolarBear$AIAttackPlayer net/minecraft/entity/monster/EntityPolarBear AIAttackPlayer -
 inner net/minecraft/entity/monster/EntityPolarBear$AIHurtByTarget net/minecraft/entity/monster/EntityPolarBear AIHurtByTarget -
 inner net/minecraft/entity/monster/EntityPolarBear$GroupData net/minecraft/entity/monster/EntityPolarBear GroupData static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected playWarningSound ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public isStanding ()Z - -
 method public setStanding (Z)V - -
 method public getStandingAnimationScale (F)F - -
 method protected getWaterSlowDown ()F - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 91
class net/minecraft/entity/monster/EntityPolarBear$AIAttackPlayer 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityPolarBear$AIAttackPlayer net/minecraft/entity/monster/EntityPolarBear AIAttackPlayer -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method public shouldExecute ()Z - -
 method protected getTargetDistance ()D - -
in 326
class net/minecraft/entity/monster/EntityPolarBear$AIAttackPlayer 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityPolarBear$AIAttackPlayer net/minecraft/entity/monster/EntityPolarBear AIAttackPlayer -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method public shouldExecute ()Z - -
 method protected getTargetDistance ()D - -
in 91
class net/minecraft/entity/monster/EntityPolarBear$AIHurtByTarget 50 super net/minecraft/entity/ai/EntityAIHurtByTarget - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIHurtByTarget net/minecraft/entity/monster/EntityPolarBear AIHurtByTarget -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method public startExecuting ()V - -
 method protected setEntityAttackTarget (Lnet/minecraft/entity/EntityCreature;Lnet/minecraft/entity/EntityLivingBase;)V - -
in 326
class net/minecraft/entity/monster/EntityPolarBear$AIHurtByTarget 52 super net/minecraft/entity/ai/EntityAIHurtByTarget - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIHurtByTarget net/minecraft/entity/monster/EntityPolarBear AIHurtByTarget -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method public startExecuting ()V - -
 method protected setEntityAttackTarget (Lnet/minecraft/entity/EntityCreature;Lnet/minecraft/entity/EntityLivingBase;)V - -
in 91
class net/minecraft/entity/monster/EntityPolarBear$AIMeleeAttack 50 super net/minecraft/entity/ai/EntityAIAttackMelee - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIMeleeAttack net/minecraft/entity/monster/EntityPolarBear AIMeleeAttack -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method protected checkAndPerformAttack (Lnet/minecraft/entity/EntityLivingBase;D)V - -
 method public resetTask ()V - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 326
class net/minecraft/entity/monster/EntityPolarBear$AIMeleeAttack 52 super net/minecraft/entity/ai/EntityAIAttackMelee - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIMeleeAttack net/minecraft/entity/monster/EntityPolarBear AIMeleeAttack -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method protected checkAndPerformAttack (Lnet/minecraft/entity/EntityLivingBase;D)V - -
 method public resetTask ()V - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 91
class net/minecraft/entity/monster/EntityPolarBear$AIPanic 50 super net/minecraft/entity/ai/EntityAIPanic - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIPanic net/minecraft/entity/monster/EntityPolarBear AIPanic -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method public shouldExecute ()Z - -
in 326
class net/minecraft/entity/monster/EntityPolarBear$AIPanic 52 super net/minecraft/entity/ai/EntityAIPanic - -
 inner net/minecraft/entity/monster/EntityPolarBear$AIPanic net/minecraft/entity/monster/EntityPolarBear AIPanic -
 method public <init> (Lnet/minecraft/entity/monster/EntityPolarBear;)V - -
 method public shouldExecute ()Z - -
in 91
class net/minecraft/entity/monster/EntityPolarBear$GroupData 50 super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/monster/EntityPolarBear$GroupData net/minecraft/entity/monster/EntityPolarBear GroupData static
 field public madeParent Z -
in 326
class net/minecraft/entity/monster/EntityPolarBear$GroupData 52 super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/monster/EntityPolarBear$GroupData net/minecraft/entity/monster/EntityPolarBear GroupData static
 field public madeParent Z -
in 91
class net/minecraft/entity/monster/EntityShulker 50 public,super net/minecraft/entity/monster/EntityGolem net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntityShulker$BodyHelper net/minecraft/entity/monster/EntityShulker BodyHelper -
 inner net/minecraft/entity/monster/EntityShulker$AIPeek net/minecraft/entity/monster/EntityShulker AIPeek -
 inner net/minecraft/entity/monster/EntityShulker$AIDefenseAttack net/minecraft/entity/monster/EntityShulker AIDefenseAttack static
 inner net/minecraft/entity/monster/EntityShulker$AIAttackNearest net/minecraft/entity/monster/EntityShulker AIAttackNearest -
 inner net/minecraft/entity/monster/EntityShulker$AIAttack net/minecraft/entity/monster/EntityShulker AIAttack -
 field protected,static,final ATTACHED_FACE Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/EnumFacing;>;
 field protected,static,final ATTACHED_BLOCK_POS Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lcom/google/common/base/Optional<Lnet/minecraft/util/math/BlockPos;>;>;
 field protected,static,final PEEK_TICK Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected initEntityAI ()V - -
 method protected canTriggerWalking ()Z - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method public playLivingSound ()V - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method protected createBodyHelper ()Lnet/minecraft/entity/EntityBodyHelper; - -
 method public,static registerFixesShulker (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method public setPosition (DDD)V - -
 method protected tryTeleportToNewPosition ()Z - -
 method public onLivingUpdate ()V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getAttachmentFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public getAttachmentPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public setAttachmentPos (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getPeekTick ()I - -
 method public updateArmorModifier (I)V - -
 method public getClientPeekAmount (F)F - -
 method public getClientTeleportInterp ()I - -
 method public getOldAttachPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getEyeHeight ()F - -
 method public getVerticalFaceSpeed ()I - -
 method public getHorizontalFaceSpeed ()I - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public getCollisionBorderSize ()F - -
 method public isAttachedToBlock ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 326
class net/minecraft/entity/monster/EntityShulker 52 public,super net/minecraft/entity/monster/EntityGolem net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntityShulker$BodyHelper net/minecraft/entity/monster/EntityShulker BodyHelper -
 inner net/minecraft/entity/monster/EntityShulker$AIPeek net/minecraft/entity/monster/EntityShulker AIPeek -
 inner net/minecraft/entity/monster/EntityShulker$AIDefenseAttack net/minecraft/entity/monster/EntityShulker AIDefenseAttack static
 inner net/minecraft/entity/monster/EntityShulker$AIAttackNearest net/minecraft/entity/monster/EntityShulker AIAttackNearest -
 inner net/minecraft/entity/monster/EntityShulker$AIAttack net/minecraft/entity/monster/EntityShulker AIAttack -
 field protected,static,final ATTACHED_FACE Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/util/EnumFacing;>;
 field protected,static,final ATTACHED_BLOCK_POS Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lcom/google/common/base/Optional<Lnet/minecraft/util/math/BlockPos;>;>;
 field protected,static,final PEEK_TICK Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field protected,static,final COLOR Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public,static,final DEFAULT_COLOR Lnet/minecraft/item/EnumDyeColor; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected initEntityAI ()V - -
 method protected canTriggerWalking ()Z - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method public playLivingSound ()V - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method protected createBodyHelper ()Lnet/minecraft/entity/EntityBodyHelper; - -
 method public,static registerFixesShulker (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method public move (Lnet/minecraft/entity/MoverType;DDD)V - -
 method public setPosition (DDD)V - -
 method protected tryTeleportToNewPosition ()Z - -
 method public onLivingUpdate ()V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getCollisionBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getAttachmentFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public getAttachmentPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public setAttachmentPos (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getPeekTick ()I - -
 method public updateArmorModifier (I)V - -
 method public getClientPeekAmount (F)F - -
 method public getClientTeleportInterp ()I - -
 method public getOldAttachPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getEyeHeight ()F - -
 method public getVerticalFaceSpeed ()I - -
 method public getHorizontalFaceSpeed ()I - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public getCollisionBorderSize ()F - -
 method public isAttachedToBlock ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getColor ()Lnet/minecraft/item/EnumDyeColor; - -
in 91
class net/minecraft/entity/monster/EntityShulker$AIAttack 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityShulker$AIAttack net/minecraft/entity/monster/EntityShulker AIAttack -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityShulker$AIAttack 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityShulker$AIAttack net/minecraft/entity/monster/EntityShulker AIAttack -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/monster/EntityShulker$AIAttackNearest 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityShulker$AIAttackNearest net/minecraft/entity/monster/EntityShulker AIAttackNearest -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;Lnet/minecraft/entity/monster/EntityShulker;)V - -
 method public shouldExecute ()Z - -
 method protected getTargetableArea (D)Lnet/minecraft/util/math/AxisAlignedBB; - -
in 326
class net/minecraft/entity/monster/EntityShulker$AIAttackNearest 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/player/EntityPlayer;>;
 inner net/minecraft/entity/monster/EntityShulker$AIAttackNearest net/minecraft/entity/monster/EntityShulker AIAttackNearest -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;Lnet/minecraft/entity/monster/EntityShulker;)V - -
 method public shouldExecute ()Z - -
 method protected getTargetableArea (D)Lnet/minecraft/util/math/AxisAlignedBB; - -
in 91
class net/minecraft/entity/monster/EntityShulker$AIDefenseAttack 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/EntityLivingBase;>;
 inner net/minecraft/entity/monster/EntityShulker$AIDefenseAttack net/minecraft/entity/monster/EntityShulker AIDefenseAttack static
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;)V - -
 method public shouldExecute ()Z - -
 method protected getTargetableArea (D)Lnet/minecraft/util/math/AxisAlignedBB; - -
in 326
class net/minecraft/entity/monster/EntityShulker$AIDefenseAttack 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/EntityLivingBase;>;
 inner net/minecraft/entity/monster/EntityShulker$AIDefenseAttack net/minecraft/entity/monster/EntityShulker AIDefenseAttack static
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;)V - -
 method public shouldExecute ()Z - -
 method protected getTargetableArea (D)Lnet/minecraft/util/math/AxisAlignedBB; - -
in 91
class net/minecraft/entity/monster/EntityShulker$AIPeek 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityShulker$AIPeek net/minecraft/entity/monster/EntityShulker AIPeek -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityShulker$AIPeek 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityShulker$AIPeek net/minecraft/entity/monster/EntityShulker AIPeek -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/monster/EntityShulker$BodyHelper 50 super net/minecraft/entity/EntityBodyHelper - -
 inner net/minecraft/entity/monster/EntityShulker$BodyHelper net/minecraft/entity/monster/EntityShulker BodyHelper -
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public updateRenderAngles ()V - -
in 326
class net/minecraft/entity/monster/EntityShulker$BodyHelper 52 super net/minecraft/entity/EntityBodyHelper - -
 inner net/minecraft/entity/monster/EntityShulker$BodyHelper net/minecraft/entity/monster/EntityShulker BodyHelper -
 method public <init> (Lnet/minecraft/entity/monster/EntityShulker;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public updateRenderAngles ()V - -
in 90
class net/minecraft/entity/monster/EntitySilverfish 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntitySilverfish$AIHideInStone net/minecraft/entity/monster/EntitySilverfish AIHideInStone static
 inner net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish net/minecraft/entity/monster/EntitySilverfish AISummonSilverfish static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getYOffset ()D - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method protected canTriggerWalking ()Z - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public onUpdate ()V - -
 method public getBlockPathWeight (Lnet/minecraft/util/BlockPos;)F - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 91
class net/minecraft/entity/monster/EntitySilverfish 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntitySilverfish$AIHideInStone net/minecraft/entity/monster/EntitySilverfish AIHideInStone static
 inner net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish net/minecraft/entity/monster/EntitySilverfish AISummonSilverfish static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSilverfish (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method public getYOffset ()D - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method protected canTriggerWalking ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public onUpdate ()V - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 326
class net/minecraft/entity/monster/EntitySilverfish 52 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish net/minecraft/entity/monster/EntitySilverfish AISummonSilverfish static
 inner net/minecraft/entity/monster/EntitySilverfish$AIHideInStone net/minecraft/entity/monster/EntitySilverfish AIHideInStone static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSilverfish (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method public getYOffset ()D - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method protected canTriggerWalking ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public onUpdate ()V - -
 method public setRenderYawOffset (F)V - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method protected isValidLightLevel ()Z - -
 method public getCanSpawnHere ()Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
in 24
class net/minecraft/entity/monster/EntitySilverfish$AIHideInStone 50 super net/minecraft/entity/ai/EntityAIWander - -
 inner net/minecraft/entity/monster/EntitySilverfish$AIHideInStone net/minecraft/entity/monster/EntitySilverfish AIHideInStone static
 inner net/minecraft/block/BlockSilverfish$EnumType net/minecraft/block/BlockSilverfish EnumType public,static,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySilverfish;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/monster/EntitySilverfish$AIHideInStone 52 super net/minecraft/entity/ai/EntityAIWander - -
 inner net/minecraft/entity/monster/EntitySilverfish$AIHideInStone net/minecraft/entity/monster/EntitySilverfish AIHideInStone static
 inner net/minecraft/block/BlockSilverfish$EnumType net/minecraft/block/BlockSilverfish EnumType public,static,abstract,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySilverfish;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
in 90
class net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish net/minecraft/entity/monster/EntitySilverfish AISummonSilverfish static
 inner net/minecraft/block/BlockSilverfish$EnumType net/minecraft/block/BlockSilverfish EnumType public,static,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySilverfish;)V - -
 method public func_179462_f ()V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish net/minecraft/entity/monster/EntitySilverfish AISummonSilverfish static
 inner net/minecraft/block/BlockSilverfish$EnumType net/minecraft/block/BlockSilverfish EnumType public,static,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySilverfish;)V - -
 method public notifyHurt ()V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySilverfish$AISummonSilverfish net/minecraft/entity/monster/EntitySilverfish AISummonSilverfish static
 inner net/minecraft/block/BlockSilverfish$EnumType net/minecraft/block/BlockSilverfish EnumType public,static,abstract,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySilverfish;)V - -
 method public notifyHurt ()V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/monster/EntitySkeleton 50 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public onLivingUpdate ()V - -
 method public updateRidden ()V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method protected addRandomDrop ()V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public setCombatTask ()V - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getSkeletonType ()I - -
 method public setSkeletonType (I)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setCurrentItemOrArmor (ILnet/minecraft/item/ItemStack;)V - -
 method public getEyeHeight ()F - -
 method public getYOffset ()D - -
in 91
class net/minecraft/entity/monster/EntitySkeleton 50 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 method public isSwingingArms ()Z - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public onLivingUpdate ()V - -
 method public updateRidden ()V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public setCombatTask ()V - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getSkeletonType ()Lnet/minecraft/entity/monster/SkeletonType; - -
 method public setSkeletonType (Lnet/minecraft/entity/monster/SkeletonType;)V - -
 method public,static registerFixesSkeleton (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public getEyeHeight ()F - -
 method public getYOffset ()D - -
 method public setSwingingArms (Z)V - -
in 326
class net/minecraft/entity/monster/EntitySkeleton 52 public,super net/minecraft/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSkeleton (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected getArrow (F)Lnet/minecraft/entity/projectile/EntityArrow; - -
in 90
class net/minecraft/entity/monster/EntitySlime 50 public,super net/minecraft/entity/EntityLiving net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeHop net/minecraft/entity/monster/EntitySlime AISlimeHop static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFloat net/minecraft/entity/monster/EntitySlime AISlimeFloat static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFaceRandom net/minecraft/entity/monster/EntitySlime AISlimeFaceRandom static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeAttack net/minecraft/entity/monster/EntitySlime AISlimeAttack static
 field public squishAmount F -
 field public squishFactor F -
 field public prevSquishFactor F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected setSlimeSize (I)V - -
 method public getSlimeSize ()I - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected getJumpSound ()Ljava/lang/String; - -
 method public onUpdate ()V - -
 method protected alterSquishAmount ()V - -
 method protected getJumpDelay ()I - -
 method protected createInstance ()Lnet/minecraft/entity/monster/EntitySlime; - -
 method public onDataWatcherUpdate (I)V - -
 method public setDead ()V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected func_175451_e (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEyeHeight ()F - -
 method protected canDamagePlayer ()Z - -
 method protected getAttackStrength ()I - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public getCanSpawnHere ()Z - -
 method protected getSoundVolume ()F - -
 method public getVerticalFaceSpeed ()I - -
 method protected makesSoundOnJump ()Z - -
 method protected makesSoundOnLand ()Z - -
 method protected jump ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected spawnCustomParticles ()Z - -
in 91
class net/minecraft/entity/monster/EntitySlime 50 public,super net/minecraft/entity/EntityLiving net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeHop net/minecraft/entity/monster/EntitySlime AISlimeHop static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFloat net/minecraft/entity/monster/EntitySlime AISlimeFloat static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFaceRandom net/minecraft/entity/monster/EntitySlime AISlimeFaceRandom static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeAttack net/minecraft/entity/monster/EntitySlime AISlimeAttack static
 field public squishAmount F -
 field public squishFactor F -
 field public prevSquishFactor F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method protected setSlimeSize (I)V - -
 method public getSlimeSize ()I - -
 method public,static registerFixesSlime (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public isSmallSlime ()Z - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method public onUpdate ()V - -
 method protected alterSquishAmount ()V - -
 method protected getJumpDelay ()I - -
 method protected createInstance ()Lnet/minecraft/entity/monster/EntitySlime; - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public setDead ()V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected dealDamage (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEyeHeight ()F - -
 method protected canDamagePlayer ()Z - -
 method protected getAttackStrength ()I - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSquishSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getCanSpawnHere ()Z - -
 method protected getSoundVolume ()F - -
 method public getVerticalFaceSpeed ()I - -
 method protected makesSoundOnJump ()Z - -
 method protected jump ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected getJumpSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected spawnCustomParticles ()Z - -
in 326
class net/minecraft/entity/monster/EntitySlime 52 public,super net/minecraft/entity/EntityLiving net/minecraft/entity/monster/IMob -
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeHop net/minecraft/entity/monster/EntitySlime AISlimeHop static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFloat net/minecraft/entity/monster/EntitySlime AISlimeFloat static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFaceRandom net/minecraft/entity/monster/EntitySlime AISlimeFaceRandom static
 inner net/minecraft/entity/monster/EntitySlime$AISlimeAttack net/minecraft/entity/monster/EntitySlime AISlimeAttack static
 field public squishAmount F -
 field public squishFactor F -
 field public prevSquishFactor F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method protected setSlimeSize (IZ)V - -
 method public getSlimeSize ()I - -
 method public,static registerFixesSlime (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public isSmallSlime ()Z - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method public onUpdate ()V - -
 method protected alterSquishAmount ()V - -
 method protected getJumpDelay ()I - -
 method protected createInstance ()Lnet/minecraft/entity/monster/EntitySlime; - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public setDead ()V - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected dealDamage (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEyeHeight ()F - -
 method protected canDamagePlayer ()Z - -
 method protected getAttackStrength ()I - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSquishSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getCanSpawnHere ()Z - -
 method protected getSoundVolume ()F - -
 method public getVerticalFaceSpeed ()I - -
 method protected makesSoundOnJump ()Z - -
 method protected jump ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected getJumpSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected spawnCustomParticles ()Z - -
in 24
class net/minecraft/entity/monster/EntitySlime$AISlimeAttack 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeAttack net/minecraft/entity/monster/EntitySlime AISlimeAttack static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public continueExecuting ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntitySlime$AISlimeAttack 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeAttack net/minecraft/entity/monster/EntitySlime AISlimeAttack static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public shouldContinueExecuting ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/monster/EntitySlime$AISlimeFaceRandom 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFaceRandom net/minecraft/entity/monster/EntitySlime AISlimeFaceRandom static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntitySlime$AISlimeFaceRandom 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFaceRandom net/minecraft/entity/monster/EntitySlime AISlimeFaceRandom static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/monster/EntitySlime$AISlimeFloat 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFloat net/minecraft/entity/monster/EntitySlime AISlimeFloat static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntitySlime$AISlimeFloat 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeFloat net/minecraft/entity/monster/EntitySlime AISlimeFloat static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 24
class net/minecraft/entity/monster/EntitySlime$AISlimeHop 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeHop net/minecraft/entity/monster/EntitySlime AISlimeHop static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntitySlime$AISlimeHop 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySlime$AISlimeHop net/minecraft/entity/monster/EntitySlime AISlimeHop static
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public func_179920_a (FZ)V - -
 method public setSpeed (D)V - -
 method public onUpdateMoveHelper ()V - -
in 91
class net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public setDirection (FZ)V - -
 method public setSpeed (D)V - -
 method public onUpdateMoveHelper ()V - -
in 326
class net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper 52 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntitySlime$SlimeMoveHelper net/minecraft/entity/monster/EntitySlime SlimeMoveHelper static
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySlime;)V - -
 method public setDirection (FZ)V - -
 method public setSpeed (D)V - -
 method public onUpdateMoveHelper ()V - -
in 90
class net/minecraft/entity/monster/EntitySnowman 50 public,super net/minecraft/entity/monster/EntityGolem net/minecraft/entity/IRangedAttackMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public onLivingUpdate ()V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/monster/EntitySnowman 50 public,super net/minecraft/entity/monster/EntityGolem net/minecraft/entity/IRangedAttackMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSnowman (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public onLivingUpdate ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getEyeHeight ()F - -
 method protected processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method public isPumpkinEquipped ()Z - -
 method public setPumpkinEquipped (Z)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
in 326
class net/minecraft/entity/monster/EntitySnowman 52 public,super net/minecraft/entity/monster/EntityGolem net/minecraft/entity/IRangedAttackMob,net/minecraftforge/common/IShearable -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSnowman (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onLivingUpdate ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getEyeHeight ()F - -
 method protected processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public isPumpkinEquipped ()Z - -
 method public setPumpkinEquipped (Z)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public isShearable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public setSwingingArms (Z)V - -
in 326
class net/minecraft/entity/monster/EntitySpellcasterIllager 52 public,super,abstract net/minecraft/entity/monster/AbstractIllager - -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell net/minecraft/entity/monster/EntitySpellcasterIllager AIUseSpell public,abstract
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AICastingApell net/minecraft/entity/monster/EntitySpellcasterIllager AICastingApell public
 inner net/minecraft/entity/monster/AbstractIllager$IllagerArmPose net/minecraft/entity/monster/AbstractIllager IllagerArmPose public,static,final,enum
 field protected spellTicks I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getArmPose ()Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; - -
 method public isSpellcasting ()Z - -
 method public setSpellType (Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType;)V - -
 method protected getSpellType ()Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
 method protected updateAITasks ()V - -
 method public onUpdate ()V - -
 method protected getSpellTicks ()I - -
 method protected,abstract getSpellSound ()Lnet/minecraft/util/SoundEvent; - -
in 326
class net/minecraft/entity/monster/EntitySpellcasterIllager$AICastingApell 52 public,super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AICastingApell net/minecraft/entity/monster/EntitySpellcasterIllager AICastingApell public
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntitySpellcasterIllager;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell 52 public,super,abstract net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$AIUseSpell net/minecraft/entity/monster/EntitySpellcasterIllager AIUseSpell public,abstract
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 field protected spellWarmup I -
 field protected spellCooldown I -
 method protected <init> (Lnet/minecraft/entity/monster/EntitySpellcasterIllager;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
 method protected,abstract castSpell ()V - -
 method protected getCastWarmupTime ()I - -
 method protected,abstract getCastingTime ()I - -
 method protected,abstract getCastingInterval ()I - -
 method protected,abstract getSpellPrepareSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected,abstract getSpellType ()Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
in 326
class net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType;>;
 inner net/minecraft/entity/monster/EntitySpellcasterIllager$SpellType net/minecraft/entity/monster/EntitySpellcasterIllager SpellType public,static,final,enum
 field public,static,final,enum NONE Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; -
 field public,static,final,enum SUMMON_VEX Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; -
 field public,static,final,enum FANGS Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; -
 field public,static,final,enum WOLOLO Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; -
 field public,static,final,enum DISAPPEAR Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; -
 field public,static,final,enum BLINDNESS Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; -
 method public,static values ()[Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
 method public,static getFromId (I)Lnet/minecraft/entity/monster/EntitySpellcasterIllager$SpellType; - -
in 90
class net/minecraft/entity/monster/EntitySpider 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntitySpider$AISpiderTarget net/minecraft/entity/monster/EntitySpider AISpiderTarget static
 inner net/minecraft/entity/monster/EntitySpider$AISpiderAttack net/minecraft/entity/monster/EntitySpider AISpiderAttack static
 inner net/minecraft/entity/monster/EntitySpider$GroupData net/minecraft/entity/monster/EntitySpider GroupData public,static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getMountedYOffset ()D - -
 method protected getNewNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public isOnLadder ()Z - -
 method public setInWeb ()V - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public isPotionApplicable (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public isBesideClimbableBlock ()Z - -
 method public setBesideClimbableBlock (Z)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/monster/EntitySpider 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntitySpider$AISpiderTarget net/minecraft/entity/monster/EntitySpider AISpiderTarget static
 inner net/minecraft/entity/monster/EntitySpider$AISpiderAttack net/minecraft/entity/monster/EntitySpider AISpiderAttack static
 inner net/minecraft/entity/monster/EntitySpider$GroupData net/minecraft/entity/monster/EntitySpider GroupData public,static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSpider (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method public getMountedYOffset ()D - -
 method protected createNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isOnLadder ()Z - -
 method public setInWeb ()V - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public isPotionApplicable (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public isBesideClimbableBlock ()Z - -
 method public setBesideClimbableBlock (Z)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
in 326
class net/minecraft/entity/monster/EntitySpider 52 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntitySpider$GroupData net/minecraft/entity/monster/EntitySpider GroupData public,static
 inner net/minecraft/entity/monster/EntitySpider$AISpiderTarget net/minecraft/entity/monster/EntitySpider AISpiderTarget static
 inner net/minecraft/entity/monster/EntitySpider$AISpiderAttack net/minecraft/entity/monster/EntitySpider AISpiderAttack static
 inner net/minecraftforge/event/entity/living/PotionEvent$PotionApplicableEvent net/minecraftforge/event/entity/living/PotionEvent PotionApplicableEvent public,static
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSpider (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method public getMountedYOffset ()D - -
 method protected createNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isOnLadder ()Z - -
 method public setInWeb ()V - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public isPotionApplicable (Lnet/minecraft/potion/PotionEffect;)Z - -
 method public isBesideClimbableBlock ()Z - -
 method public setBesideClimbableBlock (Z)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
in 90
class net/minecraft/entity/monster/EntitySpider$AISpiderAttack 50 super net/minecraft/entity/ai/EntityAIAttackOnCollide - -
 inner net/minecraft/entity/monster/EntitySpider$AISpiderAttack net/minecraft/entity/monster/EntitySpider AISpiderAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class;)V (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;)V -
 method public continueExecuting ()Z - -
 method protected func_179512_a (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 91
class net/minecraft/entity/monster/EntitySpider$AISpiderAttack 50 super net/minecraft/entity/ai/EntityAIAttackMelee - -
 inner net/minecraft/entity/monster/EntitySpider$AISpiderAttack net/minecraft/entity/monster/EntitySpider AISpiderAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntitySpider;)V - -
 method public continueExecuting ()Z - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 326
class net/minecraft/entity/monster/EntitySpider$AISpiderAttack 52 super net/minecraft/entity/ai/EntityAIAttackMelee - -
 inner net/minecraft/entity/monster/EntitySpider$AISpiderAttack net/minecraft/entity/monster/EntitySpider AISpiderAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntitySpider;)V - -
 method public shouldContinueExecuting ()Z - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 90
class net/minecraft/entity/monster/EntitySpider$AISpiderTarget 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget;
 inner net/minecraft/entity/monster/EntitySpider$AISpiderTarget net/minecraft/entity/monster/EntitySpider AISpiderTarget static
 method public <init> (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class;)V (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class<TT;>;)V -
 method public shouldExecute ()Z - -
in 91
class net/minecraft/entity/monster/EntitySpider$AISpiderTarget 50 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<TT;>;
 inner net/minecraft/entity/monster/EntitySpider$AISpiderTarget net/minecraft/entity/monster/EntitySpider AISpiderTarget static
 method public <init> (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class;)V (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class<TT;>;)V -
 method public shouldExecute ()Z - -
in 326
class net/minecraft/entity/monster/EntitySpider$AISpiderTarget 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - <T:Lnet/minecraft/entity/EntityLivingBase;>Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<TT;>;
 inner net/minecraft/entity/monster/EntitySpider$AISpiderTarget net/minecraft/entity/monster/EntitySpider AISpiderTarget static
 method public <init> (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class;)V (Lnet/minecraft/entity/monster/EntitySpider;Ljava/lang/Class<TT;>;)V -
 method public shouldExecute ()Z - -
in 90
class net/minecraft/entity/monster/EntitySpider$GroupData 50 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/monster/EntitySpider$GroupData net/minecraft/entity/monster/EntitySpider GroupData public,static
 field public potionEffectId I -
 method public <init> ()V - -
 method public func_111104_a (Ljava/util/Random;)V - -
in 91
class net/minecraft/entity/monster/EntitySpider$GroupData 50 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/monster/EntitySpider$GroupData net/minecraft/entity/monster/EntitySpider GroupData public,static
 field public effect Lnet/minecraft/potion/Potion; -
 method public <init> ()V - -
 method public setRandomEffect (Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/monster/EntitySpider$GroupData 52 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/monster/EntitySpider$GroupData net/minecraft/entity/monster/EntitySpider GroupData public,static
 field public effect Lnet/minecraft/potion/Potion; -
 method public <init> ()V - -
 method public setRandomEffect (Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/monster/EntityStray 52 public,super net/minecraft/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesStray (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getCanSpawnHere ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getArrow (F)Lnet/minecraft/entity/projectile/EntityArrow; - -
in 326
class net/minecraft/entity/monster/EntityVex 52 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityVex$AICopyOwnerTarget net/minecraft/entity/monster/EntityVex AICopyOwnerTarget -
 inner net/minecraft/entity/monster/EntityVex$AIMoveRandom net/minecraft/entity/monster/EntityVex AIMoveRandom -
 inner net/minecraft/entity/monster/EntityVex$AIChargeAttack net/minecraft/entity/monster/EntityVex AIChargeAttack -
 inner net/minecraft/entity/monster/EntityVex$AIMoveControl net/minecraft/entity/monster/EntityVex AIMoveControl -
 field protected,static,final VEX_FLAGS Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public move (Lnet/minecraft/entity/MoverType;DDD)V - -
 method public onUpdate ()V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public,static registerFixesVex (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getOwner ()Lnet/minecraft/entity/EntityLiving; - -
 method public getBoundOrigin ()Lnet/minecraft/util/math/BlockPos; - -
 method public setBoundOrigin (Lnet/minecraft/util/math/BlockPos;)V - -
 method public isCharging ()Z - -
 method public setCharging (Z)V - -
 method public setOwner (Lnet/minecraft/entity/EntityLiving;)V - -
 method public setLimitedLife (I)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getBrightnessForRender ()I - -
 method public getBrightness ()F - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
in 326
class net/minecraft/entity/monster/EntityVex$AIChargeAttack 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityVex$AIChargeAttack net/minecraft/entity/monster/EntityVex AIChargeAttack -
 method public <init> (Lnet/minecraft/entity/monster/EntityVex;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityVex$AICopyOwnerTarget 52 super net/minecraft/entity/ai/EntityAITarget - -
 inner net/minecraft/entity/monster/EntityVex$AICopyOwnerTarget net/minecraft/entity/monster/EntityVex AICopyOwnerTarget -
 method public <init> (Lnet/minecraft/entity/monster/EntityVex;Lnet/minecraft/entity/EntityCreature;)V - -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
in 326
class net/minecraft/entity/monster/EntityVex$AIMoveControl 52 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/monster/EntityVex$AIMoveControl net/minecraft/entity/monster/EntityVex AIMoveControl -
 inner net/minecraft/entity/ai/EntityMoveHelper$Action net/minecraft/entity/ai/EntityMoveHelper Action public,static,final,enum
 method public <init> (Lnet/minecraft/entity/monster/EntityVex;Lnet/minecraft/entity/monster/EntityVex;)V - -
 method public onUpdateMoveHelper ()V - -
in 326
class net/minecraft/entity/monster/EntityVex$AIMoveRandom 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/monster/EntityVex$AIMoveRandom net/minecraft/entity/monster/EntityVex AIMoveRandom -
 method public <init> (Lnet/minecraft/entity/monster/EntityVex;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/monster/EntityVindicator 52 public,super net/minecraft/entity/monster/AbstractIllager - -
 inner net/minecraft/entity/monster/EntityVindicator$AIJohnnyAttack net/minecraft/entity/monster/EntityVindicator AIJohnnyAttack static
 inner net/minecraft/entity/monster/AbstractIllager$IllagerArmPose net/minecraft/entity/monster/AbstractIllager IllagerArmPose public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesVindicator (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isAggressive ()Z - -
 method public setAggressive (Z)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getArmPose ()Lnet/minecraft/entity/monster/AbstractIllager$IllagerArmPose; - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method protected updateAITasks ()V - -
 method public isOnSameTeam (Lnet/minecraft/entity/Entity;)Z - -
 method public setCustomNameTag (Ljava/lang/String;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
in 326
class net/minecraft/entity/monster/EntityVindicator$AIJohnnyAttack 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/EntityLivingBase;>;
 inner net/minecraft/entity/monster/EntityVindicator$AIJohnnyAttack net/minecraft/entity/monster/EntityVindicator AIJohnnyAttack static
 method public <init> (Lnet/minecraft/entity/monster/EntityVindicator;)V - -
 method public shouldExecute ()Z - -
in 90
class net/minecraft/entity/monster/EntityWitch 50 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public setAggressive (Z)V - -
 method public getAggressive ()Z - -
 method protected applyEntityAttributes ()V - -
 method public onLivingUpdate ()V - -
 method protected applyPotionDamageCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected dropFewItems (ZI)V - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/monster/EntityWitch 50 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesWitch (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public setAggressive (Z)V - -
 method public isDrinkingPotion ()Z - -
 method protected applyEntityAttributes ()V - -
 method public onLivingUpdate ()V - -
 method protected applyPotionDamageCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getEyeHeight ()F - -
in 326
class net/minecraft/entity/monster/EntityWitch 52 public,super net/minecraft/entity/monster/EntityMob net/minecraft/entity/IRangedAttackMob -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesWitch (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public setDrinkingPotion (Z)V - -
 method public isDrinkingPotion ()Z - -
 method protected applyEntityAttributes ()V - -
 method public onLivingUpdate ()V - -
 method public handleStatusUpdate (B)V - -
 method protected applyPotionDamageCalculations (Lnet/minecraft/util/DamageSource;F)F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public getEyeHeight ()F - -
 method public setSwingingArms (Z)V - -
in 326
class net/minecraft/entity/monster/EntityWitherSkeleton 52 public,super net/minecraft/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesWitherSkeleton (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/util/SoundEvent; - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method protected setEnchantmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method protected getArrow (F)Lnet/minecraft/entity/projectile/EntityArrow; - -
in 90
class net/minecraft/entity/monster/EntityZombie 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityZombie$GroupData net/minecraft/entity/monster/EntityZombie GroupData -
 inner net/minecraftforge/event/entity/living/ZombieEvent$SummonAidEvent net/minecraftforge/event/entity/living/ZombieEvent SummonAidEvent public,static
 inner net/minecraft/util/BlockPos$MutableBlockPos net/minecraft/util/BlockPos MutableBlockPos public,static,final
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 field protected,static,final reinforcementChance Lnet/minecraft/entity/ai/attributes/IAttribute; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public getTotalArmorValue ()I - -
 method public isBreakDoorsTaskSet ()Z - -
 method public setBreakDoorsAItask (Z)V - -
 method public isChild ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public setChild (Z)V - -
 method public isVillager ()Z - -
 method public setVillager (Z)V - -
 method public onLivingUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public onUpdate ()V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method protected addRandomDrop ()V - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEyeHeight ()F - -
 method protected func_175448_a (Lnet/minecraft/item/ItemStack;)Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected startConversion (I)V - -
 method public handleStatusUpdate (B)V - -
 method protected canDespawn ()Z - -
 method public isConverting ()Z - -
 method protected convertToVillager ()V - -
 method protected getConversionTimeBoost ()I - -
 method public setChildSize (Z)V - -
 method protected,final setSize (FF)V - -
 method protected,final multiplySize (F)V - -
 method public getYOffset ()D - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
in 91
class net/minecraft/entity/monster/EntityZombie 50 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityZombie$GroupData net/minecraft/entity/monster/EntityZombie GroupData -
 inner net/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession net/minecraftforge/fml/common/registry/VillagerRegistry VillagerProfession public,static
 inner net/minecraftforge/event/entity/living/ZombieEvent$SummonAidEvent net/minecraftforge/event/entity/living/ZombieEvent SummonAidEvent public,static
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 field protected,static,final SPAWN_REINFORCEMENTS_CHANCE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public setArmsRaised (Z)V - -
 method public isArmsRaised ()Z - -
 method public isBreakDoorsTaskSet ()Z - -
 method public setBreakDoorsAItask (Z)V - -
 method public isChild ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public setChild (Z)V - -
 method public,deprecated getZombieType ()Lnet/minecraft/entity/monster/ZombieType; - -
 method public isVillager ()Z - -
 method public getVillagerTypeForge ()Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession; - -
 method public,deprecated setZombieType (Lnet/minecraft/entity/monster/ZombieType;)V - -
 method public setVillagerType (Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession;)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public onLivingUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public onUpdate ()V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public,static registerFixesZombie (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEyeHeight ()F - -
 method protected canEquipItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected startConversion (I)V - -
 method public handleStatusUpdate (B)V - -
 method protected canDespawn ()Z - -
 method public isConverting ()Z - -
 method protected convertToVillager ()V - -
 method protected getConversionTimeBoost ()I - -
 method public setChildSize (Z)V - -
 method protected,final setSize (FF)V - -
 method protected,final multiplySize (F)V - -
 method public getYOffset ()D - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public getName ()Ljava/lang/String; - -
in 326
class net/minecraft/entity/monster/EntityZombie 52 public,super net/minecraft/entity/monster/EntityMob - -
 inner net/minecraft/entity/monster/EntityZombie$GroupData net/minecraft/entity/monster/EntityZombie GroupData -
 inner net/minecraftforge/event/entity/living/ZombieEvent$SummonAidEvent net/minecraftforge/event/entity/living/ZombieEvent SummonAidEvent public,static
 inner net/minecraftforge/fml/common/eventhandler/Event$Result net/minecraftforge/fml/common/eventhandler/Event Result public,static,final,enum
 field protected,static,final SPAWN_REINFORCEMENTS_CHANCE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public setArmsRaised (Z)V - -
 method public isArmsRaised ()Z - -
 method public isBreakDoorsTaskSet ()Z - -
 method public setBreakDoorsAItask (Z)V - -
 method public isChild ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public setChild (Z)V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public onLivingUpdate ()V - -
 method protected shouldBurnInDay ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected setEquipmentBasedOnDifficulty (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public,static registerFixesZombie (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getEyeHeight ()F - -
 method protected canEquipItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public setChildSize (Z)V - -
 method protected,final setSize (FF)V - -
 method protected,final multiplySize (F)V - -
 method public getYOffset ()D - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected getSkullDrop ()Lnet/minecraft/item/ItemStack; - -
in 24
class net/minecraft/entity/monster/EntityZombie$GroupData 50 super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/monster/EntityZombie$GroupData net/minecraft/entity/monster/EntityZombie GroupData -
 field public isChild Z -
 field public isVillager Z -
in 326
class net/minecraft/entity/monster/EntityZombie$GroupData 52 super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/monster/EntityZombie$GroupData net/minecraft/entity/monster/EntityZombie GroupData -
 field public isChild Z -
in 326
class net/minecraft/entity/monster/EntityZombieVillager 52 public,super net/minecraft/entity/monster/EntityZombie - -
 inner net/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession net/minecraftforge/fml/common/registry/VillagerRegistry VillagerProfession public,static
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public setProfession (I)V - -
 method public,deprecated getProfession ()I - -
 method public,static registerFixesZombieVillager (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public onUpdate ()V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected canDespawn ()Z - -
 method public isConverting ()Z - -
 method protected startConverting (Ljava/util/UUID;I)V - -
 method public handleStatusUpdate (B)V - -
 method protected finishConversion ()V - -
 method protected getConversionProgress ()I - -
 method protected getSoundPitch ()F - -
 method public getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method public getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getStepSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getSkullDrop ()Lnet/minecraft/item/ItemStack; - -
 method public setForgeProfession (Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession;)V - -
 method public getForgeProfession ()Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession; - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
in 90
class net/minecraft/entity/monster/IMob 50 public,interface,abstract java/lang/Object net/minecraft/entity/passive/IAnimals -
 field public,static,final mobSelector Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<Lnet/minecraft/entity/Entity;>;
 field public,static,final VISIBLE_MOB_SELECTOR Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<Lnet/minecraft/entity/Entity;>;
in 91
class net/minecraft/entity/monster/IMob 50 public,interface,abstract java/lang/Object net/minecraft/entity/passive/IAnimals -
 field public,static,final MOB_SELECTOR Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<Lnet/minecraft/entity/Entity;>;
 field public,static,final VISIBLE_MOB_SELECTOR Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<Lnet/minecraft/entity/Entity;>;
in 326
class net/minecraft/entity/monster/IMob 52 public,interface,abstract java/lang/Object net/minecraft/entity/passive/IAnimals -
 field public,static,final MOB_SELECTOR Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<Lnet/minecraft/entity/Entity;>;
 field public,static,final VISIBLE_MOB_SELECTOR Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<Lnet/minecraft/entity/Entity;>;
in 91
class net/minecraft/entity/monster/SkeletonType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/monster/SkeletonType;>;
 field public,static,final,enum NORMAL Lnet/minecraft/entity/monster/SkeletonType; -
 field public,static,final,enum WITHER Lnet/minecraft/entity/monster/SkeletonType; -
 field public,static,final,enum STRAY Lnet/minecraft/entity/monster/SkeletonType; -
 method public,static values ()[Lnet/minecraft/entity/monster/SkeletonType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/monster/SkeletonType; - -
 method public getId ()I - -
 method public,static getByOrdinal (I)Lnet/minecraft/entity/monster/SkeletonType; - -
 method public getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getStepSound ()Lnet/minecraft/util/SoundEvent; - -
in 91
class net/minecraft/entity/monster/ZombieType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/monster/ZombieType;>;
 field public,static,final,enum NORMAL Lnet/minecraft/entity/monster/ZombieType; -
 field public,static,final,enum VILLAGER_FARMER Lnet/minecraft/entity/monster/ZombieType; -
 field public,static,final,enum VILLAGER_LIBRARIAN Lnet/minecraft/entity/monster/ZombieType; -
 field public,static,final,enum VILLAGER_PRIEST Lnet/minecraft/entity/monster/ZombieType; -
 field public,static,final,enum VILLAGER_SMITH Lnet/minecraft/entity/monster/ZombieType; -
 field public,static,final,enum VILLAGER_BUTCHER Lnet/minecraft/entity/monster/ZombieType; -
 field public,static,final,enum HUSK Lnet/minecraft/entity/monster/ZombieType; -
 method public,static values ()[Lnet/minecraft/entity/monster/ZombieType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/monster/ZombieType; - -
 method public getId ()I - -
 method public isVillager ()Z - -
 method public getVillagerId ()I - -
 method public,static getByOrdinal (I)Lnet/minecraft/entity/monster/ZombieType; - -
 method public,static getVillagerByOrdinal (I)Lnet/minecraft/entity/monster/ZombieType; - -
 method public getName ()Lnet/minecraft/util/text/TextComponentTranslation; - -
 method public isSunSensitive ()Z - -
 method public getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getStepSound ()Lnet/minecraft/util/SoundEvent; - -
in 326
class net/minecraft/entity/passive/AbstractChestHorse 52 public,super,abstract net/minecraft/entity/passive/AbstractHorse - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected applyEntityAttributes ()V - -
 method public hasChest ()Z - -
 method public setChested (Z)V - -
 method protected getInventorySize ()I - -
 method public getMountedYOffset ()D - -
 method protected getAngrySound ()Lnet/minecraft/util/SoundEvent; - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public,static registerFixesAbstractChestHorse (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class;)V (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class<*>;)V -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected playChestEquipSound ()V - -
 method public getInventoryColumns ()I - -
in 326
class net/minecraft/entity/passive/AbstractHorse 52 public,super,abstract net/minecraft/entity/passive/EntityAnimal net/minecraft/inventory/IInventoryChangedListener,net/minecraft/entity/IJumpingMount -
 field protected,static,final JUMP_STRENGTH Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field public tailCounter I -
 field public sprintCounter I -
 field protected horseJumping Z -
 field protected horseChest Lnet/minecraft/inventory/ContainerHorseChest; -
 field protected temper I -
 field protected jumpPower F -
 field protected canGallop Z -
 field protected gallopTime I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method protected getHorseWatchableBoolean (I)Z - -
 method protected setHorseWatchableBoolean (IZ)V - -
 method public isTame ()Z - -
 method public getOwnerUniqueId ()Ljava/util/UUID; - -
 method public setOwnerUniqueId (Ljava/util/UUID;)V - -
 method public getHorseSize ()F - -
 method public setScaleForAge (Z)V - -
 method public isHorseJumping ()Z - -
 method public setHorseTamed (Z)V - -
 method public setHorseJumping (Z)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected onLeashDistance (F)V - -
 method public isEatingHaystack ()Z - -
 method public isRearing ()Z - -
 method public isBreeding ()Z - -
 method public setBreeding (Z)V - -
 method public setHorseSaddled (Z)V - -
 method public getTemper ()I - -
 method public setTemper (I)V - -
 method public increaseTemper (I)I - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canBePushed ()Z - -
 method public fall (FF)V - -
 method protected getInventorySize ()I - -
 method protected initHorseChest ()V - -
 method protected updateHorseSlots ()V - -
 method public onInventoryChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method protected getClosestHorse (Lnet/minecraft/entity/Entity;D)Lnet/minecraft/entity/passive/AbstractHorse; - -
 method public getHorseJumpStrength ()D - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method public canBeSaddled ()Z - -
 method public isHorseSaddled ()Z - -
 method protected getAngrySound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected playGallopSound (Lnet/minecraft/block/SoundType;)V - -
 method protected applyEntityAttributes ()V - -
 method public getMaxSpawnedInChunk ()I - -
 method public getMaxTemper ()I - -
 method protected getSoundVolume ()F - -
 method public getTalkInterval ()I - -
 method public openGUI (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected handleEating (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method protected mountTo (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected isMovementBlocked ()Z - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public onLivingUpdate ()V - -
 method protected followMother ()V - -
 method public canEatGrass ()Z - -
 method public onUpdate ()V - -
 method public setEatingHaystack (Z)V - -
 method public setRearing (Z)V - -
 method public makeMad ()V - -
 method public setTamedBy (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public travel (FFF)V - -
 method public,static registerFixesAbstractHorse (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class;)V (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/Class<*>;)V -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method protected canMate ()Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method protected setOffspringAttributes (Lnet/minecraft/entity/EntityAgeable;Lnet/minecraft/entity/passive/AbstractHorse;)V - -
 method public canBeSteered ()Z - -
 method public getGrassEatingAmount (F)F - -
 method public getRearingAmount (F)F - -
 method public getMouthOpennessAngle (F)F - -
 method public setJumpPower (I)V - -
 method public canJump ()Z - -
 method public handleStartJump (I)V - -
 method public handleStopJump ()V - -
 method protected spawnHorseParticles (Z)V - -
 method public handleStatusUpdate (B)V - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method protected getModifiedMaxHealth ()F - -
 method protected getModifiedJumpStrength ()D - -
 method protected getModifiedMovementSpeed ()D - -
 method public isOnLadder ()Z - -
 method public getEyeHeight ()F - -
 method public wearsArmor ()Z - -
 method public isArmor (Lnet/minecraft/item/ItemStack;)Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 90
class net/minecraft/entity/passive/EntityAmbientCreature 50 public,super,abstract net/minecraft/entity/EntityLiving net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public allowLeashing ()Z - -
 method protected interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 91
class net/minecraft/entity/passive/EntityAmbientCreature 50 public,super,abstract net/minecraft/entity/EntityLiving net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 326
class net/minecraft/entity/passive/EntityAmbientCreature 52 public,super,abstract net/minecraft/entity/EntityLiving net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 90
class net/minecraft/entity/passive/EntityAnimal 50 public,super,abstract net/minecraft/entity/EntityAgeable net/minecraft/entity/passive/IAnimals -
 field protected spawnableBlock Lnet/minecraft/block/Block; -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected updateAITasks ()V - -
 method public onLivingUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getBlockPathWeight (Lnet/minecraft/util/BlockPos;)F - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getCanSpawnHere ()Z - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected consumeItemFromStack (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public setInLove (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getPlayerInLove ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public isInLove ()Z - -
 method public resetInLove ()V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
in 91
class net/minecraft/entity/passive/EntityAnimal 50 public,super,abstract net/minecraft/entity/EntityAgeable net/minecraft/entity/passive/IAnimals -
 field protected spawnableBlock Lnet/minecraft/block/Block; -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected updateAITasks ()V - -
 method public onLivingUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getYOffset ()D - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getCanSpawnHere ()Z - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected consumeItemFromStack (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public setInLove (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getPlayerInLove ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public isInLove ()Z - -
 method public resetInLove ()V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
in 326
class net/minecraft/entity/passive/EntityAnimal 52 public,super,abstract net/minecraft/entity/EntityAgeable net/minecraft/entity/passive/IAnimals -
 field protected spawnableBlock Lnet/minecraft/block/Block; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected updateAITasks ()V - -
 method public onLivingUpdate ()V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getBlockPathWeight (Lnet/minecraft/util/math/BlockPos;)F - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getYOffset ()D - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getCanSpawnHere ()Z - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected consumeItemFromStack (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public setInLove (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getLoveCause ()Lnet/minecraft/entity/player/EntityPlayerMP; - -
 method public isInLove ()Z - -
 method public resetInLove ()V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public handleStatusUpdate (B)V - -
in 90
class net/minecraft/entity/passive/EntityBat 50 public,super net/minecraft/entity/passive/EntityAmbientCreature - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected getSoundVolume ()F - -
 method protected getSoundPitch ()F - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public canBePushed ()Z - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected collideWithNearbyEntities ()V - -
 method protected applyEntityAttributes ()V - -
 method public getIsBatHanging ()Z - -
 method public setIsBatHanging (Z)V - -
 method public onUpdate ()V - -
 method protected updateAITasks ()V - -
 method protected canTriggerWalking ()Z - -
 method public fall (FF)V - -
 method protected updateFallState (DZLnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;)V - -
 method public doesEntityNotTriggerPressurePlate ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getCanSpawnHere ()Z - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/passive/EntityBat 50 public,super net/minecraft/entity/passive/EntityAmbientCreature - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected getSoundVolume ()F - -
 method protected getSoundPitch ()F - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public canBePushed ()Z - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected collideWithNearbyEntities ()V - -
 method protected applyEntityAttributes ()V - -
 method public getIsBatHanging ()Z - -
 method public setIsBatHanging (Z)V - -
 method public onUpdate ()V - -
 method protected updateAITasks ()V - -
 method protected canTriggerWalking ()Z - -
 method public fall (FF)V - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public doesEntityNotTriggerPressurePlate ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public,static registerFixesBat (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getCanSpawnHere ()Z - -
 method public getEyeHeight ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 326
class net/minecraft/entity/passive/EntityBat 52 public,super net/minecraft/entity/passive/EntityAmbientCreature - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method protected getSoundVolume ()F - -
 method protected getSoundPitch ()F - -
 method public getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public canBePushed ()Z - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected collideWithNearbyEntities ()V - -
 method protected applyEntityAttributes ()V - -
 method public getIsBatHanging ()Z - -
 method public setIsBatHanging (Z)V - -
 method public onUpdate ()V - -
 method protected updateAITasks ()V - -
 method protected canTriggerWalking ()Z - -
 method public fall (FF)V - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public doesEntityNotTriggerPressurePlate ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public,static registerFixesBat (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getCanSpawnHere ()Z - -
 method public getEyeHeight ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 90
class net/minecraft/entity/passive/EntityChicken 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 field public wingRotation F -
 field public destPos F -
 field public field_70884_g F -
 field public field_70888_h F -
 field public wingRotDelta F -
 field public timeUntilNextEgg I -
 field public chickenJockey Z -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method public onLivingUpdate ()V - -
 method public fall (FF)V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityChicken; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected canDespawn ()Z - -
 method public updateRiderPosition ()V - -
 method public isChickenJockey ()Z - -
 method public setChickenJockey (Z)V - -
in 91
class net/minecraft/entity/passive/EntityChicken 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 field public wingRotation F -
 field public destPos F -
 field public oFlapSpeed F -
 field public oFlap F -
 field public wingRotDelta F -
 field public timeUntilNextEgg I -
 field public chickenJockey Z -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method public onLivingUpdate ()V - -
 method public fall (FF)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityChicken; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public,static registerFixesChicken (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected canDespawn ()Z - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method public isChickenJockey ()Z - -
 method public setChickenJockey (Z)V - -
in 326
class net/minecraft/entity/passive/EntityChicken 52 public,super net/minecraft/entity/passive/EntityAnimal - -
 field public wingRotation F -
 field public destPos F -
 field public oFlapSpeed F -
 field public oFlap F -
 field public wingRotDelta F -
 field public timeUntilNextEgg I -
 field public chickenJockey Z -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method public getEyeHeight ()F - -
 method protected applyEntityAttributes ()V - -
 method public onLivingUpdate ()V - -
 method public fall (FF)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityChicken; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public,static registerFixesChicken (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected canDespawn ()Z - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method public isChickenJockey ()Z - -
 method public setChickenJockey (Z)V - -
in 90
class net/minecraft/entity/passive/EntityCow 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getSoundVolume ()F - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityCow; - -
 method public getEyeHeight ()F - -
in 91
class net/minecraft/entity/passive/EntityCow 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesCow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getSoundVolume ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityCow; - -
 method public getEyeHeight ()F - -
in 326
class net/minecraft/entity/passive/EntityCow 52 public,super net/minecraft/entity/passive/EntityAnimal - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesCow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected getSoundVolume ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityCow; - -
 method public getEyeHeight ()F - -
in 326
class net/minecraft/entity/passive/EntityDonkey 52 public,super net/minecraft/entity/passive/AbstractChestHorse - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesDonkey (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
in 326
class net/minecraft/entity/passive/EntityFlying 52 public,interface,abstract java/lang/Object - -
in 90
class net/minecraft/entity/passive/EntityHorse 50 public,super net/minecraft/entity/passive/EntityAnimal net/minecraft/inventory/IInvBasic -
 inner net/minecraft/entity/passive/EntityHorse$GroupData net/minecraft/entity/passive/EntityHorse GroupData public,static
 inner net/minecraft/block/Block$SoundType net/minecraft/block/Block SoundType public,static
 field public field_110278_bp I -
 field public field_110279_bq I -
 field protected horseJumping Z -
 field protected temper I -
 field protected jumpPower F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public setHorseType (I)V - -
 method public getHorseType ()I - -
 method public setHorseVariant (I)V - -
 method public getHorseVariant ()I - -
 method public getName ()Ljava/lang/String; - -
 method public isAdultHorse ()Z - -
 method public isTame ()Z - -
 method public func_110253_bW ()Z - -
 method public getOwnerId ()Ljava/lang/String; - -
 method public setOwnerId (Ljava/lang/String;)V - -
 method public getHorseSize ()F - -
 method public setScaleForAge (Z)V - -
 method public isHorseJumping ()Z - -
 method public setHorseTamed (Z)V - -
 method public setHorseJumping (Z)V - -
 method public allowLeashing ()Z - -
 method protected func_142017_o (F)V - -
 method public isChested ()Z - -
 method public getHorseArmorIndexSynced ()I - -
 method public isEatingHaystack ()Z - -
 method public isRearing ()Z - -
 method public isBreeding ()Z - -
 method public getHasReproduced ()Z - -
 method public setHorseArmorStack (Lnet/minecraft/item/ItemStack;)V - -
 method public setBreeding (Z)V - -
 method public setChested (Z)V - -
 method public setHasReproduced (Z)V - -
 method public setHorseSaddled (Z)V - -
 method public getTemper ()I - -
 method public setTemper (I)V - -
 method public increaseTemper (I)I - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getTotalArmorValue ()I - -
 method public canBePushed ()Z - -
 method public prepareChunkForSpawn ()Z - -
 method public dropChests ()V - -
 method public fall (FF)V - -
 method public onInventoryChanged (Lnet/minecraft/inventory/InventoryBasic;)V - -
 method public getCanSpawnHere ()Z - -
 method protected getClosestHorse (Lnet/minecraft/entity/Entity;D)Lnet/minecraft/entity/passive/EntityHorse; - -
 method public getHorseJumpStrength ()D - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method public isHorseSaddled ()Z - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getAngrySoundName ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected applyEntityAttributes ()V - -
 method public getMaxSpawnedInChunk ()I - -
 method public getMaxTemper ()I - -
 method protected getSoundVolume ()F - -
 method public getTalkInterval ()I - -
 method public func_110239_cn ()Z - -
 method public func_175507_cI ()Z - -
 method public getHorseTexture ()Ljava/lang/String; - -
 method public getVariantTexturePaths ()[Ljava/lang/String; - -
 method public openGUI (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public canWearArmor ()Z - -
 method public canCarryChest ()Z - -
 method protected isMovementBlocked ()Z - -
 method public isUndead ()Z - -
 method public isSterile ()Z - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method public setEating (Z)V - -
 method public setEatingHaystack (Z)V - -
 method public setRearing (Z)V - -
 method public makeHorseRearWithSound ()V - -
 method public dropChestItems ()V - -
 method public setTamedBy (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public moveEntityWithHeading (FF)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getGrassEatingAmount (F)F - -
 method public getRearingAmount (F)F - -
 method public getMouthOpennessAngle (F)F - -
 method public setJumpPower (I)V - -
 method protected spawnHorseParticles (Z)V - -
 method public handleStatusUpdate (B)V - -
 method public updateRiderPosition ()V - -
 method public,static isArmorItem (Lnet/minecraft/item/Item;)Z - -
 method public isOnLadder ()Z - -
 method public getEyeHeight ()F - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
in 91
class net/minecraft/entity/passive/EntityHorse 50 public,super net/minecraft/entity/passive/EntityAnimal net/minecraft/inventory/IInventoryChangedListener,net/minecraft/entity/IJumpingMount -
 inner net/minecraft/entity/passive/EntityHorse$GroupData net/minecraft/entity/passive/EntityHorse GroupData public,static
 field public tailCounter I -
 field public sprintCounter I -
 field protected horseJumping Z -
 field protected temper I -
 field protected jumpPower F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method public setType (Lnet/minecraft/entity/passive/HorseType;)V - -
 method public getType ()Lnet/minecraft/entity/passive/HorseType; - -
 method public setHorseVariant (I)V - -
 method public getHorseVariant ()I - -
 method public getName ()Ljava/lang/String; - -
 method public isAdultHorse ()Z - -
 method public isTame ()Z - -
 method public isRidable ()Z - -
 method public getOwnerUniqueId ()Ljava/util/UUID; - -
 method public setOwnerUniqueId (Ljava/util/UUID;)V - -
 method public getHorseSize ()F - -
 method public setScaleForAge (Z)V - -
 method public isHorseJumping ()Z - -
 method public setHorseTamed (Z)V - -
 method public setHorseJumping (Z)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected onLeashDistance (F)V - -
 method public isChested ()Z - -
 method public getHorseArmorType ()Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public isEatingHaystack ()Z - -
 method public isRearing ()Z - -
 method public isBreeding ()Z - -
 method public getHasReproduced ()Z - -
 method public setHorseArmorStack (Lnet/minecraft/item/ItemStack;)V - -
 method public setBreeding (Z)V - -
 method public setChested (Z)V - -
 method public setHasReproduced (Z)V - -
 method public setHorseSaddled (Z)V - -
 method public getTemper ()I - -
 method public setTemper (I)V - -
 method public increaseTemper (I)I - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canBePushed ()Z - -
 method public prepareChunkForSpawn ()Z - -
 method public dropChests ()V - -
 method public fall (FF)V - -
 method public onInventoryChanged (Lnet/minecraft/inventory/InventoryBasic;)V - -
 method public getCanSpawnHere ()Z - -
 method protected getClosestHorse (Lnet/minecraft/entity/Entity;D)Lnet/minecraft/entity/passive/EntityHorse; - -
 method public getHorseJumpStrength ()D - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method public isHorseSaddled ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getAngrySound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected applyEntityAttributes ()V - -
 method public getMaxSpawnedInChunk ()I - -
 method public getMaxTemper ()I - -
 method protected getSoundVolume ()F - -
 method public getTalkInterval ()I - -
 method public hasLayeredTextures ()Z - -
 method public hasTexture ()Z - -
 method public getHorseTexture ()Ljava/lang/String; - -
 method public getVariantTexturePaths ()[Ljava/lang/String; - -
 method public openGUI (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected isMovementBlocked ()Z - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method public setEatingHaystack (Z)V - -
 method public setRearing (Z)V - -
 method public makeHorseRearWithSound ()V - -
 method public dropChestItems ()V - -
 method public setTamedBy (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public moveEntityWithHeading (FF)V - -
 method public,static registerFixesHorse (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public canBeSteered ()Z - -
 method public getGrassEatingAmount (F)F - -
 method public getRearingAmount (F)F - -
 method public getMouthOpennessAngle (F)F - -
 method public setJumpPower (I)V - -
 method public canJump ()Z - -
 method public handleStartJump (I)V - -
 method public handleStopJump ()V - -
 method protected spawnHorseParticles (Z)V - -
 method public handleStatusUpdate (B)V - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method public getMountedYOffset ()D - -
 method public isSkeletonTrap ()Z - -
 method public setSkeletonTrap (Z)V - -
 method public isOnLadder ()Z - -
 method public getEyeHeight ()F - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 326
class net/minecraft/entity/passive/EntityHorse 52 public,super net/minecraft/entity/passive/AbstractHorse - -
 inner net/minecraft/entity/passive/EntityHorse$GroupData net/minecraft/entity/passive/EntityHorse GroupData public,static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public,static registerFixesHorse (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setHorseVariant (I)V - -
 method public getHorseVariant ()I - -
 method public getHorseTexture ()Ljava/lang/String; - -
 method public getVariantTexturePaths ()[Ljava/lang/String; - -
 method protected updateHorseSlots ()V - -
 method public setHorseArmorStack (Lnet/minecraft/item/ItemStack;)V - -
 method public getHorseArmorType ()Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public onInventoryChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method protected playGallopSound (Lnet/minecraft/block/SoundType;)V - -
 method protected applyEntityAttributes ()V - -
 method public onUpdate ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getAngrySound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public wearsArmor ()Z - -
 method public isArmor (Lnet/minecraft/item/ItemStack;)Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 90
class net/minecraft/entity/passive/EntityHorse$GroupData 50 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/passive/EntityHorse$GroupData net/minecraft/entity/passive/EntityHorse GroupData public,static
 field public horseType I -
 field public horseVariant I -
 method public <init> (II)V - -
in 91
class net/minecraft/entity/passive/EntityHorse$GroupData 50 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/passive/EntityHorse$GroupData net/minecraft/entity/passive/EntityHorse GroupData public,static
 field public horseType Lnet/minecraft/entity/passive/HorseType; -
 field public horseVariant I -
 method public <init> (Lnet/minecraft/entity/passive/HorseType;I)V - -
in 326
class net/minecraft/entity/passive/EntityHorse$GroupData 52 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/passive/EntityHorse$GroupData net/minecraft/entity/passive/EntityHorse GroupData public,static
 field public variant I -
 method public <init> (I)V - -
in 326
class net/minecraft/entity/passive/EntityLlama 52 public,super net/minecraft/entity/passive/AbstractChestHorse net/minecraft/entity/IRangedAttackMob -
 inner net/minecraft/entity/passive/EntityLlama$AIDefendTarget net/minecraft/entity/passive/EntityLlama AIDefendTarget static
 inner net/minecraft/entity/passive/EntityLlama$AIHurtByTarget net/minecraft/entity/passive/EntityLlama AIHurtByTarget static
 inner net/minecraft/entity/passive/EntityLlama$GroupData net/minecraft/entity/passive/EntityLlama GroupData static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getStrength ()I - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public getVariant ()I - -
 method public setVariant (I)V - -
 method protected getInventorySize ()I - -
 method public updatePassenger (Lnet/minecraft/entity/Entity;)V - -
 method public getMountedYOffset ()D - -
 method public canBeSteered ()Z - -
 method protected handleEating (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z - -
 method protected isMovementBlocked ()Z - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public hasColor ()Z - -
 method protected getAngrySound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected playChestEquipSound ()V - -
 method public makeMad ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getInventoryColumns ()I - -
 method public wearsArmor ()Z - -
 method public isArmor (Lnet/minecraft/item/ItemStack;)Z - -
 method public canBeSaddled ()Z - -
 method public onInventoryChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method protected updateHorseSlots ()V - -
 method public getColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public getMaxTemper ()I - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityLlama; - -
 method public fall (FF)V - -
 method public leaveCaravan ()V - -
 method public joinCaravan (Lnet/minecraft/entity/passive/EntityLlama;)V - -
 method public hasCaravanTrail ()Z - -
 method public inCaravan ()Z - -
 method public getCaravanHead ()Lnet/minecraft/entity/passive/EntityLlama; - -
 method protected followLeashSpeed ()D - -
 method protected followMother ()V - -
 method public canEatGrass ()Z - -
 method public attackEntityWithRangedAttack (Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method public setSwingingArms (Z)V - -
in 326
class net/minecraft/entity/passive/EntityLlama$AIDefendTarget 52 super net/minecraft/entity/ai/EntityAINearestAttackableTarget - Lnet/minecraft/entity/ai/EntityAINearestAttackableTarget<Lnet/minecraft/entity/passive/EntityWolf;>;
 inner net/minecraft/entity/passive/EntityLlama$AIDefendTarget net/minecraft/entity/passive/EntityLlama AIDefendTarget static
 method public <init> (Lnet/minecraft/entity/passive/EntityLlama;)V - -
 method public shouldExecute ()Z - -
 method protected getTargetDistance ()D - -
in 326
class net/minecraft/entity/passive/EntityLlama$AIHurtByTarget 52 super net/minecraft/entity/ai/EntityAIHurtByTarget - -
 inner net/minecraft/entity/passive/EntityLlama$AIHurtByTarget net/minecraft/entity/passive/EntityLlama AIHurtByTarget static
 method public <init> (Lnet/minecraft/entity/passive/EntityLlama;)V - -
 method public shouldContinueExecuting ()Z - -
in 326
class net/minecraft/entity/passive/EntityLlama$GroupData 52 super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/passive/EntityLlama$GroupData net/minecraft/entity/passive/EntityLlama GroupData static
 field public variant I -
in 90
class net/minecraft/entity/passive/EntityMooshroom 50 public,super net/minecraft/entity/passive/EntityCow net/minecraftforge/common/IShearable -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityMooshroom; - -
 method public isShearable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;I)Ljava/util/List; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;I)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
in 91
class net/minecraft/entity/passive/EntityMooshroom 50 public,super net/minecraft/entity/passive/EntityCow net/minecraftforge/common/IShearable -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesMooshroom (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityMooshroom; - -
 method public isShearable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 326
class net/minecraft/entity/passive/EntityMooshroom 52 public,super net/minecraft/entity/passive/EntityCow net/minecraftforge/common/IShearable -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesMooshroom (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityMooshroom; - -
 method public isShearable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 326
class net/minecraft/entity/passive/EntityMule 52 public,super net/minecraft/entity/passive/AbstractChestHorse - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesMule (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected playChestEquipSound ()V - -
in 90
class net/minecraft/entity/passive/EntityOcelot 50 public,super net/minecraft/entity/passive/EntityTameable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public updateAITasks ()V - -
 method protected canDespawn ()Z - -
 method protected applyEntityAttributes ()V - -
 method public fall (FF)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getSoundVolume ()F - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected dropFewItems (ZI)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityOcelot; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public getTameSkin ()I - -
 method public setTameSkin (I)V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public setTamed (Z)V - -
 method protected setupTamedAI ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 91
class net/minecraft/entity/passive/EntityOcelot 50 public,super net/minecraft/entity/passive/EntityTameable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method public updateAITasks ()V - -
 method protected canDespawn ()Z - -
 method protected applyEntityAttributes ()V - -
 method public fall (FF)V - -
 method public,static registerFixesOcelot (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityOcelot; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public getTameSkin ()I - -
 method public setTameSkin (I)V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public setTamed (Z)V - -
 method protected setupTamedAI ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 326
class net/minecraft/entity/passive/EntityOcelot 52 public,super net/minecraft/entity/passive/EntityTameable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected entityInit ()V - -
 method public updateAITasks ()V - -
 method protected canDespawn ()Z - -
 method protected applyEntityAttributes ()V - -
 method public fall (FF)V - -
 method public,static registerFixesOcelot (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityOcelot; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public getTameSkin ()I - -
 method public setTameSkin (I)V - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getName ()Ljava/lang/String; - -
 method protected setupTamedAI ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
in 326
class net/minecraft/entity/passive/EntityParrot 52 public,super net/minecraft/entity/passive/EntityShoulderRiding net/minecraft/entity/passive/EntityFlying -
 field public flap F -
 field public flapSpeed F -
 field public oFlapSpeed F -
 field public oFlap F -
 field public flapping F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method protected createNavigator (Lnet/minecraft/world/World;)Lnet/minecraft/pathfinding/PathNavigate; - -
 method public getEyeHeight ()F - -
 method public onLivingUpdate ()V - -
 method public setPartying (Lnet/minecraft/util/math/BlockPos;Z)V - -
 method public isPartying ()Z - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getCanSpawnHere ()Z - -
 method public fall (FF)V - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/EntityAgeable; - -
 method public,static playAmbientSound (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;)V - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method protected playFlySound (F)F - -
 method protected makeFlySound ()Z - -
 method protected getSoundPitch ()F - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public canBePushed ()Z - -
 method protected collideWithEntity (Lnet/minecraft/entity/Entity;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getVariant ()I - -
 method public setVariant (I)V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isFlying ()Z - -
 method public,static registerMimicSound (Ljava/lang/Class;Lnet/minecraft/util/SoundEvent;)V (Ljava/lang/Class<+Lnet/minecraft/entity/Entity;>;Lnet/minecraft/util/SoundEvent;)V -
in 90
class net/minecraft/entity/passive/EntityPig 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public canBeSteered ()Z - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected dropFewItems (ZI)V - -
 method public getSaddled ()Z - -
 method public setSaddled (Z)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public fall (FF)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityPig; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getAIControlledByPlayer ()Lnet/minecraft/entity/ai/EntityAIControlledByPlayer; - -
in 91
class net/minecraft/entity/passive/EntityPig 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
 method public canBeSteered ()Z - -
 method protected entityInit ()V - -
 method public,static registerFixesPig (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected dropEquipment (ZI)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getSaddled ()Z - -
 method public setSaddled (Z)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public fall (FF)V - -
 method public moveEntityWithHeading (FF)V - -
 method public boost ()Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityPig; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/entity/passive/EntityPig 52 public,super net/minecraft/entity/passive/EntityAnimal - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public getControllingPassenger ()Lnet/minecraft/entity/Entity; - -
 method public canBeSteered ()Z - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method protected entityInit ()V - -
 method public,static registerFixesPig (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public getSaddled ()Z - -
 method public setSaddled (Z)V - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public travel (FFF)V - -
 method public boost ()Z - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityPig; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
in 90
class net/minecraft/entity/passive/EntityRabbit 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 inner net/minecraft/entity/passive/EntityRabbit$EnumMoveType net/minecraft/entity/passive/EntityRabbit EnumMoveType static,final,enum
 inner net/minecraft/entity/passive/EntityRabbit$AIEvilAttack net/minecraft/entity/passive/EntityRabbit AIEvilAttack static
 inner net/minecraft/entity/passive/EntityRabbit$AIPanic net/minecraft/entity/passive/EntityRabbit AIPanic static
 inner net/minecraft/entity/passive/EntityRabbit$AIRaidFarm net/minecraft/entity/passive/EntityRabbit AIRaidFarm static
 inner net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity net/minecraft/entity/passive/EntityRabbit AIAvoidEntity static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper net/minecraft/entity/passive/EntityRabbit RabbitMoveHelper static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 inner net/minecraft/entity/passive/EntityRabbit$RabbitTypeData net/minecraft/entity/passive/EntityRabbit RabbitTypeData public,static
 method public func_175521_o (F)F - -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected getJumpUpwardsMotion ()F - -
 method public setMoveType (Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType;)V - -
 method public setMovementSpeed (D)V - -
 method public setJumping (ZLnet/minecraft/entity/passive/EntityRabbit$EnumMoveType;)V - -
 method public doMovementAction (Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType;)V - -
 method public func_175523_cj ()Z - -
 method protected entityInit ()V - -
 method public updateAITasks ()V - -
 method public spawnRunningParticles ()V - -
 method public onLivingUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getJumpingSound ()Ljava/lang/String; - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getTotalArmorValue ()I - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected addRandomDrop ()V - -
 method protected dropFewItems (ZI)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityRabbit; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRabbitType ()I - -
 method public setRabbitType (I)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected getMoveTypeDuration ()I - -
 method protected createEatingParticles ()V - -
in 91
class net/minecraft/entity/passive/EntityRabbit 50 public,super net/minecraft/entity/passive/EntityAnimal - -
 inner net/minecraft/entity/passive/EntityRabbit$AIEvilAttack net/minecraft/entity/passive/EntityRabbit AIEvilAttack static
 inner net/minecraft/entity/passive/EntityRabbit$AIPanic net/minecraft/entity/passive/EntityRabbit AIPanic static
 inner net/minecraft/entity/passive/EntityRabbit$AIRaidFarm net/minecraft/entity/passive/EntityRabbit AIRaidFarm static
 inner net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity net/minecraft/entity/passive/EntityRabbit AIAvoidEntity static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper net/minecraft/entity/passive/EntityRabbit RabbitMoveHelper static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 inner net/minecraft/entity/passive/EntityRabbit$RabbitTypeData net/minecraft/entity/passive/EntityRabbit RabbitTypeData public,static
 method public setJumpCompletion (F)F - -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected getJumpUpwardsMotion ()F - -
 method protected jump ()V - -
 method public setMovementSpeed (D)V - -
 method public setJumping (Z)V - -
 method public startJumping ()V - -
 method protected entityInit ()V - -
 method public updateAITasks ()V - -
 method public spawnRunningParticles ()V - -
 method public onLivingUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method public,static registerFixesRabbit (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getJumpSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityRabbit; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRabbitType ()I - -
 method public setRabbitType (I)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected createEatingParticles ()V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
in 326
class net/minecraft/entity/passive/EntityRabbit 52 public,super net/minecraft/entity/passive/EntityAnimal - -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitTypeData net/minecraft/entity/passive/EntityRabbit RabbitTypeData public,static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper net/minecraft/entity/passive/EntityRabbit RabbitMoveHelper static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 inner net/minecraft/entity/passive/EntityRabbit$AIRaidFarm net/minecraft/entity/passive/EntityRabbit AIRaidFarm static
 inner net/minecraft/entity/passive/EntityRabbit$AIPanic net/minecraft/entity/passive/EntityRabbit AIPanic static
 inner net/minecraft/entity/passive/EntityRabbit$AIEvilAttack net/minecraft/entity/passive/EntityRabbit AIEvilAttack static
 inner net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity net/minecraft/entity/passive/EntityRabbit AIAvoidEntity static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected getJumpUpwardsMotion ()F - -
 method protected jump ()V - -
 method public getJumpCompletion (F)F - -
 method public setMovementSpeed (D)V - -
 method public setJumping (Z)V - -
 method public startJumping ()V - -
 method protected entityInit ()V - -
 method public updateAITasks ()V - -
 method public spawnRunningParticles ()V - -
 method public onLivingUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method public,static registerFixesRabbit (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getJumpSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityRabbit; - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getRabbitType ()I - -
 method public setRabbitType (I)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method protected createEatingParticles ()V - -
 method public handleStatusUpdate (B)V - -
in 90
class net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity 50 super net/minecraft/entity/ai/EntityAIAvoidEntity - <T:Lnet/minecraft/entity/Entity;>Lnet/minecraft/entity/ai/EntityAIAvoidEntity<TT;>;
 inner net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity net/minecraft/entity/passive/EntityRabbit AIAvoidEntity static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;Ljava/lang/Class;FDD)V (Lnet/minecraft/entity/passive/EntityRabbit;Ljava/lang/Class<TT;>;FDD)V -
 method public updateTask ()V - -
in 91
class net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity 50 super net/minecraft/entity/ai/EntityAIAvoidEntity - <T:Lnet/minecraft/entity/Entity;>Lnet/minecraft/entity/ai/EntityAIAvoidEntity<TT;>;
 inner net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity net/minecraft/entity/passive/EntityRabbit AIAvoidEntity static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;Ljava/lang/Class;FDD)V (Lnet/minecraft/entity/passive/EntityRabbit;Ljava/lang/Class<TT;>;FDD)V -
 method public shouldExecute ()Z - -
in 326
class net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity 52 super net/minecraft/entity/ai/EntityAIAvoidEntity - <T:Lnet/minecraft/entity/Entity;>Lnet/minecraft/entity/ai/EntityAIAvoidEntity<TT;>;
 inner net/minecraft/entity/passive/EntityRabbit$AIAvoidEntity net/minecraft/entity/passive/EntityRabbit AIAvoidEntity static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;Ljava/lang/Class;FDD)V (Lnet/minecraft/entity/passive/EntityRabbit;Ljava/lang/Class<TT;>;FDD)V -
 method public shouldExecute ()Z - -
in 90
class net/minecraft/entity/passive/EntityRabbit$AIEvilAttack 50 super net/minecraft/entity/ai/EntityAIAttackOnCollide - -
 inner net/minecraft/entity/passive/EntityRabbit$AIEvilAttack net/minecraft/entity/passive/EntityRabbit AIEvilAttack static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method protected func_179512_a (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 91
class net/minecraft/entity/passive/EntityRabbit$AIEvilAttack 50 super net/minecraft/entity/ai/EntityAIAttackMelee - -
 inner net/minecraft/entity/passive/EntityRabbit$AIEvilAttack net/minecraft/entity/passive/EntityRabbit AIEvilAttack static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 326
class net/minecraft/entity/passive/EntityRabbit$AIEvilAttack 52 super net/minecraft/entity/ai/EntityAIAttackMelee - -
 inner net/minecraft/entity/passive/EntityRabbit$AIEvilAttack net/minecraft/entity/passive/EntityRabbit AIEvilAttack static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method protected getAttackReachSqr (Lnet/minecraft/entity/EntityLivingBase;)D - -
in 24
class net/minecraft/entity/passive/EntityRabbit$AIPanic 50 super net/minecraft/entity/ai/EntityAIPanic - -
 inner net/minecraft/entity/passive/EntityRabbit$AIPanic net/minecraft/entity/passive/EntityRabbit AIPanic static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;D)V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/passive/EntityRabbit$AIPanic 52 super net/minecraft/entity/ai/EntityAIPanic - -
 inner net/minecraft/entity/passive/EntityRabbit$AIPanic net/minecraft/entity/passive/EntityRabbit AIPanic static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;D)V - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/passive/EntityRabbit$AIRaidFarm 50 super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 inner net/minecraft/entity/passive/EntityRabbit$AIRaidFarm net/minecraft/entity/passive/EntityRabbit AIRaidFarm static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)Z - -
in 91
class net/minecraft/entity/passive/EntityRabbit$AIRaidFarm 50 super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 inner net/minecraft/entity/passive/EntityRabbit$AIRaidFarm net/minecraft/entity/passive/EntityRabbit AIRaidFarm static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public shouldExecute ()Z - -
 method public continueExecuting ()Z - -
 method public startExecuting ()V - -
 method public resetTask ()V - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 326
class net/minecraft/entity/passive/EntityRabbit$AIRaidFarm 52 super net/minecraft/entity/ai/EntityAIMoveToBlock - -
 inner net/minecraft/entity/passive/EntityRabbit$AIRaidFarm net/minecraft/entity/passive/EntityRabbit AIRaidFarm static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public shouldExecute ()Z - -
 method public shouldContinueExecuting ()Z - -
 method public updateTask ()V - -
 method protected shouldMoveTo (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Z - -
in 90
class net/minecraft/entity/passive/EntityRabbit$EnumMoveType 50 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType;>;
 inner net/minecraft/entity/passive/EntityRabbit$EnumMoveType net/minecraft/entity/passive/EntityRabbit EnumMoveType static,final,enum
 field public,static,final,enum NONE Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType; -
 field public,static,final,enum HOP Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType; -
 field public,static,final,enum STEP Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType; -
 field public,static,final,enum SPRINT Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType; -
 field public,static,final,enum ATTACK Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType; -
 method public,static values ()[Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/passive/EntityRabbit$EnumMoveType; - -
 method public getSpeed ()F - -
 method public func_180074_b ()F - -
 method public getDuration ()I - -
 method public func_180073_d ()I - -
in 90
class net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper 50 public,super net/minecraft/entity/ai/EntityJumpHelper - -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 inner net/minecraft/entity/passive/EntityRabbit$EnumMoveType net/minecraft/entity/passive/EntityRabbit EnumMoveType static,final,enum
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public getIsJumping ()Z - -
 method public func_180065_d ()Z - -
 method public func_180066_a (Z)V - -
 method public doJump ()V - -
in 91
class net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper 50 public,super net/minecraft/entity/ai/EntityJumpHelper - -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public getIsJumping ()Z - -
 method public canJump ()Z - -
 method public setCanJump (Z)V - -
 method public doJump ()V - -
in 326
class net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper 52 public,super net/minecraft/entity/ai/EntityJumpHelper - -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public getIsJumping ()Z - -
 method public canJump ()Z - -
 method public setCanJump (Z)V - -
 method public doJump ()V - -
in 90
class net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper net/minecraft/entity/passive/EntityRabbit RabbitMoveHelper static
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public onUpdateMoveHelper ()V - -
in 91
class net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper 50 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper net/minecraft/entity/passive/EntityRabbit RabbitMoveHelper static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public onUpdateMoveHelper ()V - -
 method public setMoveTo (DDDD)V - -
in 326
class net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper 52 super net/minecraft/entity/ai/EntityMoveHelper - -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitMoveHelper net/minecraft/entity/passive/EntityRabbit RabbitMoveHelper static
 inner net/minecraft/entity/passive/EntityRabbit$RabbitJumpHelper net/minecraft/entity/passive/EntityRabbit RabbitJumpHelper public
 method public <init> (Lnet/minecraft/entity/passive/EntityRabbit;)V - -
 method public onUpdateMoveHelper ()V - -
 method public setMoveTo (DDDD)V - -
in 24
class net/minecraft/entity/passive/EntityRabbit$RabbitTypeData 50 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitTypeData net/minecraft/entity/passive/EntityRabbit RabbitTypeData public,static
 field public typeData I -
 method public <init> (I)V - -
in 326
class net/minecraft/entity/passive/EntityRabbit$RabbitTypeData 52 public,super java/lang/Object net/minecraft/entity/IEntityLivingData -
 inner net/minecraft/entity/passive/EntityRabbit$RabbitTypeData net/minecraft/entity/passive/EntityRabbit RabbitTypeData public,static
 field public typeData I -
 method public <init> (I)V - -
in 90
class net/minecraft/entity/passive/EntitySheep 50 public,super net/minecraft/entity/passive/EntityAnimal net/minecraftforge/common/IShearable -
 method public,static getDyeRgb (Lnet/minecraft/item/EnumDyeColor;)[F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected updateAITasks ()V - -
 method public onLivingUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected dropFewItems (ZI)V - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public handleStatusUpdate (B)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getHeadRotationPointY (F)F - -
 method public getHeadRotationAngleX (F)F - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public getFleeceColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public setFleeceColor (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public getSheared ()Z - -
 method public setSheared (Z)V - -
 method public,static getRandomSheepColor (Ljava/util/Random;)Lnet/minecraft/item/EnumDyeColor; - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntitySheep; - -
 method public eatGrassBonus ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
 method public isShearable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;I)Ljava/util/List; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/BlockPos;I)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
in 91
class net/minecraft/entity/passive/EntitySheep 50 public,super net/minecraft/entity/passive/EntityAnimal net/minecraftforge/common/IShearable -
 method public,static getDyeRgb (Lnet/minecraft/item/EnumDyeColor;)[F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected updateAITasks ()V - -
 method public onLivingUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public handleStatusUpdate (B)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method public getHeadRotationPointY (F)F - -
 method public getHeadRotationAngleX (F)F - -
 method public,static registerFixesSheep (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public getFleeceColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public setFleeceColor (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public getSheared ()Z - -
 method public setSheared (Z)V - -
 method public,static getRandomSheepColor (Ljava/util/Random;)Lnet/minecraft/item/EnumDyeColor; - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntitySheep; - -
 method public eatGrassBonus ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public getEyeHeight ()F - -
 method public isShearable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
in 326
class net/minecraft/entity/passive/EntitySheep 52 public,super net/minecraft/entity/passive/EntityAnimal net/minecraftforge/common/IShearable -
 method public,static getDyeRgb (Lnet/minecraft/item/EnumDyeColor;)[F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected updateAITasks ()V - -
 method public onLivingUpdate ()V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public handleStatusUpdate (B)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public,static registerFixesSheep (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getHeadRotationPointY (F)F - -
 method public getHeadRotationAngleX (F)F - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public getFleeceColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public setFleeceColor (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public getSheared ()Z - -
 method public setSheared (Z)V - -
 method public,static getRandomSheepColor (Ljava/util/Random;)Lnet/minecraft/item/EnumDyeColor; - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntitySheep; - -
 method public eatGrassBonus ()V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public isShearable (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List; (Lnet/minecraft/item/ItemStack;Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;I)Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public getEyeHeight ()F - -
in 326
class net/minecraft/entity/passive/EntityShoulderRiding 52 public,super,abstract net/minecraft/entity/passive/EntityTameable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public setEntityOnShoulder (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onUpdate ()V - -
 method public canSitOnShoulder ()Z - -
in 326
class net/minecraft/entity/passive/EntitySkeletonHorse 52 public,super net/minecraft/entity/passive/AbstractHorse - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method public getMountedYOffset ()D - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public onLivingUpdate ()V - -
 method public,static registerFixesSkeletonHorse (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public isTrap ()Z - -
 method public setTrap (Z)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
in 90
class net/minecraft/entity/passive/EntitySquid 50 public,super net/minecraft/entity/passive/EntityWaterMob - -
 inner net/minecraft/entity/passive/EntitySquid$AIMoveRandom net/minecraft/entity/passive/EntitySquid AIMoveRandom static
 field public squidPitch F -
 field public prevSquidPitch F -
 field public squidYaw F -
 field public prevSquidYaw F -
 field public squidRotation F -
 field public prevSquidRotation F -
 field public tentacleAngle F -
 field public lastTentacleAngle F -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public getEyeHeight ()F - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getSoundVolume ()F - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method protected canTriggerWalking ()Z - -
 method protected dropFewItems (ZI)V - -
 method public isInWater ()Z - -
 method public onLivingUpdate ()V - -
 method public moveEntityWithHeading (FF)V - -
 method public getCanSpawnHere ()Z - -
 method public func_175568_b (FFF)V - -
 method public func_175567_n ()Z - -
in 91
class net/minecraft/entity/passive/EntitySquid 50 public,super net/minecraft/entity/passive/EntityWaterMob - -
 inner net/minecraft/entity/passive/EntitySquid$AIMoveRandom net/minecraft/entity/passive/EntitySquid AIMoveRandom static
 field public squidPitch F -
 field public prevSquidPitch F -
 field public squidYaw F -
 field public prevSquidYaw F -
 field public squidRotation F -
 field public prevSquidRotation F -
 field public tentacleAngle F -
 field public lastTentacleAngle F -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSquid (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public getEyeHeight ()F - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method protected canTriggerWalking ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public isInWater ()Z - -
 method public onLivingUpdate ()V - -
 method public moveEntityWithHeading (FF)V - -
 method public getCanSpawnHere ()Z - -
 method public setMovementVector (FFF)V - -
 method public hasMovementVector ()Z - -
in 326
class net/minecraft/entity/passive/EntitySquid 52 public,super net/minecraft/entity/passive/EntityWaterMob - -
 inner net/minecraft/entity/passive/EntitySquid$AIMoveRandom net/minecraft/entity/passive/EntitySquid AIMoveRandom static
 field public squidPitch F -
 field public prevSquidPitch F -
 field public squidYaw F -
 field public prevSquidYaw F -
 field public squidRotation F -
 field public prevSquidRotation F -
 field public tentacleAngle F -
 field public lastTentacleAngle F -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesSquid (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public getEyeHeight ()F - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method protected canTriggerWalking ()Z - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public onLivingUpdate ()V - -
 method public travel (FFF)V - -
 method public getCanSpawnHere ()Z - -
 method public handleStatusUpdate (B)V - -
 method public setMovementVector (FFF)V - -
 method public hasMovementVector ()Z - -
in 24
class net/minecraft/entity/passive/EntitySquid$AIMoveRandom 50 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/passive/EntitySquid$AIMoveRandom net/minecraft/entity/passive/EntitySquid AIMoveRandom static
 method public <init> (Lnet/minecraft/entity/passive/EntitySquid;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/passive/EntitySquid$AIMoveRandom 52 super net/minecraft/entity/ai/EntityAIBase - -
 inner net/minecraft/entity/passive/EntitySquid$AIMoveRandom net/minecraft/entity/passive/EntitySquid AIMoveRandom static
 method public <init> (Lnet/minecraft/entity/passive/EntitySquid;)V - -
 method public shouldExecute ()Z - -
 method public updateTask ()V - -
in 90
class net/minecraft/entity/passive/EntityTameable 50 public,super,abstract net/minecraft/entity/passive/EntityAnimal net/minecraft/entity/IEntityOwnable -
 field protected aiSit Lnet/minecraft/entity/ai/EntityAISit; -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected playTameEffect (Z)V - -
 method public isTamed ()Z - -
 method public setTamed (Z)V - -
 method protected setupTamedAI ()V - -
 method public isSitting ()Z - -
 method public setSitting (Z)V - -
 method public getOwnerId ()Ljava/lang/String; - -
 method public setOwnerId (Ljava/lang/String;)V - -
 method public getOwner ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public isOwner (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getAISit ()Lnet/minecraft/entity/ai/EntityAISit; - -
 method public shouldAttackEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public isOnSameTeam (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
in 91
class net/minecraft/entity/passive/EntityTameable 50 public,super,abstract net/minecraft/entity/passive/EntityAnimal net/minecraft/entity/IEntityOwnable -
 field protected,static,final TAMED Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field protected,static,final OWNER_UNIQUE_ID Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lcom/google/common/base/Optional<Ljava/util/UUID;>;>;
 field protected aiSit Lnet/minecraft/entity/ai/EntityAISit; -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected playTameEffect (Z)V - -
 method public isTamed ()Z - -
 method public setTamed (Z)V - -
 method protected setupTamedAI ()V - -
 method public isSitting ()Z - -
 method public setSitting (Z)V - -
 method public getOwnerId ()Ljava/util/UUID; - -
 method public setOwnerId (Ljava/util/UUID;)V - -
 method public getOwner ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public isOwner (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getAISit ()Lnet/minecraft/entity/ai/EntityAISit; - -
 method public shouldAttackEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public isOnSameTeam (Lnet/minecraft/entity/Entity;)Z - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
in 326
class net/minecraft/entity/passive/EntityTameable 52 public,super,abstract net/minecraft/entity/passive/EntityAnimal net/minecraft/entity/IEntityOwnable -
 field protected,static,final TAMED Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field protected,static,final OWNER_UNIQUE_ID Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lcom/google/common/base/Optional<Ljava/util/UUID;>;>;
 field protected aiSit Lnet/minecraft/entity/ai/EntityAISit; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected playTameEffect (Z)V - -
 method public handleStatusUpdate (B)V - -
 method public isTamed ()Z - -
 method public setTamed (Z)V - -
 method protected setupTamedAI ()V - -
 method public isSitting ()Z - -
 method public setSitting (Z)V - -
 method public getOwnerId ()Ljava/util/UUID; - -
 method public setOwnerId (Ljava/util/UUID;)V - -
 method public setTamedBy (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getOwner ()Lnet/minecraft/entity/EntityLivingBase; - -
 method public isOwner (Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getAISit ()Lnet/minecraft/entity/ai/EntityAISit; - -
 method public shouldAttackEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public isOnSameTeam (Lnet/minecraft/entity/Entity;)Z - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
in 90
class net/minecraft/entity/passive/EntityVillager 50 public,super net/minecraft/entity/EntityAgeable net/minecraft/entity/IMerchant,net/minecraft/entity/INpc -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ListItemForEmeralds net/minecraft/entity/passive/EntityVillager ListItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedItemForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedBookForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedBookForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem net/minecraft/entity/passive/EntityVillager ItemAndEmeraldToItem public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 inner net/minecraft/entity/passive/EntityVillager$EmeraldForItems net/minecraft/entity/passive/EntityVillager EmeraldForItems public,static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;I)V - -
 method protected onGrowingAdult ()V - -
 method protected applyEntityAttributes ()V - -
 method protected updateAITasks ()V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected entityInit ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected canDespawn ()Z - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public setProfession (I)V - -
 method public getProfession ()I - -
 method public isMating ()Z - -
 method public setMating (Z)V - -
 method public setPlaying (Z)V - -
 method public isPlaying ()Z - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public isTrading ()Z - -
 method public getIsWillingToMate (Z)Z - -
 method public setIsWillingToMate (Z)V - -
 method public useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public getEyeHeight ()F - -
 method public handleStatusUpdate (B)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public setLookingForHome ()V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityVillager; - -
 method public allowLeashing ()Z - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public getVillagerInventory ()Lnet/minecraft/inventory/InventoryBasic; - -
 method protected updateEquipmentIfNeeded (Lnet/minecraft/entity/item/EntityItem;)V - -
 method public func_175553_cp ()Z - -
 method public canAbondonItems ()Z - -
 method public func_175557_cr ()Z - -
 method public isFarmItemInInventory ()Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
in 91
class net/minecraft/entity/passive/EntityVillager 50 public,super net/minecraft/entity/EntityAgeable net/minecraft/entity/IMerchant,net/minecraft/entity/INpc -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ListItemForEmeralds net/minecraft/entity/passive/EntityVillager ListItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedItemForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedBookForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedBookForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem net/minecraft/entity/passive/EntityVillager ItemAndEmeraldToItem public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 inner net/minecraft/entity/passive/EntityVillager$EmeraldForItems net/minecraft/entity/passive/EntityVillager EmeraldForItems public,static
 inner net/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession net/minecraftforge/fml/common/registry/VillagerRegistry VillagerProfession public,static
 inner net/minecraftforge/fml/common/registry/VillagerRegistry$VillagerCareer net/minecraftforge/fml/common/registry/VillagerRegistry VillagerCareer public,static
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;I)V - -
 method protected initEntityAI ()V - -
 method protected onGrowingAdult ()V - -
 method protected applyEntityAttributes ()V - -
 method protected updateAITasks ()V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method protected entityInit ()V - -
 method public,static registerFixesVillager (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected canDespawn ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public setProfession (I)V - -
 method public,deprecated getProfession ()I - -
 method public setProfession (Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession;)V - -
 method public getProfessionForge ()Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession; - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public isMating ()Z - -
 method public setMating (Z)V - -
 method public setPlaying (Z)V - -
 method public isPlaying ()Z - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public isTrading ()Z - -
 method public getIsWillingToMate (Z)Z - -
 method public setIsWillingToMate (Z)V - -
 method public useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getEyeHeight ()F - -
 method public handleStatusUpdate (B)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public setLookingForHome ()V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityVillager; - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public getVillagerInventory ()Lnet/minecraft/inventory/InventoryBasic; - -
 method protected updateEquipmentIfNeeded (Lnet/minecraft/entity/item/EntityItem;)V - -
 method public hasEnoughFoodToBreed ()Z - -
 method public canAbondonItems ()Z - -
 method public wantsMoreFood ()Z - -
 method public isFarmItemInInventory ()Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public,static GET_TRADES_DONT_USE ()[[[[Lnet/minecraft/entity/passive/EntityVillager$ITradeList; - -
in 326
class net/minecraft/entity/passive/EntityVillager 52 public,super net/minecraft/entity/EntityAgeable net/minecraft/entity/INpc,net/minecraft/entity/IMerchant -
 inner net/minecraft/entity/passive/EntityVillager$TreasureMapForEmeralds net/minecraft/entity/passive/EntityVillager TreasureMapForEmeralds static
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ListItemForEmeralds net/minecraft/entity/passive/EntityVillager ListItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedItemForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedBookForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedBookForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem net/minecraft/entity/passive/EntityVillager ItemAndEmeraldToItem public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 inner net/minecraft/entity/passive/EntityVillager$EmeraldForItems net/minecraft/entity/passive/EntityVillager EmeraldForItems public,static
 inner net/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession net/minecraftforge/fml/common/registry/VillagerRegistry VillagerProfession public,static
 inner net/minecraftforge/fml/common/registry/VillagerRegistry$VillagerCareer net/minecraftforge/fml/common/registry/VillagerRegistry VillagerCareer public,static
 inner net/minecraft/world/storage/MapDecoration$Type net/minecraft/world/storage/MapDecoration Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;I)V - -
 method protected initEntityAI ()V - -
 method protected onGrowingAdult ()V - -
 method protected applyEntityAttributes ()V - -
 method protected updateAITasks ()V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method protected entityInit ()V - -
 method public,static registerFixesVillager (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected canDespawn ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public setProfession (I)V - -
 method public,deprecated getProfession ()I - -
 method public setProfession (Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession;)V - -
 method public getProfessionForge ()Lnet/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession; - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public isMating ()Z - -
 method public setMating (Z)V - -
 method public setPlaying (Z)V - -
 method public isPlaying ()Z - -
 method public setRevengeTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public setCustomer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCustomer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public isTrading ()Z - -
 method public getIsWillingToMate (Z)Z - -
 method public setIsWillingToMate (Z)V - -
 method public useRecipe (Lnet/minecraft/village/MerchantRecipe;)V - -
 method public verifySellingItem (Lnet/minecraft/item/ItemStack;)V - -
 method public getRecipes (Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/village/MerchantRecipeList; - -
 method public setRecipes (Lnet/minecraft/village/MerchantRecipeList;)V - -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public getPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getEyeHeight ()F - -
 method public handleStatusUpdate (B)V - -
 method public onInitialSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;)Lnet/minecraft/entity/IEntityLivingData; - -
 method public finalizeMobSpawn (Lnet/minecraft/world/DifficultyInstance;Lnet/minecraft/entity/IEntityLivingData;Z)Lnet/minecraft/entity/IEntityLivingData; - -
 method public setLookingForHome ()V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityVillager; - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public onStruckByLightning (Lnet/minecraft/entity/effect/EntityLightningBolt;)V - -
 method public getVillagerInventory ()Lnet/minecraft/inventory/InventoryBasic; - -
 method protected updateEquipmentIfNeeded (Lnet/minecraft/entity/item/EntityItem;)V - -
 method public hasEnoughFoodToBreed ()Z - -
 method public canAbondonItems ()Z - -
 method public wantsMoreFood ()Z - -
 method public isFarmItemInInventory ()Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public,static,deprecated GET_TRADES_DONT_USE ()[[[[Lnet/minecraft/entity/passive/EntityVillager$ITradeList; - -
in 90
class net/minecraft/entity/passive/EntityVillager$EmeraldForItems 50 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$EmeraldForItems net/minecraft/entity/passive/EntityVillager EmeraldForItems public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public sellItem Lnet/minecraft/item/Item; -
 field public price Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 91
class net/minecraft/entity/passive/EntityVillager$EmeraldForItems 50 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$EmeraldForItems net/minecraft/entity/passive/EntityVillager EmeraldForItems public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public buyingItem Lnet/minecraft/item/Item; -
 field public price Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/passive/EntityVillager$EmeraldForItems 52 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$EmeraldForItems net/minecraft/entity/passive/EntityVillager EmeraldForItems public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public buyingItem Lnet/minecraft/item/Item; -
 field public price Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public addMerchantRecipe (Lnet/minecraft/entity/IMerchant;Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 24
class net/minecraft/entity/passive/EntityVillager$ITradeList 50 public,interface,abstract java/lang/Object - -
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 method public,abstract modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/passive/EntityVillager$ITradeList 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 method public,abstract addMerchantRecipe (Lnet/minecraft/entity/IMerchant;Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 90
class net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem 50 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem net/minecraft/entity/passive/EntityVillager ItemAndEmeraldToItem public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public buyingItemStack Lnet/minecraft/item/ItemStack; -
 field public buyingPriceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 field public sellingItemstack Lnet/minecraft/item/ItemStack; -
 field public field_179408_d Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 91
class net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem 50 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem net/minecraft/entity/passive/EntityVillager ItemAndEmeraldToItem public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public buyingItemStack Lnet/minecraft/item/ItemStack; -
 field public buyingPriceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 field public sellingItemstack Lnet/minecraft/item/ItemStack; -
 field public sellingPriceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem 52 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ItemAndEmeraldToItem net/minecraft/entity/passive/EntityVillager ItemAndEmeraldToItem public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public buyingItemStack Lnet/minecraft/item/ItemStack; -
 field public buyingPriceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 field public sellingItemstack Lnet/minecraft/item/ItemStack; -
 field public sellingPriceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public addMerchantRecipe (Lnet/minecraft/entity/IMerchant;Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 24
class net/minecraft/entity/passive/EntityVillager$ListEnchantedBookForEmeralds 50 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedBookForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedBookForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 method public <init> ()V - -
 method public modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/passive/EntityVillager$ListEnchantedBookForEmeralds 52 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedBookForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedBookForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 method public <init> ()V - -
 method public addMerchantRecipe (Lnet/minecraft/entity/IMerchant;Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 24
class net/minecraft/entity/passive/EntityVillager$ListEnchantedItemForEmeralds 50 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedItemForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public enchantedItemStack Lnet/minecraft/item/ItemStack; -
 field public priceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/passive/EntityVillager$ListEnchantedItemForEmeralds 52 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ListEnchantedItemForEmeralds net/minecraft/entity/passive/EntityVillager ListEnchantedItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public enchantedItemStack Lnet/minecraft/item/ItemStack; -
 field public priceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public addMerchantRecipe (Lnet/minecraft/entity/IMerchant;Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 24
class net/minecraft/entity/passive/EntityVillager$ListItemForEmeralds 50 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ListItemForEmeralds net/minecraft/entity/passive/EntityVillager ListItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public itemToBuy Lnet/minecraft/item/ItemStack; -
 field public priceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public modifyMerchantRecipeList (Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 326
class net/minecraft/entity/passive/EntityVillager$ListItemForEmeralds 52 public,super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/entity/passive/EntityVillager$ListItemForEmeralds net/minecraft/entity/passive/EntityVillager ListItemForEmeralds public,static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public itemToBuy Lnet/minecraft/item/ItemStack; -
 field public priceInfo Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 method public <init> (Lnet/minecraft/item/Item;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public <init> (Lnet/minecraft/item/ItemStack;Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;)V - -
 method public addMerchantRecipe (Lnet/minecraft/entity/IMerchant;Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 24
class net/minecraft/entity/passive/EntityVillager$PriceInfo 50 public,super net/minecraft/util/Tuple - Lnet/minecraft/util/Tuple<Ljava/lang/Integer;Ljava/lang/Integer;>;
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 method public <init> (II)V - -
 method public getPrice (Ljava/util/Random;)I - -
in 326
class net/minecraft/entity/passive/EntityVillager$PriceInfo 52 public,super net/minecraft/util/Tuple - Lnet/minecraft/util/Tuple<Ljava/lang/Integer;Ljava/lang/Integer;>;
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 method public <init> (II)V - -
 method public getPrice (Ljava/util/Random;)I - -
in 326
class net/minecraft/entity/passive/EntityVillager$TreasureMapForEmeralds 52 super java/lang/Object net/minecraft/entity/passive/EntityVillager$ITradeList -
 inner net/minecraft/entity/passive/EntityVillager$PriceInfo net/minecraft/entity/passive/EntityVillager PriceInfo public,static
 inner net/minecraft/world/storage/MapDecoration$Type net/minecraft/world/storage/MapDecoration Type public,static,final,enum
 inner net/minecraft/entity/passive/EntityVillager$TreasureMapForEmeralds net/minecraft/entity/passive/EntityVillager TreasureMapForEmeralds static
 inner net/minecraft/entity/passive/EntityVillager$ITradeList net/minecraft/entity/passive/EntityVillager ITradeList public,static,interface,abstract
 field public value Lnet/minecraft/entity/passive/EntityVillager$PriceInfo; -
 field public destination Ljava/lang/String; -
 field public destinationType Lnet/minecraft/world/storage/MapDecoration$Type; -
 method public <init> (Lnet/minecraft/entity/passive/EntityVillager$PriceInfo;Ljava/lang/String;Lnet/minecraft/world/storage/MapDecoration$Type;)V - -
 method public addMerchantRecipe (Lnet/minecraft/entity/IMerchant;Lnet/minecraft/village/MerchantRecipeList;Ljava/util/Random;)V - -
in 24
class net/minecraft/entity/passive/EntityWaterMob 50 public,super,abstract net/minecraft/entity/EntityLiving net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public canBreatheUnderwater ()Z - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public onEntityUpdate ()V - -
 method public isPushedByWater ()Z - -
in 326
class net/minecraft/entity/passive/EntityWaterMob 52 public,super,abstract net/minecraft/entity/EntityLiving net/minecraft/entity/passive/IAnimals -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public canBreatheUnderwater ()Z - -
 method public getCanSpawnHere ()Z - -
 method public isNotColliding ()Z - -
 method public getTalkInterval ()I - -
 method protected canDespawn ()Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method public onEntityUpdate ()V - -
 method public isPushedByWater ()Z - -
in 90
class net/minecraft/entity/passive/EntityWolf 50 public,super net/minecraft/entity/passive/EntityTameable - -
 method public isWolfWet ()Z - -
 method public getShadingWhileWet (F)F - -
 method public getShakeAngle (FF)F - -
 method public getInterestedAngle (F)F - -
 method public handleStatusUpdate (B)V - -
 method public getTailRotation ()F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected applyEntityAttributes ()V - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected updateAITasks ()V - -
 method protected entityInit ()V - -
 method protected playStepSound (Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getLivingSound ()Ljava/lang/String; - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method protected getSoundVolume ()F - -
 method protected getDropItem ()Lnet/minecraft/item/Item; - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method public getEyeHeight ()F - -
 method public getVerticalFaceSpeed ()I - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public setTamed (Z)V - -
 method public interact (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getMaxSpawnedInChunk ()I - -
 method public isAngry ()Z - -
 method public setAngry (Z)V - -
 method public getCollarColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public setCollarColor (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityWolf; - -
 method public setBegging (Z)V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public isBegging ()Z - -
 method protected canDespawn ()Z - -
 method public shouldAttackEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public allowLeashing ()Z - -
in 91
class net/minecraft/entity/passive/EntityWolf 50 public,super net/minecraft/entity/passive/EntityTameable - -
 method public isWolfWet ()Z - -
 method public getShadingWhileWet (F)F - -
 method public getShakeAngle (FF)F - -
 method public getInterestedAngle (F)F - -
 method public handleStatusUpdate (B)V - -
 method public getTailRotation ()F - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected updateAITasks ()V - -
 method protected entityInit ()V - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public,static registerFixesWolf (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method public getEyeHeight ()F - -
 method public getVerticalFaceSpeed ()I - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public setTamed (Z)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;Lnet/minecraft/item/ItemStack;)Z - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getMaxSpawnedInChunk ()I - -
 method public isAngry ()Z - -
 method public setAngry (Z)V - -
 method public getCollarColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public setCollarColor (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityWolf; - -
 method public setBegging (Z)V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public isBegging ()Z - -
 method public shouldAttackEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 326
class net/minecraft/entity/passive/EntityWolf 52 public,super net/minecraft/entity/passive/EntityTameable - -
 inner net/minecraft/entity/passive/EntityWolf$AIAvoidEntity net/minecraft/entity/passive/EntityWolf AIAvoidEntity -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected initEntityAI ()V - -
 method protected applyEntityAttributes ()V - -
 method public setAttackTarget (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected updateAITasks ()V - -
 method protected entityInit ()V - -
 method protected playStepSound (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/Block;)V - -
 method public,static registerFixesWolf (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSoundVolume ()F - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public onLivingUpdate ()V - -
 method public onUpdate ()V - -
 method public isWolfWet ()Z - -
 method public getShadingWhileWet (F)F - -
 method public getShakeAngle (FF)F - -
 method public getInterestedAngle (F)F - -
 method public getEyeHeight ()F - -
 method public getVerticalFaceSpeed ()I - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public attackEntityAsMob (Lnet/minecraft/entity/Entity;)Z - -
 method public setTamed (Z)V - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
 method public handleStatusUpdate (B)V - -
 method public getTailRotation ()F - -
 method public isBreedingItem (Lnet/minecraft/item/ItemStack;)Z - -
 method public getMaxSpawnedInChunk ()I - -
 method public isAngry ()Z - -
 method public setAngry (Z)V - -
 method public getCollarColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public setCollarColor (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public createChild (Lnet/minecraft/entity/EntityAgeable;)Lnet/minecraft/entity/passive/EntityWolf; - -
 method public setBegging (Z)V - -
 method public canMateWith (Lnet/minecraft/entity/passive/EntityAnimal;)Z - -
 method public isBegging ()Z - -
 method public shouldAttackEntity (Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;)Z - -
 method public canBeLeashedTo (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 326
class net/minecraft/entity/passive/EntityWolf$AIAvoidEntity 52 super net/minecraft/entity/ai/EntityAIAvoidEntity - <T:Lnet/minecraft/entity/Entity;>Lnet/minecraft/entity/ai/EntityAIAvoidEntity<TT;>;
 inner net/minecraft/entity/passive/EntityWolf$AIAvoidEntity net/minecraft/entity/passive/EntityWolf AIAvoidEntity -
 method public <init> (Lnet/minecraft/entity/passive/EntityWolf;Lnet/minecraft/entity/passive/EntityWolf;Ljava/lang/Class;FDD)V (Lnet/minecraft/entity/passive/EntityWolf;Ljava/lang/Class<TT;>;FDD)V -
 method public shouldExecute ()Z - -
 method public startExecuting ()V - -
 method public updateTask ()V - -
in 326
class net/minecraft/entity/passive/EntityZombieHorse 52 public,super net/minecraft/entity/passive/AbstractHorse - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public,static registerFixesZombieHorse (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected applyEntityAttributes ()V - -
 method public getCreatureAttribute ()Lnet/minecraft/entity/EnumCreatureAttribute; - -
 method protected getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public processInteract (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/util/EnumHand;)Z - -
in 91
class net/minecraft/entity/passive/HorseArmorType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/passive/HorseArmorType;>;
 field public,static,final,enum NONE Lnet/minecraft/entity/passive/HorseArmorType; -
 field public,static,final,enum IRON Lnet/minecraft/entity/passive/HorseArmorType; -
 field public,static,final,enum GOLD Lnet/minecraft/entity/passive/HorseArmorType; -
 field public,static,final,enum DIAMOND Lnet/minecraft/entity/passive/HorseArmorType; -
 method public getHash ()Ljava/lang/String; - -
 method public getTextureName ()Ljava/lang/String; - -
 method public,static values ()[Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public getOrdinal ()I - -
 method public getProtection ()I - -
 method public,static getByOrdinal (I)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static getByItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static getByItem (Lnet/minecraft/item/Item;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static isHorseArmor (Lnet/minecraft/item/Item;)Z - -
in 326
class net/minecraft/entity/passive/HorseArmorType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/passive/HorseArmorType;>;
 field public,static,final,enum NONE Lnet/minecraft/entity/passive/HorseArmorType; -
 field public,static,final,enum IRON Lnet/minecraft/entity/passive/HorseArmorType; -
 field public,static,final,enum GOLD Lnet/minecraft/entity/passive/HorseArmorType; -
 field public,static,final,enum DIAMOND Lnet/minecraft/entity/passive/HorseArmorType; -
 method public,static values ()[Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public getOrdinal ()I - -
 method public getHash ()Ljava/lang/String; - -
 method public getProtection ()I - -
 method public getTextureName ()Ljava/lang/String; - -
 method public,static,deprecated getByOrdinal (I)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static getByItemStack (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static,deprecated getByItem (Lnet/minecraft/item/Item;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static,deprecated isHorseArmor (Lnet/minecraft/item/Item;)Z - -
 method public,static getByName (Ljava/lang/String;)Lnet/minecraft/entity/passive/HorseArmorType; - -
 method public,static isHorseArmor (Lnet/minecraft/item/ItemStack;)Z - -
in 91
class net/minecraft/entity/passive/HorseType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/passive/HorseType;>;
 field public,static,final,enum HORSE Lnet/minecraft/entity/passive/HorseType; -
 field public,static,final,enum DONKEY Lnet/minecraft/entity/passive/HorseType; -
 field public,static,final,enum MULE Lnet/minecraft/entity/passive/HorseType; -
 field public,static,final,enum ZOMBIE Lnet/minecraft/entity/passive/HorseType; -
 field public,static,final,enum SKELETON Lnet/minecraft/entity/passive/HorseType; -
 method public getTexture ()Lnet/minecraft/util/ResourceLocation; - -
 method public,static values ()[Lnet/minecraft/entity/passive/HorseType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/passive/HorseType; - -
 method public getAmbientSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getDefaultName ()Lnet/minecraft/util/text/TextComponentTranslation; - -
 method public canBeChested ()Z - -
 method public hasMuleEars ()Z - -
 method public isUndead ()Z - -
 method public canMate ()Z - -
 method public isHorse ()Z - -
 method public getOrdinal ()I - -
 method public,static getArmorType (I)Lnet/minecraft/entity/passive/HorseType; - -
 method public getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
in 24
class net/minecraft/entity/passive/IAnimals 50 public,interface,abstract java/lang/Object - -
in 326
class net/minecraft/entity/passive/IAnimals 52 public,interface,abstract java/lang/Object - -
in 90
class net/minecraft/entity/player/EntityPlayer 50 public,super,abstract net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/entity/player/EntityPlayer$EnumStatus net/minecraft/entity/player/EntityPlayer EnumStatus public,static,final,enum
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/world/WorldSettings$GameType net/minecraft/world/WorldSettings GameType public,static,final,enum
 inner net/minecraftforge/common/ISpecialArmor$ArmorProperties net/minecraftforge/common/ISpecialArmor ArmorProperties public,static
 inner net/minecraft/event/ClickEvent$Action net/minecraft/event/ClickEvent Action public,static,final,enum
 field public,static,final PERSISTED_NBT_TAG Ljava/lang/String; - "PlayerPersisted"
 field public eyeHeight F -
 field public inventory Lnet/minecraft/entity/player/InventoryPlayer; -
 field public inventoryContainer Lnet/minecraft/inventory/Container; -
 field public openContainer Lnet/minecraft/inventory/Container; -
 field protected foodStats Lnet/minecraft/util/FoodStats; -
 field protected flyToggleTimer I -
 field public prevCameraYaw F -
 field public cameraYaw F -
 field public xpCooldown I -
 field public prevChasingPosX D -
 field public prevChasingPosY D -
 field public prevChasingPosZ D -
 field public chasingPosX D -
 field public chasingPosY D -
 field public chasingPosZ D -
 field protected sleeping Z -
 field public playerLocation Lnet/minecraft/util/BlockPos; -
 field public renderOffsetX F -
 field public renderOffsetY F -
 field public renderOffsetZ F -
 field public capabilities Lnet/minecraft/entity/player/PlayerCapabilities; -
 field public experienceLevel I -
 field public experienceTotal I -
 field public experience F -
 field protected speedOnGround F -
 field protected speedInAir F -
 field public fishEntity Lnet/minecraft/entity/projectile/EntityFishHook; -
 method public <init> (Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public getItemInUse ()Lnet/minecraft/item/ItemStack; - -
 method public getItemInUseCount ()I - -
 method public isUsingItem ()Z - -
 method public getItemInUseDuration ()I - -
 method public stopUsingItem ()V - -
 method public clearItemInUse ()V - -
 method public isBlocking ()Z - -
 method public onUpdate ()V - -
 method public getMaxInPortalTime ()I - -
 method protected getSwimSound ()Ljava/lang/String; - -
 method protected getSplashSound ()Ljava/lang/String; - -
 method public getPortalCooldown ()I - -
 method public playSound (Ljava/lang/String;FF)V - -
 method protected updateItemUse (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onItemUseFinish ()V - -
 method public handleStatusUpdate (B)V - -
 method protected isMovementBlocked ()Z - -
 method public closeScreen ()V - -
 method public updateRidden ()V - -
 method public preparePlayerToSpawn ()V - -
 method protected updateEntityActionState ()V - -
 method public onLivingUpdate ()V - -
 method public getScore ()I - -
 method public setScore (I)V - -
 method public addScore (I)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected getHurtSound ()Ljava/lang/String; - -
 method protected getDeathSound ()Ljava/lang/String; - -
 method public addToPlayerScore (Lnet/minecraft/entity/Entity;I)V - -
 method public dropOneItem (Z)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropPlayerItemWithRandomChoice (Lnet/minecraft/item/ItemStack;Z)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItem (Lnet/minecraft/item/ItemStack;ZZ)Lnet/minecraft/entity/item/EntityItem; - -
 method public joinEntityItemWithWorld (Lnet/minecraft/entity/item/EntityItem;)V - -
 method public,deprecated getToolDigEfficiency (Lnet/minecraft/block/Block;)F - -
 method public getBreakSpeed (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/BlockPos;)F - -
 method public canHarvestBlock (Lnet/minecraft/block/Block;)Z - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canAttackPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected damageArmor (F)V - -
 method public getTotalArmorValue ()I - -
 method public getArmorVisibility ()F - -
 method protected damageEntity (Lnet/minecraft/util/DamageSource;F)V - -
 method public openEditSign (Lnet/minecraft/tileentity/TileEntitySign;)V - -
 method public openEditCommandBlock (Lnet/minecraft/command/server/CommandBlockLogic;)V - -
 method public displayVillagerTradeGui (Lnet/minecraft/entity/IMerchant;)V - -
 method public displayGUIChest (Lnet/minecraft/inventory/IInventory;)V - -
 method public displayGUIHorse (Lnet/minecraft/entity/passive/EntityHorse;Lnet/minecraft/inventory/IInventory;)V - -
 method public displayGui (Lnet/minecraft/world/IInteractionObject;)V - -
 method public displayGUIBook (Lnet/minecraft/item/ItemStack;)V - -
 method public interactWith (Lnet/minecraft/entity/Entity;)Z - -
 method public getCurrentEquippedItem ()Lnet/minecraft/item/ItemStack; - -
 method public destroyCurrentEquippedItem ()V - -
 method public getYOffset ()D - -
 method public attackTargetEntityWithCurrentItem (Lnet/minecraft/entity/Entity;)V - -
 method public onCriticalHit (Lnet/minecraft/entity/Entity;)V - -
 method public onEnchantmentCritical (Lnet/minecraft/entity/Entity;)V - -
 method public respawnPlayer ()V - -
 method public setDead ()V - -
 method public isEntityInsideOpaqueBlock ()Z - -
 method public isUser ()Z - -
 method public getGameProfile ()Lcom/mojang/authlib/GameProfile; - -
 method public trySleep (Lnet/minecraft/util/BlockPos;)Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; - -
 method public wakeUpPlayer (ZZZ)V - -
 method public,static getBedSpawnLocation (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Z)Lnet/minecraft/util/BlockPos; - -
 method public getBedOrientationInDegrees ()F - -
 method public isPlayerSleeping ()Z - -
 method public isPlayerFullyAsleep ()Z - -
 method public getSleepTimer ()I - -
 method public addChatComponentMessage (Lnet/minecraft/util/IChatComponent;)V - -
 method public getBedLocation ()Lnet/minecraft/util/BlockPos; - -
 method public,deprecated isSpawnForced ()Z - -
 method public setSpawnPoint (Lnet/minecraft/util/BlockPos;Z)V - -
 method public triggerAchievement (Lnet/minecraft/stats/StatBase;)V - -
 method public addStat (Lnet/minecraft/stats/StatBase;I)V - -
 method public func_175145_a (Lnet/minecraft/stats/StatBase;)V - -
 method public jump ()V - -
 method public moveEntityWithHeading (FF)V - -
 method public getAIMoveSpeed ()F - -
 method public addMovementStat (DDD)V - -
 method public fall (FF)V - -
 method protected resetHeight ()V - -
 method protected getFallSoundString (I)Ljava/lang/String; - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public setInWeb ()V - -
 method public getCurrentArmor (I)Lnet/minecraft/item/ItemStack; - -
 method public addExperience (I)V - -
 method public getXPSeed ()I - -
 method public removeExperienceLevel (I)V - -
 method public addExperienceLevel (I)V - -
 method public xpBarCap ()I - -
 method public addExhaustion (F)V - -
 method public getFoodStats ()Lnet/minecraft/util/FoodStats; - -
 method public canEat (Z)Z - -
 method public shouldHeal ()Z - -
 method public setItemInUse (Lnet/minecraft/item/ItemStack;I)V - -
 method public isAllowEdit ()Z - -
 method public canPlayerEdit (Lnet/minecraft/util/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/item/ItemStack;)Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method protected isPlayer ()Z - -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method public clonePlayer (Lnet/minecraft/entity/player/EntityPlayer;Z)V - -
 method protected canTriggerWalking ()Z - -
 method public sendPlayerAbilities ()V - -
 method public setGameType (Lnet/minecraft/world/WorldSettings$GameType;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getInventoryEnderChest ()Lnet/minecraft/inventory/InventoryEnderChest; - -
 method public getEquipmentInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getHeldItem ()Lnet/minecraft/item/ItemStack; - -
 method public setCurrentItemOrArmor (ILnet/minecraft/item/ItemStack;)V - -
 method public isInvisibleToPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract isSpectator ()Z - -
 method public getInventory ()[Lnet/minecraft/item/ItemStack; - -
 method public isPushedByWater ()Z - -
 method public getWorldScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public getEyeHeight ()F - -
 method public setAbsorptionAmount (F)V - -
 method public getAbsorptionAmount ()F - -
 method public,static getUUID (Lcom/mojang/authlib/GameProfile;)Ljava/util/UUID; - -
 method public,static getOfflineUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public canOpen (Lnet/minecraft/world/LockCode;)Z - -
 method public isWearing (Lnet/minecraft/entity/player/EnumPlayerModelParts;)Z - -
 method public sendCommandFeedback ()Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public hasReducedDebug ()Z - -
 method public setReducedDebug (Z)V - -
 method public openGui (Ljava/lang/Object;ILnet/minecraft/world/World;III)V - -
 method public getBedLocation (I)Lnet/minecraft/util/BlockPos; - -
 method public isSpawnForced (I)Z - -
 method public setSpawnChunk (Lnet/minecraft/util/BlockPos;ZI)V - -
 method public getDefaultEyeHeight ()F - -
 method public getDisplayNameString ()Ljava/lang/String; - -
 method public refreshDisplayName ()V - -
 method public addPrefix (Lnet/minecraft/util/IChatComponent;)V - -
 method public addSuffix (Lnet/minecraft/util/IChatComponent;)V - -
 method public getPrefixes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/util/IChatComponent;>; -
 method public getSuffixes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/util/IChatComponent;>; -
in 91
class net/minecraft/entity/player/EntityPlayer 50 public,super,abstract net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/entity/player/EntityPlayer$SleepResult net/minecraft/entity/player/EntityPlayer SleepResult public,static,final,enum
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraftforge/common/ISpecialArmor$ArmorProperties net/minecraftforge/common/ISpecialArmor ArmorProperties public,static
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 inner net/minecraft/util/text/event/ClickEvent$Action net/minecraft/util/text/event/ClickEvent Action public,static,final,enum
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 field public,static,final PERSISTED_NBT_TAG Ljava/lang/String; - "PlayerPersisted"
 field public eyeHeight F -
 field protected,static,final PLAYER_MODEL_FLAG Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field protected,static,final MAIN_HAND Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field public inventory Lnet/minecraft/entity/player/InventoryPlayer; -
 field public inventoryContainer Lnet/minecraft/inventory/Container; -
 field public openContainer Lnet/minecraft/inventory/Container; -
 field protected foodStats Lnet/minecraft/util/FoodStats; -
 field protected flyToggleTimer I -
 field public prevCameraYaw F -
 field public cameraYaw F -
 field public xpCooldown I -
 field public prevChasingPosX D -
 field public prevChasingPosY D -
 field public prevChasingPosZ D -
 field public chasingPosX D -
 field public chasingPosY D -
 field public chasingPosZ D -
 field protected sleeping Z -
 field public bedLocation Lnet/minecraft/util/math/BlockPos; -
 field public renderOffsetX F -
 field public renderOffsetY F -
 field public renderOffsetZ F -
 field public capabilities Lnet/minecraft/entity/player/PlayerCapabilities; -
 field public experienceLevel I -
 field public experienceTotal I -
 field public experience F -
 field protected speedOnGround F -
 field protected speedInAir F -
 field public fishEntity Lnet/minecraft/entity/projectile/EntityFishHook; -
 method protected createCooldownTracker ()Lnet/minecraft/util/CooldownTracker; - -
 method public <init> (Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected updateSize ()V - -
 method public getMaxInPortalTime ()I - -
 method protected getSwimSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSplashSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getPortalCooldown ()I - -
 method public playSound (Lnet/minecraft/util/SoundEvent;FF)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public handleStatusUpdate (B)V - -
 method protected isMovementBlocked ()Z - -
 method public closeScreen ()V - -
 method public updateRidden ()V - -
 method public preparePlayerToSpawn ()V - -
 method protected updateEntityActionState ()V - -
 method public onLivingUpdate ()V - -
 method public getScore ()I - -
 method public setScore (I)V - -
 method public addScore (I)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected getHurtSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public addToPlayerScore (Lnet/minecraft/entity/Entity;I)V - -
 method public dropItem (Z)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItem (Lnet/minecraft/item/ItemStack;Z)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItem (Lnet/minecraft/item/ItemStack;ZZ)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItemAndGetStack (Lnet/minecraft/entity/item/EntityItem;)Lnet/minecraft/item/ItemStack; - -
 method public,deprecated getDigSpeed (Lnet/minecraft/block/state/IBlockState;)F - -
 method public getDigSpeed (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)F - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public,static registerFixesPlayer (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canAttackPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected damageArmor (F)V - -
 method protected damageShield (F)V - -
 method public getArmorVisibility ()F - -
 method protected damageEntity (Lnet/minecraft/util/DamageSource;F)V - -
 method public openEditSign (Lnet/minecraft/tileentity/TileEntitySign;)V - -
 method public displayGuiEditCommandCart (Lnet/minecraft/tileentity/CommandBlockBaseLogic;)V - -
 method public displayGuiCommandBlock (Lnet/minecraft/tileentity/TileEntityCommandBlock;)V - -
 method public openEditStructure (Lnet/minecraft/tileentity/TileEntityStructure;)V - -
 method public displayVillagerTradeGui (Lnet/minecraft/entity/IMerchant;)V - -
 method public displayGUIChest (Lnet/minecraft/inventory/IInventory;)V - -
 method public openGuiHorseInventory (Lnet/minecraft/entity/passive/EntityHorse;Lnet/minecraft/inventory/IInventory;)V - -
 method public displayGui (Lnet/minecraft/world/IInteractionObject;)V - -
 method public openBook (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)V - -
 method public interact (Lnet/minecraft/entity/Entity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method public getYOffset ()D - -
 method public dismountRidingEntity ()V - -
 method public attackTargetEntityWithCurrentItem (Lnet/minecraft/entity/Entity;)V - -
 method public onCriticalHit (Lnet/minecraft/entity/Entity;)V - -
 method public onEnchantmentCritical (Lnet/minecraft/entity/Entity;)V - -
 method public spawnSweepParticles ()V - -
 method public respawnPlayer ()V - -
 method public setDead ()V - -
 method public isEntityInsideOpaqueBlock ()Z - -
 method public isUser ()Z - -
 method public getGameProfile ()Lcom/mojang/authlib/GameProfile; - -
 method public trySleep (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
 method public wakeUpPlayer (ZZZ)V - -
 method public,static getBedSpawnLocation (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Z)Lnet/minecraft/util/math/BlockPos; - -
 method public getBedOrientationInDegrees ()F - -
 method public isPlayerSleeping ()Z - -
 method public isPlayerFullyAsleep ()Z - -
 method public getSleepTimer ()I - -
 method public sendStatusMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public getBedLocation ()Lnet/minecraft/util/math/BlockPos; - -
 method public,deprecated isSpawnForced ()Z - -
 method public setSpawnPoint (Lnet/minecraft/util/math/BlockPos;Z)V - -
 method public hasAchievement (Lnet/minecraft/stats/Achievement;)Z - -
 method public addStat (Lnet/minecraft/stats/StatBase;)V - -
 method public addStat (Lnet/minecraft/stats/StatBase;I)V - -
 method public takeStat (Lnet/minecraft/stats/StatBase;)V - -
 method public jump ()V - -
 method public moveEntityWithHeading (FF)V - -
 method public getAIMoveSpeed ()F - -
 method public addMovementStat (DDD)V - -
 method public fall (FF)V - -
 method protected resetHeight ()V - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public setInWeb ()V - -
 method public addExperience (I)V - -
 method public getXPSeed ()I - -
 method public removeExperienceLevel (I)V - -
 method public addExperienceLevel (I)V - -
 method public xpBarCap ()I - -
 method public addExhaustion (F)V - -
 method public getFoodStats ()Lnet/minecraft/util/FoodStats; - -
 method public canEat (Z)Z - -
 method public shouldHeal ()Z - -
 method public isAllowEdit ()Z - -
 method public canPlayerEdit (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/item/ItemStack;)Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method protected isPlayer ()Z - -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method public clonePlayer (Lnet/minecraft/entity/player/EntityPlayer;Z)V - -
 method protected canTriggerWalking ()Z - -
 method public sendPlayerAbilities ()V - -
 method public setGameType (Lnet/minecraft/world/GameType;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getInventoryEnderChest ()Lnet/minecraft/inventory/InventoryEnderChest; - -
 method public getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public isInvisibleToPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract isSpectator ()Z - -
 method public,abstract isCreative ()Z - -
 method public isPushedByWater ()Z - -
 method public getWorldScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getEyeHeight ()F - -
 method public setAbsorptionAmount (F)V - -
 method public getAbsorptionAmount ()F - -
 method public,static getUUID (Lcom/mojang/authlib/GameProfile;)Ljava/util/UUID; - -
 method public,static getOfflineUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public canOpen (Lnet/minecraft/world/LockCode;)Z - -
 method public isWearing (Lnet/minecraft/entity/player/EnumPlayerModelParts;)Z - -
 method public sendCommandFeedback ()Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public hasReducedDebug ()Z - -
 method public setReducedDebug (Z)V - -
 method public getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
 method public setPrimaryHand (Lnet/minecraft/util/EnumHandSide;)V - -
 method public getCooldownPeriod ()F - -
 method public getCooledAttackStrength (F)F - -
 method public resetCooldown ()V - -
 method public getCooldownTracker ()Lnet/minecraft/util/CooldownTracker; - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public getLuck ()F - -
 method public canUseCommandBlock ()Z - -
 method public openGui (Ljava/lang/Object;ILnet/minecraft/world/World;III)V - -
 method public getBedLocation (I)Lnet/minecraft/util/math/BlockPos; - -
 method public isSpawnForced (I)Z - -
 method public setSpawnChunk (Lnet/minecraft/util/math/BlockPos;ZI)V - -
 method public getDefaultEyeHeight ()F - -
 method public getDisplayNameString ()Ljava/lang/String; - -
 method public refreshDisplayName ()V - -
 method public addPrefix (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public addSuffix (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public getPrefixes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/util/text/ITextComponent;>; -
 method public getSuffixes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/util/text/ITextComponent;>; -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 326
class net/minecraft/entity/player/EntityPlayer 52 public,super,abstract net/minecraft/entity/EntityLivingBase - -
 inner net/minecraft/entity/player/EntityPlayer$SleepResult net/minecraft/entity/player/EntityPlayer SleepResult public,static,final,enum
 inner net/minecraft/entity/player/EntityPlayer$SleepEnemyPredicate net/minecraft/entity/player/EntityPlayer SleepEnemyPredicate static
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraftforge/common/ISpecialArmor$ArmorProperties net/minecraftforge/common/ISpecialArmor ArmorProperties public,static
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 inner net/minecraft/util/text/event/ClickEvent$Action net/minecraft/util/text/event/ClickEvent Action public,static,final,enum
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 field public,static,final PERSISTED_NBT_TAG Ljava/lang/String; - "PlayerPersisted"
 field protected spawnChunkMap Ljava/util/HashMap; Ljava/util/HashMap<Ljava/lang/Integer;Lnet/minecraft/util/math/BlockPos;>;
 field protected spawnForcedMap Ljava/util/HashMap; Ljava/util/HashMap<Ljava/lang/Integer;Ljava/lang/Boolean;>;
 field public eyeHeight F -
 field public,static,final REACH_DISTANCE Lnet/minecraft/entity/ai/attributes/IAttribute; -
 field protected,static,final PLAYER_MODEL_FLAG Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field protected,static,final MAIN_HAND Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Ljava/lang/Byte;>;
 field protected,static,final LEFT_SHOULDER_ENTITY Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/nbt/NBTTagCompound;>;
 field protected,static,final RIGHT_SHOULDER_ENTITY Lnet/minecraft/network/datasync/DataParameter; Lnet/minecraft/network/datasync/DataParameter<Lnet/minecraft/nbt/NBTTagCompound;>;
 field public inventory Lnet/minecraft/entity/player/InventoryPlayer; -
 field protected enderChest Lnet/minecraft/inventory/InventoryEnderChest; -
 field public inventoryContainer Lnet/minecraft/inventory/Container; -
 field public openContainer Lnet/minecraft/inventory/Container; -
 field protected foodStats Lnet/minecraft/util/FoodStats; -
 field protected flyToggleTimer I -
 field public prevCameraYaw F -
 field public cameraYaw F -
 field public xpCooldown I -
 field public prevChasingPosX D -
 field public prevChasingPosY D -
 field public prevChasingPosZ D -
 field public chasingPosX D -
 field public chasingPosY D -
 field public chasingPosZ D -
 field protected sleeping Z -
 field public bedLocation Lnet/minecraft/util/math/BlockPos; -
 field public renderOffsetX F -
 field public renderOffsetY F -
 field public renderOffsetZ F -
 field protected spawnPos Lnet/minecraft/util/math/BlockPos; -
 field protected spawnForced Z -
 field public capabilities Lnet/minecraft/entity/player/PlayerCapabilities; -
 field public experienceLevel I -
 field public experienceTotal I -
 field public experience F -
 field protected xpSeed I -
 field protected speedInAir F -
 field public fishEntity Lnet/minecraft/entity/projectile/EntityFishHook; -
 method protected createCooldownTracker ()Lnet/minecraft/util/CooldownTracker; - -
 method public <init> (Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V - -
 method protected applyEntityAttributes ()V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method protected updateSize ()V - -
 method public getMaxInPortalTime ()I - -
 method protected getSwimSound ()Lnet/minecraft/util/SoundEvent; - -
 method protected getSplashSound ()Lnet/minecraft/util/SoundEvent; - -
 method public getPortalCooldown ()I - -
 method public playSound (Lnet/minecraft/util/SoundEvent;FF)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method protected getFireImmuneTicks ()I - -
 method public handleStatusUpdate (B)V - -
 method protected isMovementBlocked ()Z - -
 method public closeScreen ()V - -
 method public updateRidden ()V - -
 method public preparePlayerToSpawn ()V - -
 method protected updateEntityActionState ()V - -
 method public onLivingUpdate ()V - -
 method public getScore ()I - -
 method public setScore (I)V - -
 method public addScore (I)V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method protected destroyVanishingCursedItems ()V - -
 method protected getHurtSound (Lnet/minecraft/util/DamageSource;)Lnet/minecraft/util/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/util/SoundEvent; - -
 method public dropItem (Z)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItem (Lnet/minecraft/item/ItemStack;Z)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItem (Lnet/minecraft/item/ItemStack;ZZ)Lnet/minecraft/entity/item/EntityItem; - -
 method public dropItemAndGetStack (Lnet/minecraft/entity/item/EntityItem;)Lnet/minecraft/item/ItemStack; - -
 method public,deprecated getDigSpeed (Lnet/minecraft/block/state/IBlockState;)F - -
 method public getDigSpeed (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)F - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public,static registerFixesPlayer (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected blockUsingShield (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public canAttackPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected damageArmor (F)V - -
 method protected damageShield (F)V - -
 method public getArmorVisibility ()F - -
 method protected damageEntity (Lnet/minecraft/util/DamageSource;F)V - -
 method public openEditSign (Lnet/minecraft/tileentity/TileEntitySign;)V - -
 method public displayGuiEditCommandCart (Lnet/minecraft/tileentity/CommandBlockBaseLogic;)V - -
 method public displayGuiCommandBlock (Lnet/minecraft/tileentity/TileEntityCommandBlock;)V - -
 method public openEditStructure (Lnet/minecraft/tileentity/TileEntityStructure;)V - -
 method public displayVillagerTradeGui (Lnet/minecraft/entity/IMerchant;)V - -
 method public displayGUIChest (Lnet/minecraft/inventory/IInventory;)V - -
 method public openGuiHorseInventory (Lnet/minecraft/entity/passive/AbstractHorse;Lnet/minecraft/inventory/IInventory;)V - -
 method public displayGui (Lnet/minecraft/world/IInteractionObject;)V - -
 method public openBook (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)V - -
 method public interactOn (Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult; - -
 method public getYOffset ()D - -
 method public dismountRidingEntity ()V - -
 method public attackTargetEntityWithCurrentItem (Lnet/minecraft/entity/Entity;)V - -
 method public disableShield (Z)V - -
 method public onCriticalHit (Lnet/minecraft/entity/Entity;)V - -
 method public onEnchantmentCritical (Lnet/minecraft/entity/Entity;)V - -
 method public spawnSweepParticles ()V - -
 method public respawnPlayer ()V - -
 method public setDead ()V - -
 method public isEntityInsideOpaqueBlock ()Z - -
 method public isUser ()Z - -
 method public getGameProfile ()Lcom/mojang/authlib/GameProfile; - -
 method public trySleep (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
 method public wakeUpPlayer (ZZZ)V - -
 method public,static getBedSpawnLocation (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Z)Lnet/minecraft/util/math/BlockPos; - -
 method public getBedOrientationInDegrees ()F - -
 method public isPlayerSleeping ()Z - -
 method public isPlayerFullyAsleep ()Z - -
 method public getSleepTimer ()I - -
 method public sendStatusMessage (Lnet/minecraft/util/text/ITextComponent;Z)V - -
 method public getBedLocation ()Lnet/minecraft/util/math/BlockPos; - -
 method public,deprecated isSpawnForced ()Z - -
 method public setSpawnPoint (Lnet/minecraft/util/math/BlockPos;Z)V - -
 method public addStat (Lnet/minecraft/stats/StatBase;)V - -
 method public addStat (Lnet/minecraft/stats/StatBase;I)V - -
 method public takeStat (Lnet/minecraft/stats/StatBase;)V - -
 method public unlockRecipes (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>;)V -
 method public unlockRecipes ([Lnet/minecraft/util/ResourceLocation;)V - -
 method public resetRecipes (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>;)V -
 method public jump ()V - -
 method public travel (FFF)V - -
 method public getAIMoveSpeed ()F - -
 method public addMovementStat (DDD)V - -
 method public fall (FF)V - -
 method protected doWaterSplashEffect ()V - -
 method protected getFallSound (I)Lnet/minecraft/util/SoundEvent; - -
 method public onKillEntity (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public setInWeb ()V - -
 method public addExperience (I)V - -
 method public getXPSeed ()I - -
 method public onEnchant (Lnet/minecraft/item/ItemStack;I)V - -
 method public addExperienceLevel (I)V - -
 method public xpBarCap ()I - -
 method public addExhaustion (F)V - -
 method public getFoodStats ()Lnet/minecraft/util/FoodStats; - -
 method public canEat (Z)Z - -
 method public shouldHeal ()Z - -
 method public isAllowEdit ()Z - -
 method public canPlayerEdit (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/item/ItemStack;)Z - -
 method protected getExperiencePoints (Lnet/minecraft/entity/player/EntityPlayer;)I - -
 method protected isPlayer ()Z - -
 method public getAlwaysRenderNameTagForRender ()Z - -
 method protected canTriggerWalking ()Z - -
 method public sendPlayerAbilities ()V - -
 method public setGameType (Lnet/minecraft/world/GameType;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getInventoryEnderChest ()Lnet/minecraft/inventory/InventoryEnderChest; - -
 method public getItemStackFromSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;)Lnet/minecraft/item/ItemStack; - -
 method public setItemStackToSlot (Lnet/minecraft/inventory/EntityEquipmentSlot;Lnet/minecraft/item/ItemStack;)V - -
 method public addItemStackToInventory (Lnet/minecraft/item/ItemStack;)Z - -
 method public getHeldEquipment ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public getArmorInventoryList ()Ljava/lang/Iterable; ()Ljava/lang/Iterable<Lnet/minecraft/item/ItemStack;>; -
 method public addShoulderEntity (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method protected spawnShoulderEntities ()V - -
 method public isInvisibleToPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract isSpectator ()Z - -
 method public,abstract isCreative ()Z - -
 method public isPushedByWater ()Z - -
 method public getWorldScoreboard ()Lnet/minecraft/scoreboard/Scoreboard; - -
 method public getTeam ()Lnet/minecraft/scoreboard/Team; - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getEyeHeight ()F - -
 method public setAbsorptionAmount (F)V - -
 method public getAbsorptionAmount ()F - -
 method public,static getUUID (Lcom/mojang/authlib/GameProfile;)Ljava/util/UUID; - -
 method public,static getOfflineUUID (Ljava/lang/String;)Ljava/util/UUID; - -
 method public canOpen (Lnet/minecraft/world/LockCode;)Z - -
 method public isWearing (Lnet/minecraft/entity/player/EnumPlayerModelParts;)Z - -
 method public sendCommandFeedback ()Z - -
 method public replaceItemInInventory (ILnet/minecraft/item/ItemStack;)Z - -
 method public hasReducedDebug ()Z - -
 method public setReducedDebug (Z)V - -
 method public getPrimaryHand ()Lnet/minecraft/util/EnumHandSide; - -
 method public setPrimaryHand (Lnet/minecraft/util/EnumHandSide;)V - -
 method public getLeftShoulderEntity ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method protected setLeftShoulderEntity (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getRightShoulderEntity ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method protected setRightShoulderEntity (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getCooldownPeriod ()F - -
 method public getCooledAttackStrength (F)F - -
 method public resetCooldown ()V - -
 method public getCooldownTracker ()Lnet/minecraft/util/CooldownTracker; - -
 method public applyEntityCollision (Lnet/minecraft/entity/Entity;)V - -
 method public getLuck ()F - -
 method public canUseCommandBlock ()Z - -
 method public openGui (Ljava/lang/Object;ILnet/minecraft/world/World;III)V - -
 method public getBedLocation (I)Lnet/minecraft/util/math/BlockPos; - -
 method public isSpawnForced (I)Z - -
 method public setSpawnChunk (Lnet/minecraft/util/math/BlockPos;ZI)V - -
 method public getDefaultEyeHeight ()F - -
 method public getDisplayNameString ()Ljava/lang/String; - -
 method public refreshDisplayName ()V - -
 method public addPrefix (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public addSuffix (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public getPrefixes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/util/text/ITextComponent;>; -
 method public getSuffixes ()Ljava/util/Collection; ()Ljava/util/Collection<Lnet/minecraft/util/text/ITextComponent;>; -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public hasSpawnDimension ()Z - -
 method public getSpawnDimension ()I - -
 method public setSpawnDimension (Ljava/lang/Integer;)V - -
in 24
class net/minecraft/entity/player/EntityPlayer$EnumChatVisibility 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility;>;
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 field public,static,final,enum FULL Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; -
 field public,static,final,enum SYSTEM Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; -
 field public,static,final,enum HIDDEN Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; -
 method public,static values ()[Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public getChatVisibility ()I - -
 method public,static getEnumChatVisibility (I)Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public getResourceKey ()Ljava/lang/String; - -
in 326
class net/minecraft/entity/player/EntityPlayer$EnumChatVisibility 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility;>;
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 field public,static,final,enum FULL Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; -
 field public,static,final,enum SYSTEM Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; -
 field public,static,final,enum HIDDEN Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; -
 method public,static values ()[Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public getChatVisibility ()I - -
 method public,static getEnumChatVisibility (I)Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public getResourceKey ()Ljava/lang/String; - -
in 90
class net/minecraft/entity/player/EntityPlayer$EnumStatus 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EntityPlayer$EnumStatus;>;
 inner net/minecraft/entity/player/EntityPlayer$EnumStatus net/minecraft/entity/player/EntityPlayer EnumStatus public,static,final,enum
 field public,static,final,enum OK Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; -
 field public,static,final,enum NOT_POSSIBLE_HERE Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; -
 field public,static,final,enum NOT_POSSIBLE_NOW Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; -
 field public,static,final,enum TOO_FAR_AWAY Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; -
 field public,static,final,enum OTHER_PROBLEM Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; -
 field public,static,final,enum NOT_SAFE Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; -
 method public,static values ()[Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; - -
in 326
class net/minecraft/entity/player/EntityPlayer$SleepEnemyPredicate 52 super java/lang/Object com/google/common/base/Predicate Ljava/lang/Object;Lcom/google/common/base/Predicate<Lnet/minecraft/entity/monster/EntityMob;>;
 inner net/minecraft/entity/player/EntityPlayer$SleepEnemyPredicate net/minecraft/entity/player/EntityPlayer SleepEnemyPredicate static
 method public apply (Lnet/minecraft/entity/monster/EntityMob;)Z - -
in 91
class net/minecraft/entity/player/EntityPlayer$SleepResult 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EntityPlayer$SleepResult;>;
 inner net/minecraft/entity/player/EntityPlayer$SleepResult net/minecraft/entity/player/EntityPlayer SleepResult public,static,final,enum
 field public,static,final,enum OK Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum NOT_POSSIBLE_HERE Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum NOT_POSSIBLE_NOW Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum TOO_FAR_AWAY Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum OTHER_PROBLEM Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum NOT_SAFE Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 method public,static values ()[Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
in 326
class net/minecraft/entity/player/EntityPlayer$SleepResult 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EntityPlayer$SleepResult;>;
 inner net/minecraft/entity/player/EntityPlayer$SleepResult net/minecraft/entity/player/EntityPlayer SleepResult public,static,final,enum
 field public,static,final,enum OK Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum NOT_POSSIBLE_HERE Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum NOT_POSSIBLE_NOW Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum TOO_FAR_AWAY Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum OTHER_PROBLEM Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 field public,static,final,enum NOT_SAFE Lnet/minecraft/entity/player/EntityPlayer$SleepResult; -
 method public,static values ()[Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
in 90
class net/minecraft/entity/player/EntityPlayerMP 50 public,super net/minecraft/entity/player/EntityPlayer net/minecraft/inventory/ICrafting -
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/entity/player/EntityPlayer$EnumStatus net/minecraft/entity/player/EntityPlayer EnumStatus public,static,final,enum
 inner net/minecraft/world/WorldSettings$GameType net/minecraft/world/WorldSettings GameType public,static,final,enum
 inner net/minecraftforge/event/world/ChunkWatchEvent$Watch net/minecraftforge/event/world/ChunkWatchEvent Watch public,static
 inner net/minecraft/network/play/server/S42PacketCombatEvent$Event net/minecraft/network/play/server/S42PacketCombatEvent Event public,static,final,enum
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 field public playerNetServerHandler Lnet/minecraft/network/NetHandlerPlayServer; -
 field public,final mcServer Lnet/minecraft/server/MinecraftServer; -
 field public,final theItemInWorldManager Lnet/minecraft/server/management/ItemInWorldManager; -
 field public managedPosX D -
 field public managedPosZ D -
 field public,final loadedChunks Ljava/util/List; Ljava/util/List<Lnet/minecraft/world/ChunkCoordIntPair;>;
 field public currentWindowId I -
 field public isChangingQuantityOnly Z -
 field public ping I -
 field public playerConqueredTheEnd Z -
 method public <init> (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/world/WorldServer;Lcom/mojang/authlib/GameProfile;Lnet/minecraft/server/management/ItemInWorldManager;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public addExperienceLevel (I)V - -
 method public removeExperienceLevel (I)V - -
 method public addSelfToInternalCraftingInventory ()V - -
 method public sendEnterCombat ()V - -
 method public sendEndCombat ()V - -
 method public onUpdate ()V - -
 method public onUpdateEntity ()V - -
 method protected updateBiomesExplored ()V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canAttackPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public travelToDimension (I)V - -
 method public isSpectatedByPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public onItemPickup (Lnet/minecraft/entity/Entity;I)V - -
 method public trySleep (Lnet/minecraft/util/BlockPos;)Lnet/minecraft/entity/player/EntityPlayer$EnumStatus; - -
 method public wakeUpPlayer (ZZZ)V - -
 method public mountEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected updateFallState (DZLnet/minecraft/block/Block;Lnet/minecraft/util/BlockPos;)V - -
 method public handleFalling (DZ)V - -
 method public openEditSign (Lnet/minecraft/tileentity/TileEntitySign;)V - -
 method public getNextWindowId ()V - -
 method public displayGui (Lnet/minecraft/world/IInteractionObject;)V - -
 method public displayGUIChest (Lnet/minecraft/inventory/IInventory;)V - -
 method public displayVillagerTradeGui (Lnet/minecraft/entity/IMerchant;)V - -
 method public displayGUIHorse (Lnet/minecraft/entity/passive/EntityHorse;Lnet/minecraft/inventory/IInventory;)V - -
 method public displayGUIBook (Lnet/minecraft/item/ItemStack;)V - -
 method public sendSlotContents (Lnet/minecraft/inventory/Container;ILnet/minecraft/item/ItemStack;)V - -
 method public sendContainerToPlayer (Lnet/minecraft/inventory/Container;)V - -
 method public updateCraftingInventory (Lnet/minecraft/inventory/Container;Ljava/util/List;)V (Lnet/minecraft/inventory/Container;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public sendProgressBarUpdate (Lnet/minecraft/inventory/Container;II)V - -
 method public sendAllWindowProperties (Lnet/minecraft/inventory/Container;Lnet/minecraft/inventory/IInventory;)V - -
 method public closeScreen ()V - -
 method public updateHeldItem ()V - -
 method public closeContainer ()V - -
 method public setEntityActionState (FFZZ)V - -
 method public addStat (Lnet/minecraft/stats/StatBase;I)V - -
 method public func_175145_a (Lnet/minecraft/stats/StatBase;)V - -
 method public mountEntityAndWakeUp ()V - -
 method public setPlayerHealthUpdated ()V - -
 method public addChatComponentMessage (Lnet/minecraft/util/IChatComponent;)V - -
 method protected onItemUseFinish ()V - -
 method public setItemInUse (Lnet/minecraft/item/ItemStack;I)V - -
 method public clonePlayer (Lnet/minecraft/entity/player/EntityPlayer;Z)V - -
 method protected onNewPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected onChangedPotionEffect (Lnet/minecraft/potion/PotionEffect;Z)V - -
 method protected onFinishedPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public setPositionAndUpdate (DDD)V - -
 method public onCriticalHit (Lnet/minecraft/entity/Entity;)V - -
 method public onEnchantmentCritical (Lnet/minecraft/entity/Entity;)V - -
 method public sendPlayerAbilities ()V - -
 method public getServerForPlayer ()Lnet/minecraft/world/WorldServer; - -
 method public setGameType (Lnet/minecraft/world/WorldSettings$GameType;)V - -
 method public isSpectator ()Z - -
 method public addChatMessage (Lnet/minecraft/util/IChatComponent;)V - -
 method public canCommandSenderUseCommand (ILjava/lang/String;)Z - -
 method public getPlayerIP ()Ljava/lang/String; - -
 method public handleClientSettings (Lnet/minecraft/network/play/client/C15PacketClientSettings;)V - -
 method public getChatVisibility ()Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public loadResourcePack (Ljava/lang/String;Ljava/lang/String;)V - -
 method public getPosition ()Lnet/minecraft/util/BlockPos; - -
 method public markPlayerActive ()V - -
 method public getStatFile ()Lnet/minecraft/stats/StatisticsFile; - -
 method public removeEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected updatePotionMetadata ()V - -
 method public getSpectatingEntity ()Lnet/minecraft/entity/Entity; - -
 method public setSpectatingEntity (Lnet/minecraft/entity/Entity;)V - -
 method public attackTargetEntityWithCurrentItem (Lnet/minecraft/entity/Entity;)V - -
 method public getLastActiveTime ()J - -
 method public getTabListDisplayName ()Lnet/minecraft/util/IChatComponent; - -
in 91
class net/minecraft/entity/player/EntityPlayerMP 50 public,super net/minecraft/entity/player/EntityPlayer net/minecraft/inventory/IContainerListener -
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/entity/player/EntityPlayer$SleepResult net/minecraft/entity/player/EntityPlayer SleepResult public,static,final,enum
 inner net/minecraftforge/event/entity/player/PlayerContainerEvent$Open net/minecraftforge/event/entity/player/PlayerContainerEvent Open public,static
 inner net/minecraftforge/event/entity/player/PlayerContainerEvent$Close net/minecraftforge/event/entity/player/PlayerContainerEvent Close public,static
 inner net/minecraft/network/play/server/SPacketCombatEvent$Event net/minecraft/network/play/server/SPacketCombatEvent Event public,static,final,enum
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 field public connection Lnet/minecraft/network/NetHandlerPlayServer; -
 field public,final mcServer Lnet/minecraft/server/MinecraftServer; -
 field public,final interactionManager Lnet/minecraft/server/management/PlayerInteractionManager; -
 field public managedPosX D -
 field public managedPosZ D -
 field public currentWindowId I -
 field public isChangingQuantityOnly Z -
 field public ping I -
 field public playerConqueredTheEnd Z -
 method public <init> (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/world/WorldServer;Lcom/mojang/authlib/GameProfile;Lnet/minecraft/server/management/PlayerInteractionManager;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public addExperienceLevel (I)V - -
 method public removeExperienceLevel (I)V - -
 method public addSelfToInternalCraftingInventory ()V - -
 method public sendEnterCombat ()V - -
 method public sendEndCombat ()V - -
 method protected createCooldownTracker ()Lnet/minecraft/util/CooldownTracker; - -
 method public onUpdate ()V - -
 method public onUpdateEntity ()V - -
 method protected updateBiomesExplored ()V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canAttackPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public changeDimension (I)Lnet/minecraft/entity/Entity; - -
 method public isSpectatedByPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public onItemPickup (Lnet/minecraft/entity/Entity;I)V - -
 method public trySleep (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
 method public wakeUpPlayer (ZZZ)V - -
 method public startRiding (Lnet/minecraft/entity/Entity;Z)Z - -
 method public dismountRidingEntity ()V - -
 method public isEntityInvulnerable (Lnet/minecraft/util/DamageSource;)Z - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method protected frostWalk (Lnet/minecraft/util/math/BlockPos;)V - -
 method public handleFalling (DZ)V - -
 method public openEditSign (Lnet/minecraft/tileentity/TileEntitySign;)V - -
 method public getNextWindowId ()V - -
 method public displayGui (Lnet/minecraft/world/IInteractionObject;)V - -
 method public displayGUIChest (Lnet/minecraft/inventory/IInventory;)V - -
 method public displayVillagerTradeGui (Lnet/minecraft/entity/IMerchant;)V - -
 method public openGuiHorseInventory (Lnet/minecraft/entity/passive/EntityHorse;Lnet/minecraft/inventory/IInventory;)V - -
 method public openBook (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)V - -
 method public displayGuiCommandBlock (Lnet/minecraft/tileentity/TileEntityCommandBlock;)V - -
 method public sendSlotContents (Lnet/minecraft/inventory/Container;ILnet/minecraft/item/ItemStack;)V - -
 method public sendContainerToPlayer (Lnet/minecraft/inventory/Container;)V - -
 method public updateCraftingInventory (Lnet/minecraft/inventory/Container;Ljava/util/List;)V (Lnet/minecraft/inventory/Container;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public sendProgressBarUpdate (Lnet/minecraft/inventory/Container;II)V - -
 method public sendAllWindowProperties (Lnet/minecraft/inventory/Container;Lnet/minecraft/inventory/IInventory;)V - -
 method public closeScreen ()V - -
 method public updateHeldItem ()V - -
 method public closeContainer ()V - -
 method public setEntityActionState (FFZZ)V - -
 method public hasAchievement (Lnet/minecraft/stats/Achievement;)Z - -
 method public addStat (Lnet/minecraft/stats/StatBase;I)V - -
 method public takeStat (Lnet/minecraft/stats/StatBase;)V - -
 method public mountEntityAndWakeUp ()V - -
 method public setPlayerHealthUpdated ()V - -
 method public sendStatusMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method protected onItemUseFinish ()V - -
 method public clonePlayer (Lnet/minecraft/entity/player/EntityPlayer;Z)V - -
 method protected onNewPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected onChangedPotionEffect (Lnet/minecraft/potion/PotionEffect;Z)V - -
 method protected onFinishedPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public setPositionAndUpdate (DDD)V - -
 method public onCriticalHit (Lnet/minecraft/entity/Entity;)V - -
 method public onEnchantmentCritical (Lnet/minecraft/entity/Entity;)V - -
 method public sendPlayerAbilities ()V - -
 method public getServerWorld ()Lnet/minecraft/world/WorldServer; - -
 method public setGameType (Lnet/minecraft/world/GameType;)V - -
 method public isSpectator ()Z - -
 method public isCreative ()Z - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public canUseCommand (ILjava/lang/String;)Z - -
 method public getPlayerIP ()Ljava/lang/String; - -
 method public handleClientSettings (Lnet/minecraft/network/play/client/CPacketClientSettings;)V - -
 method public getChatVisibility ()Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public loadResourcePack (Ljava/lang/String;Ljava/lang/String;)V - -
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public markPlayerActive ()V - -
 method public getStatFile ()Lnet/minecraft/stats/StatisticsManagerServer; - -
 method public removeEntity (Lnet/minecraft/entity/Entity;)V - -
 method public addEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected updatePotionMetadata ()V - -
 method public getSpectatingEntity ()Lnet/minecraft/entity/Entity; - -
 method public setSpectatingEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected decrementTimeUntilPortal ()V - -
 method public attackTargetEntityWithCurrentItem (Lnet/minecraft/entity/Entity;)V - -
 method public getLastActiveTime ()J - -
 method public getTabListDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public swingArm (Lnet/minecraft/util/EnumHand;)V - -
 method public isInvulnerableDimensionChange ()Z - -
 method public clearInvulnerableDimensionChange ()V - -
 method public setElytraFlying ()V - -
 method public clearElytraFlying ()V - -
in 326
class net/minecraft/entity/player/EntityPlayerMP 52 public,super net/minecraft/entity/player/EntityPlayer net/minecraft/inventory/IContainerListener -
 inner net/minecraft/entity/player/EntityPlayer$EnumChatVisibility net/minecraft/entity/player/EntityPlayer EnumChatVisibility public,static,final,enum
 inner net/minecraft/entity/EntityList$EntityEggInfo net/minecraft/entity/EntityList EntityEggInfo public,static
 inner net/minecraft/entity/player/EntityPlayer$SleepResult net/minecraft/entity/player/EntityPlayer SleepResult public,static,final,enum
 inner net/minecraftforge/event/entity/player/PlayerContainerEvent$Open net/minecraftforge/event/entity/player/PlayerContainerEvent Open public,static
 inner net/minecraftforge/event/entity/player/PlayerContainerEvent$Close net/minecraftforge/event/entity/player/PlayerContainerEvent Close public,static
 inner net/minecraft/network/play/server/SPacketCombatEvent$Event net/minecraft/network/play/server/SPacketCombatEvent Event public,static,final,enum
 inner net/minecraft/scoreboard/Team$EnumVisible net/minecraft/scoreboard/Team EnumVisible public,static,final,enum
 field public connection Lnet/minecraft/network/NetHandlerPlayServer; -
 field public,final server Lnet/minecraft/server/MinecraftServer; -
 field public,final interactionManager Lnet/minecraft/server/management/PlayerInteractionManager; -
 field public managedPosX D -
 field public managedPosZ D -
 field public currentWindowId I -
 field public isChangingQuantityOnly Z -
 field public ping I -
 field public queuedEndExit Z -
 method public <init> (Lnet/minecraft/server/MinecraftServer;Lnet/minecraft/world/WorldServer;Lcom/mojang/authlib/GameProfile;Lnet/minecraft/server/management/PlayerInteractionManager;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static registerFixesPlayerMP (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public addExperienceLevel (I)V - -
 method public onEnchant (Lnet/minecraft/item/ItemStack;I)V - -
 method public addSelfToInternalCraftingInventory ()V - -
 method public sendEnterCombat ()V - -
 method public sendEndCombat ()V - -
 method protected onInsideBlock (Lnet/minecraft/block/state/IBlockState;)V - -
 method protected createCooldownTracker ()Lnet/minecraft/util/CooldownTracker; - -
 method public onUpdate ()V - -
 method public onUpdateEntity ()V - -
 method public onDeath (Lnet/minecraft/util/DamageSource;)V - -
 method public awardKillScore (Lnet/minecraft/entity/Entity;ILnet/minecraft/util/DamageSource;)V - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public canAttackPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public changeDimension (ILnet/minecraftforge/common/util/ITeleporter;)Lnet/minecraft/entity/Entity; - -
 method public isSpectatedByPlayer (Lnet/minecraft/entity/player/EntityPlayerMP;)Z - -
 method public onItemPickup (Lnet/minecraft/entity/Entity;I)V - -
 method public trySleep (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/entity/player/EntityPlayer$SleepResult; - -
 method public wakeUpPlayer (ZZZ)V - -
 method public startRiding (Lnet/minecraft/entity/Entity;Z)Z - -
 method public dismountRidingEntity ()V - -
 method public isEntityInvulnerable (Lnet/minecraft/util/DamageSource;)Z - -
 method protected updateFallState (DZLnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/math/BlockPos;)V - -
 method protected frostWalk (Lnet/minecraft/util/math/BlockPos;)V - -
 method public handleFalling (DZ)V - -
 method public openEditSign (Lnet/minecraft/tileentity/TileEntitySign;)V - -
 method public getNextWindowId ()V - -
 method public displayGui (Lnet/minecraft/world/IInteractionObject;)V - -
 method public displayGUIChest (Lnet/minecraft/inventory/IInventory;)V - -
 method public displayVillagerTradeGui (Lnet/minecraft/entity/IMerchant;)V - -
 method public openGuiHorseInventory (Lnet/minecraft/entity/passive/AbstractHorse;Lnet/minecraft/inventory/IInventory;)V - -
 method public openBook (Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumHand;)V - -
 method public displayGuiCommandBlock (Lnet/minecraft/tileentity/TileEntityCommandBlock;)V - -
 method public sendSlotContents (Lnet/minecraft/inventory/Container;ILnet/minecraft/item/ItemStack;)V - -
 method public sendContainerToPlayer (Lnet/minecraft/inventory/Container;)V - -
 method public sendAllContents (Lnet/minecraft/inventory/Container;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/inventory/Container;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public sendWindowProperty (Lnet/minecraft/inventory/Container;II)V - -
 method public sendAllWindowProperties (Lnet/minecraft/inventory/Container;Lnet/minecraft/inventory/IInventory;)V - -
 method public closeScreen ()V - -
 method public updateHeldItem ()V - -
 method public closeContainer ()V - -
 method public setEntityActionState (FFZZ)V - -
 method public addStat (Lnet/minecraft/stats/StatBase;I)V - -
 method public takeStat (Lnet/minecraft/stats/StatBase;)V - -
 method public unlockRecipes (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>;)V -
 method public unlockRecipes ([Lnet/minecraft/util/ResourceLocation;)V - -
 method public resetRecipes (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/crafting/IRecipe;>;)V -
 method public mountEntityAndWakeUp ()V - -
 method public hasDisconnected ()Z - -
 method public setPlayerHealthUpdated ()V - -
 method public sendStatusMessage (Lnet/minecraft/util/text/ITextComponent;Z)V - -
 method protected onItemUseFinish ()V - -
 method public copyFrom (Lnet/minecraft/entity/player/EntityPlayerMP;Z)V - -
 method protected onNewPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected onChangedPotionEffect (Lnet/minecraft/potion/PotionEffect;Z)V - -
 method protected onFinishedPotionEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method public setPositionAndUpdate (DDD)V - -
 method public onCriticalHit (Lnet/minecraft/entity/Entity;)V - -
 method public onEnchantmentCritical (Lnet/minecraft/entity/Entity;)V - -
 method public sendPlayerAbilities ()V - -
 method public getServerWorld ()Lnet/minecraft/world/WorldServer; - -
 method public setGameType (Lnet/minecraft/world/GameType;)V - -
 method public isSpectator ()Z - -
 method public isCreative ()Z - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public canUseCommand (ILjava/lang/String;)Z - -
 method public getPlayerIP ()Ljava/lang/String; - -
 method public handleClientSettings (Lnet/minecraft/network/play/client/CPacketClientSettings;)V - -
 method public getChatVisibility ()Lnet/minecraft/entity/player/EntityPlayer$EnumChatVisibility; - -
 method public loadResourcePack (Ljava/lang/String;Ljava/lang/String;)V - -
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public markPlayerActive ()V - -
 method public getStatFile ()Lnet/minecraft/stats/StatisticsManagerServer; - -
 method public getRecipeBook ()Lnet/minecraft/stats/RecipeBookServer; - -
 method public removeEntity (Lnet/minecraft/entity/Entity;)V - -
 method public addEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected updatePotionMetadata ()V - -
 method public getSpectatingEntity ()Lnet/minecraft/entity/Entity; - -
 method public setSpectatingEntity (Lnet/minecraft/entity/Entity;)V - -
 method protected decrementTimeUntilPortal ()V - -
 method public attackTargetEntityWithCurrentItem (Lnet/minecraft/entity/Entity;)V - -
 method public getLastActiveTime ()J - -
 method public getTabListDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public swingArm (Lnet/minecraft/util/EnumHand;)V - -
 method public isInvulnerableDimensionChange ()Z - -
 method public clearInvulnerableDimensionChange ()V - -
 method public setElytraFlying ()V - -
 method public clearElytraFlying ()V - -
 method public getAdvancements ()Lnet/minecraft/advancements/PlayerAdvancements; - -
 method public getEnteredNetherPosition ()Lnet/minecraft/util/math/Vec3d; - -
in 90
class net/minecraft/entity/player/EnumPlayerModelParts 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EnumPlayerModelParts;>;
 field public,static,final,enum CAPE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum JACKET Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum LEFT_SLEEVE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum RIGHT_SLEEVE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum LEFT_PANTS_LEG Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum RIGHT_PANTS_LEG Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum HAT Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 method public,static values ()[Lnet/minecraft/entity/player/EnumPlayerModelParts; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EnumPlayerModelParts; - -
 method public getPartMask ()I - -
 method public getPartId ()I - -
 method public getPartName ()Ljava/lang/String; - -
 method public func_179326_d ()Lnet/minecraft/util/IChatComponent; - -
in 91
class net/minecraft/entity/player/EnumPlayerModelParts 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EnumPlayerModelParts;>;
 field public,static,final,enum CAPE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum JACKET Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum LEFT_SLEEVE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum RIGHT_SLEEVE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum LEFT_PANTS_LEG Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum RIGHT_PANTS_LEG Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum HAT Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 method public,static values ()[Lnet/minecraft/entity/player/EnumPlayerModelParts; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EnumPlayerModelParts; - -
 method public getPartMask ()I - -
 method public getPartId ()I - -
 method public getPartName ()Ljava/lang/String; - -
 method public getName ()Lnet/minecraft/util/text/ITextComponent; - -
in 326
class net/minecraft/entity/player/EnumPlayerModelParts 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/player/EnumPlayerModelParts;>;
 field public,static,final,enum CAPE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum JACKET Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum LEFT_SLEEVE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum RIGHT_SLEEVE Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum LEFT_PANTS_LEG Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum RIGHT_PANTS_LEG Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 field public,static,final,enum HAT Lnet/minecraft/entity/player/EnumPlayerModelParts; -
 method public,static values ()[Lnet/minecraft/entity/player/EnumPlayerModelParts; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/player/EnumPlayerModelParts; - -
 method public getPartMask ()I - -
 method public getPartId ()I - -
 method public getPartName ()Ljava/lang/String; - -
 method public getName ()Lnet/minecraft/util/text/ITextComponent; - -
in 90
class net/minecraft/entity/player/InventoryPlayer 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 field public mainInventory [Lnet/minecraft/item/ItemStack; -
 field public armorInventory [Lnet/minecraft/item/ItemStack; -
 field public currentItem I -
 field public player Lnet/minecraft/entity/player/EntityPlayer; -
 field public inventoryChanged Z -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCurrentItem ()Lnet/minecraft/item/ItemStack; - -
 method public,static getHotbarSize ()I - -
 method public getFirstEmptyStack ()I - -
 method public setCurrentItem (Lnet/minecraft/item/Item;IZZ)V - -
 method public clearMatchingItems (Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)I - -
 method public changeCurrentItem (I)V - -
 method public decrementAnimations ()V - -
 method public consumeInventoryItem (Lnet/minecraft/item/Item;)Z - -
 method public hasItem (Lnet/minecraft/item/Item;)Z - -
 method public addItemStackToInventory (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getStrVsBlock (Lnet/minecraft/block/Block;)F - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagList;)Lnet/minecraft/nbt/NBTTagList; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public getInventoryStackLimit ()I - -
 method public canHeldItemHarvest (Lnet/minecraft/block/Block;)Z - -
 method public armorItemInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getTotalArmorValue ()I - -
 method public damageArmor (F)V - -
 method public dropAllItems ()V - -
 method public markDirty ()V - -
 method public setItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public getItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public hasItemStack (Lnet/minecraft/item/ItemStack;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public copyInventory (Lnet/minecraft/entity/player/InventoryPlayer;)V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 91
class net/minecraft/entity/player/InventoryPlayer 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 field public,final mainInventory [Lnet/minecraft/item/ItemStack; -
 field public,final armorInventory [Lnet/minecraft/item/ItemStack; -
 field public,final offHandInventory [Lnet/minecraft/item/ItemStack; -
 field public currentItem I -
 field public player Lnet/minecraft/entity/player/EntityPlayer; -
 field public inventoryChanged Z -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCurrentItem ()Lnet/minecraft/item/ItemStack; - -
 method public,static getHotbarSize ()I - -
 method public getFirstEmptyStack ()I - -
 method public setPickedItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public pickItem (I)V - -
 method public,static isHotbar (I)Z - -
 method public getSlotFor (Lnet/minecraft/item/ItemStack;)I - -
 method public getBestHotbarSlot ()I - -
 method public changeCurrentItem (I)V - -
 method public clearMatchingItems (Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)I - -
 method public decrementAnimations ()V - -
 method public addItemStackToInventory (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public deleteStack (Lnet/minecraft/item/ItemStack;)V - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getStrVsBlock (Lnet/minecraft/block/state/IBlockState;)F - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagList;)Lnet/minecraft/nbt/NBTTagList; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getInventoryStackLimit ()I - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public armorItemInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public damageArmor (F)V - -
 method public dropAllItems ()V - -
 method public markDirty ()V - -
 method public setItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public getItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public hasItemStack (Lnet/minecraft/item/ItemStack;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public copyInventory (Lnet/minecraft/entity/player/InventoryPlayer;)V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 326
class net/minecraft/entity/player/InventoryPlayer 52 public,super java/lang/Object net/minecraft/inventory/IInventory -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final mainInventory Lnet/minecraft/util/NonNullList; Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;
 field public,final armorInventory Lnet/minecraft/util/NonNullList; Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;
 field public,final offHandInventory Lnet/minecraft/util/NonNullList; Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;
 field public currentItem I -
 field public player Lnet/minecraft/entity/player/EntityPlayer; -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCurrentItem ()Lnet/minecraft/item/ItemStack; - -
 method public,static getHotbarSize ()I - -
 method public getFirstEmptyStack ()I - -
 method public setPickedItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public pickItem (I)V - -
 method public,static isHotbar (I)Z - -
 method public getSlotFor (Lnet/minecraft/item/ItemStack;)I - -
 method public findSlotMatchingUnusedItem (Lnet/minecraft/item/ItemStack;)I - -
 method public getBestHotbarSlot ()I - -
 method public changeCurrentItem (I)V - -
 method public clearMatchingItems (Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)I - -
 method public storeItemStack (Lnet/minecraft/item/ItemStack;)I - -
 method public decrementAnimations ()V - -
 method public addItemStackToInventory (Lnet/minecraft/item/ItemStack;)Z - -
 method public add (ILnet/minecraft/item/ItemStack;)Z - -
 method public placeItemBackInInventory (Lnet/minecraft/world/World;Lnet/minecraft/item/ItemStack;)V - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public deleteStack (Lnet/minecraft/item/ItemStack;)V - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getDestroySpeed (Lnet/minecraft/block/state/IBlockState;)F - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagList;)Lnet/minecraft/nbt/NBTTagList; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getInventoryStackLimit ()I - -
 method public canHarvestBlock (Lnet/minecraft/block/state/IBlockState;)Z - -
 method public armorItemInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public damageArmor (F)V - -
 method public dropAllItems ()V - -
 method public markDirty ()V - -
 method public getTimesChanged ()I - -
 method public setItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public getItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public hasItemStack (Lnet/minecraft/item/ItemStack;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public copyInventory (Lnet/minecraft/entity/player/InventoryPlayer;)V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public fillStackedContents (Lnet/minecraft/client/util/RecipeItemHelper;Z)V - -
in 24
class net/minecraft/entity/player/PlayerCapabilities 50 public,super java/lang/Object - -
 field public disableDamage Z -
 field public isFlying Z -
 field public allowFlying Z -
 field public isCreativeMode Z -
 field public allowEdit Z -
 method public setFlySpeed (F)V - -
 method public setPlayerWalkSpeed (F)V - -
 method public <init> ()V - -
 method public writeCapabilitiesToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readCapabilitiesFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getFlySpeed ()F - -
 method public getWalkSpeed ()F - -
in 326
class net/minecraft/entity/player/PlayerCapabilities 52 public,super java/lang/Object - -
 field public disableDamage Z -
 field public isFlying Z -
 field public allowFlying Z -
 field public isCreativeMode Z -
 field public allowEdit Z -
 method public <init> ()V - -
 method public writeCapabilitiesToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readCapabilitiesFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getFlySpeed ()F - -
 method public setFlySpeed (F)V - -
 method public getWalkSpeed ()F - -
 method public setPlayerWalkSpeed (F)V - -
in 90
class net/minecraft/entity/projectile/EntityArrow 50 public,super net/minecraft/entity/Entity net/minecraft/entity/IProjectile -
 field public canBePickedUp I -
 field public arrowShake I -
 field public shootingEntity Lnet/minecraft/entity/Entity; -
 method public setPositionAndRotation2 (DDDFFIZ)V - -
 method public setVelocity (DDD)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/EntityLivingBase;FF)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;F)V - -
 method protected entityInit ()V - -
 method public setThrowableHeading (DDDFF)V - -
 method public onUpdate ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected canTriggerWalking ()Z - -
 method public setDamage (D)V - -
 method public getDamage ()D - -
 method public setKnockbackStrength (I)V - -
 method public canAttackWithItem ()Z - -
 method public getEyeHeight ()F - -
 method public setIsCritical (Z)V - -
 method public getIsCritical ()Z - -
in 91
class net/minecraft/entity/projectile/EntityArrow 50 public,super,abstract net/minecraft/entity/Entity net/minecraft/entity/IProjectile -
 inner net/minecraft/entity/projectile/EntityArrow$PickupStatus net/minecraft/entity/projectile/EntityArrow PickupStatus public,static,final,enum
 field protected inGround Z -
 field protected timeInGround I -
 field public pickupStatus Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 field public arrowShake I -
 field public shootingEntity Lnet/minecraft/entity/Entity; -
 method public isInRangeToRenderDist (D)Z - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public setVelocity (DDD)V - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method public setAim (Lnet/minecraft/entity/Entity;FFFFF)V - -
 method public setThrowableHeading (DDDFF)V - -
 method public onUpdate ()V - -
 method protected onHit (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method protected arrowHit (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected findEntityOnPath (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/entity/Entity; - -
 method public,static registerFixesArrow (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method public,static registerFixesArrow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected,abstract getArrowStack ()Lnet/minecraft/item/ItemStack; - -
 method protected canTriggerWalking ()Z - -
 method public setDamage (D)V - -
 method public getDamage ()D - -
 method public setKnockbackStrength (I)V - -
 method public canBeAttackedWithItem ()Z - -
 method public getEyeHeight ()F - -
 method public setIsCritical (Z)V - -
 method public getIsCritical ()Z - -
in 326
class net/minecraft/entity/projectile/EntityArrow 52 public,super,abstract net/minecraft/entity/Entity net/minecraft/entity/IProjectile -
 inner net/minecraft/entity/projectile/EntityArrow$PickupStatus net/minecraft/entity/projectile/EntityArrow PickupStatus public,static,final,enum
 field protected inGround Z -
 field protected timeInGround I -
 field public pickupStatus Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 field public arrowShake I -
 field public shootingEntity Lnet/minecraft/entity/Entity; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public isInRangeToRenderDist (D)Z - -
 method protected entityInit ()V - -
 method public shoot (Lnet/minecraft/entity/Entity;FFFFF)V - -
 method public shoot (DDDFF)V - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public setVelocity (DDD)V - -
 method public onUpdate ()V - -
 method protected onHit (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public move (Lnet/minecraft/entity/MoverType;DDD)V - -
 method protected arrowHit (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected findEntityOnPath (Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/entity/Entity; - -
 method public,static registerFixesArrow (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method public,static registerFixesArrow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onCollideWithPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected,abstract getArrowStack ()Lnet/minecraft/item/ItemStack; - -
 method protected canTriggerWalking ()Z - -
 method public setDamage (D)V - -
 method public getDamage ()D - -
 method public setKnockbackStrength (I)V - -
 method public canBeAttackedWithItem ()Z - -
 method public getEyeHeight ()F - -
 method public setIsCritical (Z)V - -
 method public getIsCritical ()Z - -
 method public setEnchantmentEffectsFromEntity (Lnet/minecraft/entity/EntityLivingBase;F)V - -
in 91
class net/minecraft/entity/projectile/EntityArrow$PickupStatus 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus;>;
 inner net/minecraft/entity/projectile/EntityArrow$PickupStatus net/minecraft/entity/projectile/EntityArrow PickupStatus public,static,final,enum
 field public,static,final,enum DISALLOWED Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 field public,static,final,enum ALLOWED Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 field public,static,final,enum CREATIVE_ONLY Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 method public,static values ()[Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; - -
 method public,static getByOrdinal (I)Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; - -
in 326
class net/minecraft/entity/projectile/EntityArrow$PickupStatus 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus;>;
 inner net/minecraft/entity/projectile/EntityArrow$PickupStatus net/minecraft/entity/projectile/EntityArrow PickupStatus public,static,final,enum
 field public,static,final,enum DISALLOWED Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 field public,static,final,enum ALLOWED Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 field public,static,final,enum CREATIVE_ONLY Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; -
 method public,static values ()[Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; - -
 method public,static getByOrdinal (I)Lnet/minecraft/entity/projectile/EntityArrow$PickupStatus; - -
in 91
class net/minecraft/entity/projectile/EntityDragonFireball 50 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public,static registerFixesDragonFireball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected isFireballFiery ()Z - -
in 326
class net/minecraft/entity/projectile/EntityDragonFireball 52 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public,static registerFixesDragonFireball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected isFireballFiery ()Z - -
in 90
class net/minecraft/entity/projectile/EntityEgg 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
in 91
class net/minecraft/entity/projectile/EntityEgg 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesEgg (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
in 326
class net/minecraft/entity/projectile/EntityEgg 52 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesEgg (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public handleStatusUpdate (B)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
in 326
class net/minecraft/entity/projectile/EntityEvokerFangs 52 public,super net/minecraft/entity/Entity - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDFILnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method public setCaster (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getCaster ()Lnet/minecraft/entity/EntityLivingBase; - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onUpdate ()V - -
 method public handleStatusUpdate (B)V - -
 method public getAnimationProgress (F)F - -
in 90
class net/minecraft/entity/projectile/EntityFireball 50 public,super,abstract net/minecraft/entity/Entity - -
 field public shootingEntity Lnet/minecraft/entity/EntityLivingBase; -
 field public accelerationX D -
 field public accelerationY D -
 field public accelerationZ D -
 method public isInRangeToRenderDist (D)Z - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public onUpdate ()V - -
 method protected getMotionFactor ()F - -
 method protected,abstract onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public getCollisionBorderSize ()F - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getBrightness (F)F - -
in 91
class net/minecraft/entity/projectile/EntityFireball 50 public,super,abstract net/minecraft/entity/Entity - -
 field public shootingEntity Lnet/minecraft/entity/EntityLivingBase; -
 field public accelerationX D -
 field public accelerationY D -
 field public accelerationZ D -
 method public isInRangeToRenderDist (D)Z - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public onUpdate ()V - -
 method protected isFireballFiery ()Z - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected getMotionFactor ()F - -
 method protected,abstract onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesFireball (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public getCollisionBorderSize ()F - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getBrightness (F)F - -
in 326
class net/minecraft/entity/projectile/EntityFireball 52 public,super,abstract net/minecraft/entity/Entity - -
 field public shootingEntity Lnet/minecraft/entity/EntityLivingBase; -
 field public accelerationX D -
 field public accelerationY D -
 field public accelerationZ D -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public isInRangeToRenderDist (D)Z - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public onUpdate ()V - -
 method protected isFireballFiery ()Z - -
 method protected getParticleType ()Lnet/minecraft/util/EnumParticleTypes; - -
 method protected getMotionFactor ()F - -
 method protected,abstract onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesFireball (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canBeCollidedWith ()Z - -
 method public getCollisionBorderSize ()F - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method public getBrightness ()F - -
 method public getBrightnessForRender ()I - -
in 90
class net/minecraft/entity/projectile/EntityFishHook 50 public,super net/minecraft/entity/Entity - -
 inner net/minecraftforge/common/FishingHooks$FishableCategory net/minecraftforge/common/FishingHooks FishableCategory public,static,final,enum
 inner net/minecraft/item/ItemFishFood$FishType net/minecraft/item/ItemFishFood FishType public,static,final,enum
 field public,static,final JUNK Ljava/util/List; Ljava/util/List<Lnet/minecraft/util/WeightedRandomFishable;>;
 field public,static,final TREASURE Ljava/util/List; Ljava/util/List<Lnet/minecraft/util/WeightedRandomFishable;>;
 field public,static,final FISH Ljava/util/List; Ljava/util/List<Lnet/minecraft/util/WeightedRandomFishable;>;
 field public shake I -
 field public angler Lnet/minecraft/entity/player/EntityPlayer; -
 field public caughtEntity Lnet/minecraft/entity/Entity; -
 method public,static func_174855_j ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/util/WeightedRandomFishable;>; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/player/EntityPlayer;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected entityInit ()V - -
 method public isInRangeToRenderDist (D)Z - -
 method public handleHookCasting (DDDFF)V - -
 method public setPositionAndRotation2 (DDDFFIZ)V - -
 method public setVelocity (DDD)V - -
 method public onUpdate ()V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public handleHookRetraction ()I - -
 method public setDead ()V - -
in 91
class net/minecraft/entity/projectile/EntityFishHook 50 public,super net/minecraft/entity/Entity - -
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 field public angler Lnet/minecraft/entity/player/EntityPlayer; -
 field public caughtEntity Lnet/minecraft/entity/Entity; -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isInRangeToRenderDist (D)Z - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public setVelocity (DDD)V - -
 method public handleStatusUpdate (B)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected entityInit ()V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public handleHookCasting (DDDFF)V - -
 method public onUpdate ()V - -
 method protected canBeHooked (Lnet/minecraft/entity/Entity;)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public handleHookRetraction ()I - -
 method protected bringInHookedEntity ()V - -
 method public setDead ()V - -
in 326
class net/minecraft/entity/projectile/EntityFishHook 52 public,super net/minecraft/entity/Entity - -
 inner net/minecraft/entity/projectile/EntityFishHook$State net/minecraft/entity/projectile/EntityFishHook State static,final,enum
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 field public caughtEntity Lnet/minecraft/entity/Entity; -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public setLureSpeed (I)V - -
 method public setLuck (I)V - -
 method protected entityInit ()V - -
 method public notifyDataManagerChange (Lnet/minecraft/network/datasync/DataParameter;)V (Lnet/minecraft/network/datasync/DataParameter<*>;)V -
 method public isInRangeToRenderDist (D)Z - -
 method public setPositionAndRotationDirect (DDDFFIZ)V - -
 method public onUpdate ()V - -
 method protected canBeHooked (Lnet/minecraft/entity/Entity;)Z - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public handleHookRetraction ()I - -
 method public handleStatusUpdate (B)V - -
 method protected bringInHookedEntity ()V - -
 method protected canTriggerWalking ()Z - -
 method public setDead ()V - -
 method public getAngler ()Lnet/minecraft/entity/player/EntityPlayer; - -
in 326
class net/minecraft/entity/projectile/EntityFishHook$State 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/entity/projectile/EntityFishHook$State;>;
 inner net/minecraft/entity/projectile/EntityFishHook$State net/minecraft/entity/projectile/EntityFishHook State static,final,enum
 field public,static,final,enum FLYING Lnet/minecraft/entity/projectile/EntityFishHook$State; -
 field public,static,final,enum HOOKED_IN_ENTITY Lnet/minecraft/entity/projectile/EntityFishHook$State; -
 field public,static,final,enum BOBBING Lnet/minecraft/entity/projectile/EntityFishHook$State; -
 method public,static values ()[Lnet/minecraft/entity/projectile/EntityFishHook$State; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/entity/projectile/EntityFishHook$State; - -
in 90
class net/minecraft/entity/projectile/EntityLargeFireball 50 public,super net/minecraft/entity/projectile/EntityFireball - -
 field public explosionPower I -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/entity/projectile/EntityLargeFireball 50 public,super net/minecraft/entity/projectile/EntityFireball - -
 field public explosionPower I -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesLargeFireball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/entity/projectile/EntityLargeFireball 52 public,super net/minecraft/entity/projectile/EntityFireball - -
 field public explosionPower I -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesLargeFireball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/entity/projectile/EntityLlamaSpit 52 public,super net/minecraft/entity/Entity net/minecraft/entity/IProjectile -
 field public owner Lnet/minecraft/entity/passive/EntityLlama; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/passive/EntityLlama;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public onUpdate ()V - -
 method public setVelocity (DDD)V - -
 method public shoot (DDDFF)V - -
 method public onHit (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method protected entityInit ()V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 90
class net/minecraft/entity/projectile/EntityPotion 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;DDDI)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;I)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method protected getGravityVelocity ()F - -
 method protected getVelocity ()F - -
 method protected getInaccuracy ()F - -
 method public setPotionDamage (I)V - -
 method public getPotionDamage ()I - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/entity/projectile/EntityPotion 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 inner net/minecraft/util/EnumFacing$Plane net/minecraft/util/EnumFacing Plane public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method protected entityInit ()V - -
 method public getPotion ()Lnet/minecraft/item/ItemStack; - -
 method public setItem (Lnet/minecraft/item/ItemStack;)V - -
 method protected getGravityVelocity ()F - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesPotion (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/entity/projectile/EntityPotion 52 public,super net/minecraft/entity/projectile/EntityThrowable - -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 inner net/minecraft/util/EnumFacing$Plane net/minecraft/util/EnumFacing Plane public,static,final,enum
 field public,static,final WATER_SENSITIVE Lcom/google/common/base/Predicate; Lcom/google/common/base/Predicate<Lnet/minecraft/entity/EntityLivingBase;>;
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
 method protected entityInit ()V - -
 method public getPotion ()Lnet/minecraft/item/ItemStack; - -
 method public setItem (Lnet/minecraft/item/ItemStack;)V - -
 method protected getGravityVelocity ()F - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesPotion (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/entity/projectile/EntityShulkerBullet 50 public,super net/minecraft/entity/Entity - -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public isInRangeToRenderDist (D)Z - -
 method public getBrightnessForRender (F)I - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumFacing$Axis;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public isBurning ()Z - -
 method public getBrightness (F)F - -
 method protected bulletHit (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
in 326
class net/minecraft/entity/projectile/EntityShulkerBullet 52 public,super net/minecraft/entity/Entity - -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public getSoundCategory ()Lnet/minecraft/util/SoundCategory; - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumFacing$Axis;)V - -
 method protected writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public isBurning ()Z - -
 method public isInRangeToRenderDist (D)Z - -
 method public getBrightness ()F - -
 method public getBrightnessForRender ()I - -
 method protected bulletHit (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
in 90
class net/minecraft/entity/projectile/EntitySmallFireball 50 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
in 91
class net/minecraft/entity/projectile/EntitySmallFireball 50 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public,static registerFixesSmallFireball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
in 326
class net/minecraft/entity/projectile/EntitySmallFireball 52 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public,static registerFixesSmallFireball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
in 90
class net/minecraft/entity/projectile/EntitySnowball 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
in 91
class net/minecraft/entity/projectile/EntitySnowball 50 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesSnowball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
in 326
class net/minecraft/entity/projectile/EntitySnowball 52 public,super net/minecraft/entity/projectile/EntityThrowable - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public,static registerFixesSnowball (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public handleStatusUpdate (B)V - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
in 91
class net/minecraft/entity/projectile/EntitySpectralArrow 50 public,super net/minecraft/entity/projectile/EntityArrow - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public onUpdate ()V - -
 method protected getArrowStack ()Lnet/minecraft/item/ItemStack; - -
 method protected arrowHit (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public,static registerFixesSpectralArrow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 326
class net/minecraft/entity/projectile/EntitySpectralArrow 52 public,super net/minecraft/entity/projectile/EntityArrow - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public onUpdate ()V - -
 method protected getArrowStack ()Lnet/minecraft/item/ItemStack; - -
 method protected arrowHit (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public,static registerFixesSpectralArrow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 90
class net/minecraft/entity/projectile/EntityThrowable 50 public,super,abstract net/minecraft/entity/Entity net/minecraft/entity/IProjectile -
 inner net/minecraft/util/MovingObjectPosition$MovingObjectType net/minecraft/util/MovingObjectPosition MovingObjectType public,static,final,enum
 field protected inGround Z -
 field public throwableShake I -
 method public isInRangeToRenderDist (D)Z - -
 method public setVelocity (DDD)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method protected entityInit ()V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method protected getVelocity ()F - -
 method protected getInaccuracy ()F - -
 method public setThrowableHeading (DDDFF)V - -
 method public onUpdate ()V - -
 method protected getGravityVelocity ()F - -
 method protected,abstract onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getThrower ()Lnet/minecraft/entity/EntityLivingBase; - -
in 91
class net/minecraft/entity/projectile/EntityThrowable 50 public,super,abstract net/minecraft/entity/Entity net/minecraft/entity/IProjectile -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 field protected inGround Z -
 field public throwableShake I -
 field public ignoreEntity Lnet/minecraft/entity/Entity; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method public isInRangeToRenderDist (D)Z - -
 method public setHeadingFromThrower (Lnet/minecraft/entity/Entity;FFFFF)V - -
 method public setThrowableHeading (DDDFF)V - -
 method public setVelocity (DDD)V - -
 method public onUpdate ()V - -
 method protected getGravityVelocity ()F - -
 method protected,abstract onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesThrowable (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getThrower ()Lnet/minecraft/entity/EntityLivingBase; - -
in 326
class net/minecraft/entity/projectile/EntityThrowable 52 public,super,abstract net/minecraft/entity/Entity net/minecraft/entity/IProjectile -
 inner net/minecraft/util/math/RayTraceResult$Type net/minecraft/util/math/RayTraceResult Type public,static,final,enum
 field protected inGround Z -
 field public throwableShake I -
 field protected thrower Lnet/minecraft/entity/EntityLivingBase; -
 field public ignoreEntity Lnet/minecraft/entity/Entity; -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected entityInit ()V - -
 method public isInRangeToRenderDist (D)Z - -
 method public shoot (Lnet/minecraft/entity/Entity;FFFFF)V - -
 method public shoot (DDDFF)V - -
 method public setVelocity (DDD)V - -
 method public onUpdate ()V - -
 method protected getGravityVelocity ()F - -
 method protected,abstract onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public,static registerFixesThrowable (Lnet/minecraft/util/datafix/DataFixer;Ljava/lang/String;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getThrower ()Lnet/minecraft/entity/EntityLivingBase; - -
in 91
class net/minecraft/entity/projectile/EntityTippedArrow 50 public,super net/minecraft/entity/projectile/EntityArrow - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public setPotionEffect (Lnet/minecraft/item/ItemStack;)V - -
 method public addEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public getColor ()I - -
 method public,static registerFixesTippedArrow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected arrowHit (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected getArrowStack ()Lnet/minecraft/item/ItemStack; - -
 method public handleStatusUpdate (B)V - -
in 326
class net/minecraft/entity/projectile/EntityTippedArrow 52 public,super net/minecraft/entity/projectile/EntityArrow - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;DDD)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public setPotionEffect (Lnet/minecraft/item/ItemStack;)V - -
 method public,static getCustomColor (Lnet/minecraft/item/ItemStack;)I - -
 method public addEffect (Lnet/minecraft/potion/PotionEffect;)V - -
 method protected entityInit ()V - -
 method public onUpdate ()V - -
 method public getColor ()I - -
 method public,static registerFixesTippedArrow (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeEntityToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readEntityFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method protected arrowHit (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method protected getArrowStack ()Lnet/minecraft/item/ItemStack; - -
 method public handleStatusUpdate (B)V - -
in 90
class net/minecraft/entity/projectile/EntityWitherSkull 50 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method protected getMotionFactor ()F - -
 method public isBurning ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method protected onImpact (Lnet/minecraft/util/MovingObjectPosition;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected entityInit ()V - -
 method public isInvulnerable ()Z - -
 method public setInvulnerable (Z)V - -
in 91
class net/minecraft/entity/projectile/EntityWitherSkull 50 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public,static registerFixesWitherSkull (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getMotionFactor ()F - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public isBurning ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected entityInit ()V - -
 method public isInvulnerable ()Z - -
 method public setInvulnerable (Z)V - -
 method protected isFireballFiery ()Z - -
in 326
class net/minecraft/entity/projectile/EntityWitherSkull 52 public,super net/minecraft/entity/projectile/EntityFireball - -
 method public <init> (Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/world/World;Lnet/minecraft/entity/EntityLivingBase;DDD)V - -
 method public,static registerFixesWitherSkull (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method protected getMotionFactor ()F - -
 method public <init> (Lnet/minecraft/world/World;DDDDDD)V - -
 method public isBurning ()Z - -
 method public getExplosionResistance (Lnet/minecraft/world/Explosion;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;)F - -
 method protected onImpact (Lnet/minecraft/util/math/RayTraceResult;)V - -
 method public canBeCollidedWith ()Z - -
 method public attackEntityFrom (Lnet/minecraft/util/DamageSource;F)Z - -
 method protected entityInit ()V - -
 method public isInvulnerable ()Z - -
 method public setInvulnerable (Z)V - -
 method protected isFireballFiery ()Z - -
in 91
class net/minecraft/entity/projectile/ProjectileHelper 50 public,final,super java/lang/Object - -
 method public,static forwardsRaycast (Lnet/minecraft/entity/Entity;ZZLnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/RayTraceResult; - -
 method public,static,final rotateTowardsMovement (Lnet/minecraft/entity/Entity;F)V - -
in 326
class net/minecraft/entity/projectile/ProjectileHelper 52 public,final,super java/lang/Object - -
 method public,static forwardsRaycast (Lnet/minecraft/entity/Entity;ZZLnet/minecraft/entity/Entity;)Lnet/minecraft/util/math/RayTraceResult; - -
 method public,static,final rotateTowardsMovement (Lnet/minecraft/entity/Entity;F)V - -
