cg-stub-db 1
in 0
class scala/text/DocBreak 50 public,final,super java/lang/Object - -
 method public,static toString ()Ljava/lang/String; - -
 method public,static hashCode ()I - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static format (ILjava/io/Writer;)V - -
 method public,static $colon$div$colon (Ljava/lang/String;)Lscala/text/Document; - -
 method public,static $colon$div$colon (Lscala/text/Document;)Lscala/text/Document; - -
 method public,static $colon$colon (Ljava/lang/String;)Lscala/text/Document; - -
 method public,static $colon$colon (Lscala/text/Document;)Lscala/text/Document; - -
in 0
class scala/text/DocBreak$ 50 public,final,super,deprecated scala/text/Document scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lscala/text/DocBreak$; -
 method public,static <clinit> ()V - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 0
class scala/text/DocCons 50 public,super,deprecated scala/text/Document scala/Product,scala/Serializable -
 method public,static unapply (Lscala/text/DocCons;)Lscala/Option; (Lscala/text/DocCons;)Lscala/Option<Lscala/Tuple2<Lscala/text/Document;Lscala/text/Document;>;>; -
 method public,static apply (Lscala/text/Document;Lscala/text/Document;)Lscala/text/DocCons; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Lscala/text/Document;Lscala/text/Document;>;Lscala/text/DocCons;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Lscala/text/Document;Lscala/Function1<Lscala/text/Document;Lscala/text/DocCons;>;>; -
 method public hd ()Lscala/text/Document; - -
 method public tl ()Lscala/text/Document; - -
 method public copy (Lscala/text/Document;Lscala/text/Document;)Lscala/text/DocCons; - -
 method public copy$default$1 ()Lscala/text/Document; - -
 method public copy$default$2 ()Lscala/text/Document; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/text/Document;Lscala/text/Document;)V - -
in 0
class scala/text/DocCons$ 50 public,final,super,deprecated scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Lscala/text/Document;Lscala/text/Document;Lscala/text/DocCons;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/text/DocCons$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/text/Document;Lscala/text/Document;)Lscala/text/DocCons; - -
 method public unapply (Lscala/text/DocCons;)Lscala/Option; (Lscala/text/DocCons;)Lscala/Option<Lscala/Tuple2<Lscala/text/Document;Lscala/text/Document;>;>; -
in 0
class scala/text/DocGroup 50 public,super,deprecated scala/text/Document scala/Product,scala/Serializable -
 method public,static unapply (Lscala/text/DocGroup;)Lscala/Option; (Lscala/text/DocGroup;)Lscala/Option<Lscala/text/Document;>; -
 method public,static apply (Lscala/text/Document;)Lscala/text/DocGroup; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/text/DocGroup;TA;>;)Lscala/Function1<Lscala/text/Document;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Lscala/text/Document;>;)Lscala/Function1<TA;Lscala/text/DocGroup;>; -
 method public doc ()Lscala/text/Document; - -
 method public copy (Lscala/text/Document;)Lscala/text/DocGroup; - -
 method public copy$default$1 ()Lscala/text/Document; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Lscala/text/Document;)V - -
in 0
class scala/text/DocGroup$ 50 public,final,super,deprecated scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Lscala/text/Document;Lscala/text/DocGroup;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/text/DocGroup$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Lscala/text/Document;)Lscala/text/DocGroup; - -
 method public unapply (Lscala/text/DocGroup;)Lscala/Option; (Lscala/text/DocGroup;)Lscala/Option<Lscala/text/Document;>; -
in 0
class scala/text/DocNest 50 public,super,deprecated scala/text/Document scala/Product,scala/Serializable -
 method public,static unapply (Lscala/text/DocNest;)Lscala/Option; (Lscala/text/DocNest;)Lscala/Option<Lscala/Tuple2<Ljava/lang/Object;Lscala/text/Document;>;>; -
 method public,static apply (ILscala/text/Document;)Lscala/text/DocNest; - -
 method public,static tupled ()Lscala/Function1; ()Lscala/Function1<Lscala/Tuple2<Ljava/lang/Object;Lscala/text/Document;>;Lscala/text/DocNest;>; -
 method public,static curried ()Lscala/Function1; ()Lscala/Function1<Ljava/lang/Object;Lscala/Function1<Lscala/text/Document;Lscala/text/DocNest;>;>; -
 method public indent ()I - -
 method public doc ()Lscala/text/Document; - -
 method public copy (ILscala/text/Document;)Lscala/text/DocNest; - -
 method public copy$default$1 ()I - -
 method public copy$default$2 ()Lscala/text/Document; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (ILscala/text/Document;)V - -
in 0
class scala/text/DocNest$ 50 public,final,super,deprecated scala/runtime/AbstractFunction2 scala/Serializable Lscala/runtime/AbstractFunction2<Ljava/lang/Object;Lscala/text/Document;Lscala/text/DocNest;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/text/DocNest$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (ILscala/text/Document;)Lscala/text/DocNest; - -
 method public unapply (Lscala/text/DocNest;)Lscala/Option; (Lscala/text/DocNest;)Lscala/Option<Lscala/Tuple2<Ljava/lang/Object;Lscala/text/Document;>;>; -
in 0
class scala/text/DocNil 50 public,final,super java/lang/Object - -
 method public,static toString ()Ljava/lang/String; - -
 method public,static hashCode ()I - -
 method public,static canEqual (Ljava/lang/Object;)Z - -
 method public,static productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public,static productElement (I)Ljava/lang/Object; - -
 method public,static productArity ()I - -
 method public,static productPrefix ()Ljava/lang/String; - -
 method public,static format (ILjava/io/Writer;)V - -
 method public,static $colon$div$colon (Ljava/lang/String;)Lscala/text/Document; - -
 method public,static $colon$div$colon (Lscala/text/Document;)Lscala/text/Document; - -
 method public,static $colon$colon (Ljava/lang/String;)Lscala/text/Document; - -
 method public,static $colon$colon (Lscala/text/Document;)Lscala/text/Document; - -
in 0
class scala/text/DocNil$ 50 public,final,super,deprecated scala/text/Document scala/Product,scala/Serializable -
 field public,static,final MODULE$ Lscala/text/DocNil$; -
 method public,static <clinit> ()V - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
in 0
class scala/text/DocText 50 public,super,deprecated scala/text/Document scala/Product,scala/Serializable -
 method public,static unapply (Lscala/text/DocText;)Lscala/Option; (Lscala/text/DocText;)Lscala/Option<Ljava/lang/String;>; -
 method public,static apply (Ljava/lang/String;)Lscala/text/DocText; - -
 method public,static andThen (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<Lscala/text/DocText;TA;>;)Lscala/Function1<Ljava/lang/String;TA;>; -
 method public,static compose (Lscala/Function1;)Lscala/Function1; <A:Ljava/lang/Object;>(Lscala/Function1<TA;Ljava/lang/String;>;)Lscala/Function1<TA;Lscala/text/DocText;>; -
 method public txt ()Ljava/lang/String; - -
 method public copy (Ljava/lang/String;)Lscala/text/DocText; - -
 method public copy$default$1 ()Ljava/lang/String; - -
 method public productPrefix ()Ljava/lang/String; - -
 method public productArity ()I - -
 method public productElement (I)Ljava/lang/Object; - -
 method public productIterator ()Lscala/collection/Iterator; ()Lscala/collection/Iterator<Ljava/lang/Object;>; -
 method public canEqual (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public toString ()Ljava/lang/String; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public <init> (Ljava/lang/String;)V - -
in 0
class scala/text/DocText$ 50 public,final,super,deprecated scala/runtime/AbstractFunction1 scala/Serializable Lscala/runtime/AbstractFunction1<Ljava/lang/String;Lscala/text/DocText;>;Lscala/Serializable;
 field public,static,final MODULE$ Lscala/text/DocText$; -
 method public,static <clinit> ()V - -
 method public,final toString ()Ljava/lang/String; - -
 method public apply (Ljava/lang/String;)Lscala/text/DocText; - -
 method public unapply (Lscala/text/DocText;)Lscala/Option; (Lscala/text/DocText;)Lscala/Option<Ljava/lang/String;>; -
in 0
class scala/text/Document 50 public,super,abstract,deprecated java/lang/Object - -
 method public,static nest (ILscala/text/Document;)Lscala/text/Document; - -
 method public,static group (Lscala/text/Document;)Lscala/text/Document; - -
 method public,static text (Ljava/lang/String;)Lscala/text/Document; - -
 method public,static break ()Lscala/text/DocBreak$; - -
 method public,static empty ()Lscala/text/DocNil$; - -
 method public $colon$colon (Lscala/text/Document;)Lscala/text/Document; - -
 method public $colon$colon (Ljava/lang/String;)Lscala/text/Document; - -
 method public $colon$div$colon (Lscala/text/Document;)Lscala/text/Document; - -
 method public $colon$div$colon (Ljava/lang/String;)Lscala/text/Document; - -
 method public format (ILjava/io/Writer;)V - -
 method public <init> ()V - -
in 0
class scala/text/Document$ 50 public,final,super,deprecated java/lang/Object - -
 field public,static,final MODULE$ Lscala/text/Document$; -
 method public,static <clinit> ()V - -
 method public empty ()Lscala/text/DocNil$; - -
 method public break ()Lscala/text/DocBreak$; - -
 method public text (Ljava/lang/String;)Lscala/text/Document; - -
 method public group (Lscala/text/Document;)Lscala/text/Document; - -
 method public nest (ILscala/text/Document;)Lscala/text/Document; - -
