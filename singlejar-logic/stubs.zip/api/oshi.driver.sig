cg-stub-db 1
in 290
class oshi/driver/linux/Devicetree 52 public,final,super java/lang/Object - -
 method public,static queryModel ()Ljava/lang/String; - -
in 290
class oshi/driver/linux/Dmidecode 52 public,final,super java/lang/Object - -
 method public,static querySerialNumber ()Ljava/lang/String; - -
 method public,static queryUUID ()Ljava/lang/String; - -
 method public,static queryBiosNameRev ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/String;Ljava/lang/String;>; -
in 290
class oshi/driver/linux/Lshal 52 public,final,super java/lang/Object - -
 method public,static querySerialNumber ()Ljava/lang/String; - -
 method public,static queryUUID ()Ljava/lang/String; - -
in 290
class oshi/driver/linux/Lshw 52 public,final,super java/lang/Object - -
 method public,static queryModel ()Ljava/lang/String; - -
 method public,static querySerialNumber ()Ljava/lang/String; - -
 method public,static queryUUID ()Ljava/lang/String; - -
 method public,static queryCpuCapacity ()J - -
in 290
class oshi/driver/linux/Sysfs 52 public,final,super java/lang/Object - -
 method public,static querySystemVendor ()Ljava/lang/String; - -
 method public,static queryProductModel ()Ljava/lang/String; - -
 method public,static queryProductSerial ()Ljava/lang/String; - -
 method public,static queryUUID ()Ljava/lang/String; - -
 method public,static queryBoardVendor ()Ljava/lang/String; - -
 method public,static queryBoardModel ()Ljava/lang/String; - -
 method public,static queryBoardVersion ()Ljava/lang/String; - -
 method public,static queryBoardSerial ()Ljava/lang/String; - -
 method public,static queryBiosVendor ()Ljava/lang/String; - -
 method public,static queryBiosDescription ()Ljava/lang/String; - -
 method public,static queryBiosVersion (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static queryBiosReleaseDate ()Ljava/lang/String; - -
in 290
class oshi/driver/linux/Who 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/linux/LinuxLibc$LinuxUtmpx oshi/jna/platform/linux/LinuxLibc LinuxUtmpx public,static
 inner oshi/jna/platform/linux/LinuxLibc$Ut_Tv oshi/jna/platform/linux/LinuxLibc Ut_Tv public,static
 method public,static,synchronized queryUtxent ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 39
class oshi/driver/linux/proc/Auxv 52 public,final,super java/lang/Object - -
 field public,static,final AT_PAGESZ I - I6
 field public,static,final AT_HWCAP I - I16
 field public,static,final AT_CLKTCK I - I17
 method public,static queryAuxv ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Long;>; -
in 1184
class oshi/driver/linux/proc/CpuInfo 52 public,final,super java/lang/Object - -
 method public,static queryCpuManufacturer ()Ljava/lang/String; - -
 method public,static queryBoardInfo ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;>; -
in 28
class oshi/driver/linux/proc/CpuInfo 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryCpuManufacturer ()Ljava/lang/String; - -
 method public,static queryBoardInfo ()Loshi/util/tuples/Quartet; ()Loshi/util/tuples/Quartet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;>; -
 method public,static queryFeatureFlags ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
in 290
class oshi/driver/linux/proc/CpuStat 52 public,final,super java/lang/Object - -
 inner oshi/hardware/CentralProcessor$TickType oshi/hardware/CentralProcessor TickType public,static,final,enum
 method public,static getSystemCpuLoadTicks ()[J - -
 method public,static getProcessorCpuLoadTicks (I)[[J - -
 method public,static getContextSwitches ()J - -
 method public,static getInterrupts ()J - -
 method public,static getBootTime ()J - -
in 290
class oshi/driver/linux/proc/DiskStats 52 public,final,super java/lang/Object - -
 inner oshi/driver/linux/proc/DiskStats$IoStat oshi/driver/linux/proc/DiskStats IoStat public,static,final,enum
 method public,static getDiskStats ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/Map<Loshi/driver/linux/proc/DiskStats$IoStat;Ljava/lang/Long;>;>; -
in 290
class oshi/driver/linux/proc/DiskStats$IoStat 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/linux/proc/DiskStats$IoStat;>;
 inner oshi/driver/linux/proc/DiskStats$IoStat oshi/driver/linux/proc/DiskStats IoStat public,static,final,enum
 field public,static,final,enum MAJOR Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum MINOR Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum NAME Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum READS Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum READS_MERGED Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum READS_SECTOR Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum READS_MS Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum WRITES Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum WRITES_MERGED Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum WRITES_SECTOR Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum WRITES_MS Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum IO_QUEUE_LENGTH Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum IO_MS Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum IO_MS_WEIGHTED Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum DISCARDS Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum DISCARDS_MERGED Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum DISCARDS_SECTOR Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum DISCARDS_MS Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum FLUSHES Loshi/driver/linux/proc/DiskStats$IoStat; -
 field public,static,final,enum FLUSHES_MS Loshi/driver/linux/proc/DiskStats$IoStat; -
 method public,static values ()[Loshi/driver/linux/proc/DiskStats$IoStat; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/linux/proc/DiskStats$IoStat; - -
in 1184
class oshi/driver/linux/proc/ProcessStat 52 public,final,super java/lang/Object - -
 inner oshi/driver/linux/proc/ProcessStat$PidStat oshi/driver/linux/proc/ProcessStat PidStat public,static,final,enum
 inner oshi/driver/linux/proc/ProcessStat$PidStatM oshi/driver/linux/proc/ProcessStat PidStatM public,static,final,enum
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final PROC_PID_STAT_LENGTH I -
 method public,static getPidStats (I)Loshi/util/tuples/Triplet; (I)Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/Character;Ljava/util/Map<Loshi/driver/linux/proc/ProcessStat$PidStat;Ljava/lang/Long;>;>; -
 method public,static getPidStatM (I)Ljava/util/Map; (I)Ljava/util/Map<Loshi/driver/linux/proc/ProcessStat$PidStatM;Ljava/lang/Long;>; -
 method public,static getFileDescriptorFiles (I)[Ljava/io/File; - -
 method public,static getPidFiles ()[Ljava/io/File; - -
 method public,static querySocketToPidMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>; -
 method public,static getThreadIds (I)Ljava/util/List; (I)Ljava/util/List<Ljava/lang/Integer;>; -
 method public,static getState (C)Loshi/software/os/OSProcess$State; - -
in 28
class oshi/driver/linux/proc/ProcessStat 52 public,final,super java/lang/Object - -
 inner oshi/driver/linux/proc/ProcessStat$PidStat oshi/driver/linux/proc/ProcessStat PidStat public,static,final,enum
 inner oshi/driver/linux/proc/ProcessStat$PidStatM oshi/driver/linux/proc/ProcessStat PidStatM public,static,final,enum
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final PROC_PID_STAT_LENGTH I -
 method public,static getPidStats (I)Loshi/util/tuples/Triplet; (I)Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/Character;Ljava/util/Map<Loshi/driver/linux/proc/ProcessStat$PidStat;Ljava/lang/Long;>;>; -
 method public,static getPidStatM (I)Ljava/util/Map; (I)Ljava/util/Map<Loshi/driver/linux/proc/ProcessStat$PidStatM;Ljava/lang/Long;>; -
 method public,static getFileDescriptorFiles (I)[Ljava/io/File; - -
 method public,static getPidFiles ()[Ljava/io/File; - -
 method public,static querySocketToPidMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/Long;Ljava/lang/Integer;>; -
 method public,static getThreadIds (I)Ljava/util/List; (I)Ljava/util/List<Ljava/lang/Integer;>; -
 method public,static getState (C)Loshi/software/os/OSProcess$State; - -
in 290
class oshi/driver/linux/proc/ProcessStat$PidStat 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/linux/proc/ProcessStat$PidStat;>;
 inner oshi/driver/linux/proc/ProcessStat$PidStat oshi/driver/linux/proc/ProcessStat PidStat public,static,final,enum
 field public,static,final,enum PID Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum COMM Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum STATE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum PPID Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum PGRP Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum SESSION Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum TTY_NR Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum PTGID Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum FLAGS Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum MINFLT Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum CMINFLT Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum MAJFLT Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum CMAJFLT Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum UTIME Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum STIME Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum CUTIME Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum CSTIME Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum PRIORITY Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum NICE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum NUM_THREADS Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum ITREALVALUE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum STARTTIME Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum VSIZE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum RSS Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum RSSLIM Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum STARTCODE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum ENDCODE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum STARTSTACK Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum KSTKESP Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum KSTKEIP Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum SIGNAL Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum BLOCKED Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum SIGIGNORE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum SIGCATCH Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum WCHAN Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum NSWAP Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum CNSWAP Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum EXIT_SIGNAL Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum PROCESSOR Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum RT_PRIORITY Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum POLICY Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum DELAYACCT_BLKIO_TICKS Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum GUEST_TIME Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum CGUEST_TIME Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum START_DATA Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum END_DATA Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum START_BRK Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum ARG_START Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum ARG_END Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum ENV_START Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum ENV_END Loshi/driver/linux/proc/ProcessStat$PidStat; -
 field public,static,final,enum EXIT_CODE Loshi/driver/linux/proc/ProcessStat$PidStat; -
 method public,static values ()[Loshi/driver/linux/proc/ProcessStat$PidStat; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/linux/proc/ProcessStat$PidStat; - -
in 290
class oshi/driver/linux/proc/ProcessStat$PidStatM 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/linux/proc/ProcessStat$PidStatM;>;
 inner oshi/driver/linux/proc/ProcessStat$PidStatM oshi/driver/linux/proc/ProcessStat PidStatM public,static,final,enum
 field public,static,final,enum SIZE Loshi/driver/linux/proc/ProcessStat$PidStatM; -
 field public,static,final,enum RESIDENT Loshi/driver/linux/proc/ProcessStat$PidStatM; -
 field public,static,final,enum SHARED Loshi/driver/linux/proc/ProcessStat$PidStatM; -
 field public,static,final,enum TEXT Loshi/driver/linux/proc/ProcessStat$PidStatM; -
 field public,static,final,enum LIB Loshi/driver/linux/proc/ProcessStat$PidStatM; -
 field public,static,final,enum DATA Loshi/driver/linux/proc/ProcessStat$PidStatM; -
 field public,static,final,enum DT Loshi/driver/linux/proc/ProcessStat$PidStatM; -
 method public,static values ()[Loshi/driver/linux/proc/ProcessStat$PidStatM; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/linux/proc/ProcessStat$PidStatM; - -
in 290
class oshi/driver/linux/proc/UpTime 52 public,final,super java/lang/Object - -
 method public,static getSystemUptimeSeconds ()D - -
in 1183
class oshi/driver/linux/proc/UserGroupInfo 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getUser (Ljava/lang/String;)Ljava/lang/String; - -
 method public,static getGroupName (Ljava/lang/String;)Ljava/lang/String; - -
in 290
class oshi/driver/mac/ThreadInfo 52 public,final,super java/lang/Object - -
 inner oshi/driver/mac/ThreadInfo$ThreadStats oshi/driver/mac/ThreadInfo ThreadStats public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryTaskThreads (I)Ljava/util/List; (I)Ljava/util/List<Loshi/driver/mac/ThreadInfo$ThreadStats;>; -
in 290
class oshi/driver/mac/ThreadInfo$ThreadStats 52 public,super java/lang/Object - -
 inner oshi/driver/mac/ThreadInfo$ThreadStats oshi/driver/mac/ThreadInfo ThreadStats public,static
 inner oshi/software/os/OSProcess$State oshi/software/os/OSProcess State public,static,final,enum
 method public <init> (IDCJJI)V - -
 method public getThreadId ()I - -
 method public getUserTime ()J - -
 method public getSystemTime ()J - -
 method public getUpTime ()J - -
 method public getState ()Loshi/software/os/OSProcess$State; - -
 method public getPriority ()I - -
in 290
class oshi/driver/mac/Who 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/mac/SystemB$MacUtmpx oshi/jna/platform/mac/SystemB MacUtmpx public,static
 inner com/sun/jna/platform/mac/SystemB$Timeval com/sun/jna/platform/mac/SystemB Timeval public,static
 method public,static,synchronized queryUtxent ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 290
class oshi/driver/mac/WindowInfo 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/mac/CoreFoundation$CFArrayRef com/sun/jna/platform/mac/CoreFoundation CFArrayRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFStringRef com/sun/jna/platform/mac/CoreFoundation CFStringRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFDictionaryRef com/sun/jna/platform/mac/CoreFoundation CFDictionaryRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFBooleanRef com/sun/jna/platform/mac/CoreFoundation CFBooleanRef public,static
 inner com/sun/jna/platform/mac/CoreFoundation$CFNumberRef com/sun/jna/platform/mac/CoreFoundation CFNumberRef public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGRect oshi/jna/platform/mac/CoreGraphics CGRect public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGPoint oshi/jna/platform/mac/CoreGraphics CGPoint public,static
 inner oshi/jna/platform/mac/CoreGraphics$CGSize oshi/jna/platform/mac/CoreGraphics CGSize public,static
 method public,static queryDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 1185
class oshi/driver/mac/disk/Fsstat 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/mac/SystemB$Statfs com/sun/jna/platform/mac/SystemB Statfs public,static
 method public,static queryPartitionToMountMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
in 34
class oshi/driver/mac/disk/Fsstat 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/mac/SystemB$Statfs com/sun/jna/platform/mac/SystemB Statfs public,static
 method public,static queryFsstat ([Lcom/sun/jna/platform/mac/SystemB$Statfs;II)I - -
 method public,static getFileSystems (I)[Lcom/sun/jna/platform/mac/SystemB$Statfs; - -
 method public,static queryPartitionToMountMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
in 82
class oshi/driver/mac/net/NetStat 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/mac/SystemB$IFmsgHdr com/sun/jna/platform/mac/SystemB IFmsgHdr public,static
 inner com/sun/jna/platform/mac/SystemB$IFmsgHdr2 com/sun/jna/platform/mac/SystemB IFmsgHdr2 public,static
 inner oshi/driver/mac/net/NetStat$IFdata oshi/driver/mac/net/NetStat IFdata public,static
 inner com/sun/jna/platform/mac/SystemB$IFdata64 com/sun/jna/platform/mac/SystemB IFdata64 public,static
 method public,static queryIFdata (I)Ljava/util/Map; (I)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/mac/net/NetStat$IFdata;>; -
in 34
class oshi/driver/mac/net/NetStat 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner com/sun/jna/platform/mac/SystemB$IFmsgHdr com/sun/jna/platform/mac/SystemB IFmsgHdr public,static
 inner com/sun/jna/platform/mac/SystemB$IFmsgHdr2 com/sun/jna/platform/mac/SystemB IFmsgHdr2 public,static
 inner oshi/driver/mac/net/NetStat$IFdata oshi/driver/mac/net/NetStat IFdata public,static
 inner com/sun/jna/platform/mac/SystemB$IFdata64 com/sun/jna/platform/mac/SystemB IFdata64 public,static
 method public,static queryIFdata (I)Ljava/util/Map; (I)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/mac/net/NetStat$IFdata;>; -
in 39
class oshi/driver/mac/net/NetStat 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseableSizeTByReference oshi/jna/ByRef CloseableSizeTByReference public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t$ByReference com/sun/jna/platform/unix/LibCAPI$size_t ByReference public,static
 inner com/sun/jna/platform/mac/SystemB$IFmsgHdr com/sun/jna/platform/mac/SystemB IFmsgHdr public,static
 inner com/sun/jna/platform/mac/SystemB$IFmsgHdr2 com/sun/jna/platform/mac/SystemB IFmsgHdr2 public,static
 inner oshi/driver/mac/net/NetStat$IFdata oshi/driver/mac/net/NetStat IFdata public,static
 inner com/sun/jna/platform/mac/SystemB$IFdata64 com/sun/jna/platform/mac/SystemB IFdata64 public,static
 method public,static queryIFdata (I)Ljava/util/Map; (I)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/mac/net/NetStat$IFdata;>; -
in 290
class oshi/driver/mac/net/NetStat$IFdata 52 public,super java/lang/Object - -
 inner oshi/driver/mac/net/NetStat$IFdata oshi/driver/mac/net/NetStat IFdata public,static
 method public getIfType ()I - -
 method public getOPackets ()J - -
 method public getIPackets ()J - -
 method public getOBytes ()J - -
 method public getIBytes ()J - -
 method public getOErrors ()J - -
 method public getIErrors ()J - -
 method public getCollisions ()J - -
 method public getIDrops ()J - -
 method public getSpeed ()J - -
 method public getTimeStamp ()J - -
in 290
class oshi/driver/unix/NetStat 52 public,final,super java/lang/Object - -
 inner oshi/software/os/InternetProtocolStats$IPConnection oshi/software/os/InternetProtocolStats IPConnection public,static,final
 inner oshi/software/os/InternetProtocolStats$TcpState oshi/software/os/InternetProtocolStats TcpState public,static,final,enum
 inner oshi/software/os/InternetProtocolStats$TcpStats oshi/software/os/InternetProtocolStats TcpStats public,static,final
 inner oshi/software/os/InternetProtocolStats$UdpStats oshi/software/os/InternetProtocolStats UdpStats public,static,final
 method public,static queryTcpnetstat ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/Long;Ljava/lang/Long;>; -
 method public,static queryNetstat ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/InternetProtocolStats$IPConnection;>; -
 method public,static queryTcpStats (Ljava/lang/String;)Loshi/software/os/InternetProtocolStats$TcpStats; - -
 method public,static queryUdpStats (Ljava/lang/String;)Loshi/software/os/InternetProtocolStats$UdpStats; - -
in 290
class oshi/driver/unix/Who 52 public,final,super java/lang/Object - -
 method public,static,synchronized queryWho ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 290
class oshi/driver/unix/Xrandr 52 public,final,super java/lang/Object - -
 method public,static getEdidArrays ()Ljava/util/List; ()Ljava/util/List<[B>; -
in 290
class oshi/driver/unix/Xwininfo 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static queryXWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 290
class oshi/driver/unix/aix/Ls 52 public,final,super java/lang/Object - -
 method public,static queryDeviceMajorMinor ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Loshi/util/tuples/Pair<Ljava/lang/Integer;Ljava/lang/Integer;>;>; -
in 290
class oshi/driver/unix/aix/Lscfg 52 public,final,super java/lang/Object - -
 method public,static queryAllDevices ()Ljava/util/List; ()Ljava/util/List<Ljava/lang/String;>; -
 method public,static queryBackplaneModelSerialVersion (Ljava/util/List;)Loshi/util/tuples/Triplet; (Ljava/util/List<Ljava/lang/String;>;)Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;>; -
 method public,static queryModelSerial (Ljava/lang/String;)Loshi/util/tuples/Pair; (Ljava/lang/String;)Loshi/util/tuples/Pair<Ljava/lang/String;Ljava/lang/String;>; -
in 371
class oshi/driver/unix/aix/Lspv 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public,static queryLogicalVolumes (Ljava/lang/String;Ljava/util/Map;)Ljava/util/List; (Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Loshi/util/tuples/Pair<Ljava/lang/Integer;Ljava/lang/Integer;>;>;)Ljava/util/List<Loshi/hardware/HWPartition;>; -
in 23
class oshi/driver/unix/aix/Lspv 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryLogicalVolumes (Ljava/lang/String;Ljava/util/Map;)Ljava/util/List; (Ljava/lang/String;Ljava/util/Map<Ljava/lang/String;Loshi/util/tuples/Pair<Ljava/lang/Integer;Ljava/lang/Integer;>;>;)Ljava/util/List<Loshi/hardware/HWPartition;>; -
in 290
class oshi/driver/unix/aix/Lssrad 52 public,final,super java/lang/Object - -
 method public,static queryNodesPackages ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/Integer;Loshi/util/tuples/Pair<Ljava/lang/Integer;Ljava/lang/Integer;>;>; -
in 34
class oshi/driver/unix/aix/PsInfo 52 public,final,super java/lang/Object - -
 inner oshi/driver/unix/aix/PsInfo$LwpsInfoT oshi/driver/unix/aix/PsInfo LwpsInfoT static,final,enum
 inner oshi/driver/unix/aix/PsInfo$PsInfoT oshi/driver/unix/aix/PsInfo PsInfoT static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$ssize_t com/sun/jna/platform/unix/LibCAPI ssize_t public,static
 method public,static queryArgsEnvAddrs (I)Loshi/util/tuples/Triplet; (I)Loshi/util/tuples/Triplet<Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/Long;>; -
 method public,static queryArgsEnv (I)Loshi/util/tuples/Pair; (I)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>; -
in 39
class oshi/driver/unix/aix/PsInfo 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/unix/AixLibc$AixPsInfo oshi/jna/platform/unix/AixLibc AixPsInfo public,static
 inner oshi/jna/platform/unix/AixLibc$AixLwpsInfo oshi/jna/platform/unix/AixLibc AixLwpsInfo public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$ssize_t com/sun/jna/platform/unix/LibCAPI ssize_t public,static
 method public,static queryPsInfo (I)Loshi/jna/platform/unix/AixLibc$AixPsInfo; - -
 method public,static queryLwpsInfo (II)Loshi/jna/platform/unix/AixLibc$AixLwpsInfo; - -
 method public,static queryArgsEnvAddrs (ILoshi/jna/platform/unix/AixLibc$AixPsInfo;)Loshi/util/tuples/Triplet; (ILoshi/jna/platform/unix/AixLibc$AixPsInfo;)Loshi/util/tuples/Triplet<Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/Long;>; -
 method public,static queryArgsEnv (ILoshi/jna/platform/unix/AixLibc$AixPsInfo;)Loshi/util/tuples/Pair; (ILoshi/jna/platform/unix/AixLibc$AixPsInfo;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>; -
in 34
class oshi/driver/unix/aix/PsInfo$LwpsInfoT 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/unix/aix/PsInfo$LwpsInfoT;>;
 inner oshi/driver/unix/aix/PsInfo$LwpsInfoT oshi/driver/unix/aix/PsInfo LwpsInfoT static,final,enum
 field public,static,final,enum PR_LWPID Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_ADDR Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_WCHAN Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_FLAG Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_WTYPE Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_STATE Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_SNAME Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_NICE Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_PRI Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_POLICY Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_CLNAME Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_ONPRO Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_BINDPRO Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 field public,static,final,enum SIZE Loshi/driver/unix/aix/PsInfo$LwpsInfoT; -
 method public,static values ()[Loshi/driver/unix/aix/PsInfo$LwpsInfoT; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/unix/aix/PsInfo$LwpsInfoT; - -
 method public size ()I - -
in 34
class oshi/driver/unix/aix/PsInfo$PsInfoT 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/unix/aix/PsInfo$PsInfoT;>;
 inner oshi/driver/unix/aix/PsInfo$PsInfoT oshi/driver/unix/aix/PsInfo PsInfoT static,final,enum
 inner oshi/driver/unix/aix/PsInfo$LwpsInfoT oshi/driver/unix/aix/PsInfo LwpsInfoT static,final,enum
 field public,static,final,enum PR_FLAG Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_FLAG2 Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_NLWP Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PAD1 Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_UID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_EUID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_GID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_EGID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PPID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PGID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_SID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_TTYDEV Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ADDR Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_SIZE Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_RSSIZE Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_START Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_TIME Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_CID Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PAD2 Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ARGC Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ARGV Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ENVP Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_FNAME Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PSARGS Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PAD Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum PR_LWP Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 field public,static,final,enum SIZE Loshi/driver/unix/aix/PsInfo$PsInfoT; -
 method public,static values ()[Loshi/driver/unix/aix/PsInfo$PsInfoT; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/unix/aix/PsInfo$PsInfoT; - -
 method public size ()I - -
in 290
class oshi/driver/unix/aix/Uptime 52 public,final,super java/lang/Object - -
 method public,static queryUpTime ()J - -
in 290
class oshi/driver/unix/aix/Who 52 public,final,super java/lang/Object - -
 method public,static queryBootTime ()J - -
in 290
class oshi/driver/unix/aix/perfstat/PerfstatConfig 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t com/sun/jna/platform/unix/aix/Perfstat perfstat_partition_config_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_id_t com/sun/jna/platform/unix/aix/Perfstat perfstat_id_t public,static
 method public,static queryConfig ()Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_partition_config_t; - -
in 290
class oshi/driver/unix/aix/perfstat/PerfstatCpu 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_total_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_id_t com/sun/jna/platform/unix/aix/Perfstat perfstat_id_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_t com/sun/jna/platform/unix/aix/Perfstat perfstat_cpu_t public,static
 method public,static queryCpuTotal ()Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_total_t; - -
 method public,static queryCpu ()[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_cpu_t; - -
 method public,static queryCpuAffinityMask ()J - -
in 290
class oshi/driver/unix/aix/perfstat/PerfstatDisk 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_disk_t com/sun/jna/platform/unix/aix/Perfstat perfstat_disk_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_id_t com/sun/jna/platform/unix/aix/Perfstat perfstat_id_t public,static
 method public,static queryDiskStats ()[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_disk_t; - -
in 290
class oshi/driver/unix/aix/perfstat/PerfstatMemory 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_memory_total_t com/sun/jna/platform/unix/aix/Perfstat perfstat_memory_total_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_id_t com/sun/jna/platform/unix/aix/Perfstat perfstat_id_t public,static
 method public,static queryMemoryTotal ()Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_memory_total_t; - -
in 290
class oshi/driver/unix/aix/perfstat/PerfstatNetInterface 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_netinterface_t com/sun/jna/platform/unix/aix/Perfstat perfstat_netinterface_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_id_t com/sun/jna/platform/unix/aix/Perfstat perfstat_id_t public,static
 method public,static queryNetInterfaces ()[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_netinterface_t; - -
in 290
class oshi/driver/unix/aix/perfstat/PerfstatProcess 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t com/sun/jna/platform/unix/aix/Perfstat perfstat_process_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_id_t com/sun/jna/platform/unix/aix/Perfstat perfstat_id_t public,static
 method public,static queryProcesses ()[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_process_t; - -
in 290
class oshi/driver/unix/aix/perfstat/PerfstatProtocol 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t com/sun/jna/platform/unix/aix/Perfstat perfstat_protocol_t public,static
 inner com/sun/jna/platform/unix/aix/Perfstat$perfstat_id_t com/sun/jna/platform/unix/aix/Perfstat perfstat_id_t public,static
 method public,static queryProtocols ()[Lcom/sun/jna/platform/unix/aix/Perfstat$perfstat_protocol_t; - -
in 1183
class oshi/driver/unix/freebsd/Who 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/freebsd/FreeBsdLibc FreeBsdUtmpx public,static
 inner oshi/jna/platform/unix/freebsd/FreeBsdLibc$Timeval oshi/jna/platform/unix/freebsd/FreeBsdLibc Timeval public,static
 method public,static,synchronized queryUtxent ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 39
class oshi/driver/unix/freebsd/Who 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/unix/FreeBsdLibc$FreeBsdUtmpx oshi/jna/platform/unix/FreeBsdLibc FreeBsdUtmpx public,static
 inner oshi/jna/platform/unix/FreeBsdLibc$Timeval oshi/jna/platform/unix/FreeBsdLibc Timeval public,static
 method public,static,synchronized queryUtxent ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 290
class oshi/driver/unix/freebsd/disk/GeomDiskList 52 public,final,super java/lang/Object - -
 method public,static queryDisks ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Loshi/util/tuples/Triplet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;>;>; -
in 290
class oshi/driver/unix/freebsd/disk/GeomPartList 52 public,final,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryPartitions ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/util/List<Loshi/hardware/HWPartition;>;>; -
in 290
class oshi/driver/unix/freebsd/disk/Mount 52 public,final,super java/lang/Object - -
 method public,static queryPartitionToMountMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
in 290
class oshi/driver/unix/openbsd/disk/Disklabel 52 public,final,super java/lang/Object - -
 method public,static getDiskParams (Ljava/lang/String;)Loshi/util/tuples/Quartet; (Ljava/lang/String;)Loshi/util/tuples/Quartet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/util/List<Loshi/hardware/HWPartition;>;>; -
in 34
class oshi/driver/unix/solaris/PsInfo 52 public,final,super java/lang/Object - -
 inner oshi/driver/unix/solaris/PsInfo$LwpsInfoT oshi/driver/unix/solaris/PsInfo LwpsInfoT static,final,enum
 inner oshi/driver/unix/solaris/PsInfo$PsInfoT oshi/driver/unix/solaris/PsInfo PsInfoT static,final,enum
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$ssize_t com/sun/jna/platform/unix/LibCAPI ssize_t public,static
 method public,static queryArgsEnvAddrs (I)Loshi/util/tuples/Quartet; (I)Loshi/util/tuples/Quartet<Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Byte;>; -
 method public,static queryArgsEnv (I)Loshi/util/tuples/Pair; (I)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>; -
in 39
class oshi/driver/unix/solaris/PsInfo 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPsInfo oshi/jna/platform/unix/SolarisLibc SolarisPsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo oshi/jna/platform/unix/SolarisLibc SolarisLwpsInfo public,static
 inner oshi/jna/platform/unix/SolarisLibc$SolarisPrUsage oshi/jna/platform/unix/SolarisLibc SolarisPrUsage public,static
 inner com/sun/jna/platform/unix/LibCAPI$size_t com/sun/jna/platform/unix/LibCAPI size_t public,static
 inner com/sun/jna/platform/unix/LibCAPI$ssize_t com/sun/jna/platform/unix/LibCAPI ssize_t public,static
 method public,static queryPsInfo (I)Loshi/jna/platform/unix/SolarisLibc$SolarisPsInfo; - -
 method public,static queryLwpsInfo (II)Loshi/jna/platform/unix/SolarisLibc$SolarisLwpsInfo; - -
 method public,static queryPrUsage (I)Loshi/jna/platform/unix/SolarisLibc$SolarisPrUsage; - -
 method public,static queryPrUsage (II)Loshi/jna/platform/unix/SolarisLibc$SolarisPrUsage; - -
 method public,static queryArgsEnvAddrs (ILoshi/jna/platform/unix/SolarisLibc$SolarisPsInfo;)Loshi/util/tuples/Quartet; (ILoshi/jna/platform/unix/SolarisLibc$SolarisPsInfo;)Loshi/util/tuples/Quartet<Ljava/lang/Integer;Ljava/lang/Long;Ljava/lang/Long;Ljava/lang/Byte;>; -
 method public,static queryArgsEnv (ILoshi/jna/platform/unix/SolarisLibc$SolarisPsInfo;)Loshi/util/tuples/Pair; (ILoshi/jna/platform/unix/SolarisLibc$SolarisPsInfo;)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>; -
in 34
class oshi/driver/unix/solaris/PsInfo$LwpsInfoT 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/unix/solaris/PsInfo$LwpsInfoT;>;
 inner oshi/driver/unix/solaris/PsInfo$LwpsInfoT oshi/driver/unix/solaris/PsInfo LwpsInfoT static,final,enum
 field public,static,final,enum PR_FLAG Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_LWPID Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_ADDR Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_WCHAN Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_STYPE Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_STATE Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_SNAME Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_NICE Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_SYSCALL Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_OLDPRI Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_CPU Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_PRI Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_PCTCPU Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PAD Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_START Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_TIME Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_CLNAME Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_NAME Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_ONPRO Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_BINDPRO Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_BINDPSET Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_LGRP Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum PR_LAST_ONPROC Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 field public,static,final,enum SIZE Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; -
 method public,static values ()[Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/unix/solaris/PsInfo$LwpsInfoT; - -
 method public size ()I - -
in 34
class oshi/driver/unix/solaris/PsInfo$PsInfoT 52 final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/unix/solaris/PsInfo$PsInfoT;>;
 inner oshi/driver/unix/solaris/PsInfo$PsInfoT oshi/driver/unix/solaris/PsInfo PsInfoT static,final,enum
 inner oshi/driver/unix/solaris/PsInfo$LwpsInfoT oshi/driver/unix/solaris/PsInfo LwpsInfoT static,final,enum
 field public,static,final,enum PR_FLAG Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_NLWP Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_NZOMB Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PPID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PGID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_SID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_UID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_EUID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_GID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_EGID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PAD1 Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ADDR Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_SIZE Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_RSSIZE Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_TTYDEV Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PCTCPU Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PCTMEM Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PAD2 Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_START Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_TIME Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_CTIME Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_FNAME Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PSARGS Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_WSTAT Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ARGC Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ARGV Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ENVP Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_DMODEL Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PAD3 Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_LWP Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_TASKID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_PROJID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_POOLID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_ZONEID Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum PR_CONTRACT Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 field public,static,final,enum SIZE Loshi/driver/unix/solaris/PsInfo$PsInfoT; -
 method public,static values ()[Loshi/driver/unix/solaris/PsInfo$PsInfoT; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/unix/solaris/PsInfo$PsInfoT; - -
 method public size ()I - -
in 1183
class oshi/driver/unix/solaris/Who 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/unix/solaris/SolarisLibc$SolarisUtmpx oshi/jna/platform/unix/solaris/SolarisLibc SolarisUtmpx public,static
 inner oshi/jna/platform/unix/solaris/SolarisLibc$Timeval oshi/jna/platform/unix/solaris/SolarisLibc Timeval public,static
 method public,static,synchronized queryUtxent ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 39
class oshi/driver/unix/solaris/Who 52 public,final,super java/lang/Object - -
 inner oshi/jna/platform/unix/SolarisLibc$SolarisUtmpx oshi/jna/platform/unix/SolarisLibc SolarisUtmpx public,static
 inner oshi/jna/platform/unix/SolarisLibc$Timeval oshi/jna/platform/unix/SolarisLibc Timeval public,static
 method public,static,synchronized queryUtxent ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 290
class oshi/driver/unix/solaris/disk/Iostat 52 public,final,super java/lang/Object - -
 method public,static queryPartitionToMountMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public,static queryDeviceStrings (Ljava/util/Set;)Ljava/util/Map; (Ljava/util/Set<Ljava/lang/String;>;)Ljava/util/Map<Ljava/lang/String;Loshi/util/tuples/Quintet<Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;>;>; -
in 290
class oshi/driver/unix/solaris/disk/Lshal 52 public,final,super java/lang/Object - -
 method public,static queryDiskToMajorMap ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/Integer;>; -
in 290
class oshi/driver/unix/solaris/disk/Prtvtoc 52 public,final,super java/lang/Object - -
 method public,static queryPartitions (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Loshi/hardware/HWPartition;>; -
in 290
class oshi/driver/unix/solaris/kstat/SystemPages 52 public,final,super java/lang/Object - -
 inner oshi/util/platform/unix/solaris/KstatUtil$KstatChain oshi/util/platform/unix/solaris/KstatUtil KstatChain public,static,final
 inner com/sun/jna/platform/unix/solaris/LibKstat$Kstat com/sun/jna/platform/unix/solaris/LibKstat Kstat public,static
 method public,static queryAvailableTotal ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/lang/Long;Ljava/lang/Long;>; -
in 1183
class oshi/driver/windows/DeviceTree 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/Guid$GUID com/sun/jna/platform/win32/Guid GUID public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA com/sun/jna/platform/win32/SetupApi SP_DEVINFO_DATA public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryDeviceTree (Lcom/sun/jna/platform/win32/Guid$GUID;)Loshi/util/tuples/Quintet; (Lcom/sun/jna/platform/win32/Guid$GUID;)Loshi/util/tuples/Quintet<Ljava/util/Set<Ljava/lang/Integer;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;>; -
in 39
class oshi/driver/windows/DeviceTree 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/Guid$GUID com/sun/jna/platform/win32/Guid GUID public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/jna/Struct$CloseableSpDevinfoData oshi/jna/Struct CloseableSpDevinfoData public,static
 inner com/sun/jna/platform/win32/SetupApi$SP_DEVINFO_DATA com/sun/jna/platform/win32/SetupApi SP_DEVINFO_DATA public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryDeviceTree (Lcom/sun/jna/platform/win32/Guid$GUID;)Loshi/util/tuples/Quintet; (Lcom/sun/jna/platform/win32/Guid$GUID;)Loshi/util/tuples/Quintet<Ljava/util/Set<Ljava/lang/Integer;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/Integer;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;Ljava/util/Map<Ljava/lang/Integer;Ljava/lang/String;>;>; -
in 1183
class oshi/driver/windows/EnumWindows 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinDef$HWND com/sun/jna/platform/win32/WinDef HWND public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 39
class oshi/driver/windows/EnumWindows 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinDef$HWND com/sun/jna/platform/win32/WinDef HWND public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/WinDef$DWORD com/sun/jna/platform/win32/WinDef DWORD public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryDesktopWindows (Z)Ljava/util/List; (Z)Ljava/util/List<Loshi/software/os/OSDesktopWindow;>; -
in 1183
class oshi/driver/windows/LogicalProcessorInformation 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinNT$LOGICAL_PROCESSOR_RELATIONSHIP com/sun/jna/platform/win32/WinNT LOGICAL_PROCESSOR_RELATIONSHIP public,static,interface,abstract
 inner com/sun/jna/platform/win32/WinNT$SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX com/sun/jna/platform/win32/WinNT SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX public,static,abstract
 inner com/sun/jna/platform/win32/WinNT$PROCESSOR_RELATIONSHIP com/sun/jna/platform/win32/WinNT PROCESSOR_RELATIONSHIP public,static
 inner com/sun/jna/platform/win32/WinNT$GROUP_AFFINITY com/sun/jna/platform/win32/WinNT GROUP_AFFINITY public,static
 inner com/sun/jna/platform/win32/WinNT$NUMA_NODE_RELATIONSHIP com/sun/jna/platform/win32/WinNT NUMA_NODE_RELATIONSHIP public,static
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner com/sun/jna/platform/win32/WinNT$SYSTEM_LOGICAL_PROCESSOR_INFORMATION com/sun/jna/platform/win32/WinNT SYSTEM_LOGICAL_PROCESSOR_INFORMATION public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getLogicalProcessorInformationEx ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
 method public,static getLogicalProcessorInformation ()Ljava/util/List; ()Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>; -
in 42
class oshi/driver/windows/LogicalProcessorInformation 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinNT$LOGICAL_PROCESSOR_RELATIONSHIP com/sun/jna/platform/win32/WinNT LOGICAL_PROCESSOR_RELATIONSHIP public,static,interface,abstract
 inner com/sun/jna/platform/win32/WinNT$SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX com/sun/jna/platform/win32/WinNT SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX public,static,abstract
 inner com/sun/jna/platform/win32/WinNT$PROCESSOR_RELATIONSHIP com/sun/jna/platform/win32/WinNT PROCESSOR_RELATIONSHIP public,static
 inner com/sun/jna/platform/win32/WinNT$GROUP_AFFINITY com/sun/jna/platform/win32/WinNT GROUP_AFFINITY public,static
 inner com/sun/jna/platform/win32/WinNT$NUMA_NODE_RELATIONSHIP com/sun/jna/platform/win32/WinNT NUMA_NODE_RELATIONSHIP public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner com/sun/jna/platform/win32/WinNT$SYSTEM_LOGICAL_PROCESSOR_INFORMATION com/sun/jna/platform/win32/WinNT SYSTEM_LOGICAL_PROCESSOR_INFORMATION public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getLogicalProcessorInformationEx ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
 method public,static getLogicalProcessorInformation ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;>; -
in 23
class oshi/driver/windows/LogicalProcessorInformation 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinNT$LOGICAL_PROCESSOR_RELATIONSHIP com/sun/jna/platform/win32/WinNT LOGICAL_PROCESSOR_RELATIONSHIP public,static,interface,abstract
 inner com/sun/jna/platform/win32/WinNT$SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX com/sun/jna/platform/win32/WinNT SYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX public,static,abstract
 inner com/sun/jna/platform/win32/WinNT$PROCESSOR_RELATIONSHIP com/sun/jna/platform/win32/WinNT PROCESSOR_RELATIONSHIP public,static
 inner com/sun/jna/platform/win32/WinNT$GROUP_AFFINITY com/sun/jna/platform/win32/WinNT GROUP_AFFINITY public,static
 inner com/sun/jna/platform/win32/WinNT$CACHE_RELATIONSHIP com/sun/jna/platform/win32/WinNT CACHE_RELATIONSHIP public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache oshi/hardware/CentralProcessor ProcessorCache public,static
 inner oshi/hardware/CentralProcessor$ProcessorCache$Type oshi/hardware/CentralProcessor$ProcessorCache Type public,static,final,enum
 inner com/sun/jna/platform/win32/WinNT$NUMA_NODE_RELATIONSHIP com/sun/jna/platform/win32/WinNT NUMA_NODE_RELATIONSHIP public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 inner com/sun/jna/platform/win32/BaseTSD$ULONG_PTR com/sun/jna/platform/win32/BaseTSD ULONG_PTR public,static
 inner oshi/hardware/CentralProcessor$LogicalProcessor oshi/hardware/CentralProcessor LogicalProcessor public,static
 inner oshi/hardware/CentralProcessor$PhysicalProcessor oshi/hardware/CentralProcessor PhysicalProcessor public,static
 inner com/sun/jna/platform/win32/WinNT$SYSTEM_LOGICAL_PROCESSOR_INFORMATION com/sun/jna/platform/win32/WinNT SYSTEM_LOGICAL_PROCESSOR_INFORMATION public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getLogicalProcessorInformationEx ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
 method public,static getLogicalProcessorInformation ()Loshi/util/tuples/Triplet; ()Loshi/util/tuples/Triplet<Ljava/util/List<Loshi/hardware/CentralProcessor$LogicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$PhysicalProcessor;>;Ljava/util/List<Loshi/hardware/CentralProcessor$ProcessorCache;>;>; -
in 39
class oshi/driver/windows/perfmon/LoadAverage 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty oshi/driver/windows/perfmon/ProcessInformation IdleProcessorTimeProperty public,static,final,enum
 method public,static queryLoadAverage (I)[D - -
 method public,static,synchronized stopDaemon ()V - -
 method public,static,synchronized startDaemon ()V - -
in 290
class oshi/driver/windows/perfmon/MemoryInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty oshi/driver/windows/perfmon/MemoryInformation PageSwapProperty public,static,final,enum
 method public,static queryPageSwaps ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty;Ljava/lang/Long;>; -
in 290
class oshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty;>;Loshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty;
 inner oshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty oshi/driver/windows/perfmon/MemoryInformation PageSwapProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 field public,static,final,enum PAGESINPUTPERSEC Loshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty; -
 field public,static,final,enum PAGESOUTPUTPERSEC Loshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/MemoryInformation$PageSwapProperty; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
in 290
class oshi/driver/windows/perfmon/PagingFile 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/PagingFile$PagingPercentProperty oshi/driver/windows/perfmon/PagingFile PagingPercentProperty public,static,final,enum
 method public,static querySwapUsed ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/PagingFile$PagingPercentProperty;Ljava/lang/Long;>; -
in 290
class oshi/driver/windows/perfmon/PagingFile$PagingPercentProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/PagingFile$PagingPercentProperty;>;Loshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty;
 inner oshi/driver/windows/perfmon/PagingFile$PagingPercentProperty oshi/driver/windows/perfmon/PagingFile PagingPercentProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 field public,static,final,enum PERCENTUSAGE Loshi/driver/windows/perfmon/PagingFile$PagingPercentProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/PagingFile$PagingPercentProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/PagingFile$PagingPercentProperty; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
in 39
class oshi/driver/windows/perfmon/PerfmonConstants 52 public,final,super java/lang/Object - -
in 220
class oshi/driver/windows/perfmon/PerfmonDisabled 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
in 60
class oshi/driver/windows/perfmon/PerfmonDisabled 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 field public,static,final PERF_OS_DISABLED Z -
 field public,static,final PERF_PROC_DISABLED Z -
 field public,static,final PERF_DISK_DISABLED Z -
in 290
class oshi/driver/windows/perfmon/PhysicalDisk 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty oshi/driver/windows/perfmon/PhysicalDisk PhysicalDiskProperty public,static,final,enum
 method public,static queryDiskCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 290
class oshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty oshi/driver/windows/perfmon/PhysicalDisk PhysicalDiskProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; -
 field public,static,final,enum DISKREADSPERSEC Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; -
 field public,static,final,enum DISKREADBYTESPERSEC Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; -
 field public,static,final,enum DISKWRITESPERSEC Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; -
 field public,static,final,enum DISKWRITEBYTESPERSEC Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; -
 field public,static,final,enum CURRENTDISKQUEUELENGTH Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; -
 field public,static,final,enum PERCENTDISKTIME Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/PhysicalDisk$PhysicalDiskProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 1183
class oshi/driver/windows/perfmon/ProcessInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty oshi/driver/windows/perfmon/ProcessInformation ProcessPerformanceProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty oshi/driver/windows/perfmon/ProcessInformation HandleCountProperty public,static,final,enum
 method public,static queryProcessCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryHandles ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 39
class oshi/driver/windows/perfmon/ProcessInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty oshi/driver/windows/perfmon/ProcessInformation ProcessPerformanceProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty oshi/driver/windows/perfmon/ProcessInformation HandleCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty oshi/driver/windows/perfmon/ProcessInformation IdleProcessorTimeProperty public,static,final,enum
 method public,static queryProcessCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryHandles ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryIdleProcessCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 290
class oshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty oshi/driver/windows/perfmon/ProcessInformation HandleCountProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty; -
 field public,static,final,enum HANDLECOUNT Loshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessInformation$HandleCountProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 39
class oshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty oshi/driver/windows/perfmon/ProcessInformation IdleProcessorTimeProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty; -
 field public,static,final,enum PERCENTPROCESSORTIME Loshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty; -
 field public,static,final,enum ELAPSEDTIME Loshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessInformation$IdleProcessorTimeProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 82
class oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty oshi/driver/windows/perfmon/ProcessInformation ProcessPerformanceProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PRIORITY Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum CREATIONDATE Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PROCESSID Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PARENTPROCESSID Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum READTRANSFERCOUNT Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum WRITETRANSFERCOUNT Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PRIVATEPAGECOUNT Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PAGEFAULTSPERSEC Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 30
class oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty oshi/driver/windows/perfmon/ProcessInformation ProcessPerformanceProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PRIORITYBASE Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum ELAPSEDTIME Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum IDPROCESS Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum CREATINGPROCESSID Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum IOREADBYTESPERSEC Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum IOWRITEBYTESPERSEC Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PRIVATEBYTES Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 field public,static,final,enum PAGEFAULTSPERSEC Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 1183
class oshi/driver/windows/perfmon/ProcessorInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 method public,static queryProcessorCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInterruptCounters ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty;Ljava/lang/Long;>; -
 method public,static queryFrequencyCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 35
class oshi/driver/windows/perfmon/ProcessorInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorUtilityTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 method public,static queryProcessorCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryProcessorCapacityCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInterruptCounters ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty;Ljava/lang/Long;>; -
 method public,static queryFrequencyCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 28
class oshi/driver/windows/perfmon/ProcessorInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation SystemTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorUtilityTickCountProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 method public,static queryProcessorCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static querySystemCounters ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty;Ljava/lang/Long;>; -
 method public,static queryProcessorCapacityCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryInterruptCounters ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty;Ljava/lang/Long;>; -
 method public,static queryFrequencyCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 290
class oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty;>;Loshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty;
 inner oshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty oshi/driver/windows/perfmon/ProcessorInformation InterruptsProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 field public,static,final,enum INTERRUPTSPERSEC Loshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessorInformation$InterruptsProperty; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
in 290
class oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorFrequencyProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty; -
 field public,static,final,enum PERCENTOFMAXIMUMFREQUENCY Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorFrequencyProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 290
class oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorTickCountProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; -
 field public,static,final,enum PERCENTDPCTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; -
 field public,static,final,enum PERCENTINTERRUPTTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; -
 field public,static,final,enum PERCENTPRIVILEGEDTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; -
 field public,static,final,enum PERCENTPROCESSORTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; -
 field public,static,final,enum PERCENTUSERTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorTickCountProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 39
class oshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation ProcessorUtilityTickCountProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTDPCTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTINTERRUPTTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTPRIVILEGEDTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTPROCESSORTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum TIMESTAMP_SYS100NS Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTPRIVILEGEDUTILITY Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTPROCESSORUTILITY Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTPROCESSORUTILITY_BASE Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 field public,static,final,enum PERCENTUSERTIME Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessorInformation$ProcessorUtilityTickCountProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 28
class oshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty;>;Loshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty;
 inner oshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty oshi/driver/windows/perfmon/ProcessorInformation SystemTickCountProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 field public,static,final,enum PERCENTDPCTIME Loshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty; -
 field public,static,final,enum PERCENTINTERRUPTTIME Loshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ProcessorInformation$SystemTickCountProperty; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
in 1183
class oshi/driver/windows/perfmon/SystemInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty oshi/driver/windows/perfmon/SystemInformation ContextSwitchProperty public,static,final,enum
 method public,static queryContextSwitchCounters ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty;Ljava/lang/Long;>; -
in 39
class oshi/driver/windows/perfmon/SystemInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty oshi/driver/windows/perfmon/SystemInformation ContextSwitchProperty public,static,final,enum
 inner oshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty oshi/driver/windows/perfmon/SystemInformation ProcessorQueueLengthProperty public,static,final,enum
 method public,static queryContextSwitchCounters ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty;Ljava/lang/Long;>; -
 method public,static queryProcessorQueueLength ()Ljava/util/Map; ()Ljava/util/Map<Loshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty;Ljava/lang/Long;>; -
in 290
class oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty;>;Loshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty;
 inner oshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty oshi/driver/windows/perfmon/SystemInformation ContextSwitchProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 field public,static,final,enum CONTEXTSWITCHESPERSEC Loshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/SystemInformation$ContextSwitchProperty; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
in 39
class oshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty;>;Loshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty;
 inner oshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty oshi/driver/windows/perfmon/SystemInformation ProcessorQueueLengthProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterQuery$PdhCounterProperty oshi/util/platform/windows/PerfCounterQuery PdhCounterProperty public,static,interface,abstract
 field public,static,final,enum PROCESSORQUEUELENGTH Loshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/SystemInformation$ProcessorQueueLengthProperty; - -
 method public getInstance ()Ljava/lang/String; - -
 method public getCounter ()Ljava/lang/String; - -
in 368
class oshi/driver/windows/perfmon/ThreadInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty oshi/driver/windows/perfmon/ThreadInformation ThreadPerformanceProperty public,static,final,enum
 method public,static queryThreadCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 60
class oshi/driver/windows/perfmon/ThreadInformation 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty oshi/driver/windows/perfmon/ThreadInformation ThreadPerformanceProperty public,static,final,enum
 method public,static queryThreadCounters ()Loshi/util/tuples/Pair; ()Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
 method public,static queryThreadCounters (Ljava/lang/String;I)Loshi/util/tuples/Pair; (Ljava/lang/String;I)Loshi/util/tuples/Pair<Ljava/util/List<Ljava/lang/String;>;Ljava/util/Map<Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty;Ljava/util/List<Ljava/lang/Long;>;>;>; -
in 290
class oshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty 52 public,final,super,enum java/lang/Enum oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty Ljava/lang/Enum<Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty;>;Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;
 inner oshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty oshi/driver/windows/perfmon/ThreadInformation ThreadPerformanceProperty public,static,final,enum
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 field public,static,final,enum NAME Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum PERCENTUSERTIME Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum PERCENTPRIVILEGEDTIME Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum ELAPSEDTIME Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum PRIORITYCURRENT Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum STARTADDRESS Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum THREADSTATE Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum THREADWAITREASON Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum IDPROCESS Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum IDTHREAD Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 field public,static,final,enum CONTEXTSWITCHESPERSEC Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; -
 method public,static values ()[Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty; - -
 method public getCounter ()Ljava/lang/String; - -
in 1183
class oshi/driver/windows/registry/HkeyPerformanceDataUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinPerf$PERF_DATA_BLOCK com/sun/jna/platform/win32/WinPerf PERF_DATA_BLOCK public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner com/sun/jna/platform/win32/WinPerf$PERF_OBJECT_TYPE com/sun/jna/platform/win32/WinPerf PERF_OBJECT_TYPE public,static
 inner com/sun/jna/platform/win32/WinPerf$PERF_COUNTER_DEFINITION com/sun/jna/platform/win32/WinPerf PERF_COUNTER_DEFINITION public,static
 inner com/sun/jna/platform/win32/WinPerf$PERF_INSTANCE_DEFINITION com/sun/jna/platform/win32/WinPerf PERF_INSTANCE_DEFINITION public,static
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 inner com/sun/jna/platform/win32/WinPerf$PERF_COUNTER_BLOCK com/sun/jna/platform/win32/WinPerf PERF_COUNTER_BLOCK public,static
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 method public,static readPerfDataFromRegistry (Ljava/lang/String;Ljava/lang/Class;)Loshi/util/tuples/Triplet; <T:Ljava/lang/Enum<TT;>;:Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;>(Ljava/lang/String;Ljava/lang/Class<TT;>;)Loshi/util/tuples/Triplet<Ljava/util/List<Ljava/util/Map<TT;Ljava/lang/Object;>;>;Ljava/lang/Long;Ljava/lang/Long;>; -
in 39
class oshi/driver/windows/registry/HkeyPerformanceDataUtil 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinPerf$PERF_DATA_BLOCK com/sun/jna/platform/win32/WinPerf PERF_DATA_BLOCK public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner com/sun/jna/platform/win32/WinPerf$PERF_OBJECT_TYPE com/sun/jna/platform/win32/WinPerf PERF_OBJECT_TYPE public,static
 inner com/sun/jna/platform/win32/WinPerf$PERF_COUNTER_DEFINITION com/sun/jna/platform/win32/WinPerf PERF_COUNTER_DEFINITION public,static
 inner com/sun/jna/platform/win32/WinPerf$PERF_INSTANCE_DEFINITION com/sun/jna/platform/win32/WinPerf PERF_INSTANCE_DEFINITION public,static
 inner oshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty oshi/util/platform/windows/PerfCounterWildcardQuery PdhCounterWildcardProperty public,static,interface,abstract
 inner com/sun/jna/platform/win32/WinPerf$PERF_COUNTER_BLOCK com/sun/jna/platform/win32/WinPerf PERF_COUNTER_BLOCK public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 method public,static readPerfDataFromRegistry (Ljava/lang/String;Ljava/lang/Class;)Loshi/util/tuples/Triplet; <T:Ljava/lang/Enum<TT;>;:Loshi/util/platform/windows/PerfCounterWildcardQuery$PdhCounterWildcardProperty;>(Ljava/lang/String;Ljava/lang/Class<TT;>;)Loshi/util/tuples/Triplet<Ljava/util/List<Ljava/util/Map<TT;Ljava/lang/Object;>;>;Ljava/lang/Long;Ljava/lang/Long;>; -
in 290
class oshi/driver/windows/registry/HkeyUserData 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner com/sun/jna/platform/win32/Advapi32Util$Account com/sun/jna/platform/win32/Advapi32Util Account public,static
 inner com/sun/jna/platform/win32/WinReg$HKEYByReference com/sun/jna/platform/win32/WinReg HKEYByReference public,static
 inner com/sun/jna/platform/win32/Advapi32Util$InfoKey com/sun/jna/platform/win32/Advapi32Util InfoKey public,static
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 method public,static queryUserSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 2
class oshi/driver/windows/registry/InstalledAppsData 52 public,final,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner com/sun/jna/platform/win32/WinReg$HKEY com/sun/jna/platform/win32/WinReg HKEY public,static
 inner com/sun/jna/platform/win32/WinReg$HKEYByReference com/sun/jna/platform/win32/WinReg HKEYByReference public,static
 method public,static queryInstalledApps ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/ApplicationInfo;>; -
in 1183
class oshi/driver/windows/registry/NetSessionData 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/Netapi32$SESSION_INFO_10 com/sun/jna/platform/win32/Netapi32 SESSION_INFO_10 public,static
 method public,static queryUserSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 39
class oshi/driver/windows/registry/NetSessionData 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/Netapi32$SESSION_INFO_10 com/sun/jna/platform/win32/Netapi32 SESSION_INFO_10 public,static
 method public,static queryUserSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 1183
class oshi/driver/windows/registry/ProcessPerformanceData 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty oshi/driver/windows/perfmon/ProcessInformation ProcessPerformanceProperty public,static,final,enum
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 field public,static,final WIN_HKEY_PERFDATA Ljava/lang/String; - "oshi.os.windows.hkeyperfdata"
 method public,static buildProcessMapFromRegistry (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>; -
 method public,static buildProcessMapFromPerfCounters (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>; -
in 220
class oshi/driver/windows/registry/ProcessPerformanceData 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty oshi/driver/windows/perfmon/ProcessInformation ProcessPerformanceProperty public,static,final,enum
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 method public,static buildProcessMapFromRegistry (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>; -
 method public,static buildProcessMapFromPerfCounters (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>; -
in 60
class oshi/driver/windows/registry/ProcessPerformanceData 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ProcessInformation$ProcessPerformanceProperty oshi/driver/windows/perfmon/ProcessInformation ProcessPerformanceProperty public,static,final,enum
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 method public,static buildProcessMapFromRegistry (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>; -
 method public,static buildProcessMapFromPerfCounters (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>; -
 method public,static buildProcessMapFromPerfCounters (Ljava/util/Collection;Ljava/lang/String;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;Ljava/lang/String;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock;>; -
in 290
class oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock 52 public,super java/lang/Object - -
 inner oshi/driver/windows/registry/ProcessPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ProcessPerformanceData PerfCounterBlock public,static
 method public <init> (Ljava/lang/String;IIJJJJJI)V - -
 method public getName ()Ljava/lang/String; - -
 method public getParentProcessID ()I - -
 method public getPriority ()I - -
 method public getResidentSetSize ()J - -
 method public getStartTime ()J - -
 method public getUpTime ()J - -
 method public getBytesRead ()J - -
 method public getBytesWritten ()J - -
 method public getPageFaults ()J - -
in 1183
class oshi/driver/windows/registry/ProcessWtsData 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTS_PROCESS_INFO_EX com/sun/jna/platform/win32/Wtsapi32 WTS_PROCESS_INFO_EX public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$ProcessXPProperty oshi/driver/windows/wmi/Win32Process ProcessXPProperty public,static,final,enum
 method public,static queryProcessWtsMap (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessWtsData$WtsInfo;>; -
in 39
class oshi/driver/windows/registry/ProcessWtsData 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTS_PROCESS_INFO_EX com/sun/jna/platform/win32/Wtsapi32 WTS_PROCESS_INFO_EX public,static
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$ProcessXPProperty oshi/driver/windows/wmi/Win32Process ProcessXPProperty public,static,final,enum
 method public,static queryProcessWtsMap (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ProcessWtsData$WtsInfo;>; -
in 290
class oshi/driver/windows/registry/ProcessWtsData$WtsInfo 52 public,super java/lang/Object - -
 inner oshi/driver/windows/registry/ProcessWtsData$WtsInfo oshi/driver/windows/registry/ProcessWtsData WtsInfo public,static
 method public <init> (Ljava/lang/String;Ljava/lang/String;IJJJJ)V - -
 method public getName ()Ljava/lang/String; - -
 method public getPath ()Ljava/lang/String; - -
 method public getThreadCount ()I - -
 method public getVirtualSize ()J - -
 method public getKernelTime ()J - -
 method public getUserTime ()J - -
 method public getOpenFiles ()J - -
in 1183
class oshi/driver/windows/registry/SessionWtsData 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTS_SESSION_INFO com/sun/jna/platform/win32/Wtsapi32 WTS_SESSION_INFO public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTSINFO com/sun/jna/platform/win32/Wtsapi32 WTSINFO public,static
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTS_CLIENT_ADDRESS com/sun/jna/platform/win32/Wtsapi32 WTS_CLIENT_ADDRESS public,static
 method public,static queryUserSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 39
class oshi/driver/windows/registry/SessionWtsData 52 public,final,super java/lang/Object - -
 inner oshi/jna/ByRef$CloseablePointerByReference oshi/jna/ByRef CloseablePointerByReference public,static
 inner oshi/jna/ByRef$CloseableIntByReference oshi/jna/ByRef CloseableIntByReference public,static
 inner com/sun/jna/platform/win32/WinNT$HANDLE com/sun/jna/platform/win32/WinNT HANDLE public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTS_SESSION_INFO com/sun/jna/platform/win32/Wtsapi32 WTS_SESSION_INFO public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTSINFO com/sun/jna/platform/win32/Wtsapi32 WTSINFO public,static
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 inner com/sun/jna/platform/win32/WinNT$LARGE_INTEGER com/sun/jna/platform/win32/WinNT LARGE_INTEGER public,static
 inner com/sun/jna/platform/win32/Wtsapi32$WTS_CLIENT_ADDRESS com/sun/jna/platform/win32/Wtsapi32 WTS_CLIENT_ADDRESS public,static
 method public,static queryUserSessions ()Ljava/util/List; ()Ljava/util/List<Loshi/software/os/OSSession;>; -
in 368
class oshi/driver/windows/registry/ThreadPerformanceData 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty oshi/driver/windows/perfmon/ThreadInformation ThreadPerformanceProperty public,static,final,enum
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 method public,static buildThreadMapFromRegistry (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>; -
 method public,static buildThreadMapFromPerfCounters (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>; -
in 60
class oshi/driver/windows/registry/ThreadPerformanceData 52 public,final,super java/lang/Object - -
 inner oshi/driver/windows/perfmon/ThreadInformation$ThreadPerformanceProperty oshi/driver/windows/perfmon/ThreadInformation ThreadPerformanceProperty public,static,final,enum
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 inner com/sun/jna/platform/win32/WinBase$FILETIME com/sun/jna/platform/win32/WinBase FILETIME public,static
 method public,static buildThreadMapFromRegistry (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>; -
 method public,static buildThreadMapFromPerfCounters (Ljava/util/Collection;)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>; -
 method public,static buildThreadMapFromPerfCounters (Ljava/util/Collection;Ljava/lang/String;I)Ljava/util/Map; (Ljava/util/Collection<Ljava/lang/Integer;>;Ljava/lang/String;I)Ljava/util/Map<Ljava/lang/Integer;Loshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock;>; -
in 290
class oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock 52 public,super java/lang/Object - -
 inner oshi/driver/windows/registry/ThreadPerformanceData$PerfCounterBlock oshi/driver/windows/registry/ThreadPerformanceData PerfCounterBlock public,static
 method public <init> (Ljava/lang/String;IIJJJIIIJI)V - -
 method public getName ()Ljava/lang/String; - -
 method public getThreadID ()I - -
 method public getOwningProcessID ()I - -
 method public getStartTime ()J - -
 method public getUserTime ()J - -
 method public getKernelTime ()J - -
 method public getPriority ()I - -
 method public getThreadState ()I - -
 method public getThreadWaitReason ()I - -
 method public getStartAddress ()J - -
 method public getContextSwitches ()I - -
in 290
class oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature TemperatureProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 field public,static,final WMI_NAMESPACE Ljava/lang/String; - "ROOT\\WMI"
 method public,static queryCurrentTemperature ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty;>; -
in 290
class oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty;>;
 inner oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty oshi/driver/windows/wmi/MSAcpiThermalZoneTemperature TemperatureProperty public,static,final,enum
 field public,static,final,enum CURRENTTEMPERATURE Loshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/MSAcpiThermalZoneTemperature$TemperatureProperty; - -
in 290
class oshi/driver/windows/wmi/MSFTStorage 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty oshi/driver/windows/wmi/MSFTStorage StoragePoolProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty oshi/driver/windows/wmi/MSFTStorage StoragePoolToPhysicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty oshi/driver/windows/wmi/MSFTStorage PhysicalDiskProperty public,static,final,enum
 inner oshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty oshi/driver/windows/wmi/MSFTStorage VirtualDiskProperty public,static,final,enum
 method public,static queryStoragePools (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty;>; -
 method public,static queryStoragePoolPhysicalDisks (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty;>; -
 method public,static queryPhysicalDisks (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty;>; -
 method public,static queryVirtualDisks (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty;>; -
in 290
class oshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty;>;
 inner oshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty oshi/driver/windows/wmi/MSFTStorage PhysicalDiskProperty public,static,final,enum
 field public,static,final,enum FRIENDLYNAME Loshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty; -
 field public,static,final,enum PHYSICALLOCATION Loshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty; -
 field public,static,final,enum OBJECTID Loshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/MSFTStorage$PhysicalDiskProperty; - -
in 290
class oshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty;>;
 inner oshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty oshi/driver/windows/wmi/MSFTStorage StoragePoolProperty public,static,final,enum
 field public,static,final,enum FRIENDLYNAME Loshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty; -
 field public,static,final,enum OBJECTID Loshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/MSFTStorage$StoragePoolProperty; - -
in 290
class oshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty;>;
 inner oshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty oshi/driver/windows/wmi/MSFTStorage StoragePoolToPhysicalDiskProperty public,static,final,enum
 field public,static,final,enum STORAGEPOOL Loshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty; -
 field public,static,final,enum PHYSICALDISK Loshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/MSFTStorage$StoragePoolToPhysicalDiskProperty; - -
in 290
class oshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty;>;
 inner oshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty oshi/driver/windows/wmi/MSFTStorage VirtualDiskProperty public,static,final,enum
 field public,static,final,enum FRIENDLYNAME Loshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty; -
 field public,static,final,enum OBJECTID Loshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/MSFTStorage$VirtualDiskProperty; - -
in 290
class oshi/driver/windows/wmi/OhmHardware 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/OhmHardware$IdentifierProperty oshi/driver/windows/wmi/OhmHardware IdentifierProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryHwIdentifier (Loshi/util/platform/windows/WmiQueryHandler;Ljava/lang/String;Ljava/lang/String;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;Ljava/lang/String;Ljava/lang/String;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/OhmHardware$IdentifierProperty;>; -
in 290
class oshi/driver/windows/wmi/OhmHardware$IdentifierProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/OhmHardware$IdentifierProperty;>;
 inner oshi/driver/windows/wmi/OhmHardware$IdentifierProperty oshi/driver/windows/wmi/OhmHardware IdentifierProperty public,static,final,enum
 field public,static,final,enum IDENTIFIER Loshi/driver/windows/wmi/OhmHardware$IdentifierProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/OhmHardware$IdentifierProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/OhmHardware$IdentifierProperty; - -
in 290
class oshi/driver/windows/wmi/OhmSensor 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/OhmSensor$ValueProperty oshi/driver/windows/wmi/OhmSensor ValueProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static querySensorValue (Loshi/util/platform/windows/WmiQueryHandler;Ljava/lang/String;Ljava/lang/String;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;Ljava/lang/String;Ljava/lang/String;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/OhmSensor$ValueProperty;>; -
in 290
class oshi/driver/windows/wmi/OhmSensor$ValueProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/OhmSensor$ValueProperty;>;
 inner oshi/driver/windows/wmi/OhmSensor$ValueProperty oshi/driver/windows/wmi/OhmSensor ValueProperty public,static,final,enum
 field public,static,final,enum VALUE Loshi/driver/windows/wmi/OhmSensor$ValueProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/OhmSensor$ValueProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/OhmSensor$ValueProperty; - -
in 290
class oshi/driver/windows/wmi/Win32BaseBoard 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty oshi/driver/windows/wmi/Win32BaseBoard BaseBoardProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryBaseboardInfo ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty;>; -
in 1186
class oshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty;>;
 inner oshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty oshi/driver/windows/wmi/Win32BaseBoard BaseBoardProperty public,static,final,enum
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 field public,static,final,enum MODEL Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 field public,static,final,enum VERSION Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 field public,static,final,enum SERIALNUMBER Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; - -
in 2
class oshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty;>;
 inner oshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty oshi/driver/windows/wmi/Win32BaseBoard BaseBoardProperty public,static,final,enum
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 field public,static,final,enum MODEL Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 field public,static,final,enum PRODUCT Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 field public,static,final,enum VERSION Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 field public,static,final,enum SERIALNUMBER Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32BaseBoard$BaseBoardProperty; - -
in 290
class oshi/driver/windows/wmi/Win32Bios 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32Bios$BiosSerialProperty oshi/driver/windows/wmi/Win32Bios BiosSerialProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Bios$BiosProperty oshi/driver/windows/wmi/Win32Bios BiosProperty public,static,final,enum
 method public,static querySerialNumber ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Bios$BiosSerialProperty;>; -
 method public,static queryBiosInfo ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Bios$BiosProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32Bios$BiosProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Bios$BiosProperty;>;
 inner oshi/driver/windows/wmi/Win32Bios$BiosProperty oshi/driver/windows/wmi/Win32Bios BiosProperty public,static,final,enum
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32Bios$BiosProperty; -
 field public,static,final,enum NAME Loshi/driver/windows/wmi/Win32Bios$BiosProperty; -
 field public,static,final,enum DESCRIPTION Loshi/driver/windows/wmi/Win32Bios$BiosProperty; -
 field public,static,final,enum VERSION Loshi/driver/windows/wmi/Win32Bios$BiosProperty; -
 field public,static,final,enum RELEASEDATE Loshi/driver/windows/wmi/Win32Bios$BiosProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Bios$BiosProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Bios$BiosProperty; - -
in 290
class oshi/driver/windows/wmi/Win32Bios$BiosSerialProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Bios$BiosSerialProperty;>;
 inner oshi/driver/windows/wmi/Win32Bios$BiosSerialProperty oshi/driver/windows/wmi/Win32Bios BiosSerialProperty public,static,final,enum
 field public,static,final,enum SERIALNUMBER Loshi/driver/windows/wmi/Win32Bios$BiosSerialProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Bios$BiosSerialProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Bios$BiosSerialProperty; - -
in 290
class oshi/driver/windows/wmi/Win32ComputerSystem 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty oshi/driver/windows/wmi/Win32ComputerSystem ComputerSystemProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryComputerSystem ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty;>;
 inner oshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty oshi/driver/windows/wmi/Win32ComputerSystem ComputerSystemProperty public,static,final,enum
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty; -
 field public,static,final,enum MODEL Loshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32ComputerSystem$ComputerSystemProperty; - -
in 290
class oshi/driver/windows/wmi/Win32ComputerSystemProduct 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty oshi/driver/windows/wmi/Win32ComputerSystemProduct ComputerSystemProductProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryIdentifyingNumberUUID ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty;>;
 inner oshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty oshi/driver/windows/wmi/Win32ComputerSystemProduct ComputerSystemProductProperty public,static,final,enum
 field public,static,final,enum IDENTIFYINGNUMBER Loshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty; -
 field public,static,final,enum UUID Loshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32ComputerSystemProduct$ComputerSystemProductProperty; - -
in 290
class oshi/driver/windows/wmi/Win32DiskDrive 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty oshi/driver/windows/wmi/Win32DiskDrive DiskDriveProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryDiskDrive (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty;>;
 inner oshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty oshi/driver/windows/wmi/Win32DiskDrive DiskDriveProperty public,static,final,enum
 field public,static,final,enum INDEX Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; -
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; -
 field public,static,final,enum MODEL Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; -
 field public,static,final,enum NAME Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; -
 field public,static,final,enum SERIALNUMBER Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; -
 field public,static,final,enum SIZE Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32DiskDrive$DiskDriveProperty; - -
in 290
class oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition DriveToPartitionProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryDriveToPartition (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty;>;
 inner oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty oshi/driver/windows/wmi/Win32DiskDriveToDiskPartition DriveToPartitionProperty public,static,final,enum
 field public,static,final,enum ANTECEDENT Loshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty; -
 field public,static,final,enum DEPENDENT Loshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32DiskDriveToDiskPartition$DriveToPartitionProperty; - -
in 290
class oshi/driver/windows/wmi/Win32DiskPartition 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty oshi/driver/windows/wmi/Win32DiskPartition DiskPartitionProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryPartition (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty;>;
 inner oshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty oshi/driver/windows/wmi/Win32DiskPartition DiskPartitionProperty public,static,final,enum
 field public,static,final,enum INDEX Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; -
 field public,static,final,enum DESCRIPTION Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; -
 field public,static,final,enum DEVICEID Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; -
 field public,static,final,enum DISKINDEX Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; -
 field public,static,final,enum NAME Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; -
 field public,static,final,enum SIZE Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; -
 field public,static,final,enum TYPE Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32DiskPartition$DiskPartitionProperty; - -
in 290
class oshi/driver/windows/wmi/Win32Fan 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32Fan$SpeedProperty oshi/driver/windows/wmi/Win32Fan SpeedProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static querySpeed ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Fan$SpeedProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32Fan$SpeedProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Fan$SpeedProperty;>;
 inner oshi/driver/windows/wmi/Win32Fan$SpeedProperty oshi/driver/windows/wmi/Win32Fan SpeedProperty public,static,final,enum
 field public,static,final,enum DESIREDSPEED Loshi/driver/windows/wmi/Win32Fan$SpeedProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Fan$SpeedProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Fan$SpeedProperty; - -
in 290
class oshi/driver/windows/wmi/Win32LogicalDisk 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty oshi/driver/windows/wmi/Win32LogicalDisk LogicalDiskProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryLogicalDisk (Ljava/lang/String;Z)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Ljava/lang/String;Z)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty;>;
 inner oshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty oshi/driver/windows/wmi/Win32LogicalDisk LogicalDiskProperty public,static,final,enum
 field public,static,final,enum ACCESS Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum DESCRIPTION Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum DRIVETYPE Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum FILESYSTEM Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum FREESPACE Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum NAME Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum PROVIDERNAME Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum SIZE Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 field public,static,final,enum VOLUMENAME Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32LogicalDisk$LogicalDiskProperty; - -
in 290
class oshi/driver/windows/wmi/Win32LogicalDiskToPartition 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty oshi/driver/windows/wmi/Win32LogicalDiskToPartition DiskToPartitionProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryDiskToPartition (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Loshi/util/platform/windows/WmiQueryHandler;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty;>;
 inner oshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty oshi/driver/windows/wmi/Win32LogicalDiskToPartition DiskToPartitionProperty public,static,final,enum
 field public,static,final,enum ANTECEDENT Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty; -
 field public,static,final,enum DEPENDENT Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty; -
 field public,static,final,enum ENDINGADDRESS Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty; -
 field public,static,final,enum STARTINGADDRESS Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32LogicalDiskToPartition$DiskToPartitionProperty; - -
in 290
class oshi/driver/windows/wmi/Win32OperatingSystem 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty oshi/driver/windows/wmi/Win32OperatingSystem OSVersionProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryOsVersion ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty;>;
 inner oshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty oshi/driver/windows/wmi/Win32OperatingSystem OSVersionProperty public,static,final,enum
 field public,static,final,enum VERSION Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty; -
 field public,static,final,enum PRODUCTTYPE Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty; -
 field public,static,final,enum BUILDNUMBER Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty; -
 field public,static,final,enum CSDVERSION Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty; -
 field public,static,final,enum SUITEMASK Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32OperatingSystem$OSVersionProperty; - -
in 290
class oshi/driver/windows/wmi/Win32PhysicalMemory 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8 oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryPropertyWin8 public,static,final,enum
 method public,static queryphysicalMemory ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty;>; -
 method public,static queryphysicalMemoryWin8 ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8;>; -
in 1184
class oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty;>;
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryProperty public,static,final,enum
 field public,static,final,enum BANKLABEL Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum CAPACITY Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum SPEED Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum SMBIOSMEMORYTYPE Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; - -
in 28
class oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty;>;
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryProperty public,static,final,enum
 field public,static,final,enum BANKLABEL Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum CAPACITY Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum SPEED Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum PARTNUMBER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum SMBIOSMEMORYTYPE Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 field public,static,final,enum SERIALNUMBER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryProperty; - -
in 1184
class oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8;>;
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8 oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryPropertyWin8 public,static,final,enum
 field public,static,final,enum BANKLABEL Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum CAPACITY Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum SPEED Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum MEMORYTYPE Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; - -
in 28
class oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8;>;
 inner oshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8 oshi/driver/windows/wmi/Win32PhysicalMemory PhysicalMemoryPropertyWin8 public,static,final,enum
 field public,static,final,enum BANKLABEL Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum CAPACITY Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum SPEED Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum MANUFACTURER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum MEMORYTYPE Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum PARTNUMBER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 field public,static,final,enum SERIALNUMBER Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32PhysicalMemory$PhysicalMemoryPropertyWin8; - -
in 1183
class oshi/driver/windows/wmi/Win32Process 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$ProcessXPProperty oshi/driver/windows/wmi/Win32Process ProcessXPProperty public,static,final,enum
 method public,static queryCommandLines (Ljava/util/Set;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Ljava/util/Set<Ljava/lang/Integer;>;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Process$CommandLineProperty;>; -
 method public,static queryProcesses (Ljava/util/Collection;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Ljava/util/Collection<Ljava/lang/Integer;>;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty;>; -
in 39
class oshi/driver/windows/wmi/Win32Process 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$ProcessXPProperty oshi/driver/windows/wmi/Win32Process ProcessXPProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static queryCommandLines (Ljava/util/Set;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Ljava/util/Set<Ljava/lang/Integer;>;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Process$CommandLineProperty;>; -
 method public,static queryProcesses (Ljava/util/Collection;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; (Ljava/util/Collection<Ljava/lang/Integer;>;)Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32Process$CommandLineProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Process$CommandLineProperty;>;
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 field public,static,final,enum PROCESSID Loshi/driver/windows/wmi/Win32Process$CommandLineProperty; -
 field public,static,final,enum COMMANDLINE Loshi/driver/windows/wmi/Win32Process$CommandLineProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Process$CommandLineProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Process$CommandLineProperty; - -
in 290
class oshi/driver/windows/wmi/Win32Process$ProcessXPProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty;>;
 inner oshi/driver/windows/wmi/Win32Process$ProcessXPProperty oshi/driver/windows/wmi/Win32Process ProcessXPProperty public,static,final,enum
 field public,static,final,enum PROCESSID Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 field public,static,final,enum NAME Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 field public,static,final,enum KERNELMODETIME Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 field public,static,final,enum USERMODETIME Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 field public,static,final,enum THREADCOUNT Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 field public,static,final,enum PAGEFILEUSAGE Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 field public,static,final,enum HANDLECOUNT Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 field public,static,final,enum EXECUTABLEPATH Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Process$ProcessXPProperty; - -
in 290
class oshi/driver/windows/wmi/Win32ProcessCached 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Process$CommandLineProperty oshi/driver/windows/wmi/Win32Process CommandLineProperty public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static getInstance ()Loshi/driver/windows/wmi/Win32ProcessCached; - -
 method public getCommandLine (IJ)Ljava/lang/String; - -
in 290
class oshi/driver/windows/wmi/Win32Processor 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32Processor$VoltProperty oshi/driver/windows/wmi/Win32Processor VoltProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 inner oshi/driver/windows/wmi/Win32Processor$BitnessProperty oshi/driver/windows/wmi/Win32Processor BitnessProperty public,static,final,enum
 method public,static queryVoltage ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Processor$VoltProperty;>; -
 method public,static queryProcessorId ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty;>; -
 method public,static queryBitness ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32Processor$BitnessProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32Processor$BitnessProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Processor$BitnessProperty;>;
 inner oshi/driver/windows/wmi/Win32Processor$BitnessProperty oshi/driver/windows/wmi/Win32Processor BitnessProperty public,static,final,enum
 field public,static,final,enum ADDRESSWIDTH Loshi/driver/windows/wmi/Win32Processor$BitnessProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Processor$BitnessProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Processor$BitnessProperty; - -
in 290
class oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty;>;
 inner oshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty oshi/driver/windows/wmi/Win32Processor ProcessorIdProperty public,static,final,enum
 field public,static,final,enum PROCESSORID Loshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Processor$ProcessorIdProperty; - -
in 290
class oshi/driver/windows/wmi/Win32Processor$VoltProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32Processor$VoltProperty;>;
 inner oshi/driver/windows/wmi/Win32Processor$VoltProperty oshi/driver/windows/wmi/Win32Processor VoltProperty public,static,final,enum
 field public,static,final,enum CURRENTVOLTAGE Loshi/driver/windows/wmi/Win32Processor$VoltProperty; -
 field public,static,final,enum VOLTAGECAPS Loshi/driver/windows/wmi/Win32Processor$VoltProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32Processor$VoltProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32Processor$VoltProperty; - -
in 290
class oshi/driver/windows/wmi/Win32VideoController 52 public,final,super java/lang/Object - -
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiQuery com/sun/jna/platform/win32/COM/WbemcliUtil WmiQuery public,static
 inner oshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty oshi/driver/windows/wmi/Win32VideoController VideoControllerProperty public,static,final,enum
 inner com/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult com/sun/jna/platform/win32/COM/WbemcliUtil WmiResult public
 method public,static queryVideoController ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult; ()Lcom/sun/jna/platform/win32/COM/WbemcliUtil$WmiResult<Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty;>; -
in 290
class oshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty;>;
 inner oshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty oshi/driver/windows/wmi/Win32VideoController VideoControllerProperty public,static,final,enum
 field public,static,final,enum ADAPTERCOMPATIBILITY Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty; -
 field public,static,final,enum ADAPTERRAM Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty; -
 field public,static,final,enum DRIVERVERSION Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty; -
 field public,static,final,enum NAME Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty; -
 field public,static,final,enum PNPDEVICEID Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty; -
 method public,static values ()[Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty; - -
 method public,static valueOf (Ljava/lang/String;)Loshi/driver/windows/wmi/Win32VideoController$VideoControllerProperty; - -
