cg-stub-db 1
in 24
class jline/console/ConsoleKeys 49 public,super java/lang/Object - -
 method public <init> (Ljava/lang/String;Ljava/net/URL;)V - -
 method protected isViEditMode ()Z - -
 method protected setKeyMap (Ljava/lang/String;)Z - -
 method protected getKeyMaps ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljline/console/KeyMap;>; -
 method protected getKeys ()Ljline/console/KeyMap; - -
 method protected setKeys (Ljline/console/KeyMap;)V - -
 method protected getViEditMode ()Z - -
 method protected loadKeys (Ljava/lang/String;Ljava/net/URL;)V - -
 method public getVariable (Ljava/lang/String;)Ljava/lang/String; - -
in 24
class jline/console/ConsoleReader 49 public,super java/lang/Object - -
 inner jline/console/ConsoleReader$State jline/console/ConsoleReader State private,static,final,enum
 inner jline/console/history/History$Entry jline/console/history/History Entry public,static,interface,abstract
 field public,static,final JLINE_NOBELL Ljava/lang/String; - "jline.nobell"
 field public,static,final JLINE_ESC_TIMEOUT Ljava/lang/String; - "jline.esc.timeout"
 field public,static,final JLINE_INPUTRC Ljava/lang/String; - "jline.inputrc"
 field public,static,final INPUT_RC Ljava/lang/String; - ".inputrc"
 field public,static,final DEFAULT_INPUT_RC Ljava/lang/String; - "/etc/inputrc"
 field public,static,final BACKSPACE C - I8
 field public,static,final RESET_LINE C - I13
 field public,static,final KEYBOARD_BELL C - I7
 field public,static,final NULL_MASK C - I0
 field public,static,final TAB_WIDTH I - I8
 field public,static,final JLINE_COMPLETION_THRESHOLD Ljava/lang/String; - "jline.completion.threshold"
 field public,static,final CR Ljava/lang/String; -
 method public <init> ()V - java/io/IOException
 method public <init> (Ljava/io/InputStream;Ljava/io/OutputStream;)V - java/io/IOException
 method public <init> (Ljava/io/InputStream;Ljava/io/OutputStream;Ljline/Terminal;)V - java/io/IOException
 method public <init> (Ljava/lang/String;Ljava/io/InputStream;Ljava/io/OutputStream;Ljline/Terminal;)V - java/io/IOException
 method public <init> (Ljava/lang/String;Ljava/io/InputStream;Ljava/io/OutputStream;Ljline/Terminal;Ljava/lang/String;)V - java/io/IOException
 method public getKeys ()Ljline/console/KeyMap; - -
 method public shutdown ()V - -
 method protected finalize ()V - java/lang/Throwable
 method public getInput ()Ljava/io/InputStream; - -
 method public getOutput ()Ljava/io/Writer; - -
 method public getTerminal ()Ljline/Terminal; - -
 method public getCursorBuffer ()Ljline/console/CursorBuffer; - -
 method public setExpandEvents (Z)V - -
 method public getExpandEvents ()Z - -
 method public setCopyPasteDetection (Z)V - -
 method public isCopyPasteDetectionEnabled ()Z - -
 method public setBellEnabled (Z)V - -
 method public getBellEnabled ()Z - -
 method public setHandleUserInterrupt (Z)V - -
 method public getHandleUserInterrupt ()Z - -
 method public setHandleLitteralNext (Z)V - -
 method public getHandleLitteralNext ()Z - -
 method public setCommentBegin (Ljava/lang/String;)V - -
 method public getCommentBegin ()Ljava/lang/String; - -
 method public setPrompt (Ljava/lang/String;)V - -
 method public getPrompt ()Ljava/lang/String; - -
 method public setEchoCharacter (Ljava/lang/Character;)V - -
 method public getEchoCharacter ()Ljava/lang/Character; - -
 method protected,final resetLine ()Z - java/io/IOException
 method public setCursorPosition (I)Z - java/io/IOException
 method public drawLine ()V - java/io/IOException
 method public redrawLine ()V - java/io/IOException
 method protected expandEvents (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public putString (Ljava/lang/CharSequence;)V - java/io/IOException
 method protected back (I)V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public backspace ()Z - java/io/IOException
 method protected moveToEnd ()Z - java/io/IOException
 method public setParenBlinkTimeout (I)V - -
 method public isKeyMap (Ljava/lang/String;)Z - -
 method public accept ()Ljava/lang/String; - java/io/IOException
 method public moveCursor (I)I - java/io/IOException
 method public readCharacter ()I - java/io/IOException
 method public readCharacter (Z)I - java/io/IOException
 method public,varargs readCharacter ([C)I - java/io/IOException
 method public,varargs readCharacter (Z[C)I - java/io/IOException
 method public readBinding (Ljline/console/KeyMap;)Ljava/lang/Object; - java/io/IOException
 method public getLastBinding ()Ljava/lang/String; - -
 method public readLine ()Ljava/lang/String; - java/io/IOException
 method public readLine (Ljava/lang/Character;)Ljava/lang/String; - java/io/IOException
 method public readLine (Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public readLine (Ljava/lang/String;Ljava/lang/Character;)Ljava/lang/String; - java/io/IOException
 method public setKeyMap (Ljava/lang/String;)Z - -
 method public getKeyMap ()Ljava/lang/String; - -
 method public readLine (Ljava/lang/String;Ljava/lang/Character;Ljava/lang/String;)Ljava/lang/String; - java/io/IOException
 method public addCompleter (Ljline/console/completer/Completer;)Z - -
 method public removeCompleter (Ljline/console/completer/Completer;)Z - -
 method public getCompleters ()Ljava/util/Collection; ()Ljava/util/Collection<Ljline/console/completer/Completer;>; -
 method public setCompletionHandler (Ljline/console/completer/CompletionHandler;)V - -
 method public getCompletionHandler ()Ljline/console/completer/CompletionHandler; - -
 method protected complete ()Z - java/io/IOException
 method protected printCompletionCandidates ()V - java/io/IOException
 method public setAutoprintThreshold (I)V - -
 method public getAutoprintThreshold ()I - -
 method public setPaginationEnabled (Z)V - -
 method public isPaginationEnabled ()Z - -
 method public setHistory (Ljline/console/history/History;)V - -
 method public getHistory ()Ljline/console/history/History; - -
 method public setHistoryEnabled (Z)V - -
 method public isHistoryEnabled ()Z - -
 method public print (Ljava/lang/CharSequence;)V - java/io/IOException
 method public println (Ljava/lang/CharSequence;)V - java/io/IOException
 method public println ()V - java/io/IOException
 method public delete ()Z - java/io/IOException
 method public killLine ()Z - java/io/IOException
 method public yank ()Z - java/io/IOException
 method public yankPop ()Z - java/io/IOException
 method public clearScreen ()Z - java/io/IOException
 method public beep ()V - java/io/IOException
 method public paste ()Z - java/io/IOException
 method public addTriggeredAction (CLjava/awt/event/ActionListener;)V - -
 method public printColumns (Ljava/util/Collection;)V (Ljava/util/Collection<+Ljava/lang/CharSequence;>;)V java/io/IOException
 method public resetPromptLine (Ljava/lang/String;Ljava/lang/String;I)V - java/io/IOException
 method public printSearchStatus (Ljava/lang/String;Ljava/lang/String;)V - java/io/IOException
 method public printForwardSearchStatus (Ljava/lang/String;Ljava/lang/String;)V - java/io/IOException
 method public restoreLine (Ljava/lang/String;I)V - java/io/IOException
 method public searchBackwards (Ljava/lang/String;I)I - -
 method public searchBackwards (Ljava/lang/String;)I - -
 method public searchBackwards (Ljava/lang/String;IZ)I - -
 method public searchForwards (Ljava/lang/String;I)I - -
 method public searchForwards (Ljava/lang/String;)I - -
 method public searchForwards (Ljava/lang/String;IZ)I - -
in 24
class jline/console/ConsoleReader$State 49 final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljline/console/ConsoleReader$State;>;
 inner jline/console/ConsoleReader$State jline/console/ConsoleReader State private,static,final,enum
 field public,static,final,enum NORMAL Ljline/console/ConsoleReader$State; -
 field public,static,final,enum SEARCH Ljline/console/ConsoleReader$State; -
 field public,static,final,enum FORWARD_SEARCH Ljline/console/ConsoleReader$State; -
 field public,static,final,enum VI_YANK_TO Ljline/console/ConsoleReader$State; -
 field public,static,final,enum VI_DELETE_TO Ljline/console/ConsoleReader$State; -
 field public,static,final,enum VI_CHANGE_TO Ljline/console/ConsoleReader$State; -
 method public,static values ()[Ljline/console/ConsoleReader$State; - -
 method public,static valueOf (Ljava/lang/String;)Ljline/console/ConsoleReader$State; - -
in 24
class jline/console/CursorBuffer 49 public,super java/lang/Object - -
 field public cursor I -
 field public,final buffer Ljava/lang/StringBuilder; -
 method public <init> ()V - -
 method public copy ()Ljline/console/CursorBuffer; - -
 method public isOverTyping ()Z - -
 method public setOverTyping (Z)V - -
 method public length ()I - -
 method public nextChar ()C - -
 method public current ()C - -
 method public write (C)V - -
 method public write (Ljava/lang/CharSequence;)V - -
 method public clear ()Z - -
 method public upToCursor ()Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 24
class jline/console/KeyMap 49 public,super java/lang/Object - -
 field public,static,final VI_MOVE Ljava/lang/String; - "vi-move"
 field public,static,final VI_INSERT Ljava/lang/String; - "vi-insert"
 field public,static,final EMACS Ljava/lang/String; - "emacs"
 field public,static,final EMACS_STANDARD Ljava/lang/String; - "emacs-standard"
 field public,static,final EMACS_CTLX Ljava/lang/String; - "emacs-ctlx"
 field public,static,final EMACS_META Ljava/lang/String; - "emacs-meta"
 field public,static,final CTRL_D C - I4
 field public,static,final CTRL_G C - I7
 field public,static,final CTRL_H C - I8
 field public,static,final CTRL_I C - I9
 field public,static,final CTRL_J C - I10
 field public,static,final CTRL_M C - I13
 field public,static,final CTRL_R C - I18
 field public,static,final CTRL_S C - I19
 field public,static,final CTRL_U C - I21
 field public,static,final CTRL_X C - I24
 field public,static,final CTRL_Y C - I25
 field public,static,final ESCAPE C - I27
 field public,static,final CTRL_OB C - I27
 field public,static,final CTRL_CB C - I29
 field public,static,final DELETE I - I127
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;Z)V - -
 method protected <init> (Ljava/lang/String;[Ljava/lang/Object;Z)V - -
 method public isViKeyMap ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public getAnotherKey ()Ljava/lang/Object; - -
 method public from (Ljline/console/KeyMap;)V - -
 method public getBound (Ljava/lang/CharSequence;)Ljava/lang/Object; - -
 method public bindIfNotBound (Ljava/lang/CharSequence;Ljava/lang/Object;)V - -
 method public bind (Ljava/lang/CharSequence;Ljava/lang/Object;)V - -
 method public setBlinkMatchingParen (Z)V - -
 method public,static isMeta (C)Z - -
 method public,static unMeta (C)C - -
 method public,static meta (C)C - -
 method public,static keyMaps ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljline/console/KeyMap;>; -
 method public,static emacs ()Ljline/console/KeyMap; - -
 method public,static emacsCtrlX ()Ljline/console/KeyMap; - -
 method public,static emacsMeta ()Ljline/console/KeyMap; - -
 method public,static viInsertion ()Ljline/console/KeyMap; - -
 method public,static viMovement ()Ljline/console/KeyMap; - -
in 24
class jline/console/KillRing 49 public,final,super java/lang/Object - -
 method public <init> (I)V - -
 method public <init> ()V - -
 method public resetLastYank ()V - -
 method public resetLastKill ()V - -
 method public lastYank ()Z - -
 method public add (Ljava/lang/String;)V - -
 method public addBackwards (Ljava/lang/String;)V - -
 method public yank ()Ljava/lang/String; - -
 method public yankPop ()Ljava/lang/String; - -
in 24
class jline/console/Operation 49 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljline/console/Operation;>;
 field public,static,final,enum ABORT Ljline/console/Operation; -
 field public,static,final,enum ACCEPT_LINE Ljline/console/Operation; -
 field public,static,final,enum ARROW_KEY_PREFIX Ljline/console/Operation; -
 field public,static,final,enum BACKWARD_BYTE Ljline/console/Operation; -
 field public,static,final,enum BACKWARD_CHAR Ljline/console/Operation; -
 field public,static,final,enum BACKWARD_DELETE_CHAR Ljline/console/Operation; -
 field public,static,final,enum BACKWARD_KILL_LINE Ljline/console/Operation; -
 field public,static,final,enum BACKWARD_KILL_WORD Ljline/console/Operation; -
 field public,static,final,enum BACKWARD_WORD Ljline/console/Operation; -
 field public,static,final,enum BEGINNING_OF_HISTORY Ljline/console/Operation; -
 field public,static,final,enum BEGINNING_OF_LINE Ljline/console/Operation; -
 field public,static,final,enum CALL_LAST_KBD_MACRO Ljline/console/Operation; -
 field public,static,final,enum CAPITALIZE_WORD Ljline/console/Operation; -
 field public,static,final,enum CHARACTER_SEARCH Ljline/console/Operation; -
 field public,static,final,enum CHARACTER_SEARCH_BACKWARD Ljline/console/Operation; -
 field public,static,final,enum CLEAR_SCREEN Ljline/console/Operation; -
 field public,static,final,enum COMPLETE Ljline/console/Operation; -
 field public,static,final,enum COPY_BACKWARD_WORD Ljline/console/Operation; -
 field public,static,final,enum COPY_FORWARD_WORD Ljline/console/Operation; -
 field public,static,final,enum COPY_REGION_AS_KILL Ljline/console/Operation; -
 field public,static,final,enum DELETE_CHAR Ljline/console/Operation; -
 field public,static,final,enum DELETE_CHAR_OR_LIST Ljline/console/Operation; -
 field public,static,final,enum DELETE_HORIZONTAL_SPACE Ljline/console/Operation; -
 field public,static,final,enum DIGIT_ARGUMENT Ljline/console/Operation; -
 field public,static,final,enum DO_LOWERCASE_VERSION Ljline/console/Operation; -
 field public,static,final,enum DOWNCASE_WORD Ljline/console/Operation; -
 field public,static,final,enum DUMP_FUNCTIONS Ljline/console/Operation; -
 field public,static,final,enum DUMP_MACROS Ljline/console/Operation; -
 field public,static,final,enum DUMP_VARIABLES Ljline/console/Operation; -
 field public,static,final,enum EMACS_EDITING_MODE Ljline/console/Operation; -
 field public,static,final,enum END_KBD_MACRO Ljline/console/Operation; -
 field public,static,final,enum END_OF_HISTORY Ljline/console/Operation; -
 field public,static,final,enum END_OF_LINE Ljline/console/Operation; -
 field public,static,final,enum EXCHANGE_POINT_AND_MARK Ljline/console/Operation; -
 field public,static,final,enum EXIT_OR_DELETE_CHAR Ljline/console/Operation; -
 field public,static,final,enum FORWARD_BACKWARD_DELETE_CHAR Ljline/console/Operation; -
 field public,static,final,enum FORWARD_BYTE Ljline/console/Operation; -
 field public,static,final,enum FORWARD_CHAR Ljline/console/Operation; -
 field public,static,final,enum FORWARD_SEARCH_HISTORY Ljline/console/Operation; -
 field public,static,final,enum FORWARD_WORD Ljline/console/Operation; -
 field public,static,final,enum HISTORY_SEARCH_BACKWARD Ljline/console/Operation; -
 field public,static,final,enum HISTORY_SEARCH_FORWARD Ljline/console/Operation; -
 field public,static,final,enum INSERT_CLOSE_CURLY Ljline/console/Operation; -
 field public,static,final,enum INSERT_CLOSE_PAREN Ljline/console/Operation; -
 field public,static,final,enum INSERT_CLOSE_SQUARE Ljline/console/Operation; -
 field public,static,final,enum INSERT_COMMENT Ljline/console/Operation; -
 field public,static,final,enum INSERT_COMPLETIONS Ljline/console/Operation; -
 field public,static,final,enum INTERRUPT Ljline/console/Operation; -
 field public,static,final,enum KILL_WHOLE_LINE Ljline/console/Operation; -
 field public,static,final,enum KILL_LINE Ljline/console/Operation; -
 field public,static,final,enum KILL_REGION Ljline/console/Operation; -
 field public,static,final,enum KILL_WORD Ljline/console/Operation; -
 field public,static,final,enum MENU_COMPLETE Ljline/console/Operation; -
 field public,static,final,enum MENU_COMPLETE_BACKWARD Ljline/console/Operation; -
 field public,static,final,enum NEXT_HISTORY Ljline/console/Operation; -
 field public,static,final,enum NON_INCREMENTAL_FORWARD_SEARCH_HISTORY Ljline/console/Operation; -
 field public,static,final,enum NON_INCREMENTAL_REVERSE_SEARCH_HISTORY Ljline/console/Operation; -
 field public,static,final,enum NON_INCREMENTAL_FORWARD_SEARCH_HISTORY_AGAIN Ljline/console/Operation; -
 field public,static,final,enum NON_INCREMENTAL_REVERSE_SEARCH_HISTORY_AGAIN Ljline/console/Operation; -
 field public,static,final,enum OLD_MENU_COMPLETE Ljline/console/Operation; -
 field public,static,final,enum OVERWRITE_MODE Ljline/console/Operation; -
 field public,static,final,enum PASTE_FROM_CLIPBOARD Ljline/console/Operation; -
 field public,static,final,enum POSSIBLE_COMPLETIONS Ljline/console/Operation; -
 field public,static,final,enum PREVIOUS_HISTORY Ljline/console/Operation; -
 field public,static,final,enum QUOTED_INSERT Ljline/console/Operation; -
 field public,static,final,enum QUIT Ljline/console/Operation; -
 field public,static,final,enum RE_READ_INIT_FILE Ljline/console/Operation; -
 field public,static,final,enum REDRAW_CURRENT_LINE Ljline/console/Operation; -
 field public,static,final,enum REVERSE_SEARCH_HISTORY Ljline/console/Operation; -
 field public,static,final,enum REVERT_LINE Ljline/console/Operation; -
 field public,static,final,enum SELF_INSERT Ljline/console/Operation; -
 field public,static,final,enum SET_MARK Ljline/console/Operation; -
 field public,static,final,enum SKIP_CSI_SEQUENCE Ljline/console/Operation; -
 field public,static,final,enum START_KBD_MACRO Ljline/console/Operation; -
 field public,static,final,enum TAB_INSERT Ljline/console/Operation; -
 field public,static,final,enum TILDE_EXPAND Ljline/console/Operation; -
 field public,static,final,enum TRANSPOSE_CHARS Ljline/console/Operation; -
 field public,static,final,enum TRANSPOSE_WORDS Ljline/console/Operation; -
 field public,static,final,enum TTY_STATUS Ljline/console/Operation; -
 field public,static,final,enum UNDO Ljline/console/Operation; -
 field public,static,final,enum UNIVERSAL_ARGUMENT Ljline/console/Operation; -
 field public,static,final,enum UNIX_FILENAME_RUBOUT Ljline/console/Operation; -
 field public,static,final,enum UNIX_LINE_DISCARD Ljline/console/Operation; -
 field public,static,final,enum UNIX_WORD_RUBOUT Ljline/console/Operation; -
 field public,static,final,enum UPCASE_WORD Ljline/console/Operation; -
 field public,static,final,enum YANK Ljline/console/Operation; -
 field public,static,final,enum YANK_LAST_ARG Ljline/console/Operation; -
 field public,static,final,enum YANK_NTH_ARG Ljline/console/Operation; -
 field public,static,final,enum YANK_POP Ljline/console/Operation; -
 field public,static,final,enum VI_APPEND_EOL Ljline/console/Operation; -
 field public,static,final,enum VI_APPEND_MODE Ljline/console/Operation; -
 field public,static,final,enum VI_ARG_DIGIT Ljline/console/Operation; -
 field public,static,final,enum VI_BACK_TO_INDENT Ljline/console/Operation; -
 field public,static,final,enum VI_BACKWARD_BIGWORD Ljline/console/Operation; -
 field public,static,final,enum VI_BACKWARD_WORD Ljline/console/Operation; -
 field public,static,final,enum VI_BWORD Ljline/console/Operation; -
 field public,static,final,enum VI_CHANGE_CASE Ljline/console/Operation; -
 field public,static,final,enum VI_CHANGE_CHAR Ljline/console/Operation; -
 field public,static,final,enum VI_CHANGE_TO Ljline/console/Operation; -
 field public,static,final,enum VI_CHANGE_TO_EOL Ljline/console/Operation; -
 field public,static,final,enum VI_CHAR_SEARCH Ljline/console/Operation; -
 field public,static,final,enum VI_COLUMN Ljline/console/Operation; -
 field public,static,final,enum VI_COMPLETE Ljline/console/Operation; -
 field public,static,final,enum VI_DELETE Ljline/console/Operation; -
 field public,static,final,enum VI_DELETE_TO Ljline/console/Operation; -
 field public,static,final,enum VI_DELETE_TO_EOL Ljline/console/Operation; -
 field public,static,final,enum VI_EDITING_MODE Ljline/console/Operation; -
 field public,static,final,enum VI_END_BIGWORD Ljline/console/Operation; -
 field public,static,final,enum VI_END_WORD Ljline/console/Operation; -
 field public,static,final,enum VI_EOF_MAYBE Ljline/console/Operation; -
 field public,static,final,enum VI_EWORD Ljline/console/Operation; -
 field public,static,final,enum VI_FWORD Ljline/console/Operation; -
 field public,static,final,enum VI_FETCH_HISTORY Ljline/console/Operation; -
 field public,static,final,enum VI_FIRST_PRINT Ljline/console/Operation; -
 field public,static,final,enum VI_FORWARD_BIGWORD Ljline/console/Operation; -
 field public,static,final,enum VI_FORWARD_WORD Ljline/console/Operation; -
 field public,static,final,enum VI_GOTO_MARK Ljline/console/Operation; -
 field public,static,final,enum VI_INSERT_BEG Ljline/console/Operation; -
 field public,static,final,enum VI_INSERTION_MODE Ljline/console/Operation; -
 field public,static,final,enum VI_KILL_WHOLE_LINE Ljline/console/Operation; -
 field public,static,final,enum VI_MATCH Ljline/console/Operation; -
 field public,static,final,enum VI_MOVEMENT_MODE Ljline/console/Operation; -
 field public,static,final,enum VI_NEXT_WORD Ljline/console/Operation; -
 field public,static,final,enum VI_OVERSTRIKE Ljline/console/Operation; -
 field public,static,final,enum VI_OVERSTRIKE_DELETE Ljline/console/Operation; -
 field public,static,final,enum VI_PREV_WORD Ljline/console/Operation; -
 field public,static,final,enum VI_PUT Ljline/console/Operation; -
 field public,static,final,enum VI_REDO Ljline/console/Operation; -
 field public,static,final,enum VI_REPLACE Ljline/console/Operation; -
 field public,static,final,enum VI_RUBOUT Ljline/console/Operation; -
 field public,static,final,enum VI_SEARCH Ljline/console/Operation; -
 field public,static,final,enum VI_SEARCH_AGAIN Ljline/console/Operation; -
 field public,static,final,enum VI_SET_MARK Ljline/console/Operation; -
 field public,static,final,enum VI_SUBST Ljline/console/Operation; -
 field public,static,final,enum VI_TILDE_EXPAND Ljline/console/Operation; -
 field public,static,final,enum VI_YANK_ARG Ljline/console/Operation; -
 field public,static,final,enum VI_YANK_TO Ljline/console/Operation; -
 field public,static,final,enum VI_MOVE_ACCEPT_LINE Ljline/console/Operation; -
 field public,static,final,enum VI_NEXT_HISTORY Ljline/console/Operation; -
 field public,static,final,enum VI_PREVIOUS_HISTORY Ljline/console/Operation; -
 field public,static,final,enum VI_INSERT_COMMENT Ljline/console/Operation; -
 field public,static,final,enum VI_BEGINNING_OF_LINE_OR_ARG_DIGIT Ljline/console/Operation; -
 method public,static values ()[Ljline/console/Operation; - -
 method public,static valueOf (Ljava/lang/String;)Ljline/console/Operation; - -
in 24
class jline/console/UserInterruptException 49 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;)V - -
 method public getPartialLine ()Ljava/lang/String; - -
in 24
class jline/console/WCWidth 49 public,super java/lang/Object - -
 inner jline/console/WCWidth$Interval jline/console/WCWidth Interval private,static
 method public <init> ()V - -
 method public,static wcwidth (I)I - -
in 24
class jline/console/WCWidth$Interval 49 super java/lang/Object - -
 inner jline/console/WCWidth$Interval jline/console/WCWidth Interval private,static
 field public,final first I -
 field public,final last I -
 method public <init> (II)V - -
in 24
class jline/console/completer/AggregateCompleter 49 public,super java/lang/Object jline/console/completer/Completer -
 inner jline/console/completer/AggregateCompleter$Completion jline/console/completer/AggregateCompleter Completion private
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Ljline/console/completer/Completer;>;)V -
 method public,varargs <init> ([Ljline/console/completer/Completer;)V - -
 method public getCompleters ()Ljava/util/Collection; ()Ljava/util/Collection<Ljline/console/completer/Completer;>; -
 method public complete (Ljava/lang/String;ILjava/util/List;)I (Ljava/lang/String;ILjava/util/List<Ljava/lang/CharSequence;>;)I -
 method public toString ()Ljava/lang/String; - -
in 24
class jline/console/completer/AggregateCompleter$Completion 49 super java/lang/Object - -
 inner jline/console/completer/AggregateCompleter$Completion jline/console/completer/AggregateCompleter Completion private
 field public,final candidates Ljava/util/List; Ljava/util/List<Ljava/lang/CharSequence;>;
 field public cursor I -
 method public <init> (Ljline/console/completer/AggregateCompleter;Ljava/util/List;)V (Ljava/util/List<Ljava/lang/CharSequence;>;)V -
 method public complete (Ljline/console/completer/Completer;Ljava/lang/String;I)V - -
in 24
class jline/console/completer/AnsiStringsCompleter 49 public,super java/lang/Object jline/console/completer/Completer -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Ljava/lang/String;>;)V -
 method public,varargs <init> ([Ljava/lang/String;)V - -
 method public getStrings ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public complete (Ljava/lang/String;ILjava/util/List;)I (Ljava/lang/String;ILjava/util/List<Ljava/lang/CharSequence;>;)I -
in 24
class jline/console/completer/ArgumentCompleter 49 public,super java/lang/Object jline/console/completer/Completer -
 inner jline/console/completer/ArgumentCompleter$ArgumentList jline/console/completer/ArgumentCompleter ArgumentList public,static
 inner jline/console/completer/ArgumentCompleter$WhitespaceArgumentDelimiter jline/console/completer/ArgumentCompleter WhitespaceArgumentDelimiter public,static
 inner jline/console/completer/ArgumentCompleter$AbstractArgumentDelimiter jline/console/completer/ArgumentCompleter AbstractArgumentDelimiter public,static,abstract
 inner jline/console/completer/ArgumentCompleter$ArgumentDelimiter jline/console/completer/ArgumentCompleter ArgumentDelimiter public,static,interface,abstract
 method public <init> (Ljline/console/completer/ArgumentCompleter$ArgumentDelimiter;Ljava/util/Collection;)V (Ljline/console/completer/ArgumentCompleter$ArgumentDelimiter;Ljava/util/Collection<Ljline/console/completer/Completer;>;)V -
 method public,varargs <init> (Ljline/console/completer/ArgumentCompleter$ArgumentDelimiter;[Ljline/console/completer/Completer;)V - -
 method public,varargs <init> ([Ljline/console/completer/Completer;)V - -
 method public <init> (Ljava/util/List;)V (Ljava/util/List<Ljline/console/completer/Completer;>;)V -
 method public setStrict (Z)V - -
 method public isStrict ()Z - -
 method public getDelimiter ()Ljline/console/completer/ArgumentCompleter$ArgumentDelimiter; - -
 method public getCompleters ()Ljava/util/List; ()Ljava/util/List<Ljline/console/completer/Completer;>; -
 method public complete (Ljava/lang/String;ILjava/util/List;)I (Ljava/lang/String;ILjava/util/List<Ljava/lang/CharSequence;>;)I -
in 24
class jline/console/completer/ArgumentCompleter$AbstractArgumentDelimiter 49 public,super,abstract java/lang/Object jline/console/completer/ArgumentCompleter$ArgumentDelimiter -
 inner jline/console/completer/ArgumentCompleter$AbstractArgumentDelimiter jline/console/completer/ArgumentCompleter AbstractArgumentDelimiter public,static,abstract
 inner jline/console/completer/ArgumentCompleter$ArgumentList jline/console/completer/ArgumentCompleter ArgumentList public,static
 inner jline/console/completer/ArgumentCompleter$ArgumentDelimiter jline/console/completer/ArgumentCompleter ArgumentDelimiter public,static,interface,abstract
 method public <init> ()V - -
 method public setQuoteChars ([C)V - -
 method public getQuoteChars ()[C - -
 method public setEscapeChars ([C)V - -
 method public getEscapeChars ()[C - -
 method public delimit (Ljava/lang/CharSequence;I)Ljline/console/completer/ArgumentCompleter$ArgumentList; - -
 method public isDelimiter (Ljava/lang/CharSequence;I)Z - -
 method public isQuoted (Ljava/lang/CharSequence;I)Z - -
 method public isQuoteChar (Ljava/lang/CharSequence;I)Z - -
 method public isEscapeChar (Ljava/lang/CharSequence;I)Z - -
 method public isEscaped (Ljava/lang/CharSequence;I)Z - -
 method public,abstract isDelimiterChar (Ljava/lang/CharSequence;I)Z - -
in 24
class jline/console/completer/ArgumentCompleter$ArgumentDelimiter 49 public,interface,abstract java/lang/Object - -
 inner jline/console/completer/ArgumentCompleter$ArgumentList jline/console/completer/ArgumentCompleter ArgumentList public,static
 inner jline/console/completer/ArgumentCompleter$ArgumentDelimiter jline/console/completer/ArgumentCompleter ArgumentDelimiter public,static,interface,abstract
 method public,abstract delimit (Ljava/lang/CharSequence;I)Ljline/console/completer/ArgumentCompleter$ArgumentList; - -
 method public,abstract isDelimiter (Ljava/lang/CharSequence;I)Z - -
in 24
class jline/console/completer/ArgumentCompleter$ArgumentList 49 public,super java/lang/Object - -
 inner jline/console/completer/ArgumentCompleter$ArgumentList jline/console/completer/ArgumentCompleter ArgumentList public,static
 method public <init> ([Ljava/lang/String;III)V - -
 method public setCursorArgumentIndex (I)V - -
 method public getCursorArgumentIndex ()I - -
 method public getCursorArgument ()Ljava/lang/String; - -
 method public setArgumentPosition (I)V - -
 method public getArgumentPosition ()I - -
 method public setArguments ([Ljava/lang/String;)V - -
 method public getArguments ()[Ljava/lang/String; - -
 method public setBufferPosition (I)V - -
 method public getBufferPosition ()I - -
in 24
class jline/console/completer/ArgumentCompleter$WhitespaceArgumentDelimiter 49 public,super jline/console/completer/ArgumentCompleter$AbstractArgumentDelimiter - -
 inner jline/console/completer/ArgumentCompleter$WhitespaceArgumentDelimiter jline/console/completer/ArgumentCompleter WhitespaceArgumentDelimiter public,static
 inner jline/console/completer/ArgumentCompleter$AbstractArgumentDelimiter jline/console/completer/ArgumentCompleter AbstractArgumentDelimiter public,static,abstract
 method public <init> ()V - -
 method public isDelimiterChar (Ljava/lang/CharSequence;I)Z - -
in 24
class jline/console/completer/CandidateListCompletionHandler 49 public,super java/lang/Object jline/console/completer/CompletionHandler -
 inner jline/console/completer/CandidateListCompletionHandler$Messages jline/console/completer/CandidateListCompletionHandler Messages private,static,final,enum
 method public <init> ()V - -
 method public getPrintSpaceAfterFullCompletion ()Z - -
 method public setPrintSpaceAfterFullCompletion (Z)V - -
 method public isStripAnsi ()Z - -
 method public setStripAnsi (Z)V - -
 method public complete (Ljline/console/ConsoleReader;Ljava/util/List;I)Z (Ljline/console/ConsoleReader;Ljava/util/List<Ljava/lang/CharSequence;>;I)Z java/io/IOException
 method public,static setBuffer (Ljline/console/ConsoleReader;Ljava/lang/CharSequence;I)V - java/io/IOException
 method public,static printCandidates (Ljline/console/ConsoleReader;Ljava/util/Collection;)V (Ljline/console/ConsoleReader;Ljava/util/Collection<Ljava/lang/CharSequence;>;)V java/io/IOException
in 24
class jline/console/completer/CandidateListCompletionHandler$Messages 49 final,super,enum java/lang/Enum - Ljava/lang/Enum<Ljline/console/completer/CandidateListCompletionHandler$Messages;>;
 inner jline/console/completer/CandidateListCompletionHandler$Messages jline/console/completer/CandidateListCompletionHandler Messages private,static,final,enum
 field public,static,final,enum DISPLAY_CANDIDATES Ljline/console/completer/CandidateListCompletionHandler$Messages; -
 field public,static,final,enum DISPLAY_CANDIDATES_YES Ljline/console/completer/CandidateListCompletionHandler$Messages; -
 field public,static,final,enum DISPLAY_CANDIDATES_NO Ljline/console/completer/CandidateListCompletionHandler$Messages; -
 method public,static values ()[Ljline/console/completer/CandidateListCompletionHandler$Messages; - -
 method public,static valueOf (Ljava/lang/String;)Ljline/console/completer/CandidateListCompletionHandler$Messages; - -
 method public,varargs format ([Ljava/lang/Object;)Ljava/lang/String; - -
in 24
class jline/console/completer/Completer 49 public,interface,abstract java/lang/Object - -
 method public,abstract complete (Ljava/lang/String;ILjava/util/List;)I (Ljava/lang/String;ILjava/util/List<Ljava/lang/CharSequence;>;)I -
in 24
class jline/console/completer/CompletionHandler 49 public,interface,abstract java/lang/Object - -
 method public,abstract complete (Ljline/console/ConsoleReader;Ljava/util/List;I)Z (Ljline/console/ConsoleReader;Ljava/util/List<Ljava/lang/CharSequence;>;I)Z java/io/IOException
in 24
class jline/console/completer/EnumCompleter 49 public,super jline/console/completer/StringsCompleter - -
 method public <init> (Ljava/lang/Class;)V (Ljava/lang/Class<+Ljava/lang/Enum<*>;>;)V -
in 24
class jline/console/completer/FileNameCompleter 49 public,super java/lang/Object jline/console/completer/Completer -
 method public <init> ()V - -
 method public complete (Ljava/lang/String;ILjava/util/List;)I (Ljava/lang/String;ILjava/util/List<Ljava/lang/CharSequence;>;)I -
 method protected separator ()Ljava/lang/String; - -
 method protected getUserHome ()Ljava/io/File; - -
 method protected getUserDir ()Ljava/io/File; - -
 method protected matchFiles (Ljava/lang/String;Ljava/lang/String;[Ljava/io/File;Ljava/util/List;)I (Ljava/lang/String;Ljava/lang/String;[Ljava/io/File;Ljava/util/List<Ljava/lang/CharSequence;>;)I -
 method protected render (Ljava/io/File;Ljava/lang/CharSequence;)Ljava/lang/CharSequence; - -
in 24
class jline/console/completer/NullCompleter 49 public,final,super java/lang/Object jline/console/completer/Completer -
 field public,static,final INSTANCE Ljline/console/completer/NullCompleter; -
 method public <init> ()V - -
 method public complete (Ljava/lang/String;ILjava/util/List;)I (Ljava/lang/String;ILjava/util/List<Ljava/lang/CharSequence;>;)I -
in 24
class jline/console/completer/StringsCompleter 49 public,super java/lang/Object jline/console/completer/Completer -
 method public <init> ()V - -
 method public <init> (Ljava/util/Collection;)V (Ljava/util/Collection<Ljava/lang/String;>;)V -
 method public,varargs <init> ([Ljava/lang/String;)V - -
 method public getStrings ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
 method public complete (Ljava/lang/String;ILjava/util/List;)I (Ljava/lang/String;ILjava/util/List<Ljava/lang/CharSequence;>;)I -
in 24
class jline/console/history/FileHistory 49 public,super jline/console/history/MemoryHistory jline/console/history/PersistentHistory,java/io/Flushable -
 inner jline/console/history/History$Entry jline/console/history/History Entry public,static,interface,abstract
 method public <init> (Ljava/io/File;)V - java/io/IOException
 method public getFile ()Ljava/io/File; - -
 method public load (Ljava/io/File;)V - java/io/IOException
 method public load (Ljava/io/InputStream;)V - java/io/IOException
 method public load (Ljava/io/Reader;)V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public purge ()V - java/io/IOException
in 24
class jline/console/history/History 49 public,interface,abstract java/lang/Object java/lang/Iterable Ljava/lang/Object;Ljava/lang/Iterable<Ljline/console/history/History$Entry;>;
 inner jline/console/history/History$Entry jline/console/history/History Entry public,static,interface,abstract
 method public,abstract size ()I - -
 method public,abstract isEmpty ()Z - -
 method public,abstract index ()I - -
 method public,abstract clear ()V - -
 method public,abstract get (I)Ljava/lang/CharSequence; - -
 method public,abstract add (Ljava/lang/CharSequence;)V - -
 method public,abstract set (ILjava/lang/CharSequence;)V - -
 method public,abstract remove (I)Ljava/lang/CharSequence; - -
 method public,abstract removeFirst ()Ljava/lang/CharSequence; - -
 method public,abstract removeLast ()Ljava/lang/CharSequence; - -
 method public,abstract replace (Ljava/lang/CharSequence;)V - -
 method public,abstract entries (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<Ljline/console/history/History$Entry;>; -
 method public,abstract entries ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<Ljline/console/history/History$Entry;>; -
 method public,abstract iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Ljline/console/history/History$Entry;>; -
 method public,abstract current ()Ljava/lang/CharSequence; - -
 method public,abstract previous ()Z - -
 method public,abstract next ()Z - -
 method public,abstract moveToFirst ()Z - -
 method public,abstract moveToLast ()Z - -
 method public,abstract moveTo (I)Z - -
 method public,abstract moveToEnd ()V - -
in 24
class jline/console/history/History$Entry 49 public,interface,abstract java/lang/Object - -
 inner jline/console/history/History$Entry jline/console/history/History Entry public,static,interface,abstract
 method public,abstract index ()I - -
 method public,abstract value ()Ljava/lang/CharSequence; - -
in 24
class jline/console/history/MemoryHistory 49 public,super java/lang/Object jline/console/history/History -
 inner jline/console/history/MemoryHistory$EntriesIterator jline/console/history/MemoryHistory EntriesIterator private
 inner jline/console/history/MemoryHistory$EntryImpl jline/console/history/MemoryHistory EntryImpl private,static
 inner jline/console/history/History$Entry jline/console/history/History Entry public,static,interface,abstract
 field public,static,final DEFAULT_MAX_SIZE I - I500
 method public <init> ()V - -
 method public setMaxSize (I)V - -
 method public getMaxSize ()I - -
 method public isIgnoreDuplicates ()Z - -
 method public setIgnoreDuplicates (Z)V - -
 method public isAutoTrim ()Z - -
 method public setAutoTrim (Z)V - -
 method public size ()I - -
 method public isEmpty ()Z - -
 method public index ()I - -
 method public clear ()V - -
 method public get (I)Ljava/lang/CharSequence; - -
 method public set (ILjava/lang/CharSequence;)V - -
 method public add (Ljava/lang/CharSequence;)V - -
 method public remove (I)Ljava/lang/CharSequence; - -
 method public removeFirst ()Ljava/lang/CharSequence; - -
 method public removeLast ()Ljava/lang/CharSequence; - -
 method protected internalAdd (Ljava/lang/CharSequence;)V - -
 method public replace (Ljava/lang/CharSequence;)V - -
 method public entries (I)Ljava/util/ListIterator; (I)Ljava/util/ListIterator<Ljline/console/history/History$Entry;>; -
 method public entries ()Ljava/util/ListIterator; ()Ljava/util/ListIterator<Ljline/console/history/History$Entry;>; -
 method public iterator ()Ljava/util/Iterator; ()Ljava/util/Iterator<Ljline/console/history/History$Entry;>; -
 method public moveToLast ()Z - -
 method public moveTo (I)Z - -
 method public moveToFirst ()Z - -
 method public moveToEnd ()V - -
 method public current ()Ljava/lang/CharSequence; - -
 method public previous ()Z - -
 method public next ()Z - -
 method public toString ()Ljava/lang/String; - -
in 24
class jline/console/history/MemoryHistory$EntriesIterator 49 super java/lang/Object java/util/ListIterator Ljava/lang/Object;Ljava/util/ListIterator<Ljline/console/history/History$Entry;>;
 inner jline/console/history/MemoryHistory$EntriesIterator jline/console/history/MemoryHistory EntriesIterator private
 inner jline/console/history/History$Entry jline/console/history/History Entry public,static,interface,abstract
 inner jline/console/history/MemoryHistory$EntryImpl jline/console/history/MemoryHistory EntryImpl private,static
 method public next ()Ljline/console/history/History$Entry; - -
 method public previous ()Ljline/console/history/History$Entry; - -
 method public nextIndex ()I - -
 method public previousIndex ()I - -
 method public hasNext ()Z - -
 method public hasPrevious ()Z - -
 method public remove ()V - -
 method public set (Ljline/console/history/History$Entry;)V - -
 method public add (Ljline/console/history/History$Entry;)V - -
in 24
class jline/console/history/MemoryHistory$EntryImpl 49 super java/lang/Object jline/console/history/History$Entry -
 inner jline/console/history/MemoryHistory$EntryImpl jline/console/history/MemoryHistory EntryImpl private,static
 inner jline/console/history/History$Entry jline/console/history/History Entry public,static,interface,abstract
 method public <init> (ILjava/lang/CharSequence;)V - -
 method public index ()I - -
 method public value ()Ljava/lang/CharSequence; - -
 method public toString ()Ljava/lang/String; - -
in 24
class jline/console/history/PersistentHistory 49 public,interface,abstract java/lang/Object jline/console/history/History -
 method public,abstract flush ()V - java/io/IOException
 method public,abstract purge ()V - java/io/IOException
in 24
class jline/console/internal/ConsoleReaderInputStream 49 super java/io/SequenceInputStream - -
 inner jline/console/internal/ConsoleReaderInputStream$ConsoleLineInputStream jline/console/internal/ConsoleReaderInputStream ConsoleLineInputStream private,static
 inner jline/console/internal/ConsoleReaderInputStream$ConsoleEnumeration jline/console/internal/ConsoleReaderInputStream ConsoleEnumeration private,static
 method public,static setIn ()V - java/io/IOException
 method public,static setIn (Ljline/console/ConsoleReader;)V - -
 method public,static restoreIn ()V - -
 method public <init> (Ljline/console/ConsoleReader;)V - -
in 24
class jline/console/internal/ConsoleReaderInputStream$ConsoleEnumeration 49 super java/lang/Object java/util/Enumeration Ljava/lang/Object;Ljava/util/Enumeration<Ljava/io/InputStream;>;
 inner jline/console/internal/ConsoleReaderInputStream$ConsoleLineInputStream jline/console/internal/ConsoleReaderInputStream ConsoleLineInputStream private,static
 inner jline/console/internal/ConsoleReaderInputStream$ConsoleEnumeration jline/console/internal/ConsoleReaderInputStream ConsoleEnumeration private,static
 method public <init> (Ljline/console/ConsoleReader;)V - -
 method public nextElement ()Ljava/io/InputStream; - -
 method public hasMoreElements ()Z - -
in 24
class jline/console/internal/ConsoleReaderInputStream$ConsoleLineInputStream 49 super java/io/InputStream - -
 inner jline/console/internal/ConsoleReaderInputStream$ConsoleLineInputStream jline/console/internal/ConsoleReaderInputStream ConsoleLineInputStream private,static
 field protected wasNull Z -
 method public <init> (Ljline/console/ConsoleReader;)V - -
 method public read ()I - java/io/IOException
in 24
class jline/console/internal/ConsoleRunner 49 public,super java/lang/Object - -
 field public,static,final property Ljava/lang/String; - "jline.history"
 method public <init> ()V - -
 method public,static main ([Ljava/lang/String;)V - java/lang/Exception
