cg-stub-db 1
in 90
class net/minecraft/inventory/AnimalChest 50 public,super net/minecraft/inventory/InventoryBasic - -
 method public <init> (Lnet/minecraft/util/IChatComponent;I)V - -
 method public <init> (Ljava/lang/String;I)V - -
in 91
class net/minecraft/inventory/AnimalChest 50 public,super net/minecraft/inventory/InventoryBasic - -
 method public <init> (Lnet/minecraft/util/text/ITextComponent;I)V - -
 method public <init> (Ljava/lang/String;I)V - -
in 91
class net/minecraft/inventory/ClickType 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/inventory/ClickType;>;
 field public,static,final,enum PICKUP Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum QUICK_MOVE Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum SWAP Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum CLONE Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum THROW Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum QUICK_CRAFT Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum PICKUP_ALL Lnet/minecraft/inventory/ClickType; -
 method public,static values ()[Lnet/minecraft/inventory/ClickType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/inventory/ClickType; - -
in 326
class net/minecraft/inventory/ClickType 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/inventory/ClickType;>;
 field public,static,final,enum PICKUP Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum QUICK_MOVE Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum SWAP Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum CLONE Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum THROW Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum QUICK_CRAFT Lnet/minecraft/inventory/ClickType; -
 field public,static,final,enum PICKUP_ALL Lnet/minecraft/inventory/ClickType; -
 method public,static values ()[Lnet/minecraft/inventory/ClickType; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/inventory/ClickType; - -
in 90
class net/minecraft/inventory/Container 50 public,super,abstract java/lang/Object - -
 field public inventoryItemStacks Ljava/util/List; Ljava/util/List<Lnet/minecraft/item/ItemStack;>;
 field public inventorySlots Ljava/util/List; Ljava/util/List<Lnet/minecraft/inventory/Slot;>;
 field public windowId I -
 field protected crafters Ljava/util/List; Ljava/util/List<Lnet/minecraft/inventory/ICrafting;>;
 method public <init> ()V - -
 method protected addSlotToContainer (Lnet/minecraft/inventory/Slot;)Lnet/minecraft/inventory/Slot; - -
 method public onCraftGuiOpened (Lnet/minecraft/inventory/ICrafting;)V - -
 method public getInventory ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public removeCraftingFromCrafters (Lnet/minecraft/inventory/ICrafting;)V - -
 method public detectAndSendChanges ()V - -
 method public enchantItem (Lnet/minecraft/entity/player/EntityPlayer;I)Z - -
 method public getSlotFromInventory (Lnet/minecraft/inventory/IInventory;I)Lnet/minecraft/inventory/Slot; - -
 method public getSlot (I)Lnet/minecraft/inventory/Slot; - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public slotClick (IIILnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
 method protected retrySlotClick (IIZLnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public putStackInSlot (ILnet/minecraft/item/ItemStack;)V - -
 method public putStacksInSlots ([Lnet/minecraft/item/ItemStack;)V - -
 method public updateProgressBar (II)V - -
 method public getNextTransactionID (Lnet/minecraft/entity/player/InventoryPlayer;)S - -
 method public getCanCraft (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public setCanCraft (Lnet/minecraft/entity/player/EntityPlayer;Z)V - -
 method public,abstract canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected mergeItemStack (Lnet/minecraft/item/ItemStack;IIZ)Z - -
 method public,static extractDragMode (I)I - -
 method public,static getDragEvent (I)I - -
 method public,static func_94534_d (II)I - -
 method public,static isValidDragMode (ILnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected resetDrag ()V - -
 method public,static canAddItemToSlot (Lnet/minecraft/inventory/Slot;Lnet/minecraft/item/ItemStack;Z)Z - -
 method public,static computeStackSize (Ljava/util/Set;ILnet/minecraft/item/ItemStack;I)V (Ljava/util/Set<Lnet/minecraft/inventory/Slot;>;ILnet/minecraft/item/ItemStack;I)V -
 method public canDragIntoSlot (Lnet/minecraft/inventory/Slot;)Z - -
 method public,static calcRedstone (Lnet/minecraft/tileentity/TileEntity;)I - -
 method public,static calcRedstoneFromInventory (Lnet/minecraft/inventory/IInventory;)I - -
in 91
class net/minecraft/inventory/Container 50 public,super,abstract java/lang/Object - -
 field public inventoryItemStacks Ljava/util/List; Ljava/util/List<Lnet/minecraft/item/ItemStack;>;
 field public inventorySlots Ljava/util/List; Ljava/util/List<Lnet/minecraft/inventory/Slot;>;
 field public windowId I -
 field protected listeners Ljava/util/List; Ljava/util/List<Lnet/minecraft/inventory/IContainerListener;>;
 method public <init> ()V - -
 method protected addSlotToContainer (Lnet/minecraft/inventory/Slot;)Lnet/minecraft/inventory/Slot; - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public getInventory ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/ItemStack;>; -
 method public removeListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public enchantItem (Lnet/minecraft/entity/player/EntityPlayer;I)Z - -
 method public getSlotFromInventory (Lnet/minecraft/inventory/IInventory;I)Lnet/minecraft/inventory/Slot; - -
 method public getSlot (I)Lnet/minecraft/inventory/Slot; - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public slotClick (IILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
 method protected retrySlotClick (IIZLnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public putStackInSlot (ILnet/minecraft/item/ItemStack;)V - -
 method public putStacksInSlots ([Lnet/minecraft/item/ItemStack;)V - -
 method public updateProgressBar (II)V - -
 method public getNextTransactionID (Lnet/minecraft/entity/player/InventoryPlayer;)S - -
 method public getCanCraft (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public setCanCraft (Lnet/minecraft/entity/player/EntityPlayer;Z)V - -
 method public,abstract canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected mergeItemStack (Lnet/minecraft/item/ItemStack;IIZ)Z - -
 method public,static extractDragMode (I)I - -
 method public,static getDragEvent (I)I - -
 method public,static getQuickcraftMask (II)I - -
 method public,static isValidDragMode (ILnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected resetDrag ()V - -
 method public,static canAddItemToSlot (Lnet/minecraft/inventory/Slot;Lnet/minecraft/item/ItemStack;Z)Z - -
 method public,static computeStackSize (Ljava/util/Set;ILnet/minecraft/item/ItemStack;I)V (Ljava/util/Set<Lnet/minecraft/inventory/Slot;>;ILnet/minecraft/item/ItemStack;I)V -
 method public canDragIntoSlot (Lnet/minecraft/inventory/Slot;)Z - -
 method public,static calcRedstone (Lnet/minecraft/tileentity/TileEntity;)I - -
 method public,static calcRedstoneFromInventory (Lnet/minecraft/inventory/IInventory;)I - -
in 326
class net/minecraft/inventory/Container 52 public,super,abstract java/lang/Object - -
 field public inventoryItemStacks Lnet/minecraft/util/NonNullList; Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;
 field public inventorySlots Ljava/util/List; Ljava/util/List<Lnet/minecraft/inventory/Slot;>;
 field public windowId I -
 field protected listeners Ljava/util/List; Ljava/util/List<Lnet/minecraft/inventory/IContainerListener;>;
 method public <init> ()V - -
 method protected addSlotToContainer (Lnet/minecraft/inventory/Slot;)Lnet/minecraft/inventory/Slot; - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public getInventory ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public removeListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public enchantItem (Lnet/minecraft/entity/player/EntityPlayer;I)Z - -
 method public getSlotFromInventory (Lnet/minecraft/inventory/IInventory;I)Lnet/minecraft/inventory/Slot; - -
 method public getSlot (I)Lnet/minecraft/inventory/Slot; - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public slotClick (IILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method protected clearContainer (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/inventory/IInventory;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public putStackInSlot (ILnet/minecraft/item/ItemStack;)V - -
 method public setAll (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public updateProgressBar (II)V - -
 method public getNextTransactionID (Lnet/minecraft/entity/player/InventoryPlayer;)S - -
 method public getCanCraft (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public setCanCraft (Lnet/minecraft/entity/player/EntityPlayer;Z)V - -
 method public,abstract canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected mergeItemStack (Lnet/minecraft/item/ItemStack;IIZ)Z - -
 method public,static extractDragMode (I)I - -
 method public,static getDragEvent (I)I - -
 method public,static getQuickcraftMask (II)I - -
 method public,static isValidDragMode (ILnet/minecraft/entity/player/EntityPlayer;)Z - -
 method protected resetDrag ()V - -
 method public,static canAddItemToSlot (Lnet/minecraft/inventory/Slot;Lnet/minecraft/item/ItemStack;Z)Z - -
 method public,static computeStackSize (Ljava/util/Set;ILnet/minecraft/item/ItemStack;I)V (Ljava/util/Set<Lnet/minecraft/inventory/Slot;>;ILnet/minecraft/item/ItemStack;I)V -
 method public canDragIntoSlot (Lnet/minecraft/inventory/Slot;)Z - -
 method public,static calcRedstone (Lnet/minecraft/tileentity/TileEntity;)I - -
 method public,static calcRedstoneFromInventory (Lnet/minecraft/inventory/IInventory;)I - -
 method protected slotChangedCraftingGrid (Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/inventory/InventoryCraftResult;)V - -
in 90
class net/minecraft/inventory/ContainerBeacon 50 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/ContainerBeacon$BeaconSlot net/minecraft/inventory/ContainerBeacon BeaconSlot -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;)V - -
 method public onCraftGuiOpened (Lnet/minecraft/inventory/ICrafting;)V - -
 method public updateProgressBar (II)V - -
 method public func_180611_e ()Lnet/minecraft/inventory/IInventory; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/inventory/ContainerBeacon 50 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/ContainerBeacon$BeaconSlot net/minecraft/inventory/ContainerBeacon BeaconSlot -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public updateProgressBar (II)V - -
 method public getTileEntity ()Lnet/minecraft/inventory/IInventory; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/inventory/ContainerBeacon 52 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/ContainerBeacon$BeaconSlot net/minecraft/inventory/ContainerBeacon BeaconSlot -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public updateProgressBar (II)V - -
 method public getTileEntity ()Lnet/minecraft/inventory/IInventory; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 24
class net/minecraft/inventory/ContainerBeacon$BeaconSlot 50 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBeacon$BeaconSlot net/minecraft/inventory/ContainerBeacon BeaconSlot -
 method public <init> (Lnet/minecraft/inventory/ContainerBeacon;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
in 326
class net/minecraft/inventory/ContainerBeacon$BeaconSlot 52 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBeacon$BeaconSlot net/minecraft/inventory/ContainerBeacon BeaconSlot -
 method public <init> (Lnet/minecraft/inventory/ContainerBeacon;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
in 90
class net/minecraft/inventory/ContainerBrewingStand 50 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/ContainerBrewingStand$Potion net/minecraft/inventory/ContainerBrewingStand Potion static
 inner net/minecraft/inventory/ContainerBrewingStand$Ingredient net/minecraft/inventory/ContainerBrewingStand Ingredient -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;)V - -
 method public onCraftGuiOpened (Lnet/minecraft/inventory/ICrafting;)V - -
 method public detectAndSendChanges ()V - -
 method public updateProgressBar (II)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/inventory/ContainerBrewingStand 50 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/ContainerBrewingStand$Potion net/minecraft/inventory/ContainerBrewingStand Potion static
 inner net/minecraft/inventory/ContainerBrewingStand$Ingredient net/minecraft/inventory/ContainerBrewingStand Ingredient static
 inner net/minecraft/inventory/ContainerBrewingStand$Fuel net/minecraft/inventory/ContainerBrewingStand Fuel static
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public updateProgressBar (II)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/inventory/ContainerBrewingStand 52 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/ContainerBrewingStand$Potion net/minecraft/inventory/ContainerBrewingStand Potion static
 inner net/minecraft/inventory/ContainerBrewingStand$Ingredient net/minecraft/inventory/ContainerBrewingStand Ingredient static
 inner net/minecraft/inventory/ContainerBrewingStand$Fuel net/minecraft/inventory/ContainerBrewingStand Fuel static
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public updateProgressBar (II)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/inventory/ContainerBrewingStand$Fuel 50 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBrewingStand$Fuel net/minecraft/inventory/ContainerBrewingStand Fuel static
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static isValidBrewingFuel (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
in 326
class net/minecraft/inventory/ContainerBrewingStand$Fuel 52 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBrewingStand$Fuel net/minecraft/inventory/ContainerBrewingStand Fuel static
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public,static isValidBrewingFuel (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
in 90
class net/minecraft/inventory/ContainerBrewingStand$Ingredient 50 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBrewingStand$Ingredient net/minecraft/inventory/ContainerBrewingStand Ingredient -
 method public <init> (Lnet/minecraft/inventory/ContainerBrewingStand;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
in 91
class net/minecraft/inventory/ContainerBrewingStand$Ingredient 50 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBrewingStand$Ingredient net/minecraft/inventory/ContainerBrewingStand Ingredient static
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
in 326
class net/minecraft/inventory/ContainerBrewingStand$Ingredient 52 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBrewingStand$Ingredient net/minecraft/inventory/ContainerBrewingStand Ingredient static
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
in 24
class net/minecraft/inventory/ContainerBrewingStand$Potion 50 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBrewingStand$Potion net/minecraft/inventory/ContainerBrewingStand Potion static
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
 method public onPickupFromSlot (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public,static canHoldPotion (Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/inventory/ContainerBrewingStand$Potion 52 super net/minecraft/inventory/Slot - -
 inner net/minecraft/inventory/ContainerBrewingStand$Potion net/minecraft/inventory/ContainerBrewingStand Potion static
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getSlotStackLimit ()I - -
 method public onTake (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public,static canHoldPotion (Lnet/minecraft/item/ItemStack;)Z - -
in 24
class net/minecraft/inventory/ContainerChest 50 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getLowerChestInventory ()Lnet/minecraft/inventory/IInventory; - -
in 326
class net/minecraft/inventory/ContainerChest 52 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getLowerChestInventory ()Lnet/minecraft/inventory/IInventory; - -
in 24
class net/minecraft/inventory/ContainerDispenser 50 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/inventory/ContainerDispenser 52 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/inventory/ContainerEnchantment 50 public,super net/minecraft/inventory/Container - -
 field public tableInventory Lnet/minecraft/inventory/IInventory; -
 field public xpSeed I -
 field public enchantLevels [I -
 field public enchantmentIds [I -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)V - -
 method public onCraftGuiOpened (Lnet/minecraft/inventory/ICrafting;)V - -
 method public detectAndSendChanges ()V - -
 method public updateProgressBar (II)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public enchantItem (Lnet/minecraft/entity/player/EntityPlayer;I)Z - -
 method public getLapisAmount ()I - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/inventory/ContainerEnchantment 50 public,super net/minecraft/inventory/Container - -
 field public tableInventory Lnet/minecraft/inventory/IInventory; -
 field public xpSeed I -
 field public enchantLevels [I -
 field public enchantClue [I -
 field public worldClue [I -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method protected broadcastData (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public updateProgressBar (II)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public enchantItem (Lnet/minecraft/entity/player/EntityPlayer;I)Z - -
 method public getLapisAmount ()I - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/inventory/ContainerEnchantment 52 public,super net/minecraft/inventory/Container - -
 field public tableInventory Lnet/minecraft/inventory/IInventory; -
 field public xpSeed I -
 field public enchantLevels [I -
 field public enchantClue [I -
 field public worldClue [I -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method protected broadcastData (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public updateProgressBar (II)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public enchantItem (Lnet/minecraft/entity/player/EntityPlayer;I)Z - -
 method public getLapisAmount ()I - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/inventory/ContainerFurnace 50 public,super net/minecraft/inventory/Container - -
 method public updateProgressBar (II)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;)V - -
 method public onCraftGuiOpened (Lnet/minecraft/inventory/ICrafting;)V - -
 method public detectAndSendChanges ()V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 91
class net/minecraft/inventory/ContainerFurnace 50 public,super net/minecraft/inventory/Container - -
 method public updateProgressBar (II)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/inventory/ContainerFurnace 52 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;)V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public updateProgressBar (II)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
in 24
class net/minecraft/inventory/ContainerHopper 50 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 326
class net/minecraft/inventory/ContainerHopper 52 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 326
class net/minecraft/inventory/ContainerHorseChest 52 public,super net/minecraft/inventory/InventoryBasic - -
 method public <init> (Ljava/lang/String;I)V - -
 method public <init> (Lnet/minecraft/util/text/ITextComponent;I)V - -
in 24
class net/minecraft/inventory/ContainerHorseInventory 50 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/passive/EntityHorse;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 326
class net/minecraft/inventory/ContainerHorseInventory 52 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/passive/AbstractHorse;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 90
class net/minecraft/inventory/ContainerMerchant 50 public,super net/minecraft/inventory/Container - -
 method public updateProgressBar (II)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/IMerchant;Lnet/minecraft/world/World;)V - -
 method public getMerchantInventory ()Lnet/minecraft/inventory/InventoryMerchant; - -
 method public onCraftGuiOpened (Lnet/minecraft/inventory/ICrafting;)V - -
 method public detectAndSendChanges ()V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public setCurrentRecipeIndex (I)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 91
class net/minecraft/inventory/ContainerMerchant 50 public,super net/minecraft/inventory/Container - -
 method public updateProgressBar (II)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/IMerchant;Lnet/minecraft/world/World;)V - -
 method public getMerchantInventory ()Lnet/minecraft/inventory/InventoryMerchant; - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public detectAndSendChanges ()V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public setCurrentRecipeIndex (I)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 326
class net/minecraft/inventory/ContainerMerchant 52 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/IMerchant;Lnet/minecraft/world/World;)V - -
 method public getMerchantInventory ()Lnet/minecraft/inventory/InventoryMerchant; - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public setCurrentRecipeIndex (I)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 90
class net/minecraft/inventory/ContainerPlayer 50 public,super net/minecraft/inventory/Container - -
 field public craftMatrix Lnet/minecraft/inventory/InventoryCrafting; -
 field public craftResult Lnet/minecraft/inventory/IInventory; -
 field public isLocalWorld Z -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;ZLnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
in 91
class net/minecraft/inventory/ContainerPlayer 50 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public craftMatrix Lnet/minecraft/inventory/InventoryCrafting; -
 field public craftResult Lnet/minecraft/inventory/IInventory; -
 field public isLocalWorld Z -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;ZLnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
in 326
class net/minecraft/inventory/ContainerPlayer 52 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public craftMatrix Lnet/minecraft/inventory/InventoryCrafting; -
 field public craftResult Lnet/minecraft/inventory/InventoryCraftResult; -
 field public isLocalWorld Z -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;ZLnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
in 90
class net/minecraft/inventory/ContainerRepair 50 public,super net/minecraft/inventory/Container - -
 field public maximumCost I -
 field public materialCost I -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public updateRepairOutput ()V - -
 method public onCraftGuiOpened (Lnet/minecraft/inventory/ICrafting;)V - -
 method public updateProgressBar (II)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public updateItemName (Ljava/lang/String;)V - -
in 91
class net/minecraft/inventory/ContainerRepair 50 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public maximumCost I -
 field public materialCost I -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public updateRepairOutput ()V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public updateProgressBar (II)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public updateItemName (Ljava/lang/String;)V - -
in 326
class net/minecraft/inventory/ContainerRepair 52 public,super net/minecraft/inventory/Container - -
 inner net/minecraft/enchantment/Enchantment$Rarity net/minecraft/enchantment/Enchantment Rarity public,static,final,enum
 field public maximumCost I -
 field public materialCost I -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public updateRepairOutput ()V - -
 method public addListener (Lnet/minecraft/inventory/IContainerListener;)V - -
 method public updateProgressBar (II)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public updateItemName (Ljava/lang/String;)V - -
in 326
class net/minecraft/inventory/ContainerShulkerBox 52 public,super net/minecraft/inventory/Container - -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 90
class net/minecraft/inventory/ContainerWorkbench 50 public,super net/minecraft/inventory/Container - -
 field public craftMatrix Lnet/minecraft/inventory/InventoryCrafting; -
 field public craftResult Lnet/minecraft/inventory/IInventory; -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
in 91
class net/minecraft/inventory/ContainerWorkbench 50 public,super net/minecraft/inventory/Container - -
 field public craftMatrix Lnet/minecraft/inventory/InventoryCrafting; -
 field public craftResult Lnet/minecraft/inventory/IInventory; -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
in 326
class net/minecraft/inventory/ContainerWorkbench 52 public,super net/minecraft/inventory/Container - -
 field public craftMatrix Lnet/minecraft/inventory/InventoryCrafting; -
 field public craftResult Lnet/minecraft/inventory/InventoryCraftResult; -
 method public <init> (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
 method public onCraftMatrixChanged (Lnet/minecraft/inventory/IInventory;)V - -
 method public onContainerClosed (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public canInteractWith (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public transferStackInSlot (Lnet/minecraft/entity/player/EntityPlayer;I)Lnet/minecraft/item/ItemStack; - -
 method public canMergeSlot (Lnet/minecraft/item/ItemStack;Lnet/minecraft/inventory/Slot;)Z - -
in 91
class net/minecraft/inventory/EntityEquipmentSlot 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/inventory/EntityEquipmentSlot;>;
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public,static,final,enum MAINHAND Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum OFFHAND Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum FEET Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum LEGS Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum CHEST Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum HEAD Lnet/minecraft/inventory/EntityEquipmentSlot; -
 method public,static values ()[Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public getSlotType ()Lnet/minecraft/inventory/EntityEquipmentSlot$Type; - -
 method public getIndex ()I - -
 method public getSlotIndex ()I - -
 method public getName ()Ljava/lang/String; - -
 method public,static fromString (Ljava/lang/String;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
in 326
class net/minecraft/inventory/EntityEquipmentSlot 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/inventory/EntityEquipmentSlot;>;
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public,static,final,enum MAINHAND Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum OFFHAND Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum FEET Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum LEGS Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum CHEST Lnet/minecraft/inventory/EntityEquipmentSlot; -
 field public,static,final,enum HEAD Lnet/minecraft/inventory/EntityEquipmentSlot; -
 method public,static values ()[Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
 method public getSlotType ()Lnet/minecraft/inventory/EntityEquipmentSlot$Type; - -
 method public getIndex ()I - -
 method public getSlotIndex ()I - -
 method public getName ()Ljava/lang/String; - -
 method public,static fromString (Ljava/lang/String;)Lnet/minecraft/inventory/EntityEquipmentSlot; - -
in 91
class net/minecraft/inventory/EntityEquipmentSlot$Type 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/inventory/EntityEquipmentSlot$Type;>;
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public,static,final,enum HAND Lnet/minecraft/inventory/EntityEquipmentSlot$Type; -
 field public,static,final,enum ARMOR Lnet/minecraft/inventory/EntityEquipmentSlot$Type; -
 method public,static values ()[Lnet/minecraft/inventory/EntityEquipmentSlot$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/inventory/EntityEquipmentSlot$Type; - -
in 326
class net/minecraft/inventory/EntityEquipmentSlot$Type 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/inventory/EntityEquipmentSlot$Type;>;
 inner net/minecraft/inventory/EntityEquipmentSlot$Type net/minecraft/inventory/EntityEquipmentSlot Type public,static,final,enum
 field public,static,final,enum HAND Lnet/minecraft/inventory/EntityEquipmentSlot$Type; -
 field public,static,final,enum ARMOR Lnet/minecraft/inventory/EntityEquipmentSlot$Type; -
 method public,static values ()[Lnet/minecraft/inventory/EntityEquipmentSlot$Type; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/inventory/EntityEquipmentSlot$Type; - -
in 91
class net/minecraft/inventory/IContainerListener 50 public,interface,abstract java/lang/Object - -
 method public,abstract updateCraftingInventory (Lnet/minecraft/inventory/Container;Ljava/util/List;)V (Lnet/minecraft/inventory/Container;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public,abstract sendSlotContents (Lnet/minecraft/inventory/Container;ILnet/minecraft/item/ItemStack;)V - -
 method public,abstract sendProgressBarUpdate (Lnet/minecraft/inventory/Container;II)V - -
 method public,abstract sendAllWindowProperties (Lnet/minecraft/inventory/Container;Lnet/minecraft/inventory/IInventory;)V - -
in 326
class net/minecraft/inventory/IContainerListener 52 public,interface,abstract java/lang/Object - -
 method public,abstract sendAllContents (Lnet/minecraft/inventory/Container;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/inventory/Container;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
 method public,abstract sendSlotContents (Lnet/minecraft/inventory/Container;ILnet/minecraft/item/ItemStack;)V - -
 method public,abstract sendWindowProperty (Lnet/minecraft/inventory/Container;II)V - -
 method public,abstract sendAllWindowProperties (Lnet/minecraft/inventory/Container;Lnet/minecraft/inventory/IInventory;)V - -
in 90
class net/minecraft/inventory/ICrafting 50 public,interface,abstract java/lang/Object - -
 method public,abstract updateCraftingInventory (Lnet/minecraft/inventory/Container;Ljava/util/List;)V (Lnet/minecraft/inventory/Container;Ljava/util/List<Lnet/minecraft/item/ItemStack;>;)V -
 method public,abstract sendSlotContents (Lnet/minecraft/inventory/Container;ILnet/minecraft/item/ItemStack;)V - -
 method public,abstract sendProgressBarUpdate (Lnet/minecraft/inventory/Container;II)V - -
 method public,abstract sendAllWindowProperties (Lnet/minecraft/inventory/Container;Lnet/minecraft/inventory/IInventory;)V - -
in 90
class net/minecraft/inventory/IInvBasic 50 public,interface,abstract java/lang/Object - -
 method public,abstract onInventoryChanged (Lnet/minecraft/inventory/InventoryBasic;)V - -
in 90
class net/minecraft/inventory/IInventory 50 public,interface,abstract java/lang/Object net/minecraft/world/IWorldNameable -
 method public,abstract getSizeInventory ()I - -
 method public,abstract getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public,abstract removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public,abstract getInventoryStackLimit ()I - -
 method public,abstract markDirty ()V - -
 method public,abstract isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public,abstract getField (I)I - -
 method public,abstract setField (II)V - -
 method public,abstract getFieldCount ()I - -
 method public,abstract clear ()V - -
in 91
class net/minecraft/inventory/IInventory 50 public,interface,abstract java/lang/Object net/minecraft/world/IWorldNameable -
 method public,abstract getSizeInventory ()I - -
 method public,abstract getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public,abstract removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public,abstract getInventoryStackLimit ()I - -
 method public,abstract markDirty ()V - -
 method public,abstract isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public,abstract getField (I)I - -
 method public,abstract setField (II)V - -
 method public,abstract getFieldCount ()I - -
 method public,abstract clear ()V - -
in 326
class net/minecraft/inventory/IInventory 52 public,interface,abstract java/lang/Object net/minecraft/world/IWorldNameable -
 method public,abstract getSizeInventory ()I - -
 method public,abstract isEmpty ()Z - -
 method public,abstract getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public,abstract removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public,abstract setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public,abstract getInventoryStackLimit ()I - -
 method public,abstract markDirty ()V - -
 method public,abstract isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public,abstract openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public,abstract isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public,abstract getField (I)I - -
 method public,abstract setField (II)V - -
 method public,abstract getFieldCount ()I - -
 method public,abstract clear ()V - -
in 91
class net/minecraft/inventory/IInventoryChangedListener 50 public,interface,abstract java/lang/Object - -
 method public,abstract onInventoryChanged (Lnet/minecraft/inventory/InventoryBasic;)V - -
in 326
class net/minecraft/inventory/IInventoryChangedListener 52 public,interface,abstract java/lang/Object - -
 method public,abstract onInventoryChanged (Lnet/minecraft/inventory/IInventory;)V - -
in 24
class net/minecraft/inventory/ISidedInventory 50 public,interface,abstract java/lang/Object net/minecraft/inventory/IInventory -
 method public,abstract getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public,abstract canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public,abstract canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
in 326
class net/minecraft/inventory/ISidedInventory 52 public,interface,abstract java/lang/Object net/minecraft/inventory/IInventory -
 method public,abstract getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public,abstract canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public,abstract canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
in 90
class net/minecraft/inventory/InventoryBasic 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/util/IChatComponent;I)V - -
 method public <init> (Ljava/lang/String;ZI)V - -
 method public addInventoryChangeListener (Lnet/minecraft/inventory/IInvBasic;)V - -
 method public removeInventoryChangeListener (Lnet/minecraft/inventory/IInvBasic;)V - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public func_174894_a (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getSizeInventory ()I - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 91
class net/minecraft/inventory/InventoryBasic 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/util/text/ITextComponent;I)V - -
 method public <init> (Ljava/lang/String;ZI)V - -
 method public addInventoryChangeListener (Lnet/minecraft/inventory/IInventoryChangedListener;)V - -
 method public removeInventoryChangeListener (Lnet/minecraft/inventory/IInventoryChangedListener;)V - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public addItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getSizeInventory ()I - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 326
class net/minecraft/inventory/InventoryBasic 52 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Ljava/lang/String;ZI)V - -
 method public <init> (Lnet/minecraft/util/text/ITextComponent;I)V - -
 method public addInventoryChangeListener (Lnet/minecraft/inventory/IInventoryChangedListener;)V - -
 method public removeInventoryChangeListener (Lnet/minecraft/inventory/IInventoryChangedListener;)V - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public addItem (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 90
class net/minecraft/inventory/InventoryCraftResult 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 91
class net/minecraft/inventory/InventoryCraftResult 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 326
class net/minecraft/inventory/InventoryCraftResult 52 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public setRecipeUsed (Lnet/minecraft/item/crafting/IRecipe;)V - -
 method public getRecipeUsed ()Lnet/minecraft/item/crafting/IRecipe; - -
in 90
class net/minecraft/inventory/InventoryCrafting 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/inventory/Container;II)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getStackInRowAndColumn (II)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getHeight ()I - -
 method public getWidth ()I - -
in 91
class net/minecraft/inventory/InventoryCrafting 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/inventory/Container;II)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getStackInRowAndColumn (II)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getHeight ()I - -
 method public getWidth ()I - -
in 326
class net/minecraft/inventory/InventoryCrafting 52 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/inventory/Container;II)V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getStackInRowAndColumn (II)Lnet/minecraft/item/ItemStack; - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getHeight ()I - -
 method public getWidth ()I - -
 method public fillStackedContents (Lnet/minecraft/client/util/RecipeItemHelper;)V - -
in 90
class net/minecraft/inventory/InventoryEnderChest 50 public,super net/minecraft/inventory/InventoryBasic - -
 method public <init> ()V - -
 method public setChestTileEntity (Lnet/minecraft/tileentity/TileEntityEnderChest;)V - -
 method public loadInventoryFromNBT (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public saveInventoryToNBT ()Lnet/minecraft/nbt/NBTTagList; - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 91
class net/minecraft/inventory/InventoryEnderChest 50 public,super net/minecraft/inventory/InventoryBasic - -
 method public <init> ()V - -
 method public setChestTileEntity (Lnet/minecraft/tileentity/TileEntityEnderChest;)V - -
 method public loadInventoryFromNBT (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public saveInventoryToNBT ()Lnet/minecraft/nbt/NBTTagList; - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 326
class net/minecraft/inventory/InventoryEnderChest 52 public,super net/minecraft/inventory/InventoryBasic - -
 method public <init> ()V - -
 method public setChestTileEntity (Lnet/minecraft/tileentity/TileEntityEnderChest;)V - -
 method public loadInventoryFromNBT (Lnet/minecraft/nbt/NBTTagList;)V - -
 method public saveInventoryToNBT ()Lnet/minecraft/nbt/NBTTagList; - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
in 90
class net/minecraft/inventory/InventoryHelper 50 public,super java/lang/Object - -
 method public,static dropInventoryItems (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/inventory/IInventory;)V - -
 method public,static dropInventoryItems (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/inventory/IInventory;)V - -
in 91
class net/minecraft/inventory/InventoryHelper 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public,static dropInventoryItems (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/inventory/IInventory;)V - -
 method public,static dropInventoryItems (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/inventory/IInventory;)V - -
 method public,static spawnItemStack (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
in 326
class net/minecraft/inventory/InventoryHelper 52 public,super java/lang/Object - -
 method public,static dropInventoryItems (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/inventory/IInventory;)V - -
 method public,static dropInventoryItems (Lnet/minecraft/world/World;Lnet/minecraft/entity/Entity;Lnet/minecraft/inventory/IInventory;)V - -
 method public,static spawnItemStack (Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V - -
in 90
class net/minecraft/inventory/InventoryLargeChest 50 public,super java/lang/Object net/minecraft/world/ILockableContainer -
 method public <init> (Ljava/lang/String;Lnet/minecraft/world/ILockableContainer;Lnet/minecraft/world/ILockableContainer;)V - -
 method public getSizeInventory ()I - -
 method public isPartOfLargeChest (Lnet/minecraft/inventory/IInventory;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public isLocked ()Z - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public clear ()V - -
in 91
class net/minecraft/inventory/InventoryLargeChest 50 public,super java/lang/Object net/minecraft/world/ILockableContainer -
 method public <init> (Ljava/lang/String;Lnet/minecraft/world/ILockableContainer;Lnet/minecraft/world/ILockableContainer;)V - -
 method public getSizeInventory ()I - -
 method public isPartOfLargeChest (Lnet/minecraft/inventory/IInventory;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public isLocked ()Z - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public clear ()V - -
in 326
class net/minecraft/inventory/InventoryLargeChest 52 public,super java/lang/Object net/minecraft/world/ILockableContainer -
 method public <init> (Ljava/lang/String;Lnet/minecraft/world/ILockableContainer;Lnet/minecraft/world/ILockableContainer;)V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public isPartOfLargeChest (Lnet/minecraft/inventory/IInventory;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public markDirty ()V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public isLocked ()Z - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public clear ()V - -
in 90
class net/minecraft/inventory/InventoryMerchant 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/IMerchant;)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public getInventoryStackLimit ()I - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public markDirty ()V - -
 method public resetRecipeAndSlots ()V - -
 method public getCurrentRecipe ()Lnet/minecraft/village/MerchantRecipe; - -
 method public setCurrentRecipeIndex (I)V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 91
class net/minecraft/inventory/InventoryMerchant 50 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/IMerchant;)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public markDirty ()V - -
 method public resetRecipeAndSlots ()V - -
 method public getCurrentRecipe ()Lnet/minecraft/village/MerchantRecipe; - -
 method public setCurrentRecipeIndex (I)V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 326
class net/minecraft/inventory/InventoryMerchant 52 public,super java/lang/Object net/minecraft/inventory/IInventory -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/IMerchant;)V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public markDirty ()V - -
 method public resetRecipeAndSlots ()V - -
 method public getCurrentRecipe ()Lnet/minecraft/village/MerchantRecipe; - -
 method public setCurrentRecipeIndex (I)V - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 91
class net/minecraft/inventory/ItemStackHelper 50 public,super java/lang/Object - -
 method public,static getAndSplit ([Lnet/minecraft/item/ItemStack;II)Lnet/minecraft/item/ItemStack; - -
 method public,static getAndRemove ([Lnet/minecraft/item/ItemStack;I)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/inventory/ItemStackHelper 52 public,super java/lang/Object - -
 method public,static getAndSplit (Ljava/util/List;II)Lnet/minecraft/item/ItemStack; (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;II)Lnet/minecraft/item/ItemStack; -
 method public,static getAndRemove (Ljava/util/List;I)Lnet/minecraft/item/ItemStack; (Ljava/util/List<Lnet/minecraft/item/ItemStack;>;I)Lnet/minecraft/item/ItemStack; -
 method public,static saveAllItems (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/util/NonNullList;)Lnet/minecraft/nbt/NBTTagCompound; (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)Lnet/minecraft/nbt/NBTTagCompound; -
 method public,static saveAllItems (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/util/NonNullList;Z)Lnet/minecraft/nbt/NBTTagCompound; (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;Z)Lnet/minecraft/nbt/NBTTagCompound; -
 method public,static loadAllItems (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/util/NonNullList;)V (Lnet/minecraft/nbt/NBTTagCompound;Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>;)V -
in 90
class net/minecraft/inventory/Slot 50 public,super java/lang/Object - -
 field public,final inventory Lnet/minecraft/inventory/IInventory; -
 field public slotNumber I -
 field public xDisplayPosition I -
 field public yDisplayPosition I -
 field protected backgroundName Ljava/lang/String; -
 field protected backgroundLocation Lnet/minecraft/util/ResourceLocation; -
 field protected backgroundMap Ljava/lang/Object; -
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public onSlotChange (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
 method public onPickupFromSlot (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getStack ()Lnet/minecraft/item/ItemStack; - -
 method public getHasStack ()Z - -
 method public putStack (Lnet/minecraft/item/ItemStack;)V - -
 method public onSlotChanged ()V - -
 method public getSlotStackLimit ()I - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public getSlotTexture ()Ljava/lang/String; - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method public isHere (Lnet/minecraft/inventory/IInventory;I)Z - -
 method public canTakeStack (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public canBeHovered ()Z - -
 method public getBackgroundLocation ()Lnet/minecraft/util/ResourceLocation; - -
 method public setBackgroundLocation (Lnet/minecraft/util/ResourceLocation;)V - -
 method public setBackgroundName (Ljava/lang/String;)V - -
 method public getBackgroundSprite ()Lnet/minecraft/client/renderer/texture/TextureAtlasSprite; - -
 method protected getBackgroundMap ()Lnet/minecraft/client/renderer/texture/TextureMap; - -
 method public getSlotIndex ()I - -
in 91
class net/minecraft/inventory/Slot 50 public,super java/lang/Object - -
 field public,final inventory Lnet/minecraft/inventory/IInventory; -
 field public slotNumber I -
 field public xPos I -
 field public yPos I -
 field protected backgroundName Ljava/lang/String; -
 field protected backgroundLocation Lnet/minecraft/util/ResourceLocation; -
 field protected backgroundMap Ljava/lang/Object; -
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public onSlotChange (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
 method public onPickupFromSlot (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getStack ()Lnet/minecraft/item/ItemStack; - -
 method public getHasStack ()Z - -
 method public putStack (Lnet/minecraft/item/ItemStack;)V - -
 method public onSlotChanged ()V - -
 method public getSlotStackLimit ()I - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public getSlotTexture ()Ljava/lang/String; - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method public isHere (Lnet/minecraft/inventory/IInventory;I)Z - -
 method public canTakeStack (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public canBeHovered ()Z - -
 method public getBackgroundLocation ()Lnet/minecraft/util/ResourceLocation; - -
 method public setBackgroundLocation (Lnet/minecraft/util/ResourceLocation;)V - -
 method public setBackgroundName (Ljava/lang/String;)V - -
 method public getBackgroundSprite ()Lnet/minecraft/client/renderer/texture/TextureAtlasSprite; - -
 method protected getBackgroundMap ()Lnet/minecraft/client/renderer/texture/TextureMap; - -
 method public getSlotIndex ()I - -
 method public isSameInventory (Lnet/minecraft/inventory/Slot;)Z - -
in 326
class net/minecraft/inventory/Slot 52 public,super java/lang/Object - -
 field public,final inventory Lnet/minecraft/inventory/IInventory; -
 field public slotNumber I -
 field public xPos I -
 field public yPos I -
 field protected backgroundName Ljava/lang/String; -
 field protected backgroundLocation Lnet/minecraft/util/ResourceLocation; -
 field protected backgroundMap Ljava/lang/Object; -
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public onSlotChange (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemStack;)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onSwapCraft (I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
 method public onTake (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getStack ()Lnet/minecraft/item/ItemStack; - -
 method public getHasStack ()Z - -
 method public putStack (Lnet/minecraft/item/ItemStack;)V - -
 method public onSlotChanged ()V - -
 method public getSlotStackLimit ()I - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public getSlotTexture ()Ljava/lang/String; - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method public isHere (Lnet/minecraft/inventory/IInventory;I)Z - -
 method public canTakeStack (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public isEnabled ()Z - -
 method public getBackgroundLocation ()Lnet/minecraft/util/ResourceLocation; - -
 method public setBackgroundLocation (Lnet/minecraft/util/ResourceLocation;)V - -
 method public setBackgroundName (Ljava/lang/String;)V - -
 method public getBackgroundSprite ()Lnet/minecraft/client/renderer/texture/TextureAtlasSprite; - -
 method protected getBackgroundMap ()Lnet/minecraft/client/renderer/texture/TextureMap; - -
 method public getSlotIndex ()I - -
 method public isSameInventory (Lnet/minecraft/inventory/Slot;)Z - -
in 24
class net/minecraft/inventory/SlotCrafting 50 public,super net/minecraft/inventory/Slot - -
 inner net/minecraft/item/Item$ToolMaterial net/minecraft/item/Item ToolMaterial public,static,final,enum
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
 method public onPickupFromSlot (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
in 326
class net/minecraft/inventory/SlotCrafting 52 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/inventory/InventoryCrafting;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onSwapCraft (I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
 method public onTake (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
in 24
class net/minecraft/inventory/SlotFurnaceFuel 50 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public,static isBucket (Lnet/minecraft/item/ItemStack;)Z - -
in 326
class net/minecraft/inventory/SlotFurnaceFuel 52 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public getItemStackLimit (Lnet/minecraft/item/ItemStack;)I - -
 method public,static isBucket (Lnet/minecraft/item/ItemStack;)Z - -
in 24
class net/minecraft/inventory/SlotFurnaceOutput 50 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method public onPickupFromSlot (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
in 326
class net/minecraft/inventory/SlotFurnaceOutput 52 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method public onTake (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
in 24
class net/minecraft/inventory/SlotMerchantResult 50 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/IMerchant;Lnet/minecraft/inventory/InventoryMerchant;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
 method public onPickupFromSlot (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)V - -
in 326
class net/minecraft/inventory/SlotMerchantResult 52 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/entity/IMerchant;Lnet/minecraft/inventory/InventoryMerchant;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
 method public decrStackSize (I)Lnet/minecraft/item/ItemStack; - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;I)V - -
 method protected onCrafting (Lnet/minecraft/item/ItemStack;)V - -
 method public onTake (Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/ItemStack; - -
in 326
class net/minecraft/inventory/SlotShulkerBox 52 public,super net/minecraft/inventory/Slot - -
 method public <init> (Lnet/minecraft/inventory/IInventory;III)V - -
 method public isItemValid (Lnet/minecraft/item/ItemStack;)Z - -
