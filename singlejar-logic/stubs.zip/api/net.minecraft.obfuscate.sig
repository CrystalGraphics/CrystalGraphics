cg-stub-db 1
in 82
class net/minecraft/obfuscate/DontObfuscate 60 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 93
class net/minecraft/obfuscate/DontObfuscate 61 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
in 60
class net/minecraft/obfuscate/DontObfuscate 65 public,interface,abstract,annotation java/lang/Object java/lang/annotation/Annotation -
 anno visible @Ljava/lang/annotation/Retention;(value=ELjava/lang/annotation/RetentionPolicy;#CLASS)
